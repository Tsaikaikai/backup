﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;
using AOISystem.Halcon.Controls;

namespace AOISystem.Halcon.Recipe
{
    public static class ROIManager
    {
        private const string Xml_Root_Node = "Document";
        private const string Xml_Member_Node = "Member";
        private const string Xml_Property_Node = "Property";

        private const string Recipe_Root_Path = "Recipe\\";

        public static string ROIsFolderPath
        {
            get
            {
                if (RecipeManager.ActiveRecipe == null)
                {
                    throw new Exception("ActiveRecipe為null");
                }
                string xmlROIsFolderPath = string.Format(@"{0}\{1}{2:D3}_{3}\", Application.StartupPath, 
                    Recipe_Root_Path, RecipeManager.ActiveRecipe.RecipeNo, RecipeManager.ActiveRecipe.RecipeID);
                if (!Directory.Exists(xmlROIsFolderPath))
                {
                    throw new Exception(string.Format("{0:D3}_{1}資料夾不存在", RecipeManager.ActiveRecipe.RecipeNo, 
                        RecipeManager.ActiveRecipe.RecipeID));
                }
                return xmlROIsFolderPath;
            }
        }

        public static string ROIsFilePath
        {
            get
            {
                if (ROIsFolderPath == string.Empty)
                {
                    throw new Exception("XmlROIsFolderPath為Empty");
                }
                return string.Format("{0}ROIs.xml", ROIsFolderPath);
            }
        }

        #region - ROI Info Operation Methods -
        /// <summary>
        /// 根據Recipe Info取得ROI Info
        /// </summary>
        /// <param name="recipeInfo"></param>
        /// <returns></returns>
        public static ROIInfoCollection GetROIInfoCollection(RecipeInfo recipeInfo)
        {
            RecipeManager.ActiveRecipe = recipeInfo;
            return GetROIInfoCollection(ROIsFilePath);
        }
        /// <summary>
        /// 根據指定路徑取得ROI Info Collection
        /// </summary>
        /// <param name="rOIPath"></param>
        /// <returns></returns>
        public static ROIInfoCollection GetROIInfoCollection(string rOIPath)
        {
            if (!File.Exists(rOIPath))
            {
                return new ROIInfoCollection();
            }

            XDocument xDoc = XDocument.Load(rOIPath);
            ROIInfoCollection recipeInfoCollection = new ROIInfoCollection();

            foreach (XElement element in xDoc.Element(Xml_Root_Node).Element(Xml_Member_Node).Elements())
            {
                recipeInfoCollection.Add(new ROIInfo()
                {
                    Index = (int)element.Attribute("Index"),
                    RegionType = (int)element.Attribute("RegionType"),
                    InspectId = (int)element.Attribute("InspectId"),
                    X = (double)element.Attribute("X"),
                    Y = (double)element.Attribute("Y"),
                    Width = (double)element.Attribute("Width"),
                    Height = (double)element.Attribute("Height"),
                    Angle = (double)element.Attribute("Angle"),
                    Radius = (double)element.Attribute("Radius"),
                    ActiveColor = (HColorMode)Enum.Parse(typeof(HColorMode), (string)element.Attribute("ActiveColor")),
                    ActiveHColor = (HColorMode)Enum.Parse(typeof(HColorMode), (string)element.Attribute("ActiveHColor")),
                    InActiveColor = (HColorMode)Enum.Parse(typeof(HColorMode), (string)element.Attribute("InActiveColor"))
                });
            }
            return recipeInfoCollection;
        }
        /// <summary>
        /// 將ROI Info Collection儲存至當前Recipe Info
        /// </summary>
        /// <param name="rOIInfoCollection"></param>
        public static void SetROIInfoCollection(ROIInfoCollection rOIInfoCollection)
        {
            SetROIInfoCollection(RecipeManager.ActiveRecipe, rOIInfoCollection);
        }
        /// <summary>
        /// 將ROI Info Collection儲存至指定Recipe Info
        /// </summary>
        /// <param name="recipeInfo"></param>
        /// <param name="rOIInfoCollection"></param>
        public static void SetROIInfoCollection(RecipeInfo recipeInfo, ROIInfoCollection rOIInfoCollection)
        {
            string filePath = string.Format(@"{0}\{1}{2:D3}_{3}\ROIs.xml", Application.StartupPath, Recipe_Root_Path, recipeInfo.RecipeNo, recipeInfo.RecipeID);
            SetROIInfoCollection(filePath, rOIInfoCollection);
        }
        /// <summary>
        /// 將ROI Info Collection儲存至指定路徑
        /// </summary>
        /// <param name="rOIPath"></param>
        /// <param name="collection"></param>
        public static void SetROIInfoCollection(string rOIPath, ROIInfoCollection collection)
        {
            XDocument xDoc;
            if (System.IO.File.Exists(rOIPath) == false)
            {
                xDoc = new XDocument();
                XElement rootElement = new XElement(Xml_Root_Node);
                XElement memberElement = new XElement(Xml_Member_Node);

                rootElement.Add(memberElement);
                xDoc.Add(rootElement);
            }
            else
            {
                xDoc = XDocument.Load(rOIPath);
            }

            xDoc.Element(Xml_Root_Node).Element(Xml_Member_Node).RemoveNodes();

            foreach (ROIInfo recipe in collection)
            {
                xDoc.Element(Xml_Root_Node).Element(Xml_Member_Node).Add(new XElement(Xml_Property_Node,
                        new XAttribute("Index", recipe.Index),
                        new XAttribute("RegionType", recipe.RegionType),
                        new XAttribute("InspectId", recipe.InspectId),
                        new XAttribute("X", recipe.X),
                        new XAttribute("Y", recipe.Y),
                        new XAttribute("Width", recipe.Width),
                        new XAttribute("Height", recipe.Height),
                        new XAttribute("Angle", recipe.Angle),
                        new XAttribute("Radius", recipe.Radius),
                        new XAttribute("ActiveColor", recipe.ActiveColor),
                        new XAttribute("ActiveHColor", recipe.ActiveHColor),
                        new XAttribute("InActiveColor", recipe.InActiveColor)));
            }
            xDoc.Save(rOIPath);
        }
        #endregion - ROI Info Operation Methods -
    }
}
