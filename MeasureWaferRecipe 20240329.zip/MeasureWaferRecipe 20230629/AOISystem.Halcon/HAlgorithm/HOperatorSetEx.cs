﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HalconDotNet;


namespace AOISystem.Halcon.HAlgorithm
{
    public static class HOperatorSetEx
    {
        #region - Chapter_4 : File -
        #region - 4.1  Images -
        /// <summary>
        /// 讀取有不同文件格式的圖像
        /// </summary>
        /// <param name="fileName">圖檔路徑</param>
        /// <returns></returns>
        public static HObject ReadImage(HTuple fileName)
        {
            HObject image;
            HOperatorSet.ReadImage(out image, fileName);
            return image;
        }
        /// <summary>
        /// 用圖形格式寫圖像
        /// </summary>
        /// <param name="image"></param>
        public static void WriteImage(HObject image)
        {
            WriteImage(image, string.Format("{0}.bmp", DateTime.Now.ToString("yyyyMMdd_HHmmss")));
        }
        /// <summary>
        /// 用圖形格式寫圖像
        /// </summary>
        /// <param name="image"></param>
        /// <param name="fileName"></param>
        public static void WriteImage(HObject image, HTuple fileName)
        {
            HOperatorSet.WriteImage(image, "bmp", 0, fileName);
        }
        /// <summary>
        /// 用圖形格式寫圖像
        /// </summary>
        /// <param name="image"></param>
        /// <param name="format"></param>
        /// <param name="fileName"></param>
        public static void WriteImage(HObject image, HTuple format, HTuple fileName)
        {
            HOperatorSet.WriteImage(image, format, 0, fileName);
        }
        #endregion - 4.1  Images -
        #endregion - Chapter_4 : File -

        #region - Chapter_5 : Filter -
        #region - 5.5  Enhancement -
        /// <summary>
        /// 增強圖像對比度
        /// </summary>
        /// <param name="image"></param>
        /// <param name="maskWidth"></param>
        /// <param name="maskHeight"></param>
        /// <param name="factor"></param>
        /// <returns></returns>
        public static HObject Emphasize(HObject image, HTuple maskWidth, HTuple maskHeight, HTuple factor)
        {
            HObject imageEmphasize;
            HOperatorSet.Emphasize(image, out imageEmphasize, maskWidth, maskHeight, factor);
            return imageEmphasize;
        }
        #endregion - 5.5  Enhancement -

        #region - 5.7  Geometric-Transformations -
        /// <summary>
        /// 鏡像一個圖像
        /// </summary>
        /// <param name="image"></param>
        /// <param name="mode">'row', 'column', 'diagonal'</param>
        /// <returns></returns>
        public static HObject MirrorImage(HObject image, HTuple mode)
        {
            HObject imageMirror;
            HOperatorSet.MirrorImage(image, out imageMirror, mode);
            return imageMirror;
        }
        /// <summary>
        /// 以一個圖像的中心為圓心旋轉
        /// </summary>
        /// <param name="image">圖片來源</param>
        /// <param name="phi">旋轉角度</param>
        /// <returns></returns>
        public static HObject RotateImage(HObject image, HTuple phi)
        {
            return RotateImage(image, phi, "constant");
        }
        /// <summary>
        /// 以一個圖像的中心為圓心旋轉
        /// </summary>
        /// <param name="image">圖片來源</param>
        /// <param name="phi">旋轉角度</param>
        /// <param name="interpolation"></param>
        /// <returns></returns>
        public static HObject RotateImage(HObject image, HTuple phi, HTuple interpolation)
        {
            HObject imageRotate;
            HOperatorSet.RotateImage(image, out imageRotate, phi, interpolation);
            return imageRotate;
        }
        #endregion - 5.7  Geometric-Transformations -
        #endregion - Chapter_5 : Filter -

        #region - Chapter_7 : Image -
        #region - 7.1  Access -
        /// <summary>
        /// 獲取一個通道的指針
        /// </summary>
        /// <param name="image">圖檔</param>
        /// <param name="isDisposePointer"></param>
        /// <returns></returns>
        public static HImageInfo GetImagePointer1(HObject image, bool isDisposePointer)
        {
            HTuple pointer, type, width, height;
            HOperatorSet.GetImagePointer1(image, out pointer, out type, out width, out height);
            if (isDisposePointer)
            {
                image.Dispose();
            }
            HImageInfo hImageInfo = new HImageInfo()
            {
                Pointer = pointer,
                Type = type,
                Width = width,
                Height = height
            };
            return hImageInfo;
        }
        /// <summary>
        /// 獲取一個通道的指針
        /// </summary>
        /// <param name="fileName">圖片路徑</param>
        /// <returns></returns>
        public static HImageInfo GetImagePointer1(HTuple fileName, bool isDisposePointer)
        {
            return GetImagePointer1(ReadImage(fileName), isDisposePointer);
        }
        #endregion - 7.1  Access -

        #region - 7.4  Creation -
        /// <summary>
        /// 從像素的一個指針創建一個圖像
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="pixelPointer"></param>
        /// <returns></returns>
        public static HObject GenImage1(HTuple width, HTuple height, HTuple pixelPointer)
        {
            return GenImage1("byte", width, height, pixelPointer);
        }
        /// <summary>
        /// 從像素的一個指針創建一個圖像
        /// </summary>
        /// <param name="type"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="pixelPointer"></param>
        /// <returns></returns>
        public static HObject GenImage1(HTuple type, HTuple width, HTuple height, HTuple pixelPointer)
        {
            HObject image;
            HOperatorSet.GenImage1(out image, type, width, height, pixelPointer);
            return image;
        }
        #endregion - 7.4  Creation -

        #region - 7.7  Format -
        /// <summary>
        /// 去掉一個矩形圖像區域
        /// </summary>
        /// <param name="image"></param>
        /// <param name="row1"></param>
        /// <param name="column1"></param>
        /// <param name="row2"></param>
        /// <param name="column2"></param>
        /// <returns></returns>
        public static HObject CropRectangle1(HObject image, HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        {
            HObject imagePart;
            HOperatorSet.CropRectangle1(image, out imagePart, row1, column1, row2, column2);
            return imagePart;
        }
        #endregion - 7.7  Format -
        #endregion - Chapter_7 : Image -

        #region - Chapter_13 : Object -
        #region - 13.1  Information -
        /// <summary>
        /// 統計一個元組中的對象
        /// </summary>
        /// <param name="objects"></param>
        /// <returns></returns>
        public static HTuple CountObj(HObject objects)
        {
            HTuple number;
            HOperatorSet.CountObj(objects, out number);
            return number;
        }
        /// <summary>
        /// 一幅目標圖像組成部分的信息
        /// </summary>
        /// <param name="objectVal"></param>
        /// <param name="request">"creator", "type"</param>
        /// <param name="channel"></param>
        /// <returns></returns>
        public static HTuple GetChannelInfo(HObject objectVal, HTuple request, HTuple channel)
        {
            HTuple information;
            HOperatorSet.GetChannelInfo(objectVal, request, channel, out information);
            return information;
        }
        /// <summary>
        /// 比較目標圖像的平等性
        /// </summary>
        /// <param name="objects1">objects1</param>
        /// <param name="objects2">objects2</param>
        /// <returns></returns>
        public static bool TestEqualObj(HObject objects1, HObject objects2)
        {
            HTuple isEqual;
            if (!HOperatorSetEx.TestObjDef(objects2))
            {
                return false;
            }
            HOperatorSet.TestEqualObj(objects1, objects2, out isEqual);
            return isEqual == 1;
        }
        /// <summary>
        /// 測試目標是否被刪除
        /// </summary>
        /// <param name="objectVal"></param>
        /// <returns></returns>
        public static bool TestObjDef(HObject objectVal)
        {
            try
            {
                HTuple isDefined;
                HOperatorSet.CountObj(objectVal, out isDefined);
                if (isDefined.TupleLength() == 0)
                {
                    isDefined = -1;
                }
                else if (isDefined == 1)
                {
                    isDefined = objectVal.CountObj();
                }
                return isDefined >= 1;
            }
            catch
            {
                return false;
            }
        }
        #endregion - 13.1  Information -

        #region - 13.2  Manipulation -
        /// <summary>
        /// 連接兩個目標元組的圖標
        /// </summary>
        /// <param name="objects1"></param>
        /// <param name="objects2"></param>
        /// <returns></returns>
        public static HObject ConcatObj(HObject objects1, HObject objects2)
        {
            HObject objectsConcat;
            HOperatorSet.ConcatObj(objects1, objects2, out objectsConcat);
            return objectsConcat;
        }
        /// <summary>
        /// 創建一個空的目標元組
        /// </summary>
        /// <returns></returns>
        public static HObject GenEmptyObj()
        {
            HObject emptyObject;
            HOperatorSet.GenEmptyObj(out emptyObject);
            return emptyObject;
        }
        /// <summary>
        /// 從一個目標元組中選擇目標
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static HObject SelectObj(HObject objects, HTuple index)
        {
            HObject objectSelected;
            HOperatorSet.SelectObj(objects, out objectSelected, index);
            return objectSelected;
        }
        #endregion - 13.2  Manipulation -
        #endregion - Chapter_13 : Object -

        #region - Chapter_14 : Regions -
        #region - 14.2  Creation -
        /// <summary>
        /// 創建一個與坐標軸平行的長方形
        /// </summary>
        /// <param name="row1"></param>
        /// <param name="column1"></param>
        /// <param name="row2"></param>
        /// <param name="column2"></param>
        /// <returns></returns>
        public static HObject GenRectangle1(HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        {
            HObject rectangle;
            HOperatorSet.GenRectangle1(out  rectangle, row1, column1, row2, column2);
            return rectangle;
        }
        /// <summary>
        /// 將輸入線以區域形式存儲
        /// </summary>
        /// <param name="beginRow"></param>
        /// <param name="beginCol"></param>
        /// <param name="endRow"></param>
        /// <param name="endCol"></param>
        /// <returns></returns>
        public static HObject GenRegionLine(HTuple beginRow, HTuple beginCol, HTuple endRow, HTuple endCol)
        {
            HObject regionLines;
            HOperatorSet.GenRegionLine(out regionLines, beginRow, beginCol, endRow, endCol);
            return regionLines;
        }
        #endregion - 14.2  Creation -

        #region - 14.3  Features -
        /// <summary>
        /// 選擇彼此有某種關係的區域
        /// </summary>
        /// <param name="region1">region1</param>
        /// <param name="region2">region2</param>
        /// <param name="min">重疊最小值</param>
        /// <param name="max">重疊最大值</param>
        /// <returns></returns>
        public static HObject SelectShapeProto(HObject regions, HObject pattern, HTuple feature, HTuple min, HTuple max)
        {
            HObject selectedRegions;
            HOperatorSet.SelectShapeProto(regions, pattern, out selectedRegions, feature, min, max);
            return selectedRegions;
        }
        #endregion - 14.3  Features -

        #region - 14.5  Sets -
        /// <summary>
        /// 返回所有輸入區域的並集
        /// </summary>
        /// <param name="region"></param>
        /// <returns></returns>
        public static HObject Union1(HObject region)
        {
            HObject regionUnion;
            HOperatorSet.Union1(region, out  regionUnion);
            return regionUnion;
        }
        /// <summary>
        /// 返回兩個區域的並集
        /// </summary>
        /// <param name="region1"></param>
        /// <param name="region2"></param>
        /// <returns></returns>
        public static HObject Union2(HObject region1, HObject region2)
        {
            HObject regionUnion;
            HOperatorSet.Union2(region1, region2, out regionUnion);
            return regionUnion;
        }
        #endregion - 14.5  Sets -
        #endregion - Chapter_14 : Regions -

        #region - Chapter_18 : Tuple -
        #region - 18.5  Creation -
        /// <summary>
        /// 合併兩個元組為一個新的
        /// </summary>
        /// <param name="t1"></param>
        /// <param name="t2"></param>
        /// <returns></returns>
        public static HTuple TupleConcat(HTuple t1, HTuple t2)
        {
            HTuple concat;
            HOperatorSet.TupleConcat(t1, t2, out concat);
            return concat;
        }
        #endregion - 18.5  Creation -

        #region - 18.7  Features -
        /// <summary>
        /// 返回一個元組元素數目
        /// </summary>
        /// <param name="tuple"></param>
        /// <returns></returns>
        public static HTuple TupleLength(HTuple tuple)
        {
            HTuple length;
            HOperatorSet.TupleLength(tuple, out length);
            return length;
        }
        #endregion - 18.7  Features -

        #region - 18.9  Selection -
        /// <summary>
        /// 選擇一個元組中單一元素
        /// </summary>
        /// <param name="tuple"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static HTuple TupleSelect(HTuple tuple, HTuple index)
        {
            HTuple selected;
            HOperatorSet.TupleSelect(tuple, index, out selected);
            return selected;
        }
        #endregion - 18.9  Selection -
        #endregion - Chapter_18 : Tuple -

        #region - Chapter_19 : XLD -
        #region - 19.2  Creation -
        /// <summary>
        /// 根據每個輸入點交叉的形狀創鍵一個XLD輪廓(contour)
        /// </summary>
        /// <param name="row">row</param>
        /// <param name="col">col</param>
        /// <param name="size">size</param>
        /// <param name="angle">angle</param>
        /// <returns>cross</returns>
        public static HObject GenCrossContourXld(HTuple row, HTuple col, HTuple size, HTuple angle)
        {
            HObject cross;
            HOperatorSet.GenCrossContourXld(out cross, row, col, size, angle);
            return cross;
        }
        #endregion - 19.2  Creation -
        #endregion - Chapter_19 : XLD -



        #region - Union -

        ///// <summary>降低一幅圖像的Domain</summary>
        ///// <param name="image"></param>
        ///// <param name="region"></param>
        ///// <returns></returns>
        //public HObject ReduceDomain(HObject image, HObject region)
        //{
        //    HObject imageReduced;
        //    HOperatorSet.ReduceDomain(image, region, out  imageReduced);
        //    return imageReduced;
        //}
        ///// <summary>在圖像內搜尋角落</summary>
        ///// <param name="image"></param>
        ///// <param name="size"></param>
        ///// <param name="weight"></param>
        ///// <returns></returns>
        //public HObject CornerResponse(HObject image, HTuple size, HTuple weight)
        //{
        //    HObject imageCorner;
        //    HOperatorSet.CornerResponse(image, out  imageCorner, size, weight);
        //    return imageCorner;
        //}
        ///// <summary>在特徵形狀幫助下選擇regions</summary>
        ///// <param name="regions"></param>
        ///// <param name="features"></param>
        ///// <param name="operation"></param>
        ///// <param name="min"></param>
        ///// <param name="max"></param>
        ///// <returns></returns>
        //public HObject SelectShape(HObject regions, HTuple features, HTuple operation, HTuple min, HTuple max)
        //{
        //    HObject selectedRegions;
        //    HOperatorSet.SelectShape(regions, out  selectedRegions, features, operation, min, max);
        //    return selectedRegions;
        //}
        ///// <summary>在特徵形狀幫助下選擇regions</summary>
        ///// <param name="regions"></param>
        ///// <param name="percent"></param>
        ///// <returns></returns>
        //public HObject SelectShapeStd(HObject regions, HTuple shape, HTuple percent)
        //{
        //    //"max_area"
        //    HObject selectedRegions;
        //    HOperatorSet.SelectShapeStd(regions, out selectedRegions, shape, percent);
        //    return selectedRegions;
        //}
        #endregion - Union -



        ///// <summary>HObject清除</summary>
        ///// <param name="hObject"></param>
        ///// <returns>true:清除成功, false:清除失敗</returns>
        //public bool Dispose(HObject hObject)
        //{
        //    try
        //    {
        //        HOperatorSet.ClearObj(hObject);
        //        hObject.Dispose();
        //        return true;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //}
        //#region Math
        ///// <summary>
        ///// 找最小
        ///// </summary>
        ///// <param name="input">輸入值</param>
        ///// <returns></returns>
        //public HTuple TupleMin(HTuple input)
        //{
        //    HTuple output;
        //    HOperatorSet.TupleMin(input, out output);
        //    return output;
        //}
        ///// <summary>
        ///// 環狀?
        ///// </summary>
        ///// <param name="input"></param>
        ///// <returns></returns>
        //public HTuple Circularity(HObject input)
        //{
        //    HTuple output;
        //    HOperatorSet.Circularity(input, out output);
        //    return output;
        //}
        //#endregion

        //#region Draw
        ///// <summary>
        ///// 利用顏色範圍尋找中心點
        ///// </summary>
        ///// <returns></returns>
        //public HTuple[] ObtainCentralPoint(HObject image, HTuple lowColor, HTuple highColor)
        //{
        //    HObject ImageReduced;
        //    HTuple Row, Column, Area;
        //    HTuple CenterCol_U, CenterRow_U;
        //    HTuple[] Mark1Pos = new HTuple[2];

        //    HOperatorSet.GrayClosingRect(image, out ImageReduced, 50, 50);
        //    HOperatorSet.GrayOpeningRect(ImageReduced, out ImageReduced, 25, 25);
        //    HOperatorSet.ScaleImageMax(ImageReduced, out ImageReduced);
        //    HOperatorSet.Threshold(ImageReduced, out ImageReduced, lowColor, highColor);
        //    HOperatorSet.AreaCenter(ImageReduced, out Area, out Row, out Column);
        //    Mark1Pos[0] = Column;
        //    Mark1Pos[1] = Row;
        //    return Mark1Pos;
        //}

        ///// <summary>
        ///// 計算角度偏移量
        ///// </summary>
        ///// <param name="list"></param>
        ///// <returns></returns>
        //public double FindAngleError(HTuple[] mark1Pos, HTuple[] mark2Pos)
        //{
        //    HTuple ATan;
        //    HTuple dx, dy;
        //    dx = mark2Pos[0] - mark1Pos[0];
        //    dy = mark2Pos[1] - mark1Pos[1];
        //    HOperatorSet.TupleAtan(dx / dy, out ATan);
        //    return -ATan * 180 / Math.PI;
        //}

        ///// <summary>
        ///// 縮放圖
        ///// </summary>
        ///// <param name="width"></param>
        ///// <param name="height"></param>
        ///// <param name="interpolation"></param>
        ///// <returns></returns>
        //public HObject ZoomImageSize(HObject image, HTuple width, HTuple height, HTuple interpolation)
        //{
        //    HObject imageZoom;
        //    HOperatorSet.ZoomImageSize(image, out imageZoom, width, height, interpolation);
        //    return imageZoom;
        //}
        ///// <summary>
        ///// 取最大灰階
        ///// </summary>
        ///// <param name="image"></param>
        ///// <returns></returns>
        //public HObject ScaleImageMax(HObject image)
        //{
        //    HObject imageScaleMax;
        //    HOperatorSet.ScaleImageMax(image, out imageScaleMax);
        //    return imageScaleMax;
        //}
        ///// <summary>
        ///// 畫方塊
        ///// </summary>
        ///// <param name="row"></param>
        ///// <param name="column"></param>
        ///// <param name="phi"></param>
        ///// <param name="length1"></param>
        ///// <param name="length2"></param>
        ///// <returns></returns>
        //public HObject GenRectangle2(HTuple row, HTuple column, HTuple phi, HTuple length1, HTuple length2)
        //{
        //    HObject rectAngle;
        //    HOperatorSet.GenRectangle2(out rectAngle, row, column, phi, length1, length2);
        //    return rectAngle;
        //}
        ///// <summary>
        ///// 利用顏色範圍尋找兩圖差異區域
        ///// </summary>
        ///// <param name="RegionErosion2">被比較圖</param>
        ///// <param name="ImageRotate">主圖</param>
        ///// <param name="LowColor">主圖顏色範圍低灰階</param>
        ///// <param name="HighColor">主圖顏色範圍高灰階</param>
        ///// <returns></returns>
        //public HObject FindAreaOfDifference(HObject RegionErosion, HObject ImageRotate, HTuple LowColor, HTuple HighColor)
        //{
        //    HObject Region;
        //    HObject RegionDifference;
        //    Region = Threshold(ImageRotate, LowColor, HighColor);
        //    RegionDifference = Difference(RegionErosion, Region);
        //    return Connection(RegionDifference);
        //}
        ///// <summary>
        ///// 取某顏色範圍
        ///// </summary>
        ///// <param name="ImageRotate"></param>
        ///// <param name="LowColor"></param>
        ///// <param name="HighColor"></param>
        ///// <returns></returns>
        //public HObject Threshold(HObject ImageRotate, HTuple LowColor, HTuple HighColor)
        //{
        //    HObject Region;
        //    HOperatorSet.Threshold(ImageRotate, out Region, LowColor, HighColor);
        //    return Region;
        //}
        ///// <summary>
        ///// 清除細微錯誤區域
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="width"></param>
        ///// <param name="height"></param>
        ///// <returns></returns>
        //public HObject OpeningRectangle1(HObject region, HTuple width, HTuple height)
        //{
        //    HObject regionOpening;
        //    HOperatorSet.OpeningRectangle1(region, out regionOpening, width, height);
        //    return regionOpening;
        //}
        ///// <summary>
        ///// 尋找不相同的部分
        ///// </summary>
        ///// <param name="RegionErosion"></param>
        ///// <param name="Region"></param>
        ///// <returns></returns>
        //public HObject Difference(HObject RegionErosion, HObject Region)
        //{
        //    HObject RegionDifference;
        //    HOperatorSet.Difference(RegionErosion, Region, out  RegionDifference);
        //    return RegionDifference;
        //}
        ///// <summary>
        ///// 區域相連 沒相連的分為不同區塊的集合
        ///// </summary>
        ///// <param name="RegionDifference"></param>
        ///// <returns></returns>
        //public HObject Connection(HObject RegionDifference)
        //{
        //    HObject ConnectedRegions;
        //    HOperatorSet.Connection(RegionDifference, out ConnectedRegions);
        //    return ConnectedRegions;
        //}
        ///// <summary>
        ///// 圓形渲染,小洞會被關閉
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="radius"></param>
        ///// <returns></returns>
        //public HObject DilationCircle(HObject region, HTuple radius)
        //{
        //    HObject regionDilation;
        //    HOperatorSet.DilationCircle(region, out  regionDilation, radius);
        //    return regionDilation;
        //}
        ///// <summary>
        ///// 圍繞與同等的斧平行的長方形。 並傳回資訊
        ///// </summary>
        ///// <param name="regions"></param>
        ///// <returns></returns>
        //public HTuple[] SmallestRectangle1(HObject regions)
        //{
        //    HTuple row1, column1, row2, column2;
        //    HTuple[] Parameters = new HTuple[4]; ;
        //    HOperatorSet.SmallestRectangle1(regions, out  row1, out  column1, out  row2, out  column2);
        //    Parameters[0] = row1;
        //    Parameters[1] = column1;
        //    Parameters[2] = row2;
        //    Parameters[3] = column2;
        //    return Parameters;
        //}
        ///// <summary>
        ///// 於圖像取出一塊矩形
        ///// </summary>
        ///// <param name="image"></param>
        ///// <param name="row1"></param>
        ///// <param name="column1"></param>
        ///// <param name="row2"></param>
        ///// <param name="column2"></param>
        ///// <returns></returns>
        //public HObject CropRectangle1(HObject image, HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        //{
        //    HObject imagePart;
        //    HOperatorSet.CropRectangle1(image, out  imagePart, row1, column1, row2, column2);
        //    return imagePart;
        //}
        ///// <summary>
        ///// 被從確定的灰階執中剪下
        ///// </summary>
        ///// <param name="image"></param>
        ///// <returns></returns>
        //public HObject CropDomain(HObject image)
        //{
        //    HObject imagePart;
        //    HOperatorSet.CropDomain(image, out  imagePart);
        //    return imagePart;
        //}
        //#endregion

        //#region CAD
        ///// <summary>
        ///// 影像灰階反向
        ///// </summary>
        ///// <param name="input"></param>
        ///// <returns></returns>
        //public HObject BitNot(HObject input)
        //{
        //    HObject output;
        //    HOperatorSet.BitNot(input, out output);
        //    return output;
        //}
        ///// <summary>
        ///// 平均灰階
        ///// </summary>
        ///// <param name="input"></param>
        ///// <param name="width">遮罩寬</param>
        ///// <param name="height">遮罩高</param>
        ///// <returns></returns>
        //public HObject MeanImage(HObject input, HTuple width, HTuple height)
        //{
        //    HObject output;
        //    HOperatorSet.MeanImage(input, out output, width, height);
        //    return output;
        //}
        ///// <summary>
        ///// 動態2值化
        ///// </summary>
        ///// <param name="input1">原始影像</param>
        ///// <param name="input2">比對影像</param>
        ///// <param name="offset">灰階偏移量</param>
        ///// <returns>2值化結果</returns>
        //public HObject DynThreshold(HObject input1, HObject input2, HTuple offset)
        //{
        //    HObject output;
        //    HOperatorSet.DynThreshold(input1, input2, out output, offset, "light");
        //    return output;
        //}
        ///// <summary>
        ///// 合併Defect
        ///// </summary>
        ///// <param name="input">輸入圖像</param>
        ///// <param name="width">範圍寬</param>
        ///// <param name="height">範圍高</param>
        ///// <param name="number">範圍內個數</param>
        ///// <returns></returns>
        //public HObject RankRegion(HObject input, HTuple width, HTuple height, HTuple number)
        //{
        //    HObject output;
        //    HOperatorSet.RankRegion(input, out output, width, height, number);
        //    return output;
        //}
        ///// <summary>
        ///// 選擇灰階
        ///// </summary>
        ///// <param name="image">輸入圖像</param>
        ///// <param name="region">輸入範圍</param>
        ///// <param name="min">最小值</param>
        ///// <param name="max">最大值</param>
        ///// <returns></returns>
        //public HObject SelectGray(HObject image, HObject region, HTuple min, HTuple max)
        //{
        //    HObject output;
        //    HOperatorSet.SelectGray(region, image, out output, "mean", "and", min, max);
        //    return output;
        //}
        ///// <summary>
        ///// 在Region範圍內填入灰階
        ///// </summary>
        ///// <param name="image">輸入影像</param>
        ///// <param name="region">輸入範圍</param>
        ///// <param name="grayValue">灰階值</param>
        ///// <returns></returns>
        //public HObject PaintRegion(HObject image, HObject region, HTuple grayValue)
        //{
        //    HObject output;
        //    HOperatorSet.PaintRegion(region, image, out output, grayValue, "fill");
        //    return output;
        //}
        ///// <summary>
        ///// 細線化
        ///// </summary>
        ///// <param name="region"></param>
        ///// <returns></returns>
        //public HObject Skeleton(HObject region)
        //{
        //    HObject output;
        //    HOperatorSet.Skeleton(region, out output);
        //    return output;
        //}
        ///// <summary>
        ///// 縮放
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="scaleWidth"></param>
        ///// <param name="scaleHeight"></param>
        ///// <returns></returns>
        //public HObject ZoomRegion(HObject region, HTuple scaleWidth, HTuple scaleHeight)
        //{
        //    HObject regionZoom;
        //    HOperatorSet.ZoomRegion(region, out  regionZoom, scaleWidth, scaleHeight);
        //    return regionZoom;

        //}
        ///// <summary>
        ///// 讀2近位圖或是Halcon region
        ///// </summary>
        ///// <param name="rOIPath"></param>
        ///// <returns></returns>
        //public HObject ReadRegion(string rOIPath)
        //{
        //    HObject Region;
        //    HOperatorSet.ReadRegion(out Region, rOIPath);
        //    return Region;
        //}
        ///// <summary>
        ///// 移動Region到指定位置
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="row"></param>
        ///// <param name="column"></param>
        ///// <returns></returns>
        //public HObject MoveRegion(HObject region, HTuple row, HTuple column)
        //{
        //    HObject regionMoved;
        //    HOperatorSet.MoveRegion(region, out regionMoved, row, column);
        //    return regionMoved;
        //}
        ///// <summary>
        ///// 合併2Region
        ///// </summary>
        ///// <param name="region1"></param>
        ///// <param name="region2"></param>
        ///// <returns></returns>
        //public HObject Intersection(HObject region1, HObject region2)
        //{
        //    HObject regionIntersection;
        //    HOperatorSet.Intersection(region1, region2, out regionIntersection);
        //    return regionIntersection;
        //}
        ///// <summary>
        ///// 透過circular structuring element.打開1 Region
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="radius"></param>
        ///// <returns></returns>
        //public HObject OpeningCircle(HObject region, HTuple radius)
        //{
        //    HObject regionOpening;
        //    HOperatorSet.OpeningCircle(region, out  regionOpening, radius);
        //    return regionOpening;
        //}
        ///// <summary>
        ///// 侵蝕region 
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="radius"></param>
        ///// <returns></returns>
        //public HObject ErosionCircle(HObject region, HTuple radius)
        //{
        //    HObject regionErosion;
        //    HOperatorSet.ErosionCircle(region, out regionErosion, radius);
        //    return regionErosion;
        //}
        ///// <summary>
        ///// 矩形侵蝕region
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="width"></param>
        ///// <param name="height"></param>
        ///// <returns></returns>
        //public HObject ErosionRectangle1(HObject region, HTuple width, HTuple height)
        //{
        //    HObject regionErosion;
        //    HOperatorSet.ErosionRectangle1(region, out  regionErosion, width, height);
        //    return regionErosion;
        //}
        ///// <summary>
        ///// 用  circular structuring element 關閉 region
        ///// </summary>
        ///// <param name="region"></param>
        ///// <param name="radius"></param>
        ///// <returns></returns>
        //public HObject ClosingCircle(HObject region, HTuple radius)
        //{
        //    HObject regionClosing;
        //    HOperatorSet.ClosingCircle(region, out  regionClosing, radius);
        //    return regionClosing;
        //}
        //#endregion

        //#region ShapeModel
        ///// <summary>
        ///// 產生ShapeModel
        ///// </summary>
        //public void CreatShapeModel(HObject image, string rOIPath)
        //{
        //    HTuple ModelID;
        //    //create_shape_model (ImageReduced, 'auto', -0.39, 0.79, 'auto', 'auto', 'use_polarity', 'auto', 'auto', ModelID)
        //    HOperatorSet.CreateShapeModel(image, "auto", -0.39, 0.79, "auto", "auto", "use_polarity", "auto", "auto", out ModelID);

        //    //HOperatorSet.CreateShapeModel(m_Himage, NumLevels, AngleExtent, AngleExtent, AngleStep, Optimization, Metric, Contrast, MinContrast, out ModelID);
        //    WriteShapeModel(rOIPath, ModelID);
        //    //HOperatorSet.WriteShapeModel(ModelID,@"D:\Tmp\halcon\wModel.shm");
        //}
        ///// <summary>
        ///// 寫入ShapeModel
        ///// </summary>
        ///// <param name="url"></param>
        ///// <param name="ModelID"></param>
        //public void WriteShapeModel(string url, HTuple ModelID)
        //{
        //    HOperatorSet.WriteShapeModel(ModelID, url);
        //}
        ///// <summary>
        ///// 讀取ShapeModel
        ///// </summary>
        ///// <param name="url"></param>
        ///// <returns></returns>
        //public HTuple ReadShapeModel(string url)
        //{
        //    HTuple ModelID;
        //    HOperatorSet.ReadShapeModel(url, out ModelID);
        //    return ModelID;
        //}
        ///// <summary>
        ///// 尋找ShapeModel目標
        ///// </summary>
        ///// <returns></returns>
        //public HTuple[] FindShapeModel(HObject image, HTuple modelID)
        //{

        //    HTuple Row, Column, Angle, Score;
        //    HTuple[] Output = new HTuple[4];
        //    //find_shape_model (Desert, ModelID, -0.39, 0.78, 0.5, 1, 0.5, 'least_squares', 0, 0.9, Row, Column, Angle, Score)
        //    HOperatorSet.FindShapeModel(image, modelID, -0.1, 0.1, 0.5, 1, 0.5, "least_squares", 0, 0.9, out Row, out Column, out Angle, out Score);
        //    Output[0] = Row;
        //    Output[1] = Column;
        //    Output[2] = Angle;
        //    Output[3] = Score;
        //    return Output;
        //}
        //#endregion
    }

    public class HImageInfo
    {
        public HTuple Pointer { get; set; }

        public HTuple Type { get; set; }

        public HTuple Width { get; set; }

        public HTuple Height { get; set; }
    }
}
