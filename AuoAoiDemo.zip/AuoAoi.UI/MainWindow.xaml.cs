using System.Windows;
using System.Windows.Controls;

namespace AuoAoi.UI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainTab.SelectedIndex = 0;
        }

        /// <summary>
        /// 統一處理導覽按鈕點擊事件。
        /// NavBar 中所有 RadioButton 都指向此 handler。
        /// 切換邏輯依 Content 字串對應 TabIndex，與原始 AuoAoiTemplate 一致。
        /// </summary>
        private void NavButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton btn)
            {
                switch (btn.Content.ToString())
                {
                    case "Home":    MainTab.SelectedIndex = 0; break;
                    case "Manual":  MainTab.SelectedIndex = 1; break;
                    case "Recipe":  MainTab.SelectedIndex = 2; break;
                    case "History": MainTab.SelectedIndex = 3; break;
                    case "Log":     MainTab.SelectedIndex = 4; break;
                    case "MSA":     MainTab.SelectedIndex = 5; break;
                }
            }
        }
    }
}
