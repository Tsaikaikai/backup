using AuoAoi.Core.Models;
using AuoAoi.Core.StateMachine;
using AuoAoi.Infrastructure.Logging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace AuoAoi.UI.ViewModels
{
    // ════════════════════════════════════════════════════════════════
    // HomeViewModel
    // 職責：Home 頁面的即時監控資料（Live Image 佔位、Session 流程進度）
    // ════════════════════════════════════════════════════════════════
    public class HomeViewModel : ViewModelBase
    {
        private SessionState _sessionState = SessionState.Waiting;
        public  SessionState SessionState
        {
            get => _sessionState;
            set
            {
                SetField(ref _sessionState, value);
                OnPropertyChanged(nameof(SessionStateText));
            }
        }

        public string SessionStateText => _sessionState.ToString().ToUpperInvariant();

        // Session 流程步驟（供 Status 區顯示進度點）
        public ObservableCollection<SessionStepItem> SessionSteps { get; }
            = new ObservableCollection<SessionStepItem>
            {
                new SessionStepItem { StepName = "1. 取像 (Acquisition)" },
                new SessionStepItem { StepName = "2. 檢測 (Inspection)" },
                new SessionStepItem { StepName = "3. 上報 (MES Report)"  },
                new SessionStepItem { StepName = "4. 存圖 (Image Save)"  },
            };

        public void UpdateSessionState(SessionState state)
        {
            SessionState = state;
            // 依狀態更新步驟高亮
            for (int i = 0; i < SessionSteps.Count; i++)
                SessionSteps[i].IsActive = (i == (int)state - 1);
        }
    }

    public class SessionStepItem : ViewModelBase
    {
        public string StepName { get; set; }

        private bool _isActive;
        public bool IsActive
        {
            get => _isActive;
            set => SetField(ref _isActive, value);
        }
    }


    // ════════════════════════════════════════════════════════════════
    // ManualViewModel
    // 職責：手動單步操作（Trigger 單次取像，顯示結果）
    // ════════════════════════════════════════════════════════════════
    public class ManualViewModel : ViewModelBase
    {
        private string _manualStatusText = "Ready for manual test.";
        public  string ManualStatusText
        {
            get => _manualStatusText;
            set => SetField(ref _manualStatusText, value);
        }

        public RelayCommand ManualTriggerCommand { get; }

        public ManualViewModel()
        {
            ManualTriggerCommand = new RelayCommand(() =>
            {
                // Demo：顯示觸發訊息（實際應呼叫 Engine.ManualGrab()）
                ManualStatusText = $"[{DateTime.Now:HH:mm:ss}] Manual trigger fired.";
            });
        }
    }


    // ════════════════════════════════════════════════════════════════
    // RecipeViewModel
    // 職責：顯示並切換 Recipe
    // ════════════════════════════════════════════════════════════════
    public class RecipeViewModel : ViewModelBase
    {
        private readonly RecipeManager _recipeManager;

        public ObservableCollection<string> RecipeNames { get; } = new ObservableCollection<string>();

        private string _selectedRecipeName;
        public string SelectedRecipeName
        {
            get => _selectedRecipeName;
            set
            {
                SetField(ref _selectedRecipeName, value);
                OnPropertyChanged(nameof(CurrentRecipe));
            }
        }

        public RecipeData CurrentRecipe => _recipeManager.Current;

        public RelayCommand LoadRecipeCommand { get; }

        public RecipeViewModel(RecipeManager recipeManager)
        {
            _recipeManager = recipeManager;
            foreach (var name in recipeManager.GetAllNames())
                RecipeNames.Add(name);

            _selectedRecipeName = recipeManager.Current?.ModelName;

            LoadRecipeCommand = new RelayCommand(() =>
            {
                if (!string.IsNullOrEmpty(_selectedRecipeName))
                {
                    _recipeManager.Load(_selectedRecipeName);
                    OnPropertyChanged(nameof(CurrentRecipe));
                }
            });
        }
    }


    // ════════════════════════════════════════════════════════════════
    // HistoryViewModel
    // 職責：顯示所有檢測歷史紀錄，支援篩選
    // ════════════════════════════════════════════════════════════════
    public class HistoryViewModel : ViewModelBase
    {
        private readonly ObservableCollection<InspectionRecord> _allRecords
            = new ObservableCollection<InspectionRecord>();

        public ObservableCollection<InspectionRecord> DisplayRecords { get; }
            = new ObservableCollection<InspectionRecord>();

        private string _filterKeyword = string.Empty;
        public string FilterKeyword
        {
            get => _filterKeyword;
            set { SetField(ref _filterKeyword, value); ApplyFilter(); }
        }

        private bool _showNgOnly;
        public bool ShowNgOnly
        {
            get => _showNgOnly;
            set { SetField(ref _showNgOnly, value); ApplyFilter(); }
        }

        public void AddRecord(InspectionRecord record)
        {
            _allRecords.Insert(0, record);   // 最新的在最上面
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            DisplayRecords.Clear();
            IEnumerable<InspectionRecord> filtered = _allRecords;

            if (_showNgOnly)
                filtered = filtered.Where(r => !r.IsOk);

            if (!string.IsNullOrWhiteSpace(_filterKeyword))
                filtered = filtered.Where(r =>
                    r.GlassId.IndexOf(_filterKeyword, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    r.DefectType.IndexOf(_filterKeyword, StringComparison.OrdinalIgnoreCase) >= 0);

            foreach (var r in filtered)
                DisplayRecords.Add(r);
        }
    }


    // ════════════════════════════════════════════════════════════════
    // LogViewModel
    // 職責：顯示即時 Log，支援等級篩選
    // ════════════════════════════════════════════════════════════════
    public class LogViewModel : ViewModelBase
    {
        private readonly ObservableCollection<LogEntry> _allEntries
            = new ObservableCollection<LogEntry>();

        public ObservableCollection<LogEntry> DisplayEntries { get; }
            = new ObservableCollection<LogEntry>();

        private string _levelFilter = "All";
        public string LevelFilter
        {
            get => _levelFilter;
            set { SetField(ref _levelFilter, value); ApplyFilter(); }
        }

        public List<string> LevelOptions { get; }
            = new List<string> { "All", "Info", "Warning", "Error", "Debug" };

        // ── 6. CLEAR 按鈕 Command ─────────────────────────────────────
        public RelayCommand ClearCommand { get; }

        public LogViewModel()
        {
            ClearCommand = new RelayCommand(() =>
            {
                _allEntries.Clear();
                DisplayEntries.Clear();
            });
        }

        public void AddLog(Core.Interfaces.LogLevel level, string message)
        {
            var entry = new LogEntry { Level = level.ToString(), Message = message, Time = DateTime.Now };
            _allEntries.Insert(0, entry);
            if (_allEntries.Count > 1000) _allEntries.RemoveAt(_allEntries.Count - 1);
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            DisplayEntries.Clear();
            IEnumerable<LogEntry> filtered = _allEntries;
            if (_levelFilter != "All")
                filtered = filtered.Where(e => e.Level.Equals(_levelFilter, StringComparison.OrdinalIgnoreCase));
            foreach (var e in filtered)
                DisplayEntries.Add(e);
        }
    }

    public class LogEntry
    {
        public string   Level   { get; set; }
        public string   Message { get; set; }
        public DateTime Time    { get; set; }
    }


    // ════════════════════════════════════════════════════════════════
    // MsaViewModel
    // 職責：MSA / GRR 統計分析（Demo：顯示假數據）
    // ════════════════════════════════════════════════════════════════
    public class MsaViewModel : ViewModelBase
    {
        public ObservableCollection<MsaRow> MsaData { get; }
            = new ObservableCollection<MsaRow>();

        private string _grrResult = "—";
        public string GrrResult
        {
            get => _grrResult;
            set => SetField(ref _grrResult, value);
        }

        public RelayCommand RunGrrCommand { get; }

        public MsaViewModel()
        {
            RunGrrCommand = new RelayCommand(() =>
            {
                // Demo：產生假的 GRR 數據
                MsaData.Clear();
                var rng = new Random();
                for (int i = 1; i <= 10; i++)
                    MsaData.Add(new MsaRow
                    {
                        SampleId    = $"S{i:D3}",
                        Operator1   = Math.Round(0.5 + rng.NextDouble() * 0.2, 4),
                        Operator2   = Math.Round(0.5 + rng.NextDouble() * 0.2, 4),
                        Repeatability = Math.Round(rng.NextDouble() * 0.05, 4)
                    });

                GrrResult = "GRR = 8.2%  ✓ Acceptable (< 10%)";
            });
        }
    }

    public class MsaRow
    {
        public string SampleId      { get; set; }
        public double Operator1     { get; set; }
        public double Operator2     { get; set; }
        public double Repeatability { get; set; }
    }
}
