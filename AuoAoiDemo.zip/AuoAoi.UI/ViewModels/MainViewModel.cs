using AuoAoi.Core.Models;
using AuoAoi.Core.StateMachine;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;

namespace AuoAoi.UI.ViewModels
{
    /// <summary>
    /// 主視窗 ViewModel。
    /// 職責：
    ///   1. 持有 MainEngine，是 UI 與 Core 的唯一橋樑
    ///   2. 訂閱 Engine 事件，更新 ObservableProperty 通知 UI
    ///   3. 將 UI 按鈕（RelayCommand）轉換為 Engine Command 呼叫
    ///   4. 維護今日統計數據，供 Home 頁面顯示
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        #region Fields

        private readonly MainEngine  _engine;
        private readonly Dispatcher  _dispatcher = Application.Current.Dispatcher;
        private readonly Random      _rng        = new Random();
        private int                  _glassSeq   = 1;

        #endregion

        #region Properties — 系統狀態

        private SystemState _systemState;
        public SystemState SystemState
        {
            get => _systemState;
            private set
            {
                SetField(ref _systemState, value);
                OnPropertyChanged(nameof(SystemStateText));
                OnPropertyChanged(nameof(IsRunning));
                OnPropertyChanged(nameof(CanStart));
                OnPropertyChanged(nameof(CanStop));
                OnPropertyChanged(nameof(StatusBarText));
                OnPropertyChanged(nameof(StatusLightColor));

                StartCommand.RaiseCanExecuteChanged();
                StopCommand.RaiseCanExecuteChanged();
                AckErrorCommand.RaiseCanExecuteChanged();
            }
        }

        public string SystemStateText => _systemState.ToString().ToUpperInvariant();
        public bool   IsRunning       => _systemState == SystemState.Running;
        public bool   CanStart        => _systemState == SystemState.Idle
                                      || _systemState == SystemState.Ready;
        public bool   CanStop         => _systemState == SystemState.Running;

        // ── 5. Status Bar 底部文字 ────────────────────────────────────
        public string StatusBarText
        {
            get
            {
                switch (_systemState)
                {
                    case SystemState.Initializing: return "Initializing... | AUO Production Line A";
                    case SystemState.Idle:         return "System Idle | AUO Production Line A";
                    case SystemState.Ready:        return "System Ready | AUO Production Line A";
                    case SystemState.Running:      return "● Auto Running | AUO Production Line A";
                    case SystemState.Maintenance:  return "Maintenance Mode | AUO Production Line A";
                    case SystemState.Resetting:    return "Resetting... | AUO Production Line A";
                    case SystemState.Error:        return "⚠ ERROR — Click ACK to reset | AUO Production Line A";
                    case SystemState.ShuttingDown: return "Shutting down... | AUO Production Line A";
                    default:                       return "AUO Production Line A";
                }
            }
        }

        // ── 5. 指示燈顏色：Running=綠、Error=紅、其他=灰 ───────────────
        public Brush StatusLightColor
        {
            get
            {
                switch (_systemState)
                {
                    case SystemState.Running:  return new SolidColorBrush(Color.FromRgb(0x32, 0x87, 0x32)); // AuoOK
                    case SystemState.Error:    return new SolidColorBrush(Color.FromRgb(0xE6, 0x5F, 0x5A)); // AuoNG
                    default:                   return new SolidColorBrush(Color.FromRgb(0x96, 0x96, 0x96)); // AuoGray
                }
            }
        }

        #endregion

        #region Properties — Session 流程步驟（Home 右下角進度指示）

        private SessionState _currentSessionState = SessionState.Waiting;
        public SessionState CurrentSessionState
        {
            get => _currentSessionState;
            private set
            {
                SetField(ref _currentSessionState, value);
                OnPropertyChanged(nameof(Step1Active));
                OnPropertyChanged(nameof(Step2Active));
                OnPropertyChanged(nameof(Step3Active));
                OnPropertyChanged(nameof(Step4Active));
            }
        }

        public bool Step1Active => _currentSessionState == SessionState.Processing;
        public bool Step2Active => _currentSessionState == SessionState.Judging;
        public bool Step3Active => _currentSessionState == SessionState.Reporting;
        public bool Step4Active => _currentSessionState == SessionState.Transferring
                                || _currentSessionState == SessionState.Completed;

        #endregion

        #region Properties — 最新檢測結果

        private string _lastResultText = "—";
        public string LastResultText
        {
            get => _lastResultText;
            private set => SetField(ref _lastResultText, value);
        }

        private string _lastDefectType = string.Empty;
        public string LastDefectType
        {
            get => _lastDefectType;
            private set => SetField(ref _lastDefectType, value);
        }

        private double _lastScore;
        public double LastScore
        {
            get => _lastScore;
            private set => SetField(ref _lastScore, value);
        }

        private bool _lastIsOk = true;
        public bool LastIsOk
        {
            get => _lastIsOk;
            private set
            {
                SetField(ref _lastIsOk, value);
                // ── 2. 結果卡片顏色隨 OK/NG 切換 ──────────────────────
                OnPropertyChanged(nameof(ResultBorderBrush));
                OnPropertyChanged(nameof(ResultForeground));
            }
        }

        // ── 2. INSPECTION RESULT 卡片顏色 ────────────────────────────
        public Brush ResultBorderBrush => _lastIsOk
            ? new SolidColorBrush(Color.FromRgb(0x32, 0x87, 0x32))   // AuoOK 綠
            : new SolidColorBrush(Color.FromRgb(0xE6, 0x5F, 0x5A));  // AuoNG 紅

        public Brush ResultForeground => _lastIsOk
            ? new SolidColorBrush(Color.FromRgb(0x32, 0x87, 0x32))
            : new SolidColorBrush(Color.FromRgb(0xE6, 0x5F, 0x5A));

        #endregion

        #region Properties — 當日統計

        private int _todayTotal;
        public int TodayTotal
        {
            get => _todayTotal;
            private set
            {
                SetField(ref _todayTotal, value);
                OnPropertyChanged(nameof(TodayNgRate));
            }
        }

        private int _todayNg;
        public int TodayNg
        {
            get => _todayNg;
            private set
            {
                SetField(ref _todayNg, value);
                OnPropertyChanged(nameof(TodayNgRate));
            }
        }

        public double TodayNgRate => TodayTotal == 0 ? 0.0 : (double)TodayNg / TodayTotal * 100.0;

        #endregion

        #region Properties — Product ID（每片自動更新）

        private string _currentRunId  = "AUO-AUTO-001";
        private string _currentModel  = "AUO-G123-V1";
        private string _currentLot    = "B260319A01";
        private string _currentGlassId = "G01-260319-A3-001";

        public string CurrentRunId
        {
            get => _currentRunId;
            private set => SetField(ref _currentRunId, value);
        }
        public string CurrentModel
        {
            get => _currentModel;
            private set => SetField(ref _currentModel, value);
        }
        public string CurrentLot
        {
            get => _currentLot;
            private set => SetField(ref _currentLot, value);
        }
        public string CurrentGlassId
        {
            get => _currentGlassId;
            private set => SetField(ref _currentGlassId, value);
        }

        /// <summary>每次 Session 開始時產生新的假 GlassId，模擬換片</summary>
        private void GenerateNextGlassId()
        {
            _glassSeq++;
            var date   = DateTime.Now.ToString("yyMMdd");
            var row    = (char)('A' + (_glassSeq % 5));
            CurrentRunId   = $"AUO-AUTO-{_glassSeq:D3}";
            CurrentGlassId = $"G{_glassSeq:D2}-{date}-{row}3-{(_glassSeq % 999):D3}";
        }

        #endregion

        #region Properties — 操作員 / 系統資訊

        private string _operatorName = "OPERATOR";
        public string OperatorName
        {
            get => _operatorName;
            set => SetField(ref _operatorName, value);
        }

        // ── 4. 含時分秒，每秒更新 ────────────────────────────────────
        public string CurrentDateTime => DateTime.Now.ToString("yyyy/MM/dd  HH:mm:ss");

        #endregion

        #region Commands

        public RelayCommand StartCommand    { get; }
        public RelayCommand StopCommand     { get; }
        public RelayCommand AckErrorCommand { get; }

        #endregion

        #region Sub ViewModels

        public HomeViewModel    HomeVm    { get; }
        public ManualViewModel  ManualVm  { get; }
        public RecipeViewModel  RecipeVm  { get; }
        public HistoryViewModel HistoryVm { get; }
        public LogViewModel     LogVm     { get; }
        public MsaViewModel     MsaVm     { get; }

        #endregion

        #region Constructor

        public MainViewModel(
            MainEngine engine,
            HomeViewModel    homeVm,
            ManualViewModel  manualVm,
            RecipeViewModel  recipeVm,
            HistoryViewModel historyVm,
            LogViewModel     logVm,
            MsaViewModel     msaVm)
        {
            _engine   = engine;
            HomeVm    = homeVm;
            ManualVm  = manualVm;
            RecipeVm  = recipeVm;
            HistoryVm = historyVm;
            LogVm     = logVm;
            MsaVm     = msaVm;

            _engine.StateChanged        += OnEngineStateChanged;
            _engine.InspectionCompleted += OnInspectionCompleted;
            _engine.SessionStateChanged += OnSessionStateChanged;

            _systemState = engine.State;

            StartCommand    = new RelayCommand(ExecuteStart,    () => CanStart);
            StopCommand     = new RelayCommand(ExecuteStop,     () => CanStop);
            AckErrorCommand = new RelayCommand(ExecuteAckError, () => SystemState == SystemState.Error);

            _ = _engine.InitializeAsync();

            // ── 時鐘每秒更新（Header 時間 + StatusBar）────────────────
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) => OnPropertyChanged(nameof(CurrentDateTime));
            timer.Start();
        }

        #endregion

        #region Command Handlers

        private void ExecuteStart()
        {
            _engine.LoadRecipe(_engine.CurrentRecipe.ModelName);
            _engine.Start();
        }

        private async void ExecuteStop()
        {
            await _engine.StopAsync();
        }

        private async void ExecuteAckError()
        {
            await _engine.AcknowledgeErrorAsync();
        }

        #endregion

        #region Engine Event Handlers

        private void OnEngineStateChanged(SystemState newState)
        {
            _dispatcher.Invoke(() => SystemState = newState);
        }

        private void OnSessionStateChanged(SessionState state)
        {
            _dispatcher.Invoke(() =>
            {
                // ── 1. Session 開始取像時產生新 GlassId ──────────────
                if (state == SessionState.Processing)
                    GenerateNextGlassId();

                CurrentSessionState = state;
            });
        }

        private void OnInspectionCompleted(InspectionRecord record)
        {
            _dispatcher.Invoke(() =>
            {
                LastIsOk       = record.IsOk;
                LastResultText = record.IsOk ? "OK" : "NG";
                LastDefectType = record.IsOk ? string.Empty : record.DefectType;
                LastScore      = record.Score;

                TodayTotal++;
                if (!record.IsOk) TodayNg++;

                HistoryVm.AddRecord(record);

                CurrentSessionState = SessionState.Waiting;
            });
        }

        #endregion
    }
}
