using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace AuoAoi.UI.ViewModels
{
    /// <summary>
    /// ViewModel 基底類別。
    /// 實作 INotifyPropertyChanged，子類別使用 SetField() 更新屬性即可自動通知 UI。
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 設定欄位值並觸發 PropertyChanged。
        /// 使用範例：SetField(ref _state, value);
        /// </summary>
        protected bool SetField<T>(ref T field, T value,
            [CallerMemberName] string propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    /// <summary>
    /// ICommand 標準實作。
    /// ViewModel 中所有按鈕命令都使用 RelayCommand，
    /// 讓 UI 與邏輯完全解耦：XAML 只需 Binding，不寫 Click event。
    /// </summary>
    public class RelayCommand : ICommand
    {
        private readonly Action<object>    _execute;
        private readonly Func<object,bool> _canExecute;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute    = execute    ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        // 簡易建構子（無參數版）
        public RelayCommand(Action execute, Func<bool> canExecute = null)
            : this(_ => execute(), canExecute == null ? (Func<object,bool>)null : _ => canExecute()) { }

        public bool CanExecute(object parameter) => _canExecute?.Invoke(parameter) ?? true;
        public void Execute(object parameter)    => _execute(parameter);

        public event EventHandler CanExecuteChanged
        {
            add    => System.Windows.Input.CommandManager.RequerySuggested += value;
            remove => System.Windows.Input.CommandManager.RequerySuggested -= value;
        }

        /// <summary>手動觸發 CanExecuteChanged（例如狀態改變後）</summary>
        public void RaiseCanExecuteChanged()
            => System.Windows.Input.CommandManager.InvalidateRequerySuggested();
    }
}
