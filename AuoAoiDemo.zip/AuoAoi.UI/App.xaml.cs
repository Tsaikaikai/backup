using AuoAoi.Core.StateMachine;
using AuoAoi.Infrastructure.Algorithm;
using AuoAoi.Infrastructure.Camera;
using AuoAoi.Infrastructure.Data;
using AuoAoi.Infrastructure.Lighting;
using AuoAoi.Infrastructure.Logging;
using AuoAoi.Infrastructure.Mes;
using AuoAoi.Infrastructure.Plc;
using AuoAoi.UI.ViewModels;
using System.Windows;

namespace AuoAoi.UI
{
    /// <summary>
    /// App.xaml.cs — Composition Root（組裝根）
    ///
    /// ════════════════════════════════════════════════════════════
    /// 這是整個系統唯一知道「所有具體實作」的地方。
    ///
    /// 規則：
    ///   - UI 層（ViewModel）只依賴 Core 層介面（ICamera 等）
    ///   - Infrastructure 具體類別只在這裡被 new 出來
    ///   - 如需換掉相機品牌：只改這個檔案，其餘零修改
    /// ════════════════════════════════════════════════════════════
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // ── Step 1: 建立 Infrastructure 層物件 ──────────────────
            var logService = new FileLogService();
            var camera     = new VirtualCamera();
            var algorithm  = new MockAlgorithm();
            var lighting   = new MockLighting(logService);
            var plc        = new MockCommunication(logService);
            var mes        = new MockMesService(logService);
            var repository = new InMemoryRepository();

            // ── Step 2: 建立 Core 層物件（注入 Infrastructure）───────
            var recipeManager = new RecipeManager();
            var engine        = new MainEngine(
                camera, algorithm, lighting, plc,
                logService, mes, recipeManager);

            // ── Step 3: 建立各頁面 ViewModel ─────────────────────────
            var homeVm    = new HomeViewModel();
            var manualVm  = new ManualViewModel();
            var recipeVm  = new RecipeViewModel(recipeManager);
            var historyVm = new HistoryViewModel();
            var logVm     = new LogViewModel();
            var msaVm     = new MsaViewModel();

            // ── Step 4: Log 事件 → LogViewModel（即時更新 UI）────────
            logService.LogAdded += (level, msg) =>
                Dispatcher.Invoke(() => logVm.AddLog(level, msg));

            // ── Step 5: Session 狀態 → HomeViewModel ─────────────────
            engine.InspectionCompleted += record =>
                Dispatcher.Invoke(() => homeVm.UpdateSessionState(
                    AuoAoi.Core.StateMachine.SessionState.Completed));

            // ── Step 6: 建立主 ViewModel（注入 Engine + 子 ViewModels）
            var mainVm = new MainViewModel(
                engine, homeVm, manualVm, recipeVm, historyVm, logVm, msaVm);

            // ── Step 7: 建立主視窗並設定 DataContext ─────────────────
            var mainWindow = new MainWindow { DataContext = mainVm };
            mainWindow.Show();
        }
    }
}
