using OpenCvSharp;
using System;

namespace AuoAoi.Core.Interfaces
{
    /// <summary>
    /// 演算法抽象介面。
    /// 所有演算法（幾何比對、AI 推論等）都必須實作此介面，
    /// 確保平台端呼叫方式統一，演算法可無縫替換。
    /// </summary>
    public interface IAlgorithm : IDisposable
    {
        /// <summary>演算法名稱，用於 Log 識別</summary>
        string Name { get; }

        /// <summary>
        /// 執行演算法主流程。
        /// ──────────────────────────────────────────────
        /// 參數排序慣例：
        ///   1. 輸入參數（影像、設定）
        ///   2. 輸出參數（out）依「結果 → 視覺 → 診斷」排列
        /// ──────────────────────────────────────────────
        /// </summary>
        /// <param name="image">輸入影像</param>
        /// <param name="score">信心分數 0.0（最差）~ 1.0（最佳）</param>
        /// <param name="defectType">缺陷類型；判定 OK 時為空字串</param>
        /// <returns>
        /// true  = 演算法流程完整走完，輸出參數有效。<br/>
        /// false = 流程中途異常（影像為空、參數錯誤等），輸出參數無效。
        /// </returns>
        bool Execute(Mat image, out double score, out string defectType);
    }
}
