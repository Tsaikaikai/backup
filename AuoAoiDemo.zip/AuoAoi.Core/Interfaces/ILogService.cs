using AuoAoi.Core.Models;

namespace AuoAoi.Core.Interfaces
{
    /// <summary>Log 等級定義</summary>
    public enum LogLevel { Debug, Info, Warning, Error }

    /// <summary>
    /// 日誌服務抽象介面。
    /// Infrastructure 層可實作為寫檔、寫 DB、或同時兩者。
    /// </summary>
    public interface ILogService
    {
        void Log(LogLevel level, string message);

        // 便利方法，讓呼叫端不用每次帶 level
        void Debug(string message);
        void Info(string message);
        void Warning(string message);
        void Error(string message);
    }

    /// <summary>
    /// MES 上報抽象介面。
    /// Demo 中由 MockMesService 實作（寫 Log 代替真實 HTTP 呼叫）。
    /// 實際產線時替換為 HttpMesService 即可，Core 層零修改。
    /// </summary>
    public interface IMesService
    {
        /// <summary>
        /// 上報單次檢測結果至 MES。
        /// </summary>
        /// <param name="record">檢測紀錄</param>
        /// <returns>true = 上報成功（或已寫入 Cache 等待重送）</returns>
        bool Report(InspectionRecord record);
    }
}
