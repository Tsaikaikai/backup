namespace AuoAoi.Core.Interfaces
{
    /// <summary>
    /// PLC / 外部設備通訊抽象介面（Modbus、I/O 訊號等）。
    /// </summary>
    public interface ICommunication
    {
        bool Connect();
        void Disconnect();

        /// <summary>等待 Trigger 訊號（阻塞直到收到或逾時）</summary>
        /// <param name="timeoutMs">逾時毫秒數</param>
        bool WaitForTrigger(int timeoutMs = 5000);

        /// <summary>送出 OK/NG 訊號給 PLC</summary>
        void SendResult(bool isOk);
    }
}
