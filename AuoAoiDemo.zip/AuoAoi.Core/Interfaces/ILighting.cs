namespace AuoAoi.Core.Interfaces
{
    /// <summary>
    /// 光源控制抽象介面。
    /// </summary>
    public interface ILighting
    {
        /// <summary>開啟光源，brightness 範圍 0~255</summary>
        void TurnOn(int brightness = 128);

        /// <summary>關閉光源</summary>
        void TurnOff();
    }
}
