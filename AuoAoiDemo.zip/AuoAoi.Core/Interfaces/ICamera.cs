using OpenCvSharp;

namespace AuoAoi.Core.Interfaces
{
    /// <summary>
    /// 相機抽象介面。
    /// Infrastructure 層的任何相機實作（VirtualCamera、HikCamImpl 等）都必須實作此介面。
    /// Core 層只依賴介面，永遠不知道底層是哪個品牌的相機。
    /// </summary>
    public interface ICamera
    {
        /// <summary>開啟相機連線</summary>
        bool Open();

        /// <summary>關閉相機連線</summary>
        void Close();

        /// <summary>
        /// 擷取一張影像。
        /// </summary>
        /// <param name="frame">輸出影像（Mat）</param>
        /// <returns>true = 取像成功；false = 取像失敗（逾時或斷線）</returns>
        bool GrabFrame(out Mat frame);
    }
}
