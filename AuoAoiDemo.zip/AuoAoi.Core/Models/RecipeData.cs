using System.ComponentModel;

namespace AuoAoi.Core.Models
{
    /// <summary>
    /// 產品配方資料模型。
    /// 使用 [Category] / [DisplayName] / [Description] 屬性，
    /// 平台端 PropertyGrid 可自動生成 UI，無需手動配置。
    /// </summary>
    public class RecipeData
    {
        // ── 1. Product ────────────────────────────────
        [Category("1.Product")]
        [DisplayName("Model Name")]
        [Description("產品機種名稱")]
        public string ModelName { get; set; } = "AUO-G123-V1";

        [Category("1.Product")]
        [DisplayName("NG Score Threshold")]
        [Description("低於此分數判定為 NG（0.0 ~ 1.0）")]
        public double NgThreshold { get; set; } = 0.6;

        // ── 2. Camera ─────────────────────────────────
        [Category("2.Camera")]
        [DisplayName("Exposure Time (ms)")]
        [Description("曝光時間（毫秒）")]
        public int ExposureMs { get; set; } = 10;

        [Category("2.Camera")]
        [DisplayName("Brightness")]
        [Description("影像亮度補償（0~255）")]
        public int Brightness { get; set; } = 128;

        // ── 3. System ─────────────────────────────────
        [Category("3.System")]
        [DisplayName("Image Save Path")]
        [Description("NG 圖像儲存路徑")]
        public string ImageSavePath { get; set; } = @"C:\AuoAoi\Images";

        [Category("3.System")]
        [DisplayName("MES Enable")]
        [Description("是否啟用 MES 上報")]
        public bool MesEnable { get; set; } = true;
    }
}
