using System;

namespace AuoAoi.Core.Models
{
    /// <summary>
    /// 單次完整檢測結果的資料模型。
    /// 封裝「一片產品從取像到判定完成」的所有資訊，
    /// 可直接存入資料庫或上報 MES。
    /// </summary>
    public class InspectionRecord
    {
        public Guid   Id          { get; set; } = Guid.NewGuid();
        public DateTime Timestamp { get; set; } = DateTime.Now;

        // ── 產品資訊 ──────────────────────────────────
        public string GlassId     { get; set; } = string.Empty;
        public string ModelName   { get; set; } = string.Empty;
        public string LotId       { get; set; } = string.Empty;
        public string RecipeName  { get; set; } = string.Empty;

        // ── 判定結果 ──────────────────────────────────
        public bool   IsOk        { get; set; }
        public string DefectType  { get; set; } = string.Empty;  // OK 時為空字串
        public double Score       { get; set; }                  // 0.0 ~ 1.0

        // ── 診斷資訊 ──────────────────────────────────
        public string ImagePath   { get; set; } = string.Empty;  // 存圖路徑
        public long   ElapsedMs   { get; set; }                  // 檢測耗時

        public override string ToString()
            => $"[{Timestamp:HH:mm:ss}] {GlassId} → {(IsOk ? "OK" : $"NG ({DefectType})")} score={Score:F3}";
    }
}
