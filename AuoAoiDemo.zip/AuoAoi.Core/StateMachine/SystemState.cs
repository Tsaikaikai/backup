namespace AuoAoi.Core.StateMachine
{
    /// <summary>
    /// 系統層級狀態（Main Engine FSM）。
    /// 描述整個平台從開機到關機的生命週期。
    /// </summary>
    public enum SystemState
    {
        /// <summary>程式啟動，自動檢測硬體連線</summary>
        Initializing,

        /// <summary>初始化完成，等待載入 Recipe</summary>
        Idle,

        /// <summary>Recipe 已載入，可以開始生產</summary>
        Ready,

        /// <summary>自動檢測運行中</summary>
        Running,

        /// <summary>工程維護模式（手動調試硬體）</summary>
        Maintenance,

        /// <summary>硬體歸零、清空 Buffer、狀態復位</summary>
        Resetting,

        /// <summary>任何層級拋出 Exception 時進入</summary>
        Error,

        /// <summary>正在釋放資源、儲存最後狀態</summary>
        ShuttingDown
    }

    /// <summary>
    /// 單次檢測流程狀態（Inspection Session FSM）。
    /// 描述「一片產品」從 Trigger 到結果送出的完整流程。
    /// </summary>
    public enum SessionState
    {
        /// <summary>等待 PLC 或軟體 Trigger 訊號</summary>
        Waiting,

        /// <summary>取像、影像前處理、演算法推論</summary>
        Processing,

        /// <summary>綜合各站結果，判定 OK/NG</summary>
        Judging,

        /// <summary>更新 UI、寫 DB、上報 MES、存圖（非同步）</summary>
        Reporting,

        /// <summary>送出 OK/NG 訊號給 PLC，等待產品離開</summary>
        Transferring,

        /// <summary>此次 Session 正常完成</summary>
        Completed,

        /// <summary>此次 Session 發生錯誤（逾時、相機斷線等）</summary>
        Faulted
    }
}
