using AuoAoi.Core.Interfaces;
using AuoAoi.Core.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AuoAoi.Core.StateMachine
{
    /// <summary>
    /// 系統主狀態機（Main Engine）。
    /// 平台的核心驅動器，負責：
    ///   1. 管理系統生命週期（INITIALIZING → IDLE → READY → RUNNING → ...）
    ///   2. 在 Running 狀態下持續 new InspectionSession 並執行
    ///   3. 任何例外均轉入 ERROR 狀態，保障系統可預測性
    ///
    /// 設計重點：
    ///   - 透過建構子注入（Constructor Injection）接收所有依賴
    ///   - 上層（UI/ViewModel）只能呼叫 Command 方法，無法直接操作硬體
    ///   - 狀態轉換透過 StateChanged 事件通知 UI，保持解耦
    /// </summary>
    public class MainEngine
    {
        #region Fields & Events

        private readonly ICamera        _camera;
        private readonly IAlgorithm     _algorithm;
        private readonly ILighting      _lighting;
        private readonly ICommunication _plc;
        private readonly ILogService    _log;
        private readonly IMesService    _mes;
        private readonly RecipeManager  _recipeManager;

        private CancellationTokenSource _cts;
        private Task                    _runningTask;

        /// <summary>系統狀態改變時觸發（供 ViewModel 更新 UI）</summary>
        public event Action<SystemState> StateChanged;

        /// <summary>Session 流程步驟改變時觸發（供 Home 頁面即時顯示進度）</summary>
        public event Action<SessionState> SessionStateChanged;

        /// <summary>單次檢測完成時觸發（供 ViewModel 更新 Home 頁面統計）</summary>
        public event Action<InspectionRecord> InspectionCompleted;

        /// <summary>目前系統狀態</summary>
        public SystemState State { get; private set; } = SystemState.Idle;

        /// <summary>目前載入的 Recipe</summary>
        public RecipeData CurrentRecipe => _recipeManager.Current;

        #endregion

        #region Constructor

        /// <summary>
        /// 所有依賴由外部注入（Composition Root 在 App.xaml.cs 組裝）。
        /// Core 層不知道任何具體實作，只依賴介面。
        /// </summary>
        public MainEngine(
            ICamera camera,
            IAlgorithm algorithm,
            ILighting lighting,
            ICommunication plc,
            ILogService log,
            IMesService mes,
            RecipeManager recipeManager)
        {
            _camera        = camera;
            _algorithm     = algorithm;
            _lighting      = lighting;
            _plc           = plc;
            _log           = log;
            _mes           = mes;
            _recipeManager = recipeManager;
        }

        #endregion

        #region MainFunction — Commands (UI 呼叫點)

        /// <summary>
        /// [Command] 初始化所有硬體。
        /// 對應 INITIALIZING 狀態，程式啟動時呼叫。
        /// </summary>
        public async Task InitializeAsync()
        {
            TransitionTo(SystemState.Initializing);
            _log.Info("=== System initializing... ===");

            await Task.Run(() =>
            {
                // Step 1: 開啟相機
                bool cameraOk = _camera.Open();
                if (!cameraOk) throw new Exception("Camera initialization failed.");
                _log.Info("  [OK] Camera connected.");

                // Step 2: PLC 連線
                bool plcOk = _plc.Connect();
                if (!plcOk) throw new Exception("PLC connection failed.");
                _log.Info("  [OK] PLC connected.");

                // Step 3: 載入預設 Recipe
                _recipeManager.LoadDefault();
                _log.Info($"  [OK] Default recipe loaded: {_recipeManager.Current.ModelName}");
            });

            TransitionTo(SystemState.Idle);
            _log.Info("=== Initialization complete. System IDLE. ===");
        }

        /// <summary>
        /// [Command] 載入 Recipe，成功後進入 READY。
        /// </summary>
        public void LoadRecipe(string recipeName)
        {
            if (State != SystemState.Idle)
            {
                _log.Warning($"LoadRecipe ignored: current state is {State}.");
                return;
            }

            _recipeManager.Load(recipeName);
            _log.Info($"Recipe loaded: {recipeName}");
            TransitionTo(SystemState.Ready);
        }

        /// <summary>
        /// [Command] 開始自動生產。
        /// 在背景執行緒持續執行 InspectionSession，直到收到 Stop 指令。
        /// </summary>
        public void Start()
        {
            if (State != SystemState.Ready)
            {
                _log.Warning($"Start ignored: current state is {State} (must be Ready).");
                return;
            }

            _cts         = new CancellationTokenSource();
            _runningTask = Task.Run(() => RunLoop(_cts.Token));

            TransitionTo(SystemState.Running);
            _log.Info("=== Production STARTED. ===");
        }

        /// <summary>
        /// [Command] 停止自動生產，回到 READY。
        /// </summary>
        public async Task StopAsync()
        {
            if (State != SystemState.Running) return;

            _log.Info("Stop requested, waiting for current session to finish...");
            _cts?.Cancel();

            if (_runningTask != null)
                await _runningTask;   // 等待當前 Session 乾淨結束

            TransitionTo(SystemState.Ready);
            _log.Info("=== Production STOPPED. System READY. ===");
        }

        /// <summary>
        /// [Command] 進入 Maintenance 模式（手動調試）。
        /// </summary>
        public void EnterMaintenance()
        {
            if (State != SystemState.Idle)
            {
                _log.Warning("EnterMaintenance: only allowed from IDLE.");
                return;
            }
            TransitionTo(SystemState.Maintenance);
            _log.Info("Entered MAINTENANCE mode.");
        }

        /// <summary>
        /// [Command] 離開 Maintenance，觸發 RESETTING 後回到 IDLE。
        /// </summary>
        public async Task ExitMaintenanceAsync()
        {
            TransitionTo(SystemState.Resetting);
            _log.Info("Resetting hardware...");

            await Task.Delay(500);   // Mock：實際為 Homing / Buffer 清空

            TransitionTo(SystemState.Idle);
            _log.Info("Reset complete. System IDLE.");
        }

        /// <summary>
        /// [Command] 確認錯誤，觸發 RESETTING 流程。
        /// </summary>
        public async Task AcknowledgeErrorAsync()
        {
            if (State != SystemState.Error) return;

            TransitionTo(SystemState.Resetting);
            _log.Info("Error acknowledged. Resetting...");

            await Task.Delay(500);

            TransitionTo(SystemState.Idle);
            _log.Info("Reset complete. System IDLE.");
        }

        /// <summary>
        /// [Command] 關機流程。
        /// </summary>
        public async Task ShutdownAsync()
        {
            _log.Info("=== Shutdown sequence started. ===");
            TransitionTo(SystemState.ShuttingDown);

            if (State == SystemState.Running)
                await StopAsync();

            await Task.Run(() =>
            {
                _camera.Close();
                _plc.Disconnect();
                _algorithm.Dispose();
                _log.Info("All resources released.");
            });
        }

        #endregion

        #region PrivateTools

        /// <summary>
        /// 自動生產主迴圈。
        /// 持續執行 InspectionSession，直到 CancellationToken 被取消。
        /// </summary>
        private void RunLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    // ── 每次生產循環 new 一個全新的 Session ──────────
                    var session = new InspectionSession(
                        _camera, _algorithm, _lighting,
                        _plc, _log, _mes,
                        _recipeManager.Current);

                    // Session 完成後轉發給 UI 層
                    session.Completed     += record => InspectionCompleted?.Invoke(record);

                    // Session 每個步驟轉發給 UI 層（Home 頁面進度圓點）
                    session.StateChanged  += state  => SessionStateChanged?.Invoke(state);

                    session.Run(token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _log.Error($"Unhandled exception in RunLoop: {ex.Message}");
                    TransitionTo(SystemState.Error);
                    break;   // 跳出迴圈，等待 AcknowledgeError
                }
            }
        }

        private void TransitionTo(SystemState next)
        {
            _log.Debug($"System: {State} → {next}");
            State = next;
            StateChanged?.Invoke(next);
        }

        #endregion
    }
}
