using AuoAoi.Core.Interfaces;
using AuoAoi.Core.Models;
using System;
using System.Diagnostics;
using System.Threading;

namespace AuoAoi.Core.StateMachine
{
    /// <summary>
    /// 單次檢測流程的狀態機。
    /// 封裝「一片產品從 Trigger 到結果送出」的所有步驟與資料。
    ///
    /// 設計重點：
    ///   - 此類別只負責「單次」流程，不持有硬體長期狀態。
    ///   - 由 MainEngine 在每次進入 Running 後 new 一個新的 Session。
    ///   - 流程結束後透過 Completed 事件通知 Engine。
    /// </summary>
    public class InspectionSession
    {
        #region Fields & Events

        private readonly ICamera        _camera;
        private readonly IAlgorithm     _algorithm;
        private readonly ILighting      _lighting;
        private readonly ICommunication _plc;
        private readonly ILogService    _log;
        private readonly IMesService    _mes;
        private readonly RecipeData     _recipe;

        /// <summary>此次 Session 的所有資料（持續更新直到 Completed）</summary>
        public InspectionRecord Record { get; } = new InspectionRecord();

        /// <summary>目前 Session 狀態</summary>
        public SessionState State { get; private set; } = SessionState.Waiting;

        /// <summary>Session 完成時觸發（成功或失敗皆會觸發）</summary>
        public event Action<InspectionRecord> Completed;

        /// <summary>Session 狀態改變時觸發（供 UI 顯示流程進度）</summary>
        public event Action<SessionState> StateChanged;

        #endregion

        #region Constructor

        public InspectionSession(
            ICamera camera, IAlgorithm algorithm,
            ILighting lighting, ICommunication plc,
            ILogService log, IMesService mes,
            RecipeData recipe)
        {
            _camera    = camera;
            _algorithm = algorithm;
            _lighting  = lighting;
            _plc       = plc;
            _log       = log;
            _mes       = mes;
            _recipe    = recipe;

            Record.RecipeName = recipe.ModelName;
            Record.ModelName  = recipe.ModelName;
        }

        #endregion

        #region MainFunction

        /// <summary>
        /// 執行完整的單次檢測流程。
        /// 由 MainEngine 在背景執行緒呼叫，不阻塞 UI 執行緒。
        /// </summary>
        public void Run(CancellationToken cancellationToken)
        {
            var sw = Stopwatch.StartNew();

            try
            {
                // ── Step 1: WAITING — 等待 Trigger ──────────────────
                TransitionTo(SessionState.Waiting);
                _log.Info("Session started, waiting for trigger...");

                bool triggered = _plc.WaitForTrigger(timeoutMs: 5000);
                if (!triggered)
                    throw new TimeoutException("PLC trigger timeout.");

                cancellationToken.ThrowIfCancellationRequested();

                // ── Step 2: PROCESSING — 取像 + 推論 ────────────────
                TransitionTo(SessionState.Processing);

                _lighting.TurnOn(_recipe.Brightness);

                bool grabbed = _camera.GrabFrame(out var frame);
                if (!grabbed || frame == null || frame.Empty())
                    throw new Exception("Camera grab failed or returned empty frame.");

                using (frame)
                {
                    bool algoOk = _algorithm.Execute(
                        frame,
                        out double score,
                        out string defectType);

                    if (!algoOk)
                        throw new Exception("Algorithm Execute() returned false.");

                    // ── Step 3: JUDGING — 比對 Recipe 門檻 ──────────
                    TransitionTo(SessionState.Judging);

                    Record.Score      = score;
                    Record.DefectType = defectType;
                    Record.IsOk       = score >= _recipe.NgThreshold;

                    _log.Info($"Judging: score={score:F3}, threshold={_recipe.NgThreshold:F3} → {(Record.IsOk ? "OK" : "NG")}");
                }

                _lighting.TurnOff();

                cancellationToken.ThrowIfCancellationRequested();

                // ── Step 4: REPORTING — 更新 UI / DB / MES ──────────
                TransitionTo(SessionState.Reporting);

                Record.ElapsedMs = sw.ElapsedMilliseconds;

                if (_recipe.MesEnable)
                {
                    bool reported = _mes.Report(Record);
                    if (!reported)
                        _log.Warning("MES report failed, cached locally.");
                }

                // ── Step 5: TRANSFERRING — 送訊號給 PLC ─────────────
                TransitionTo(SessionState.Transferring);
                _plc.SendResult(Record.IsOk);
                _log.Info($"Result sent to PLC: {(Record.IsOk ? "OK" : "NG")}");

                // ── 完成 ─────────────────────────────────────────────
                TransitionTo(SessionState.Completed);
                _log.Info($"Session completed in {Record.ElapsedMs} ms.");
            }
            catch (OperationCanceledException)
            {
                _log.Warning("Session cancelled by user.");
                TransitionTo(SessionState.Faulted);
            }
            catch (Exception ex)
            {
                _log.Error($"Session faulted: {ex.Message}");
                Record.DefectType = "SESSION_ERROR";
                Record.IsOk       = false;
                TransitionTo(SessionState.Faulted);
            }
            finally
            {
                _lighting.TurnOff();
                sw.Stop();
                Completed?.Invoke(Record);
            }
        }

        #endregion

        #region PrivateTools

        private void TransitionTo(SessionState next)
        {
            _log.Debug($"  Session: {State} → {next}");
            State = next;
            StateChanged?.Invoke(next);
        }

        #endregion
    }
}
