using AuoAoi.Core.Models;
using System.Collections.Generic;

namespace AuoAoi.Core.StateMachine
{
    /// <summary>
    /// Recipe 管理服務。
    /// 負責 Recipe 的載入、切換與持久化（Demo 版使用 in-memory 儲存）。
    ///
    /// 設計重點：
    ///   Recipe 與邏輯分離 — 工廠端可獨立調參，不需改程式碼。
    ///   實際產線可替換為讀取 XML/JSON 檔案的實作。
    /// </summary>
    public class RecipeManager
    {
        #region Fields

        private readonly Dictionary<string, RecipeData> _recipes
            = new Dictionary<string, RecipeData>();

        /// <summary>目前作用中的 Recipe</summary>
        public RecipeData Current { get; private set; }

        #endregion

        #region MainFunction

        /// <summary>載入預設 Recipe（程式啟動時呼叫）</summary>
        public void LoadDefault()
        {
            // Demo：直接建立幾筆假 Recipe
            _recipes["AUO-G123-V1"] = new RecipeData
            {
                ModelName    = "AUO-G123-V1",
                NgThreshold  = 0.6,
                ExposureMs   = 10,
                Brightness   = 128,
                MesEnable    = true
            };
            _recipes["AUO-G456-V2"] = new RecipeData
            {
                ModelName    = "AUO-G456-V2",
                NgThreshold  = 0.7,
                ExposureMs   = 15,
                Brightness   = 150,
                MesEnable    = false
            };

            Current = _recipes["AUO-G123-V1"];
        }

        /// <summary>依名稱切換 Recipe</summary>
        public bool Load(string recipeName)
        {
            if (_recipes.TryGetValue(recipeName, out var recipe))
            {
                Current = recipe;
                return true;
            }
            return false;
        }

        /// <summary>取得所有可用 Recipe 名稱（供 Recipe 頁面下拉選單使用）</summary>
        public IEnumerable<string> GetAllNames() => _recipes.Keys;

        #endregion
    }
}
