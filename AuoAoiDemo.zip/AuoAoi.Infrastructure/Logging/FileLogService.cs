using AuoAoi.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;

namespace AuoAoi.Infrastructure.Logging
{
    /// <summary>
    /// 檔案日誌服務（implements ILogService）。
    /// 同時寫檔案與觸發 UI 事件，讓 Log 頁面即時更新。
    /// </summary>
    public class FileLogService : ILogService
    {
        private readonly string _logPath;
        private readonly object _lock = new object();

        /// <summary>有新 Log 時觸發（供 LogViewModel 訂閱，即時更新 UI）</summary>
        public event Action<LogLevel, string> LogAdded;

        public FileLogService(string logPath = null)
        {
            _logPath = logPath ?? Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, "Logs",
                $"AuoAoi_{DateTime.Now:yyyyMMdd}.log");

            Directory.CreateDirectory(Path.GetDirectoryName(_logPath));
        }

        public void Log(LogLevel level, string message)
        {
            string line = $"[{DateTime.Now:HH:mm:ss.fff}] [{level,-7}] {message}";

            lock (_lock)
            {
                try { File.AppendAllText(_logPath, line + Environment.NewLine); }
                catch { /* 寫檔失敗不中斷主流程 */ }
            }

            LogAdded?.Invoke(level, line);
        }

        public void Debug(string msg)   => Log(LogLevel.Debug,   msg);
        public void Info(string msg)    => Log(LogLevel.Info,    msg);
        public void Warning(string msg) => Log(LogLevel.Warning, msg);
        public void Error(string msg)   => Log(LogLevel.Error,   msg);
    }
}
