using AuoAoi.Core.Interfaces;
using AuoAoi.Core.Models;
using System.Threading;

namespace AuoAoi.Infrastructure.Mes
{
    /// <summary>
    /// MES 上報 Mock 實作。
    /// Demo 中以寫 Log 代替真實 HTTP 呼叫，示意「上報接點」在哪裡。
    /// 實際產線：替換為 HttpMesService，Core 層零修改。
    /// </summary>
    public class MockMesService : IMesService
    {
        private readonly ILogService _log;
        public MockMesService(ILogService log) { _log = log; }

        public bool Report(InspectionRecord record)
        {
            // ── 示意：這裡替換為真實的 HTTP POST ──────────────────────
            _log.Info($"[MES Mock] Reporting → GlassId={record.GlassId}, " +
                      $"Result={( record.IsOk ? "OK" : "NG")}, Score={record.Score:F3}");
            return true;
        }
    }
}
