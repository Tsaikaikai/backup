using AuoAoi.Core.Interfaces;

namespace AuoAoi.Infrastructure.Lighting
{
    /// <summary>光源控制 Mock 實作</summary>
    public class MockLighting : ILighting
    {
        private readonly ILogService _log;
        public MockLighting(ILogService log) { _log = log; }

        public void TurnOn(int brightness = 128)
            => _log.Debug($"[Light Mock] ON  brightness={brightness}");

        public void TurnOff()
            => _log.Debug("[Light Mock] OFF");
    }
}
