using AuoAoi.Core.Interfaces;
using OpenCvSharp;
using System;

namespace AuoAoi.Infrastructure.Camera
{
    /// <summary>
    /// 虛擬相機（implements ICamera）。
    /// 用程式畫假影像，無需實體相機即可模擬完整流程。
    ///
    /// Demo 重點：
    ///   - 展示「如何實作 ICamera」的標準範本
    ///   - 實際換相機時，只需新增 HikCamImpl : ICamera，Core 層零修改
    /// </summary>
    public class VirtualCamera : ICamera
    {
        #region Fields

        private bool   _isOpen;
        private int    _frameCount;
        private Random _rng = new Random();

        #endregion

        #region MainFunction

        public bool Open()
        {
            // Mock：模擬硬體初始化耗時
            System.Threading.Thread.Sleep(200);
            _isOpen    = true;
            _frameCount = 0;
            return true;
        }

        public void Close()
        {
            _isOpen = false;
        }

        /// <summary>
        /// 產生一張假影像（640×480，灰階底圖 + 幾個隨機色塊）。
        /// 影像內容不重要，重點是讓演算法有 Mat 可以處理。
        /// </summary>
        public bool GrabFrame(out Mat frame)
        {
            frame = null;

            if (!_isOpen) return false;

            // Step 1: 建立灰階底圖
            frame = new Mat(480, 640, MatType.CV_8UC3, new Scalar(50, 50, 50));

            // Step 2: 畫幾個隨機色塊，模擬產品特徵
            for (int i = 0; i < 5; i++)
            {
                int x = _rng.Next(50, 500);
                int y = _rng.Next(50, 380);
                int w = _rng.Next(40, 120);
                int h = _rng.Next(40, 80);
                var color = new Scalar(
                    _rng.Next(80, 255),
                    _rng.Next(80, 255),
                    _rng.Next(80, 255));
                Cv2.Rectangle(frame, new Rect(x, y, w, h), color, -1);
            }

            // Step 3: 畫上 Frame Counter，方便 Demo 時識別
            Cv2.PutText(
                frame,
                $"VIRTUAL FRAME #{++_frameCount}",
                new Point(20, 460),
                HersheyFonts.HersheySimplex,
                0.6, Scalar.White, 1);

            return true;
        }

        #endregion
    }
}
