using AuoAoi.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AuoAoi.Infrastructure.Data
{
    /// <summary>
    /// 檢測紀錄 In-Memory 儲存庫（Demo 用，無需資料庫）。
    /// 實際產線替換為 SqliteRepository 或 SqlServerRepository。
    /// </summary>
    public class InMemoryRepository
    {
        private readonly List<InspectionRecord> _records = new List<InspectionRecord>();
        private readonly object _lock = new object();

        public void Add(InspectionRecord record)
        {
            lock (_lock) { _records.Add(record); }
        }

        public IReadOnlyList<InspectionRecord> GetAll()
        {
            lock (_lock) { return _records.ToList().AsReadOnly(); }
        }

        public IReadOnlyList<InspectionRecord> GetToday()
        {
            var today = DateTime.Today;
            lock (_lock)
            {
                return _records
                    .Where(r => r.Timestamp.Date == today)
                    .ToList().AsReadOnly();
            }
        }
    }
}
