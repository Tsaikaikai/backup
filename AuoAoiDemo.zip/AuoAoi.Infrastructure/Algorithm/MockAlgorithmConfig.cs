using System.ComponentModel;
using System.IO;
using System.Xml.Serialization;

namespace AuoAoi.Infrastructure.Algorithm
{
    /// <summary>
    /// MockAlgorithm 的參數配置類別。
    ///
    /// 設計重點（配置分離規範）：
    ///   - 與演算法邏輯完全分離，獨立一個類別
    ///   - [Category] / [DisplayName] 讓 WinForms PropertyGrid 自動分組顯示
    ///   - 實作 LoadConfig / SaveConfig，支援 XML 序列化
    /// </summary>
    [XmlRoot("MockAlgorithmConfig")]
    public class MockAlgorithmConfig
    {
        // ── 1. Threshold ──────────────────────────────────────
        [Category("1.Threshold")]
        [DisplayName("NG Score Threshold")]
        [Description("低於此分數判定為 NG（0.0 ~ 1.0）")]
        public double NgThreshold { get; set; } = 0.6;

        // ── 2. Debug ──────────────────────────────────────────
        [Category("2.Debug")]
        [DisplayName("Processing Delay (ms)")]
        [Description("模擬演算法推論耗時（毫秒），Demo 用")]
        public int ProcessingDelayMs { get; set; } = 200;

        [Category("2.Debug")]
        [DisplayName("Save Result Image")]
        [Description("是否儲存帶有標注框的結果影像")]
        public bool SaveResultImage { get; set; } = false;

        // ── 標準序列化介面 ────────────────────────────────────
        public void SaveConfig(string path)
        {
            var xs = new XmlSerializer(typeof(MockAlgorithmConfig));
            using (var sw = new StreamWriter(path))
                xs.Serialize(sw, this);
        }

        public static MockAlgorithmConfig LoadConfig(string path)
        {
            var xs = new XmlSerializer(typeof(MockAlgorithmConfig));
            using (var sr = new StreamReader(path))
                return (MockAlgorithmConfig)xs.Deserialize(sr);
        }
    }
}
