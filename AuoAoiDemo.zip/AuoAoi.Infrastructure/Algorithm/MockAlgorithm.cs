using AuoAoi.Core.Interfaces;
using OpenCvSharp;
using System;

namespace AuoAoi.Infrastructure.Algorithm
{
    /// <summary>
    /// 演算法標準範本（Mock 實作）。
    ///
    /// ════════════════════════════════════════════════════════════
    /// 這個類別示範所有演算法都必須遵循的「五大規範」：
    ///   1. 命名空間 / 類別命名 / #region 三區塊
    ///   2. 標準 Execute 介面
    ///   3. 配置分離（Config 類別）
    ///   4. 資源與異常管理（IDisposable + try-catch-finally）
    ///   5. XML 註解 + // Step N: 邏輯標註
    /// ════════════════════════════════════════════════════════════
    ///
    /// 實際產線演算法開發時，複製此檔案並修改 Execute 內的邏輯即可。
    /// </summary>
    public class MockAlgorithm : IAlgorithm
    {
        #region ConfigData

        /// <summary>演算法參數，符合平台 PropertyGrid 自動生成 UI 的規範</summary>
        public MockAlgorithmConfig Config { get; } = new MockAlgorithmConfig();

        #endregion

        #region Fields

        public string Name => "MockAlgorithm v1.0";

        private readonly Random _rng = new Random();
        private bool _disposed;

        #endregion

        #region MainFunction

        /// <summary>
        /// 執行演算法主流程（Mock：隨機產生結果）。
        /// </summary>
        /// <param name="image">輸入影像</param>
        /// <param name="score">信心分數 0.0~1.0</param>
        /// <param name="defectType">缺陷類型，OK 時為空字串</param>
        /// <returns>true = 流程完整走完；false = 途中異常</returns>
        public bool Execute(Mat image, out double score, out string defectType)
        {
            // ── 規範4：out 參數必須在第一行初始化 ──────────────────
            score      = 0.0;
            defectType = string.Empty;

            try
            {
                // Step 1: 驗證輸入
                if (image == null || image.Empty())
                    throw new ArgumentException("Input image is null or empty.");

                // Step 2: 前處理（Mock：模擬耗時）
                System.Threading.Thread.Sleep(Config.ProcessingDelayMs);

                // Step 3: 演算法推論（Mock：隨機產生 score）
                score = _rng.NextDouble();

                // Step 4: 判定缺陷類型（依 score 決定）
                if (score < Config.NgThreshold)
                {
                    defectType = PickRandomDefect();
                }

                return true;
            }
            catch (Exception ex)
            {
                // ── 規範4：捕捉後包裝拋出，讓平台層統一處理 ─────────
                throw new Exception($"[{Name}] Execute failed: {ex.Message}", ex);
            }
            finally
            {
                // ── 規範4：非託管資源必須在 finally 釋放 ─────────────
                // （此 Mock 沒有額外 Mat，若有請在此 Dispose）
            }
        }

        #endregion

        #region PrivateTools

        private string PickRandomDefect()
        {
            string[] defects = { "Scratch", "Particle", "Crack", "Stain", "Bubble" };
            return defects[_rng.Next(defects.Length)];
        }

        #endregion

        #region IDisposable

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;
            if (disposing)
            {
                // 釋放所有 Managed / Unmanaged 資源
                // 例如：_modelMat?.Dispose();
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
