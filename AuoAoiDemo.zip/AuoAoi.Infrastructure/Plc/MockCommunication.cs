using AuoAoi.Core.Interfaces;
using System.Threading;

namespace AuoAoi.Infrastructure.Plc
{
    /// <summary>
    /// PLC 通訊 Mock 實作（implements ICommunication）。
    /// WaitForTrigger 使用 Thread.Sleep 模擬等待，
    /// 讓工程師在辦公室也能跑完整流程。
    /// </summary>
    public class MockCommunication : ICommunication
    {
        private readonly ILogService _log;
        public MockCommunication(ILogService log) { _log = log; }

        public bool Connect()
        {
            _log.Info("[PLC Mock] Connected.");
            return true;
        }

        public void Disconnect()
        {
            _log.Info("[PLC Mock] Disconnected.");
        }

        /// <summary>模擬等待 Trigger：Sleep 1 秒代替真實 I/O 等待</summary>
        public bool WaitForTrigger(int timeoutMs = 5000)
        {
            _log.Debug("[PLC Mock] Waiting for trigger...");
            Thread.Sleep(1000);   // 模擬產品送料間隔
            _log.Debug("[PLC Mock] Trigger received.");
            return true;
        }

        /// <summary>模擬送出 OK/NG 訊號</summary>
        public void SendResult(bool isOk)
        {
            _log.Info($"[PLC Mock] Signal sent → {(isOk ? "OK" : "NG")}");
        }
    }
}
