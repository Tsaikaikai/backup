import cv2
import os
import numpy as np


# Implement selectROI
class HsvTool:


    def __init__(self, image, hsv_lower=[0,0,0], hsv_upper=[255,255,255]):

        self.drawing = False
        
        self.image = image
        self.img_hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
        self.hsv_lower = [int(hsv_lower[0]),int(hsv_lower[1]),int(hsv_lower[2])]
        self.hsv_upper = [int(hsv_upper[0]),int(hsv_upper[1]),int(hsv_upper[2])]
        
        
        
    def getHSVvalue(self):
    
        def nothing(x):
            pass

        winname1 = "HSV Tool"
        cv2.namedWindow(winname1, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(winname1, 360, 640)
        
        
        winName = 'HSV config'
        cv2.namedWindow(winName)

        cv2.createTrackbar('LowerH',winName,self.hsv_lower[0],255,nothing)

        cv2.createTrackbar('UpperH',winName,self.hsv_upper[0],255,nothing)

        cv2.createTrackbar('LowerS',winName,self.hsv_lower[1],255,nothing)

        cv2.createTrackbar('UpperS',winName,self.hsv_upper[1],255,nothing)

        cv2.createTrackbar('LowerV',winName,self.hsv_lower[2],255,nothing)

        cv2.createTrackbar('UpperV',winName,self.hsv_upper[2],255,nothing)
        
        
        while(1):


            LowerH = cv2.getTrackbarPos('LowerH',winName)

            UpperH = cv2.getTrackbarPos('UpperH',winName)
            
            LowerS = cv2.getTrackbarPos('LowerS',winName)

            UpperS = cv2.getTrackbarPos('UpperS',winName)
            
            LowerV = cv2.getTrackbarPos('LowerV',winName)

            UpperV = cv2.getTrackbarPos('UpperV',winName)
            
            
            lower = np.array([LowerH, LowerS, LowerV])
            upper = np.array([UpperH, UpperS, UpperV])

            
            mask = cv2.inRange(self.img_hsv, lower, upper)
            result_hsv = cv2.bitwise_and(self.img_hsv, self.img_hsv, mask=mask)
            #result_hsv = cv2.bitwise_and(result_hsv, result_hsv, mask=img_sheet)
            
            cv2.imshow(winname1, result_hsv)
            key = cv2.waitKey(1)
            if key != -1 :
                cv2.destroyAllWindows()
                break

            
        return lower.tolist(), upper.tolist()
    