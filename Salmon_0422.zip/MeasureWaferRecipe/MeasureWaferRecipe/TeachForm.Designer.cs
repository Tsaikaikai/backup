﻿
namespace MeasureWaferRecipe
{
    partial class TeachForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeachForm));
            this.tbp_Edge = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txb_EdgeImgFolder = new System.Windows.Forms.TextBox();
            this.txb_EdgeImgPath = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.btn_LoadImage_Edge = new System.Windows.Forms.Button();
            this.btn_SaveRecipe_Edge = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.btn_MasureTest_Edge = new System.Windows.Forms.Button();
            this.label168 = new System.Windows.Forms.Label();
            this.btn_MasureTest_Edge_Autoselect = new System.Windows.Forms.Button();
            this.label170 = new System.Windows.Forms.Label();
            this.btn_LoadFolder_Edge = new System.Windows.Forms.Button();
            this.tbc_EdgeType = new System.Windows.Forms.TabControl();
            this.tbp_TypeB = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.nud_GrayMax = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nud_bu2Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_bv2Ratio = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nud_bu1Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_bv1Ratio = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nud_AngleStart1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_AngleTop1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nud_AngleStart2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nud_AngleTop2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label94 = new System.Windows.Forms.Label();
            this.nud_EdgeRotateAngle = new System.Windows.Forms.NumericUpDown();
            this.nud_exAngle = new System.Windows.Forms.NumericUpDown();
            this.label148 = new System.Windows.Forms.Label();
            this.nud_hvScaleW = new System.Windows.Forms.NumericUpDown();
            this.nud_hvScaleH = new System.Windows.Forms.NumericUpDown();
            this.nud_CMeasureNumber = new System.Windows.Forms.NumericUpDown();
            this.label138 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.nud_EdgeLamp = new System.Windows.Forms.NumericUpDown();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.tbl_MeasureResult = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.nud_A1Upper = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.txb_A1 = new System.Windows.Forms.TextBox();
            this.txb_A2 = new System.Windows.Forms.TextBox();
            this.txb_B1 = new System.Windows.Forms.TextBox();
            this.txb_B2 = new System.Windows.Forms.TextBox();
            this.txb_R1 = new System.Windows.Forms.TextBox();
            this.txb_R2 = new System.Windows.Forms.TextBox();
            this.txb_t = new System.Windows.Forms.TextBox();
            this.txb_Ang1 = new System.Windows.Forms.TextBox();
            this.txb_Ang2 = new System.Windows.Forms.TextBox();
            this.txb_BC = new System.Windows.Forms.TextBox();
            this.txb_C2 = new System.Windows.Forms.TextBox();
            this.txb_C1 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.nud_A1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_A2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_A2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_B1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_B2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_B2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_B1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_R1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_R2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_tUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_tLower = new System.Windows.Forms.NumericUpDown();
            this.nud_R2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_R1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_BCUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_BCLower = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_C1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_C2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_C1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_C2Lower = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.hctrl_EdgeView = new AOISystem.Halcon.Controls.HControl();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbp_Demo = new System.Windows.Forms.TabPage();
            this.btn_CheckGrinding = new System.Windows.Forms.Button();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.nud_DiameterB = new System.Windows.Forms.NumericUpDown();
            this.label204 = new System.Windows.Forms.Label();
            this.nud_edgeIndex = new System.Windows.Forms.NumericUpDown();
            this.label203 = new System.Windows.Forms.Label();
            this.btn_DefectInspectionBottomAlign = new System.Windows.Forms.Button();
            this.btn_DefectInspectionTOPAlign = new System.Windows.Forms.Button();
            this.btn_DiameterMeasurementRun = new System.Windows.Forms.Button();
            this.label175 = new System.Windows.Forms.Label();
            this.btn_NotchInspectRun = new System.Windows.Forms.Button();
            this.btn_NotchInspectLoadImage = new System.Windows.Forms.Button();
            this.btn_NotchMeasurementRun = new System.Windows.Forms.Button();
            this.btn_NotchMeasurementLoadImage = new System.Windows.Forms.Button();
            this.btn_EdgeMeasurementRun = new System.Windows.Forms.Button();
            this.btn_EdgeMeasurementLoadImage = new System.Windows.Forms.Button();
            this.btn_DefectInspectionBottomRun = new System.Windows.Forms.Button();
            this.btn_DefectInspectionBottomLoadImage = new System.Windows.Forms.Button();
            this.btn_DefectInspectionTOPRun = new System.Windows.Forms.Button();
            this.btn_DefectInspectionTOPLoadImage = new System.Windows.Forms.Button();
            this.label202 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.nud_DiameterT = new System.Windows.Forms.NumericUpDown();
            this.label191 = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.nud_Vr1 = new System.Windows.Forms.NumericUpDown();
            this.nud_P2 = new System.Windows.Forms.NumericUpDown();
            this.nud_P1 = new System.Windows.Forms.NumericUpDown();
            this.nud_AngV = new System.Windows.Forms.NumericUpDown();
            this.nud_Vr = new System.Windows.Forms.NumericUpDown();
            this.nud_Vw = new System.Windows.Forms.NumericUpDown();
            this.nud_Vh = new System.Windows.Forms.NumericUpDown();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.nud_Vr2 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.nud_C2 = new System.Windows.Forms.NumericUpDown();
            this.nud_C1 = new System.Windows.Forms.NumericUpDown();
            this.nud_BC = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang2 = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang1 = new System.Windows.Forms.NumericUpDown();
            this.nud_t = new System.Windows.Forms.NumericUpDown();
            this.nud_R2 = new System.Windows.Forms.NumericUpDown();
            this.nud_R1 = new System.Windows.Forms.NumericUpDown();
            this.nud_B2 = new System.Windows.Forms.NumericUpDown();
            this.nud_B1 = new System.Windows.Forms.NumericUpDown();
            this.nud_A2 = new System.Windows.Forms.NumericUpDown();
            this.nud_A1 = new System.Windows.Forms.NumericUpDown();
            this.label181 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.hControl_EdgeMeasurement = new AOISystem.Halcon.Controls.HControl();
            this.nud_edgeAngle = new System.Windows.Forms.NumericUpDown();
            this.btn_edgeNumberNext = new System.Windows.Forms.Button();
            this.btn_edgeNumberBack = new System.Windows.Forms.Button();
            this.label177 = new System.Windows.Forms.Label();
            this.hControl_NotchInspect = new AOISystem.Halcon.Controls.HControl();
            this.label176 = new System.Windows.Forms.Label();
            this.hControl_NotchMeasurement = new AOISystem.Halcon.Controls.HControl();
            this.label171 = new System.Windows.Forms.Label();
            this.hControl_linescanBottom = new AOISystem.Halcon.Controls.HControl();
            this.hControl_linescanTop = new AOISystem.Halcon.Controls.HControl();
            this.label192 = new System.Windows.Forms.Label();
            this.tbp_Notch = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label113 = new System.Windows.Forms.Label();
            this.nud_NotchLamp = new System.Windows.Forms.NumericUpDown();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.txb_NotchImgPath = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label50 = new System.Windows.Forms.Label();
            this.nud_NotchGrayMax = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.nud_b2Ang = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.nud_u1Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_u2Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_VrWidth1 = new System.Windows.Forms.NumericUpDown();
            this.nud_PinRadius = new System.Windows.Forms.NumericUpDown();
            this.nud_VR12Angle = new System.Windows.Forms.NumericUpDown();
            this.nud_b1Ang = new System.Windows.Forms.NumericUpDown();
            this.nud_VrWidth2 = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label112 = new System.Windows.Forms.Label();
            this.nud_NotchRotate = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_SaveRecipe_Notch = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.btn_MasureTest_Notch = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.btn_LoadImage_Notch = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.btn_LoadRecipe_Notch = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label60 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.nud_VhUpper = new System.Windows.Forms.NumericUpDown();
            this.txb_Vh = new System.Windows.Forms.TextBox();
            this.txb_Vw = new System.Windows.Forms.TextBox();
            this.txb_Vr = new System.Windows.Forms.TextBox();
            this.txb_AngV = new System.Windows.Forms.TextBox();
            this.txb_P1 = new System.Windows.Forms.TextBox();
            this.txb_P2 = new System.Windows.Forms.TextBox();
            this.txb_VR1 = new System.Windows.Forms.TextBox();
            this.txb_VR2 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.nud_VhLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR1Upper = new System.Windows.Forms.NumericUpDown();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.nud_VwUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_VwLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VrUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_VrLower = new System.Windows.Forms.NumericUpDown();
            this.nud_AngVUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_P1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_P1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_P2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_P2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_AngVLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_VR2Lower = new System.Windows.Forms.NumericUpDown();
            this.hctrl_NotchView = new AOISystem.Halcon.Controls.HControl();
            this.tbp_Defect_1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.nud_shiftAngle = new System.Windows.Forms.NumericUpDown();
            this.label169 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.nud_notchPosition = new System.Windows.Forms.NumericUpDown();
            this.nud_totalAreaNum = new System.Windows.Forms.NumericUpDown();
            this.label162 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.nud_catchAreaNum = new System.Windows.Forms.NumericUpDown();
            this.textBox_catchImage = new System.Windows.Forms.TextBox();
            this.label145 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.nud_DefectLamp_1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.lab_dispNumber_1 = new System.Windows.Forms.Label();
            this.hctrl_RawImage_1 = new AOISystem.Halcon.Controls.HControl();
            this.txb_model_1 = new System.Windows.Forms.TextBox();
            this.txb_ImageRaw_1 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label59 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.nud_PixelSize_1 = new System.Windows.Forms.NumericUpDown();
            this.label72 = new System.Windows.Forms.Label();
            this.nud_InDistance_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_CropSize_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_CropNotchWidth_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_MinScore_1 = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.btn_loadModel_1 = new System.Windows.Forms.Button();
            this.btn_LoadImage_Defect_1 = new System.Windows.Forms.Button();
            this.label91 = new System.Windows.Forms.Label();
            this.btn_CropInspectionImg_1 = new System.Windows.Forms.Button();
            this.btn_TestCropNotch_1 = new System.Windows.Forms.Button();
            this.nud_SelectCropImg_1 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.hctrl_DefectImg_1 = new AOISystem.Halcon.Controls.HControl();
            this.label95 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.nud_BackWhiteMinGray_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_DisplayDilation_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_innerDefectMaxGray_Notch_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchVwRow1_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchVwRow2_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchBlackWidth_1 = new System.Windows.Forms.NumericUpDown();
            this.label85 = new System.Windows.Forms.Label();
            this.nud_InnerDefectMinWidth_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_OutDefectMinWidth_1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.btn_TestNotchDefect_1 = new System.Windows.Forms.Button();
            this.hctrl_NotchImg_1 = new AOISystem.Halcon.Controls.HControl();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label172 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.nud_RoiWidthToBevelCenter_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_BevelWidth_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_AiDefectSize_1 = new System.Windows.Forms.NumericUpDown();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.nud_AiMinGray_1 = new System.Windows.Forms.NumericUpDown();
            this.nud_InnerDefectAreaSize_1 = new System.Windows.Forms.NumericUpDown();
            this.label75 = new System.Windows.Forms.Label();
            this.nud_innerDefectMaxGray_1 = new System.Windows.Forms.NumericUpDown();
            this.label107 = new System.Windows.Forms.Label();
            this.nud_InnerThresholdMax_1 = new System.Windows.Forms.NumericUpDown();
            this.ckb_DefectV1 = new System.Windows.Forms.CheckBox();
            this.nud_EdgeDefectAreaSize_1 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.lab_hv_ROIColumn = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.nud_ROIColumn = new System.Windows.Forms.NumericUpDown();
            this.nud_DarkLightThreshold = new System.Windows.Forms.NumericUpDown();
            this.label157 = new System.Windows.Forms.Label();
            this.lab_light_DarkThres = new System.Windows.Forms.Label();
            this.lab_DarkMax = new System.Windows.Forms.Label();
            this.lab_Dark_DarkThres = new System.Windows.Forms.Label();
            this.lab_Dark_LightThres = new System.Windows.Forms.Label();
            this.lab_WhiteThres = new System.Windows.Forms.Label();
            this.nud_light_DarkThres = new System.Windows.Forms.NumericUpDown();
            this.nud_DarkMax = new System.Windows.Forms.NumericUpDown();
            this.nud_Dark_DarkThres = new System.Windows.Forms.NumericUpDown();
            this.nud_Dark_LightThres = new System.Windows.Forms.NumericUpDown();
            this.nud_WhiteThres = new System.Windows.Forms.NumericUpDown();
            this.label149 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.nud_MinAreaSize = new System.Windows.Forms.NumericUpDown();
            this.nud_MinDefectSize = new System.Windows.Forms.NumericUpDown();
            this.ckb_DefectV2 = new System.Windows.Forms.CheckBox();
            this.btn_TestDefect_1 = new System.Windows.Forms.Button();
            this.tbp_Defect_2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label115 = new System.Windows.Forms.Label();
            this.nud_DefectLamp_2 = new System.Windows.Forms.NumericUpDown();
            this.label116 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.lab_dispNumber_2 = new System.Windows.Forms.Label();
            this.hctrl_RawImage_2 = new AOISystem.Halcon.Controls.HControl();
            this.txb_model_2 = new System.Windows.Forms.TextBox();
            this.txb_ImageRaw_2 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.nud_PixelSize_2 = new System.Windows.Forms.NumericUpDown();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.nud_InDistance_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_CropSize_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_CropNotchWidth_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_MinScore_2 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.btn_loadModel_2 = new System.Windows.Forms.Button();
            this.btn_LoadImage_Defect_2 = new System.Windows.Forms.Button();
            this.label125 = new System.Windows.Forms.Label();
            this.btn_CropInspectionImg_2 = new System.Windows.Forms.Button();
            this.btn_TestCropNotch_2 = new System.Windows.Forms.Button();
            this.nud_SelectCropImg_2 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.label147 = new System.Windows.Forms.Label();
            this.hctrl_DefectImg_2 = new AOISystem.Halcon.Controls.HControl();
            this.label126 = new System.Windows.Forms.Label();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.nud_BackWhiteMinGray_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_DisplayDilation_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_innerDefectMaxGray_Notch_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchVwRow1_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchVwRow2_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_NotchBlackWidth_2 = new System.Windows.Forms.NumericUpDown();
            this.label135 = new System.Windows.Forms.Label();
            this.nud_InnerDefectMinWidth_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_OutDefectMinWidth_2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.btn_TestDefect_2 = new System.Windows.Forms.Button();
            this.btn_TestNotchDefect_2 = new System.Windows.Forms.Button();
            this.hctrl_NotchImg_2 = new AOISystem.Halcon.Controls.HControl();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.label106 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.nud_ROIColumn_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_DarkLightThreshold_2 = new System.Windows.Forms.NumericUpDown();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.lab_Dark_DarkThres_2 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.nud_light_DarkThres_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_DarkMax_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_Dark_DarkThres_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_Dark_LightThres_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_WhiteThres_2 = new System.Windows.Forms.NumericUpDown();
            this.label160 = new System.Windows.Forms.Label();
            this.lab_MinDefectSize_2 = new System.Windows.Forms.Label();
            this.nud_MinAreaSize_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_MinDefectSize_2 = new System.Windows.Forms.NumericUpDown();
            this.ckb_DefectV2_2 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.label173 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.nud_RoiWidthToBevelCenter_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_BevelWidth_2 = new System.Windows.Forms.NumericUpDown();
            this.label144 = new System.Windows.Forms.Label();
            this.ckb_DefectV1_2 = new System.Windows.Forms.CheckBox();
            this.label139 = new System.Windows.Forms.Label();
            this.nud_InnerThresholdMax_2 = new System.Windows.Forms.NumericUpDown();
            this.nud_edgeDefectMaxGray_2 = new System.Windows.Forms.NumericUpDown();
            this.label143 = new System.Windows.Forms.Label();
            this.nud_innerDefectMaxGray_2 = new System.Windows.Forms.NumericUpDown();
            this.label141 = new System.Windows.Forms.Label();
            this.nud_InnerDefectAreaSize_2 = new System.Windows.Forms.NumericUpDown();
            this.label140 = new System.Windows.Forms.Label();
            this.nud_AiMinGray_2 = new System.Windows.Forms.NumericUpDown();
            this.label142 = new System.Windows.Forms.Label();
            this.nud_AiDefectSize_2 = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.txb_recipePath = new System.Windows.Forms.TextBox();
            this.label174 = new System.Windows.Forms.Label();
            this.btn_setRecipe = new System.Windows.Forms.Button();
            this.tbp_Edge.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tbc_EdgeType.SuspendLayout();
            this.tbp_TypeB.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GrayMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeRotateAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_exAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_hvScaleW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_hvScaleH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CMeasureNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeLamp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tbl_MeasureResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Lower)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tbp_Demo.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DiameterB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeIndex)).BeginInit();
            this.tableLayoutPanel30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DiameterT)).BeginInit();
            this.tableLayoutPanel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr2)).BeginInit();
            this.tableLayoutPanel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_t)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeAngle)).BeginInit();
            this.tbp_Notch.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchLamp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchGrayMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b2Ang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PinRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR12Angle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b1Ang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchRotate)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Lower)).BeginInit();
            this.tbp_Defect_1.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_shiftAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_notchPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_totalAreaNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_catchAreaNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DefectLamp_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PixelSize_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InDistance_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropSize_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropNotchWidth_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinScore_1)).BeginInit();
            this.tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectCropImg_1)).BeginInit();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BackWhiteMinGray_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DisplayDilation_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_Notch_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchBlackWidth_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectMinWidth_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OutDefectMinWidth_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.tableLayoutPanel24.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RoiWidthToBevelCenter_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BevelWidth_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiDefectSize_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiMinGray_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectAreaSize_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerThresholdMax_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeDefectAreaSize_1)).BeginInit();
            this.tableLayoutPanel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ROIColumn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkLightThreshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_light_DarkThres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_DarkThres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_LightThres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_WhiteThres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinAreaSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinDefectSize)).BeginInit();
            this.tbp_Defect_2.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DefectLamp_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.tableLayoutPanel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PixelSize_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InDistance_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropSize_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropNotchWidth_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinScore_2)).BeginInit();
            this.tableLayoutPanel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectCropImg_2)).BeginInit();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BackWhiteMinGray_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DisplayDilation_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_Notch_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchBlackWidth_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectMinWidth_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OutDefectMinWidth_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ROIColumn_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkLightThreshold_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_light_DarkThres_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkMax_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_DarkThres_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_LightThres_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_WhiteThres_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinAreaSize_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinDefectSize_2)).BeginInit();
            this.tableLayoutPanel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RoiWidthToBevelCenter_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BevelWidth_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerThresholdMax_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeDefectMaxGray_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectAreaSize_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiMinGray_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiDefectSize_2)).BeginInit();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbp_Edge
            // 
            this.tbp_Edge.Controls.Add(this.tableLayoutPanel1);
            this.tbp_Edge.Location = new System.Drawing.Point(4, 25);
            this.tbp_Edge.Name = "tbp_Edge";
            this.tbp_Edge.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_Edge.Size = new System.Drawing.Size(1137, 789);
            this.tbp_Edge.TabIndex = 0;
            this.tbp_Edge.Text = "Edge";
            this.tbp_Edge.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1131, 783);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txb_EdgeImgFolder);
            this.panel1.Controls.Add(this.txb_EdgeImgPath);
            this.panel1.Controls.Add(this.tableLayoutPanel4);
            this.panel1.Controls.Add(this.tbc_EdgeType);
            this.panel1.Controls.Add(this.label74);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.nud_EdgeLamp);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(446, 777);
            this.panel1.TabIndex = 2;
            // 
            // txb_EdgeImgFolder
            // 
            this.txb_EdgeImgFolder.Location = new System.Drawing.Point(164, 135);
            this.txb_EdgeImgFolder.Name = "txb_EdgeImgFolder";
            this.txb_EdgeImgFolder.Size = new System.Drawing.Size(259, 23);
            this.txb_EdgeImgFolder.TabIndex = 8;
            this.txb_EdgeImgFolder.Text = "C:\\Johnny\\Salmon\\Demo_Data\\面幅";
            // 
            // txb_EdgeImgPath
            // 
            this.txb_EdgeImgPath.Location = new System.Drawing.Point(164, 100);
            this.txb_EdgeImgPath.Name = "txb_EdgeImgPath";
            this.txb_EdgeImgPath.Size = new System.Drawing.Size(259, 23);
            this.txb_EdgeImgPath.TabIndex = 7;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_LoadImage_Edge, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.btn_SaveRecipe_Edge, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.label37, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label38, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_MasureTest_Edge, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.label168, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_MasureTest_Edge_Autoselect, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.label170, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_LoadFolder_Edge, 1, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label36.Location = new System.Drawing.Point(3, 3);
            this.label36.Margin = new System.Windows.Forms.Padding(3);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(51, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "開啟圖片";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadImage_Edge
            // 
            this.btn_LoadImage_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Edge.BackgroundImage")));
            this.btn_LoadImage_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Edge.Location = new System.Drawing.Point(3, 22);
            this.btn_LoadImage_Edge.Name = "btn_LoadImage_Edge";
            this.btn_LoadImage_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Edge.TabIndex = 2;
            this.btn_LoadImage_Edge.UseVisualStyleBackColor = true;
            this.btn_LoadImage_Edge.Click += new System.EventHandler(this.btn_LoadImage_Edge_Click);
            // 
            // btn_SaveRecipe_Edge
            // 
            this.btn_SaveRecipe_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_SaveRecipe_Edge.BackgroundImage")));
            this.btn_SaveRecipe_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_SaveRecipe_Edge.Location = new System.Drawing.Point(174, 22);
            this.btn_SaveRecipe_Edge.Name = "btn_SaveRecipe_Edge";
            this.btn_SaveRecipe_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_SaveRecipe_Edge.TabIndex = 2;
            this.btn_SaveRecipe_Edge.UseVisualStyleBackColor = true;
            this.btn_SaveRecipe_Edge.Click += new System.EventHandler(this.btn_SaveRecipe_Edge_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label37.Location = new System.Drawing.Point(174, 3);
            this.label37.Margin = new System.Windows.Forms.Padding(3);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(51, 13);
            this.label37.TabIndex = 1;
            this.label37.Text = "儲存參數";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label38.Location = new System.Drawing.Point(231, 3);
            this.label38.Margin = new System.Windows.Forms.Padding(3);
            this.label38.Name = "label38";
            this.label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label38.Size = new System.Drawing.Size(51, 13);
            this.label38.TabIndex = 1;
            this.label38.Text = "量測計算";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_MasureTest_Edge
            // 
            this.btn_MasureTest_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_MasureTest_Edge.BackgroundImage")));
            this.btn_MasureTest_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_MasureTest_Edge.Location = new System.Drawing.Point(231, 22);
            this.btn_MasureTest_Edge.Name = "btn_MasureTest_Edge";
            this.btn_MasureTest_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_MasureTest_Edge.TabIndex = 5;
            this.btn_MasureTest_Edge.UseVisualStyleBackColor = true;
            this.btn_MasureTest_Edge.Click += new System.EventHandler(this.btn_MasureTest_Edge_Click);
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label168.Location = new System.Drawing.Point(288, 3);
            this.label168.Margin = new System.Windows.Forms.Padding(3);
            this.label168.Name = "label168";
            this.label168.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label168.Size = new System.Drawing.Size(51, 13);
            this.label168.TabIndex = 6;
            this.label168.Text = "挑圖量測";
            this.label168.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_MasureTest_Edge_Autoselect
            // 
            this.btn_MasureTest_Edge_Autoselect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_MasureTest_Edge_Autoselect.BackgroundImage")));
            this.btn_MasureTest_Edge_Autoselect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_MasureTest_Edge_Autoselect.Location = new System.Drawing.Point(288, 22);
            this.btn_MasureTest_Edge_Autoselect.Name = "btn_MasureTest_Edge_Autoselect";
            this.btn_MasureTest_Edge_Autoselect.Size = new System.Drawing.Size(51, 43);
            this.btn_MasureTest_Edge_Autoselect.TabIndex = 7;
            this.btn_MasureTest_Edge_Autoselect.UseVisualStyleBackColor = true;
            this.btn_MasureTest_Edge_Autoselect.Click += new System.EventHandler(this.btn_MasureTest_Edge_Autoselect_Click);
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label170.Location = new System.Drawing.Point(60, 3);
            this.label170.Margin = new System.Windows.Forms.Padding(3);
            this.label170.Name = "label170";
            this.label170.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label170.Size = new System.Drawing.Size(51, 13);
            this.label170.TabIndex = 8;
            this.label170.Text = "挑資料夾";
            this.label170.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadFolder_Edge
            // 
            this.btn_LoadFolder_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadFolder_Edge.BackgroundImage")));
            this.btn_LoadFolder_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadFolder_Edge.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadFolder_Edge.Name = "btn_LoadFolder_Edge";
            this.btn_LoadFolder_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadFolder_Edge.TabIndex = 9;
            this.btn_LoadFolder_Edge.UseVisualStyleBackColor = true;
            this.btn_LoadFolder_Edge.Click += new System.EventHandler(this.btn_LoadFolder_Edge_Click);
            // 
            // tbc_EdgeType
            // 
            this.tbc_EdgeType.Controls.Add(this.tbp_TypeB);
            this.tbc_EdgeType.Location = new System.Drawing.Point(19, 169);
            this.tbc_EdgeType.Name = "tbc_EdgeType";
            this.tbc_EdgeType.SelectedIndex = 0;
            this.tbc_EdgeType.Size = new System.Drawing.Size(411, 584);
            this.tbc_EdgeType.TabIndex = 4;
            // 
            // tbp_TypeB
            // 
            this.tbp_TypeB.Controls.Add(this.tableLayoutPanel3);
            this.tbp_TypeB.Location = new System.Drawing.Point(4, 25);
            this.tbp_TypeB.Name = "tbp_TypeB";
            this.tbp_TypeB.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_TypeB.Size = new System.Drawing.Size(403, 555);
            this.tbp_TypeB.TabIndex = 0;
            this.tbp_TypeB.Text = "TypeB";
            this.tbp_TypeB.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.97298F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.02703F));
            this.tableLayoutPanel3.Controls.Add(this.label10, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.nud_GrayMax, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label8, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.nud_bu2Ratio, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.nud_bv2Ratio, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.label6, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label7, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.nud_bu1Ratio, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.nud_bv1Ratio, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleStart1, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleTop1, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label3, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleStart2, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.label5, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleTop2, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox3, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label94, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.nud_EdgeRotateAngle, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.nud_exAngle, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.label148, 1, 11);
            this.tableLayoutPanel3.Controls.Add(this.nud_hvScaleW, 2, 12);
            this.tableLayoutPanel3.Controls.Add(this.nud_hvScaleH, 2, 13);
            this.tableLayoutPanel3.Controls.Add(this.nud_CMeasureNumber, 2, 14);
            this.tableLayoutPanel3.Controls.Add(this.label138, 1, 12);
            this.tableLayoutPanel3.Controls.Add(this.label156, 1, 13);
            this.tableLayoutPanel3.Controls.Add(this.label161, 1, 14);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 15;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 117F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(397, 549);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(141, 3);
            this.label10.Margin = new System.Windows.Forms.Padding(3);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(181, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "最大灰階值 GrayMax (Auto : -1)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_GrayMax
            // 
            this.nud_GrayMax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_GrayMax.Location = new System.Drawing.Point(329, 3);
            this.nud_GrayMax.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_GrayMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_GrayMax.Name = "nud_GrayMax";
            this.nud_GrayMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_GrayMax.Size = new System.Drawing.Size(64, 23);
            this.nud_GrayMax.TabIndex = 0;
            this.nud_GrayMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_GrayMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(141, 273);
            this.label9.Margin = new System.Windows.Forms.Padding(3);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(127, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "起始點比率(下)  u2:H2";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(141, 303);
            this.label8.Margin = new System.Windows.Forms.Padding(3);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(114, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "終點比率(下)  v2:H2";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_bu2Ratio
            // 
            this.nud_bu2Ratio.DecimalPlaces = 2;
            this.nud_bu2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu2Ratio.Location = new System.Drawing.Point(329, 273);
            this.nud_bu2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bu2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu2Ratio.Name = "nud_bu2Ratio";
            this.nud_bu2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bu2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bu2Ratio.TabIndex = 0;
            this.nud_bu2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bu2Ratio.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_bu2Ratio.ValueChanged += new System.EventHandler(this.nud_bu2Ratio_ValueChanged);
            // 
            // nud_bv2Ratio
            // 
            this.nud_bv2Ratio.DecimalPlaces = 2;
            this.nud_bv2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv2Ratio.Location = new System.Drawing.Point(329, 303);
            this.nud_bv2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bv2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv2Ratio.Name = "nud_bv2Ratio";
            this.nud_bv2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bv2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bv2Ratio.TabIndex = 0;
            this.nud_bv2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bv2Ratio.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.nud_bv2Ratio.ValueChanged += new System.EventHandler(this.nud_bu2Ratio_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(141, 213);
            this.label6.Margin = new System.Windows.Forms.Padding(3);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(127, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "起始點比率(上)  u1:H1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(141, 243);
            this.label7.Margin = new System.Windows.Forms.Padding(3);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(126, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "終點點比率(上)  v1:H1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_bu1Ratio
            // 
            this.nud_bu1Ratio.DecimalPlaces = 2;
            this.nud_bu1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu1Ratio.Location = new System.Drawing.Point(329, 213);
            this.nud_bu1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bu1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu1Ratio.Name = "nud_bu1Ratio";
            this.nud_bu1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bu1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bu1Ratio.TabIndex = 0;
            this.nud_bu1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bu1Ratio.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // nud_bv1Ratio
            // 
            this.nud_bv1Ratio.DecimalPlaces = 2;
            this.nud_bv1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv1Ratio.Location = new System.Drawing.Point(329, 243);
            this.nud_bv1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bv1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv1Ratio.Name = "nud_bv1Ratio";
            this.nud_bv1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bv1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bv1Ratio.TabIndex = 0;
            this.nud_bv1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bv1Ratio.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(162, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "起始點a1切線角度(上) [DEG]";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleStart1
            // 
            this.nud_AngleStart1.DecimalPlaces = 2;
            this.nud_AngleStart1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleStart1.Location = new System.Drawing.Point(329, 63);
            this.nud_AngleStart1.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_AngleStart1.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_AngleStart1.Name = "nud_AngleStart1";
            this.nud_AngleStart1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleStart1.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleStart1.TabIndex = 0;
            this.nud_AngleStart1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleStart1.Value = new decimal(new int[] {
            76,
            0,
            0,
            -2147483648});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 93);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(149, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "頂點c1切線角度(上) [DEG]";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleTop1
            // 
            this.nud_AngleTop1.DecimalPlaces = 2;
            this.nud_AngleTop1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleTop1.Location = new System.Drawing.Point(329, 93);
            this.nud_AngleTop1.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_AngleTop1.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_AngleTop1.Name = "nud_AngleTop1";
            this.nud_AngleTop1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleTop1.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleTop1.TabIndex = 0;
            this.nud_AngleTop1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleTop1.Value = new decimal(new int[] {
            20,
            0,
            0,
            -2147483648});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 153);
            this.label3.Margin = new System.Windows.Forms.Padding(3);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(162, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "起始點a2切線角度(下) [DEG]";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleStart2
            // 
            this.nud_AngleStart2.DecimalPlaces = 2;
            this.nud_AngleStart2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleStart2.Location = new System.Drawing.Point(329, 153);
            this.nud_AngleStart2.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_AngleStart2.Name = "nud_AngleStart2";
            this.nud_AngleStart2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleStart2.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleStart2.TabIndex = 0;
            this.nud_AngleStart2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleStart2.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(141, 123);
            this.label5.Margin = new System.Windows.Forms.Padding(3);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(149, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "頂點c2切線角度(下) [DEG]";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleTop2
            // 
            this.nud_AngleTop2.DecimalPlaces = 2;
            this.nud_AngleTop2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleTop2.Location = new System.Drawing.Point(329, 123);
            this.nud_AngleTop2.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_AngleTop2.Name = "nud_AngleTop2";
            this.nud_AngleTop2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleTop2.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleTop2.TabIndex = 0;
            this.nud_AngleTop2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleTop2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(3, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.tableLayoutPanel3.SetRowSpan(this.pictureBox2, 4);
            this.pictureBox2.Size = new System.Drawing.Size(132, 114);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Location = new System.Drawing.Point(3, 213);
            this.pictureBox3.Name = "pictureBox3";
            this.tableLayoutPanel3.SetRowSpan(this.pictureBox3, 4);
            this.pictureBox3.Size = new System.Drawing.Size(132, 114);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(141, 33);
            this.label94.Margin = new System.Windows.Forms.Padding(3);
            this.label94.Name = "label94";
            this.label94.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label94.Size = new System.Drawing.Size(132, 16);
            this.label94.TabIndex = 1;
            this.label94.Text = "旋轉角度(順時-  逆時+)";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_EdgeRotateAngle
            // 
            this.nud_EdgeRotateAngle.Increment = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_EdgeRotateAngle.Location = new System.Drawing.Point(329, 33);
            this.nud_EdgeRotateAngle.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.nud_EdgeRotateAngle.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.nud_EdgeRotateAngle.Name = "nud_EdgeRotateAngle";
            this.nud_EdgeRotateAngle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_EdgeRotateAngle.Size = new System.Drawing.Size(64, 23);
            this.nud_EdgeRotateAngle.TabIndex = 0;
            this.nud_EdgeRotateAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_EdgeRotateAngle.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // nud_exAngle
            // 
            this.nud_exAngle.DecimalPlaces = 2;
            this.nud_exAngle.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_exAngle.Location = new System.Drawing.Point(329, 333);
            this.nud_exAngle.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_exAngle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_exAngle.Name = "nud_exAngle";
            this.nud_exAngle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_exAngle.Size = new System.Drawing.Size(64, 23);
            this.nud_exAngle.TabIndex = 0;
            this.nud_exAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_exAngle.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_exAngle.ValueChanged += new System.EventHandler(this.nud_bu2Ratio_ValueChanged);
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(141, 333);
            this.label148.Margin = new System.Windows.Forms.Padding(3);
            this.label148.Name = "label148";
            this.label148.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label148.Size = new System.Drawing.Size(111, 16);
            this.label148.TabIndex = 1;
            this.label148.Text = "R計算排除角 [Deg]";
            // 
            // nud_hvScaleW
            // 
            this.nud_hvScaleW.DecimalPlaces = 2;
            this.nud_hvScaleW.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_hvScaleW.Location = new System.Drawing.Point(329, 366);
            this.nud_hvScaleW.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_hvScaleW.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_hvScaleW.Name = "nud_hvScaleW";
            this.nud_hvScaleW.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_hvScaleW.Size = new System.Drawing.Size(64, 23);
            this.nud_hvScaleW.TabIndex = 3;
            this.nud_hvScaleW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_hvScaleW.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_hvScaleH
            // 
            this.nud_hvScaleH.DecimalPlaces = 2;
            this.nud_hvScaleH.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_hvScaleH.Location = new System.Drawing.Point(329, 396);
            this.nud_hvScaleH.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_hvScaleH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_hvScaleH.Name = "nud_hvScaleH";
            this.nud_hvScaleH.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_hvScaleH.Size = new System.Drawing.Size(64, 23);
            this.nud_hvScaleH.TabIndex = 4;
            this.nud_hvScaleH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_hvScaleH.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_CMeasureNumber
            // 
            this.nud_CMeasureNumber.DecimalPlaces = 2;
            this.nud_CMeasureNumber.Location = new System.Drawing.Point(329, 425);
            this.nud_CMeasureNumber.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_CMeasureNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_CMeasureNumber.Name = "nud_CMeasureNumber";
            this.nud_CMeasureNumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_CMeasureNumber.Size = new System.Drawing.Size(64, 23);
            this.nud_CMeasureNumber.TabIndex = 5;
            this.nud_CMeasureNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_CMeasureNumber.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(141, 366);
            this.label138.Margin = new System.Windows.Forms.Padding(3);
            this.label138.Name = "label138";
            this.label138.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label138.Size = new System.Drawing.Size(60, 16);
            this.label138.TabIndex = 6;
            this.label138.Text = "寬度scale";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(141, 396);
            this.label156.Margin = new System.Windows.Forms.Padding(3);
            this.label156.Name = "label156";
            this.label156.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label156.Size = new System.Drawing.Size(60, 16);
            this.label156.TabIndex = 7;
            this.label156.Text = "高度scale";
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(141, 425);
            this.label161.Margin = new System.Windows.Forms.Padding(3);
            this.label161.Name = "label161";
            this.label161.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label161.Size = new System.Drawing.Size(152, 16);
            this.label161.TabIndex = 8;
            this.label161.Text = "導角起始終點抓幾個量測點";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(23, 138);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(40, 16);
            this.label74.TabIndex = 1;
            this.label74.Text = "Lamp";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "A",
            "B",
            "C"});
            this.comboBox1.Location = new System.Drawing.Point(63, 99);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(35, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "B";
            // 
            // nud_EdgeLamp
            // 
            this.nud_EdgeLamp.DecimalPlaces = 2;
            this.nud_EdgeLamp.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_EdgeLamp.Location = new System.Drawing.Point(93, 136);
            this.nud_EdgeLamp.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_EdgeLamp.Name = "nud_EdgeLamp";
            this.nud_EdgeLamp.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_EdgeLamp.Size = new System.Drawing.Size(64, 23);
            this.nud_EdgeLamp.TabIndex = 0;
            this.nud_EdgeLamp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_EdgeLamp.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(64, 135);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 24);
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.20035F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.799648F));
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tbl_MeasureResult, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.hctrl_EdgeView, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(455, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.250597F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.7494F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 317F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(673, 777);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label40.Location = new System.Drawing.Point(3, 3);
            this.label40.Margin = new System.Windows.Forms.Padding(3);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(627, 16);
            this.label40.TabIndex = 1;
            this.label40.Text = "影像視窗";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbl_MeasureResult
            // 
            this.tbl_MeasureResult.ColumnCount = 10;
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.463196F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.31059F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.84919F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.181329F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.02873F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.38779F));
            this.tbl_MeasureResult.Controls.Add(this.label11, 0, 2);
            this.tbl_MeasureResult.Controls.Add(this.label12, 0, 3);
            this.tbl_MeasureResult.Controls.Add(this.label13, 5, 2);
            this.tbl_MeasureResult.Controls.Add(this.label14, 5, 3);
            this.tbl_MeasureResult.Controls.Add(this.label15, 0, 4);
            this.tbl_MeasureResult.Controls.Add(this.label16, 0, 5);
            this.tbl_MeasureResult.Controls.Add(this.label19, 0, 7);
            this.tbl_MeasureResult.Controls.Add(this.label20, 0, 8);
            this.tbl_MeasureResult.Controls.Add(this.label18, 0, 6);
            this.tbl_MeasureResult.Controls.Add(this.label22, 5, 7);
            this.tbl_MeasureResult.Controls.Add(this.label21, 5, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_A1Upper, 3, 2);
            this.tbl_MeasureResult.Controls.Add(this.label17, 5, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_A1, 1, 2);
            this.tbl_MeasureResult.Controls.Add(this.txb_A2, 1, 3);
            this.tbl_MeasureResult.Controls.Add(this.txb_B1, 1, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_B2, 1, 5);
            this.tbl_MeasureResult.Controls.Add(this.txb_R1, 1, 6);
            this.tbl_MeasureResult.Controls.Add(this.txb_R2, 1, 7);
            this.tbl_MeasureResult.Controls.Add(this.txb_t, 1, 8);
            this.tbl_MeasureResult.Controls.Add(this.txb_Ang1, 6, 2);
            this.tbl_MeasureResult.Controls.Add(this.txb_Ang2, 6, 3);
            this.tbl_MeasureResult.Controls.Add(this.txb_BC, 6, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_C2, 6, 7);
            this.tbl_MeasureResult.Controls.Add(this.txb_C1, 6, 6);
            this.tbl_MeasureResult.Controls.Add(this.label30, 7, 7);
            this.tbl_MeasureResult.Controls.Add(this.label31, 7, 6);
            this.tbl_MeasureResult.Controls.Add(this.label32, 7, 4);
            this.tbl_MeasureResult.Controls.Add(this.label33, 7, 3);
            this.tbl_MeasureResult.Controls.Add(this.label34, 7, 2);
            this.tbl_MeasureResult.Controls.Add(this.label35, 0, 1);
            this.tbl_MeasureResult.Controls.Add(this.label23, 2, 2);
            this.tbl_MeasureResult.Controls.Add(this.label24, 2, 3);
            this.tbl_MeasureResult.Controls.Add(this.label25, 2, 4);
            this.tbl_MeasureResult.Controls.Add(this.label26, 2, 5);
            this.tbl_MeasureResult.Controls.Add(this.label27, 2, 6);
            this.tbl_MeasureResult.Controls.Add(this.label28, 2, 7);
            this.tbl_MeasureResult.Controls.Add(this.label29, 2, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_A1Lower, 4, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_A2Upper, 3, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_A2Lower, 4, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_B1Upper, 3, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_B2Upper, 3, 5);
            this.tbl_MeasureResult.Controls.Add(this.nud_B2Lower, 4, 5);
            this.tbl_MeasureResult.Controls.Add(this.nud_B1Lower, 4, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_R1Upper, 3, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_R2Upper, 3, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_tUpper, 3, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_tLower, 4, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_R2Lower, 4, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_R1Lower, 4, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_BCUpper, 8, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_BCLower, 9, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang1Upper, 8, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang1Lower, 9, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang2Upper, 8, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang2Lower, 9, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_C1Upper, 8, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_C2Upper, 8, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_C1Lower, 9, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_C2Lower, 9, 7);
            this.tbl_MeasureResult.Controls.Add(this.label41, 3, 1);
            this.tbl_MeasureResult.Controls.Add(this.label42, 4, 1);
            this.tbl_MeasureResult.Controls.Add(this.label43, 5, 1);
            this.tbl_MeasureResult.Controls.Add(this.label44, 8, 1);
            this.tbl_MeasureResult.Controls.Add(this.label45, 9, 1);
            this.tbl_MeasureResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl_MeasureResult.Location = new System.Drawing.Point(3, 429);
            this.tbl_MeasureResult.Name = "tbl_MeasureResult";
            this.tbl_MeasureResult.RowCount = 9;
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.366812F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.46725F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.Size = new System.Drawing.Size(627, 311);
            this.tbl_MeasureResult.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 34);
            this.label11.TabIndex = 0;
            this.label11.Text = "A1";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 101);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 34);
            this.label12.TabIndex = 0;
            this.label12.Text = "A2";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(308, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 34);
            this.label13.TabIndex = 0;
            this.label13.Text = "Ang1";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(308, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 34);
            this.label14.TabIndex = 0;
            this.label14.Text = "Ang2";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 135);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 34);
            this.label15.TabIndex = 0;
            this.label15.Text = "B1";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 169);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 34);
            this.label16.TabIndex = 0;
            this.label16.Text = "B2";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(3, 237);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 34);
            this.label19.TabIndex = 0;
            this.label19.Text = "R2";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 271);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 40);
            this.label20.TabIndex = 0;
            this.label20.Text = "t";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(3, 203);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 34);
            this.label18.TabIndex = 0;
            this.label18.Text = "R1";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(308, 237);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 34);
            this.label22.TabIndex = 0;
            this.label22.Text = "C2";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(308, 203);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(55, 34);
            this.label21.TabIndex = 0;
            this.label21.Text = "C1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_A1Upper
            // 
            this.nud_A1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A1Upper.Location = new System.Drawing.Point(165, 70);
            this.nud_A1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A1Upper.Name = "nud_A1Upper";
            this.nud_A1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A1Upper.Size = new System.Drawing.Size(50, 23);
            this.nud_A1Upper.TabIndex = 0;
            this.nud_A1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(308, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 34);
            this.label17.TabIndex = 0;
            this.label17.Text = "BC";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txb_A1
            // 
            this.txb_A1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_A1.Location = new System.Drawing.Point(64, 70);
            this.txb_A1.Name = "txb_A1";
            this.txb_A1.ReadOnly = true;
            this.txb_A1.Size = new System.Drawing.Size(55, 23);
            this.txb_A1.TabIndex = 1;
            this.txb_A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_A2
            // 
            this.txb_A2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_A2.Location = new System.Drawing.Point(64, 104);
            this.txb_A2.Name = "txb_A2";
            this.txb_A2.ReadOnly = true;
            this.txb_A2.Size = new System.Drawing.Size(55, 23);
            this.txb_A2.TabIndex = 1;
            this.txb_A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_B1
            // 
            this.txb_B1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_B1.Location = new System.Drawing.Point(64, 138);
            this.txb_B1.Name = "txb_B1";
            this.txb_B1.ReadOnly = true;
            this.txb_B1.Size = new System.Drawing.Size(55, 23);
            this.txb_B1.TabIndex = 1;
            this.txb_B1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_B2
            // 
            this.txb_B2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_B2.Location = new System.Drawing.Point(64, 172);
            this.txb_B2.Name = "txb_B2";
            this.txb_B2.ReadOnly = true;
            this.txb_B2.Size = new System.Drawing.Size(55, 23);
            this.txb_B2.TabIndex = 1;
            this.txb_B2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_R1
            // 
            this.txb_R1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_R1.Location = new System.Drawing.Point(64, 206);
            this.txb_R1.Name = "txb_R1";
            this.txb_R1.ReadOnly = true;
            this.txb_R1.Size = new System.Drawing.Size(55, 23);
            this.txb_R1.TabIndex = 1;
            this.txb_R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_R2
            // 
            this.txb_R2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_R2.Location = new System.Drawing.Point(64, 240);
            this.txb_R2.Name = "txb_R2";
            this.txb_R2.ReadOnly = true;
            this.txb_R2.Size = new System.Drawing.Size(55, 23);
            this.txb_R2.TabIndex = 1;
            this.txb_R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_t
            // 
            this.txb_t.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_t.Location = new System.Drawing.Point(64, 274);
            this.txb_t.Name = "txb_t";
            this.txb_t.ReadOnly = true;
            this.txb_t.Size = new System.Drawing.Size(55, 23);
            this.txb_t.TabIndex = 1;
            this.txb_t.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Ang1
            // 
            this.txb_Ang1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Ang1.Location = new System.Drawing.Point(369, 70);
            this.txb_Ang1.Name = "txb_Ang1";
            this.txb_Ang1.ReadOnly = true;
            this.txb_Ang1.Size = new System.Drawing.Size(55, 23);
            this.txb_Ang1.TabIndex = 1;
            this.txb_Ang1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Ang2
            // 
            this.txb_Ang2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Ang2.Location = new System.Drawing.Point(369, 104);
            this.txb_Ang2.Name = "txb_Ang2";
            this.txb_Ang2.ReadOnly = true;
            this.txb_Ang2.Size = new System.Drawing.Size(55, 23);
            this.txb_Ang2.TabIndex = 1;
            this.txb_Ang2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_BC
            // 
            this.txb_BC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_BC.Location = new System.Drawing.Point(369, 138);
            this.txb_BC.Name = "txb_BC";
            this.txb_BC.ReadOnly = true;
            this.txb_BC.Size = new System.Drawing.Size(55, 23);
            this.txb_BC.TabIndex = 1;
            this.txb_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_C2
            // 
            this.txb_C2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_C2.Location = new System.Drawing.Point(369, 240);
            this.txb_C2.Name = "txb_C2";
            this.txb_C2.ReadOnly = true;
            this.txb_C2.Size = new System.Drawing.Size(55, 23);
            this.txb_C2.TabIndex = 1;
            this.txb_C2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_C1
            // 
            this.txb_C1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_C1.Location = new System.Drawing.Point(369, 206);
            this.txb_C1.Name = "txb_C1";
            this.txb_C1.ReadOnly = true;
            this.txb_C1.Size = new System.Drawing.Size(55, 23);
            this.txb_C1.TabIndex = 1;
            this.txb_C1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(430, 237);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 16);
            this.label30.TabIndex = 0;
            this.label30.Text = "um";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(430, 203);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(26, 16);
            this.label31.TabIndex = 0;
            this.label31.Text = "um";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(430, 135);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(26, 16);
            this.label32.TabIndex = 0;
            this.label32.Text = "um";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(430, 101);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(31, 16);
            this.label33.TabIndex = 0;
            this.label33.Text = "deg";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(430, 67);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(31, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "deg";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.tbl_MeasureResult.SetColumnSpan(this.label35, 2);
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(3, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(116, 54);
            this.label35.TabIndex = 0;
            this.label35.Text = "量測結果\r\nMesureResult";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(125, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 16);
            this.label23.TabIndex = 0;
            this.label23.Text = "um";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(125, 101);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 16);
            this.label24.TabIndex = 0;
            this.label24.Text = "um";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(125, 135);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 16);
            this.label25.TabIndex = 0;
            this.label25.Text = "um";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(125, 169);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 16);
            this.label26.TabIndex = 0;
            this.label26.Text = "um";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(125, 203);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 16);
            this.label27.TabIndex = 0;
            this.label27.Text = "um";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(125, 237);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 16);
            this.label28.TabIndex = 0;
            this.label28.Text = "um";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(125, 271);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 16);
            this.label29.TabIndex = 0;
            this.label29.Text = "um";
            // 
            // nud_A1Lower
            // 
            this.nud_A1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A1Lower.Location = new System.Drawing.Point(235, 70);
            this.nud_A1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A1Lower.Name = "nud_A1Lower";
            this.nud_A1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_A1Lower.TabIndex = 0;
            this.nud_A1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_A2Upper
            // 
            this.nud_A2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A2Upper.Location = new System.Drawing.Point(165, 104);
            this.nud_A2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A2Upper.Name = "nud_A2Upper";
            this.nud_A2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_A2Upper.TabIndex = 0;
            this.nud_A2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_A2Lower
            // 
            this.nud_A2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A2Lower.Location = new System.Drawing.Point(235, 104);
            this.nud_A2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A2Lower.Name = "nud_A2Lower";
            this.nud_A2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_A2Lower.TabIndex = 0;
            this.nud_A2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A2Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_B1Upper
            // 
            this.nud_B1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B1Upper.Location = new System.Drawing.Point(165, 138);
            this.nud_B1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B1Upper.Name = "nud_B1Upper";
            this.nud_B1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_B1Upper.TabIndex = 0;
            this.nud_B1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_B2Upper
            // 
            this.nud_B2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B2Upper.Location = new System.Drawing.Point(165, 172);
            this.nud_B2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B2Upper.Name = "nud_B2Upper";
            this.nud_B2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_B2Upper.TabIndex = 0;
            this.nud_B2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_B2Lower
            // 
            this.nud_B2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B2Lower.Location = new System.Drawing.Point(235, 172);
            this.nud_B2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B2Lower.Name = "nud_B2Lower";
            this.nud_B2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_B2Lower.TabIndex = 0;
            this.nud_B2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B2Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_B1Lower
            // 
            this.nud_B1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B1Lower.Location = new System.Drawing.Point(235, 138);
            this.nud_B1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B1Lower.Name = "nud_B1Lower";
            this.nud_B1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_B1Lower.TabIndex = 0;
            this.nud_B1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_R1Upper
            // 
            this.nud_R1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R1Upper.Location = new System.Drawing.Point(165, 206);
            this.nud_R1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R1Upper.Name = "nud_R1Upper";
            this.nud_R1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_R1Upper.TabIndex = 0;
            this.nud_R1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_R2Upper
            // 
            this.nud_R2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R2Upper.Location = new System.Drawing.Point(165, 240);
            this.nud_R2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R2Upper.Name = "nud_R2Upper";
            this.nud_R2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_R2Upper.TabIndex = 0;
            this.nud_R2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_tUpper
            // 
            this.nud_tUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_tUpper.Location = new System.Drawing.Point(165, 274);
            this.nud_tUpper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tUpper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_tUpper.Name = "nud_tUpper";
            this.nud_tUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_tUpper.Size = new System.Drawing.Size(49, 23);
            this.nud_tUpper.TabIndex = 0;
            this.nud_tUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tUpper.Value = new decimal(new int[] {
            900,
            0,
            0,
            0});
            // 
            // nud_tLower
            // 
            this.nud_tLower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_tLower.Location = new System.Drawing.Point(235, 274);
            this.nud_tLower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tLower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_tLower.Name = "nud_tLower";
            this.nud_tLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_tLower.Size = new System.Drawing.Size(49, 23);
            this.nud_tLower.TabIndex = 0;
            this.nud_tLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tLower.Value = new decimal(new int[] {
            700,
            0,
            0,
            0});
            // 
            // nud_R2Lower
            // 
            this.nud_R2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R2Lower.Location = new System.Drawing.Point(235, 240);
            this.nud_R2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R2Lower.Name = "nud_R2Lower";
            this.nud_R2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_R2Lower.TabIndex = 0;
            this.nud_R2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R2Lower.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_R1Lower
            // 
            this.nud_R1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R1Lower.Location = new System.Drawing.Point(235, 206);
            this.nud_R1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R1Lower.Name = "nud_R1Lower";
            this.nud_R1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_R1Lower.TabIndex = 0;
            this.nud_R1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_BCUpper
            // 
            this.nud_BCUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BCUpper.Location = new System.Drawing.Point(474, 138);
            this.nud_BCUpper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_BCUpper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_BCUpper.Name = "nud_BCUpper";
            this.nud_BCUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BCUpper.Size = new System.Drawing.Size(49, 23);
            this.nud_BCUpper.TabIndex = 0;
            this.nud_BCUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BCUpper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_BCLower
            // 
            this.nud_BCLower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BCLower.Location = new System.Drawing.Point(548, 138);
            this.nud_BCLower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_BCLower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_BCLower.Name = "nud_BCLower";
            this.nud_BCLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BCLower.Size = new System.Drawing.Size(49, 23);
            this.nud_BCLower.TabIndex = 0;
            this.nud_BCLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BCLower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_Ang1Upper
            // 
            this.nud_Ang1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang1Upper.Location = new System.Drawing.Point(474, 70);
            this.nud_Ang1Upper.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang1Upper.Name = "nud_Ang1Upper";
            this.nud_Ang1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang1Upper.TabIndex = 0;
            this.nud_Ang1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang1Upper.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nud_Ang1Lower
            // 
            this.nud_Ang1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang1Lower.Location = new System.Drawing.Point(548, 70);
            this.nud_Ang1Lower.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang1Lower.Name = "nud_Ang1Lower";
            this.nud_Ang1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang1Lower.TabIndex = 0;
            this.nud_Ang1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang1Lower.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_Ang2Upper
            // 
            this.nud_Ang2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang2Upper.Location = new System.Drawing.Point(474, 104);
            this.nud_Ang2Upper.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang2Upper.Name = "nud_Ang2Upper";
            this.nud_Ang2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang2Upper.TabIndex = 0;
            this.nud_Ang2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang2Upper.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nud_Ang2Lower
            // 
            this.nud_Ang2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang2Lower.Location = new System.Drawing.Point(548, 104);
            this.nud_Ang2Lower.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang2Lower.Name = "nud_Ang2Lower";
            this.nud_Ang2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang2Lower.TabIndex = 0;
            this.nud_Ang2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang2Lower.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_C1Upper
            // 
            this.nud_C1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C1Upper.Location = new System.Drawing.Point(474, 206);
            this.nud_C1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_C1Upper.Name = "nud_C1Upper";
            this.nud_C1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_C1Upper.TabIndex = 0;
            this.nud_C1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_C2Upper
            // 
            this.nud_C2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C2Upper.Location = new System.Drawing.Point(474, 240);
            this.nud_C2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_C2Upper.Name = "nud_C2Upper";
            this.nud_C2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_C2Upper.TabIndex = 0;
            this.nud_C2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_C1Lower
            // 
            this.nud_C1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C1Lower.Location = new System.Drawing.Point(548, 206);
            this.nud_C1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C1Lower.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_C1Lower.Name = "nud_C1Lower";
            this.nud_C1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_C1Lower.TabIndex = 0;
            this.nud_C1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C1Lower.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // nud_C2Lower
            // 
            this.nud_C2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C2Lower.Location = new System.Drawing.Point(548, 240);
            this.nud_C2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C2Lower.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_C2Lower.Name = "nud_C2Lower";
            this.nud_C2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_C2Lower.TabIndex = 0;
            this.nud_C2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C2Lower.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(165, 13);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(64, 54);
            this.label41.TabIndex = 0;
            this.label41.Text = "上限值\r\nUpper";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(235, 13);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(67, 54);
            this.label42.TabIndex = 0;
            this.label42.Text = "下限值\r\nLower";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.tbl_MeasureResult.SetColumnSpan(this.label43, 2);
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(308, 13);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(116, 54);
            this.label43.TabIndex = 0;
            this.label43.Text = "量測結果\r\nMesureResult";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(474, 13);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 54);
            this.label44.TabIndex = 0;
            this.label44.Text = "上限值\r\nUpper";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(548, 13);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(76, 54);
            this.label45.TabIndex = 0;
            this.label45.Text = "下限值\r\nLower";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hctrl_EdgeView
            // 
            this.hctrl_EdgeView.AllowDrop = true;
            this.hctrl_EdgeView.BackColor = System.Drawing.Color.Black;
            this.hctrl_EdgeView.FontSizeThreshold = 8;
            this.hctrl_EdgeView.ImageBuffer.Columns = 1;
            this.hctrl_EdgeView.ImageBuffer.Height = 480;
            this.hctrl_EdgeView.ImageBuffer.Heights = 480;
            this.hctrl_EdgeView.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj")));
            this.hctrl_EdgeView.ImageBuffer.RawImage = null;
            this.hctrl_EdgeView.ImageBuffer.Rows = 1;
            this.hctrl_EdgeView.ImageBuffer.Width = 640;
            this.hctrl_EdgeView.ImageBuffer.Widths = 640;
            this.hctrl_EdgeView.IsDispCenterCross = false;
            this.hctrl_EdgeView.IsDispHObject = true;
            this.hctrl_EdgeView.IsDispROIFrameFontInfo = true;
            this.hctrl_EdgeView.IsLockGetMposition = false;
            this.hctrl_EdgeView.IsLockMouseOperation = false;
            this.hctrl_EdgeView.IsUseMenuByMouseRightButton = true;
            this.hctrl_EdgeView.KeyCtrlPressStatus = false;
            this.hctrl_EdgeView.Location = new System.Drawing.Point(0, 22);
            this.hctrl_EdgeView.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_EdgeView.MaxZoom = 100F;
            this.hctrl_EdgeView.MinZoom = 0.01F;
            this.hctrl_EdgeView.Name = "hctrl_EdgeView";
            this.hctrl_EdgeView.ROIController.ActiveROIIndex = -1;
            this.hctrl_EdgeView.ROIFontSize = 18;
            this.hctrl_EdgeView.ROIFontSizeThreshold = 10;
            this.hctrl_EdgeView.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_EdgeView.ScrollBarEnable = false;
            this.hctrl_EdgeView.Size = new System.Drawing.Size(619, 404);
            this.hctrl_EdgeView.TabIndex = 3;
            this.hctrl_EdgeView.Zoom = 0.01F;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbp_Demo);
            this.tabControl1.Controls.Add(this.tbp_Edge);
            this.tabControl1.Controls.Add(this.tbp_Notch);
            this.tabControl1.Controls.Add(this.tbp_Defect_1);
            this.tabControl1.Controls.Add(this.tbp_Defect_2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(3, 62);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1145, 818);
            this.tabControl1.TabIndex = 2;
            // 
            // tbp_Demo
            // 
            this.tbp_Demo.Controls.Add(this.btn_CheckGrinding);
            this.tbp_Demo.Controls.Add(this.tableLayoutPanel31);
            this.tbp_Demo.Controls.Add(this.nud_edgeIndex);
            this.tbp_Demo.Controls.Add(this.label203);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionBottomAlign);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionTOPAlign);
            this.tbp_Demo.Controls.Add(this.btn_DiameterMeasurementRun);
            this.tbp_Demo.Controls.Add(this.label175);
            this.tbp_Demo.Controls.Add(this.btn_NotchInspectRun);
            this.tbp_Demo.Controls.Add(this.btn_NotchInspectLoadImage);
            this.tbp_Demo.Controls.Add(this.btn_NotchMeasurementRun);
            this.tbp_Demo.Controls.Add(this.btn_NotchMeasurementLoadImage);
            this.tbp_Demo.Controls.Add(this.btn_EdgeMeasurementRun);
            this.tbp_Demo.Controls.Add(this.btn_EdgeMeasurementLoadImage);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionBottomRun);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionBottomLoadImage);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionTOPRun);
            this.tbp_Demo.Controls.Add(this.btn_DefectInspectionTOPLoadImage);
            this.tbp_Demo.Controls.Add(this.label202);
            this.tbp_Demo.Controls.Add(this.label193);
            this.tbp_Demo.Controls.Add(this.tableLayoutPanel30);
            this.tbp_Demo.Controls.Add(this.tableLayoutPanel29);
            this.tbp_Demo.Controls.Add(this.tableLayoutPanel28);
            this.tbp_Demo.Controls.Add(this.label178);
            this.tbp_Demo.Controls.Add(this.hControl_EdgeMeasurement);
            this.tbp_Demo.Controls.Add(this.nud_edgeAngle);
            this.tbp_Demo.Controls.Add(this.btn_edgeNumberNext);
            this.tbp_Demo.Controls.Add(this.btn_edgeNumberBack);
            this.tbp_Demo.Controls.Add(this.label177);
            this.tbp_Demo.Controls.Add(this.hControl_NotchInspect);
            this.tbp_Demo.Controls.Add(this.label176);
            this.tbp_Demo.Controls.Add(this.hControl_NotchMeasurement);
            this.tbp_Demo.Controls.Add(this.label171);
            this.tbp_Demo.Controls.Add(this.hControl_linescanBottom);
            this.tbp_Demo.Controls.Add(this.hControl_linescanTop);
            this.tbp_Demo.Controls.Add(this.label192);
            this.tbp_Demo.Location = new System.Drawing.Point(4, 25);
            this.tbp_Demo.Name = "tbp_Demo";
            this.tbp_Demo.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_Demo.Size = new System.Drawing.Size(1137, 789);
            this.tbp_Demo.TabIndex = 4;
            this.tbp_Demo.Text = "Demo";
            this.tbp_Demo.UseVisualStyleBackColor = true;
            // 
            // btn_CheckGrinding
            // 
            this.btn_CheckGrinding.Location = new System.Drawing.Point(567, 13);
            this.btn_CheckGrinding.Name = "btn_CheckGrinding";
            this.btn_CheckGrinding.Size = new System.Drawing.Size(107, 23);
            this.btn_CheckGrinding.TabIndex = 38;
            this.btn_CheckGrinding.Text = "Check Grinding";
            this.btn_CheckGrinding.UseVisualStyleBackColor = true;
            this.btn_CheckGrinding.Click += new System.EventHandler(this.btn_CheckGrinding_Click);
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.59649F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.40351F));
            this.tableLayoutPanel31.Controls.Add(this.nud_DiameterB, 1, 0);
            this.tableLayoutPanel31.Controls.Add(this.label204, 0, 0);
            this.tableLayoutPanel31.Location = new System.Drawing.Point(934, 95);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(171, 26);
            this.tableLayoutPanel31.TabIndex = 37;
            // 
            // nud_DiameterB
            // 
            this.nud_DiameterB.DecimalPlaces = 4;
            this.nud_DiameterB.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_DiameterB.Location = new System.Drawing.Point(68, 3);
            this.nud_DiameterB.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DiameterB.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_DiameterB.Name = "nud_DiameterB";
            this.nud_DiameterB.ReadOnly = true;
            this.nud_DiameterB.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DiameterB.Size = new System.Drawing.Size(98, 23);
            this.nud_DiameterB.TabIndex = 29;
            this.nud_DiameterB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label204
            // 
            this.label204.AutoSize = true;
            this.label204.Location = new System.Drawing.Point(3, 0);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(56, 26);
            this.label204.TabIndex = 18;
            this.label204.Text = "Diameter";
            // 
            // nud_edgeIndex
            // 
            this.nud_edgeIndex.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_edgeIndex.Location = new System.Drawing.Point(537, 46);
            this.nud_edgeIndex.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.nud_edgeIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_edgeIndex.Name = "nud_edgeIndex";
            this.nud_edgeIndex.ReadOnly = true;
            this.nud_edgeIndex.Size = new System.Drawing.Size(49, 23);
            this.nud_edgeIndex.TabIndex = 35;
            // 
            // label203
            // 
            this.label203.AutoSize = true;
            this.label203.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label203.Location = new System.Drawing.Point(493, 49);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(48, 16);
            this.label203.TabIndex = 36;
            this.label203.Text = "index : ";
            // 
            // btn_DefectInspectionBottomAlign
            // 
            this.btn_DefectInspectionBottomAlign.Location = new System.Drawing.Point(235, 41);
            this.btn_DefectInspectionBottomAlign.Name = "btn_DefectInspectionBottomAlign";
            this.btn_DefectInspectionBottomAlign.Size = new System.Drawing.Size(46, 23);
            this.btn_DefectInspectionBottomAlign.TabIndex = 33;
            this.btn_DefectInspectionBottomAlign.Text = "Align";
            this.btn_DefectInspectionBottomAlign.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionBottomAlign.Click += new System.EventHandler(this.btn_DefectInspectionBottomAlign_Click);
            // 
            // btn_DefectInspectionTOPAlign
            // 
            this.btn_DefectInspectionTOPAlign.Location = new System.Drawing.Point(63, 40);
            this.btn_DefectInspectionTOPAlign.Name = "btn_DefectInspectionTOPAlign";
            this.btn_DefectInspectionTOPAlign.Size = new System.Drawing.Size(46, 23);
            this.btn_DefectInspectionTOPAlign.TabIndex = 32;
            this.btn_DefectInspectionTOPAlign.Text = "Align";
            this.btn_DefectInspectionTOPAlign.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionTOPAlign.Click += new System.EventHandler(this.btn_DefectInspectionTOPAlign_Click);
            // 
            // btn_DiameterMeasurementRun
            // 
            this.btn_DiameterMeasurementRun.Location = new System.Drawing.Point(998, 37);
            this.btn_DiameterMeasurementRun.Name = "btn_DiameterMeasurementRun";
            this.btn_DiameterMeasurementRun.Size = new System.Drawing.Size(44, 23);
            this.btn_DiameterMeasurementRun.TabIndex = 31;
            this.btn_DiameterMeasurementRun.Text = "Run";
            this.btn_DiameterMeasurementRun.UseVisualStyleBackColor = true;
            this.btn_DiameterMeasurementRun.Click += new System.EventHandler(this.btn_DiameterMeasurementRun_Click);
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label175.Location = new System.Drawing.Point(176, 16);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(159, 16);
            this.label175.TabIndex = 29;
            this.label175.Text = "Defect Inspection (Bottom)";
            // 
            // btn_NotchInspectRun
            // 
            this.btn_NotchInspectRun.Location = new System.Drawing.Point(1010, 396);
            this.btn_NotchInspectRun.Name = "btn_NotchInspectRun";
            this.btn_NotchInspectRun.Size = new System.Drawing.Size(44, 23);
            this.btn_NotchInspectRun.TabIndex = 28;
            this.btn_NotchInspectRun.Text = "Run";
            this.btn_NotchInspectRun.UseVisualStyleBackColor = true;
            this.btn_NotchInspectRun.Click += new System.EventHandler(this.btn_NotchInspectRun_Click);
            // 
            // btn_NotchInspectLoadImage
            // 
            this.btn_NotchInspectLoadImage.Location = new System.Drawing.Point(948, 396);
            this.btn_NotchInspectLoadImage.Name = "btn_NotchInspectLoadImage";
            this.btn_NotchInspectLoadImage.Size = new System.Drawing.Size(56, 23);
            this.btn_NotchInspectLoadImage.TabIndex = 27;
            this.btn_NotchInspectLoadImage.Text = "Load";
            this.btn_NotchInspectLoadImage.UseVisualStyleBackColor = true;
            this.btn_NotchInspectLoadImage.Click += new System.EventHandler(this.btn_NotchInspectLoadImage_Click);
            // 
            // btn_NotchMeasurementRun
            // 
            this.btn_NotchMeasurementRun.Location = new System.Drawing.Point(652, 395);
            this.btn_NotchMeasurementRun.Name = "btn_NotchMeasurementRun";
            this.btn_NotchMeasurementRun.Size = new System.Drawing.Size(44, 23);
            this.btn_NotchMeasurementRun.TabIndex = 26;
            this.btn_NotchMeasurementRun.Text = "Run";
            this.btn_NotchMeasurementRun.UseVisualStyleBackColor = true;
            this.btn_NotchMeasurementRun.Click += new System.EventHandler(this.btn_NotchMeasurementRun_Click);
            // 
            // btn_NotchMeasurementLoadImage
            // 
            this.btn_NotchMeasurementLoadImage.Location = new System.Drawing.Point(590, 395);
            this.btn_NotchMeasurementLoadImage.Name = "btn_NotchMeasurementLoadImage";
            this.btn_NotchMeasurementLoadImage.Size = new System.Drawing.Size(56, 23);
            this.btn_NotchMeasurementLoadImage.TabIndex = 25;
            this.btn_NotchMeasurementLoadImage.Text = "Load";
            this.btn_NotchMeasurementLoadImage.UseVisualStyleBackColor = true;
            this.btn_NotchMeasurementLoadImage.Click += new System.EventHandler(this.btn_NotchMeasurementLoadImage_Click);
            // 
            // btn_EdgeMeasurementRun
            // 
            this.btn_EdgeMeasurementRun.Location = new System.Drawing.Point(507, 13);
            this.btn_EdgeMeasurementRun.Name = "btn_EdgeMeasurementRun";
            this.btn_EdgeMeasurementRun.Size = new System.Drawing.Size(44, 23);
            this.btn_EdgeMeasurementRun.TabIndex = 24;
            this.btn_EdgeMeasurementRun.Text = "Run";
            this.btn_EdgeMeasurementRun.UseVisualStyleBackColor = true;
            this.btn_EdgeMeasurementRun.Click += new System.EventHandler(this.btn_EdgeMeasurementRun_Click);
            // 
            // btn_EdgeMeasurementLoadImage
            // 
            this.btn_EdgeMeasurementLoadImage.Location = new System.Drawing.Point(445, 13);
            this.btn_EdgeMeasurementLoadImage.Name = "btn_EdgeMeasurementLoadImage";
            this.btn_EdgeMeasurementLoadImage.Size = new System.Drawing.Size(56, 23);
            this.btn_EdgeMeasurementLoadImage.TabIndex = 23;
            this.btn_EdgeMeasurementLoadImage.Text = "Load";
            this.btn_EdgeMeasurementLoadImage.UseVisualStyleBackColor = true;
            this.btn_EdgeMeasurementLoadImage.Click += new System.EventHandler(this.btn_EdgeMeasurementLoadImage_Click);
            // 
            // btn_DefectInspectionBottomRun
            // 
            this.btn_DefectInspectionBottomRun.Location = new System.Drawing.Point(287, 40);
            this.btn_DefectInspectionBottomRun.Name = "btn_DefectInspectionBottomRun";
            this.btn_DefectInspectionBottomRun.Size = new System.Drawing.Size(44, 23);
            this.btn_DefectInspectionBottomRun.TabIndex = 22;
            this.btn_DefectInspectionBottomRun.Text = "Run";
            this.btn_DefectInspectionBottomRun.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionBottomRun.Click += new System.EventHandler(this.btn_DefectInspectionBottomRun_Click);
            // 
            // btn_DefectInspectionBottomLoadImage
            // 
            this.btn_DefectInspectionBottomLoadImage.Location = new System.Drawing.Point(181, 40);
            this.btn_DefectInspectionBottomLoadImage.Name = "btn_DefectInspectionBottomLoadImage";
            this.btn_DefectInspectionBottomLoadImage.Size = new System.Drawing.Size(48, 23);
            this.btn_DefectInspectionBottomLoadImage.TabIndex = 21;
            this.btn_DefectInspectionBottomLoadImage.Text = "Load";
            this.btn_DefectInspectionBottomLoadImage.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionBottomLoadImage.Click += new System.EventHandler(this.btn_DefectInspectionBottomLoadImage_Click);
            // 
            // btn_DefectInspectionTOPRun
            // 
            this.btn_DefectInspectionTOPRun.Location = new System.Drawing.Point(114, 41);
            this.btn_DefectInspectionTOPRun.Name = "btn_DefectInspectionTOPRun";
            this.btn_DefectInspectionTOPRun.Size = new System.Drawing.Size(44, 23);
            this.btn_DefectInspectionTOPRun.TabIndex = 20;
            this.btn_DefectInspectionTOPRun.Text = "Run";
            this.btn_DefectInspectionTOPRun.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionTOPRun.Click += new System.EventHandler(this.btn_DefectInspectionTOPRun_Click);
            // 
            // btn_DefectInspectionTOPLoadImage
            // 
            this.btn_DefectInspectionTOPLoadImage.Location = new System.Drawing.Point(8, 40);
            this.btn_DefectInspectionTOPLoadImage.Name = "btn_DefectInspectionTOPLoadImage";
            this.btn_DefectInspectionTOPLoadImage.Size = new System.Drawing.Size(48, 23);
            this.btn_DefectInspectionTOPLoadImage.TabIndex = 19;
            this.btn_DefectInspectionTOPLoadImage.Text = "Load";
            this.btn_DefectInspectionTOPLoadImage.UseVisualStyleBackColor = true;
            this.btn_DefectInspectionTOPLoadImage.Click += new System.EventHandler(this.btn_DefectInspectionTOPLoadImage_Click);
            // 
            // label202
            // 
            this.label202.AutoSize = true;
            this.label202.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label202.Location = new System.Drawing.Point(936, 127);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(165, 20);
            this.label202.TabIndex = 18;
            this.label202.Text = "Notch Measurement";
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label193.Location = new System.Drawing.Point(930, 16);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(188, 20);
            this.label193.TabIndex = 17;
            this.label193.Text = "Diameter Measurement";
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.59649F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.40351F));
            this.tableLayoutPanel30.Controls.Add(this.nud_DiameterT, 1, 0);
            this.tableLayoutPanel30.Controls.Add(this.label191, 0, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(934, 62);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(171, 26);
            this.tableLayoutPanel30.TabIndex = 15;
            // 
            // nud_DiameterT
            // 
            this.nud_DiameterT.DecimalPlaces = 4;
            this.nud_DiameterT.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_DiameterT.Location = new System.Drawing.Point(68, 3);
            this.nud_DiameterT.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DiameterT.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_DiameterT.Name = "nud_DiameterT";
            this.nud_DiameterT.ReadOnly = true;
            this.nud_DiameterT.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DiameterT.Size = new System.Drawing.Size(98, 23);
            this.nud_DiameterT.TabIndex = 29;
            this.nud_DiameterT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(3, 0);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(56, 26);
            this.label191.TabIndex = 18;
            this.label191.Text = "Diameter";
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.59649F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.40351F));
            this.tableLayoutPanel29.Controls.Add(this.nud_Vr1, 1, 6);
            this.tableLayoutPanel29.Controls.Add(this.nud_P2, 1, 5);
            this.tableLayoutPanel29.Controls.Add(this.nud_P1, 1, 4);
            this.tableLayoutPanel29.Controls.Add(this.nud_AngV, 1, 3);
            this.tableLayoutPanel29.Controls.Add(this.nud_Vr, 1, 2);
            this.tableLayoutPanel29.Controls.Add(this.nud_Vw, 1, 1);
            this.tableLayoutPanel29.Controls.Add(this.nud_Vh, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.label194, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.label195, 0, 1);
            this.tableLayoutPanel29.Controls.Add(this.label196, 0, 2);
            this.tableLayoutPanel29.Controls.Add(this.label197, 0, 3);
            this.tableLayoutPanel29.Controls.Add(this.label198, 0, 4);
            this.tableLayoutPanel29.Controls.Add(this.label199, 0, 5);
            this.tableLayoutPanel29.Controls.Add(this.label200, 0, 6);
            this.tableLayoutPanel29.Controls.Add(this.label201, 0, 7);
            this.tableLayoutPanel29.Controls.Add(this.nud_Vr2, 1, 7);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(934, 152);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 8;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(171, 227);
            this.tableLayoutPanel29.TabIndex = 14;
            // 
            // nud_Vr1
            // 
            this.nud_Vr1.DecimalPlaces = 4;
            this.nud_Vr1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_Vr1.Location = new System.Drawing.Point(68, 171);
            this.nud_Vr1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Vr1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Vr1.Name = "nud_Vr1";
            this.nud_Vr1.ReadOnly = true;
            this.nud_Vr1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Vr1.Size = new System.Drawing.Size(98, 23);
            this.nud_Vr1.TabIndex = 34;
            this.nud_Vr1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_P2
            // 
            this.nud_P2.DecimalPlaces = 4;
            this.nud_P2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_P2.Location = new System.Drawing.Point(68, 143);
            this.nud_P2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_P2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_P2.Name = "nud_P2";
            this.nud_P2.ReadOnly = true;
            this.nud_P2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P2.Size = new System.Drawing.Size(98, 23);
            this.nud_P2.TabIndex = 33;
            this.nud_P2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_P1
            // 
            this.nud_P1.DecimalPlaces = 4;
            this.nud_P1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_P1.Location = new System.Drawing.Point(68, 115);
            this.nud_P1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_P1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_P1.Name = "nud_P1";
            this.nud_P1.ReadOnly = true;
            this.nud_P1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P1.Size = new System.Drawing.Size(98, 23);
            this.nud_P1.TabIndex = 32;
            this.nud_P1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_AngV
            // 
            this.nud_AngV.DecimalPlaces = 4;
            this.nud_AngV.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_AngV.Location = new System.Drawing.Point(68, 87);
            this.nud_AngV.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_AngV.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_AngV.Name = "nud_AngV";
            this.nud_AngV.ReadOnly = true;
            this.nud_AngV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngV.Size = new System.Drawing.Size(98, 23);
            this.nud_AngV.TabIndex = 31;
            this.nud_AngV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_Vr
            // 
            this.nud_Vr.DecimalPlaces = 4;
            this.nud_Vr.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_Vr.Location = new System.Drawing.Point(68, 59);
            this.nud_Vr.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Vr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Vr.Name = "nud_Vr";
            this.nud_Vr.ReadOnly = true;
            this.nud_Vr.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Vr.Size = new System.Drawing.Size(98, 23);
            this.nud_Vr.TabIndex = 30;
            this.nud_Vr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_Vw
            // 
            this.nud_Vw.DecimalPlaces = 4;
            this.nud_Vw.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_Vw.Location = new System.Drawing.Point(68, 31);
            this.nud_Vw.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Vw.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Vw.Name = "nud_Vw";
            this.nud_Vw.ReadOnly = true;
            this.nud_Vw.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Vw.Size = new System.Drawing.Size(98, 23);
            this.nud_Vw.TabIndex = 29;
            this.nud_Vw.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_Vh
            // 
            this.nud_Vh.DecimalPlaces = 4;
            this.nud_Vh.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_Vh.Location = new System.Drawing.Point(68, 3);
            this.nud_Vh.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Vh.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Vh.Name = "nud_Vh";
            this.nud_Vh.ReadOnly = true;
            this.nud_Vh.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Vh.Size = new System.Drawing.Size(98, 23);
            this.nud_Vh.TabIndex = 28;
            this.nud_Vh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Location = new System.Drawing.Point(3, 0);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(23, 16);
            this.label194.TabIndex = 17;
            this.label194.Text = "Vh";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Location = new System.Drawing.Point(3, 28);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(25, 16);
            this.label195.TabIndex = 18;
            this.label195.Text = "Vw";
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Location = new System.Drawing.Point(3, 56);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(20, 16);
            this.label196.TabIndex = 19;
            this.label196.Text = "Vr";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Location = new System.Drawing.Point(3, 84);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(39, 16);
            this.label197.TabIndex = 20;
            this.label197.Text = "AngV";
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Location = new System.Drawing.Point(3, 112);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(22, 16);
            this.label198.TabIndex = 21;
            this.label198.Text = "P1";
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Location = new System.Drawing.Point(3, 140);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(22, 16);
            this.label199.TabIndex = 22;
            this.label199.Text = "P2";
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Location = new System.Drawing.Point(3, 168);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(31, 16);
            this.label200.TabIndex = 23;
            this.label200.Text = "VR1";
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Location = new System.Drawing.Point(3, 196);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(31, 16);
            this.label201.TabIndex = 24;
            this.label201.Text = "VR2";
            // 
            // nud_Vr2
            // 
            this.nud_Vr2.DecimalPlaces = 4;
            this.nud_Vr2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            262144});
            this.nud_Vr2.Location = new System.Drawing.Point(68, 199);
            this.nud_Vr2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Vr2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Vr2.Name = "nud_Vr2";
            this.nud_Vr2.ReadOnly = true;
            this.nud_Vr2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Vr2.Size = new System.Drawing.Size(98, 23);
            this.nud_Vr2.TabIndex = 35;
            this.nud_Vr2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.91813F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.08187F));
            this.tableLayoutPanel28.Controls.Add(this.nud_C2, 1, 11);
            this.tableLayoutPanel28.Controls.Add(this.nud_C1, 1, 10);
            this.tableLayoutPanel28.Controls.Add(this.nud_BC, 1, 9);
            this.tableLayoutPanel28.Controls.Add(this.nud_Ang2, 1, 8);
            this.tableLayoutPanel28.Controls.Add(this.nud_Ang1, 1, 7);
            this.tableLayoutPanel28.Controls.Add(this.nud_t, 1, 6);
            this.tableLayoutPanel28.Controls.Add(this.nud_R2, 1, 5);
            this.tableLayoutPanel28.Controls.Add(this.nud_R1, 1, 4);
            this.tableLayoutPanel28.Controls.Add(this.nud_B2, 1, 3);
            this.tableLayoutPanel28.Controls.Add(this.nud_B1, 1, 2);
            this.tableLayoutPanel28.Controls.Add(this.nud_A2, 1, 1);
            this.tableLayoutPanel28.Controls.Add(this.nud_A1, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label181, 0, 2);
            this.tableLayoutPanel28.Controls.Add(this.label180, 0, 1);
            this.tableLayoutPanel28.Controls.Add(this.label179, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.label182, 0, 3);
            this.tableLayoutPanel28.Controls.Add(this.label183, 0, 4);
            this.tableLayoutPanel28.Controls.Add(this.label184, 0, 5);
            this.tableLayoutPanel28.Controls.Add(this.label185, 0, 6);
            this.tableLayoutPanel28.Controls.Add(this.label186, 0, 7);
            this.tableLayoutPanel28.Controls.Add(this.label187, 0, 8);
            this.tableLayoutPanel28.Controls.Add(this.label188, 0, 9);
            this.tableLayoutPanel28.Controls.Add(this.label189, 0, 10);
            this.tableLayoutPanel28.Controls.Add(this.label190, 0, 11);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(739, 44);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 12;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(171, 336);
            this.tableLayoutPanel28.TabIndex = 13;
            // 
            // nud_C2
            // 
            this.nud_C2.DecimalPlaces = 2;
            this.nud_C2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_C2.Location = new System.Drawing.Point(61, 311);
            this.nud_C2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_C2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_C2.Name = "nud_C2";
            this.nud_C2.ReadOnly = true;
            this.nud_C2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C2.Size = new System.Drawing.Size(107, 23);
            this.nud_C2.TabIndex = 36;
            this.nud_C2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_C1
            // 
            this.nud_C1.DecimalPlaces = 2;
            this.nud_C1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_C1.Location = new System.Drawing.Point(61, 283);
            this.nud_C1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_C1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_C1.Name = "nud_C1";
            this.nud_C1.ReadOnly = true;
            this.nud_C1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C1.Size = new System.Drawing.Size(107, 23);
            this.nud_C1.TabIndex = 35;
            this.nud_C1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_BC
            // 
            this.nud_BC.DecimalPlaces = 2;
            this.nud_BC.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_BC.Location = new System.Drawing.Point(61, 255);
            this.nud_BC.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_BC.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_BC.Name = "nud_BC";
            this.nud_BC.ReadOnly = true;
            this.nud_BC.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BC.Size = new System.Drawing.Size(107, 23);
            this.nud_BC.TabIndex = 34;
            this.nud_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_Ang2
            // 
            this.nud_Ang2.DecimalPlaces = 2;
            this.nud_Ang2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_Ang2.Location = new System.Drawing.Point(61, 227);
            this.nud_Ang2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Ang2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Ang2.Name = "nud_Ang2";
            this.nud_Ang2.ReadOnly = true;
            this.nud_Ang2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang2.Size = new System.Drawing.Size(107, 23);
            this.nud_Ang2.TabIndex = 33;
            this.nud_Ang2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_Ang1
            // 
            this.nud_Ang1.DecimalPlaces = 2;
            this.nud_Ang1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_Ang1.Location = new System.Drawing.Point(61, 199);
            this.nud_Ang1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_Ang1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Ang1.Name = "nud_Ang1";
            this.nud_Ang1.ReadOnly = true;
            this.nud_Ang1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang1.Size = new System.Drawing.Size(107, 23);
            this.nud_Ang1.TabIndex = 32;
            this.nud_Ang1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_t
            // 
            this.nud_t.DecimalPlaces = 2;
            this.nud_t.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_t.Location = new System.Drawing.Point(61, 171);
            this.nud_t.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_t.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_t.Name = "nud_t";
            this.nud_t.ReadOnly = true;
            this.nud_t.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_t.Size = new System.Drawing.Size(107, 23);
            this.nud_t.TabIndex = 31;
            this.nud_t.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_R2
            // 
            this.nud_R2.DecimalPlaces = 2;
            this.nud_R2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_R2.Location = new System.Drawing.Point(61, 143);
            this.nud_R2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_R2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_R2.Name = "nud_R2";
            this.nud_R2.ReadOnly = true;
            this.nud_R2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R2.Size = new System.Drawing.Size(107, 23);
            this.nud_R2.TabIndex = 30;
            this.nud_R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_R1
            // 
            this.nud_R1.DecimalPlaces = 2;
            this.nud_R1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_R1.Location = new System.Drawing.Point(61, 115);
            this.nud_R1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_R1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_R1.Name = "nud_R1";
            this.nud_R1.ReadOnly = true;
            this.nud_R1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R1.Size = new System.Drawing.Size(107, 23);
            this.nud_R1.TabIndex = 29;
            this.nud_R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_B2
            // 
            this.nud_B2.DecimalPlaces = 2;
            this.nud_B2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_B2.Location = new System.Drawing.Point(61, 87);
            this.nud_B2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_B2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_B2.Name = "nud_B2";
            this.nud_B2.ReadOnly = true;
            this.nud_B2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B2.Size = new System.Drawing.Size(107, 23);
            this.nud_B2.TabIndex = 28;
            this.nud_B2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_B1
            // 
            this.nud_B1.DecimalPlaces = 2;
            this.nud_B1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_B1.Location = new System.Drawing.Point(61, 59);
            this.nud_B1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_B1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_B1.Name = "nud_B1";
            this.nud_B1.ReadOnly = true;
            this.nud_B1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B1.Size = new System.Drawing.Size(107, 23);
            this.nud_B1.TabIndex = 27;
            this.nud_B1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_A2
            // 
            this.nud_A2.DecimalPlaces = 2;
            this.nud_A2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_A2.Location = new System.Drawing.Point(61, 31);
            this.nud_A2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_A2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_A2.Name = "nud_A2";
            this.nud_A2.ReadOnly = true;
            this.nud_A2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A2.Size = new System.Drawing.Size(107, 23);
            this.nud_A2.TabIndex = 26;
            this.nud_A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_A1
            // 
            this.nud_A1.DecimalPlaces = 2;
            this.nud_A1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_A1.Location = new System.Drawing.Point(61, 3);
            this.nud_A1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_A1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_A1.Name = "nud_A1";
            this.nud_A1.ReadOnly = true;
            this.nud_A1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A1.Size = new System.Drawing.Size(107, 23);
            this.nud_A1.TabIndex = 14;
            this.nud_A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(3, 56);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(22, 16);
            this.label181.TabIndex = 16;
            this.label181.Text = "B1";
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Location = new System.Drawing.Point(3, 28);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(23, 16);
            this.label180.TabIndex = 15;
            this.label180.Text = "A2";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Location = new System.Drawing.Point(3, 0);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(23, 16);
            this.label179.TabIndex = 14;
            this.label179.Text = "A1";
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Location = new System.Drawing.Point(3, 84);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(22, 16);
            this.label182.TabIndex = 17;
            this.label182.Text = "B2";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(3, 112);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(23, 16);
            this.label183.TabIndex = 18;
            this.label183.Text = "R1";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(3, 140);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(23, 16);
            this.label184.TabIndex = 19;
            this.label184.Text = "R2";
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(3, 168);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(12, 16);
            this.label185.TabIndex = 20;
            this.label185.Text = "t";
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Location = new System.Drawing.Point(3, 196);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(38, 16);
            this.label186.TabIndex = 21;
            this.label186.Text = "Ang1";
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Location = new System.Drawing.Point(3, 224);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(38, 16);
            this.label187.TabIndex = 22;
            this.label187.Text = "Ang2";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Location = new System.Drawing.Point(3, 252);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(23, 16);
            this.label188.TabIndex = 23;
            this.label188.Text = "BC";
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Location = new System.Drawing.Point(3, 280);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(23, 16);
            this.label189.TabIndex = 24;
            this.label189.Text = "C1";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Location = new System.Drawing.Point(3, 308);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(23, 16);
            this.label190.TabIndex = 25;
            this.label190.Text = "C2";
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label178.Location = new System.Drawing.Point(741, 12);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(156, 20);
            this.label178.TabIndex = 12;
            this.label178.Text = "Edge Measurement";
            // 
            // hControl_EdgeMeasurement
            // 
            this.hControl_EdgeMeasurement.BackColor = System.Drawing.Color.Black;
            this.hControl_EdgeMeasurement.FontSizeThreshold = 8;
            this.hControl_EdgeMeasurement.ImageBuffer.Columns = 1;
            this.hControl_EdgeMeasurement.ImageBuffer.Height = 480;
            this.hControl_EdgeMeasurement.ImageBuffer.Heights = 480;
            this.hControl_EdgeMeasurement.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj1")));
            this.hControl_EdgeMeasurement.ImageBuffer.RawImage = null;
            this.hControl_EdgeMeasurement.ImageBuffer.Rows = 1;
            this.hControl_EdgeMeasurement.ImageBuffer.Width = 640;
            this.hControl_EdgeMeasurement.ImageBuffer.Widths = 640;
            this.hControl_EdgeMeasurement.IsDispCenterCross = false;
            this.hControl_EdgeMeasurement.IsDispHObject = true;
            this.hControl_EdgeMeasurement.IsDispROIFrameFontInfo = true;
            this.hControl_EdgeMeasurement.IsLockGetMposition = false;
            this.hControl_EdgeMeasurement.IsLockMouseOperation = false;
            this.hControl_EdgeMeasurement.IsUseMenuByMouseRightButton = true;
            this.hControl_EdgeMeasurement.KeyCtrlPressStatus = false;
            this.hControl_EdgeMeasurement.Location = new System.Drawing.Point(368, 72);
            this.hControl_EdgeMeasurement.Margin = new System.Windows.Forms.Padding(0);
            this.hControl_EdgeMeasurement.MaxZoom = 100F;
            this.hControl_EdgeMeasurement.MinZoom = 0.01F;
            this.hControl_EdgeMeasurement.Name = "hControl_EdgeMeasurement";
            this.hControl_EdgeMeasurement.ROIController.ActiveROIIndex = -1;
            this.hControl_EdgeMeasurement.ROIFontSize = 18;
            this.hControl_EdgeMeasurement.ROIFontSizeThreshold = 10;
            this.hControl_EdgeMeasurement.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hControl_EdgeMeasurement.ScrollBarEnable = false;
            this.hControl_EdgeMeasurement.Size = new System.Drawing.Size(360, 308);
            this.hControl_EdgeMeasurement.TabIndex = 11;
            this.hControl_EdgeMeasurement.Zoom = 0.01F;
            // 
            // nud_edgeAngle
            // 
            this.nud_edgeAngle.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_edgeAngle.Location = new System.Drawing.Point(635, 46);
            this.nud_edgeAngle.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.nud_edgeAngle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_edgeAngle.Name = "nud_edgeAngle";
            this.nud_edgeAngle.ReadOnly = true;
            this.nud_edgeAngle.Size = new System.Drawing.Size(49, 23);
            this.nud_edgeAngle.TabIndex = 10;
            // 
            // btn_edgeNumberNext
            // 
            this.btn_edgeNumberNext.Location = new System.Drawing.Point(445, 46);
            this.btn_edgeNumberNext.Name = "btn_edgeNumberNext";
            this.btn_edgeNumberNext.Size = new System.Drawing.Size(44, 23);
            this.btn_edgeNumberNext.TabIndex = 9;
            this.btn_edgeNumberNext.Text = "Next";
            this.btn_edgeNumberNext.UseVisualStyleBackColor = true;
            this.btn_edgeNumberNext.Click += new System.EventHandler(this.btn_edgeNumberNext_Click);
            // 
            // btn_edgeNumberBack
            // 
            this.btn_edgeNumberBack.Location = new System.Drawing.Point(395, 46);
            this.btn_edgeNumberBack.Name = "btn_edgeNumberBack";
            this.btn_edgeNumberBack.Size = new System.Drawing.Size(44, 23);
            this.btn_edgeNumberBack.TabIndex = 8;
            this.btn_edgeNumberBack.Text = "Back";
            this.btn_edgeNumberBack.UseVisualStyleBackColor = true;
            this.btn_edgeNumberBack.Click += new System.EventHandler(this.btn_edgeNumberBack_Click);
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label177.Location = new System.Drawing.Point(801, 398);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(115, 20);
            this.label177.TabIndex = 7;
            this.label177.Text = "Notch Inspect";
            // 
            // hControl_NotchInspect
            // 
            this.hControl_NotchInspect.BackColor = System.Drawing.Color.Black;
            this.hControl_NotchInspect.FontSizeThreshold = 8;
            this.hControl_NotchInspect.ImageBuffer.Columns = 1;
            this.hControl_NotchInspect.ImageBuffer.Height = 480;
            this.hControl_NotchInspect.ImageBuffer.Heights = 480;
            this.hControl_NotchInspect.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj2")));
            this.hControl_NotchInspect.ImageBuffer.RawImage = null;
            this.hControl_NotchInspect.ImageBuffer.Rows = 1;
            this.hControl_NotchInspect.ImageBuffer.Width = 640;
            this.hControl_NotchInspect.ImageBuffer.Widths = 640;
            this.hControl_NotchInspect.IsDispCenterCross = false;
            this.hControl_NotchInspect.IsDispHObject = true;
            this.hControl_NotchInspect.IsDispROIFrameFontInfo = true;
            this.hControl_NotchInspect.IsLockGetMposition = false;
            this.hControl_NotchInspect.IsLockMouseOperation = false;
            this.hControl_NotchInspect.IsUseMenuByMouseRightButton = true;
            this.hControl_NotchInspect.KeyCtrlPressStatus = false;
            this.hControl_NotchInspect.Location = new System.Drawing.Point(749, 429);
            this.hControl_NotchInspect.Margin = new System.Windows.Forms.Padding(0);
            this.hControl_NotchInspect.MaxZoom = 100F;
            this.hControl_NotchInspect.MinZoom = 0.01F;
            this.hControl_NotchInspect.Name = "hControl_NotchInspect";
            this.hControl_NotchInspect.ROIController.ActiveROIIndex = -1;
            this.hControl_NotchInspect.ROIFontSize = 18;
            this.hControl_NotchInspect.ROIFontSizeThreshold = 10;
            this.hControl_NotchInspect.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hControl_NotchInspect.ScrollBarEnable = false;
            this.hControl_NotchInspect.Size = new System.Drawing.Size(360, 347);
            this.hControl_NotchInspect.TabIndex = 6;
            this.hControl_NotchInspect.Zoom = 0.01F;
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label176.Location = new System.Drawing.Point(385, 395);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(165, 20);
            this.label176.TabIndex = 5;
            this.label176.Text = "Notch Measurement";
            // 
            // hControl_NotchMeasurement
            // 
            this.hControl_NotchMeasurement.BackColor = System.Drawing.Color.Black;
            this.hControl_NotchMeasurement.FontSizeThreshold = 8;
            this.hControl_NotchMeasurement.ImageBuffer.Columns = 1;
            this.hControl_NotchMeasurement.ImageBuffer.Height = 480;
            this.hControl_NotchMeasurement.ImageBuffer.Heights = 480;
            this.hControl_NotchMeasurement.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj3")));
            this.hControl_NotchMeasurement.ImageBuffer.RawImage = null;
            this.hControl_NotchMeasurement.ImageBuffer.Rows = 1;
            this.hControl_NotchMeasurement.ImageBuffer.Width = 640;
            this.hControl_NotchMeasurement.ImageBuffer.Widths = 640;
            this.hControl_NotchMeasurement.IsDispCenterCross = false;
            this.hControl_NotchMeasurement.IsDispHObject = true;
            this.hControl_NotchMeasurement.IsDispROIFrameFontInfo = true;
            this.hControl_NotchMeasurement.IsLockGetMposition = false;
            this.hControl_NotchMeasurement.IsLockMouseOperation = false;
            this.hControl_NotchMeasurement.IsUseMenuByMouseRightButton = true;
            this.hControl_NotchMeasurement.KeyCtrlPressStatus = false;
            this.hControl_NotchMeasurement.Location = new System.Drawing.Point(368, 429);
            this.hControl_NotchMeasurement.Margin = new System.Windows.Forms.Padding(0);
            this.hControl_NotchMeasurement.MaxZoom = 100F;
            this.hControl_NotchMeasurement.MinZoom = 0.01F;
            this.hControl_NotchMeasurement.Name = "hControl_NotchMeasurement";
            this.hControl_NotchMeasurement.ROIController.ActiveROIIndex = -1;
            this.hControl_NotchMeasurement.ROIFontSize = 18;
            this.hControl_NotchMeasurement.ROIFontSizeThreshold = 10;
            this.hControl_NotchMeasurement.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hControl_NotchMeasurement.ScrollBarEnable = false;
            this.hControl_NotchMeasurement.Size = new System.Drawing.Size(360, 347);
            this.hControl_NotchMeasurement.TabIndex = 4;
            this.hControl_NotchMeasurement.Zoom = 0.01F;
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label171.Location = new System.Drawing.Point(17, 16);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(141, 16);
            this.label171.TabIndex = 2;
            this.label171.Text = "Defect Inspection (TOP)";
            // 
            // hControl_linescanBottom
            // 
            this.hControl_linescanBottom.BackColor = System.Drawing.Color.Black;
            this.hControl_linescanBottom.FontSizeThreshold = 8;
            this.hControl_linescanBottom.ImageBuffer.Columns = 1;
            this.hControl_linescanBottom.ImageBuffer.Height = 480;
            this.hControl_linescanBottom.ImageBuffer.Heights = 480;
            this.hControl_linescanBottom.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj4")));
            this.hControl_linescanBottom.ImageBuffer.RawImage = null;
            this.hControl_linescanBottom.ImageBuffer.Rows = 1;
            this.hControl_linescanBottom.ImageBuffer.Width = 640;
            this.hControl_linescanBottom.ImageBuffer.Widths = 640;
            this.hControl_linescanBottom.IsDispCenterCross = false;
            this.hControl_linescanBottom.IsDispHObject = true;
            this.hControl_linescanBottom.IsDispROIFrameFontInfo = true;
            this.hControl_linescanBottom.IsLockGetMposition = false;
            this.hControl_linescanBottom.IsLockMouseOperation = false;
            this.hControl_linescanBottom.IsUseMenuByMouseRightButton = true;
            this.hControl_linescanBottom.KeyCtrlPressStatus = false;
            this.hControl_linescanBottom.Location = new System.Drawing.Point(181, 72);
            this.hControl_linescanBottom.Margin = new System.Windows.Forms.Padding(0);
            this.hControl_linescanBottom.MaxZoom = 100F;
            this.hControl_linescanBottom.MinZoom = 0.01F;
            this.hControl_linescanBottom.Name = "hControl_linescanBottom";
            this.hControl_linescanBottom.ROIController.ActiveROIIndex = -1;
            this.hControl_linescanBottom.ROIFontSize = 18;
            this.hControl_linescanBottom.ROIFontSizeThreshold = 10;
            this.hControl_linescanBottom.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hControl_linescanBottom.ScrollBarEnable = false;
            this.hControl_linescanBottom.Size = new System.Drawing.Size(150, 704);
            this.hControl_linescanBottom.TabIndex = 1;
            this.hControl_linescanBottom.Zoom = 0.01F;
            // 
            // hControl_linescanTop
            // 
            this.hControl_linescanTop.BackColor = System.Drawing.Color.Black;
            this.hControl_linescanTop.FontSizeThreshold = 8;
            this.hControl_linescanTop.ImageBuffer.Columns = 1;
            this.hControl_linescanTop.ImageBuffer.Height = 480;
            this.hControl_linescanTop.ImageBuffer.Heights = 480;
            this.hControl_linescanTop.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj5")));
            this.hControl_linescanTop.ImageBuffer.RawImage = null;
            this.hControl_linescanTop.ImageBuffer.Rows = 1;
            this.hControl_linescanTop.ImageBuffer.Width = 640;
            this.hControl_linescanTop.ImageBuffer.Widths = 640;
            this.hControl_linescanTop.IsDispCenterCross = false;
            this.hControl_linescanTop.IsDispHObject = true;
            this.hControl_linescanTop.IsDispROIFrameFontInfo = true;
            this.hControl_linescanTop.IsLockGetMposition = false;
            this.hControl_linescanTop.IsLockMouseOperation = false;
            this.hControl_linescanTop.IsUseMenuByMouseRightButton = true;
            this.hControl_linescanTop.KeyCtrlPressStatus = false;
            this.hControl_linescanTop.Location = new System.Drawing.Point(8, 72);
            this.hControl_linescanTop.Margin = new System.Windows.Forms.Padding(0);
            this.hControl_linescanTop.MaxZoom = 100F;
            this.hControl_linescanTop.MinZoom = 0.01F;
            this.hControl_linescanTop.Name = "hControl_linescanTop";
            this.hControl_linescanTop.ROIController.ActiveROIIndex = -1;
            this.hControl_linescanTop.ROIFontSize = 18;
            this.hControl_linescanTop.ROIFontSizeThreshold = 10;
            this.hControl_linescanTop.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hControl_linescanTop.ScrollBarEnable = false;
            this.hControl_linescanTop.Size = new System.Drawing.Size(150, 704);
            this.hControl_linescanTop.TabIndex = 0;
            this.hControl_linescanTop.Zoom = 0.01F;
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label192.Location = new System.Drawing.Point(591, 49);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(49, 16);
            this.label192.TabIndex = 34;
            this.label192.Text = "angle : ";
            // 
            // tbp_Notch
            // 
            this.tbp_Notch.Controls.Add(this.tableLayoutPanel5);
            this.tbp_Notch.Location = new System.Drawing.Point(4, 25);
            this.tbp_Notch.Name = "tbp_Notch";
            this.tbp_Notch.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_Notch.Size = new System.Drawing.Size(1137, 789);
            this.tbp_Notch.TabIndex = 1;
            this.tbp_Notch.Text = "Notch";
            this.tbp_Notch.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel5.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1131, 783);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label113);
            this.panel2.Controls.Add(this.nud_NotchLamp);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.txb_NotchImgPath);
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Controls.Add(this.tableLayoutPanel6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(446, 777);
            this.panel2.TabIndex = 2;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(279, 170);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(40, 16);
            this.label113.TabIndex = 10;
            this.label113.Text = "Lamp";
            // 
            // nud_NotchLamp
            // 
            this.nud_NotchLamp.DecimalPlaces = 2;
            this.nud_NotchLamp.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchLamp.Location = new System.Drawing.Point(351, 171);
            this.nud_NotchLamp.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_NotchLamp.Name = "nud_NotchLamp";
            this.nud_NotchLamp.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchLamp.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchLamp.TabIndex = 9;
            this.nud_NotchLamp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchLamp.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(325, 170);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(25, 24);
            this.pictureBox8.TabIndex = 11;
            this.pictureBox8.TabStop = false;
            // 
            // txb_NotchImgPath
            // 
            this.txb_NotchImgPath.Location = new System.Drawing.Point(22, 102);
            this.txb_NotchImgPath.Name = "txb_NotchImgPath";
            this.txb_NotchImgPath.Size = new System.Drawing.Size(408, 23);
            this.txb_NotchImgPath.TabIndex = 8;
            this.txb_NotchImgPath.Text = "C:\\Johnny\\Salmon\\Demo_Data\\notch_area\\crop\\clear\\003_crop.bmp";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.97298F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.02703F));
            this.tableLayoutPanel7.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.nud_NotchGrayMax, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.label51, 1, 9);
            this.tableLayoutPanel7.Controls.Add(this.label54, 1, 8);
            this.tableLayoutPanel7.Controls.Add(this.label55, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.label56, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.nud_b2Ang, 2, 3);
            this.tableLayoutPanel7.Controls.Add(this.label57, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.label58, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.nud_u1Ratio, 2, 4);
            this.tableLayoutPanel7.Controls.Add(this.nud_u2Ratio, 2, 5);
            this.tableLayoutPanel7.Controls.Add(this.nud_VrWidth1, 2, 7);
            this.tableLayoutPanel7.Controls.Add(this.nud_PinRadius, 2, 9);
            this.tableLayoutPanel7.Controls.Add(this.nud_VR12Angle, 2, 10);
            this.tableLayoutPanel7.Controls.Add(this.nud_b1Ang, 2, 2);
            this.tableLayoutPanel7.Controls.Add(this.nud_VrWidth2, 2, 8);
            this.tableLayoutPanel7.Controls.Add(this.label53, 1, 7);
            this.tableLayoutPanel7.Controls.Add(this.label52, 1, 10);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox1, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox4, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox6, 0, 7);
            this.tableLayoutPanel7.Controls.Add(this.label112, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.nud_NotchRotate, 2, 1);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(22, 202);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(30);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 12;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(397, 549);
            this.tableLayoutPanel7.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(141, 3);
            this.label50.Margin = new System.Windows.Forms.Padding(3);
            this.label50.Name = "label50";
            this.label50.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label50.Size = new System.Drawing.Size(181, 16);
            this.label50.TabIndex = 1;
            this.label50.Text = "最大灰階值 GrayMax (Auto : -1)";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_NotchGrayMax
            // 
            this.nud_NotchGrayMax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchGrayMax.Location = new System.Drawing.Point(329, 3);
            this.nud_NotchGrayMax.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_NotchGrayMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_NotchGrayMax.Name = "nud_NotchGrayMax";
            this.nud_NotchGrayMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchGrayMax.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchGrayMax.TabIndex = 0;
            this.nud_NotchGrayMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchGrayMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(141, 300);
            this.label51.Margin = new System.Windows.Forms.Padding(3);
            this.label51.Name = "label51";
            this.label51.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label51.Size = new System.Drawing.Size(106, 16);
            this.label51.TabIndex = 1;
            this.label51.Text = "鑲嵌Pin半徑 [mm]";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(141, 267);
            this.label54.Margin = new System.Windows.Forms.Padding(3);
            this.label54.Name = "label54";
            this.label54.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label54.Size = new System.Drawing.Size(165, 16);
            this.label54.TabIndex = 1;
            this.label54.Text = "槽口底半徑計算寬度(右) [um]";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(141, 69);
            this.label55.Margin = new System.Windows.Forms.Padding(3);
            this.label55.Name = "label55";
            this.label55.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label55.Size = new System.Drawing.Size(162, 16);
            this.label55.TabIndex = 1;
            this.label55.Text = "槽口起點 切線角度(左) [Deg]";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(141, 102);
            this.label56.Margin = new System.Windows.Forms.Padding(3);
            this.label56.Name = "label56";
            this.label56.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label56.Size = new System.Drawing.Size(162, 16);
            this.label56.TabIndex = 1;
            this.label56.Text = "槽口起點 切線角度(右) [Deg]";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_b2Ang
            // 
            this.nud_b2Ang.DecimalPlaces = 2;
            this.nud_b2Ang.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_b2Ang.Location = new System.Drawing.Point(329, 102);
            this.nud_b2Ang.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_b2Ang.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_b2Ang.Name = "nud_b2Ang";
            this.nud_b2Ang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_b2Ang.Size = new System.Drawing.Size(64, 23);
            this.nud_b2Ang.TabIndex = 0;
            this.nud_b2Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_b2Ang.Value = new decimal(new int[] {
            21,
            0,
            0,
            -2147483648});
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(141, 168);
            this.label57.Margin = new System.Windows.Forms.Padding(3);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(115, 16);
            this.label57.TabIndex = 1;
            this.label57.Text = "角度終點比率 h2:Vh";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(141, 135);
            this.label58.Margin = new System.Windows.Forms.Padding(3);
            this.label58.Name = "label58";
            this.label58.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label58.Size = new System.Drawing.Size(115, 16);
            this.label58.TabIndex = 1;
            this.label58.Text = "角度起點比率 h1:Vh";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_u1Ratio
            // 
            this.nud_u1Ratio.DecimalPlaces = 2;
            this.nud_u1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u1Ratio.Location = new System.Drawing.Point(329, 135);
            this.nud_u1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_u1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u1Ratio.Name = "nud_u1Ratio";
            this.nud_u1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_u1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_u1Ratio.TabIndex = 0;
            this.nud_u1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_u1Ratio.Value = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            // 
            // nud_u2Ratio
            // 
            this.nud_u2Ratio.DecimalPlaces = 2;
            this.nud_u2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u2Ratio.Location = new System.Drawing.Point(329, 168);
            this.nud_u2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_u2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u2Ratio.Name = "nud_u2Ratio";
            this.nud_u2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_u2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_u2Ratio.TabIndex = 0;
            this.nud_u2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_u2Ratio.Value = new decimal(new int[] {
            7,
            0,
            0,
            65536});
            // 
            // nud_VrWidth1
            // 
            this.nud_VrWidth1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth1.Location = new System.Drawing.Point(329, 234);
            this.nud_VrWidth1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_VrWidth1.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_VrWidth1.Name = "nud_VrWidth1";
            this.nud_VrWidth1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrWidth1.Size = new System.Drawing.Size(64, 23);
            this.nud_VrWidth1.TabIndex = 0;
            this.nud_VrWidth1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrWidth1.Value = new decimal(new int[] {
            600,
            0,
            0,
            0});
            // 
            // nud_PinRadius
            // 
            this.nud_PinRadius.DecimalPlaces = 1;
            this.nud_PinRadius.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_PinRadius.Location = new System.Drawing.Point(329, 300);
            this.nud_PinRadius.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_PinRadius.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_PinRadius.Name = "nud_PinRadius";
            this.nud_PinRadius.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_PinRadius.Size = new System.Drawing.Size(64, 23);
            this.nud_PinRadius.TabIndex = 0;
            this.nud_PinRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_PinRadius.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            // 
            // nud_VR12Angle
            // 
            this.nud_VR12Angle.DecimalPlaces = 2;
            this.nud_VR12Angle.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_VR12Angle.Location = new System.Drawing.Point(329, 333);
            this.nud_VR12Angle.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_VR12Angle.Name = "nud_VR12Angle";
            this.nud_VR12Angle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR12Angle.Size = new System.Drawing.Size(64, 23);
            this.nud_VR12Angle.TabIndex = 0;
            this.nud_VR12Angle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR12Angle.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // nud_b1Ang
            // 
            this.nud_b1Ang.DecimalPlaces = 2;
            this.nud_b1Ang.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_b1Ang.Location = new System.Drawing.Point(329, 69);
            this.nud_b1Ang.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_b1Ang.Name = "nud_b1Ang";
            this.nud_b1Ang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_b1Ang.Size = new System.Drawing.Size(64, 23);
            this.nud_b1Ang.TabIndex = 0;
            this.nud_b1Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_b1Ang.Value = new decimal(new int[] {
            21,
            0,
            0,
            0});
            // 
            // nud_VrWidth2
            // 
            this.nud_VrWidth2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth2.Location = new System.Drawing.Point(329, 267);
            this.nud_VrWidth2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_VrWidth2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth2.Name = "nud_VrWidth2";
            this.nud_VrWidth2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrWidth2.Size = new System.Drawing.Size(64, 23);
            this.nud_VrWidth2.TabIndex = 0;
            this.nud_VrWidth2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrWidth2.Value = new decimal(new int[] {
            600,
            0,
            0,
            0});
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(141, 234);
            this.label53.Margin = new System.Windows.Forms.Padding(3);
            this.label53.Name = "label53";
            this.label53.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label53.Size = new System.Drawing.Size(165, 16);
            this.label53.TabIndex = 1;
            this.label53.Text = "槽口底半徑計算寬度(左) [um]";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(141, 333);
            this.label52.Margin = new System.Windows.Forms.Padding(3);
            this.label52.Name = "label52";
            this.label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label52.Size = new System.Drawing.Size(115, 16);
            this.label52.TabIndex = 1;
            this.label52.Text = "槽口肩排除角 [Deg]";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, 69);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(132, 60);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(3, 135);
            this.pictureBox4.Name = "pictureBox4";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox4, 2);
            this.pictureBox4.Size = new System.Drawing.Size(132, 60);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(3, 234);
            this.pictureBox6.Name = "pictureBox6";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox6, 2);
            this.pictureBox6.Size = new System.Drawing.Size(132, 60);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(141, 36);
            this.label112.Margin = new System.Windows.Forms.Padding(3);
            this.label112.Name = "label112";
            this.label112.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label112.Size = new System.Drawing.Size(56, 16);
            this.label112.TabIndex = 4;
            this.label112.Text = "旋轉角度";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_NotchRotate
            // 
            this.nud_NotchRotate.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchRotate.Location = new System.Drawing.Point(329, 36);
            this.nud_NotchRotate.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.nud_NotchRotate.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.nud_NotchRotate.Name = "nud_NotchRotate";
            this.nud_NotchRotate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchRotate.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchRotate.TabIndex = 5;
            this.nud_NotchRotate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchRotate.Value = new decimal(new int[] {
            180,
            0,
            0,
            0});
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 6;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.Controls.Add(this.btn_SaveRecipe_Notch, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.label48, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label49, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_MasureTest_Notch, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.label47, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_LoadImage_Notch, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.label46, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_LoadRecipe_Notch, 0, 1);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // btn_SaveRecipe_Notch
            // 
            this.btn_SaveRecipe_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_SaveRecipe_Notch.BackgroundImage")));
            this.btn_SaveRecipe_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_SaveRecipe_Notch.Location = new System.Drawing.Point(174, 22);
            this.btn_SaveRecipe_Notch.Name = "btn_SaveRecipe_Notch";
            this.btn_SaveRecipe_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_SaveRecipe_Notch.TabIndex = 2;
            this.btn_SaveRecipe_Notch.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label48.Location = new System.Drawing.Point(174, 3);
            this.label48.Margin = new System.Windows.Forms.Padding(3);
            this.label48.Name = "label48";
            this.label48.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label48.Size = new System.Drawing.Size(51, 13);
            this.label48.TabIndex = 1;
            this.label48.Text = "儲存參數";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label49.Location = new System.Drawing.Point(231, 3);
            this.label49.Margin = new System.Windows.Forms.Padding(3);
            this.label49.Name = "label49";
            this.label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label49.Size = new System.Drawing.Size(51, 13);
            this.label49.TabIndex = 1;
            this.label49.Text = "量測計算";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_MasureTest_Notch
            // 
            this.btn_MasureTest_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_MasureTest_Notch.BackgroundImage")));
            this.btn_MasureTest_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_MasureTest_Notch.Location = new System.Drawing.Point(231, 22);
            this.btn_MasureTest_Notch.Name = "btn_MasureTest_Notch";
            this.btn_MasureTest_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_MasureTest_Notch.TabIndex = 5;
            this.btn_MasureTest_Notch.UseVisualStyleBackColor = true;
            this.btn_MasureTest_Notch.Click += new System.EventHandler(this.btn_MasureTest_Notch_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label47.Location = new System.Drawing.Point(3, 3);
            this.label47.Margin = new System.Windows.Forms.Padding(3);
            this.label47.Name = "label47";
            this.label47.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label47.Size = new System.Drawing.Size(51, 13);
            this.label47.TabIndex = 1;
            this.label47.Text = "載入參數";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadImage_Notch
            // 
            this.btn_LoadImage_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Notch.BackgroundImage")));
            this.btn_LoadImage_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Notch.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadImage_Notch.Name = "btn_LoadImage_Notch";
            this.btn_LoadImage_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Notch.TabIndex = 2;
            this.btn_LoadImage_Notch.UseVisualStyleBackColor = true;
            this.btn_LoadImage_Notch.Click += new System.EventHandler(this.btn_LoadImage_Notch_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label46.Location = new System.Drawing.Point(60, 3);
            this.label46.Margin = new System.Windows.Forms.Padding(3);
            this.label46.Name = "label46";
            this.label46.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label46.Size = new System.Drawing.Size(51, 13);
            this.label46.TabIndex = 1;
            this.label46.Text = "開啟圖片";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadRecipe_Notch
            // 
            this.btn_LoadRecipe_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadRecipe_Notch.Location = new System.Drawing.Point(3, 22);
            this.btn_LoadRecipe_Notch.Name = "btn_LoadRecipe_Notch";
            this.btn_LoadRecipe_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadRecipe_Notch.TabIndex = 5;
            this.btn_LoadRecipe_Notch.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.20035F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.799648F));
            this.tableLayoutPanel8.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.hctrl_NotchView, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(455, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 4;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.250597F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.7494F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 317F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(673, 777);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Margin = new System.Windows.Forms.Padding(3);
            this.label60.Name = "label60";
            this.label60.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label60.Size = new System.Drawing.Size(627, 16);
            this.label60.TabIndex = 1;
            this.label60.Text = "影像視窗";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 10;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.463196F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.31059F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.84919F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.181329F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.02873F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.38779F));
            this.tableLayoutPanel9.Controls.Add(this.label61, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.label62, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.label63, 5, 2);
            this.tableLayoutPanel9.Controls.Add(this.label64, 5, 3);
            this.tableLayoutPanel9.Controls.Add(this.label65, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.label66, 0, 5);
            this.tableLayoutPanel9.Controls.Add(this.label67, 0, 7);
            this.tableLayoutPanel9.Controls.Add(this.label69, 0, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_VhUpper, 3, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vh, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vw, 1, 3);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vr, 1, 4);
            this.tableLayoutPanel9.Controls.Add(this.txb_AngV, 1, 5);
            this.tableLayoutPanel9.Controls.Add(this.txb_P1, 1, 6);
            this.tableLayoutPanel9.Controls.Add(this.txb_P2, 1, 7);
            this.tableLayoutPanel9.Controls.Add(this.txb_VR1, 6, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_VR2, 6, 3);
            this.tableLayoutPanel9.Controls.Add(this.label76, 7, 3);
            this.tableLayoutPanel9.Controls.Add(this.label77, 7, 2);
            this.tableLayoutPanel9.Controls.Add(this.label78, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label79, 2, 2);
            this.tableLayoutPanel9.Controls.Add(this.label80, 2, 3);
            this.tableLayoutPanel9.Controls.Add(this.label81, 2, 4);
            this.tableLayoutPanel9.Controls.Add(this.label82, 2, 5);
            this.tableLayoutPanel9.Controls.Add(this.label83, 2, 6);
            this.tableLayoutPanel9.Controls.Add(this.label84, 2, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_VhLower, 4, 2);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR1Upper, 8, 2);
            this.tableLayoutPanel9.Controls.Add(this.label86, 3, 1);
            this.tableLayoutPanel9.Controls.Add(this.label87, 4, 1);
            this.tableLayoutPanel9.Controls.Add(this.label88, 5, 1);
            this.tableLayoutPanel9.Controls.Add(this.label89, 8, 1);
            this.tableLayoutPanel9.Controls.Add(this.label90, 9, 1);
            this.tableLayoutPanel9.Controls.Add(this.nud_VwUpper, 3, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VwLower, 4, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VrUpper, 3, 4);
            this.tableLayoutPanel9.Controls.Add(this.nud_VrLower, 4, 4);
            this.tableLayoutPanel9.Controls.Add(this.nud_AngVUpper, 3, 5);
            this.tableLayoutPanel9.Controls.Add(this.nud_P1Upper, 3, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_P1Lower, 4, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_P2Upper, 3, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_P2Lower, 4, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_AngVLower, 4, 5);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR1Lower, 9, 2);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR2Upper, 8, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR2Lower, 9, 3);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 429);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 9;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.366812F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.46725F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(627, 311);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(3, 67);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(55, 34);
            this.label61.TabIndex = 0;
            this.label61.Text = "Vh";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(3, 101);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(55, 34);
            this.label62.TabIndex = 0;
            this.label62.Text = "Vw";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(308, 67);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(55, 34);
            this.label63.TabIndex = 0;
            this.label63.Text = "VR1";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(308, 101);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(55, 34);
            this.label64.TabIndex = 0;
            this.label64.Text = "VR2";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 135);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(55, 34);
            this.label65.TabIndex = 0;
            this.label65.Text = "Vr";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(3, 169);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(55, 34);
            this.label66.TabIndex = 0;
            this.label66.Text = "AngV";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(3, 237);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(55, 34);
            this.label67.TabIndex = 0;
            this.label67.Text = "P2";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(3, 203);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(55, 34);
            this.label69.TabIndex = 0;
            this.label69.Text = "P1";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_VhUpper
            // 
            this.nud_VhUpper.DecimalPlaces = 3;
            this.nud_VhUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VhUpper.Location = new System.Drawing.Point(165, 70);
            this.nud_VhUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VhUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VhUpper.Name = "nud_VhUpper";
            this.nud_VhUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VhUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VhUpper.TabIndex = 0;
            this.nud_VhUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VhUpper.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            // 
            // txb_Vh
            // 
            this.txb_Vh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vh.Location = new System.Drawing.Point(64, 70);
            this.txb_Vh.Name = "txb_Vh";
            this.txb_Vh.ReadOnly = true;
            this.txb_Vh.Size = new System.Drawing.Size(55, 23);
            this.txb_Vh.TabIndex = 1;
            this.txb_Vh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Vw
            // 
            this.txb_Vw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vw.Location = new System.Drawing.Point(64, 104);
            this.txb_Vw.Name = "txb_Vw";
            this.txb_Vw.ReadOnly = true;
            this.txb_Vw.Size = new System.Drawing.Size(55, 23);
            this.txb_Vw.TabIndex = 1;
            this.txb_Vw.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Vr
            // 
            this.txb_Vr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vr.Location = new System.Drawing.Point(64, 138);
            this.txb_Vr.Name = "txb_Vr";
            this.txb_Vr.ReadOnly = true;
            this.txb_Vr.Size = new System.Drawing.Size(55, 23);
            this.txb_Vr.TabIndex = 1;
            this.txb_Vr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_AngV
            // 
            this.txb_AngV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_AngV.Location = new System.Drawing.Point(64, 172);
            this.txb_AngV.Name = "txb_AngV";
            this.txb_AngV.ReadOnly = true;
            this.txb_AngV.Size = new System.Drawing.Size(55, 23);
            this.txb_AngV.TabIndex = 1;
            this.txb_AngV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_P1
            // 
            this.txb_P1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_P1.Location = new System.Drawing.Point(64, 206);
            this.txb_P1.Name = "txb_P1";
            this.txb_P1.ReadOnly = true;
            this.txb_P1.Size = new System.Drawing.Size(55, 23);
            this.txb_P1.TabIndex = 1;
            this.txb_P1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_P2
            // 
            this.txb_P2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_P2.Location = new System.Drawing.Point(64, 240);
            this.txb_P2.Name = "txb_P2";
            this.txb_P2.ReadOnly = true;
            this.txb_P2.Size = new System.Drawing.Size(55, 23);
            this.txb_P2.TabIndex = 1;
            this.txb_P2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_VR1
            // 
            this.txb_VR1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_VR1.Location = new System.Drawing.Point(369, 70);
            this.txb_VR1.Name = "txb_VR1";
            this.txb_VR1.ReadOnly = true;
            this.txb_VR1.Size = new System.Drawing.Size(55, 23);
            this.txb_VR1.TabIndex = 1;
            this.txb_VR1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_VR2
            // 
            this.txb_VR2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_VR2.Location = new System.Drawing.Point(369, 104);
            this.txb_VR2.Name = "txb_VR2";
            this.txb_VR2.ReadOnly = true;
            this.txb_VR2.Size = new System.Drawing.Size(55, 23);
            this.txb_VR2.TabIndex = 1;
            this.txb_VR2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(430, 101);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(30, 16);
            this.label76.TabIndex = 0;
            this.label76.Text = "mm";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(430, 67);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(30, 16);
            this.label77.TabIndex = 0;
            this.label77.Text = "mm";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.tableLayoutPanel9.SetColumnSpan(this.label78, 2);
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(3, 13);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(116, 54);
            this.label78.TabIndex = 0;
            this.label78.Text = "量測結果\r\nMesureResult";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(125, 67);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(30, 16);
            this.label79.TabIndex = 0;
            this.label79.Text = "mm";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(125, 101);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(30, 16);
            this.label80.TabIndex = 0;
            this.label80.Text = "mm";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(125, 135);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(30, 16);
            this.label81.TabIndex = 0;
            this.label81.Text = "mm";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(125, 169);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(31, 16);
            this.label82.TabIndex = 0;
            this.label82.Text = "deg";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(125, 203);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(30, 16);
            this.label83.TabIndex = 0;
            this.label83.Text = "mm";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(125, 237);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(30, 16);
            this.label84.TabIndex = 0;
            this.label84.Text = "mm";
            // 
            // nud_VhLower
            // 
            this.nud_VhLower.DecimalPlaces = 3;
            this.nud_VhLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VhLower.Location = new System.Drawing.Point(235, 70);
            this.nud_VhLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VhLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VhLower.Name = "nud_VhLower";
            this.nud_VhLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VhLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VhLower.TabIndex = 0;
            this.nud_VhLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VhLower.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_VR1Upper
            // 
            this.nud_VR1Upper.DecimalPlaces = 3;
            this.nud_VR1Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR1Upper.Location = new System.Drawing.Point(474, 70);
            this.nud_VR1Upper.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR1Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR1Upper.Name = "nud_VR1Upper";
            this.nud_VR1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR1Upper.Size = new System.Drawing.Size(66, 23);
            this.nud_VR1Upper.TabIndex = 0;
            this.nud_VR1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR1Upper.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(165, 13);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(64, 54);
            this.label86.TabIndex = 0;
            this.label86.Text = "上限值\r\nUpper";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(235, 13);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(67, 54);
            this.label87.TabIndex = 0;
            this.label87.Text = "下限值\r\nLower";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.tableLayoutPanel9.SetColumnSpan(this.label88, 2);
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(308, 13);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(116, 54);
            this.label88.TabIndex = 0;
            this.label88.Text = "量測結果\r\nMesureResult";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(474, 13);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(68, 54);
            this.label89.TabIndex = 0;
            this.label89.Text = "上限值\r\nUpper";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(548, 13);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(76, 54);
            this.label90.TabIndex = 0;
            this.label90.Text = "下限值\r\nLower";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_VwUpper
            // 
            this.nud_VwUpper.DecimalPlaces = 3;
            this.nud_VwUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_VwUpper.Location = new System.Drawing.Point(165, 104);
            this.nud_VwUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VwUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VwUpper.Name = "nud_VwUpper";
            this.nud_VwUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VwUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VwUpper.TabIndex = 0;
            this.nud_VwUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VwUpper.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_VwLower
            // 
            this.nud_VwLower.DecimalPlaces = 3;
            this.nud_VwLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VwLower.Location = new System.Drawing.Point(235, 104);
            this.nud_VwLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VwLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VwLower.Name = "nud_VwLower";
            this.nud_VwLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VwLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VwLower.TabIndex = 0;
            this.nud_VwLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VwLower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_VrUpper
            // 
            this.nud_VrUpper.DecimalPlaces = 3;
            this.nud_VrUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VrUpper.Location = new System.Drawing.Point(165, 138);
            this.nud_VrUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VrUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VrUpper.Name = "nud_VrUpper";
            this.nud_VrUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VrUpper.TabIndex = 0;
            this.nud_VrUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrUpper.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_VrLower
            // 
            this.nud_VrLower.DecimalPlaces = 3;
            this.nud_VrLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VrLower.Location = new System.Drawing.Point(235, 138);
            this.nud_VrLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VrLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VrLower.Name = "nud_VrLower";
            this.nud_VrLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VrLower.TabIndex = 0;
            this.nud_VrLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrLower.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_AngVUpper
            // 
            this.nud_AngVUpper.DecimalPlaces = 1;
            this.nud_AngVUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_AngVUpper.Location = new System.Drawing.Point(165, 172);
            this.nud_AngVUpper.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nud_AngVUpper.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_AngVUpper.Name = "nud_AngVUpper";
            this.nud_AngVUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngVUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_AngVUpper.TabIndex = 0;
            this.nud_AngVUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngVUpper.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // nud_P1Upper
            // 
            this.nud_P1Upper.DecimalPlaces = 3;
            this.nud_P1Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P1Upper.Location = new System.Drawing.Point(165, 206);
            this.nud_P1Upper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P1Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P1Upper.Name = "nud_P1Upper";
            this.nud_P1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P1Upper.Size = new System.Drawing.Size(62, 23);
            this.nud_P1Upper.TabIndex = 0;
            this.nud_P1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P1Upper.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // nud_P1Lower
            // 
            this.nud_P1Lower.DecimalPlaces = 3;
            this.nud_P1Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P1Lower.Location = new System.Drawing.Point(235, 206);
            this.nud_P1Lower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P1Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P1Lower.Name = "nud_P1Lower";
            this.nud_P1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P1Lower.Size = new System.Drawing.Size(65, 23);
            this.nud_P1Lower.TabIndex = 0;
            this.nud_P1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P1Lower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_P2Upper
            // 
            this.nud_P2Upper.DecimalPlaces = 3;
            this.nud_P2Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P2Upper.Location = new System.Drawing.Point(165, 240);
            this.nud_P2Upper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P2Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P2Upper.Name = "nud_P2Upper";
            this.nud_P2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P2Upper.Size = new System.Drawing.Size(62, 23);
            this.nud_P2Upper.TabIndex = 0;
            this.nud_P2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P2Upper.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // nud_P2Lower
            // 
            this.nud_P2Lower.DecimalPlaces = 3;
            this.nud_P2Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P2Lower.Location = new System.Drawing.Point(235, 240);
            this.nud_P2Lower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P2Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P2Lower.Name = "nud_P2Lower";
            this.nud_P2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P2Lower.Size = new System.Drawing.Size(65, 23);
            this.nud_P2Lower.TabIndex = 0;
            this.nud_P2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P2Lower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_AngVLower
            // 
            this.nud_AngVLower.DecimalPlaces = 1;
            this.nud_AngVLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_AngVLower.Location = new System.Drawing.Point(235, 172);
            this.nud_AngVLower.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nud_AngVLower.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_AngVLower.Name = "nud_AngVLower";
            this.nud_AngVLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngVLower.Size = new System.Drawing.Size(65, 23);
            this.nud_AngVLower.TabIndex = 0;
            this.nud_AngVLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngVLower.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // nud_VR1Lower
            // 
            this.nud_VR1Lower.DecimalPlaces = 3;
            this.nud_VR1Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR1Lower.Location = new System.Drawing.Point(548, 70);
            this.nud_VR1Lower.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR1Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR1Lower.Name = "nud_VR1Lower";
            this.nud_VR1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR1Lower.Size = new System.Drawing.Size(66, 23);
            this.nud_VR1Lower.TabIndex = 0;
            this.nud_VR1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR1Lower.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // nud_VR2Upper
            // 
            this.nud_VR2Upper.DecimalPlaces = 3;
            this.nud_VR2Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR2Upper.Location = new System.Drawing.Point(474, 104);
            this.nud_VR2Upper.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR2Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR2Upper.Name = "nud_VR2Upper";
            this.nud_VR2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR2Upper.Size = new System.Drawing.Size(66, 23);
            this.nud_VR2Upper.TabIndex = 0;
            this.nud_VR2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR2Upper.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_VR2Lower
            // 
            this.nud_VR2Lower.DecimalPlaces = 3;
            this.nud_VR2Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR2Lower.Location = new System.Drawing.Point(548, 104);
            this.nud_VR2Lower.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR2Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR2Lower.Name = "nud_VR2Lower";
            this.nud_VR2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR2Lower.Size = new System.Drawing.Size(66, 23);
            this.nud_VR2Lower.TabIndex = 0;
            this.nud_VR2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR2Lower.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // hctrl_NotchView
            // 
            this.hctrl_NotchView.AllowDrop = true;
            this.hctrl_NotchView.BackColor = System.Drawing.Color.Black;
            this.hctrl_NotchView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hctrl_NotchView.FontSizeThreshold = 8;
            this.hctrl_NotchView.ImageBuffer.Columns = 1;
            this.hctrl_NotchView.ImageBuffer.Height = 480;
            this.hctrl_NotchView.ImageBuffer.Heights = 480;
            this.hctrl_NotchView.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj6")));
            this.hctrl_NotchView.ImageBuffer.RawImage = null;
            this.hctrl_NotchView.ImageBuffer.Rows = 1;
            this.hctrl_NotchView.ImageBuffer.Width = 640;
            this.hctrl_NotchView.ImageBuffer.Widths = 640;
            this.hctrl_NotchView.IsDispCenterCross = false;
            this.hctrl_NotchView.IsDispHObject = true;
            this.hctrl_NotchView.IsDispROIFrameFontInfo = true;
            this.hctrl_NotchView.IsLockGetMposition = false;
            this.hctrl_NotchView.IsLockMouseOperation = false;
            this.hctrl_NotchView.IsUseMenuByMouseRightButton = true;
            this.hctrl_NotchView.KeyCtrlPressStatus = false;
            this.hctrl_NotchView.Location = new System.Drawing.Point(0, 22);
            this.hctrl_NotchView.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_NotchView.MaxZoom = 100F;
            this.hctrl_NotchView.MinZoom = 0.01F;
            this.hctrl_NotchView.Name = "hctrl_NotchView";
            this.hctrl_NotchView.ROIController.ActiveROIIndex = -1;
            this.hctrl_NotchView.ROIFontSize = 18;
            this.hctrl_NotchView.ROIFontSizeThreshold = 10;
            this.hctrl_NotchView.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_NotchView.ScrollBarEnable = false;
            this.hctrl_NotchView.Size = new System.Drawing.Size(633, 404);
            this.hctrl_NotchView.TabIndex = 4;
            this.hctrl_NotchView.Zoom = 0.01F;
            // 
            // tbp_Defect_1
            // 
            this.tbp_Defect_1.Controls.Add(this.tableLayoutPanel10);
            this.tbp_Defect_1.Location = new System.Drawing.Point(4, 25);
            this.tbp_Defect_1.Name = "tbp_Defect_1";
            this.tbp_Defect_1.Size = new System.Drawing.Size(1137, 789);
            this.tbp_Defect_1.TabIndex = 2;
            this.tbp_Defect_1.Text = "Defect_1";
            this.tbp_Defect_1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel10.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.tableLayoutPanel13, 1, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(1137, 789);
            this.tableLayoutPanel10.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel27);
            this.panel3.Controls.Add(this.label145);
            this.panel3.Controls.Add(this.label114);
            this.panel3.Controls.Add(this.nud_DefectLamp_1);
            this.panel3.Controls.Add(this.pictureBox9);
            this.panel3.Controls.Add(this.lab_dispNumber_1);
            this.panel3.Controls.Add(this.hctrl_RawImage_1);
            this.panel3.Controls.Add(this.txb_model_1);
            this.panel3.Controls.Add(this.txb_ImageRaw_1);
            this.panel3.Controls.Add(this.tableLayoutPanel11);
            this.panel3.Controls.Add(this.tableLayoutPanel12);
            this.panel3.Controls.Add(this.btn_CropInspectionImg_1);
            this.panel3.Controls.Add(this.btn_TestCropNotch_1);
            this.panel3.Controls.Add(this.nud_SelectCropImg_1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(449, 783);
            this.panel3.TabIndex = 2;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.1749F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.8251F));
            this.tableLayoutPanel27.Controls.Add(this.nud_shiftAngle, 1, 3);
            this.tableLayoutPanel27.Controls.Add(this.label169, 0, 3);
            this.tableLayoutPanel27.Controls.Add(this.label167, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.nud_notchPosition, 1, 5);
            this.tableLayoutPanel27.Controls.Add(this.nud_totalAreaNum, 1, 1);
            this.tableLayoutPanel27.Controls.Add(this.label162, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.label164, 0, 5);
            this.tableLayoutPanel27.Controls.Add(this.label165, 0, 6);
            this.tableLayoutPanel27.Controls.Add(this.label163, 0, 4);
            this.tableLayoutPanel27.Controls.Add(this.label166, 0, 2);
            this.tableLayoutPanel27.Controls.Add(this.nud_catchAreaNum, 1, 2);
            this.tableLayoutPanel27.Controls.Add(this.textBox_catchImage, 1, 6);
            this.tableLayoutPanel27.Location = new System.Drawing.Point(116, 181);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 7;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.82311F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.81952F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.82364F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.81953F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.81953F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.81952F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.07515F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(263, 215);
            this.tableLayoutPanel27.TabIndex = 16;
            // 
            // nud_shiftAngle
            // 
            this.nud_shiftAngle.Location = new System.Drawing.Point(155, 84);
            this.nud_shiftAngle.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.nud_shiftAngle.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.nud_shiftAngle.Name = "nud_shiftAngle";
            this.nud_shiftAngle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_shiftAngle.Size = new System.Drawing.Size(64, 23);
            this.nud_shiftAngle.TabIndex = 19;
            this.nud_shiftAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_shiftAngle.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Location = new System.Drawing.Point(3, 81);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(129, 16);
            this.label169.TabIndex = 20;
            this.label169.Text = "First Shift Angle [Deg]";
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Location = new System.Drawing.Point(3, 27);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(116, 16);
            this.label167.TabIndex = 20;
            this.label167.Text = "Total Area Number";
            // 
            // nud_notchPosition
            // 
            this.nud_notchPosition.Location = new System.Drawing.Point(155, 138);
            this.nud_notchPosition.Maximum = new decimal(new int[] {
            250000,
            0,
            0,
            0});
            this.nud_notchPosition.Name = "nud_notchPosition";
            this.nud_notchPosition.ReadOnly = true;
            this.nud_notchPosition.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_notchPosition.Size = new System.Drawing.Size(80, 23);
            this.nud_notchPosition.TabIndex = 23;
            this.nud_notchPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_totalAreaNum
            // 
            this.nud_totalAreaNum.Location = new System.Drawing.Point(155, 30);
            this.nud_totalAreaNum.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.nud_totalAreaNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_totalAreaNum.Name = "nud_totalAreaNum";
            this.nud_totalAreaNum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_totalAreaNum.Size = new System.Drawing.Size(64, 23);
            this.nud_totalAreaNum.TabIndex = 17;
            this.nud_totalAreaNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_totalAreaNum.Value = new decimal(new int[] {
            72,
            0,
            0,
            0});
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(3, 0);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(110, 16);
            this.label162.TabIndex = 17;
            this.label162.Text = "挑選edge檢測圖片";
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Location = new System.Drawing.Point(3, 135);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(91, 16);
            this.label164.TabIndex = 19;
            this.label164.Text = "Notch Position";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Location = new System.Drawing.Point(3, 162);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(126, 16);
            this.label165.TabIndex = 20;
            this.label165.Text = "Catch image number";
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Location = new System.Drawing.Point(3, 108);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(48, 16);
            this.label163.TabIndex = 18;
            this.label163.Text = "Output";
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Location = new System.Drawing.Point(3, 54);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(119, 16);
            this.label166.TabIndex = 19;
            this.label166.Text = "Catch Area Number";
            // 
            // nud_catchAreaNum
            // 
            this.nud_catchAreaNum.Location = new System.Drawing.Point(155, 57);
            this.nud_catchAreaNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_catchAreaNum.Name = "nud_catchAreaNum";
            this.nud_catchAreaNum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_catchAreaNum.Size = new System.Drawing.Size(64, 23);
            this.nud_catchAreaNum.TabIndex = 18;
            this.nud_catchAreaNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_catchAreaNum.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // textBox_catchImage
            // 
            this.textBox_catchImage.Location = new System.Drawing.Point(155, 165);
            this.textBox_catchImage.Multiline = true;
            this.textBox_catchImage.Name = "textBox_catchImage";
            this.textBox_catchImage.ReadOnly = true;
            this.textBox_catchImage.Size = new System.Drawing.Size(105, 47);
            this.textBox_catchImage.TabIndex = 24;
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label145.Location = new System.Drawing.Point(368, 24);
            this.label145.Margin = new System.Windows.Forms.Padding(3);
            this.label145.Name = "label145";
            this.label145.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label145.Size = new System.Drawing.Size(73, 36);
            this.label145.TabIndex = 15;
            this.label145.Text = "正面";
            this.label145.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(184, 405);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(40, 16);
            this.label114.TabIndex = 13;
            this.label114.Text = "Lamp";
            // 
            // nud_DefectLamp_1
            // 
            this.nud_DefectLamp_1.DecimalPlaces = 2;
            this.nud_DefectLamp_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DefectLamp_1.Location = new System.Drawing.Point(256, 403);
            this.nud_DefectLamp_1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_DefectLamp_1.Name = "nud_DefectLamp_1";
            this.nud_DefectLamp_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DefectLamp_1.Size = new System.Drawing.Size(64, 23);
            this.nud_DefectLamp_1.TabIndex = 12;
            this.nud_DefectLamp_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DefectLamp_1.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(230, 402);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 24);
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            // 
            // lab_dispNumber_1
            // 
            this.lab_dispNumber_1.AutoSize = true;
            this.lab_dispNumber_1.Location = new System.Drawing.Point(119, 671);
            this.lab_dispNumber_1.Name = "lab_dispNumber_1";
            this.lab_dispNumber_1.Size = new System.Drawing.Size(80, 16);
            this.lab_dispNumber_1.TabIndex = 0;
            this.lab_dispNumber_1.Text = "全部共有    張";
            // 
            // hctrl_RawImage_1
            // 
            this.hctrl_RawImage_1.AllowDrop = true;
            this.hctrl_RawImage_1.BackColor = System.Drawing.Color.Black;
            this.hctrl_RawImage_1.FontSizeThreshold = 8;
            this.hctrl_RawImage_1.ImageBuffer.Columns = 1;
            this.hctrl_RawImage_1.ImageBuffer.Height = 480;
            this.hctrl_RawImage_1.ImageBuffer.Heights = 480;
            this.hctrl_RawImage_1.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj7")));
            this.hctrl_RawImage_1.ImageBuffer.RawImage = null;
            this.hctrl_RawImage_1.ImageBuffer.Rows = 1;
            this.hctrl_RawImage_1.ImageBuffer.Width = 640;
            this.hctrl_RawImage_1.ImageBuffer.Widths = 640;
            this.hctrl_RawImage_1.IsDispCenterCross = false;
            this.hctrl_RawImage_1.IsDispHObject = true;
            this.hctrl_RawImage_1.IsDispROIFrameFontInfo = true;
            this.hctrl_RawImage_1.IsLockGetMposition = false;
            this.hctrl_RawImage_1.IsLockMouseOperation = false;
            this.hctrl_RawImage_1.IsUseMenuByMouseRightButton = true;
            this.hctrl_RawImage_1.KeyCtrlPressStatus = false;
            this.hctrl_RawImage_1.Location = new System.Drawing.Point(19, 97);
            this.hctrl_RawImage_1.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_RawImage_1.MaxZoom = 100F;
            this.hctrl_RawImage_1.MinZoom = 0.01F;
            this.hctrl_RawImage_1.Name = "hctrl_RawImage_1";
            this.hctrl_RawImage_1.ROIController.ActiveROIIndex = -1;
            this.hctrl_RawImage_1.ROIFontSize = 18;
            this.hctrl_RawImage_1.ROIFontSizeThreshold = 10;
            this.hctrl_RawImage_1.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_RawImage_1.ScrollBarEnable = false;
            this.hctrl_RawImage_1.Size = new System.Drawing.Size(69, 669);
            this.hctrl_RawImage_1.TabIndex = 11;
            this.hctrl_RawImage_1.Zoom = 0.01F;
            // 
            // txb_model_1
            // 
            this.txb_model_1.Location = new System.Drawing.Point(100, 139);
            this.txb_model_1.Name = "txb_model_1";
            this.txb_model_1.Size = new System.Drawing.Size(279, 23);
            this.txb_model_1.TabIndex = 10;
            this.txb_model_1.Text = "C:\\Johnny\\Salmon\\Demo_Data\\linescan\\NotchModel_0307.shm";
            // 
            // txb_ImageRaw_1
            // 
            this.txb_ImageRaw_1.Location = new System.Drawing.Point(100, 110);
            this.txb_ImageRaw_1.Name = "txb_ImageRaw_1";
            this.txb_ImageRaw_1.Size = new System.Drawing.Size(279, 23);
            this.txb_ImageRaw_1.TabIndex = 9;
            this.txb_ImageRaw_1.Text = "C:\\Johnny\\Salmon\\Demo_Data\\linescan\\image\\back_Tileimage.bmp";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.1749F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.8251F));
            this.tableLayoutPanel11.Controls.Add(this.label59, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.label68, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.label70, 0, 2);
            this.tableLayoutPanel11.Controls.Add(this.label71, 0, 3);
            this.tableLayoutPanel11.Controls.Add(this.nud_PixelSize_1, 1, 3);
            this.tableLayoutPanel11.Controls.Add(this.label72, 0, 4);
            this.tableLayoutPanel11.Controls.Add(this.nud_InDistance_1, 1, 2);
            this.tableLayoutPanel11.Controls.Add(this.nud_CropSize_1, 1, 4);
            this.tableLayoutPanel11.Controls.Add(this.nud_CropNotchWidth_1, 1, 1);
            this.tableLayoutPanel11.Controls.Add(this.nud_MinScore_1, 1, 5);
            this.tableLayoutPanel11.Controls.Add(this.label73, 0, 5);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(116, 441);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 6;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(263, 173);
            this.tableLayoutPanel11.TabIndex = 7;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.tableLayoutPanel11.SetColumnSpan(this.label59, 2);
            this.label59.Location = new System.Drawing.Point(3, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(81, 16);
            this.label59.TabIndex = 0;
            this.label59.Text = "NotchModel";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(3, 27);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(105, 16);
            this.label68.TabIndex = 0;
            this.label68.Text = "CropNotchWidth";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(3, 54);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(96, 16);
            this.label70.TabIndex = 0;
            this.label70.Text = "InDistance[mm]";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(3, 81);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(83, 16);
            this.label71.TabIndex = 0;
            this.label71.Text = "PixelSize[um]";
            // 
            // nud_PixelSize_1
            // 
            this.nud_PixelSize_1.DecimalPlaces = 2;
            this.nud_PixelSize_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_PixelSize_1.Location = new System.Drawing.Point(155, 84);
            this.nud_PixelSize_1.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.nud_PixelSize_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_PixelSize_1.Name = "nud_PixelSize_1";
            this.nud_PixelSize_1.ReadOnly = true;
            this.nud_PixelSize_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_PixelSize_1.Size = new System.Drawing.Size(64, 23);
            this.nud_PixelSize_1.TabIndex = 0;
            this.nud_PixelSize_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_PixelSize_1.Value = new decimal(new int[] {
            704,
            0,
            0,
            131072});
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(3, 108);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(94, 16);
            this.label72.TabIndex = 0;
            this.label72.Text = "CropSize[pixel]";
            // 
            // nud_InDistance_1
            // 
            this.nud_InDistance_1.DecimalPlaces = 1;
            this.nud_InDistance_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_InDistance_1.Location = new System.Drawing.Point(155, 57);
            this.nud_InDistance_1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_InDistance_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_InDistance_1.Name = "nud_InDistance_1";
            this.nud_InDistance_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InDistance_1.Size = new System.Drawing.Size(64, 23);
            this.nud_InDistance_1.TabIndex = 0;
            this.nud_InDistance_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InDistance_1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // nud_CropSize_1
            // 
            this.nud_CropSize_1.Location = new System.Drawing.Point(155, 111);
            this.nud_CropSize_1.Maximum = new decimal(new int[] {
            800,
            0,
            0,
            0});
            this.nud_CropSize_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_CropSize_1.Name = "nud_CropSize_1";
            this.nud_CropSize_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_CropSize_1.Size = new System.Drawing.Size(64, 23);
            this.nud_CropSize_1.TabIndex = 0;
            this.nud_CropSize_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_CropSize_1.Value = new decimal(new int[] {
            760,
            0,
            0,
            0});
            // 
            // nud_CropNotchWidth_1
            // 
            this.nud_CropNotchWidth_1.Location = new System.Drawing.Point(155, 30);
            this.nud_CropNotchWidth_1.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_CropNotchWidth_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_CropNotchWidth_1.Name = "nud_CropNotchWidth_1";
            this.nud_CropNotchWidth_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_CropNotchWidth_1.Size = new System.Drawing.Size(64, 23);
            this.nud_CropNotchWidth_1.TabIndex = 0;
            this.nud_CropNotchWidth_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_CropNotchWidth_1.Value = new decimal(new int[] {
            700,
            0,
            0,
            0});
            // 
            // nud_MinScore_1
            // 
            this.nud_MinScore_1.DecimalPlaces = 2;
            this.nud_MinScore_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MinScore_1.Location = new System.Drawing.Point(155, 138);
            this.nud_MinScore_1.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            this.nud_MinScore_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_MinScore_1.Name = "nud_MinScore_1";
            this.nud_MinScore_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinScore_1.Size = new System.Drawing.Size(64, 23);
            this.nud_MinScore_1.TabIndex = 0;
            this.nud_MinScore_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinScore_1.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(3, 135);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(62, 16);
            this.label73.TabIndex = 0;
            this.label73.Text = "MinScore";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 6;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.Controls.Add(this.button2, 3, 1);
            this.tableLayoutPanel12.Controls.Add(this.label92, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.label93, 3, 0);
            this.tableLayoutPanel12.Controls.Add(this.btn_loadModel_1, 2, 1);
            this.tableLayoutPanel12.Controls.Add(this.btn_LoadImage_Defect_1, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.label91, 1, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel12.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tableLayoutPanel12.SetColumnSpan(this.button2, 2);
            this.button2.Location = new System.Drawing.Point(174, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(51, 43);
            this.button2.TabIndex = 2;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label92.Location = new System.Drawing.Point(117, 3);
            this.label92.Margin = new System.Windows.Forms.Padding(3);
            this.label92.Name = "label92";
            this.label92.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label92.Size = new System.Drawing.Size(41, 13);
            this.label92.TabIndex = 1;
            this.label92.Text = "Model";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label93.Location = new System.Drawing.Point(174, 3);
            this.label93.Margin = new System.Windows.Forms.Padding(3);
            this.label93.Name = "label93";
            this.label93.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label93.Size = new System.Drawing.Size(51, 13);
            this.label93.TabIndex = 1;
            this.label93.Text = "儲存參數";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_loadModel_1
            // 
            this.btn_loadModel_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_loadModel_1.BackgroundImage")));
            this.btn_loadModel_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_loadModel_1.Location = new System.Drawing.Point(117, 22);
            this.btn_loadModel_1.Name = "btn_loadModel_1";
            this.btn_loadModel_1.Size = new System.Drawing.Size(51, 43);
            this.btn_loadModel_1.TabIndex = 5;
            this.btn_loadModel_1.UseVisualStyleBackColor = true;
            this.btn_loadModel_1.Click += new System.EventHandler(this.btn_loadModel_1_Click);
            // 
            // btn_LoadImage_Defect_1
            // 
            this.btn_LoadImage_Defect_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Defect_1.BackgroundImage")));
            this.btn_LoadImage_Defect_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Defect_1.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadImage_Defect_1.Name = "btn_LoadImage_Defect_1";
            this.btn_LoadImage_Defect_1.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Defect_1.TabIndex = 2;
            this.btn_LoadImage_Defect_1.UseVisualStyleBackColor = true;
            this.btn_LoadImage_Defect_1.Click += new System.EventHandler(this.btn_LoadImage_Defect_Click);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label91.Location = new System.Drawing.Point(60, 3);
            this.label91.Margin = new System.Windows.Forms.Padding(3);
            this.label91.Name = "label91";
            this.label91.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label91.Size = new System.Drawing.Size(51, 13);
            this.label91.TabIndex = 1;
            this.label91.Text = "開啟圖片";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_CropInspectionImg_1
            // 
            this.btn_CropInspectionImg_1.BackColor = System.Drawing.Color.Khaki;
            this.btn_CropInspectionImg_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_CropInspectionImg_1.Location = new System.Drawing.Point(116, 702);
            this.btn_CropInspectionImg_1.Name = "btn_CropInspectionImg_1";
            this.btn_CropInspectionImg_1.Size = new System.Drawing.Size(263, 48);
            this.btn_CropInspectionImg_1.TabIndex = 5;
            this.btn_CropInspectionImg_1.Text = "TEST\r\nCropDomainImage\r\n";
            this.btn_CropInspectionImg_1.UseVisualStyleBackColor = false;
            this.btn_CropInspectionImg_1.Click += new System.EventHandler(this.btn_CropInspectionImg_Click);
            // 
            // btn_TestCropNotch_1
            // 
            this.btn_TestCropNotch_1.BackColor = System.Drawing.Color.Khaki;
            this.btn_TestCropNotch_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestCropNotch_1.Location = new System.Drawing.Point(116, 620);
            this.btn_TestCropNotch_1.Name = "btn_TestCropNotch_1";
            this.btn_TestCropNotch_1.Size = new System.Drawing.Size(263, 48);
            this.btn_TestCropNotch_1.TabIndex = 5;
            this.btn_TestCropNotch_1.Text = "TEST\r\nCalculateEdgePntAndCropNotch\r\n";
            this.btn_TestCropNotch_1.UseVisualStyleBackColor = false;
            this.btn_TestCropNotch_1.Click += new System.EventHandler(this.btn_TestCropNotch_Click);
            // 
            // nud_SelectCropImg_1
            // 
            this.nud_SelectCropImg_1.Location = new System.Drawing.Point(244, 671);
            this.nud_SelectCropImg_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_SelectCropImg_1.Name = "nud_SelectCropImg_1";
            this.nud_SelectCropImg_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_SelectCropImg_1.Size = new System.Drawing.Size(46, 23);
            this.nud_SelectCropImg_1.TabIndex = 0;
            this.nud_SelectCropImg_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_SelectCropImg_1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.96375F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.03625F));
            this.tableLayoutPanel13.Controls.Add(this.hctrl_DefectImg_1, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label95, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.label146, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel14, 1, 3);
            this.tableLayoutPanel13.Controls.Add(this.pictureBox7, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.btn_TestNotchDefect_1, 1, 4);
            this.tableLayoutPanel13.Controls.Add(this.hctrl_NotchImg_1, 1, 1);
            this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel24, 0, 3);
            this.tableLayoutPanel13.Controls.Add(this.btn_TestDefect_1, 0, 4);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(458, 3);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 6;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.17662F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.11436F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.65057F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.13088F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.734435F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.717916F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(676, 783);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // hctrl_DefectImg_1
            // 
            this.hctrl_DefectImg_1.AllowDrop = true;
            this.hctrl_DefectImg_1.BackColor = System.Drawing.Color.Black;
            this.hctrl_DefectImg_1.FontSizeThreshold = 8;
            this.hctrl_DefectImg_1.ImageBuffer.Columns = 1;
            this.hctrl_DefectImg_1.ImageBuffer.Height = 480;
            this.hctrl_DefectImg_1.ImageBuffer.Heights = 480;
            this.hctrl_DefectImg_1.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj8")));
            this.hctrl_DefectImg_1.ImageBuffer.RawImage = null;
            this.hctrl_DefectImg_1.ImageBuffer.Rows = 1;
            this.hctrl_DefectImg_1.ImageBuffer.Width = 640;
            this.hctrl_DefectImg_1.ImageBuffer.Widths = 640;
            this.hctrl_DefectImg_1.IsDispCenterCross = false;
            this.hctrl_DefectImg_1.IsDispHObject = true;
            this.hctrl_DefectImg_1.IsDispROIFrameFontInfo = true;
            this.hctrl_DefectImg_1.IsLockGetMposition = false;
            this.hctrl_DefectImg_1.IsLockMouseOperation = false;
            this.hctrl_DefectImg_1.IsUseMenuByMouseRightButton = true;
            this.hctrl_DefectImg_1.KeyCtrlPressStatus = false;
            this.hctrl_DefectImg_1.Location = new System.Drawing.Point(0, 24);
            this.hctrl_DefectImg_1.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_DefectImg_1.MaxZoom = 100F;
            this.hctrl_DefectImg_1.MinZoom = 0.01F;
            this.hctrl_DefectImg_1.Name = "hctrl_DefectImg_1";
            this.hctrl_DefectImg_1.ROIController.ActiveROIIndex = -1;
            this.hctrl_DefectImg_1.ROIFontSize = 18;
            this.hctrl_DefectImg_1.ROIFontSizeThreshold = 10;
            this.hctrl_DefectImg_1.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_DefectImg_1.ScrollBarEnable = false;
            this.hctrl_DefectImg_1.Size = new System.Drawing.Size(339, 232);
            this.hctrl_DefectImg_1.TabIndex = 13;
            this.hctrl_DefectImg_1.Zoom = 0.01F;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label95.Location = new System.Drawing.Point(3, 5);
            this.label95.Margin = new System.Windows.Forms.Padding(3);
            this.label95.Name = "label95";
            this.label95.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label95.Size = new System.Drawing.Size(345, 16);
            this.label95.TabIndex = 1;
            this.label95.Text = "缺陷小圖";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label146.Location = new System.Drawing.Point(354, 3);
            this.label146.Margin = new System.Windows.Forms.Padding(3);
            this.label146.Name = "label146";
            this.label146.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label146.Size = new System.Drawing.Size(61, 15);
            this.label146.TabIndex = 1;
            this.label146.Text = "Notch視窗";
            this.label146.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.72789F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.27211F));
            this.tableLayoutPanel14.Controls.Add(this.label96, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.label97, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.label98, 0, 3);
            this.tableLayoutPanel14.Controls.Add(this.label99, 0, 4);
            this.tableLayoutPanel14.Controls.Add(this.label100, 0, 5);
            this.tableLayoutPanel14.Controls.Add(this.label101, 0, 6);
            this.tableLayoutPanel14.Controls.Add(this.label102, 0, 7);
            this.tableLayoutPanel14.Controls.Add(this.label103, 0, 8);
            this.tableLayoutPanel14.Controls.Add(this.nud_BackWhiteMinGray_1, 1, 1);
            this.tableLayoutPanel14.Controls.Add(this.nud_DisplayDilation_1, 1, 2);
            this.tableLayoutPanel14.Controls.Add(this.nud_innerDefectMaxGray_Notch_1, 1, 3);
            this.tableLayoutPanel14.Controls.Add(this.nud_NotchVwRow1_1, 1, 4);
            this.tableLayoutPanel14.Controls.Add(this.nud_NotchVwRow2_1, 1, 5);
            this.tableLayoutPanel14.Controls.Add(this.nud_NotchBlackWidth_1, 1, 6);
            this.tableLayoutPanel14.Controls.Add(this.label85, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.nud_InnerDefectMinWidth_1, 1, 7);
            this.tableLayoutPanel14.Controls.Add(this.nud_OutDefectMinWidth_1, 1, 8);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(354, 449);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 9;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(312, 234);
            this.tableLayoutPanel14.TabIndex = 2;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(3, 23);
            this.label96.Margin = new System.Windows.Forms.Padding(3);
            this.label96.Name = "label96";
            this.label96.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label96.Size = new System.Drawing.Size(115, 16);
            this.label96.TabIndex = 1;
            this.label96.Text = "BackWhiteMinGray";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(3, 49);
            this.label97.Margin = new System.Windows.Forms.Padding(3);
            this.label97.Name = "label97";
            this.label97.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label97.Size = new System.Drawing.Size(93, 16);
            this.label97.TabIndex = 1;
            this.label97.Text = "DisplayDilation";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(3, 75);
            this.label98.Margin = new System.Windows.Forms.Padding(3);
            this.label98.Name = "label98";
            this.label98.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label98.Size = new System.Drawing.Size(124, 16);
            this.label98.TabIndex = 1;
            this.label98.Text = "innerDefectMaxGray";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(3, 101);
            this.label99.Margin = new System.Windows.Forms.Padding(3);
            this.label99.Name = "label99";
            this.label99.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label99.Size = new System.Drawing.Size(92, 16);
            this.label99.TabIndex = 1;
            this.label99.Text = "NotchVwRow1";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(3, 127);
            this.label100.Margin = new System.Windows.Forms.Padding(3);
            this.label100.Name = "label100";
            this.label100.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label100.Size = new System.Drawing.Size(92, 16);
            this.label100.TabIndex = 1;
            this.label100.Text = "NotchVwRow2";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(3, 153);
            this.label101.Margin = new System.Windows.Forms.Padding(3);
            this.label101.Name = "label101";
            this.label101.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label101.Size = new System.Drawing.Size(106, 16);
            this.label101.TabIndex = 1;
            this.label101.Text = "NotchBlackWidth";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(3, 179);
            this.label102.Margin = new System.Windows.Forms.Padding(3);
            this.label102.Name = "label102";
            this.label102.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label102.Size = new System.Drawing.Size(129, 16);
            this.label102.TabIndex = 1;
            this.label102.Text = "InnerDefectMinWidth";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(3, 205);
            this.label103.Margin = new System.Windows.Forms.Padding(3);
            this.label103.Name = "label103";
            this.label103.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label103.Size = new System.Drawing.Size(122, 16);
            this.label103.TabIndex = 1;
            this.label103.Text = "OutDefectMinWidth";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_BackWhiteMinGray_1
            // 
            this.nud_BackWhiteMinGray_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BackWhiteMinGray_1.Location = new System.Drawing.Point(220, 23);
            this.nud_BackWhiteMinGray_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_BackWhiteMinGray_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_BackWhiteMinGray_1.Name = "nud_BackWhiteMinGray_1";
            this.nud_BackWhiteMinGray_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BackWhiteMinGray_1.Size = new System.Drawing.Size(64, 23);
            this.nud_BackWhiteMinGray_1.TabIndex = 0;
            this.nud_BackWhiteMinGray_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BackWhiteMinGray_1.Value = new decimal(new int[] {
            223,
            0,
            0,
            0});
            // 
            // nud_DisplayDilation_1
            // 
            this.nud_DisplayDilation_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DisplayDilation_1.Location = new System.Drawing.Point(220, 49);
            this.nud_DisplayDilation_1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_DisplayDilation_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DisplayDilation_1.Name = "nud_DisplayDilation_1";
            this.nud_DisplayDilation_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DisplayDilation_1.Size = new System.Drawing.Size(64, 23);
            this.nud_DisplayDilation_1.TabIndex = 0;
            this.nud_DisplayDilation_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DisplayDilation_1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // nud_innerDefectMaxGray_Notch_1
            // 
            this.nud_innerDefectMaxGray_Notch_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_innerDefectMaxGray_Notch_1.Location = new System.Drawing.Point(220, 75);
            this.nud_innerDefectMaxGray_Notch_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_Notch_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_Notch_1.Name = "nud_innerDefectMaxGray_Notch_1";
            this.nud_innerDefectMaxGray_Notch_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_innerDefectMaxGray_Notch_1.Size = new System.Drawing.Size(64, 23);
            this.nud_innerDefectMaxGray_Notch_1.TabIndex = 0;
            this.nud_innerDefectMaxGray_Notch_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_innerDefectMaxGray_Notch_1.Value = new decimal(new int[] {
            79,
            0,
            0,
            0});
            // 
            // nud_NotchVwRow1_1
            // 
            this.nud_NotchVwRow1_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchVwRow1_1.Location = new System.Drawing.Point(220, 101);
            this.nud_NotchVwRow1_1.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_NotchVwRow1_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchVwRow1_1.Name = "nud_NotchVwRow1_1";
            this.nud_NotchVwRow1_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchVwRow1_1.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchVwRow1_1.TabIndex = 0;
            this.nud_NotchVwRow1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchVwRow1_1.Value = new decimal(new int[] {
            148,
            0,
            0,
            0});
            // 
            // nud_NotchVwRow2_1
            // 
            this.nud_NotchVwRow2_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchVwRow2_1.Location = new System.Drawing.Point(220, 127);
            this.nud_NotchVwRow2_1.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_NotchVwRow2_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchVwRow2_1.Name = "nud_NotchVwRow2_1";
            this.nud_NotchVwRow2_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchVwRow2_1.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchVwRow2_1.TabIndex = 0;
            this.nud_NotchVwRow2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchVwRow2_1.Value = new decimal(new int[] {
            546,
            0,
            0,
            0});
            // 
            // nud_NotchBlackWidth_1
            // 
            this.nud_NotchBlackWidth_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchBlackWidth_1.Location = new System.Drawing.Point(220, 153);
            this.nud_NotchBlackWidth_1.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_NotchBlackWidth_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchBlackWidth_1.Name = "nud_NotchBlackWidth_1";
            this.nud_NotchBlackWidth_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchBlackWidth_1.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchBlackWidth_1.TabIndex = 0;
            this.nud_NotchBlackWidth_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchBlackWidth_1.Value = new decimal(new int[] {
            71,
            0,
            0,
            0});
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(3, 3);
            this.label85.Margin = new System.Windows.Forms.Padding(3);
            this.label85.Name = "label85";
            this.label85.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label85.Size = new System.Drawing.Size(91, 14);
            this.label85.TabIndex = 1;
            this.label85.Text = "Notch缺陷參數";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_InnerDefectMinWidth_1
            // 
            this.nud_InnerDefectMinWidth_1.DecimalPlaces = 1;
            this.nud_InnerDefectMinWidth_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InnerDefectMinWidth_1.Location = new System.Drawing.Point(220, 179);
            this.nud_InnerDefectMinWidth_1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_InnerDefectMinWidth_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_InnerDefectMinWidth_1.Name = "nud_InnerDefectMinWidth_1";
            this.nud_InnerDefectMinWidth_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerDefectMinWidth_1.Size = new System.Drawing.Size(64, 23);
            this.nud_InnerDefectMinWidth_1.TabIndex = 0;
            this.nud_InnerDefectMinWidth_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InnerDefectMinWidth_1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_OutDefectMinWidth_1
            // 
            this.nud_OutDefectMinWidth_1.DecimalPlaces = 1;
            this.nud_OutDefectMinWidth_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_OutDefectMinWidth_1.Location = new System.Drawing.Point(220, 205);
            this.nud_OutDefectMinWidth_1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_OutDefectMinWidth_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_OutDefectMinWidth_1.Name = "nud_OutDefectMinWidth_1";
            this.nud_OutDefectMinWidth_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_OutDefectMinWidth_1.Size = new System.Drawing.Size(64, 23);
            this.nud_OutDefectMinWidth_1.TabIndex = 0;
            this.nud_OutDefectMinWidth_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_OutDefectMinWidth_1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(3, 259);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(337, 184);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // btn_TestNotchDefect_1
            // 
            this.btn_TestNotchDefect_1.BackColor = System.Drawing.Color.Khaki;
            this.btn_TestNotchDefect_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestNotchDefect_1.Location = new System.Drawing.Point(354, 689);
            this.btn_TestNotchDefect_1.Name = "btn_TestNotchDefect_1";
            this.btn_TestNotchDefect_1.Size = new System.Drawing.Size(285, 45);
            this.btn_TestNotchDefect_1.TabIndex = 5;
            this.btn_TestNotchDefect_1.Text = "TEST\r\nInspectNotchDefect_v2\r\n";
            this.btn_TestNotchDefect_1.UseVisualStyleBackColor = false;
            this.btn_TestNotchDefect_1.Click += new System.EventHandler(this.btn_TestNotchDefect_Click);
            // 
            // hctrl_NotchImg_1
            // 
            this.hctrl_NotchImg_1.AllowDrop = true;
            this.hctrl_NotchImg_1.BackColor = System.Drawing.Color.Black;
            this.hctrl_NotchImg_1.FontSizeThreshold = 8;
            this.hctrl_NotchImg_1.ImageBuffer.Columns = 1;
            this.hctrl_NotchImg_1.ImageBuffer.Height = 480;
            this.hctrl_NotchImg_1.ImageBuffer.Heights = 480;
            this.hctrl_NotchImg_1.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj9")));
            this.hctrl_NotchImg_1.ImageBuffer.RawImage = null;
            this.hctrl_NotchImg_1.ImageBuffer.Rows = 1;
            this.hctrl_NotchImg_1.ImageBuffer.Width = 640;
            this.hctrl_NotchImg_1.ImageBuffer.Widths = 640;
            this.hctrl_NotchImg_1.IsDispCenterCross = false;
            this.hctrl_NotchImg_1.IsDispHObject = true;
            this.hctrl_NotchImg_1.IsDispROIFrameFontInfo = true;
            this.hctrl_NotchImg_1.IsLockGetMposition = false;
            this.hctrl_NotchImg_1.IsLockMouseOperation = false;
            this.hctrl_NotchImg_1.IsUseMenuByMouseRightButton = true;
            this.hctrl_NotchImg_1.KeyCtrlPressStatus = false;
            this.hctrl_NotchImg_1.Location = new System.Drawing.Point(351, 24);
            this.hctrl_NotchImg_1.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_NotchImg_1.MaxZoom = 100F;
            this.hctrl_NotchImg_1.MinZoom = 0.01F;
            this.hctrl_NotchImg_1.Name = "hctrl_NotchImg_1";
            this.hctrl_NotchImg_1.ROIController.ActiveROIIndex = -1;
            this.hctrl_NotchImg_1.ROIFontSize = 18;
            this.hctrl_NotchImg_1.ROIFontSizeThreshold = 10;
            this.hctrl_NotchImg_1.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.tableLayoutPanel13.SetRowSpan(this.hctrl_NotchImg_1, 2);
            this.hctrl_NotchImg_1.ScrollBarEnable = false;
            this.hctrl_NotchImg_1.Size = new System.Drawing.Size(318, 421);
            this.hctrl_NotchImg_1.TabIndex = 12;
            this.hctrl_NotchImg_1.Zoom = 0.01F;
            this.hctrl_NotchImg_1.DragDrop += new System.Windows.Forms.DragEventHandler(this.hctrl_NotchImg_DragDrop);
            this.hctrl_NotchImg_1.DragEnter += new System.Windows.Forms.DragEventHandler(this.hctrl_NotchImg_DragEnter);
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel15, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel23, 0, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(3, 449);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(345, 234);
            this.tableLayoutPanel24.TabIndex = 14;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.72789F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.27211F));
            this.tableLayoutPanel15.Controls.Add(this.label172, 0, 9);
            this.tableLayoutPanel15.Controls.Add(this.label104, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.label105, 0, 2);
            this.tableLayoutPanel15.Controls.Add(this.nud_RoiWidthToBevelCenter_1, 1, 1);
            this.tableLayoutPanel15.Controls.Add(this.nud_BevelWidth_1, 1, 2);
            this.tableLayoutPanel15.Controls.Add(this.nud_AiDefectSize_1, 1, 5);
            this.tableLayoutPanel15.Controls.Add(this.label108, 0, 6);
            this.tableLayoutPanel15.Controls.Add(this.label109, 0, 7);
            this.tableLayoutPanel15.Controls.Add(this.label110, 0, 5);
            this.tableLayoutPanel15.Controls.Add(this.label111, 0, 8);
            this.tableLayoutPanel15.Controls.Add(this.nud_AiMinGray_1, 1, 6);
            this.tableLayoutPanel15.Controls.Add(this.nud_InnerDefectAreaSize_1, 1, 7);
            this.tableLayoutPanel15.Controls.Add(this.label75, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.nud_innerDefectMaxGray_1, 1, 8);
            this.tableLayoutPanel15.Controls.Add(this.label107, 0, 3);
            this.tableLayoutPanel15.Controls.Add(this.nud_InnerThresholdMax_1, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.ckb_DefectV1, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.nud_EdgeDefectAreaSize_1, 1, 9);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(175, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 10;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(166, 228);
            this.tableLayoutPanel15.TabIndex = 3;
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Location = new System.Drawing.Point(3, 207);
            this.label172.Margin = new System.Windows.Forms.Padding(3);
            this.label172.Name = "label172";
            this.label172.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label172.Size = new System.Drawing.Size(108, 18);
            this.label172.TabIndex = 3;
            this.label172.Text = "EdgeDefectAreaSize";
            this.label172.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(3, 23);
            this.label104.Margin = new System.Windows.Forms.Padding(3);
            this.label104.Name = "label104";
            this.label104.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label104.Size = new System.Drawing.Size(106, 17);
            this.label104.TabIndex = 1;
            this.label104.Text = "RoiWidthToBevelCenter";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(3, 46);
            this.label105.Margin = new System.Windows.Forms.Padding(3);
            this.label105.Name = "label105";
            this.label105.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label105.Size = new System.Drawing.Size(72, 16);
            this.label105.TabIndex = 1;
            this.label105.Text = "BevelWidth";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_RoiWidthToBevelCenter_1
            // 
            this.nud_RoiWidthToBevelCenter_1.Enabled = false;
            this.nud_RoiWidthToBevelCenter_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_RoiWidthToBevelCenter_1.Location = new System.Drawing.Point(118, 23);
            this.nud_RoiWidthToBevelCenter_1.Maximum = new decimal(new int[] {
            251,
            0,
            0,
            0});
            this.nud_RoiWidthToBevelCenter_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_RoiWidthToBevelCenter_1.Name = "nud_RoiWidthToBevelCenter_1";
            this.nud_RoiWidthToBevelCenter_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_RoiWidthToBevelCenter_1.Size = new System.Drawing.Size(45, 23);
            this.nud_RoiWidthToBevelCenter_1.TabIndex = 0;
            this.nud_RoiWidthToBevelCenter_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_RoiWidthToBevelCenter_1.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // nud_BevelWidth_1
            // 
            this.nud_BevelWidth_1.Enabled = false;
            this.nud_BevelWidth_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BevelWidth_1.Location = new System.Drawing.Point(118, 46);
            this.nud_BevelWidth_1.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_BevelWidth_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_BevelWidth_1.Name = "nud_BevelWidth_1";
            this.nud_BevelWidth_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BevelWidth_1.Size = new System.Drawing.Size(45, 23);
            this.nud_BevelWidth_1.TabIndex = 0;
            this.nud_BevelWidth_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BevelWidth_1.Value = new decimal(new int[] {
            27,
            0,
            0,
            0});
            // 
            // nud_AiDefectSize_1
            // 
            this.nud_AiDefectSize_1.Enabled = false;
            this.nud_AiDefectSize_1.Location = new System.Drawing.Point(118, 115);
            this.nud_AiDefectSize_1.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_AiDefectSize_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_AiDefectSize_1.Name = "nud_AiDefectSize_1";
            this.nud_AiDefectSize_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AiDefectSize_1.Size = new System.Drawing.Size(45, 23);
            this.nud_AiDefectSize_1.TabIndex = 0;
            this.nud_AiDefectSize_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AiDefectSize_1.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(3, 138);
            this.label108.Margin = new System.Windows.Forms.Padding(3);
            this.label108.Name = "label108";
            this.label108.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label108.Size = new System.Drawing.Size(67, 16);
            this.label108.TabIndex = 1;
            this.label108.Text = "AiMinGray";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(3, 161);
            this.label109.Margin = new System.Windows.Forms.Padding(3);
            this.label109.Name = "label109";
            this.label109.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label109.Size = new System.Drawing.Size(109, 17);
            this.label109.TabIndex = 1;
            this.label109.Text = "InnerDefectAreaSize";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(3, 115);
            this.label110.Margin = new System.Windows.Forms.Padding(3);
            this.label110.Name = "label110";
            this.label110.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label110.Size = new System.Drawing.Size(79, 16);
            this.label110.TabIndex = 1;
            this.label110.Text = "AiDefectSize";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(3, 184);
            this.label111.Margin = new System.Windows.Forms.Padding(3);
            this.label111.Name = "label111";
            this.label111.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label111.Size = new System.Drawing.Size(107, 17);
            this.label111.TabIndex = 1;
            this.label111.Text = "InnerDefectMaxGray (不檢查:0)";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AiMinGray_1
            // 
            this.nud_AiMinGray_1.Enabled = false;
            this.nud_AiMinGray_1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_AiMinGray_1.Location = new System.Drawing.Point(118, 138);
            this.nud_AiMinGray_1.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_AiMinGray_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_AiMinGray_1.Name = "nud_AiMinGray_1";
            this.nud_AiMinGray_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AiMinGray_1.Size = new System.Drawing.Size(45, 23);
            this.nud_AiMinGray_1.TabIndex = 0;
            this.nud_AiMinGray_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AiMinGray_1.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // nud_InnerDefectAreaSize_1
            // 
            this.nud_InnerDefectAreaSize_1.Enabled = false;
            this.nud_InnerDefectAreaSize_1.Location = new System.Drawing.Point(118, 161);
            this.nud_InnerDefectAreaSize_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_InnerDefectAreaSize_1.Name = "nud_InnerDefectAreaSize_1";
            this.nud_InnerDefectAreaSize_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerDefectAreaSize_1.Size = new System.Drawing.Size(45, 23);
            this.nud_InnerDefectAreaSize_1.TabIndex = 0;
            this.nud_InnerDefectAreaSize_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InnerDefectAreaSize_1.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(3, 3);
            this.label75.Margin = new System.Windows.Forms.Padding(3);
            this.label75.Name = "label75";
            this.label75.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label75.Size = new System.Drawing.Size(84, 14);
            this.label75.TabIndex = 1;
            this.label75.Text = "缺陷參數 V1.0";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_innerDefectMaxGray_1
            // 
            this.nud_innerDefectMaxGray_1.Enabled = false;
            this.nud_innerDefectMaxGray_1.Location = new System.Drawing.Point(118, 184);
            this.nud_innerDefectMaxGray_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_1.Name = "nud_innerDefectMaxGray_1";
            this.nud_innerDefectMaxGray_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_innerDefectMaxGray_1.Size = new System.Drawing.Size(45, 23);
            this.nud_innerDefectMaxGray_1.TabIndex = 0;
            this.nud_innerDefectMaxGray_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_innerDefectMaxGray_1.Value = new decimal(new int[] {
            105,
            0,
            0,
            0});
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(3, 69);
            this.label107.Margin = new System.Windows.Forms.Padding(3);
            this.label107.Name = "label107";
            this.label107.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label107.Size = new System.Drawing.Size(104, 17);
            this.label107.TabIndex = 1;
            this.label107.Text = "InnerThresholdMax[Auto:-1]";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_InnerThresholdMax_1
            // 
            this.nud_InnerThresholdMax_1.Enabled = false;
            this.nud_InnerThresholdMax_1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InnerThresholdMax_1.Location = new System.Drawing.Point(118, 69);
            this.nud_InnerThresholdMax_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_InnerThresholdMax_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_InnerThresholdMax_1.Name = "nud_InnerThresholdMax_1";
            this.nud_InnerThresholdMax_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerThresholdMax_1.Size = new System.Drawing.Size(45, 23);
            this.nud_InnerThresholdMax_1.TabIndex = 0;
            this.nud_InnerThresholdMax_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InnerThresholdMax_1.Value = new decimal(new int[] {
            230,
            0,
            0,
            0});
            // 
            // ckb_DefectV1
            // 
            this.ckb_DefectV1.AutoSize = true;
            this.ckb_DefectV1.Location = new System.Drawing.Point(118, 3);
            this.ckb_DefectV1.Name = "ckb_DefectV1";
            this.ckb_DefectV1.Size = new System.Drawing.Size(15, 14);
            this.ckb_DefectV1.TabIndex = 2;
            this.ckb_DefectV1.UseVisualStyleBackColor = true;
            this.ckb_DefectV1.CheckedChanged += new System.EventHandler(this.ckb_DefectV1_CheckedChanged);
            // 
            // nud_EdgeDefectAreaSize_1
            // 
            this.nud_EdgeDefectAreaSize_1.Enabled = false;
            this.nud_EdgeDefectAreaSize_1.Location = new System.Drawing.Point(118, 207);
            this.nud_EdgeDefectAreaSize_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_EdgeDefectAreaSize_1.Name = "nud_EdgeDefectAreaSize_1";
            this.nud_EdgeDefectAreaSize_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_EdgeDefectAreaSize_1.Size = new System.Drawing.Size(45, 23);
            this.nud_EdgeDefectAreaSize_1.TabIndex = 4;
            this.nud_EdgeDefectAreaSize_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_EdgeDefectAreaSize_1.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.06061F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.93939F));
            this.tableLayoutPanel23.Controls.Add(this.lab_hv_ROIColumn, 0, 1);
            this.tableLayoutPanel23.Controls.Add(this.label150, 0, 2);
            this.tableLayoutPanel23.Controls.Add(this.nud_ROIColumn, 1, 1);
            this.tableLayoutPanel23.Controls.Add(this.nud_DarkLightThreshold, 1, 2);
            this.tableLayoutPanel23.Controls.Add(this.label157, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.lab_light_DarkThres, 0, 3);
            this.tableLayoutPanel23.Controls.Add(this.lab_DarkMax, 0, 4);
            this.tableLayoutPanel23.Controls.Add(this.lab_Dark_DarkThres, 0, 5);
            this.tableLayoutPanel23.Controls.Add(this.lab_Dark_LightThres, 0, 6);
            this.tableLayoutPanel23.Controls.Add(this.lab_WhiteThres, 0, 7);
            this.tableLayoutPanel23.Controls.Add(this.nud_light_DarkThres, 1, 3);
            this.tableLayoutPanel23.Controls.Add(this.nud_DarkMax, 1, 4);
            this.tableLayoutPanel23.Controls.Add(this.nud_Dark_DarkThres, 1, 5);
            this.tableLayoutPanel23.Controls.Add(this.nud_Dark_LightThres, 1, 6);
            this.tableLayoutPanel23.Controls.Add(this.nud_WhiteThres, 1, 7);
            this.tableLayoutPanel23.Controls.Add(this.label149, 0, 8);
            this.tableLayoutPanel23.Controls.Add(this.label151, 0, 9);
            this.tableLayoutPanel23.Controls.Add(this.nud_MinAreaSize, 1, 8);
            this.tableLayoutPanel23.Controls.Add(this.nud_MinDefectSize, 1, 9);
            this.tableLayoutPanel23.Controls.Add(this.ckb_DefectV2, 1, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 10;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(165, 228);
            this.tableLayoutPanel23.TabIndex = 3;
            // 
            // lab_hv_ROIColumn
            // 
            this.lab_hv_ROIColumn.AutoSize = true;
            this.lab_hv_ROIColumn.Location = new System.Drawing.Point(3, 23);
            this.lab_hv_ROIColumn.Margin = new System.Windows.Forms.Padding(3);
            this.lab_hv_ROIColumn.Name = "lab_hv_ROIColumn";
            this.lab_hv_ROIColumn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_hv_ROIColumn.Size = new System.Drawing.Size(73, 16);
            this.lab_hv_ROIColumn.TabIndex = 1;
            this.lab_hv_ROIColumn.Text = "ROIColumn";
            this.lab_hv_ROIColumn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(3, 46);
            this.label150.Margin = new System.Windows.Forms.Padding(3);
            this.label150.Name = "label150";
            this.label150.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label150.Size = new System.Drawing.Size(99, 17);
            this.label150.TabIndex = 1;
            this.label150.Text = "DarkLightThreshold";
            this.label150.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_ROIColumn
            // 
            this.nud_ROIColumn.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_ROIColumn.Location = new System.Drawing.Point(112, 23);
            this.nud_ROIColumn.Maximum = new decimal(new int[] {
            251,
            0,
            0,
            0});
            this.nud_ROIColumn.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ROIColumn.Name = "nud_ROIColumn";
            this.nud_ROIColumn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_ROIColumn.Size = new System.Drawing.Size(50, 23);
            this.nud_ROIColumn.TabIndex = 0;
            this.nud_ROIColumn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ROIColumn.Value = new decimal(new int[] {
            130,
            0,
            0,
            0});
            // 
            // nud_DarkLightThreshold
            // 
            this.nud_DarkLightThreshold.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DarkLightThreshold.Location = new System.Drawing.Point(112, 46);
            this.nud_DarkLightThreshold.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_DarkLightThreshold.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DarkLightThreshold.Name = "nud_DarkLightThreshold";
            this.nud_DarkLightThreshold.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DarkLightThreshold.Size = new System.Drawing.Size(50, 23);
            this.nud_DarkLightThreshold.TabIndex = 0;
            this.nud_DarkLightThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DarkLightThreshold.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(3, 3);
            this.label157.Margin = new System.Windows.Forms.Padding(3);
            this.label157.Name = "label157";
            this.label157.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label157.Size = new System.Drawing.Size(84, 14);
            this.label157.TabIndex = 1;
            this.label157.Text = "缺陷參數 V2.0";
            this.label157.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_light_DarkThres
            // 
            this.lab_light_DarkThres.AutoSize = true;
            this.lab_light_DarkThres.Location = new System.Drawing.Point(3, 69);
            this.lab_light_DarkThres.Margin = new System.Windows.Forms.Padding(3);
            this.lab_light_DarkThres.Name = "lab_light_DarkThres";
            this.lab_light_DarkThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_light_DarkThres.Size = new System.Drawing.Size(94, 16);
            this.lab_light_DarkThres.TabIndex = 1;
            this.lab_light_DarkThres.Text = "light_DarkThres";
            this.lab_light_DarkThres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_DarkMax
            // 
            this.lab_DarkMax.AutoSize = true;
            this.lab_DarkMax.Location = new System.Drawing.Point(3, 92);
            this.lab_DarkMax.Margin = new System.Windows.Forms.Padding(3);
            this.lab_DarkMax.Name = "lab_DarkMax";
            this.lab_DarkMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_DarkMax.Size = new System.Drawing.Size(59, 16);
            this.lab_DarkMax.TabIndex = 1;
            this.lab_DarkMax.Text = "DarkMax";
            this.lab_DarkMax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_Dark_DarkThres
            // 
            this.lab_Dark_DarkThres.AutoSize = true;
            this.lab_Dark_DarkThres.Location = new System.Drawing.Point(3, 115);
            this.lab_Dark_DarkThres.Margin = new System.Windows.Forms.Padding(3);
            this.lab_Dark_DarkThres.Name = "lab_Dark_DarkThres";
            this.lab_Dark_DarkThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_Dark_DarkThres.Size = new System.Drawing.Size(95, 16);
            this.lab_Dark_DarkThres.TabIndex = 1;
            this.lab_Dark_DarkThres.Text = "Dark_DarkThres";
            this.lab_Dark_DarkThres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_Dark_LightThres
            // 
            this.lab_Dark_LightThres.AutoSize = true;
            this.lab_Dark_LightThres.Location = new System.Drawing.Point(3, 138);
            this.lab_Dark_LightThres.Margin = new System.Windows.Forms.Padding(3);
            this.lab_Dark_LightThres.Name = "lab_Dark_LightThres";
            this.lab_Dark_LightThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_Dark_LightThres.Size = new System.Drawing.Size(97, 16);
            this.lab_Dark_LightThres.TabIndex = 1;
            this.lab_Dark_LightThres.Text = "Dark_LightThres";
            this.lab_Dark_LightThres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_WhiteThres
            // 
            this.lab_WhiteThres.AutoSize = true;
            this.lab_WhiteThres.Location = new System.Drawing.Point(3, 161);
            this.lab_WhiteThres.Margin = new System.Windows.Forms.Padding(3);
            this.lab_WhiteThres.Name = "lab_WhiteThres";
            this.lab_WhiteThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_WhiteThres.Size = new System.Drawing.Size(71, 16);
            this.lab_WhiteThres.TabIndex = 1;
            this.lab_WhiteThres.Text = "WhiteThres";
            this.lab_WhiteThres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_light_DarkThres
            // 
            this.nud_light_DarkThres.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_light_DarkThres.Location = new System.Drawing.Point(112, 69);
            this.nud_light_DarkThres.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_light_DarkThres.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_light_DarkThres.Name = "nud_light_DarkThres";
            this.nud_light_DarkThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_light_DarkThres.Size = new System.Drawing.Size(50, 23);
            this.nud_light_DarkThres.TabIndex = 0;
            this.nud_light_DarkThres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_light_DarkThres.Value = new decimal(new int[] {
            45,
            0,
            0,
            0});
            // 
            // nud_DarkMax
            // 
            this.nud_DarkMax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DarkMax.Location = new System.Drawing.Point(112, 92);
            this.nud_DarkMax.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_DarkMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DarkMax.Name = "nud_DarkMax";
            this.nud_DarkMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DarkMax.Size = new System.Drawing.Size(50, 23);
            this.nud_DarkMax.TabIndex = 0;
            this.nud_DarkMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DarkMax.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // nud_Dark_DarkThres
            // 
            this.nud_Dark_DarkThres.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Dark_DarkThres.Location = new System.Drawing.Point(112, 115);
            this.nud_Dark_DarkThres.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_Dark_DarkThres.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Dark_DarkThres.Name = "nud_Dark_DarkThres";
            this.nud_Dark_DarkThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Dark_DarkThres.Size = new System.Drawing.Size(50, 23);
            this.nud_Dark_DarkThres.TabIndex = 0;
            this.nud_Dark_DarkThres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Dark_DarkThres.Value = new decimal(new int[] {
            35,
            0,
            0,
            0});
            // 
            // nud_Dark_LightThres
            // 
            this.nud_Dark_LightThres.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Dark_LightThres.Location = new System.Drawing.Point(112, 138);
            this.nud_Dark_LightThres.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_Dark_LightThres.Name = "nud_Dark_LightThres";
            this.nud_Dark_LightThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Dark_LightThres.Size = new System.Drawing.Size(50, 23);
            this.nud_Dark_LightThres.TabIndex = 0;
            this.nud_Dark_LightThres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Dark_LightThres.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // nud_WhiteThres
            // 
            this.nud_WhiteThres.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_WhiteThres.Location = new System.Drawing.Point(112, 161);
            this.nud_WhiteThres.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_WhiteThres.Name = "nud_WhiteThres";
            this.nud_WhiteThres.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_WhiteThres.Size = new System.Drawing.Size(50, 23);
            this.nud_WhiteThres.TabIndex = 0;
            this.nud_WhiteThres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_WhiteThres.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(3, 184);
            this.label149.Margin = new System.Windows.Forms.Padding(3);
            this.label149.Name = "label149";
            this.label149.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label149.Size = new System.Drawing.Size(79, 16);
            this.label149.TabIndex = 1;
            this.label149.Text = "MinAreaSize";
            this.label149.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(3, 207);
            this.label151.Margin = new System.Windows.Forms.Padding(3);
            this.label151.Name = "label151";
            this.label151.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label151.Size = new System.Drawing.Size(90, 16);
            this.label151.TabIndex = 1;
            this.label151.Text = "MinDefectSize";
            this.label151.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_MinAreaSize
            // 
            this.nud_MinAreaSize.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_MinAreaSize.Location = new System.Drawing.Point(112, 184);
            this.nud_MinAreaSize.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_MinAreaSize.Name = "nud_MinAreaSize";
            this.nud_MinAreaSize.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinAreaSize.Size = new System.Drawing.Size(50, 23);
            this.nud_MinAreaSize.TabIndex = 0;
            this.nud_MinAreaSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinAreaSize.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_MinDefectSize
            // 
            this.nud_MinDefectSize.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_MinDefectSize.Location = new System.Drawing.Point(112, 207);
            this.nud_MinDefectSize.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_MinDefectSize.Name = "nud_MinDefectSize";
            this.nud_MinDefectSize.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinDefectSize.Size = new System.Drawing.Size(50, 23);
            this.nud_MinDefectSize.TabIndex = 0;
            this.nud_MinDefectSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinDefectSize.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // ckb_DefectV2
            // 
            this.ckb_DefectV2.AutoSize = true;
            this.ckb_DefectV2.Checked = true;
            this.ckb_DefectV2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckb_DefectV2.Location = new System.Drawing.Point(112, 3);
            this.ckb_DefectV2.Name = "ckb_DefectV2";
            this.ckb_DefectV2.Size = new System.Drawing.Size(15, 14);
            this.ckb_DefectV2.TabIndex = 2;
            this.ckb_DefectV2.UseVisualStyleBackColor = true;
            this.ckb_DefectV2.CheckedChanged += new System.EventHandler(this.ckb_DefectV2_CheckedChanged);
            // 
            // btn_TestDefect_1
            // 
            this.btn_TestDefect_1.BackColor = System.Drawing.Color.Khaki;
            this.btn_TestDefect_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestDefect_1.Location = new System.Drawing.Point(3, 689);
            this.btn_TestDefect_1.Name = "btn_TestDefect_1";
            this.btn_TestDefect_1.Size = new System.Drawing.Size(301, 45);
            this.btn_TestDefect_1.TabIndex = 5;
            this.btn_TestDefect_1.Text = "TEST\r\nInspectWaferEdgeDefectAndDrawAi";
            this.btn_TestDefect_1.UseVisualStyleBackColor = false;
            this.btn_TestDefect_1.Click += new System.EventHandler(this.btn_TestDefect_Click);
            // 
            // tbp_Defect_2
            // 
            this.tbp_Defect_2.Controls.Add(this.tableLayoutPanel17);
            this.tbp_Defect_2.Location = new System.Drawing.Point(4, 25);
            this.tbp_Defect_2.Name = "tbp_Defect_2";
            this.tbp_Defect_2.Size = new System.Drawing.Size(1137, 789);
            this.tbp_Defect_2.TabIndex = 3;
            this.tbp_Defect_2.Text = "Defect_2";
            this.tbp_Defect_2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel17.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel20, 1, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1137, 789);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label115);
            this.panel5.Controls.Add(this.nud_DefectLamp_2);
            this.panel5.Controls.Add(this.label116);
            this.panel5.Controls.Add(this.pictureBox10);
            this.panel5.Controls.Add(this.lab_dispNumber_2);
            this.panel5.Controls.Add(this.hctrl_RawImage_2);
            this.panel5.Controls.Add(this.txb_model_2);
            this.panel5.Controls.Add(this.txb_ImageRaw_2);
            this.panel5.Controls.Add(this.tableLayoutPanel18);
            this.panel5.Controls.Add(this.tableLayoutPanel19);
            this.panel5.Controls.Add(this.btn_CropInspectionImg_2);
            this.panel5.Controls.Add(this.btn_TestCropNotch_2);
            this.panel5.Controls.Add(this.nud_SelectCropImg_2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(449, 783);
            this.panel5.TabIndex = 2;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(172, 328);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(40, 16);
            this.label115.TabIndex = 13;
            this.label115.Text = "Lamp";
            // 
            // nud_DefectLamp_2
            // 
            this.nud_DefectLamp_2.DecimalPlaces = 2;
            this.nud_DefectLamp_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DefectLamp_2.Location = new System.Drawing.Point(244, 326);
            this.nud_DefectLamp_2.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nud_DefectLamp_2.Name = "nud_DefectLamp_2";
            this.nud_DefectLamp_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DefectLamp_2.Size = new System.Drawing.Size(64, 23);
            this.nud_DefectLamp_2.TabIndex = 12;
            this.nud_DefectLamp_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DefectLamp_2.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label116.Location = new System.Drawing.Point(368, 25);
            this.label116.Margin = new System.Windows.Forms.Padding(3);
            this.label116.Name = "label116";
            this.label116.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label116.Size = new System.Drawing.Size(73, 36);
            this.label116.TabIndex = 1;
            this.label116.Text = "反面";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox10.Location = new System.Drawing.Point(218, 325);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 24);
            this.pictureBox10.TabIndex = 14;
            this.pictureBox10.TabStop = false;
            // 
            // lab_dispNumber_2
            // 
            this.lab_dispNumber_2.AutoSize = true;
            this.lab_dispNumber_2.Location = new System.Drawing.Point(119, 671);
            this.lab_dispNumber_2.Name = "lab_dispNumber_2";
            this.lab_dispNumber_2.Size = new System.Drawing.Size(80, 16);
            this.lab_dispNumber_2.TabIndex = 0;
            this.lab_dispNumber_2.Text = "全部共有    張";
            // 
            // hctrl_RawImage_2
            // 
            this.hctrl_RawImage_2.AllowDrop = true;
            this.hctrl_RawImage_2.BackColor = System.Drawing.Color.Black;
            this.hctrl_RawImage_2.FontSizeThreshold = 8;
            this.hctrl_RawImage_2.ImageBuffer.Columns = 1;
            this.hctrl_RawImage_2.ImageBuffer.Height = 480;
            this.hctrl_RawImage_2.ImageBuffer.Heights = 480;
            this.hctrl_RawImage_2.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj10")));
            this.hctrl_RawImage_2.ImageBuffer.RawImage = null;
            this.hctrl_RawImage_2.ImageBuffer.Rows = 1;
            this.hctrl_RawImage_2.ImageBuffer.Width = 640;
            this.hctrl_RawImage_2.ImageBuffer.Widths = 640;
            this.hctrl_RawImage_2.IsDispCenterCross = false;
            this.hctrl_RawImage_2.IsDispHObject = true;
            this.hctrl_RawImage_2.IsDispROIFrameFontInfo = true;
            this.hctrl_RawImage_2.IsLockGetMposition = false;
            this.hctrl_RawImage_2.IsLockMouseOperation = false;
            this.hctrl_RawImage_2.IsUseMenuByMouseRightButton = true;
            this.hctrl_RawImage_2.KeyCtrlPressStatus = false;
            this.hctrl_RawImage_2.Location = new System.Drawing.Point(19, 97);
            this.hctrl_RawImage_2.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_RawImage_2.MaxZoom = 100F;
            this.hctrl_RawImage_2.MinZoom = 0.01F;
            this.hctrl_RawImage_2.Name = "hctrl_RawImage_2";
            this.hctrl_RawImage_2.ROIController.ActiveROIIndex = -1;
            this.hctrl_RawImage_2.ROIFontSize = 18;
            this.hctrl_RawImage_2.ROIFontSizeThreshold = 10;
            this.hctrl_RawImage_2.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_RawImage_2.ScrollBarEnable = false;
            this.hctrl_RawImage_2.Size = new System.Drawing.Size(69, 670);
            this.hctrl_RawImage_2.TabIndex = 11;
            this.hctrl_RawImage_2.Zoom = 0.01F;
            // 
            // txb_model_2
            // 
            this.txb_model_2.Location = new System.Drawing.Point(100, 139);
            this.txb_model_2.Name = "txb_model_2";
            this.txb_model_2.Size = new System.Drawing.Size(279, 23);
            this.txb_model_2.TabIndex = 10;
            // 
            // txb_ImageRaw_2
            // 
            this.txb_ImageRaw_2.Location = new System.Drawing.Point(100, 110);
            this.txb_ImageRaw_2.Name = "txb_ImageRaw_2";
            this.txb_ImageRaw_2.Size = new System.Drawing.Size(279, 23);
            this.txb_ImageRaw_2.TabIndex = 9;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.07725F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.92275F));
            this.tableLayoutPanel18.Controls.Add(this.label117, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.label118, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.label119, 0, 2);
            this.tableLayoutPanel18.Controls.Add(this.label120, 0, 3);
            this.tableLayoutPanel18.Controls.Add(this.nud_PixelSize_2, 1, 3);
            this.tableLayoutPanel18.Controls.Add(this.label121, 0, 4);
            this.tableLayoutPanel18.Controls.Add(this.label122, 0, 5);
            this.tableLayoutPanel18.Controls.Add(this.nud_InDistance_2, 1, 2);
            this.tableLayoutPanel18.Controls.Add(this.nud_CropSize_2, 1, 4);
            this.tableLayoutPanel18.Controls.Add(this.nud_CropNotchWidth_2, 1, 1);
            this.tableLayoutPanel18.Controls.Add(this.nud_MinScore_2, 1, 5);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(116, 365);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 6;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(233, 249);
            this.tableLayoutPanel18.TabIndex = 7;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(3, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(81, 16);
            this.label117.TabIndex = 0;
            this.label117.Text = "NotchModel";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(3, 39);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(105, 16);
            this.label118.TabIndex = 0;
            this.label118.Text = "CropNotchWidth";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(3, 78);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(96, 16);
            this.label119.TabIndex = 0;
            this.label119.Text = "InDistance[mm]";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(3, 117);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(83, 16);
            this.label120.TabIndex = 0;
            this.label120.Text = "PixelSize[um]";
            // 
            // nud_PixelSize_2
            // 
            this.nud_PixelSize_2.DecimalPlaces = 2;
            this.nud_PixelSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_PixelSize_2.Location = new System.Drawing.Point(128, 120);
            this.nud_PixelSize_2.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.nud_PixelSize_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_PixelSize_2.Name = "nud_PixelSize_2";
            this.nud_PixelSize_2.ReadOnly = true;
            this.nud_PixelSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_PixelSize_2.Size = new System.Drawing.Size(64, 23);
            this.nud_PixelSize_2.TabIndex = 0;
            this.nud_PixelSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_PixelSize_2.Value = new decimal(new int[] {
            704,
            0,
            0,
            131072});
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(3, 156);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(94, 16);
            this.label121.TabIndex = 0;
            this.label121.Text = "CropSize[pixel]";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(3, 195);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(62, 16);
            this.label122.TabIndex = 0;
            this.label122.Text = "MinScore";
            // 
            // nud_InDistance_2
            // 
            this.nud_InDistance_2.DecimalPlaces = 1;
            this.nud_InDistance_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InDistance_2.Location = new System.Drawing.Point(128, 81);
            this.nud_InDistance_2.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_InDistance_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_InDistance_2.Name = "nud_InDistance_2";
            this.nud_InDistance_2.ReadOnly = true;
            this.nud_InDistance_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InDistance_2.Size = new System.Drawing.Size(64, 23);
            this.nud_InDistance_2.TabIndex = 0;
            this.nud_InDistance_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InDistance_2.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            // 
            // nud_CropSize_2
            // 
            this.nud_CropSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_CropSize_2.Location = new System.Drawing.Point(128, 159);
            this.nud_CropSize_2.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.nud_CropSize_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_CropSize_2.Name = "nud_CropSize_2";
            this.nud_CropSize_2.ReadOnly = true;
            this.nud_CropSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_CropSize_2.Size = new System.Drawing.Size(64, 23);
            this.nud_CropSize_2.TabIndex = 0;
            this.nud_CropSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_CropSize_2.Value = new decimal(new int[] {
            256,
            0,
            0,
            0});
            // 
            // nud_CropNotchWidth_2
            // 
            this.nud_CropNotchWidth_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_CropNotchWidth_2.Location = new System.Drawing.Point(128, 42);
            this.nud_CropNotchWidth_2.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_CropNotchWidth_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_CropNotchWidth_2.Name = "nud_CropNotchWidth_2";
            this.nud_CropNotchWidth_2.ReadOnly = true;
            this.nud_CropNotchWidth_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_CropNotchWidth_2.Size = new System.Drawing.Size(64, 23);
            this.nud_CropNotchWidth_2.TabIndex = 0;
            this.nud_CropNotchWidth_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_CropNotchWidth_2.Value = new decimal(new int[] {
            700,
            0,
            0,
            0});
            // 
            // nud_MinScore_2
            // 
            this.nud_MinScore_2.DecimalPlaces = 2;
            this.nud_MinScore_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_MinScore_2.Location = new System.Drawing.Point(128, 198);
            this.nud_MinScore_2.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            131072});
            this.nud_MinScore_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_MinScore_2.Name = "nud_MinScore_2";
            this.nud_MinScore_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinScore_2.Size = new System.Drawing.Size(64, 23);
            this.nud_MinScore_2.TabIndex = 0;
            this.nud_MinScore_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinScore_2.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 6;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel19.Controls.Add(this.button1, 3, 1);
            this.tableLayoutPanel19.Controls.Add(this.label123, 2, 0);
            this.tableLayoutPanel19.Controls.Add(this.label124, 3, 0);
            this.tableLayoutPanel19.Controls.Add(this.btn_loadModel_2, 2, 1);
            this.tableLayoutPanel19.Controls.Add(this.btn_LoadImage_Defect_2, 1, 1);
            this.tableLayoutPanel19.Controls.Add(this.label125, 1, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel19.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Location = new System.Drawing.Point(174, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(51, 43);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label123.Location = new System.Drawing.Point(117, 3);
            this.label123.Margin = new System.Windows.Forms.Padding(3);
            this.label123.Name = "label123";
            this.label123.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label123.Size = new System.Drawing.Size(41, 13);
            this.label123.TabIndex = 1;
            this.label123.Text = "Model";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label124.Location = new System.Drawing.Point(174, 3);
            this.label124.Margin = new System.Windows.Forms.Padding(3);
            this.label124.Name = "label124";
            this.label124.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label124.Size = new System.Drawing.Size(51, 13);
            this.label124.TabIndex = 1;
            this.label124.Text = "儲存參數";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_loadModel_2
            // 
            this.btn_loadModel_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_loadModel_2.BackgroundImage")));
            this.btn_loadModel_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_loadModel_2.Location = new System.Drawing.Point(117, 22);
            this.btn_loadModel_2.Name = "btn_loadModel_2";
            this.btn_loadModel_2.Size = new System.Drawing.Size(51, 43);
            this.btn_loadModel_2.TabIndex = 5;
            this.btn_loadModel_2.UseVisualStyleBackColor = true;
            this.btn_loadModel_2.Click += new System.EventHandler(this.btn_loadModel_2_Click);
            // 
            // btn_LoadImage_Defect_2
            // 
            this.btn_LoadImage_Defect_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Defect_2.BackgroundImage")));
            this.btn_LoadImage_Defect_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Defect_2.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadImage_Defect_2.Name = "btn_LoadImage_Defect_2";
            this.btn_LoadImage_Defect_2.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Defect_2.TabIndex = 2;
            this.btn_LoadImage_Defect_2.UseVisualStyleBackColor = true;
            this.btn_LoadImage_Defect_2.Click += new System.EventHandler(this.btn_LoadImage_Defect_2_Click);
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label125.Location = new System.Drawing.Point(60, 3);
            this.label125.Margin = new System.Windows.Forms.Padding(3);
            this.label125.Name = "label125";
            this.label125.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label125.Size = new System.Drawing.Size(51, 13);
            this.label125.TabIndex = 1;
            this.label125.Text = "開啟圖片";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_CropInspectionImg_2
            // 
            this.btn_CropInspectionImg_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_CropInspectionImg_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_CropInspectionImg_2.Location = new System.Drawing.Point(116, 702);
            this.btn_CropInspectionImg_2.Name = "btn_CropInspectionImg_2";
            this.btn_CropInspectionImg_2.Size = new System.Drawing.Size(263, 48);
            this.btn_CropInspectionImg_2.TabIndex = 5;
            this.btn_CropInspectionImg_2.Text = "TEST\r\nCropDomainImage\r\n";
            this.btn_CropInspectionImg_2.UseVisualStyleBackColor = false;
            this.btn_CropInspectionImg_2.Click += new System.EventHandler(this.btn_CropInspectionImg_2_Click);
            // 
            // btn_TestCropNotch_2
            // 
            this.btn_TestCropNotch_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_TestCropNotch_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestCropNotch_2.Location = new System.Drawing.Point(116, 620);
            this.btn_TestCropNotch_2.Name = "btn_TestCropNotch_2";
            this.btn_TestCropNotch_2.Size = new System.Drawing.Size(263, 48);
            this.btn_TestCropNotch_2.TabIndex = 5;
            this.btn_TestCropNotch_2.Text = "TEST\r\nCalculateEdgePntAndCropNotch\r\n";
            this.btn_TestCropNotch_2.UseVisualStyleBackColor = false;
            this.btn_TestCropNotch_2.Click += new System.EventHandler(this.btn_TestCropNotch_2_Click);
            // 
            // nud_SelectCropImg_2
            // 
            this.nud_SelectCropImg_2.Location = new System.Drawing.Point(244, 671);
            this.nud_SelectCropImg_2.Name = "nud_SelectCropImg_2";
            this.nud_SelectCropImg_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_SelectCropImg_2.Size = new System.Drawing.Size(46, 23);
            this.nud_SelectCropImg_2.TabIndex = 0;
            this.nud_SelectCropImg_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_SelectCropImg_2.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.96375F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.03625F));
            this.tableLayoutPanel20.Controls.Add(this.label147, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.hctrl_DefectImg_2, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.label126, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel21, 1, 3);
            this.tableLayoutPanel20.Controls.Add(this.pictureBox11, 0, 2);
            this.tableLayoutPanel20.Controls.Add(this.btn_TestDefect_2, 0, 4);
            this.tableLayoutPanel20.Controls.Add(this.btn_TestNotchDefect_2, 1, 4);
            this.tableLayoutPanel20.Controls.Add(this.hctrl_NotchImg_2, 1, 1);
            this.tableLayoutPanel20.Controls.Add(this.tableLayoutPanel25, 0, 3);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(458, 3);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 6;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.17662F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.11436F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.65057F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.13088F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.734435F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.717916F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(676, 783);
            this.tableLayoutPanel20.TabIndex = 1;
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label147.Location = new System.Drawing.Point(354, 3);
            this.label147.Margin = new System.Windows.Forms.Padding(3);
            this.label147.Name = "label147";
            this.label147.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label147.Size = new System.Drawing.Size(61, 15);
            this.label147.TabIndex = 15;
            this.label147.Text = "Notch視窗";
            this.label147.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hctrl_DefectImg_2
            // 
            this.hctrl_DefectImg_2.AllowDrop = true;
            this.hctrl_DefectImg_2.BackColor = System.Drawing.Color.Black;
            this.hctrl_DefectImg_2.FontSizeThreshold = 8;
            this.hctrl_DefectImg_2.ImageBuffer.Columns = 1;
            this.hctrl_DefectImg_2.ImageBuffer.Height = 480;
            this.hctrl_DefectImg_2.ImageBuffer.Heights = 480;
            this.hctrl_DefectImg_2.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj11")));
            this.hctrl_DefectImg_2.ImageBuffer.RawImage = null;
            this.hctrl_DefectImg_2.ImageBuffer.Rows = 1;
            this.hctrl_DefectImg_2.ImageBuffer.Width = 640;
            this.hctrl_DefectImg_2.ImageBuffer.Widths = 640;
            this.hctrl_DefectImg_2.IsDispCenterCross = false;
            this.hctrl_DefectImg_2.IsDispHObject = true;
            this.hctrl_DefectImg_2.IsDispROIFrameFontInfo = true;
            this.hctrl_DefectImg_2.IsLockGetMposition = false;
            this.hctrl_DefectImg_2.IsLockMouseOperation = false;
            this.hctrl_DefectImg_2.IsUseMenuByMouseRightButton = true;
            this.hctrl_DefectImg_2.KeyCtrlPressStatus = false;
            this.hctrl_DefectImg_2.Location = new System.Drawing.Point(0, 24);
            this.hctrl_DefectImg_2.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_DefectImg_2.MaxZoom = 100F;
            this.hctrl_DefectImg_2.MinZoom = 0.01F;
            this.hctrl_DefectImg_2.Name = "hctrl_DefectImg_2";
            this.hctrl_DefectImg_2.ROIController.ActiveROIIndex = -1;
            this.hctrl_DefectImg_2.ROIFontSize = 18;
            this.hctrl_DefectImg_2.ROIFontSizeThreshold = 10;
            this.hctrl_DefectImg_2.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.hctrl_DefectImg_2.ScrollBarEnable = false;
            this.hctrl_DefectImg_2.Size = new System.Drawing.Size(340, 232);
            this.hctrl_DefectImg_2.TabIndex = 13;
            this.hctrl_DefectImg_2.Zoom = 0.01F;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label126.Location = new System.Drawing.Point(3, 5);
            this.label126.Margin = new System.Windows.Forms.Padding(3);
            this.label126.Name = "label126";
            this.label126.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label126.Size = new System.Drawing.Size(345, 16);
            this.label126.TabIndex = 1;
            this.label126.Text = "缺陷小圖";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.72789F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.27211F));
            this.tableLayoutPanel21.Controls.Add(this.label127, 0, 1);
            this.tableLayoutPanel21.Controls.Add(this.label128, 0, 2);
            this.tableLayoutPanel21.Controls.Add(this.label129, 0, 3);
            this.tableLayoutPanel21.Controls.Add(this.label130, 0, 4);
            this.tableLayoutPanel21.Controls.Add(this.label131, 0, 5);
            this.tableLayoutPanel21.Controls.Add(this.label132, 0, 6);
            this.tableLayoutPanel21.Controls.Add(this.label133, 0, 7);
            this.tableLayoutPanel21.Controls.Add(this.label134, 0, 8);
            this.tableLayoutPanel21.Controls.Add(this.nud_BackWhiteMinGray_2, 1, 1);
            this.tableLayoutPanel21.Controls.Add(this.nud_DisplayDilation_2, 1, 2);
            this.tableLayoutPanel21.Controls.Add(this.nud_innerDefectMaxGray_Notch_2, 1, 3);
            this.tableLayoutPanel21.Controls.Add(this.nud_NotchVwRow1_2, 1, 4);
            this.tableLayoutPanel21.Controls.Add(this.nud_NotchVwRow2_2, 1, 5);
            this.tableLayoutPanel21.Controls.Add(this.nud_NotchBlackWidth_2, 1, 6);
            this.tableLayoutPanel21.Controls.Add(this.label135, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.nud_InnerDefectMinWidth_2, 1, 7);
            this.tableLayoutPanel21.Controls.Add(this.nud_OutDefectMinWidth_2, 1, 8);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(354, 449);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 9;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(292, 208);
            this.tableLayoutPanel21.TabIndex = 2;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(3, 23);
            this.label127.Margin = new System.Windows.Forms.Padding(3);
            this.label127.Name = "label127";
            this.label127.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label127.Size = new System.Drawing.Size(115, 16);
            this.label127.TabIndex = 1;
            this.label127.Text = "BackWhiteMinGray";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(3, 46);
            this.label128.Margin = new System.Windows.Forms.Padding(3);
            this.label128.Name = "label128";
            this.label128.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label128.Size = new System.Drawing.Size(93, 16);
            this.label128.TabIndex = 1;
            this.label128.Text = "DisplayDilation";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(3, 69);
            this.label129.Margin = new System.Windows.Forms.Padding(3);
            this.label129.Name = "label129";
            this.label129.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label129.Size = new System.Drawing.Size(124, 16);
            this.label129.TabIndex = 1;
            this.label129.Text = "innerDefectMaxGray";
            this.label129.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(3, 92);
            this.label130.Margin = new System.Windows.Forms.Padding(3);
            this.label130.Name = "label130";
            this.label130.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label130.Size = new System.Drawing.Size(92, 16);
            this.label130.TabIndex = 1;
            this.label130.Text = "NotchVwRow1";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(3, 115);
            this.label131.Margin = new System.Windows.Forms.Padding(3);
            this.label131.Name = "label131";
            this.label131.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label131.Size = new System.Drawing.Size(92, 16);
            this.label131.TabIndex = 1;
            this.label131.Text = "NotchVwRow2";
            this.label131.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(3, 138);
            this.label132.Margin = new System.Windows.Forms.Padding(3);
            this.label132.Name = "label132";
            this.label132.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label132.Size = new System.Drawing.Size(106, 16);
            this.label132.TabIndex = 1;
            this.label132.Text = "NotchBlackWidth";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(3, 161);
            this.label133.Margin = new System.Windows.Forms.Padding(3);
            this.label133.Name = "label133";
            this.label133.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label133.Size = new System.Drawing.Size(129, 16);
            this.label133.TabIndex = 1;
            this.label133.Text = "InnerDefectMinWidth";
            this.label133.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(3, 184);
            this.label134.Margin = new System.Windows.Forms.Padding(3);
            this.label134.Name = "label134";
            this.label134.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label134.Size = new System.Drawing.Size(122, 16);
            this.label134.TabIndex = 1;
            this.label134.Text = "OutDefectMinWidth";
            this.label134.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_BackWhiteMinGray_2
            // 
            this.nud_BackWhiteMinGray_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BackWhiteMinGray_2.Location = new System.Drawing.Point(206, 23);
            this.nud_BackWhiteMinGray_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_BackWhiteMinGray_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_BackWhiteMinGray_2.Name = "nud_BackWhiteMinGray_2";
            this.nud_BackWhiteMinGray_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BackWhiteMinGray_2.Size = new System.Drawing.Size(64, 23);
            this.nud_BackWhiteMinGray_2.TabIndex = 0;
            this.nud_BackWhiteMinGray_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BackWhiteMinGray_2.Value = new decimal(new int[] {
            223,
            0,
            0,
            0});
            // 
            // nud_DisplayDilation_2
            // 
            this.nud_DisplayDilation_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DisplayDilation_2.Location = new System.Drawing.Point(206, 46);
            this.nud_DisplayDilation_2.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_DisplayDilation_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DisplayDilation_2.Name = "nud_DisplayDilation_2";
            this.nud_DisplayDilation_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DisplayDilation_2.Size = new System.Drawing.Size(64, 23);
            this.nud_DisplayDilation_2.TabIndex = 0;
            this.nud_DisplayDilation_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DisplayDilation_2.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // nud_innerDefectMaxGray_Notch_2
            // 
            this.nud_innerDefectMaxGray_Notch_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_innerDefectMaxGray_Notch_2.Location = new System.Drawing.Point(206, 69);
            this.nud_innerDefectMaxGray_Notch_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_Notch_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_Notch_2.Name = "nud_innerDefectMaxGray_Notch_2";
            this.nud_innerDefectMaxGray_Notch_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_innerDefectMaxGray_Notch_2.Size = new System.Drawing.Size(64, 23);
            this.nud_innerDefectMaxGray_Notch_2.TabIndex = 0;
            this.nud_innerDefectMaxGray_Notch_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_innerDefectMaxGray_Notch_2.Value = new decimal(new int[] {
            79,
            0,
            0,
            0});
            // 
            // nud_NotchVwRow1_2
            // 
            this.nud_NotchVwRow1_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchVwRow1_2.Location = new System.Drawing.Point(206, 92);
            this.nud_NotchVwRow1_2.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_NotchVwRow1_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchVwRow1_2.Name = "nud_NotchVwRow1_2";
            this.nud_NotchVwRow1_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchVwRow1_2.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchVwRow1_2.TabIndex = 0;
            this.nud_NotchVwRow1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchVwRow1_2.Value = new decimal(new int[] {
            148,
            0,
            0,
            0});
            // 
            // nud_NotchVwRow2_2
            // 
            this.nud_NotchVwRow2_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchVwRow2_2.Location = new System.Drawing.Point(206, 115);
            this.nud_NotchVwRow2_2.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_NotchVwRow2_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchVwRow2_2.Name = "nud_NotchVwRow2_2";
            this.nud_NotchVwRow2_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchVwRow2_2.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchVwRow2_2.TabIndex = 0;
            this.nud_NotchVwRow2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchVwRow2_2.Value = new decimal(new int[] {
            546,
            0,
            0,
            0});
            // 
            // nud_NotchBlackWidth_2
            // 
            this.nud_NotchBlackWidth_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchBlackWidth_2.Location = new System.Drawing.Point(206, 138);
            this.nud_NotchBlackWidth_2.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_NotchBlackWidth_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NotchBlackWidth_2.Name = "nud_NotchBlackWidth_2";
            this.nud_NotchBlackWidth_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchBlackWidth_2.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchBlackWidth_2.TabIndex = 0;
            this.nud_NotchBlackWidth_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchBlackWidth_2.Value = new decimal(new int[] {
            71,
            0,
            0,
            0});
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(3, 3);
            this.label135.Margin = new System.Windows.Forms.Padding(3);
            this.label135.Name = "label135";
            this.label135.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label135.Size = new System.Drawing.Size(91, 14);
            this.label135.TabIndex = 1;
            this.label135.Text = "Notch缺陷參數";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_InnerDefectMinWidth_2
            // 
            this.nud_InnerDefectMinWidth_2.DecimalPlaces = 1;
            this.nud_InnerDefectMinWidth_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InnerDefectMinWidth_2.Location = new System.Drawing.Point(206, 161);
            this.nud_InnerDefectMinWidth_2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_InnerDefectMinWidth_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_InnerDefectMinWidth_2.Name = "nud_InnerDefectMinWidth_2";
            this.nud_InnerDefectMinWidth_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerDefectMinWidth_2.Size = new System.Drawing.Size(64, 23);
            this.nud_InnerDefectMinWidth_2.TabIndex = 0;
            this.nud_InnerDefectMinWidth_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InnerDefectMinWidth_2.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_OutDefectMinWidth_2
            // 
            this.nud_OutDefectMinWidth_2.DecimalPlaces = 1;
            this.nud_OutDefectMinWidth_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_OutDefectMinWidth_2.Location = new System.Drawing.Point(206, 184);
            this.nud_OutDefectMinWidth_2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_OutDefectMinWidth_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_OutDefectMinWidth_2.Name = "nud_OutDefectMinWidth_2";
            this.nud_OutDefectMinWidth_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_OutDefectMinWidth_2.Size = new System.Drawing.Size(64, 23);
            this.nud_OutDefectMinWidth_2.TabIndex = 0;
            this.nud_OutDefectMinWidth_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_OutDefectMinWidth_2.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox11.BackgroundImage")));
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox11.Location = new System.Drawing.Point(3, 259);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(343, 184);
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            // 
            // btn_TestDefect_2
            // 
            this.btn_TestDefect_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_TestDefect_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestDefect_2.Location = new System.Drawing.Point(3, 689);
            this.btn_TestDefect_2.Name = "btn_TestDefect_2";
            this.btn_TestDefect_2.Size = new System.Drawing.Size(301, 40);
            this.btn_TestDefect_2.TabIndex = 5;
            this.btn_TestDefect_2.Text = "TEST\r\nInspectWaferEdgeDefectAndDrawAi";
            this.btn_TestDefect_2.UseVisualStyleBackColor = false;
            this.btn_TestDefect_2.Click += new System.EventHandler(this.btn_TestDefect_2_Click);
            // 
            // btn_TestNotchDefect_2
            // 
            this.btn_TestNotchDefect_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_TestNotchDefect_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_TestNotchDefect_2.Location = new System.Drawing.Point(354, 689);
            this.btn_TestNotchDefect_2.Name = "btn_TestNotchDefect_2";
            this.btn_TestNotchDefect_2.Size = new System.Drawing.Size(285, 40);
            this.btn_TestNotchDefect_2.TabIndex = 5;
            this.btn_TestNotchDefect_2.Text = "TEST\r\nInspectNotchDefect_v2\r\n";
            this.btn_TestNotchDefect_2.UseVisualStyleBackColor = false;
            this.btn_TestNotchDefect_2.Click += new System.EventHandler(this.btn_TestNotchDefect_2_Click);
            // 
            // hctrl_NotchImg_2
            // 
            this.hctrl_NotchImg_2.AllowDrop = true;
            this.hctrl_NotchImg_2.BackColor = System.Drawing.Color.Black;
            this.hctrl_NotchImg_2.FontSizeThreshold = 8;
            this.hctrl_NotchImg_2.ImageBuffer.Columns = 1;
            this.hctrl_NotchImg_2.ImageBuffer.Height = 480;
            this.hctrl_NotchImg_2.ImageBuffer.Heights = 480;
            this.hctrl_NotchImg_2.ImageBuffer.KeyObj = ((object)(resources.GetObject("resource.KeyObj12")));
            this.hctrl_NotchImg_2.ImageBuffer.RawImage = null;
            this.hctrl_NotchImg_2.ImageBuffer.Rows = 1;
            this.hctrl_NotchImg_2.ImageBuffer.Width = 640;
            this.hctrl_NotchImg_2.ImageBuffer.Widths = 640;
            this.hctrl_NotchImg_2.IsDispCenterCross = false;
            this.hctrl_NotchImg_2.IsDispHObject = true;
            this.hctrl_NotchImg_2.IsDispROIFrameFontInfo = true;
            this.hctrl_NotchImg_2.IsLockGetMposition = false;
            this.hctrl_NotchImg_2.IsLockMouseOperation = false;
            this.hctrl_NotchImg_2.IsUseMenuByMouseRightButton = true;
            this.hctrl_NotchImg_2.KeyCtrlPressStatus = false;
            this.hctrl_NotchImg_2.Location = new System.Drawing.Point(351, 24);
            this.hctrl_NotchImg_2.Margin = new System.Windows.Forms.Padding(0);
            this.hctrl_NotchImg_2.MaxZoom = 100F;
            this.hctrl_NotchImg_2.MinZoom = 0.01F;
            this.hctrl_NotchImg_2.Name = "hctrl_NotchImg_2";
            this.hctrl_NotchImg_2.ROIController.ActiveROIIndex = -1;
            this.hctrl_NotchImg_2.ROIFontSize = 18;
            this.hctrl_NotchImg_2.ROIFontSizeThreshold = 10;
            this.hctrl_NotchImg_2.ROIFontZoomMode = AOISystem.Halcon.Controls.FontZoomMode.Constant;
            this.tableLayoutPanel20.SetRowSpan(this.hctrl_NotchImg_2, 2);
            this.hctrl_NotchImg_2.ScrollBarEnable = false;
            this.hctrl_NotchImg_2.Size = new System.Drawing.Size(298, 376);
            this.hctrl_NotchImg_2.TabIndex = 12;
            this.hctrl_NotchImg_2.Zoom = 0.01F;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel22, 1, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 449);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(345, 234);
            this.tableLayoutPanel25.TabIndex = 16;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.06061F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.93939F));
            this.tableLayoutPanel26.Controls.Add(this.label106, 0, 1);
            this.tableLayoutPanel26.Controls.Add(this.label152, 0, 2);
            this.tableLayoutPanel26.Controls.Add(this.nud_ROIColumn_2, 1, 1);
            this.tableLayoutPanel26.Controls.Add(this.nud_DarkLightThreshold_2, 1, 2);
            this.tableLayoutPanel26.Controls.Add(this.label153, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.label154, 0, 3);
            this.tableLayoutPanel26.Controls.Add(this.label155, 0, 4);
            this.tableLayoutPanel26.Controls.Add(this.lab_Dark_DarkThres_2, 0, 5);
            this.tableLayoutPanel26.Controls.Add(this.label158, 0, 6);
            this.tableLayoutPanel26.Controls.Add(this.label159, 0, 7);
            this.tableLayoutPanel26.Controls.Add(this.nud_light_DarkThres_2, 1, 3);
            this.tableLayoutPanel26.Controls.Add(this.nud_DarkMax_2, 1, 4);
            this.tableLayoutPanel26.Controls.Add(this.nud_Dark_DarkThres_2, 1, 5);
            this.tableLayoutPanel26.Controls.Add(this.nud_Dark_LightThres_2, 1, 6);
            this.tableLayoutPanel26.Controls.Add(this.nud_WhiteThres_2, 1, 7);
            this.tableLayoutPanel26.Controls.Add(this.label160, 0, 8);
            this.tableLayoutPanel26.Controls.Add(this.lab_MinDefectSize_2, 0, 9);
            this.tableLayoutPanel26.Controls.Add(this.nud_MinAreaSize_2, 1, 8);
            this.tableLayoutPanel26.Controls.Add(this.nud_MinDefectSize_2, 1, 9);
            this.tableLayoutPanel26.Controls.Add(this.ckb_DefectV2_2, 1, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 10;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(165, 228);
            this.tableLayoutPanel26.TabIndex = 15;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(3, 23);
            this.label106.Margin = new System.Windows.Forms.Padding(3);
            this.label106.Name = "label106";
            this.label106.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label106.Size = new System.Drawing.Size(73, 16);
            this.label106.TabIndex = 1;
            this.label106.Text = "ROIColumn";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(3, 46);
            this.label152.Margin = new System.Windows.Forms.Padding(3);
            this.label152.Name = "label152";
            this.label152.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label152.Size = new System.Drawing.Size(99, 17);
            this.label152.TabIndex = 1;
            this.label152.Text = "DarkLightThreshold";
            this.label152.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_ROIColumn_2
            // 
            this.nud_ROIColumn_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_ROIColumn_2.Location = new System.Drawing.Point(112, 23);
            this.nud_ROIColumn_2.Maximum = new decimal(new int[] {
            251,
            0,
            0,
            0});
            this.nud_ROIColumn_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_ROIColumn_2.Name = "nud_ROIColumn_2";
            this.nud_ROIColumn_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_ROIColumn_2.Size = new System.Drawing.Size(50, 23);
            this.nud_ROIColumn_2.TabIndex = 0;
            this.nud_ROIColumn_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_ROIColumn_2.Value = new decimal(new int[] {
            130,
            0,
            0,
            0});
            // 
            // nud_DarkLightThreshold_2
            // 
            this.nud_DarkLightThreshold_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DarkLightThreshold_2.Location = new System.Drawing.Point(112, 46);
            this.nud_DarkLightThreshold_2.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_DarkLightThreshold_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DarkLightThreshold_2.Name = "nud_DarkLightThreshold_2";
            this.nud_DarkLightThreshold_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DarkLightThreshold_2.Size = new System.Drawing.Size(50, 23);
            this.nud_DarkLightThreshold_2.TabIndex = 0;
            this.nud_DarkLightThreshold_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DarkLightThreshold_2.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(3, 3);
            this.label153.Margin = new System.Windows.Forms.Padding(3);
            this.label153.Name = "label153";
            this.label153.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label153.Size = new System.Drawing.Size(84, 14);
            this.label153.TabIndex = 1;
            this.label153.Text = "缺陷參數 V2.0";
            this.label153.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(3, 69);
            this.label154.Margin = new System.Windows.Forms.Padding(3);
            this.label154.Name = "label154";
            this.label154.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label154.Size = new System.Drawing.Size(94, 16);
            this.label154.TabIndex = 1;
            this.label154.Text = "light_DarkThres";
            this.label154.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(3, 92);
            this.label155.Margin = new System.Windows.Forms.Padding(3);
            this.label155.Name = "label155";
            this.label155.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label155.Size = new System.Drawing.Size(59, 16);
            this.label155.TabIndex = 1;
            this.label155.Text = "DarkMax";
            this.label155.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_Dark_DarkThres_2
            // 
            this.lab_Dark_DarkThres_2.AutoSize = true;
            this.lab_Dark_DarkThres_2.Location = new System.Drawing.Point(3, 115);
            this.lab_Dark_DarkThres_2.Margin = new System.Windows.Forms.Padding(3);
            this.lab_Dark_DarkThres_2.Name = "lab_Dark_DarkThres_2";
            this.lab_Dark_DarkThres_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_Dark_DarkThres_2.Size = new System.Drawing.Size(95, 16);
            this.lab_Dark_DarkThres_2.TabIndex = 1;
            this.lab_Dark_DarkThres_2.Text = "Dark_DarkThres";
            this.lab_Dark_DarkThres_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(3, 138);
            this.label158.Margin = new System.Windows.Forms.Padding(3);
            this.label158.Name = "label158";
            this.label158.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label158.Size = new System.Drawing.Size(97, 16);
            this.label158.TabIndex = 1;
            this.label158.Text = "Dark_LightThres";
            this.label158.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(3, 161);
            this.label159.Margin = new System.Windows.Forms.Padding(3);
            this.label159.Name = "label159";
            this.label159.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label159.Size = new System.Drawing.Size(71, 16);
            this.label159.TabIndex = 1;
            this.label159.Text = "WhiteThres";
            this.label159.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_light_DarkThres_2
            // 
            this.nud_light_DarkThres_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_light_DarkThres_2.Location = new System.Drawing.Point(112, 69);
            this.nud_light_DarkThres_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_light_DarkThres_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_light_DarkThres_2.Name = "nud_light_DarkThres_2";
            this.nud_light_DarkThres_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_light_DarkThres_2.Size = new System.Drawing.Size(50, 23);
            this.nud_light_DarkThres_2.TabIndex = 0;
            this.nud_light_DarkThres_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_light_DarkThres_2.Value = new decimal(new int[] {
            45,
            0,
            0,
            0});
            // 
            // nud_DarkMax_2
            // 
            this.nud_DarkMax_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DarkMax_2.Location = new System.Drawing.Point(112, 92);
            this.nud_DarkMax_2.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_DarkMax_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_DarkMax_2.Name = "nud_DarkMax_2";
            this.nud_DarkMax_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_DarkMax_2.Size = new System.Drawing.Size(50, 23);
            this.nud_DarkMax_2.TabIndex = 0;
            this.nud_DarkMax_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_DarkMax_2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // nud_Dark_DarkThres_2
            // 
            this.nud_Dark_DarkThres_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Dark_DarkThres_2.Location = new System.Drawing.Point(112, 115);
            this.nud_Dark_DarkThres_2.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_Dark_DarkThres_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_Dark_DarkThres_2.Name = "nud_Dark_DarkThres_2";
            this.nud_Dark_DarkThres_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Dark_DarkThres_2.Size = new System.Drawing.Size(50, 23);
            this.nud_Dark_DarkThres_2.TabIndex = 0;
            this.nud_Dark_DarkThres_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Dark_DarkThres_2.Value = new decimal(new int[] {
            35,
            0,
            0,
            0});
            // 
            // nud_Dark_LightThres_2
            // 
            this.nud_Dark_LightThres_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Dark_LightThres_2.Location = new System.Drawing.Point(112, 138);
            this.nud_Dark_LightThres_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_Dark_LightThres_2.Name = "nud_Dark_LightThres_2";
            this.nud_Dark_LightThres_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Dark_LightThres_2.Size = new System.Drawing.Size(50, 23);
            this.nud_Dark_LightThres_2.TabIndex = 0;
            this.nud_Dark_LightThres_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Dark_LightThres_2.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // nud_WhiteThres_2
            // 
            this.nud_WhiteThres_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_WhiteThres_2.Location = new System.Drawing.Point(112, 161);
            this.nud_WhiteThres_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_WhiteThres_2.Name = "nud_WhiteThres_2";
            this.nud_WhiteThres_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_WhiteThres_2.Size = new System.Drawing.Size(50, 23);
            this.nud_WhiteThres_2.TabIndex = 0;
            this.nud_WhiteThres_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_WhiteThres_2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(3, 184);
            this.label160.Margin = new System.Windows.Forms.Padding(3);
            this.label160.Name = "label160";
            this.label160.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label160.Size = new System.Drawing.Size(79, 16);
            this.label160.TabIndex = 1;
            this.label160.Text = "MinAreaSize";
            this.label160.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_MinDefectSize_2
            // 
            this.lab_MinDefectSize_2.AutoSize = true;
            this.lab_MinDefectSize_2.Location = new System.Drawing.Point(3, 207);
            this.lab_MinDefectSize_2.Margin = new System.Windows.Forms.Padding(3);
            this.lab_MinDefectSize_2.Name = "lab_MinDefectSize_2";
            this.lab_MinDefectSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_MinDefectSize_2.Size = new System.Drawing.Size(90, 16);
            this.lab_MinDefectSize_2.TabIndex = 1;
            this.lab_MinDefectSize_2.Text = "MinDefectSize";
            this.lab_MinDefectSize_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_MinAreaSize_2
            // 
            this.nud_MinAreaSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_MinAreaSize_2.Location = new System.Drawing.Point(112, 184);
            this.nud_MinAreaSize_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_MinAreaSize_2.Name = "nud_MinAreaSize_2";
            this.nud_MinAreaSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinAreaSize_2.Size = new System.Drawing.Size(50, 23);
            this.nud_MinAreaSize_2.TabIndex = 0;
            this.nud_MinAreaSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinAreaSize_2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_MinDefectSize_2
            // 
            this.nud_MinDefectSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_MinDefectSize_2.Location = new System.Drawing.Point(112, 207);
            this.nud_MinDefectSize_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_MinDefectSize_2.Name = "nud_MinDefectSize_2";
            this.nud_MinDefectSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_MinDefectSize_2.Size = new System.Drawing.Size(50, 23);
            this.nud_MinDefectSize_2.TabIndex = 0;
            this.nud_MinDefectSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_MinDefectSize_2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // ckb_DefectV2_2
            // 
            this.ckb_DefectV2_2.AutoSize = true;
            this.ckb_DefectV2_2.Checked = true;
            this.ckb_DefectV2_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckb_DefectV2_2.Location = new System.Drawing.Point(112, 3);
            this.ckb_DefectV2_2.Name = "ckb_DefectV2_2";
            this.ckb_DefectV2_2.Size = new System.Drawing.Size(15, 14);
            this.ckb_DefectV2_2.TabIndex = 2;
            this.ckb_DefectV2_2.UseVisualStyleBackColor = true;
            this.ckb_DefectV2_2.CheckedChanged += new System.EventHandler(this.ckb_DefectV2_2_CheckedChanged);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.72789F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.27211F));
            this.tableLayoutPanel22.Controls.Add(this.label173, 0, 9);
            this.tableLayoutPanel22.Controls.Add(this.label136, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.label137, 0, 2);
            this.tableLayoutPanel22.Controls.Add(this.nud_RoiWidthToBevelCenter_2, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.nud_BevelWidth_2, 1, 2);
            this.tableLayoutPanel22.Controls.Add(this.label144, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.ckb_DefectV1_2, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label139, 0, 3);
            this.tableLayoutPanel22.Controls.Add(this.nud_InnerThresholdMax_2, 1, 3);
            this.tableLayoutPanel22.Controls.Add(this.nud_edgeDefectMaxGray_2, 1, 9);
            this.tableLayoutPanel22.Controls.Add(this.label143, 0, 8);
            this.tableLayoutPanel22.Controls.Add(this.nud_innerDefectMaxGray_2, 1, 8);
            this.tableLayoutPanel22.Controls.Add(this.label141, 0, 7);
            this.tableLayoutPanel22.Controls.Add(this.nud_InnerDefectAreaSize_2, 1, 7);
            this.tableLayoutPanel22.Controls.Add(this.label140, 0, 6);
            this.tableLayoutPanel22.Controls.Add(this.nud_AiMinGray_2, 1, 6);
            this.tableLayoutPanel22.Controls.Add(this.label142, 0, 5);
            this.tableLayoutPanel22.Controls.Add(this.nud_AiDefectSize_2, 1, 5);
            this.tableLayoutPanel22.Location = new System.Drawing.Point(175, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 10;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(166, 228);
            this.tableLayoutPanel22.TabIndex = 3;
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Location = new System.Drawing.Point(3, 207);
            this.label173.Margin = new System.Windows.Forms.Padding(3);
            this.label173.Name = "label173";
            this.label173.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label173.Size = new System.Drawing.Size(109, 18);
            this.label173.TabIndex = 3;
            this.label173.Text = "EdgeDefectMaxGray";
            this.label173.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(3, 23);
            this.label136.Margin = new System.Windows.Forms.Padding(3);
            this.label136.Name = "label136";
            this.label136.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label136.Size = new System.Drawing.Size(106, 17);
            this.label136.TabIndex = 1;
            this.label136.Text = "RoiWidthToBevelCenter";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(3, 46);
            this.label137.Margin = new System.Windows.Forms.Padding(3);
            this.label137.Name = "label137";
            this.label137.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label137.Size = new System.Drawing.Size(72, 16);
            this.label137.TabIndex = 1;
            this.label137.Text = "BevelWidth";
            this.label137.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_RoiWidthToBevelCenter_2
            // 
            this.nud_RoiWidthToBevelCenter_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_RoiWidthToBevelCenter_2.Location = new System.Drawing.Point(118, 23);
            this.nud_RoiWidthToBevelCenter_2.Maximum = new decimal(new int[] {
            251,
            0,
            0,
            0});
            this.nud_RoiWidthToBevelCenter_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_RoiWidthToBevelCenter_2.Name = "nud_RoiWidthToBevelCenter_2";
            this.nud_RoiWidthToBevelCenter_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_RoiWidthToBevelCenter_2.Size = new System.Drawing.Size(45, 23);
            this.nud_RoiWidthToBevelCenter_2.TabIndex = 0;
            this.nud_RoiWidthToBevelCenter_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_RoiWidthToBevelCenter_2.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // nud_BevelWidth_2
            // 
            this.nud_BevelWidth_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BevelWidth_2.Location = new System.Drawing.Point(118, 46);
            this.nud_BevelWidth_2.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_BevelWidth_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_BevelWidth_2.Name = "nud_BevelWidth_2";
            this.nud_BevelWidth_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BevelWidth_2.Size = new System.Drawing.Size(45, 23);
            this.nud_BevelWidth_2.TabIndex = 0;
            this.nud_BevelWidth_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BevelWidth_2.Value = new decimal(new int[] {
            27,
            0,
            0,
            0});
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(3, 3);
            this.label144.Margin = new System.Windows.Forms.Padding(3);
            this.label144.Name = "label144";
            this.label144.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label144.Size = new System.Drawing.Size(56, 14);
            this.label144.TabIndex = 1;
            this.label144.Text = "缺陷參數";
            this.label144.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ckb_DefectV1_2
            // 
            this.ckb_DefectV1_2.AutoSize = true;
            this.ckb_DefectV1_2.Location = new System.Drawing.Point(118, 3);
            this.ckb_DefectV1_2.Name = "ckb_DefectV1_2";
            this.ckb_DefectV1_2.Size = new System.Drawing.Size(15, 14);
            this.ckb_DefectV1_2.TabIndex = 2;
            this.ckb_DefectV1_2.UseVisualStyleBackColor = true;
            this.ckb_DefectV1_2.CheckedChanged += new System.EventHandler(this.ckb_DefectV1_2_CheckedChanged);
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(3, 69);
            this.label139.Margin = new System.Windows.Forms.Padding(3);
            this.label139.Name = "label139";
            this.label139.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label139.Size = new System.Drawing.Size(104, 17);
            this.label139.TabIndex = 1;
            this.label139.Text = "InnerThresholdMax[Auto:-1]";
            this.label139.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_InnerThresholdMax_2
            // 
            this.nud_InnerThresholdMax_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InnerThresholdMax_2.Location = new System.Drawing.Point(118, 69);
            this.nud_InnerThresholdMax_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_InnerThresholdMax_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_InnerThresholdMax_2.Name = "nud_InnerThresholdMax_2";
            this.nud_InnerThresholdMax_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerThresholdMax_2.Size = new System.Drawing.Size(45, 23);
            this.nud_InnerThresholdMax_2.TabIndex = 0;
            this.nud_InnerThresholdMax_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_InnerThresholdMax_2.Value = new decimal(new int[] {
            230,
            0,
            0,
            0});
            // 
            // nud_edgeDefectMaxGray_2
            // 
            this.nud_edgeDefectMaxGray_2.Location = new System.Drawing.Point(118, 207);
            this.nud_edgeDefectMaxGray_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_edgeDefectMaxGray_2.Name = "nud_edgeDefectMaxGray_2";
            this.nud_edgeDefectMaxGray_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_edgeDefectMaxGray_2.Size = new System.Drawing.Size(45, 23);
            this.nud_edgeDefectMaxGray_2.TabIndex = 4;
            this.nud_edgeDefectMaxGray_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_edgeDefectMaxGray_2.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(3, 184);
            this.label143.Margin = new System.Windows.Forms.Padding(3);
            this.label143.Name = "label143";
            this.label143.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label143.Size = new System.Drawing.Size(107, 17);
            this.label143.TabIndex = 1;
            this.label143.Text = "InnerDefectMaxGray (不檢查:0)";
            this.label143.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_innerDefectMaxGray_2
            // 
            this.nud_innerDefectMaxGray_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_innerDefectMaxGray_2.Location = new System.Drawing.Point(118, 184);
            this.nud_innerDefectMaxGray_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_innerDefectMaxGray_2.Name = "nud_innerDefectMaxGray_2";
            this.nud_innerDefectMaxGray_2.ReadOnly = true;
            this.nud_innerDefectMaxGray_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_innerDefectMaxGray_2.Size = new System.Drawing.Size(45, 23);
            this.nud_innerDefectMaxGray_2.TabIndex = 0;
            this.nud_innerDefectMaxGray_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(3, 161);
            this.label141.Margin = new System.Windows.Forms.Padding(3);
            this.label141.Name = "label141";
            this.label141.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label141.Size = new System.Drawing.Size(109, 17);
            this.label141.TabIndex = 1;
            this.label141.Text = "InnerDefectAreaSize";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_InnerDefectAreaSize_2
            // 
            this.nud_InnerDefectAreaSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_InnerDefectAreaSize_2.Location = new System.Drawing.Point(118, 161);
            this.nud_InnerDefectAreaSize_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_InnerDefectAreaSize_2.Name = "nud_InnerDefectAreaSize_2";
            this.nud_InnerDefectAreaSize_2.ReadOnly = true;
            this.nud_InnerDefectAreaSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_InnerDefectAreaSize_2.Size = new System.Drawing.Size(45, 23);
            this.nud_InnerDefectAreaSize_2.TabIndex = 0;
            this.nud_InnerDefectAreaSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(3, 138);
            this.label140.Margin = new System.Windows.Forms.Padding(3);
            this.label140.Name = "label140";
            this.label140.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label140.Size = new System.Drawing.Size(67, 16);
            this.label140.TabIndex = 1;
            this.label140.Text = "AiMinGray";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AiMinGray_2
            // 
            this.nud_AiMinGray_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AiMinGray_2.Location = new System.Drawing.Point(118, 138);
            this.nud_AiMinGray_2.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.nud_AiMinGray_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_AiMinGray_2.Name = "nud_AiMinGray_2";
            this.nud_AiMinGray_2.ReadOnly = true;
            this.nud_AiMinGray_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AiMinGray_2.Size = new System.Drawing.Size(45, 23);
            this.nud_AiMinGray_2.TabIndex = 0;
            this.nud_AiMinGray_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AiMinGray_2.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(3, 115);
            this.label142.Margin = new System.Windows.Forms.Padding(3);
            this.label142.Name = "label142";
            this.label142.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label142.Size = new System.Drawing.Size(79, 16);
            this.label142.TabIndex = 1;
            this.label142.Text = "AiDefectSize";
            this.label142.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AiDefectSize_2
            // 
            this.nud_AiDefectSize_2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AiDefectSize_2.Location = new System.Drawing.Point(118, 115);
            this.nud_AiDefectSize_2.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.nud_AiDefectSize_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_AiDefectSize_2.Name = "nud_AiDefectSize_2";
            this.nud_AiDefectSize_2.ReadOnly = true;
            this.nud_AiDefectSize_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AiDefectSize_2.Size = new System.Drawing.Size(45, 23);
            this.nud_AiDefectSize_2.TabIndex = 0;
            this.nud_AiDefectSize_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AiDefectSize_2.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel16.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.690998F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 93.30901F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1151, 883);
            this.tableLayoutPanel16.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.txb_recipePath);
            this.panel4.Controls.Add(this.label174);
            this.panel4.Controls.Add(this.btn_setRecipe);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1134, 53);
            this.panel4.TabIndex = 3;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label39.Location = new System.Drawing.Point(169, 19);
            this.label39.Margin = new System.Windows.Forms.Padding(3);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label39.Size = new System.Drawing.Size(51, 15);
            this.label39.TabIndex = 14;
            this.label39.Text = "參數路徑";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txb_recipePath
            // 
            this.txb_recipePath.Location = new System.Drawing.Point(226, 17);
            this.txb_recipePath.Name = "txb_recipePath";
            this.txb_recipePath.Size = new System.Drawing.Size(902, 22);
            this.txb_recipePath.TabIndex = 13;
            this.txb_recipePath.Text = "C:\\Johnny\\Salmon\\202307思惠交接\\03 參數設定程式碼\\MeasureWaferRecipe 20230629\\MeasureWaferRe" +
    "cipe\\bin\\Debug\\AlgorithmConfig.xml";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label174.Location = new System.Drawing.Point(9, 3);
            this.label174.Margin = new System.Windows.Forms.Padding(3);
            this.label174.Name = "label174";
            this.label174.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label174.Size = new System.Drawing.Size(51, 15);
            this.label174.TabIndex = 7;
            this.label174.Text = "設定參數";
            this.label174.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_setRecipe
            // 
            this.btn_setRecipe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_setRecipe.BackgroundImage")));
            this.btn_setRecipe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_setRecipe.Location = new System.Drawing.Point(66, 3);
            this.btn_setRecipe.Name = "btn_setRecipe";
            this.btn_setRecipe.Size = new System.Drawing.Size(51, 50);
            this.btn_setRecipe.TabIndex = 6;
            this.btn_setRecipe.UseVisualStyleBackColor = true;
            this.btn_setRecipe.Click += new System.EventHandler(this.btn_setRecipe_Click);
            // 
            // TeachForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 883);
            this.Controls.Add(this.tableLayoutPanel16);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "TeachForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Algorithm Teach Form";
            this.Load += new System.EventHandler(this.TeachForm_Load);
            this.tbp_Edge.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tbc_EdgeType.ResumeLayout(false);
            this.tbp_TypeB.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GrayMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeRotateAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_exAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_hvScaleW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_hvScaleH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CMeasureNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeLamp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tbl_MeasureResult.ResumeLayout(false);
            this.tbl_MeasureResult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Lower)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tbp_Demo.ResumeLayout(false);
            this.tbp_Demo.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DiameterB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeIndex)).EndInit();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DiameterT)).EndInit();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Vr2)).EndInit();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_t)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeAngle)).EndInit();
            this.tbp_Notch.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchLamp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchGrayMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b2Ang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PinRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR12Angle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b1Ang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchRotate)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Lower)).EndInit();
            this.tbp_Defect_1.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_shiftAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_notchPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_totalAreaNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_catchAreaNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DefectLamp_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PixelSize_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InDistance_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropSize_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropNotchWidth_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinScore_1)).EndInit();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectCropImg_1)).EndInit();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BackWhiteMinGray_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DisplayDilation_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_Notch_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchBlackWidth_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectMinWidth_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OutDefectMinWidth_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RoiWidthToBevelCenter_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BevelWidth_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiDefectSize_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiMinGray_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectAreaSize_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerThresholdMax_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_EdgeDefectAreaSize_1)).EndInit();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ROIColumn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkLightThreshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_light_DarkThres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_DarkThres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_LightThres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_WhiteThres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinAreaSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinDefectSize)).EndInit();
            this.tbp_Defect_2.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DefectLamp_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PixelSize_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InDistance_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropSize_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CropNotchWidth_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinScore_2)).EndInit();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectCropImg_2)).EndInit();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BackWhiteMinGray_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DisplayDilation_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_Notch_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchVwRow2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchBlackWidth_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectMinWidth_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OutDefectMinWidth_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ROIColumn_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkLightThreshold_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_light_DarkThres_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DarkMax_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_DarkThres_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dark_LightThres_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_WhiteThres_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinAreaSize_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MinDefectSize_2)).EndInit();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_RoiWidthToBevelCenter_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BevelWidth_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerThresholdMax_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_edgeDefectMaxGray_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_innerDefectMaxGray_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_InnerDefectAreaSize_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiMinGray_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AiDefectSize_2)).EndInit();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tbp_Edge;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btn_LoadImage_Edge;
        private System.Windows.Forms.Button btn_SaveRecipe_Edge;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btn_MasureTest_Edge;
        private System.Windows.Forms.TabControl tbc_EdgeType;
        private System.Windows.Forms.TabPage tbp_TypeB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nud_GrayMax;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nud_bu2Ratio;
        private System.Windows.Forms.NumericUpDown nud_bv2Ratio;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_bu1Ratio;
        private System.Windows.Forms.NumericUpDown nud_bv1Ratio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nud_AngleStart1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_AngleTop1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nud_AngleStart2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_AngleTop2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TableLayoutPanel tbl_MeasureResult;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nud_A1Upper;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txb_A1;
        private System.Windows.Forms.TextBox txb_A2;
        private System.Windows.Forms.TextBox txb_B1;
        private System.Windows.Forms.TextBox txb_B2;
        private System.Windows.Forms.TextBox txb_R1;
        private System.Windows.Forms.TextBox txb_R2;
        private System.Windows.Forms.TextBox txb_t;
        private System.Windows.Forms.TextBox txb_Ang1;
        private System.Windows.Forms.TextBox txb_Ang2;
        private System.Windows.Forms.TextBox txb_BC;
        private System.Windows.Forms.TextBox txb_C2;
        private System.Windows.Forms.TextBox txb_C1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown nud_A1Lower;
        private System.Windows.Forms.NumericUpDown nud_A2Upper;
        private System.Windows.Forms.NumericUpDown nud_A2Lower;
        private System.Windows.Forms.NumericUpDown nud_B1Upper;
        private System.Windows.Forms.NumericUpDown nud_B2Upper;
        private System.Windows.Forms.NumericUpDown nud_B2Lower;
        private System.Windows.Forms.NumericUpDown nud_B1Lower;
        private System.Windows.Forms.NumericUpDown nud_R1Upper;
        private System.Windows.Forms.NumericUpDown nud_R2Upper;
        private System.Windows.Forms.NumericUpDown nud_tUpper;
        private System.Windows.Forms.NumericUpDown nud_tLower;
        private System.Windows.Forms.NumericUpDown nud_R2Lower;
        private System.Windows.Forms.NumericUpDown nud_R1Lower;
        private System.Windows.Forms.NumericUpDown nud_BCUpper;
        private System.Windows.Forms.NumericUpDown nud_BCLower;
        private System.Windows.Forms.NumericUpDown nud_Ang1Upper;
        private System.Windows.Forms.NumericUpDown nud_Ang1Lower;
        private System.Windows.Forms.NumericUpDown nud_Ang2Upper;
        private System.Windows.Forms.NumericUpDown nud_Ang2Lower;
        private System.Windows.Forms.NumericUpDown nud_C1Upper;
        private System.Windows.Forms.NumericUpDown nud_C2Upper;
        private System.Windows.Forms.NumericUpDown nud_C1Lower;
        private System.Windows.Forms.NumericUpDown nud_C2Lower;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TabPage tbp_Notch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown nud_NotchGrayMax;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown nud_VrWidth1;
        private System.Windows.Forms.NumericUpDown nud_PinRadius;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.NumericUpDown nud_u1Ratio;
        private System.Windows.Forms.NumericUpDown nud_u2Ratio;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown nud_VrWidth2;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.NumericUpDown nud_b2Ang;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.NumericUpDown nud_VR12Angle;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown nud_b1Ang;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btn_LoadImage_Notch;
        private System.Windows.Forms.Button btn_SaveRecipe_Notch;
        private System.Windows.Forms.Button btn_LoadRecipe_Notch;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button btn_MasureTest_Notch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.NumericUpDown nud_VhUpper;
        private System.Windows.Forms.TextBox txb_Vh;
        private System.Windows.Forms.TextBox txb_Vw;
        private System.Windows.Forms.TextBox txb_Vr;
        private System.Windows.Forms.TextBox txb_AngV;
        private System.Windows.Forms.TextBox txb_P1;
        private System.Windows.Forms.TextBox txb_P2;
        private System.Windows.Forms.TextBox txb_VR1;
        private System.Windows.Forms.TextBox txb_VR2;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.NumericUpDown nud_VhLower;
        private System.Windows.Forms.NumericUpDown nud_VR1Upper;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown nud_VwUpper;
        private System.Windows.Forms.NumericUpDown nud_VwLower;
        private System.Windows.Forms.NumericUpDown nud_VrUpper;
        private System.Windows.Forms.NumericUpDown nud_VrLower;
        private System.Windows.Forms.NumericUpDown nud_AngVUpper;
        private System.Windows.Forms.NumericUpDown nud_P1Upper;
        private System.Windows.Forms.NumericUpDown nud_P1Lower;
        private System.Windows.Forms.NumericUpDown nud_P2Upper;
        private System.Windows.Forms.NumericUpDown nud_P2Lower;
        private System.Windows.Forms.NumericUpDown nud_AngVLower;
        private System.Windows.Forms.NumericUpDown nud_VR1Lower;
        private System.Windows.Forms.NumericUpDown nud_VR2Upper;
        private System.Windows.Forms.NumericUpDown nud_VR2Lower;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TabPage tbp_Defect_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button btn_LoadImage_Defect_1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_loadModel_1;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.NumericUpDown nud_RoiWidthToBevelCenter_1;
        private System.Windows.Forms.NumericUpDown nud_BevelWidth_1;
        private System.Windows.Forms.NumericUpDown nud_InnerThresholdMax_1;
        private System.Windows.Forms.NumericUpDown nud_AiDefectSize_1;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.NumericUpDown nud_AiMinGray_1;
        private System.Windows.Forms.NumericUpDown nud_InnerDefectAreaSize_1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button btn_TestCropNotch_1;
        private System.Windows.Forms.Button btn_TestDefect_1;
        private System.Windows.Forms.NumericUpDown nud_PixelSize_1;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.NumericUpDown nud_InDistance_1;
        private System.Windows.Forms.NumericUpDown nud_CropSize_1;
        private System.Windows.Forms.NumericUpDown nud_CropNotchWidth_1;
        private System.Windows.Forms.NumericUpDown nud_MinScore_1;
        private System.Windows.Forms.Button btn_CropInspectionImg_1;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txb_EdgeImgPath;
        private AOISystem.Halcon.Controls.HControl hctrl_EdgeView;
        private System.Windows.Forms.TextBox txb_NotchImgPath;
        private AOISystem.Halcon.Controls.HControl hctrl_NotchView;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.NumericUpDown nud_EdgeRotateAngle;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.NumericUpDown nud_NotchRotate;
        private System.Windows.Forms.TextBox txb_model_1;
        private System.Windows.Forms.TextBox txb_ImageRaw_1;
        private AOISystem.Halcon.Controls.HControl hctrl_RawImage_1;
        private AOISystem.Halcon.Controls.HControl hctrl_NotchImg_1;
        private System.Windows.Forms.Label lab_dispNumber_1;
        private System.Windows.Forms.NumericUpDown nud_SelectCropImg_1;
        private AOISystem.Halcon.Controls.HControl hctrl_DefectImg_1;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.NumericUpDown nud_BackWhiteMinGray_1;
        private System.Windows.Forms.NumericUpDown nud_DisplayDilation_1;
        private System.Windows.Forms.NumericUpDown nud_innerDefectMaxGray_Notch_1;
        private System.Windows.Forms.NumericUpDown nud_NotchVwRow1_1;
        private System.Windows.Forms.NumericUpDown nud_NotchVwRow2_1;
        private System.Windows.Forms.NumericUpDown nud_NotchBlackWidth_1;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.NumericUpDown nud_InnerDefectMinWidth_1;
        private System.Windows.Forms.NumericUpDown nud_OutDefectMinWidth_1;
        private System.Windows.Forms.Button btn_TestNotchDefect_1;
        private System.Windows.Forms.NumericUpDown nud_innerDefectMaxGray_1;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown nud_EdgeLamp;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.NumericUpDown nud_NotchLamp;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.NumericUpDown nud_DefectLamp_1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TabPage tbp_Defect_2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.NumericUpDown nud_DefectLamp_2;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label lab_dispNumber_2;
        private AOISystem.Halcon.Controls.HControl hctrl_RawImage_2;
        private System.Windows.Forms.TextBox txb_model_2;
        private System.Windows.Forms.TextBox txb_ImageRaw_2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.NumericUpDown nud_PixelSize_2;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.NumericUpDown nud_InDistance_2;
        private System.Windows.Forms.NumericUpDown nud_CropSize_2;
        private System.Windows.Forms.NumericUpDown nud_CropNotchWidth_2;
        private System.Windows.Forms.NumericUpDown nud_MinScore_2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Button btn_loadModel_2;
        private System.Windows.Forms.Button btn_LoadImage_Defect_2;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Button btn_CropInspectionImg_2;
        private System.Windows.Forms.Button btn_TestCropNotch_2;
        private System.Windows.Forms.NumericUpDown nud_SelectCropImg_2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private AOISystem.Halcon.Controls.HControl hctrl_DefectImg_2;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.NumericUpDown nud_BackWhiteMinGray_2;
        private System.Windows.Forms.NumericUpDown nud_DisplayDilation_2;
        private System.Windows.Forms.NumericUpDown nud_innerDefectMaxGray_Notch_2;
        private System.Windows.Forms.NumericUpDown nud_NotchVwRow1_2;
        private System.Windows.Forms.NumericUpDown nud_NotchVwRow2_2;
        private System.Windows.Forms.NumericUpDown nud_NotchBlackWidth_2;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.NumericUpDown nud_InnerDefectMinWidth_2;
        private System.Windows.Forms.NumericUpDown nud_OutDefectMinWidth_2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.NumericUpDown nud_RoiWidthToBevelCenter_2;
        private System.Windows.Forms.NumericUpDown nud_BevelWidth_2;
        private System.Windows.Forms.NumericUpDown nud_InnerThresholdMax_2;
        private System.Windows.Forms.NumericUpDown nud_AiDefectSize_2;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.NumericUpDown nud_AiMinGray_2;
        private System.Windows.Forms.NumericUpDown nud_InnerDefectAreaSize_2;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.NumericUpDown nud_innerDefectMaxGray_2;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button btn_TestDefect_2;
        private System.Windows.Forms.Button btn_TestNotchDefect_2;
        private AOISystem.Halcon.Controls.HControl hctrl_NotchImg_2;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.NumericUpDown nud_exAngle;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Label lab_hv_ROIColumn;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label lab_light_DarkThres;
        private System.Windows.Forms.NumericUpDown nud_ROIColumn;
        private System.Windows.Forms.NumericUpDown nud_DarkLightThreshold;
        private System.Windows.Forms.NumericUpDown nud_light_DarkThres;
        private System.Windows.Forms.NumericUpDown nud_DarkMax;
        private System.Windows.Forms.Label lab_Dark_DarkThres;
        private System.Windows.Forms.Label lab_Dark_LightThres;
        private System.Windows.Forms.Label lab_DarkMax;
        private System.Windows.Forms.Label lab_WhiteThres;
        private System.Windows.Forms.NumericUpDown nud_Dark_DarkThres;
        private System.Windows.Forms.NumericUpDown nud_Dark_LightThres;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.NumericUpDown nud_WhiteThres;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.NumericUpDown nud_MinAreaSize;
        private System.Windows.Forms.NumericUpDown nud_MinDefectSize;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.CheckBox ckb_DefectV1;
        private System.Windows.Forms.CheckBox ckb_DefectV2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.NumericUpDown nud_ROIColumn_2;
        private System.Windows.Forms.NumericUpDown nud_DarkLightThreshold_2;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label lab_Dark_DarkThres_2;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.NumericUpDown nud_light_DarkThres_2;
        private System.Windows.Forms.NumericUpDown nud_DarkMax_2;
        private System.Windows.Forms.NumericUpDown nud_Dark_DarkThres_2;
        private System.Windows.Forms.NumericUpDown nud_Dark_LightThres_2;
        private System.Windows.Forms.NumericUpDown nud_WhiteThres_2;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label lab_MinDefectSize_2;
        private System.Windows.Forms.NumericUpDown nud_MinAreaSize_2;
        private System.Windows.Forms.NumericUpDown nud_MinDefectSize_2;
        private System.Windows.Forms.CheckBox ckb_DefectV2_2;
        private System.Windows.Forms.CheckBox ckb_DefectV1_2;
        private System.Windows.Forms.NumericUpDown nud_hvScaleW;
        private System.Windows.Forms.NumericUpDown nud_hvScaleH;
        private System.Windows.Forms.NumericUpDown nud_CMeasureNumber;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.NumericUpDown nud_notchPosition;
        private System.Windows.Forms.NumericUpDown nud_catchAreaNum;
        private System.Windows.Forms.NumericUpDown nud_totalAreaNum;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.NumericUpDown nud_shiftAngle;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.TextBox textBox_catchImage;
        private System.Windows.Forms.TextBox txb_EdgeImgFolder;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Button btn_LoadFolder_Edge;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.NumericUpDown nud_EdgeDefectAreaSize_1;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.NumericUpDown nud_edgeDefectMaxGray_2;
        private System.Windows.Forms.TabPage tbp_Demo;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Button btn_setRecipe;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Button btn_MasureTest_Edge_Autoselect;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txb_recipePath;
        private AOISystem.Halcon.Controls.HControl hControl_NotchMeasurement;
        private System.Windows.Forms.Label label171;
        private AOISystem.Halcon.Controls.HControl hControl_linescanBottom;
        private AOISystem.Halcon.Controls.HControl hControl_linescanTop;
        private AOISystem.Halcon.Controls.HControl hControl_NotchInspect;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.NumericUpDown nud_Vr2;
        private System.Windows.Forms.NumericUpDown nud_Vr1;
        private System.Windows.Forms.NumericUpDown nud_P2;
        private System.Windows.Forms.NumericUpDown nud_P1;
        private System.Windows.Forms.NumericUpDown nud_AngV;
        private System.Windows.Forms.NumericUpDown nud_Vr;
        private System.Windows.Forms.NumericUpDown nud_Vw;
        private System.Windows.Forms.NumericUpDown nud_Vh;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.NumericUpDown nud_C2;
        private System.Windows.Forms.NumericUpDown nud_C1;
        private System.Windows.Forms.NumericUpDown nud_BC;
        private System.Windows.Forms.NumericUpDown nud_Ang2;
        private System.Windows.Forms.NumericUpDown nud_Ang1;
        private System.Windows.Forms.NumericUpDown nud_t;
        private System.Windows.Forms.NumericUpDown nud_R2;
        private System.Windows.Forms.NumericUpDown nud_R1;
        private System.Windows.Forms.NumericUpDown nud_B2;
        private System.Windows.Forms.NumericUpDown nud_B1;
        private System.Windows.Forms.NumericUpDown nud_A2;
        private System.Windows.Forms.NumericUpDown nud_A1;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label178;
        private AOISystem.Halcon.Controls.HControl hControl_EdgeMeasurement;
        private System.Windows.Forms.NumericUpDown nud_edgeAngle;
        private System.Windows.Forms.Button btn_edgeNumberNext;
        private System.Windows.Forms.Button btn_edgeNumberBack;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.NumericUpDown nud_DiameterT;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Button btn_DefectInspectionBottomRun;
        private System.Windows.Forms.Button btn_DefectInspectionBottomLoadImage;
        private System.Windows.Forms.Button btn_DefectInspectionTOPRun;
        private System.Windows.Forms.Button btn_DefectInspectionTOPLoadImage;
        private System.Windows.Forms.Button btn_NotchInspectRun;
        private System.Windows.Forms.Button btn_NotchInspectLoadImage;
        private System.Windows.Forms.Button btn_NotchMeasurementRun;
        private System.Windows.Forms.Button btn_NotchMeasurementLoadImage;
        private System.Windows.Forms.Button btn_EdgeMeasurementRun;
        private System.Windows.Forms.Button btn_EdgeMeasurementLoadImage;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Button btn_DiameterMeasurementRun;
        private System.Windows.Forms.Button btn_DefectInspectionBottomAlign;
        private System.Windows.Forms.Button btn_DefectInspectionTOPAlign;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.NumericUpDown nud_edgeIndex;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.NumericUpDown nud_DiameterB;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Button btn_CheckGrinding;
    }
}

