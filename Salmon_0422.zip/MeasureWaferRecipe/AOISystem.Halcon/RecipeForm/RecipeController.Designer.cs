﻿namespace AOISystem.Halcon.RecipeForm
{
    partial class RecipeController
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cboCurrentRecipeChange = new System.Windows.Forms.ComboBox();
            this.lblRecipeNumber = new System.Windows.Forms.Label();
            this.Recipe_label = new System.Windows.Forms.Label();
            this.dgvRecipeList = new System.Windows.Forms.DataGridView();
            this.RecipeNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecipeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModifyTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDisplayRecipeID = new System.Windows.Forms.TextBox();
            this.lblRecipeID = new System.Windows.Forms.Label();
            this.txtDisplayRecipeNo = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecipeList)).BeginInit();
            this.SuspendLayout();
            // 
            // cboCurrentRecipeChange
            // 
            this.cboCurrentRecipeChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cboCurrentRecipeChange.FormattingEnabled = true;
            this.cboCurrentRecipeChange.Location = new System.Drawing.Point(134, 3);
            this.cboCurrentRecipeChange.Name = "cboCurrentRecipeChange";
            this.cboCurrentRecipeChange.Size = new System.Drawing.Size(177, 28);
            this.cboCurrentRecipeChange.TabIndex = 28;
            this.cboCurrentRecipeChange.Tag = "";
            // 
            // lblRecipeNumber
            // 
            this.lblRecipeNumber.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblRecipeNumber.Location = new System.Drawing.Point(3, 50);
            this.lblRecipeNumber.Name = "lblRecipeNumber";
            this.lblRecipeNumber.Size = new System.Drawing.Size(86, 22);
            this.lblRecipeNumber.TabIndex = 18;
            this.lblRecipeNumber.Text = "Recipe No：";
            this.lblRecipeNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Recipe_label
            // 
            this.Recipe_label.AutoSize = true;
            this.Recipe_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Recipe_label.Location = new System.Drawing.Point(7, 6);
            this.Recipe_label.Name = "Recipe_label";
            this.Recipe_label.Size = new System.Drawing.Size(128, 20);
            this.Recipe_label.TabIndex = 27;
            this.Recipe_label.Text = "Current Recipe : ";
            // 
            // dgvRecipeList
            // 
            this.dgvRecipeList.AllowUserToAddRows = false;
            this.dgvRecipeList.AllowUserToDeleteRows = false;
            this.dgvRecipeList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvRecipeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRecipeList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RecipeNo,
            this.RecipeID,
            this.ModifyTime,
            this.Description});
            this.dgvRecipeList.Location = new System.Drawing.Point(7, 80);
            this.dgvRecipeList.Name = "dgvRecipeList";
            this.dgvRecipeList.ReadOnly = true;
            this.dgvRecipeList.RowHeadersVisible = false;
            this.dgvRecipeList.RowTemplate.Height = 24;
            this.dgvRecipeList.Size = new System.Drawing.Size(375, 183);
            this.dgvRecipeList.TabIndex = 22;
            this.dgvRecipeList.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvRecipeList_CellMouseClick);
            // 
            // RecipeNo
            // 
            this.RecipeNo.HeaderText = "RecipeNo";
            this.RecipeNo.Name = "RecipeNo";
            this.RecipeNo.ReadOnly = true;
            this.RecipeNo.Width = 55;
            // 
            // RecipeID
            // 
            this.RecipeID.HeaderText = "RecipeID";
            this.RecipeID.Name = "RecipeID";
            this.RecipeID.ReadOnly = true;
            // 
            // ModifyTime
            // 
            this.ModifyTime.HeaderText = "ModifyTime";
            this.ModifyTime.Name = "ModifyTime";
            this.ModifyTime.ReadOnly = true;
            this.ModifyTime.Width = 140;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Width = 150;
            // 
            // txtDisplayRecipeID
            // 
            this.txtDisplayRecipeID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDisplayRecipeID.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDisplayRecipeID.Location = new System.Drawing.Point(238, 49);
            this.txtDisplayRecipeID.Name = "txtDisplayRecipeID";
            this.txtDisplayRecipeID.ReadOnly = true;
            this.txtDisplayRecipeID.Size = new System.Drawing.Size(144, 25);
            this.txtDisplayRecipeID.TabIndex = 21;
            // 
            // lblRecipeID
            // 
            this.lblRecipeID.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblRecipeID.Location = new System.Drawing.Point(141, 50);
            this.lblRecipeID.Name = "lblRecipeID";
            this.lblRecipeID.Size = new System.Drawing.Size(102, 22);
            this.lblRecipeID.TabIndex = 20;
            this.lblRecipeID.Text = "Recipe ID：";
            this.lblRecipeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtDisplayRecipeNo
            // 
            this.txtDisplayRecipeNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDisplayRecipeNo.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDisplayRecipeNo.Location = new System.Drawing.Point(85, 49);
            this.txtDisplayRecipeNo.Name = "txtDisplayRecipeNo";
            this.txtDisplayRecipeNo.ReadOnly = true;
            this.txtDisplayRecipeNo.Size = new System.Drawing.Size(50, 25);
            this.txtDisplayRecipeNo.TabIndex = 19;
            // 
            // btnOK
            // 
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOK.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnOK.ForeColor = System.Drawing.Color.Black;
            this.btnOK.Image = global::AOISystem.Halcon.Properties.Resources.OK_16;
            this.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOK.Location = new System.Drawing.Point(317, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(65, 28);
            this.btnOK.TabIndex = 29;
            this.btnOK.Text = "OK";
            this.btnOK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCopy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCopy.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCopy.ForeColor = System.Drawing.Color.Blue;
            this.btnCopy.Image = global::AOISystem.Halcon.Properties.Resources.File_copy_32;
            this.btnCopy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCopy.Location = new System.Drawing.Point(6, 269);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(120, 40);
            this.btnCopy.TabIndex = 26;
            this.btnCopy.Text = "Copy";
            this.btnCopy.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEdit.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnEdit.ForeColor = System.Drawing.Color.Maroon;
            this.btnEdit.Image = global::AOISystem.Halcon.Properties.Resources.File_edit_32;
            this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.Location = new System.Drawing.Point(134, 269);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(120, 40);
            this.btnEdit.TabIndex = 25;
            this.btnEdit.Text = "Edit";
            this.btnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnCreateEditorRecipe_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnDelete.ForeColor = System.Drawing.Color.Green;
            this.btnDelete.Image = global::AOISystem.Halcon.Properties.Resources.File_delete_32;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(262, 269);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(120, 40);
            this.btnDelete.TabIndex = 23;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // RecipeController
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txtDisplayRecipeNo);
            this.Controls.Add(this.cboCurrentRecipeChange);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblRecipeNumber);
            this.Controls.Add(this.Recipe_label);
            this.Controls.Add(this.dgvRecipeList);
            this.Controls.Add(this.txtDisplayRecipeID);
            this.Controls.Add(this.lblRecipeID);
            this.Name = "RecipeController";
            this.Size = new System.Drawing.Size(385, 312);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecipeList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboCurrentRecipeChange;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblRecipeNumber;
        private System.Windows.Forms.Label Recipe_label;
        private System.Windows.Forms.DataGridView dgvRecipeList;
        private System.Windows.Forms.TextBox txtDisplayRecipeID;
        private System.Windows.Forms.Label lblRecipeID;
        private System.Windows.Forms.TextBox txtDisplayRecipeNo;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecipeNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecipeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModifyTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
    }
}
