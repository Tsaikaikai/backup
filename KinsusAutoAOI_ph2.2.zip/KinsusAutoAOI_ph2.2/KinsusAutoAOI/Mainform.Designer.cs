﻿
namespace KinsusAutoAOI
{
    partial class Mainform
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainform));
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem(new string[] {
            "NG",
            "0",
            "0",
            "0",
            "0"}, -1, System.Drawing.SystemColors.WindowText, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold));
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem(new string[] {
            "PASS",
            "0",
            "0",
            "0",
            "0"}, -1, System.Drawing.SystemColors.WindowText, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold));
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "Repairable",
            "0",
            "0",
            "0",
            "0"}, -1, System.Drawing.SystemColors.WindowText, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold));
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "Non Repair",
            "0",
            "0",
            "0",
            "0"}, -1, System.Drawing.SystemColors.WindowText, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            this.materialDrawer1 = new MaterialSkin.Controls.MaterialDrawer();
            this.materialDrawer2 = new MaterialSkin.Controls.MaterialDrawer();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.light3 = new System.Windows.Forms.Label();
            this.light4 = new System.Windows.Forms.Label();
            this.light2 = new System.Windows.Forms.Label();
            this.light1 = new System.Windows.Forms.Label();
            this.Folder = new System.Windows.Forms.TabPage();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.materialLabel44 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard9 = new MaterialSkin.Controls.MaterialCard();
            this.auolicense = new System.Windows.Forms.PictureBox();
            this.otherlicense = new System.Windows.Forms.PictureBox();
            this.materialLabel38 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel42 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel43 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel8 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel12 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard6 = new MaterialSkin.Controls.MaterialCard();
            this.AI = new System.Windows.Forms.PictureBox();
            this.materialLabel15 = new MaterialSkin.Controls.MaterialLabel();
            this.Recipe = new System.Windows.Forms.PictureBox();
            this.materialLabel13 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel14 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel9 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard5 = new MaterialSkin.Controls.MaterialCard();
            this.logfiles = new System.Windows.Forms.PictureBox();
            this.Images = new System.Windows.Forms.PictureBox();
            this.materialLabel10 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel11 = new MaterialSkin.Controls.MaterialLabel();
            this.materialDrawer3 = new MaterialSkin.Controls.MaterialDrawer();
            this.materialCard4 = new MaterialSkin.Controls.MaterialCard();
            this.Export = new System.Windows.Forms.PictureBox();
            this.Import = new System.Windows.Forms.PictureBox();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Status = new System.Windows.Forms.TabPage();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.AIAccuracy = new System.Windows.Forms.TabPage();
            this.bt_reflash = new MaterialSkin.Controls.MaterialButton();
            this.selectAiAccModel = new MaterialSkin.Controls.MaterialComboBox();
            this.selectAiAccRange = new MaterialSkin.Controls.MaterialComboBox();
            this.materialCard11 = new MaterialSkin.Controls.MaterialCard();
            this.confusematrix = new MaterialSkin.Controls.MaterialListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.materialCard10 = new MaterialSkin.Controls.MaterialCard();
            this.AiAccFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.modifieddateLabel = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel57 = new MaterialSkin.Controls.MaterialLabel();
            this.totalpercent = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel40 = new MaterialSkin.Controls.MaterialLabel();
            this.totalProgressBar = new MaterialSkin.Controls.MaterialProgressBar();
            this.materialLabel36 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.SystemSetting = new System.Windows.Forms.TabPage();
            this.systemsetting_save = new MaterialSkin.Controls.MaterialButton();
            this.materialComboBox4 = new MaterialSkin.Controls.MaterialComboBox();
            this.materialLabel18 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard8 = new MaterialSkin.Controls.MaterialCard();
            this.materialLabel48 = new MaterialSkin.Controls.MaterialLabel();
            this.selectWorkFolderButton = new MaterialSkin.Controls.MaterialButton();
            this.workFolderTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.selectcsvfolderButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel28 = new MaterialSkin.Controls.MaterialLabel();
            this.grayShareFolderTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel54 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel53 = new MaterialSkin.Controls.MaterialLabel();
            this.exportadd = new MaterialSkin.Controls.MaterialButton();
            this.exportFolderList = new MaterialSkin.Controls.MaterialListBox();
            this.exportremove = new MaterialSkin.Controls.MaterialButton();
            this.delayAfterMonitorTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel39 = new MaterialSkin.Controls.MaterialLabel();
            this.selectbackupButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel37 = new MaterialSkin.Controls.MaterialLabel();
            this.backupTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.systemNameTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.monitorFreqTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.selectsharefolderButton = new MaterialSkin.Controls.MaterialButton();
            this.imageSaveFolderTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel30 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel29 = new MaterialSkin.Controls.MaterialLabel();
            this.rejudgeTimeOutTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.portTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel27 = new MaterialSkin.Controls.MaterialLabel();
            this.ipTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.selectimportButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel25 = new MaterialSkin.Controls.MaterialLabel();
            this.importFolderTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.selectexportButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel24 = new MaterialSkin.Controls.MaterialLabel();
            this.exportTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel23 = new MaterialSkin.Controls.MaterialLabel();
            this.system_setting = new System.Windows.Forms.PictureBox();
            this.ProductSetting = new System.Windows.Forms.TabPage();
            this.materialComboBox2 = new MaterialSkin.Controls.MaterialComboBox();
            this.materialLabel16 = new MaterialSkin.Controls.MaterialLabel();
            this.productsetting_save = new MaterialSkin.Controls.MaterialButton();
            this.materialCard7 = new MaterialSkin.Controls.MaterialCard();
            this.repairableTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.nonrepairTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel52 = new MaterialSkin.Controls.MaterialLabel();
            this.AreaCheckedflowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.materialLabel51 = new MaterialSkin.Controls.MaterialLabel();
            this.detailDefectCodeFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.defectCodeFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.selectAiYieldModelButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel47 = new MaterialSkin.Controls.MaterialLabel();
            this.aiYieldModelTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel26 = new MaterialSkin.Controls.MaterialLabel();
            this.regionsizeTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel46 = new MaterialSkin.Controls.MaterialLabel();
            this.mindefectareaTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel41 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel50 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel45 = new MaterialSkin.Controls.MaterialLabel();
            this.GV_DefectTable = new System.Windows.Forms.DataGridView();
            this.unknownTHTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.btn_AreaCheckTool = new MaterialSkin.Controls.MaterialButton();
            this.productnameTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel32 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel22 = new MaterialSkin.Controls.MaterialLabel();
            this.selectAiModelButton = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel21 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel20 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel19 = new MaterialSkin.Controls.MaterialLabel();
            this.aimodelTextBox = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialLabel17 = new MaterialSkin.Controls.MaterialLabel();
            this.product_setting = new System.Windows.Forms.PictureBox();
            this.Home = new System.Windows.Forms.TabPage();
            this.mode2RadioButton = new MaterialSkin.Controls.MaterialRadioButton();
            this.mode1RadioButton = new MaterialSkin.Controls.MaterialRadioButton();
            this.colorimg = new System.Windows.Forms.PictureBox();
            this.materialLabel49 = new MaterialSkin.Controls.MaterialLabel();
            this.grayLabel = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.colorLabel = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard12 = new MaterialSkin.Controls.MaterialCard();
            this.accuracySlider = new MaterialSkin.Controls.MaterialSlider();
            this.grayimg = new System.Windows.Forms.PictureBox();
            this.materialCard1 = new MaterialSkin.Controls.MaterialCard();
            this.Recipe_OK = new System.Windows.Forms.PictureBox();
            this.Rejudge_OK = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.AI_OK = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.materialLabel31 = new MaterialSkin.Controls.MaterialLabel();
            this.Rejudge_NG = new System.Windows.Forms.PictureBox();
            this.Recipe_NG = new System.Windows.Forms.PictureBox();
            this.AI_NG = new System.Windows.Forms.PictureBox();
            this.foldersetting_OK = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.materialLabel35 = new MaterialSkin.Controls.MaterialLabel();
            this.foldersetting_NG = new System.Windows.Forms.PictureBox();
            this.materialLabel34 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel33 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard3 = new MaterialSkin.Controls.MaterialCard();
            this.materialComboBox3 = new MaterialSkin.Controls.MaterialComboBox();
            this.materialComboBox1 = new MaterialSkin.Controls.MaterialComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard2 = new MaterialSkin.Controls.MaterialCard();
            this.shortAreaCheck_Switch = new MaterialSkin.Controls.MaterialSwitch();
            this.backup_Switch = new MaterialSkin.Controls.MaterialSwitch();
            this.rejudge_Switch = new MaterialSkin.Controls.MaterialSwitch();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.startButton = new MaterialSkin.Controls.MaterialButton();
            this.stopButton = new MaterialSkin.Controls.MaterialButton();
            this.TabControlHome = new MaterialSkin.Controls.MaterialTabControl();
            this.Type = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.AOI_Defect = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Judge = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.AI_Result = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.NewResult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialLabel55 = new MaterialSkin.Controls.MaterialLabel();
            this.Folder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.materialCard9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.auolicense)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otherlicense)).BeginInit();
            this.materialCard6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe)).BeginInit();
            this.materialCard5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logfiles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Images)).BeginInit();
            this.materialCard4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Export)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Import)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Status.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.AIAccuracy.SuspendLayout();
            this.materialCard11.SuspendLayout();
            this.materialCard10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.SystemSetting.SuspendLayout();
            this.materialCard8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.system_setting)).BeginInit();
            this.ProductSetting.SuspendLayout();
            this.materialCard7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GV_DefectTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.product_setting)).BeginInit();
            this.Home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colorimg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.materialCard12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grayimg)).BeginInit();
            this.materialCard1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe_OK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejudge_OK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AI_OK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejudge_NG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe_NG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AI_NG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foldersetting_OK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foldersetting_NG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.materialCard3.SuspendLayout();
            this.materialCard2.SuspendLayout();
            this.TabControlHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialDrawer1
            // 
            this.materialDrawer1.AutoHide = false;
            this.materialDrawer1.AutoShow = false;
            this.materialDrawer1.BackgroundWithAccent = false;
            this.materialDrawer1.BaseTabControl = null;
            this.materialDrawer1.Depth = 0;
            this.materialDrawer1.HighlightWithAccent = true;
            this.materialDrawer1.IndicatorWidth = 0;
            this.materialDrawer1.IsOpen = false;
            this.materialDrawer1.Location = new System.Drawing.Point(-237, 141);
            this.materialDrawer1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.materialDrawer1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDrawer1.Name = "materialDrawer1";
            this.materialDrawer1.ShowIconsWhenHidden = false;
            this.materialDrawer1.Size = new System.Drawing.Size(237, 399);
            this.materialDrawer1.TabIndex = 0;
            this.materialDrawer1.Text = "materialDrawer1";
            this.materialDrawer1.UseColors = false;
            // 
            // materialDrawer2
            // 
            this.materialDrawer2.AutoHide = false;
            this.materialDrawer2.AutoShow = false;
            this.materialDrawer2.BackgroundWithAccent = false;
            this.materialDrawer2.BaseTabControl = null;
            this.materialDrawer2.Depth = 0;
            this.materialDrawer2.HighlightWithAccent = true;
            this.materialDrawer2.IndicatorWidth = 0;
            this.materialDrawer2.IsOpen = false;
            this.materialDrawer2.Location = new System.Drawing.Point(-292, 613);
            this.materialDrawer2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.materialDrawer2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDrawer2.Name = "materialDrawer2";
            this.materialDrawer2.ShowIconsWhenHidden = false;
            this.materialDrawer2.Size = new System.Drawing.Size(292, 160);
            this.materialDrawer2.TabIndex = 2;
            this.materialDrawer2.Text = "materialDrawer2";
            this.materialDrawer2.UseColors = false;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.WorkerSupportsCancellation = true;
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.MainWorker_DoWork);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "home.png");
            this.imageList1.Images.SetKeyName(1, "setting.png");
            this.imageList1.Images.SetKeyName(2, "status.png");
            this.imageList1.Images.SetKeyName(3, "OK.png");
            this.imageList1.Images.SetKeyName(4, "error.png");
            this.imageList1.Images.SetKeyName(5, "folder (2).png");
            this.imageList1.Images.SetKeyName(6, "907027.png");
            this.imageList1.Images.SetKeyName(7, "2289316.png");
            this.imageList1.Images.SetKeyName(8, "4059496.png");
            this.imageList1.Images.SetKeyName(9, "3908482.png");
            this.imageList1.Images.SetKeyName(10, "4457164.png");
            this.imageList1.Images.SetKeyName(11, "3524589.png");
            this.imageList1.Images.SetKeyName(12, "3802177.png");
            this.imageList1.Images.SetKeyName(13, "1198546.png");
            this.imageList1.Images.SetKeyName(14, "1766429.png");
            this.imageList1.Images.SetKeyName(15, "2383158.png");
            this.imageList1.Images.SetKeyName(16, "292178.png");
            this.imageList1.Images.SetKeyName(17, "7747513.png");
            this.imageList1.Images.SetKeyName(18, "3329652.png");
            this.imageList1.Images.SetKeyName(19, "accgray.png");
            this.imageList1.Images.SetKeyName(20, "colormode.png");
            this.imageList1.Images.SetKeyName(21, "graymode.png");
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.WorkerReportsProgress = true;
            this.backgroundWorker2.WorkerSupportsCancellation = true;
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackupWorker_DoWork);
            // 
            // backgroundWorker3
            // 
            this.backgroundWorker3.WorkerSupportsCancellation = true;
            this.backgroundWorker3.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BreathinglightWorker_DoWork);
            // 
            // light3
            // 
            this.light3.BackColor = System.Drawing.Color.White;
            this.light3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold);
            this.light3.ForeColor = System.Drawing.Color.Transparent;
            this.light3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.light3.Location = new System.Drawing.Point(388, 49);
            this.light3.Name = "light3";
            this.light3.Size = new System.Drawing.Size(7, 15);
            this.light3.TabIndex = 49;
            // 
            // light4
            // 
            this.light4.BackColor = System.Drawing.Color.White;
            this.light4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold);
            this.light4.ForeColor = System.Drawing.Color.Transparent;
            this.light4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.light4.Location = new System.Drawing.Point(378, 49);
            this.light4.Name = "light4";
            this.light4.Size = new System.Drawing.Size(7, 15);
            this.light4.TabIndex = 50;
            // 
            // light2
            // 
            this.light2.BackColor = System.Drawing.Color.White;
            this.light2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold);
            this.light2.ForeColor = System.Drawing.Color.Transparent;
            this.light2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.light2.Location = new System.Drawing.Point(398, 49);
            this.light2.Name = "light2";
            this.light2.Size = new System.Drawing.Size(7, 15);
            this.light2.TabIndex = 52;
            // 
            // light1
            // 
            this.light1.BackColor = System.Drawing.Color.White;
            this.light1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold);
            this.light1.ForeColor = System.Drawing.Color.Transparent;
            this.light1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.light1.Location = new System.Drawing.Point(408, 49);
            this.light1.Name = "light1";
            this.light1.Size = new System.Drawing.Size(7, 15);
            this.light1.TabIndex = 51;
            // 
            // Folder
            // 
            this.Folder.BackColor = System.Drawing.Color.White;
            this.Folder.Controls.Add(this.pictureBox15);
            this.Folder.Controls.Add(this.materialLabel44);
            this.Folder.Controls.Add(this.materialCard9);
            this.Folder.Controls.Add(this.materialLabel8);
            this.Folder.Controls.Add(this.materialLabel12);
            this.Folder.Controls.Add(this.materialCard6);
            this.Folder.Controls.Add(this.materialLabel9);
            this.Folder.Controls.Add(this.materialCard5);
            this.Folder.Controls.Add(this.materialDrawer3);
            this.Folder.Controls.Add(this.materialCard4);
            this.Folder.Controls.Add(this.pictureBox1);
            this.Folder.Controls.Add(this.pictureBox5);
            this.Folder.Controls.Add(this.pictureBox3);
            this.Folder.ImageKey = "folder (2).png";
            this.Folder.Location = new System.Drawing.Point(4, 39);
            this.Folder.Name = "Folder";
            this.Folder.Size = new System.Drawing.Size(1012, 736);
            this.Folder.TabIndex = 3;
            this.Folder.Text = "Folder";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox15.Location = new System.Drawing.Point(511, 290);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(50, 50);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 26;
            this.pictureBox15.TabStop = false;
            // 
            // materialLabel44
            // 
            this.materialLabel44.AutoSize = true;
            this.materialLabel44.Depth = 0;
            this.materialLabel44.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel44.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel44.Location = new System.Drawing.Point(567, 309);
            this.materialLabel44.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel44.Name = "materialLabel44";
            this.materialLabel44.Size = new System.Drawing.Size(54, 24);
            this.materialLabel44.TabIndex = 25;
            this.materialLabel44.Text = "About";
            // 
            // materialCard9
            // 
            this.materialCard9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard9.Controls.Add(this.auolicense);
            this.materialCard9.Controls.Add(this.otherlicense);
            this.materialCard9.Controls.Add(this.materialLabel38);
            this.materialCard9.Controls.Add(this.materialLabel42);
            this.materialCard9.Controls.Add(this.materialLabel43);
            this.materialCard9.Depth = 0;
            this.materialCard9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard9.Location = new System.Drawing.Point(506, 347);
            this.materialCard9.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard9.Name = "materialCard9";
            this.materialCard9.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard9.Size = new System.Drawing.Size(400, 148);
            this.materialCard9.TabIndex = 24;
            // 
            // auolicense
            // 
            this.auolicense.BackColor = System.Drawing.Color.Transparent;
            this.auolicense.Cursor = System.Windows.Forms.Cursors.Hand;
            this.auolicense.Image = global::KinsusAutoAOI.Properties.Resources.AUO_logo_RGB;
            this.auolicense.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.auolicense.Location = new System.Drawing.Point(65, 35);
            this.auolicense.Name = "auolicense";
            this.auolicense.Size = new System.Drawing.Size(107, 66);
            this.auolicense.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.auolicense.TabIndex = 46;
            this.auolicense.TabStop = false;
            this.auolicense.Click += new System.EventHandler(this.auolicense_Click);
            // 
            // otherlicense
            // 
            this.otherlicense.Cursor = System.Windows.Forms.Cursors.Hand;
            this.otherlicense.Image = ((System.Drawing.Image)(resources.GetObject("otherlicense.Image")));
            this.otherlicense.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.otherlicense.Location = new System.Drawing.Point(259, 35);
            this.otherlicense.Name = "otherlicense";
            this.otherlicense.Size = new System.Drawing.Size(64, 64);
            this.otherlicense.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.otherlicense.TabIndex = 22;
            this.otherlicense.TabStop = false;
            this.otherlicense.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // materialLabel38
            // 
            this.materialLabel38.AutoSize = true;
            this.materialLabel38.Depth = 0;
            this.materialLabel38.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel38.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel38.Location = new System.Drawing.Point(272, 102);
            this.materialLabel38.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel38.Name = "materialLabel38";
            this.materialLabel38.Size = new System.Drawing.Size(37, 17);
            this.materialLabel38.TabIndex = 21;
            this.materialLabel38.Text = "Other";
            // 
            // materialLabel42
            // 
            this.materialLabel42.AutoSize = true;
            this.materialLabel42.Depth = 0;
            this.materialLabel42.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel42.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel42.Location = new System.Drawing.Point(106, 103);
            this.materialLabel42.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel42.Name = "materialLabel42";
            this.materialLabel42.Size = new System.Drawing.Size(29, 17);
            this.materialLabel42.TabIndex = 6;
            this.materialLabel42.Text = "AUO";
            // 
            // materialLabel43
            // 
            this.materialLabel43.AutoSize = true;
            this.materialLabel43.Depth = 0;
            this.materialLabel43.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel43.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel43.Location = new System.Drawing.Point(178, 102);
            this.materialLabel43.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel43.Name = "materialLabel43";
            this.materialLabel43.Size = new System.Drawing.Size(1, 0);
            this.materialLabel43.TabIndex = 8;
            // 
            // materialLabel8
            // 
            this.materialLabel8.AutoSize = true;
            this.materialLabel8.Depth = 0;
            this.materialLabel8.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel8.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel8.Location = new System.Drawing.Point(105, 38);
            this.materialLabel8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel8.Name = "materialLabel8";
            this.materialLabel8.Size = new System.Drawing.Size(86, 24);
            this.materialLabel8.TabIndex = 23;
            this.materialLabel8.Text = "Database";
            // 
            // materialLabel12
            // 
            this.materialLabel12.AutoSize = true;
            this.materialLabel12.Depth = 0;
            this.materialLabel12.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel12.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel12.Location = new System.Drawing.Point(102, 309);
            this.materialLabel12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel12.Name = "materialLabel12";
            this.materialLabel12.Size = new System.Drawing.Size(113, 24);
            this.materialLabel12.TabIndex = 22;
            this.materialLabel12.Text = "Environment";
            // 
            // materialCard6
            // 
            this.materialCard6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard6.Controls.Add(this.AI);
            this.materialCard6.Controls.Add(this.materialLabel15);
            this.materialCard6.Controls.Add(this.Recipe);
            this.materialCard6.Controls.Add(this.materialLabel13);
            this.materialCard6.Controls.Add(this.materialLabel14);
            this.materialCard6.Depth = 0;
            this.materialCard6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard6.Location = new System.Drawing.Point(43, 347);
            this.materialCard6.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard6.Name = "materialCard6";
            this.materialCard6.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard6.Size = new System.Drawing.Size(400, 148);
            this.materialCard6.TabIndex = 21;
            // 
            // AI
            // 
            this.AI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AI.Image = ((System.Drawing.Image)(resources.GetObject("AI.Image")));
            this.AI.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AI.Location = new System.Drawing.Point(81, 35);
            this.AI.Name = "AI";
            this.AI.Size = new System.Drawing.Size(64, 64);
            this.AI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AI.TabIndex = 22;
            this.AI.TabStop = false;
            this.AI.Click += new System.EventHandler(this.AiShortCutClick);
            // 
            // materialLabel15
            // 
            this.materialLabel15.AutoSize = true;
            this.materialLabel15.Depth = 0;
            this.materialLabel15.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel15.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel15.Location = new System.Drawing.Point(272, 102);
            this.materialLabel15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel15.Name = "materialLabel15";
            this.materialLabel15.Size = new System.Drawing.Size(45, 17);
            this.materialLabel15.TabIndex = 21;
            this.materialLabel15.Text = "Recipe";
            // 
            // Recipe
            // 
            this.Recipe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Recipe.Image = ((System.Drawing.Image)(resources.GetObject("Recipe.Image")));
            this.Recipe.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Recipe.Location = new System.Drawing.Point(261, 35);
            this.Recipe.Name = "Recipe";
            this.Recipe.Size = new System.Drawing.Size(64, 64);
            this.Recipe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Recipe.TabIndex = 10;
            this.Recipe.TabStop = false;
            this.Recipe.Click += new System.EventHandler(this.recipeShortCutClick);
            // 
            // materialLabel13
            // 
            this.materialLabel13.AutoSize = true;
            this.materialLabel13.Depth = 0;
            this.materialLabel13.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel13.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel13.Location = new System.Drawing.Point(106, 103);
            this.materialLabel13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel13.Name = "materialLabel13";
            this.materialLabel13.Size = new System.Drawing.Size(14, 17);
            this.materialLabel13.TabIndex = 6;
            this.materialLabel13.Text = "AI";
            // 
            // materialLabel14
            // 
            this.materialLabel14.AutoSize = true;
            this.materialLabel14.Depth = 0;
            this.materialLabel14.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel14.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel14.Location = new System.Drawing.Point(178, 102);
            this.materialLabel14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel14.Name = "materialLabel14";
            this.materialLabel14.Size = new System.Drawing.Size(1, 0);
            this.materialLabel14.TabIndex = 8;
            // 
            // materialLabel9
            // 
            this.materialLabel9.AutoSize = true;
            this.materialLabel9.Depth = 0;
            this.materialLabel9.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel9.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel9.Location = new System.Drawing.Point(567, 38);
            this.materialLabel9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel9.Name = "materialLabel9";
            this.materialLabel9.Size = new System.Drawing.Size(65, 24);
            this.materialLabel9.TabIndex = 17;
            this.materialLabel9.Text = "History";
            // 
            // materialCard5
            // 
            this.materialCard5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard5.Controls.Add(this.logfiles);
            this.materialCard5.Controls.Add(this.Images);
            this.materialCard5.Controls.Add(this.materialLabel10);
            this.materialCard5.Controls.Add(this.materialLabel11);
            this.materialCard5.Depth = 0;
            this.materialCard5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard5.Location = new System.Drawing.Point(506, 86);
            this.materialCard5.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard5.Name = "materialCard5";
            this.materialCard5.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard5.Size = new System.Drawing.Size(400, 148);
            this.materialCard5.TabIndex = 16;
            // 
            // logfiles
            // 
            this.logfiles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logfiles.Image = ((System.Drawing.Image)(resources.GetObject("logfiles.Image")));
            this.logfiles.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.logfiles.Location = new System.Drawing.Point(259, 36);
            this.logfiles.Name = "logfiles";
            this.logfiles.Size = new System.Drawing.Size(64, 64);
            this.logfiles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logfiles.TabIndex = 18;
            this.logfiles.TabStop = false;
            this.logfiles.Click += new System.EventHandler(this.logShortCutClick);
            // 
            // Images
            // 
            this.Images.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Images.Image = ((System.Drawing.Image)(resources.GetObject("Images.Image")));
            this.Images.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Images.Location = new System.Drawing.Point(86, 36);
            this.Images.Name = "Images";
            this.Images.Size = new System.Drawing.Size(64, 64);
            this.Images.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Images.TabIndex = 18;
            this.Images.TabStop = false;
            this.Images.Click += new System.EventHandler(this.imageSaveShortCutClick);
            // 
            // materialLabel10
            // 
            this.materialLabel10.AutoSize = true;
            this.materialLabel10.Depth = 0;
            this.materialLabel10.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel10.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel10.Location = new System.Drawing.Point(92, 103);
            this.materialLabel10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel10.Name = "materialLabel10";
            this.materialLabel10.Size = new System.Drawing.Size(48, 17);
            this.materialLabel10.TabIndex = 18;
            this.materialLabel10.Text = "Images";
            // 
            // materialLabel11
            // 
            this.materialLabel11.AutoSize = true;
            this.materialLabel11.Depth = 0;
            this.materialLabel11.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel11.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel11.Location = new System.Drawing.Point(264, 102);
            this.materialLabel11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel11.Name = "materialLabel11";
            this.materialLabel11.Size = new System.Drawing.Size(56, 17);
            this.materialLabel11.TabIndex = 19;
            this.materialLabel11.Text = "Log files";
            // 
            // materialDrawer3
            // 
            this.materialDrawer3.AutoHide = false;
            this.materialDrawer3.AutoShow = false;
            this.materialDrawer3.BackgroundWithAccent = false;
            this.materialDrawer3.BaseTabControl = null;
            this.materialDrawer3.Depth = 0;
            this.materialDrawer3.HighlightWithAccent = true;
            this.materialDrawer3.IndicatorWidth = 0;
            this.materialDrawer3.IsOpen = false;
            this.materialDrawer3.Location = new System.Drawing.Point(-375, 91);
            this.materialDrawer3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDrawer3.Name = "materialDrawer3";
            this.materialDrawer3.ShowIconsWhenHidden = false;
            this.materialDrawer3.Size = new System.Drawing.Size(375, 277);
            this.materialDrawer3.TabIndex = 11;
            this.materialDrawer3.Text = "materialDrawer3";
            this.materialDrawer3.UseColors = false;
            // 
            // materialCard4
            // 
            this.materialCard4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard4.Controls.Add(this.Export);
            this.materialCard4.Controls.Add(this.Import);
            this.materialCard4.Controls.Add(this.materialLabel6);
            this.materialCard4.Controls.Add(this.materialLabel7);
            this.materialCard4.Depth = 0;
            this.materialCard4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard4.Location = new System.Drawing.Point(43, 86);
            this.materialCard4.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard4.Name = "materialCard4";
            this.materialCard4.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard4.Size = new System.Drawing.Size(400, 148);
            this.materialCard4.TabIndex = 13;
            // 
            // Export
            // 
            this.Export.BackColor = System.Drawing.Color.White;
            this.Export.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Export.Image = ((System.Drawing.Image)(resources.GetObject("Export.Image")));
            this.Export.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Export.Location = new System.Drawing.Point(81, 36);
            this.Export.Name = "Export";
            this.Export.Size = new System.Drawing.Size(64, 64);
            this.Export.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Export.TabIndex = 20;
            this.Export.TabStop = false;
            this.Export.Click += new System.EventHandler(this.exportFolderShortCutClick);
            // 
            // Import
            // 
            this.Import.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Import.Image = ((System.Drawing.Image)(resources.GetObject("Import.Image")));
            this.Import.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Import.Location = new System.Drawing.Point(261, 36);
            this.Import.Name = "Import";
            this.Import.Size = new System.Drawing.Size(64, 64);
            this.Import.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Import.TabIndex = 10;
            this.Import.TabStop = false;
            this.Import.Click += new System.EventHandler(this.importFolderShortCutClick);
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel6.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel6.Location = new System.Drawing.Point(70, 104);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(86, 17);
            this.materialLabel6.TabIndex = 6;
            this.materialLabel6.Text = "Export Folder";
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel7.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel7.Location = new System.Drawing.Point(249, 103);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(87, 17);
            this.materialLabel7.TabIndex = 8;
            this.materialLabel7.Text = "Import Folder";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(45, 290);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox5.Location = new System.Drawing.Point(506, 19);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(55, 55);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 18;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox3.Location = new System.Drawing.Point(48, 19);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(45, 52);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // Status
            // 
            this.Status.BackColor = System.Drawing.Color.White;
            this.Status.Controls.Add(this.pictureBox8);
            this.Status.Controls.Add(this.pictureBox9);
            this.Status.Controls.Add(this.materialLabel5);
            this.Status.Controls.Add(this.materialLabel4);
            this.Status.Controls.Add(this.richTextBox2);
            this.Status.Controls.Add(this.richTextBox1);
            this.Status.ImageKey = "status.png";
            this.Status.Location = new System.Drawing.Point(4, 39);
            this.Status.Name = "Status";
            this.Status.Padding = new System.Windows.Forms.Padding(3);
            this.Status.Size = new System.Drawing.Size(1012, 736);
            this.Status.TabIndex = 1;
            this.Status.Text = "Status";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox8.Location = new System.Drawing.Point(43, 20);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(55, 55);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 48;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox9.Location = new System.Drawing.Point(43, 476);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(55, 55);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 47;
            this.pictureBox9.TabStop = false;
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.BackColor = System.Drawing.Color.White;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel5.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.materialLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel5.Location = new System.Drawing.Point(105, 492);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(131, 24);
            this.materialLabel5.TabIndex = 45;
            this.materialLabel5.Text = "Error Message";
            this.materialLabel5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.BackColor = System.Drawing.Color.White;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel4.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.materialLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel4.Location = new System.Drawing.Point(105, 38);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(111, 24);
            this.materialLabel4.TabIndex = 44;
            this.materialLabel4.Text = "Running Log";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(43, 540);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(866, 172);
            this.richTextBox2.TabIndex = 40;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(43, 86);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(866, 374);
            this.richTextBox1.TabIndex = 39;
            this.richTextBox1.Text = "";
            // 
            // AIAccuracy
            // 
            this.AIAccuracy.BackColor = System.Drawing.Color.White;
            this.AIAccuracy.Controls.Add(this.bt_reflash);
            this.AIAccuracy.Controls.Add(this.selectAiAccModel);
            this.AIAccuracy.Controls.Add(this.selectAiAccRange);
            this.AIAccuracy.Controls.Add(this.materialCard11);
            this.AIAccuracy.Controls.Add(this.materialCard10);
            this.AIAccuracy.Controls.Add(this.materialLabel36);
            this.AIAccuracy.Controls.Add(this.pictureBox16);
            this.AIAccuracy.ImageKey = "accgray.png";
            this.AIAccuracy.Location = new System.Drawing.Point(4, 39);
            this.AIAccuracy.Name = "AIAccuracy";
            this.AIAccuracy.Size = new System.Drawing.Size(984, 736);
            this.AIAccuracy.TabIndex = 7;
            this.AIAccuracy.Text = "AI Accuracy";
            this.AIAccuracy.Click += new System.EventHandler(this.AIAccuracy_Click);
            // 
            // bt_reflash
            // 
            this.bt_reflash.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bt_reflash.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.bt_reflash.Depth = 0;
            this.bt_reflash.HighEmphasis = true;
            this.bt_reflash.Icon = null;
            this.bt_reflash.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_reflash.Location = new System.Drawing.Point(818, 30);
            this.bt_reflash.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.bt_reflash.MouseState = MaterialSkin.MouseState.HOVER;
            this.bt_reflash.Name = "bt_reflash";
            this.bt_reflash.NoAccentTextColor = System.Drawing.Color.Empty;
            this.bt_reflash.Size = new System.Drawing.Size(84, 36);
            this.bt_reflash.TabIndex = 63;
            this.bt_reflash.Text = "Reflash";
            this.bt_reflash.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.bt_reflash.UseAccentColor = false;
            this.bt_reflash.UseVisualStyleBackColor = true;
            this.bt_reflash.Click += new System.EventHandler(this.bt_reflash_Click);
            // 
            // selectAiAccModel
            // 
            this.selectAiAccModel.AutoResize = false;
            this.selectAiAccModel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.selectAiAccModel.Depth = 0;
            this.selectAiAccModel.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.selectAiAccModel.DropDownHeight = 174;
            this.selectAiAccModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectAiAccModel.DropDownWidth = 121;
            this.selectAiAccModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.selectAiAccModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.selectAiAccModel.FormattingEnabled = true;
            this.selectAiAccModel.IntegralHeight = false;
            this.selectAiAccModel.ItemHeight = 43;
            this.selectAiAccModel.Location = new System.Drawing.Point(256, 20);
            this.selectAiAccModel.MaxDropDownItems = 4;
            this.selectAiAccModel.MouseState = MaterialSkin.MouseState.OUT;
            this.selectAiAccModel.Name = "selectAiAccModel";
            this.selectAiAccModel.Size = new System.Drawing.Size(254, 49);
            this.selectAiAccModel.StartIndex = 0;
            this.selectAiAccModel.TabIndex = 62;
            this.selectAiAccModel.SelectedIndexChanged += new System.EventHandler(this.selectAiAccModel_SelectedIndexChanged);
            // 
            // selectAiAccRange
            // 
            this.selectAiAccRange.AutoResize = false;
            this.selectAiAccRange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.selectAiAccRange.Depth = 0;
            this.selectAiAccRange.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.selectAiAccRange.DropDownHeight = 174;
            this.selectAiAccRange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectAiAccRange.DropDownWidth = 121;
            this.selectAiAccRange.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.selectAiAccRange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.selectAiAccRange.FormattingEnabled = true;
            this.selectAiAccRange.IntegralHeight = false;
            this.selectAiAccRange.ItemHeight = 43;
            this.selectAiAccRange.Items.AddRange(new object[] {
            "Today",
            "Last 3 Days",
            "Last 7 Days",
            "Last 14 Days",
            "Last 30 Days",
            "Last 180 Days",
            "Last 365 Days"});
            this.selectAiAccRange.Location = new System.Drawing.Point(532, 20);
            this.selectAiAccRange.MaxDropDownItems = 4;
            this.selectAiAccRange.MouseState = MaterialSkin.MouseState.OUT;
            this.selectAiAccRange.Name = "selectAiAccRange";
            this.selectAiAccRange.Size = new System.Drawing.Size(254, 49);
            this.selectAiAccRange.StartIndex = 0;
            this.selectAiAccRange.TabIndex = 61;
            this.selectAiAccRange.SelectedIndexChanged += new System.EventHandler(this.selectAiAccRange_SelectedIndexChanged);
            // 
            // materialCard11
            // 
            this.materialCard11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard11.Controls.Add(this.confusematrix);
            this.materialCard11.Depth = 0;
            this.materialCard11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard11.Location = new System.Drawing.Point(44, 414);
            this.materialCard11.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard11.Name = "materialCard11";
            this.materialCard11.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard11.Size = new System.Drawing.Size(862, 308);
            this.materialCard11.TabIndex = 57;
            // 
            // confusematrix
            // 
            this.confusematrix.AutoSizeTable = false;
            this.confusematrix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.confusematrix.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.confusematrix.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.confusematrix.Depth = 0;
            this.confusematrix.FullRowSelect = true;
            this.confusematrix.HideSelection = false;
            this.confusematrix.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20});
            this.confusematrix.Location = new System.Drawing.Point(17, 17);
            this.confusematrix.MinimumSize = new System.Drawing.Size(200, 100);
            this.confusematrix.MouseLocation = new System.Drawing.Point(-1, -1);
            this.confusematrix.MouseState = MaterialSkin.MouseState.OUT;
            this.confusematrix.MultiSelect = false;
            this.confusematrix.Name = "confusematrix";
            this.confusematrix.OwnerDraw = true;
            this.confusematrix.Size = new System.Drawing.Size(828, 274);
            this.confusematrix.TabIndex = 0;
            this.confusematrix.UseCompatibleStateImageBehavior = false;
            this.confusematrix.View = System.Windows.Forms.View.Details;
            this.confusematrix.VirtualListSize = 4;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Truth\\Predict";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "NG";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "PASS";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Repairable";
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Non Repair";
            this.columnHeader5.Width = 109;
            // 
            // materialCard10
            // 
            this.materialCard10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard10.Controls.Add(this.AiAccFlowLayoutPanel);
            this.materialCard10.Controls.Add(this.modifieddateLabel);
            this.materialCard10.Controls.Add(this.materialLabel57);
            this.materialCard10.Controls.Add(this.totalpercent);
            this.materialCard10.Controls.Add(this.materialLabel40);
            this.materialCard10.Controls.Add(this.totalProgressBar);
            this.materialCard10.Depth = 0;
            this.materialCard10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard10.Location = new System.Drawing.Point(43, 86);
            this.materialCard10.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard10.Name = "materialCard10";
            this.materialCard10.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard10.Size = new System.Drawing.Size(863, 300);
            this.materialCard10.TabIndex = 55;
            // 
            // AiAccFlowLayoutPanel
            // 
            this.AiAccFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.AiAccFlowLayoutPanel.Location = new System.Drawing.Point(272, 21);
            this.AiAccFlowLayoutPanel.Name = "AiAccFlowLayoutPanel";
            this.AiAccFlowLayoutPanel.Size = new System.Drawing.Size(580, 269);
            this.AiAccFlowLayoutPanel.TabIndex = 61;
            // 
            // modifieddateLabel
            // 
            this.modifieddateLabel.AutoSize = true;
            this.modifieddateLabel.Depth = 0;
            this.modifieddateLabel.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.modifieddateLabel.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.modifieddateLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.modifieddateLabel.Location = new System.Drawing.Point(113, 271);
            this.modifieddateLabel.MouseState = MaterialSkin.MouseState.HOVER;
            this.modifieddateLabel.Name = "modifieddateLabel";
            this.modifieddateLabel.Size = new System.Drawing.Size(27, 17);
            this.modifieddateLabel.TabIndex = 60;
            this.modifieddateLabel.Text = "now";
            // 
            // materialLabel57
            // 
            this.materialLabel57.AutoSize = true;
            this.materialLabel57.Depth = 0;
            this.materialLabel57.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel57.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel57.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel57.Location = new System.Drawing.Point(14, 272);
            this.materialLabel57.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel57.Name = "materialLabel57";
            this.materialLabel57.Size = new System.Drawing.Size(99, 17);
            this.materialLabel57.TabIndex = 59;
            this.materialLabel57.Text = "Last modified : ";
            // 
            // totalpercent
            // 
            this.totalpercent.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.totalpercent.AutoSize = true;
            this.totalpercent.Depth = 0;
            this.totalpercent.Font = new System.Drawing.Font("Roboto Light", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.totalpercent.FontType = MaterialSkin.MaterialSkinManager.fontType.H2;
            this.totalpercent.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.totalpercent.Location = new System.Drawing.Point(33, 109);
            this.totalpercent.MouseState = MaterialSkin.MouseState.HOVER;
            this.totalpercent.Name = "totalpercent";
            this.totalpercent.Size = new System.Drawing.Size(191, 72);
            this.totalpercent.TabIndex = 13;
            this.totalpercent.Text = "00.00%";
            this.totalpercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // materialLabel40
            // 
            this.materialLabel40.AutoSize = true;
            this.materialLabel40.Depth = 0;
            this.materialLabel40.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel40.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel40.Location = new System.Drawing.Point(32, 80);
            this.materialLabel40.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel40.Name = "materialLabel40";
            this.materialLabel40.Size = new System.Drawing.Size(134, 24);
            this.materialLabel40.TabIndex = 7;
            this.materialLabel40.Text = "Total Accuracy";
            // 
            // totalProgressBar
            // 
            this.totalProgressBar.Depth = 0;
            this.totalProgressBar.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.totalProgressBar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.totalProgressBar.Location = new System.Drawing.Point(29, 190);
            this.totalProgressBar.MouseState = MaterialSkin.MouseState.HOVER;
            this.totalProgressBar.Name = "totalProgressBar";
            this.totalProgressBar.Size = new System.Drawing.Size(200, 5);
            this.totalProgressBar.TabIndex = 6;
            // 
            // materialLabel36
            // 
            this.materialLabel36.AutoSize = true;
            this.materialLabel36.Depth = 0;
            this.materialLabel36.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel36.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel36.Location = new System.Drawing.Point(105, 38);
            this.materialLabel36.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel36.Name = "materialLabel36";
            this.materialLabel36.Size = new System.Drawing.Size(107, 24);
            this.materialLabel36.TabIndex = 54;
            this.materialLabel36.Text = "AI Accuracy";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::KinsusAutoAOI.Properties.Resources.acc;
            this.pictureBox16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox16.Location = new System.Drawing.Point(44, 23);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(52, 52);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 53;
            this.pictureBox16.TabStop = false;
            // 
            // SystemSetting
            // 
            this.SystemSetting.BackColor = System.Drawing.Color.White;
            this.SystemSetting.Controls.Add(this.systemsetting_save);
            this.SystemSetting.Controls.Add(this.materialComboBox4);
            this.SystemSetting.Controls.Add(this.materialLabel18);
            this.SystemSetting.Controls.Add(this.materialCard8);
            this.SystemSetting.Controls.Add(this.system_setting);
            this.SystemSetting.ImageKey = "3524589.png";
            this.SystemSetting.Location = new System.Drawing.Point(4, 39);
            this.SystemSetting.Name = "SystemSetting";
            this.SystemSetting.Padding = new System.Windows.Forms.Padding(3);
            this.SystemSetting.Size = new System.Drawing.Size(984, 736);
            this.SystemSetting.TabIndex = 6;
            this.SystemSetting.Text = "System Setting";
            // 
            // systemsetting_save
            // 
            this.systemsetting_save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.systemsetting_save.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.systemsetting_save.Depth = 0;
            this.systemsetting_save.HighEmphasis = true;
            this.systemsetting_save.Icon = ((System.Drawing.Image)(resources.GetObject("systemsetting_save.Icon")));
            this.systemsetting_save.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.systemsetting_save.Location = new System.Drawing.Point(820, 30);
            this.systemsetting_save.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.systemsetting_save.MouseState = MaterialSkin.MouseState.HOVER;
            this.systemsetting_save.Name = "systemsetting_save";
            this.systemsetting_save.NoAccentTextColor = System.Drawing.Color.Empty;
            this.systemsetting_save.Size = new System.Drawing.Size(86, 36);
            this.systemsetting_save.TabIndex = 37;
            this.systemsetting_save.Text = "SAVE";
            this.systemsetting_save.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.systemsetting_save.UseAccentColor = true;
            this.systemsetting_save.UseVisualStyleBackColor = true;
            this.systemsetting_save.Click += new System.EventHandler(this.systemSettingSaveClick);
            // 
            // materialComboBox4
            // 
            this.materialComboBox4.AutoResize = false;
            this.materialComboBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialComboBox4.Depth = 0;
            this.materialComboBox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.materialComboBox4.DropDownHeight = 174;
            this.materialComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.materialComboBox4.DropDownWidth = 121;
            this.materialComboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialComboBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialComboBox4.FormattingEnabled = true;
            this.materialComboBox4.Hint = "Select System";
            this.materialComboBox4.IntegralHeight = false;
            this.materialComboBox4.ItemHeight = 43;
            this.materialComboBox4.Location = new System.Drawing.Point(532, 20);
            this.materialComboBox4.MaxDropDownItems = 4;
            this.materialComboBox4.MouseState = MaterialSkin.MouseState.OUT;
            this.materialComboBox4.Name = "materialComboBox4";
            this.materialComboBox4.Size = new System.Drawing.Size(254, 49);
            this.materialComboBox4.StartIndex = 0;
            this.materialComboBox4.TabIndex = 36;
            this.materialComboBox4.SelectedIndexChanged += new System.EventHandler(this.systemSettingSelectedIndexChanged);
            // 
            // materialLabel18
            // 
            this.materialLabel18.AutoSize = true;
            this.materialLabel18.Depth = 0;
            this.materialLabel18.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel18.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel18.Location = new System.Drawing.Point(105, 38);
            this.materialLabel18.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel18.Name = "materialLabel18";
            this.materialLabel18.Size = new System.Drawing.Size(137, 24);
            this.materialLabel18.TabIndex = 34;
            this.materialLabel18.Text = "System Setting";
            // 
            // materialCard8
            // 
            this.materialCard8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard8.Controls.Add(this.materialLabel48);
            this.materialCard8.Controls.Add(this.selectWorkFolderButton);
            this.materialCard8.Controls.Add(this.workFolderTextBox);
            this.materialCard8.Controls.Add(this.selectcsvfolderButton);
            this.materialCard8.Controls.Add(this.materialLabel28);
            this.materialCard8.Controls.Add(this.grayShareFolderTextBox);
            this.materialCard8.Controls.Add(this.materialLabel54);
            this.materialCard8.Controls.Add(this.materialLabel53);
            this.materialCard8.Controls.Add(this.exportadd);
            this.materialCard8.Controls.Add(this.exportFolderList);
            this.materialCard8.Controls.Add(this.exportremove);
            this.materialCard8.Controls.Add(this.delayAfterMonitorTextBox);
            this.materialCard8.Controls.Add(this.materialLabel39);
            this.materialCard8.Controls.Add(this.selectbackupButton);
            this.materialCard8.Controls.Add(this.materialLabel37);
            this.materialCard8.Controls.Add(this.backupTextBox);
            this.materialCard8.Controls.Add(this.systemNameTextBox);
            this.materialCard8.Controls.Add(this.monitorFreqTextBox);
            this.materialCard8.Controls.Add(this.selectsharefolderButton);
            this.materialCard8.Controls.Add(this.imageSaveFolderTextBox);
            this.materialCard8.Controls.Add(this.materialLabel30);
            this.materialCard8.Controls.Add(this.materialLabel29);
            this.materialCard8.Controls.Add(this.rejudgeTimeOutTextBox);
            this.materialCard8.Controls.Add(this.portTextBox);
            this.materialCard8.Controls.Add(this.materialLabel27);
            this.materialCard8.Controls.Add(this.ipTextBox);
            this.materialCard8.Controls.Add(this.selectimportButton);
            this.materialCard8.Controls.Add(this.materialLabel25);
            this.materialCard8.Controls.Add(this.importFolderTextBox);
            this.materialCard8.Controls.Add(this.selectexportButton);
            this.materialCard8.Controls.Add(this.materialLabel24);
            this.materialCard8.Controls.Add(this.exportTextBox);
            this.materialCard8.Controls.Add(this.materialLabel23);
            this.materialCard8.Depth = 0;
            this.materialCard8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard8.Location = new System.Drawing.Point(43, 86);
            this.materialCard8.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard8.Name = "materialCard8";
            this.materialCard8.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard8.Size = new System.Drawing.Size(863, 633);
            this.materialCard8.TabIndex = 33;
            // 
            // materialLabel48
            // 
            this.materialLabel48.AutoSize = true;
            this.materialLabel48.Depth = 0;
            this.materialLabel48.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel48.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel48.Location = new System.Drawing.Point(56, 400);
            this.materialLabel48.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel48.Name = "materialLabel48";
            this.materialLabel48.Size = new System.Drawing.Size(77, 17);
            this.materialLabel48.TabIndex = 60;
            this.materialLabel48.Text = "Work Folder";
            // 
            // selectWorkFolderButton
            // 
            this.selectWorkFolderButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectWorkFolderButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectWorkFolderButton.Depth = 0;
            this.selectWorkFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectWorkFolderButton.HighEmphasis = false;
            this.selectWorkFolderButton.Icon = null;
            this.selectWorkFolderButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectWorkFolderButton.Location = new System.Drawing.Point(759, 391);
            this.selectWorkFolderButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectWorkFolderButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectWorkFolderButton.Name = "selectWorkFolderButton";
            this.selectWorkFolderButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectWorkFolderButton.Size = new System.Drawing.Size(74, 36);
            this.selectWorkFolderButton.TabIndex = 59;
            this.selectWorkFolderButton.Text = "select";
            this.selectWorkFolderButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectWorkFolderButton.UseAccentColor = false;
            this.selectWorkFolderButton.UseVisualStyleBackColor = true;
            this.selectWorkFolderButton.Click += new System.EventHandler(this.selectWorkFolderButton_Click);
            // 
            // workFolderTextBox
            // 
            this.workFolderTextBox.AnimateReadOnly = false;
            this.workFolderTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.workFolderTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.workFolderTextBox.Depth = 0;
            this.workFolderTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.workFolderTextBox.HideSelection = true;
            this.workFolderTextBox.Hint = "Ex : \\\\ThisCpmputer\\Work_folder";
            this.workFolderTextBox.LeadingIcon = null;
            this.workFolderTextBox.Location = new System.Drawing.Point(173, 385);
            this.workFolderTextBox.MaxLength = 128;
            this.workFolderTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.workFolderTextBox.Name = "workFolderTextBox";
            this.workFolderTextBox.PasswordChar = '\0';
            this.workFolderTextBox.PrefixSuffixText = null;
            this.workFolderTextBox.ReadOnly = false;
            this.workFolderTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.workFolderTextBox.SelectedText = "";
            this.workFolderTextBox.SelectionLength = 0;
            this.workFolderTextBox.SelectionStart = 0;
            this.workFolderTextBox.ShortcutsEnabled = true;
            this.workFolderTextBox.Size = new System.Drawing.Size(570, 48);
            this.workFolderTextBox.TabIndex = 58;
            this.workFolderTextBox.TabStop = false;
            this.workFolderTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.workFolderTextBox.TrailingIcon = null;
            this.workFolderTextBox.UseSystemPasswordChar = false;
            // 
            // selectcsvfolderButton
            // 
            this.selectcsvfolderButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectcsvfolderButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectcsvfolderButton.Depth = 0;
            this.selectcsvfolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectcsvfolderButton.HighEmphasis = false;
            this.selectcsvfolderButton.Icon = null;
            this.selectcsvfolderButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectcsvfolderButton.Location = new System.Drawing.Point(759, 582);
            this.selectcsvfolderButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectcsvfolderButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectcsvfolderButton.Name = "selectcsvfolderButton";
            this.selectcsvfolderButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectcsvfolderButton.Size = new System.Drawing.Size(74, 36);
            this.selectcsvfolderButton.TabIndex = 57;
            this.selectcsvfolderButton.Text = "select";
            this.selectcsvfolderButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectcsvfolderButton.UseAccentColor = false;
            this.selectcsvfolderButton.UseVisualStyleBackColor = true;
            this.selectcsvfolderButton.Click += new System.EventHandler(this.selectCsvFolderButtonClick);
            // 
            // materialLabel28
            // 
            this.materialLabel28.AutoSize = true;
            this.materialLabel28.Depth = 0;
            this.materialLabel28.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel28.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel28.Location = new System.Drawing.Point(29, 591);
            this.materialLabel28.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel28.Name = "materialLabel28";
            this.materialLabel28.Size = new System.Drawing.Size(115, 17);
            this.materialLabel28.TabIndex = 56;
            this.materialLabel28.Text = "Gray Share Folder";
            // 
            // grayShareFolderTextBox
            // 
            this.grayShareFolderTextBox.AnimateReadOnly = false;
            this.grayShareFolderTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.grayShareFolderTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.grayShareFolderTextBox.Depth = 0;
            this.grayShareFolderTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grayShareFolderTextBox.HideSelection = true;
            this.grayShareFolderTextBox.Hint = "Ex : \\\\GrayComputer\\Share_folder";
            this.grayShareFolderTextBox.LeadingIcon = null;
            this.grayShareFolderTextBox.Location = new System.Drawing.Point(173, 576);
            this.grayShareFolderTextBox.MaxLength = 128;
            this.grayShareFolderTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.grayShareFolderTextBox.Name = "grayShareFolderTextBox";
            this.grayShareFolderTextBox.PasswordChar = '\0';
            this.grayShareFolderTextBox.PrefixSuffixText = null;
            this.grayShareFolderTextBox.ReadOnly = false;
            this.grayShareFolderTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.grayShareFolderTextBox.SelectedText = "";
            this.grayShareFolderTextBox.SelectionLength = 0;
            this.grayShareFolderTextBox.SelectionStart = 0;
            this.grayShareFolderTextBox.ShortcutsEnabled = true;
            this.grayShareFolderTextBox.Size = new System.Drawing.Size(570, 48);
            this.grayShareFolderTextBox.TabIndex = 55;
            this.grayShareFolderTextBox.TabStop = false;
            this.grayShareFolderTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.grayShareFolderTextBox.TrailingIcon = null;
            this.grayShareFolderTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel54
            // 
            this.materialLabel54.AutoSize = true;
            this.materialLabel54.Depth = 0;
            this.materialLabel54.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel54.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel54.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel54.Location = new System.Drawing.Point(56, 339);
            this.materialLabel54.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel54.Name = "materialLabel54";
            this.materialLabel54.Size = new System.Drawing.Size(76, 17);
            this.materialLabel54.TabIndex = 54;
            this.materialLabel54.Text = "Save Folder";
            // 
            // materialLabel53
            // 
            this.materialLabel53.AutoSize = true;
            this.materialLabel53.Depth = 0;
            this.materialLabel53.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel53.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel53.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel53.Location = new System.Drawing.Point(28, 139);
            this.materialLabel53.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel53.Name = "materialLabel53";
            this.materialLabel53.Size = new System.Drawing.Size(129, 17);
            this.materialLabel53.TabIndex = 53;
            this.materialLabel53.Text = "(select 1 or 2 folder)";
            // 
            // exportadd
            // 
            this.exportadd.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.exportadd.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.exportadd.Depth = 0;
            this.exportadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportadd.HighEmphasis = false;
            this.exportadd.Icon = null;
            this.exportadd.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.exportadd.Location = new System.Drawing.Point(759, 107);
            this.exportadd.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.exportadd.MouseState = MaterialSkin.MouseState.HOVER;
            this.exportadd.Name = "exportadd";
            this.exportadd.NoAccentTextColor = System.Drawing.Color.Empty;
            this.exportadd.Size = new System.Drawing.Size(64, 36);
            this.exportadd.TabIndex = 52;
            this.exportadd.Text = "+ Add";
            this.exportadd.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.exportadd.UseAccentColor = false;
            this.exportadd.UseVisualStyleBackColor = true;
            this.exportadd.Click += new System.EventHandler(this.exportadd_Click);
            // 
            // exportFolderList
            // 
            this.exportFolderList.AllowDrop = true;
            this.exportFolderList.BackColor = System.Drawing.Color.LightGray;
            this.exportFolderList.BorderColor = System.Drawing.Color.LightGray;
            this.exportFolderList.Depth = 0;
            this.exportFolderList.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.exportFolderList.Location = new System.Drawing.Point(173, 152);
            this.exportFolderList.MouseState = MaterialSkin.MouseState.HOVER;
            this.exportFolderList.Name = "exportFolderList";
            this.exportFolderList.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.exportFolderList.SelectedIndex = -1;
            this.exportFolderList.SelectedItem = null;
            this.exportFolderList.ShowScrollBar = true;
            this.exportFolderList.Size = new System.Drawing.Size(569, 99);
            this.exportFolderList.TabIndex = 51;
            // 
            // exportremove
            // 
            this.exportremove.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.exportremove.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.exportremove.Depth = 0;
            this.exportremove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exportremove.HighEmphasis = false;
            this.exportremove.Icon = null;
            this.exportremove.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.exportremove.Location = new System.Drawing.Point(759, 168);
            this.exportremove.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.exportremove.MouseState = MaterialSkin.MouseState.HOVER;
            this.exportremove.Name = "exportremove";
            this.exportremove.NoAccentTextColor = System.Drawing.Color.Empty;
            this.exportremove.Size = new System.Drawing.Size(93, 36);
            this.exportremove.TabIndex = 50;
            this.exportremove.Text = "– Remove";
            this.exportremove.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.exportremove.UseAccentColor = false;
            this.exportremove.UseVisualStyleBackColor = true;
            this.exportremove.Click += new System.EventHandler(this.exportremove_Click);
            // 
            // delayAfterMonitorTextBox
            // 
            this.delayAfterMonitorTextBox.AnimateReadOnly = false;
            this.delayAfterMonitorTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.delayAfterMonitorTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.delayAfterMonitorTextBox.Depth = 0;
            this.delayAfterMonitorTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.delayAfterMonitorTextBox.HideSelection = true;
            this.delayAfterMonitorTextBox.Hint = "Ex : 5";
            this.delayAfterMonitorTextBox.LeadingIcon = null;
            this.delayAfterMonitorTextBox.Location = new System.Drawing.Point(562, 39);
            this.delayAfterMonitorTextBox.MaxLength = 2;
            this.delayAfterMonitorTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.delayAfterMonitorTextBox.Name = "delayAfterMonitorTextBox";
            this.delayAfterMonitorTextBox.PasswordChar = '\0';
            this.delayAfterMonitorTextBox.PrefixSuffixText = null;
            this.delayAfterMonitorTextBox.ReadOnly = false;
            this.delayAfterMonitorTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.delayAfterMonitorTextBox.SelectedText = "";
            this.delayAfterMonitorTextBox.SelectionLength = 0;
            this.delayAfterMonitorTextBox.SelectionStart = 0;
            this.delayAfterMonitorTextBox.ShortcutsEnabled = true;
            this.delayAfterMonitorTextBox.Size = new System.Drawing.Size(180, 48);
            this.delayAfterMonitorTextBox.TabIndex = 49;
            this.delayAfterMonitorTextBox.TabStop = false;
            this.delayAfterMonitorTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.delayAfterMonitorTextBox.TrailingIcon = null;
            this.delayAfterMonitorTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel39
            // 
            this.materialLabel39.AutoSize = true;
            this.materialLabel39.Depth = 0;
            this.materialLabel39.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel39.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel39.Location = new System.Drawing.Point(565, 18);
            this.materialLabel39.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel39.Name = "materialLabel39";
            this.materialLabel39.Size = new System.Drawing.Size(160, 17);
            this.materialLabel39.TabIndex = 48;
            this.materialLabel39.Text = "Delay After Monitor (sec)";
            // 
            // selectbackupButton
            // 
            this.selectbackupButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectbackupButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectbackupButton.Depth = 0;
            this.selectbackupButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectbackupButton.HighEmphasis = false;
            this.selectbackupButton.Icon = null;
            this.selectbackupButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectbackupButton.Location = new System.Drawing.Point(759, 454);
            this.selectbackupButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectbackupButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectbackupButton.Name = "selectbackupButton";
            this.selectbackupButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectbackupButton.Size = new System.Drawing.Size(74, 36);
            this.selectbackupButton.TabIndex = 47;
            this.selectbackupButton.Text = "select";
            this.selectbackupButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectbackupButton.UseAccentColor = false;
            this.selectbackupButton.UseVisualStyleBackColor = true;
            this.selectbackupButton.Click += new System.EventHandler(this.selectBackupButtonClick);
            // 
            // materialLabel37
            // 
            this.materialLabel37.AutoSize = true;
            this.materialLabel37.Depth = 0;
            this.materialLabel37.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel37.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel37.Location = new System.Drawing.Point(45, 463);
            this.materialLabel37.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel37.Name = "materialLabel37";
            this.materialLabel37.Size = new System.Drawing.Size(92, 17);
            this.materialLabel37.TabIndex = 46;
            this.materialLabel37.Text = "Backup Folder";
            // 
            // backupTextBox
            // 
            this.backupTextBox.AnimateReadOnly = false;
            this.backupTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.backupTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.backupTextBox.Depth = 0;
            this.backupTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.backupTextBox.HideSelection = true;
            this.backupTextBox.LeadingIcon = null;
            this.backupTextBox.Location = new System.Drawing.Point(173, 448);
            this.backupTextBox.MaxLength = 128;
            this.backupTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.backupTextBox.Name = "backupTextBox";
            this.backupTextBox.PasswordChar = '\0';
            this.backupTextBox.PrefixSuffixText = null;
            this.backupTextBox.ReadOnly = false;
            this.backupTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.backupTextBox.SelectedText = "";
            this.backupTextBox.SelectionLength = 0;
            this.backupTextBox.SelectionStart = 0;
            this.backupTextBox.ShortcutsEnabled = true;
            this.backupTextBox.Size = new System.Drawing.Size(570, 48);
            this.backupTextBox.TabIndex = 45;
            this.backupTextBox.TabStop = false;
            this.backupTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.backupTextBox.TrailingIcon = null;
            this.backupTextBox.UseSystemPasswordChar = false;
            // 
            // systemNameTextBox
            // 
            this.systemNameTextBox.AnimateReadOnly = false;
            this.systemNameTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.systemNameTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.systemNameTextBox.Depth = 0;
            this.systemNameTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.systemNameTextBox.HideSelection = true;
            this.systemNameTextBox.LeadingIcon = null;
            this.systemNameTextBox.Location = new System.Drawing.Point(42, 39);
            this.systemNameTextBox.MaxLength = 50;
            this.systemNameTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.systemNameTextBox.Name = "systemNameTextBox";
            this.systemNameTextBox.PasswordChar = '\0';
            this.systemNameTextBox.PrefixSuffixText = null;
            this.systemNameTextBox.ReadOnly = false;
            this.systemNameTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.systemNameTextBox.SelectedText = "";
            this.systemNameTextBox.SelectionLength = 0;
            this.systemNameTextBox.SelectionStart = 0;
            this.systemNameTextBox.ShortcutsEnabled = true;
            this.systemNameTextBox.Size = new System.Drawing.Size(180, 48);
            this.systemNameTextBox.TabIndex = 44;
            this.systemNameTextBox.TabStop = false;
            this.systemNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.systemNameTextBox.TrailingIcon = null;
            this.systemNameTextBox.UseSystemPasswordChar = false;
            // 
            // monitorFreqTextBox
            // 
            this.monitorFreqTextBox.AnimateReadOnly = false;
            this.monitorFreqTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.monitorFreqTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.monitorFreqTextBox.Depth = 0;
            this.monitorFreqTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.monitorFreqTextBox.HideSelection = true;
            this.monitorFreqTextBox.Hint = "Ex : 5";
            this.monitorFreqTextBox.LeadingIcon = null;
            this.monitorFreqTextBox.Location = new System.Drawing.Point(302, 39);
            this.monitorFreqTextBox.MaxLength = 2;
            this.monitorFreqTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.monitorFreqTextBox.Name = "monitorFreqTextBox";
            this.monitorFreqTextBox.PasswordChar = '\0';
            this.monitorFreqTextBox.PrefixSuffixText = null;
            this.monitorFreqTextBox.ReadOnly = false;
            this.monitorFreqTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.monitorFreqTextBox.SelectedText = "";
            this.monitorFreqTextBox.SelectionLength = 0;
            this.monitorFreqTextBox.SelectionStart = 0;
            this.monitorFreqTextBox.ShortcutsEnabled = true;
            this.monitorFreqTextBox.Size = new System.Drawing.Size(180, 48);
            this.monitorFreqTextBox.TabIndex = 43;
            this.monitorFreqTextBox.TabStop = false;
            this.monitorFreqTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.monitorFreqTextBox.TrailingIcon = null;
            this.monitorFreqTextBox.UseSystemPasswordChar = false;
            // 
            // selectsharefolderButton
            // 
            this.selectsharefolderButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectsharefolderButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectsharefolderButton.Depth = 0;
            this.selectsharefolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectsharefolderButton.HighEmphasis = false;
            this.selectsharefolderButton.Icon = null;
            this.selectsharefolderButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectsharefolderButton.Location = new System.Drawing.Point(759, 330);
            this.selectsharefolderButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectsharefolderButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectsharefolderButton.Name = "selectsharefolderButton";
            this.selectsharefolderButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectsharefolderButton.Size = new System.Drawing.Size(74, 36);
            this.selectsharefolderButton.TabIndex = 42;
            this.selectsharefolderButton.Text = "select";
            this.selectsharefolderButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectsharefolderButton.UseAccentColor = false;
            this.selectsharefolderButton.UseVisualStyleBackColor = true;
            this.selectsharefolderButton.Click += new System.EventHandler(this.selectShareFolderButtonClick);
            // 
            // imageSaveFolderTextBox
            // 
            this.imageSaveFolderTextBox.AnimateReadOnly = false;
            this.imageSaveFolderTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.imageSaveFolderTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.imageSaveFolderTextBox.Depth = 0;
            this.imageSaveFolderTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.imageSaveFolderTextBox.HideSelection = true;
            this.imageSaveFolderTextBox.Hint = "Ex : \\\\ThisCpmputer\\AI_data";
            this.imageSaveFolderTextBox.LeadingIcon = null;
            this.imageSaveFolderTextBox.Location = new System.Drawing.Point(173, 324);
            this.imageSaveFolderTextBox.MaxLength = 128;
            this.imageSaveFolderTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.imageSaveFolderTextBox.Name = "imageSaveFolderTextBox";
            this.imageSaveFolderTextBox.PasswordChar = '\0';
            this.imageSaveFolderTextBox.PrefixSuffixText = null;
            this.imageSaveFolderTextBox.ReadOnly = false;
            this.imageSaveFolderTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.imageSaveFolderTextBox.SelectedText = "";
            this.imageSaveFolderTextBox.SelectionLength = 0;
            this.imageSaveFolderTextBox.SelectionStart = 0;
            this.imageSaveFolderTextBox.ShortcutsEnabled = true;
            this.imageSaveFolderTextBox.Size = new System.Drawing.Size(570, 48);
            this.imageSaveFolderTextBox.TabIndex = 40;
            this.imageSaveFolderTextBox.TabStop = false;
            this.imageSaveFolderTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.imageSaveFolderTextBox.TrailingIcon = null;
            this.imageSaveFolderTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel30
            // 
            this.materialLabel30.AutoSize = true;
            this.materialLabel30.Depth = 0;
            this.materialLabel30.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel30.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel30.Location = new System.Drawing.Point(305, 18);
            this.materialLabel30.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel30.Name = "materialLabel30";
            this.materialLabel30.Size = new System.Drawing.Size(176, 17);
            this.materialLabel30.TabIndex = 39;
            this.materialLabel30.Text = "Monitoring Frequency (sec)";
            // 
            // materialLabel29
            // 
            this.materialLabel29.AutoSize = true;
            this.materialLabel29.Depth = 0;
            this.materialLabel29.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel29.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel29.Location = new System.Drawing.Point(41, 516);
            this.materialLabel29.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel29.Name = "materialLabel29";
            this.materialLabel29.Size = new System.Drawing.Size(100, 17);
            this.materialLabel29.TabIndex = 37;
            this.materialLabel29.Text = "Rejudge Center";
            // 
            // rejudgeTimeOutTextBox
            // 
            this.rejudgeTimeOutTextBox.AnimateReadOnly = false;
            this.rejudgeTimeOutTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.rejudgeTimeOutTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.rejudgeTimeOutTextBox.Depth = 0;
            this.rejudgeTimeOutTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.rejudgeTimeOutTextBox.HideSelection = true;
            this.rejudgeTimeOutTextBox.Hint = "TimeOut";
            this.rejudgeTimeOutTextBox.LeadingIcon = null;
            this.rejudgeTimeOutTextBox.Location = new System.Drawing.Point(173, 512);
            this.rejudgeTimeOutTextBox.MaxLength = 50;
            this.rejudgeTimeOutTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.rejudgeTimeOutTextBox.Name = "rejudgeTimeOutTextBox";
            this.rejudgeTimeOutTextBox.PasswordChar = '\0';
            this.rejudgeTimeOutTextBox.PrefixSuffixText = null;
            this.rejudgeTimeOutTextBox.ReadOnly = false;
            this.rejudgeTimeOutTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rejudgeTimeOutTextBox.SelectedText = "";
            this.rejudgeTimeOutTextBox.SelectionLength = 0;
            this.rejudgeTimeOutTextBox.SelectionStart = 0;
            this.rejudgeTimeOutTextBox.ShortcutsEnabled = true;
            this.rejudgeTimeOutTextBox.Size = new System.Drawing.Size(155, 48);
            this.rejudgeTimeOutTextBox.TabIndex = 36;
            this.rejudgeTimeOutTextBox.TabStop = false;
            this.rejudgeTimeOutTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.rejudgeTimeOutTextBox.TrailingIcon = null;
            this.rejudgeTimeOutTextBox.UseSystemPasswordChar = false;
            // 
            // portTextBox
            // 
            this.portTextBox.AnimateReadOnly = false;
            this.portTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.portTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.portTextBox.Depth = 0;
            this.portTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.portTextBox.HideSelection = true;
            this.portTextBox.Hint = "Port";
            this.portTextBox.LeadingIcon = null;
            this.portTextBox.Location = new System.Drawing.Point(587, 512);
            this.portTextBox.MaxLength = 50;
            this.portTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.portTextBox.Name = "portTextBox";
            this.portTextBox.PasswordChar = '\0';
            this.portTextBox.PrefixSuffixText = null;
            this.portTextBox.ReadOnly = false;
            this.portTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.portTextBox.SelectedText = "";
            this.portTextBox.SelectionLength = 0;
            this.portTextBox.SelectionStart = 0;
            this.portTextBox.ShortcutsEnabled = true;
            this.portTextBox.Size = new System.Drawing.Size(155, 48);
            this.portTextBox.TabIndex = 34;
            this.portTextBox.TabStop = false;
            this.portTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.portTextBox.TrailingIcon = null;
            this.portTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel27
            // 
            this.materialLabel27.AutoSize = true;
            this.materialLabel27.Depth = 0;
            this.materialLabel27.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel27.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel27.Location = new System.Drawing.Point(68, 536);
            this.materialLabel27.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel27.Name = "materialLabel27";
            this.materialLabel27.Size = new System.Drawing.Size(47, 17);
            this.materialLabel27.TabIndex = 31;
            this.materialLabel27.Text = "Setting";
            // 
            // ipTextBox
            // 
            this.ipTextBox.AnimateReadOnly = false;
            this.ipTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ipTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.ipTextBox.Depth = 0;
            this.ipTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ipTextBox.HideSelection = true;
            this.ipTextBox.Hint = "IP";
            this.ipTextBox.LeadingIcon = null;
            this.ipTextBox.Location = new System.Drawing.Point(380, 512);
            this.ipTextBox.MaxLength = 50;
            this.ipTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.ipTextBox.Name = "ipTextBox";
            this.ipTextBox.PasswordChar = '\0';
            this.ipTextBox.PrefixSuffixText = null;
            this.ipTextBox.ReadOnly = false;
            this.ipTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ipTextBox.SelectedText = "";
            this.ipTextBox.SelectionLength = 0;
            this.ipTextBox.SelectionStart = 0;
            this.ipTextBox.ShortcutsEnabled = true;
            this.ipTextBox.Size = new System.Drawing.Size(155, 48);
            this.ipTextBox.TabIndex = 30;
            this.ipTextBox.TabStop = false;
            this.ipTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ipTextBox.TrailingIcon = null;
            this.ipTextBox.UseSystemPasswordChar = false;
            // 
            // selectimportButton
            // 
            this.selectimportButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectimportButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectimportButton.Depth = 0;
            this.selectimportButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectimportButton.HighEmphasis = false;
            this.selectimportButton.Icon = null;
            this.selectimportButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectimportButton.Location = new System.Drawing.Point(759, 268);
            this.selectimportButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectimportButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectimportButton.Name = "selectimportButton";
            this.selectimportButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectimportButton.Size = new System.Drawing.Size(74, 36);
            this.selectimportButton.TabIndex = 29;
            this.selectimportButton.Text = "select";
            this.selectimportButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectimportButton.UseAccentColor = false;
            this.selectimportButton.UseVisualStyleBackColor = true;
            this.selectimportButton.Click += new System.EventHandler(this.selectImportButtonClick);
            // 
            // materialLabel25
            // 
            this.materialLabel25.AutoSize = true;
            this.materialLabel25.Depth = 0;
            this.materialLabel25.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel25.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel25.Location = new System.Drawing.Point(48, 279);
            this.materialLabel25.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel25.Name = "materialLabel25";
            this.materialLabel25.Size = new System.Drawing.Size(87, 17);
            this.materialLabel25.TabIndex = 28;
            this.materialLabel25.Text = "Import Folder";
            // 
            // importFolderTextBox
            // 
            this.importFolderTextBox.AnimateReadOnly = false;
            this.importFolderTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.importFolderTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.importFolderTextBox.Depth = 0;
            this.importFolderTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.importFolderTextBox.HideSelection = true;
            this.importFolderTextBox.Hint = "Ex : \\\\CIMS\\Import";
            this.importFolderTextBox.LeadingIcon = null;
            this.importFolderTextBox.Location = new System.Drawing.Point(173, 262);
            this.importFolderTextBox.MaxLength = 128;
            this.importFolderTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.importFolderTextBox.Name = "importFolderTextBox";
            this.importFolderTextBox.PasswordChar = '\0';
            this.importFolderTextBox.PrefixSuffixText = null;
            this.importFolderTextBox.ReadOnly = false;
            this.importFolderTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.importFolderTextBox.SelectedText = "";
            this.importFolderTextBox.SelectionLength = 0;
            this.importFolderTextBox.SelectionStart = 0;
            this.importFolderTextBox.ShortcutsEnabled = true;
            this.importFolderTextBox.Size = new System.Drawing.Size(570, 48);
            this.importFolderTextBox.TabIndex = 27;
            this.importFolderTextBox.TabStop = false;
            this.importFolderTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.importFolderTextBox.TrailingIcon = null;
            this.importFolderTextBox.UseSystemPasswordChar = false;
            // 
            // selectexportButton
            // 
            this.selectexportButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectexportButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectexportButton.Depth = 0;
            this.selectexportButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectexportButton.HighEmphasis = false;
            this.selectexportButton.Icon = null;
            this.selectexportButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectexportButton.Location = new System.Drawing.Point(58, 168);
            this.selectexportButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectexportButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectexportButton.Name = "selectexportButton";
            this.selectexportButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectexportButton.Size = new System.Drawing.Size(74, 36);
            this.selectexportButton.TabIndex = 26;
            this.selectexportButton.Text = "select";
            this.selectexportButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectexportButton.UseAccentColor = false;
            this.selectexportButton.UseVisualStyleBackColor = true;
            this.selectexportButton.Click += new System.EventHandler(this.selectExportButtonClick);
            // 
            // materialLabel24
            // 
            this.materialLabel24.AutoSize = true;
            this.materialLabel24.Depth = 0;
            this.materialLabel24.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel24.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel24.Location = new System.Drawing.Point(46, 116);
            this.materialLabel24.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel24.Name = "materialLabel24";
            this.materialLabel24.Size = new System.Drawing.Size(86, 17);
            this.materialLabel24.TabIndex = 25;
            this.materialLabel24.Text = "Export Folder";
            // 
            // exportTextBox
            // 
            this.exportTextBox.AnimateReadOnly = false;
            this.exportTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exportTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.exportTextBox.Depth = 0;
            this.exportTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.exportTextBox.HideSelection = true;
            this.exportTextBox.LeadingIcon = null;
            this.exportTextBox.Location = new System.Drawing.Point(173, 99);
            this.exportTextBox.MaxLength = 128;
            this.exportTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.exportTextBox.Name = "exportTextBox";
            this.exportTextBox.PasswordChar = '\0';
            this.exportTextBox.PrefixSuffixText = null;
            this.exportTextBox.ReadOnly = false;
            this.exportTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.exportTextBox.SelectedText = "";
            this.exportTextBox.SelectionLength = 0;
            this.exportTextBox.SelectionStart = 0;
            this.exportTextBox.ShortcutsEnabled = true;
            this.exportTextBox.Size = new System.Drawing.Size(570, 48);
            this.exportTextBox.TabIndex = 24;
            this.exportTextBox.TabStop = false;
            this.exportTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.exportTextBox.TrailingIcon = null;
            this.exportTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel23
            // 
            this.materialLabel23.AutoSize = true;
            this.materialLabel23.Depth = 0;
            this.materialLabel23.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel23.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel23.Location = new System.Drawing.Point(46, 18);
            this.materialLabel23.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel23.Name = "materialLabel23";
            this.materialLabel23.Size = new System.Drawing.Size(89, 17);
            this.materialLabel23.TabIndex = 23;
            this.materialLabel23.Text = "System Name";
            // 
            // system_setting
            // 
            this.system_setting.Image = ((System.Drawing.Image)(resources.GetObject("system_setting.Image")));
            this.system_setting.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.system_setting.Location = new System.Drawing.Point(43, 20);
            this.system_setting.Name = "system_setting";
            this.system_setting.Size = new System.Drawing.Size(54, 54);
            this.system_setting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.system_setting.TabIndex = 32;
            this.system_setting.TabStop = false;
            // 
            // ProductSetting
            // 
            this.ProductSetting.BackColor = System.Drawing.Color.White;
            this.ProductSetting.Controls.Add(this.materialComboBox2);
            this.ProductSetting.Controls.Add(this.materialLabel16);
            this.ProductSetting.Controls.Add(this.productsetting_save);
            this.ProductSetting.Controls.Add(this.materialCard7);
            this.ProductSetting.Controls.Add(this.product_setting);
            this.ProductSetting.ImageKey = "4059496.png";
            this.ProductSetting.Location = new System.Drawing.Point(4, 39);
            this.ProductSetting.Name = "ProductSetting";
            this.ProductSetting.Size = new System.Drawing.Size(984, 736);
            this.ProductSetting.TabIndex = 5;
            this.ProductSetting.Text = "Product Setting";
            // 
            // materialComboBox2
            // 
            this.materialComboBox2.AutoResize = false;
            this.materialComboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialComboBox2.Depth = 0;
            this.materialComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.materialComboBox2.DropDownHeight = 174;
            this.materialComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.materialComboBox2.DropDownWidth = 121;
            this.materialComboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialComboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialComboBox2.FormattingEnabled = true;
            this.materialComboBox2.Hint = "Select Product";
            this.materialComboBox2.IntegralHeight = false;
            this.materialComboBox2.ItemHeight = 43;
            this.materialComboBox2.Location = new System.Drawing.Point(532, 20);
            this.materialComboBox2.MaxDropDownItems = 4;
            this.materialComboBox2.MouseState = MaterialSkin.MouseState.OUT;
            this.materialComboBox2.Name = "materialComboBox2";
            this.materialComboBox2.Size = new System.Drawing.Size(254, 49);
            this.materialComboBox2.StartIndex = 0;
            this.materialComboBox2.TabIndex = 35;
            this.materialComboBox2.SelectedIndexChanged += new System.EventHandler(this.productSettingSelectedIndexChanged);
            // 
            // materialLabel16
            // 
            this.materialLabel16.AutoSize = true;
            this.materialLabel16.Depth = 0;
            this.materialLabel16.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel16.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel16.Location = new System.Drawing.Point(104, 38);
            this.materialLabel16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel16.Name = "materialLabel16";
            this.materialLabel16.Size = new System.Drawing.Size(140, 24);
            this.materialLabel16.TabIndex = 28;
            this.materialLabel16.Text = "Product Setting";
            // 
            // productsetting_save
            // 
            this.productsetting_save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.productsetting_save.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.productsetting_save.Depth = 0;
            this.productsetting_save.HighEmphasis = true;
            this.productsetting_save.Icon = ((System.Drawing.Image)(resources.GetObject("productsetting_save.Icon")));
            this.productsetting_save.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.productsetting_save.Location = new System.Drawing.Point(820, 30);
            this.productsetting_save.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.productsetting_save.MouseState = MaterialSkin.MouseState.HOVER;
            this.productsetting_save.Name = "productsetting_save";
            this.productsetting_save.NoAccentTextColor = System.Drawing.Color.Empty;
            this.productsetting_save.Size = new System.Drawing.Size(86, 36);
            this.productsetting_save.TabIndex = 34;
            this.productsetting_save.Text = "SAVE";
            this.productsetting_save.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.productsetting_save.UseAccentColor = true;
            this.productsetting_save.UseVisualStyleBackColor = true;
            this.productsetting_save.Click += new System.EventHandler(this.productSettingSaveClick);
            // 
            // materialCard7
            // 
            this.materialCard7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard7.Controls.Add(this.materialLabel55);
            this.materialCard7.Controls.Add(this.repairableTextBox);
            this.materialCard7.Controls.Add(this.nonrepairTextBox);
            this.materialCard7.Controls.Add(this.materialLabel52);
            this.materialCard7.Controls.Add(this.AreaCheckedflowLayoutPanel);
            this.materialCard7.Controls.Add(this.materialLabel51);
            this.materialCard7.Controls.Add(this.detailDefectCodeFlowLayoutPanel);
            this.materialCard7.Controls.Add(this.defectCodeFlowLayoutPanel);
            this.materialCard7.Controls.Add(this.selectAiYieldModelButton);
            this.materialCard7.Controls.Add(this.materialLabel47);
            this.materialCard7.Controls.Add(this.aiYieldModelTextBox);
            this.materialCard7.Controls.Add(this.materialLabel26);
            this.materialCard7.Controls.Add(this.regionsizeTextBox);
            this.materialCard7.Controls.Add(this.materialLabel46);
            this.materialCard7.Controls.Add(this.mindefectareaTextBox);
            this.materialCard7.Controls.Add(this.materialLabel41);
            this.materialCard7.Controls.Add(this.materialLabel50);
            this.materialCard7.Controls.Add(this.materialLabel45);
            this.materialCard7.Controls.Add(this.GV_DefectTable);
            this.materialCard7.Controls.Add(this.unknownTHTextBox);
            this.materialCard7.Controls.Add(this.btn_AreaCheckTool);
            this.materialCard7.Controls.Add(this.productnameTextBox);
            this.materialCard7.Controls.Add(this.materialLabel32);
            this.materialCard7.Controls.Add(this.materialLabel22);
            this.materialCard7.Controls.Add(this.selectAiModelButton);
            this.materialCard7.Controls.Add(this.materialLabel21);
            this.materialCard7.Controls.Add(this.materialLabel20);
            this.materialCard7.Controls.Add(this.materialLabel19);
            this.materialCard7.Controls.Add(this.aimodelTextBox);
            this.materialCard7.Controls.Add(this.materialLabel17);
            this.materialCard7.Depth = 0;
            this.materialCard7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard7.Location = new System.Drawing.Point(43, 86);
            this.materialCard7.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard7.Name = "materialCard7";
            this.materialCard7.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard7.Size = new System.Drawing.Size(863, 633);
            this.materialCard7.TabIndex = 27;
            // 
            // repairableTextBox
            // 
            this.repairableTextBox.AnimateReadOnly = false;
            this.repairableTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.repairableTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.repairableTextBox.Depth = 0;
            this.repairableTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.repairableTextBox.HideSelection = true;
            this.repairableTextBox.Hint = "REPAIRABLE";
            this.repairableTextBox.LeadingIcon = null;
            this.repairableTextBox.Location = new System.Drawing.Point(633, 503);
            this.repairableTextBox.MaxLength = 50;
            this.repairableTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.repairableTextBox.Name = "repairableTextBox";
            this.repairableTextBox.PasswordChar = '\0';
            this.repairableTextBox.PrefixSuffixText = null;
            this.repairableTextBox.ReadOnly = false;
            this.repairableTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.repairableTextBox.SelectedText = "";
            this.repairableTextBox.SelectionLength = 0;
            this.repairableTextBox.SelectionStart = 0;
            this.repairableTextBox.ShortcutsEnabled = true;
            this.repairableTextBox.Size = new System.Drawing.Size(120, 48);
            this.repairableTextBox.TabIndex = 83;
            this.repairableTextBox.TabStop = false;
            this.repairableTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.repairableTextBox.TrailingIcon = null;
            this.repairableTextBox.UseSystemPasswordChar = false;
            // 
            // nonrepairTextBox
            // 
            this.nonrepairTextBox.AnimateReadOnly = false;
            this.nonrepairTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.nonrepairTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.nonrepairTextBox.Depth = 0;
            this.nonrepairTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.nonrepairTextBox.HideSelection = true;
            this.nonrepairTextBox.Hint = "NONREPAIR";
            this.nonrepairTextBox.LeadingIcon = null;
            this.nonrepairTextBox.Location = new System.Drawing.Point(633, 561);
            this.nonrepairTextBox.MaxLength = 50;
            this.nonrepairTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.nonrepairTextBox.Name = "nonrepairTextBox";
            this.nonrepairTextBox.PasswordChar = '\0';
            this.nonrepairTextBox.PrefixSuffixText = null;
            this.nonrepairTextBox.ReadOnly = false;
            this.nonrepairTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nonrepairTextBox.SelectedText = "";
            this.nonrepairTextBox.SelectionLength = 0;
            this.nonrepairTextBox.SelectionStart = 0;
            this.nonrepairTextBox.ShortcutsEnabled = true;
            this.nonrepairTextBox.Size = new System.Drawing.Size(120, 48);
            this.nonrepairTextBox.TabIndex = 84;
            this.nonrepairTextBox.TabStop = false;
            this.nonrepairTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.nonrepairTextBox.TrailingIcon = null;
            this.nonrepairTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel52
            // 
            this.materialLabel52.AutoSize = true;
            this.materialLabel52.Depth = 0;
            this.materialLabel52.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel52.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel52.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel52.Location = new System.Drawing.Point(636, 466);
            this.materialLabel52.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel52.Name = "materialLabel52";
            this.materialLabel52.Size = new System.Drawing.Size(71, 17);
            this.materialLabel52.TabIndex = 85;
            this.materialLabel52.Text = "Area check";
            // 
            // AreaCheckedflowLayoutPanel
            // 
            this.AreaCheckedflowLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AreaCheckedflowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.AreaCheckedflowLayoutPanel.Location = new System.Drawing.Point(450, 405);
            this.AreaCheckedflowLayoutPanel.Name = "AreaCheckedflowLayoutPanel";
            this.AreaCheckedflowLayoutPanel.Size = new System.Drawing.Size(168, 203);
            this.AreaCheckedflowLayoutPanel.TabIndex = 82;
            this.AreaCheckedflowLayoutPanel.WrapContents = false;
            // 
            // materialLabel51
            // 
            this.materialLabel51.AutoSize = true;
            this.materialLabel51.Depth = 0;
            this.materialLabel51.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel51.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel51.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel51.Location = new System.Drawing.Point(246, 307);
            this.materialLabel51.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel51.Name = "materialLabel51";
            this.materialLabel51.Size = new System.Drawing.Size(180, 17);
            this.materialLabel51.TabIndex = 81;
            this.materialLabel51.Text = "Defect code (Yield Analysis)";
            // 
            // detailDefectCodeFlowLayoutPanel
            // 
            this.detailDefectCodeFlowLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.detailDefectCodeFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.detailDefectCodeFlowLayoutPanel.Location = new System.Drawing.Point(243, 327);
            this.detailDefectCodeFlowLayoutPanel.Name = "detailDefectCodeFlowLayoutPanel";
            this.detailDefectCodeFlowLayoutPanel.Size = new System.Drawing.Size(193, 281);
            this.detailDefectCodeFlowLayoutPanel.TabIndex = 80;
            this.detailDefectCodeFlowLayoutPanel.WrapContents = false;
            // 
            // defectCodeFlowLayoutPanel
            // 
            this.defectCodeFlowLayoutPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.defectCodeFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.defectCodeFlowLayoutPanel.Location = new System.Drawing.Point(42, 327);
            this.defectCodeFlowLayoutPanel.Name = "defectCodeFlowLayoutPanel";
            this.defectCodeFlowLayoutPanel.Size = new System.Drawing.Size(193, 281);
            this.defectCodeFlowLayoutPanel.TabIndex = 79;
            this.defectCodeFlowLayoutPanel.WrapContents = false;
            // 
            // selectAiYieldModelButton
            // 
            this.selectAiYieldModelButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectAiYieldModelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectAiYieldModelButton.Depth = 0;
            this.selectAiYieldModelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectAiYieldModelButton.HighEmphasis = false;
            this.selectAiYieldModelButton.Icon = null;
            this.selectAiYieldModelButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectAiYieldModelButton.Location = new System.Drawing.Point(760, 128);
            this.selectAiYieldModelButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectAiYieldModelButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectAiYieldModelButton.Name = "selectAiYieldModelButton";
            this.selectAiYieldModelButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectAiYieldModelButton.Size = new System.Drawing.Size(74, 36);
            this.selectAiYieldModelButton.TabIndex = 69;
            this.selectAiYieldModelButton.Text = "select";
            this.selectAiYieldModelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectAiYieldModelButton.UseAccentColor = false;
            this.selectAiYieldModelButton.UseVisualStyleBackColor = true;
            this.selectAiYieldModelButton.Click += new System.EventHandler(this.selectYieldAiModelButton_Click);
            // 
            // materialLabel47
            // 
            this.materialLabel47.AutoSize = true;
            this.materialLabel47.Depth = 0;
            this.materialLabel47.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel47.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel47.Location = new System.Drawing.Point(241, 97);
            this.materialLabel47.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel47.Name = "materialLabel47";
            this.materialLabel47.Size = new System.Drawing.Size(160, 17);
            this.materialLabel47.TabIndex = 68;
            this.materialLabel47.Text = "AI Model (Yield Analysis)";
            // 
            // aiYieldModelTextBox
            // 
            this.aiYieldModelTextBox.AnimateReadOnly = false;
            this.aiYieldModelTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.aiYieldModelTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.aiYieldModelTextBox.Depth = 0;
            this.aiYieldModelTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.aiYieldModelTextBox.HideSelection = true;
            this.aiYieldModelTextBox.Hint = ".onnx model";
            this.aiYieldModelTextBox.LeadingIcon = null;
            this.aiYieldModelTextBox.Location = new System.Drawing.Point(237, 120);
            this.aiYieldModelTextBox.MaxLength = 128;
            this.aiYieldModelTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.aiYieldModelTextBox.Name = "aiYieldModelTextBox";
            this.aiYieldModelTextBox.PasswordChar = '\0';
            this.aiYieldModelTextBox.PrefixSuffixText = null;
            this.aiYieldModelTextBox.ReadOnly = true;
            this.aiYieldModelTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.aiYieldModelTextBox.SelectedText = "";
            this.aiYieldModelTextBox.SelectionLength = 0;
            this.aiYieldModelTextBox.SelectionStart = 0;
            this.aiYieldModelTextBox.ShortcutsEnabled = true;
            this.aiYieldModelTextBox.Size = new System.Drawing.Size(516, 48);
            this.aiYieldModelTextBox.TabIndex = 67;
            this.aiYieldModelTextBox.TabStop = false;
            this.aiYieldModelTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.aiYieldModelTextBox.TrailingIcon = null;
            this.aiYieldModelTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel26
            // 
            this.materialLabel26.AutoSize = true;
            this.materialLabel26.Depth = 0;
            this.materialLabel26.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel26.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel26.Location = new System.Drawing.Point(200, 131);
            this.materialLabel26.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel26.Name = "materialLabel26";
            this.materialLabel26.Size = new System.Drawing.Size(16, 24);
            this.materialLabel26.TabIndex = 66;
            this.materialLabel26.Text = "%";
            // 
            // regionsizeTextBox
            // 
            this.regionsizeTextBox.AnimateReadOnly = false;
            this.regionsizeTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.regionsizeTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.regionsizeTextBox.Depth = 0;
            this.regionsizeTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.regionsizeTextBox.HideSelection = true;
            this.regionsizeTextBox.LeadingIcon = null;
            this.regionsizeTextBox.Location = new System.Drawing.Point(633, 327);
            this.regionsizeTextBox.MaxLength = 50;
            this.regionsizeTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.regionsizeTextBox.Name = "regionsizeTextBox";
            this.regionsizeTextBox.PasswordChar = '\0';
            this.regionsizeTextBox.PrefixSuffixText = null;
            this.regionsizeTextBox.ReadOnly = false;
            this.regionsizeTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.regionsizeTextBox.SelectedText = "";
            this.regionsizeTextBox.SelectionLength = 0;
            this.regionsizeTextBox.SelectionStart = 0;
            this.regionsizeTextBox.ShortcutsEnabled = true;
            this.regionsizeTextBox.Size = new System.Drawing.Size(120, 48);
            this.regionsizeTextBox.TabIndex = 58;
            this.regionsizeTextBox.TabStop = false;
            this.regionsizeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.regionsizeTextBox.TrailingIcon = null;
            this.regionsizeTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel46
            // 
            this.materialLabel46.AutoSize = true;
            this.materialLabel46.Depth = 0;
            this.materialLabel46.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel46.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel46.Location = new System.Drawing.Point(453, 385);
            this.materialLabel46.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel46.Name = "materialLabel46";
            this.materialLabel46.Size = new System.Drawing.Size(73, 17);
            this.materialLabel46.TabIndex = 65;
            this.materialLabel46.Text = "Area Check";
            // 
            // mindefectareaTextBox
            // 
            this.mindefectareaTextBox.AnimateReadOnly = false;
            this.mindefectareaTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.mindefectareaTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.mindefectareaTextBox.Depth = 0;
            this.mindefectareaTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.mindefectareaTextBox.HideSelection = true;
            this.mindefectareaTextBox.LeadingIcon = null;
            this.mindefectareaTextBox.Location = new System.Drawing.Point(633, 405);
            this.mindefectareaTextBox.MaxLength = 50;
            this.mindefectareaTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.mindefectareaTextBox.Name = "mindefectareaTextBox";
            this.mindefectareaTextBox.PasswordChar = '\0';
            this.mindefectareaTextBox.PrefixSuffixText = null;
            this.mindefectareaTextBox.ReadOnly = false;
            this.mindefectareaTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mindefectareaTextBox.SelectedText = "";
            this.mindefectareaTextBox.SelectionLength = 0;
            this.mindefectareaTextBox.SelectionStart = 0;
            this.mindefectareaTextBox.ShortcutsEnabled = true;
            this.mindefectareaTextBox.Size = new System.Drawing.Size(120, 48);
            this.mindefectareaTextBox.TabIndex = 59;
            this.mindefectareaTextBox.TabStop = false;
            this.mindefectareaTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mindefectareaTextBox.TrailingIcon = null;
            this.mindefectareaTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel41
            // 
            this.materialLabel41.AutoSize = true;
            this.materialLabel41.Depth = 0;
            this.materialLabel41.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel41.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel41.Location = new System.Drawing.Point(636, 307);
            this.materialLabel41.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel41.Name = "materialLabel41";
            this.materialLabel41.Size = new System.Drawing.Size(76, 17);
            this.materialLabel41.TabIndex = 60;
            this.materialLabel41.Text = "Region Size";
            // 
            // materialLabel50
            // 
            this.materialLabel50.AutoSize = true;
            this.materialLabel50.Depth = 0;
            this.materialLabel50.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel50.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel50.Location = new System.Drawing.Point(636, 385);
            this.materialLabel50.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel50.Name = "materialLabel50";
            this.materialLabel50.Size = new System.Drawing.Size(103, 17);
            this.materialLabel50.TabIndex = 61;
            this.materialLabel50.Text = "Min Defect Area";
            // 
            // materialLabel45
            // 
            this.materialLabel45.AutoSize = true;
            this.materialLabel45.Depth = 0;
            this.materialLabel45.Font = new System.Drawing.Font("Roboto", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel45.FontType = MaterialSkin.MaterialSkinManager.fontType.Button;
            this.materialLabel45.Location = new System.Drawing.Point(42, 611);
            this.materialLabel45.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel45.Name = "materialLabel45";
            this.materialLabel45.Size = new System.Drawing.Size(352, 17);
            this.materialLabel45.TabIndex = 63;
            this.materialLabel45.Text = "# Gray mode：Type NONE/UNKNOWN will run AutoVRS";
            // 
            // GV_DefectTable
            // 
            this.GV_DefectTable.AllowUserToResizeColumns = false;
            this.GV_DefectTable.AllowUserToResizeRows = false;
            this.GV_DefectTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GV_DefectTable.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.GV_DefectTable.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GV_DefectTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.GV_DefectTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Type,
            this.AOI_Defect,
            this.Judge,
            this.AI_Result,
            this.NewResult});
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GV_DefectTable.DefaultCellStyle = dataGridViewCellStyle39;
            this.GV_DefectTable.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GV_DefectTable.Location = new System.Drawing.Point(42, 201);
            this.GV_DefectTable.Name = "GV_DefectTable";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GV_DefectTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.GV_DefectTable.RowHeadersWidth = 27;
            this.GV_DefectTable.RowTemplate.Height = 24;
            this.GV_DefectTable.Size = new System.Drawing.Size(711, 95);
            this.GV_DefectTable.TabIndex = 57;
            this.GV_DefectTable.TabStop = false;
            this.GV_DefectTable.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellValueChanged);
            // 
            // unknownTHTextBox
            // 
            this.unknownTHTextBox.AnimateReadOnly = false;
            this.unknownTHTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.unknownTHTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.unknownTHTextBox.Depth = 0;
            this.unknownTHTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.unknownTHTextBox.HideSelection = true;
            this.unknownTHTextBox.Hint = "Ex : 80";
            this.unknownTHTextBox.LeadingIcon = null;
            this.unknownTHTextBox.Location = new System.Drawing.Point(43, 120);
            this.unknownTHTextBox.MaxLength = 50;
            this.unknownTHTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.unknownTHTextBox.Name = "unknownTHTextBox";
            this.unknownTHTextBox.PasswordChar = '\0';
            this.unknownTHTextBox.PrefixSuffixText = null;
            this.unknownTHTextBox.ReadOnly = false;
            this.unknownTHTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.unknownTHTextBox.SelectedText = "";
            this.unknownTHTextBox.SelectionLength = 0;
            this.unknownTHTextBox.SelectionStart = 0;
            this.unknownTHTextBox.ShortcutsEnabled = true;
            this.unknownTHTextBox.Size = new System.Drawing.Size(150, 48);
            this.unknownTHTextBox.TabIndex = 56;
            this.unknownTHTextBox.TabStop = false;
            this.unknownTHTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.unknownTHTextBox.TrailingIcon = null;
            this.unknownTHTextBox.UseSystemPasswordChar = false;
            // 
            // btn_AreaCheckTool
            // 
            this.btn_AreaCheckTool.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_AreaCheckTool.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btn_AreaCheckTool.Depth = 0;
            this.btn_AreaCheckTool.HighEmphasis = true;
            this.btn_AreaCheckTool.Icon = null;
            this.btn_AreaCheckTool.Location = new System.Drawing.Point(458, 337);
            this.btn_AreaCheckTool.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_AreaCheckTool.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_AreaCheckTool.Name = "btn_AreaCheckTool";
            this.btn_AreaCheckTool.NoAccentTextColor = System.Drawing.Color.Empty;
            this.btn_AreaCheckTool.Size = new System.Drawing.Size(150, 36);
            this.btn_AreaCheckTool.TabIndex = 62;
            this.btn_AreaCheckTool.Text = "Area Check Tool";
            this.btn_AreaCheckTool.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btn_AreaCheckTool.UseAccentColor = false;
            this.btn_AreaCheckTool.UseVisualStyleBackColor = true;
            this.btn_AreaCheckTool.Click += new System.EventHandler(this.btn_AreaCheckTool_Click);
            // 
            // productnameTextBox
            // 
            this.productnameTextBox.AnimateReadOnly = false;
            this.productnameTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.productnameTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.productnameTextBox.Depth = 0;
            this.productnameTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.productnameTextBox.HideSelection = true;
            this.productnameTextBox.LeadingIcon = null;
            this.productnameTextBox.Location = new System.Drawing.Point(42, 40);
            this.productnameTextBox.MaxLength = 50;
            this.productnameTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.productnameTextBox.Name = "productnameTextBox";
            this.productnameTextBox.PasswordChar = '\0';
            this.productnameTextBox.PrefixSuffixText = null;
            this.productnameTextBox.ReadOnly = false;
            this.productnameTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.productnameTextBox.SelectedText = "";
            this.productnameTextBox.SelectionLength = 0;
            this.productnameTextBox.SelectionStart = 0;
            this.productnameTextBox.ShortcutsEnabled = true;
            this.productnameTextBox.Size = new System.Drawing.Size(150, 48);
            this.productnameTextBox.TabIndex = 45;
            this.productnameTextBox.TabStop = false;
            this.productnameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.productnameTextBox.TrailingIcon = null;
            this.productnameTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel32
            // 
            this.materialLabel32.AutoSize = true;
            this.materialLabel32.Depth = 0;
            this.materialLabel32.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel32.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel32.Location = new System.Drawing.Point(46, 177);
            this.materialLabel32.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel32.Name = "materialLabel32";
            this.materialLabel32.Size = new System.Drawing.Size(115, 17);
            this.materialLabel32.TabIndex = 25;
            this.materialLabel32.Text = "Defect Rule Table";
            // 
            // materialLabel22
            // 
            this.materialLabel22.AutoSize = true;
            this.materialLabel22.Depth = 0;
            this.materialLabel22.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel22.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel22.Location = new System.Drawing.Point(46, 18);
            this.materialLabel22.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel22.Name = "materialLabel22";
            this.materialLabel22.Size = new System.Drawing.Size(92, 17);
            this.materialLabel22.TabIndex = 21;
            this.materialLabel22.Text = "Product Name";
            // 
            // selectAiModelButton
            // 
            this.selectAiModelButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.selectAiModelButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.selectAiModelButton.Depth = 0;
            this.selectAiModelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectAiModelButton.HighEmphasis = false;
            this.selectAiModelButton.Icon = null;
            this.selectAiModelButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectAiModelButton.Location = new System.Drawing.Point(760, 47);
            this.selectAiModelButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.selectAiModelButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.selectAiModelButton.Name = "selectAiModelButton";
            this.selectAiModelButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.selectAiModelButton.Size = new System.Drawing.Size(74, 36);
            this.selectAiModelButton.TabIndex = 20;
            this.selectAiModelButton.Text = "select";
            this.selectAiModelButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.selectAiModelButton.UseAccentColor = false;
            this.selectAiModelButton.UseVisualStyleBackColor = true;
            this.selectAiModelButton.Click += new System.EventHandler(this.selectAiModelButtonClick);
            // 
            // materialLabel21
            // 
            this.materialLabel21.AutoSize = true;
            this.materialLabel21.Depth = 0;
            this.materialLabel21.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel21.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel21.Location = new System.Drawing.Point(46, 98);
            this.materialLabel21.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel21.Name = "materialLabel21";
            this.materialLabel21.Size = new System.Drawing.Size(181, 17);
            this.materialLabel21.TabIndex = 19;
            this.materialLabel21.Text = "Unknown Threshold (0~100)";
            // 
            // materialLabel20
            // 
            this.materialLabel20.AutoSize = true;
            this.materialLabel20.Depth = 0;
            this.materialLabel20.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel20.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle1;
            this.materialLabel20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel20.Location = new System.Drawing.Point(116, 146);
            this.materialLabel20.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel20.Name = "materialLabel20";
            this.materialLabel20.Size = new System.Drawing.Size(1, 0);
            this.materialLabel20.TabIndex = 15;
            // 
            // materialLabel19
            // 
            this.materialLabel19.AutoSize = true;
            this.materialLabel19.Depth = 0;
            this.materialLabel19.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel19.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel19.Location = new System.Drawing.Point(241, 18);
            this.materialLabel19.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel19.Name = "materialLabel19";
            this.materialLabel19.Size = new System.Drawing.Size(57, 17);
            this.materialLabel19.TabIndex = 13;
            this.materialLabel19.Text = "AI Model";
            // 
            // aimodelTextBox
            // 
            this.aimodelTextBox.AnimateReadOnly = false;
            this.aimodelTextBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.aimodelTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.aimodelTextBox.Depth = 0;
            this.aimodelTextBox.Font = new System.Drawing.Font("Roboto", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.aimodelTextBox.HideSelection = true;
            this.aimodelTextBox.Hint = ".onnx model";
            this.aimodelTextBox.LeadingIcon = null;
            this.aimodelTextBox.Location = new System.Drawing.Point(237, 41);
            this.aimodelTextBox.MaxLength = 128;
            this.aimodelTextBox.MouseState = MaterialSkin.MouseState.OUT;
            this.aimodelTextBox.Name = "aimodelTextBox";
            this.aimodelTextBox.PasswordChar = '\0';
            this.aimodelTextBox.PrefixSuffixText = null;
            this.aimodelTextBox.ReadOnly = true;
            this.aimodelTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.aimodelTextBox.SelectedText = "";
            this.aimodelTextBox.SelectionLength = 0;
            this.aimodelTextBox.SelectionStart = 0;
            this.aimodelTextBox.ShortcutsEnabled = true;
            this.aimodelTextBox.Size = new System.Drawing.Size(516, 48);
            this.aimodelTextBox.TabIndex = 12;
            this.aimodelTextBox.TabStop = false;
            this.aimodelTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.aimodelTextBox.TrailingIcon = null;
            this.aimodelTextBox.UseSystemPasswordChar = false;
            // 
            // materialLabel17
            // 
            this.materialLabel17.AutoSize = true;
            this.materialLabel17.Depth = 0;
            this.materialLabel17.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel17.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel17.Location = new System.Drawing.Point(46, 307);
            this.materialLabel17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel17.Name = "materialLabel17";
            this.materialLabel17.Size = new System.Drawing.Size(77, 17);
            this.materialLabel17.TabIndex = 6;
            this.materialLabel17.Text = "Defect code";
            // 
            // product_setting
            // 
            this.product_setting.Image = ((System.Drawing.Image)(resources.GetObject("product_setting.Image")));
            this.product_setting.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.product_setting.Location = new System.Drawing.Point(43, 19);
            this.product_setting.Name = "product_setting";
            this.product_setting.Size = new System.Drawing.Size(54, 54);
            this.product_setting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.product_setting.TabIndex = 26;
            this.product_setting.TabStop = false;
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.White;
            this.Home.Controls.Add(this.mode2RadioButton);
            this.Home.Controls.Add(this.mode1RadioButton);
            this.Home.Controls.Add(this.colorimg);
            this.Home.Controls.Add(this.materialLabel49);
            this.Home.Controls.Add(this.grayLabel);
            this.Home.Controls.Add(this.pictureBox4);
            this.Home.Controls.Add(this.colorLabel);
            this.Home.Controls.Add(this.materialCard12);
            this.Home.Controls.Add(this.grayimg);
            this.Home.Controls.Add(this.materialCard1);
            this.Home.Controls.Add(this.pictureBox7);
            this.Home.Controls.Add(this.pictureBox6);
            this.Home.Controls.Add(this.pictureBox2);
            this.Home.Controls.Add(this.materialLabel2);
            this.Home.Controls.Add(this.materialCard3);
            this.Home.Controls.Add(this.label5);
            this.Home.Controls.Add(this.materialLabel1);
            this.Home.Controls.Add(this.materialCard2);
            this.Home.Controls.Add(this.materialLabel3);
            this.Home.Controls.Add(this.startButton);
            this.Home.Controls.Add(this.stopButton);
            this.Home.ImageKey = "home.png";
            this.Home.Location = new System.Drawing.Point(4, 39);
            this.Home.Name = "Home";
            this.Home.Padding = new System.Windows.Forms.Padding(3);
            this.Home.Size = new System.Drawing.Size(984, 736);
            this.Home.TabIndex = 0;
            this.Home.Text = "Home";
            // 
            // mode2RadioButton
            // 
            this.mode2RadioButton.AutoSize = true;
            this.mode2RadioButton.Depth = 0;
            this.mode2RadioButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.mode2RadioButton.Location = new System.Drawing.Point(585, 620);
            this.mode2RadioButton.Margin = new System.Windows.Forms.Padding(0);
            this.mode2RadioButton.MouseLocation = new System.Drawing.Point(-1, -1);
            this.mode2RadioButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.mode2RadioButton.Name = "mode2RadioButton";
            this.mode2RadioButton.Ripple = true;
            this.mode2RadioButton.Size = new System.Drawing.Size(202, 37);
            this.mode2RadioButton.TabIndex = 66;
            this.mode2RadioButton.TabStop = true;
            this.mode2RadioButton.Text = "Mode 2 (Yield Analysis)";
            this.mode2RadioButton.UseVisualStyleBackColor = true;
            // 
            // mode1RadioButton
            // 
            this.mode1RadioButton.AutoSize = true;
            this.mode1RadioButton.Depth = 0;
            this.mode1RadioButton.Location = new System.Drawing.Point(585, 583);
            this.mode1RadioButton.Margin = new System.Windows.Forms.Padding(0);
            this.mode1RadioButton.MouseLocation = new System.Drawing.Point(-1, -1);
            this.mode1RadioButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.mode1RadioButton.Name = "mode1RadioButton";
            this.mode1RadioButton.Ripple = true;
            this.mode1RadioButton.Size = new System.Drawing.Size(155, 37);
            this.mode1RadioButton.TabIndex = 65;
            this.mode1RadioButton.TabStop = true;
            this.mode1RadioButton.Text = "Mode 1 (Normal)";
            this.mode1RadioButton.UseVisualStyleBackColor = true;
            // 
            // colorimg
            // 
            this.colorimg.Image = global::KinsusAutoAOI.Properties.Resources.colormode;
            this.colorimg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.colorimg.Location = new System.Drawing.Point(518, 588);
            this.colorimg.Name = "colorimg";
            this.colorimg.Size = new System.Drawing.Size(50, 50);
            this.colorimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.colorimg.TabIndex = 64;
            this.colorimg.TabStop = false;
            // 
            // materialLabel49
            // 
            this.materialLabel49.AutoSize = true;
            this.materialLabel49.Depth = 0;
            this.materialLabel49.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel49.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel49.Location = new System.Drawing.Point(104, 513);
            this.materialLabel49.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel49.Name = "materialLabel49";
            this.materialLabel49.Size = new System.Drawing.Size(191, 24);
            this.materialLabel49.TabIndex = 61;
            this.materialLabel49.Text = "Realtime AI Accuracy";
            // 
            // grayLabel
            // 
            this.grayLabel.AutoSize = true;
            this.grayLabel.Depth = 0;
            this.grayLabel.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.grayLabel.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.grayLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grayLabel.Location = new System.Drawing.Point(509, 641);
            this.grayLabel.MouseState = MaterialSkin.MouseState.HOVER;
            this.grayLabel.Name = "grayLabel";
            this.grayLabel.Size = new System.Drawing.Size(70, 17);
            this.grayLabel.TabIndex = 63;
            this.grayLabel.Text = "Gray Mode";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::KinsusAutoAOI.Properties.Resources.acc;
            this.pictureBox4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox4.Location = new System.Drawing.Point(42, 499);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 60;
            this.pictureBox4.TabStop = false;
            // 
            // colorLabel
            // 
            this.colorLabel.AutoSize = true;
            this.colorLabel.Depth = 0;
            this.colorLabel.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.colorLabel.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.colorLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.colorLabel.Location = new System.Drawing.Point(506, 641);
            this.colorLabel.MouseState = MaterialSkin.MouseState.HOVER;
            this.colorLabel.Name = "colorLabel";
            this.colorLabel.Size = new System.Drawing.Size(74, 17);
            this.colorLabel.TabIndex = 55;
            this.colorLabel.Text = "Color Mode";
            // 
            // materialCard12
            // 
            this.materialCard12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard12.Controls.Add(this.accuracySlider);
            this.materialCard12.Depth = 0;
            this.materialCard12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard12.Location = new System.Drawing.Point(43, 566);
            this.materialCard12.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard12.Name = "materialCard12";
            this.materialCard12.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard12.Size = new System.Drawing.Size(399, 104);
            this.materialCard12.TabIndex = 59;
            // 
            // accuracySlider
            // 
            this.accuracySlider.Depth = 0;
            this.accuracySlider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.accuracySlider.Location = new System.Drawing.Point(52, 35);
            this.accuracySlider.MouseState = MaterialSkin.MouseState.HOVER;
            this.accuracySlider.Name = "accuracySlider";
            this.accuracySlider.Size = new System.Drawing.Size(299, 40);
            this.accuracySlider.TabIndex = 20;
            this.accuracySlider.Text = "Rejudge Rate";
            this.accuracySlider.UseAccentColor = true;
            this.accuracySlider.Value = 20;
            this.accuracySlider.ValueMax = 100;
            this.accuracySlider.ValueSuffix = "%";
            // 
            // grayimg
            // 
            this.grayimg.Image = global::KinsusAutoAOI.Properties.Resources.graymode;
            this.grayimg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grayimg.Location = new System.Drawing.Point(518, 588);
            this.grayimg.Name = "grayimg";
            this.grayimg.Size = new System.Drawing.Size(50, 50);
            this.grayimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.grayimg.TabIndex = 62;
            this.grayimg.TabStop = false;
            // 
            // materialCard1
            // 
            this.materialCard1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard1.Controls.Add(this.Recipe_OK);
            this.materialCard1.Controls.Add(this.Rejudge_OK);
            this.materialCard1.Controls.Add(this.pictureBox13);
            this.materialCard1.Controls.Add(this.pictureBox10);
            this.materialCard1.Controls.Add(this.pictureBox12);
            this.materialCard1.Controls.Add(this.AI_OK);
            this.materialCard1.Controls.Add(this.pictureBox11);
            this.materialCard1.Controls.Add(this.label2);
            this.materialCard1.Controls.Add(this.materialLabel31);
            this.materialCard1.Controls.Add(this.Rejudge_NG);
            this.materialCard1.Controls.Add(this.Recipe_NG);
            this.materialCard1.Controls.Add(this.AI_NG);
            this.materialCard1.Controls.Add(this.foldersetting_OK);
            this.materialCard1.Controls.Add(this.label6);
            this.materialCard1.Controls.Add(this.materialLabel35);
            this.materialCard1.Controls.Add(this.foldersetting_NG);
            this.materialCard1.Controls.Add(this.materialLabel34);
            this.materialCard1.Controls.Add(this.materialLabel33);
            this.materialCard1.Depth = 0;
            this.materialCard1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard1.Location = new System.Drawing.Point(43, 86);
            this.materialCard1.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard1.Name = "materialCard1";
            this.materialCard1.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard1.Size = new System.Drawing.Size(400, 375);
            this.materialCard1.TabIndex = 54;
            // 
            // Recipe_OK
            // 
            this.Recipe_OK.Image = ((System.Drawing.Image)(resources.GetObject("Recipe_OK.Image")));
            this.Recipe_OK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Recipe_OK.Location = new System.Drawing.Point(301, 29);
            this.Recipe_OK.Name = "Recipe_OK";
            this.Recipe_OK.Size = new System.Drawing.Size(43, 47);
            this.Recipe_OK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Recipe_OK.TabIndex = 58;
            this.Recipe_OK.TabStop = false;
            this.Recipe_OK.Visible = false;
            // 
            // Rejudge_OK
            // 
            this.Rejudge_OK.Image = ((System.Drawing.Image)(resources.GetObject("Rejudge_OK.Image")));
            this.Rejudge_OK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Rejudge_OK.Location = new System.Drawing.Point(301, 205);
            this.Rejudge_OK.Name = "Rejudge_OK";
            this.Rejudge_OK.Size = new System.Drawing.Size(43, 47);
            this.Rejudge_OK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Rejudge_OK.TabIndex = 65;
            this.Rejudge_OK.TabStop = false;
            this.Rejudge_OK.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox13.Location = new System.Drawing.Point(55, 118);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(35, 38);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 64;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox10.Location = new System.Drawing.Point(56, 30);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(40, 40);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 61;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox12.Location = new System.Drawing.Point(52, 295);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(40, 40);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 63;
            this.pictureBox12.TabStop = false;
            // 
            // AI_OK
            // 
            this.AI_OK.Image = ((System.Drawing.Image)(resources.GetObject("AI_OK.Image")));
            this.AI_OK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AI_OK.Location = new System.Drawing.Point(301, 294);
            this.AI_OK.Name = "AI_OK";
            this.AI_OK.Size = new System.Drawing.Size(43, 47);
            this.AI_OK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AI_OK.TabIndex = 36;
            this.AI_OK.TabStop = false;
            this.AI_OK.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox11.Location = new System.Drawing.Point(52, 207);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(40, 40);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 62;
            this.pictureBox11.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(257, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 21);
            this.label2.TabIndex = 31;
            // 
            // materialLabel31
            // 
            this.materialLabel31.AutoSize = true;
            this.materialLabel31.Depth = 0;
            this.materialLabel31.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel31.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel31.Location = new System.Drawing.Point(126, 39);
            this.materialLabel31.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel31.Name = "materialLabel31";
            this.materialLabel31.Size = new System.Drawing.Size(130, 24);
            this.materialLabel31.TabIndex = 60;
            this.materialLabel31.Text = "Recipe Setting";
            // 
            // Rejudge_NG
            // 
            this.Rejudge_NG.Enabled = false;
            this.Rejudge_NG.Image = ((System.Drawing.Image)(resources.GetObject("Rejudge_NG.Image")));
            this.Rejudge_NG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Rejudge_NG.Location = new System.Drawing.Point(304, 207);
            this.Rejudge_NG.Name = "Rejudge_NG";
            this.Rejudge_NG.Size = new System.Drawing.Size(37, 40);
            this.Rejudge_NG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Rejudge_NG.TabIndex = 48;
            this.Rejudge_NG.TabStop = false;
            this.Rejudge_NG.Visible = false;
            // 
            // Recipe_NG
            // 
            this.Recipe_NG.Enabled = false;
            this.Recipe_NG.Image = ((System.Drawing.Image)(resources.GetObject("Recipe_NG.Image")));
            this.Recipe_NG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Recipe_NG.Location = new System.Drawing.Point(304, 31);
            this.Recipe_NG.Name = "Recipe_NG";
            this.Recipe_NG.Size = new System.Drawing.Size(37, 40);
            this.Recipe_NG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Recipe_NG.TabIndex = 59;
            this.Recipe_NG.TabStop = false;
            this.Recipe_NG.Visible = false;
            // 
            // AI_NG
            // 
            this.AI_NG.Enabled = false;
            this.AI_NG.Image = ((System.Drawing.Image)(resources.GetObject("AI_NG.Image")));
            this.AI_NG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AI_NG.Location = new System.Drawing.Point(304, 297);
            this.AI_NG.Name = "AI_NG";
            this.AI_NG.Size = new System.Drawing.Size(37, 40);
            this.AI_NG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AI_NG.TabIndex = 50;
            this.AI_NG.TabStop = false;
            this.AI_NG.Visible = false;
            // 
            // foldersetting_OK
            // 
            this.foldersetting_OK.Image = ((System.Drawing.Image)(resources.GetObject("foldersetting_OK.Image")));
            this.foldersetting_OK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.foldersetting_OK.Location = new System.Drawing.Point(301, 116);
            this.foldersetting_OK.Name = "foldersetting_OK";
            this.foldersetting_OK.Size = new System.Drawing.Size(43, 47);
            this.foldersetting_OK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.foldersetting_OK.TabIndex = 53;
            this.foldersetting_OK.TabStop = false;
            this.foldersetting_OK.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(257, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 21);
            this.label6.TabIndex = 51;
            // 
            // materialLabel35
            // 
            this.materialLabel35.AutoSize = true;
            this.materialLabel35.Depth = 0;
            this.materialLabel35.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel35.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel35.Location = new System.Drawing.Point(123, 306);
            this.materialLabel35.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel35.Name = "materialLabel35";
            this.materialLabel35.Size = new System.Drawing.Size(137, 24);
            this.materialLabel35.TabIndex = 57;
            this.materialLabel35.Text = "AI Environment";
            // 
            // foldersetting_NG
            // 
            this.foldersetting_NG.Enabled = false;
            this.foldersetting_NG.Image = ((System.Drawing.Image)(resources.GetObject("foldersetting_NG.Image")));
            this.foldersetting_NG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.foldersetting_NG.Location = new System.Drawing.Point(304, 119);
            this.foldersetting_NG.Name = "foldersetting_NG";
            this.foldersetting_NG.Size = new System.Drawing.Size(37, 40);
            this.foldersetting_NG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.foldersetting_NG.TabIndex = 54;
            this.foldersetting_NG.TabStop = false;
            this.foldersetting_NG.Visible = false;
            // 
            // materialLabel34
            // 
            this.materialLabel34.AutoSize = true;
            this.materialLabel34.Depth = 0;
            this.materialLabel34.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel34.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel34.Location = new System.Drawing.Point(122, 217);
            this.materialLabel34.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel34.Name = "materialLabel34";
            this.materialLabel34.Size = new System.Drawing.Size(138, 24);
            this.materialLabel34.TabIndex = 56;
            this.materialLabel34.Text = "Rejudge Center";
            // 
            // materialLabel33
            // 
            this.materialLabel33.AutoSize = true;
            this.materialLabel33.Depth = 0;
            this.materialLabel33.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel33.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel33.Location = new System.Drawing.Point(114, 128);
            this.materialLabel33.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel33.Name = "materialLabel33";
            this.materialLabel33.Size = new System.Drawing.Size(155, 24);
            this.materialLabel33.TabIndex = 55;
            this.materialLabel33.Text = "Database Setting";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox7.Location = new System.Drawing.Point(43, 20);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 53;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox6.Location = new System.Drawing.Point(508, 20);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 52;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(508, 278);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 51;
            this.pictureBox2.TabStop = false;
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel2.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel2.Location = new System.Drawing.Point(575, 293);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(61, 24);
            this.materialLabel2.TabIndex = 50;
            this.materialLabel2.Text = "Recipe";
            // 
            // materialCard3
            // 
            this.materialCard3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard3.Controls.Add(this.materialComboBox3);
            this.materialCard3.Controls.Add(this.materialComboBox1);
            this.materialCard3.Depth = 0;
            this.materialCard3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard3.Location = new System.Drawing.Point(506, 347);
            this.materialCard3.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard3.Name = "materialCard3";
            this.materialCard3.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard3.Size = new System.Drawing.Size(398, 202);
            this.materialCard3.TabIndex = 49;
            // 
            // materialComboBox3
            // 
            this.materialComboBox3.AutoResize = false;
            this.materialComboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialComboBox3.Depth = 0;
            this.materialComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.materialComboBox3.DropDownHeight = 174;
            this.materialComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.materialComboBox3.DropDownWidth = 121;
            this.materialComboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialComboBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialComboBox3.FormattingEnabled = true;
            this.materialComboBox3.Hint = "System Recipe";
            this.materialComboBox3.IntegralHeight = false;
            this.materialComboBox3.ItemHeight = 43;
            this.materialComboBox3.Location = new System.Drawing.Point(40, 123);
            this.materialComboBox3.MaxDropDownItems = 4;
            this.materialComboBox3.MouseState = MaterialSkin.MouseState.OUT;
            this.materialComboBox3.Name = "materialComboBox3";
            this.materialComboBox3.Size = new System.Drawing.Size(328, 49);
            this.materialComboBox3.StartIndex = 0;
            this.materialComboBox3.TabIndex = 52;
            this.materialComboBox3.SelectedIndexChanged += new System.EventHandler(this.systemRecipeSelectedIndexChanged);
            // 
            // materialComboBox1
            // 
            this.materialComboBox1.AutoResize = false;
            this.materialComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialComboBox1.Depth = 0;
            this.materialComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.materialComboBox1.DropDownHeight = 174;
            this.materialComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.materialComboBox1.DropDownWidth = 121;
            this.materialComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialComboBox1.FormattingEnabled = true;
            this.materialComboBox1.Hint = "Product Recipe";
            this.materialComboBox1.IntegralHeight = false;
            this.materialComboBox1.ItemHeight = 43;
            this.materialComboBox1.Location = new System.Drawing.Point(40, 37);
            this.materialComboBox1.MaxDropDownItems = 4;
            this.materialComboBox1.MouseState = MaterialSkin.MouseState.OUT;
            this.materialComboBox1.Name = "materialComboBox1";
            this.materialComboBox1.Size = new System.Drawing.Size(328, 49);
            this.materialComboBox1.StartIndex = 0;
            this.materialComboBox1.TabIndex = 51;
            this.materialComboBox1.SelectedIndexChanged += new System.EventHandler(this.productRecipeSelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(182, 384);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 47;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel1.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel1.Location = new System.Drawing.Point(575, 38);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(60, 24);
            this.materialLabel1.TabIndex = 46;
            this.materialLabel1.Text = "Option";
            // 
            // materialCard2
            // 
            this.materialCard2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard2.Controls.Add(this.shortAreaCheck_Switch);
            this.materialCard2.Controls.Add(this.backup_Switch);
            this.materialCard2.Controls.Add(this.rejudge_Switch);
            this.materialCard2.Depth = 0;
            this.materialCard2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard2.Location = new System.Drawing.Point(506, 86);
            this.materialCard2.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard2.Name = "materialCard2";
            this.materialCard2.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard2.Size = new System.Drawing.Size(400, 168);
            this.materialCard2.TabIndex = 45;
            // 
            // shortAreaCheck_Switch
            // 
            this.shortAreaCheck_Switch.Appearance = System.Windows.Forms.Appearance.Button;
            this.shortAreaCheck_Switch.AutoSize = true;
            this.shortAreaCheck_Switch.Checked = true;
            this.shortAreaCheck_Switch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.shortAreaCheck_Switch.Depth = 0;
            this.shortAreaCheck_Switch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.shortAreaCheck_Switch.Location = new System.Drawing.Point(103, 115);
            this.shortAreaCheck_Switch.Margin = new System.Windows.Forms.Padding(0);
            this.shortAreaCheck_Switch.MouseLocation = new System.Drawing.Point(-1, -1);
            this.shortAreaCheck_Switch.MouseState = MaterialSkin.MouseState.HOVER;
            this.shortAreaCheck_Switch.Name = "shortAreaCheck_Switch";
            this.shortAreaCheck_Switch.Ripple = true;
            this.shortAreaCheck_Switch.Size = new System.Drawing.Size(179, 37);
            this.shortAreaCheck_Switch.TabIndex = 53;
            this.shortAreaCheck_Switch.Text = "Short Area Check";
            this.shortAreaCheck_Switch.UseVisualStyleBackColor = true;
            // 
            // backup_Switch
            // 
            this.backup_Switch.Appearance = System.Windows.Forms.Appearance.Button;
            this.backup_Switch.AutoSize = true;
            this.backup_Switch.Checked = true;
            this.backup_Switch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.backup_Switch.Depth = 0;
            this.backup_Switch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backup_Switch.Location = new System.Drawing.Point(103, 64);
            this.backup_Switch.Margin = new System.Windows.Forms.Padding(0);
            this.backup_Switch.MouseLocation = new System.Drawing.Point(-1, -1);
            this.backup_Switch.MouseState = MaterialSkin.MouseState.HOVER;
            this.backup_Switch.Name = "backup_Switch";
            this.backup_Switch.Ripple = true;
            this.backup_Switch.Size = new System.Drawing.Size(149, 37);
            this.backup_Switch.TabIndex = 52;
            this.backup_Switch.Text = "Backup Data";
            this.backup_Switch.UseVisualStyleBackColor = true;
            // 
            // rejudge_Switch
            // 
            this.rejudge_Switch.Appearance = System.Windows.Forms.Appearance.Button;
            this.rejudge_Switch.AutoSize = true;
            this.rejudge_Switch.Checked = true;
            this.rejudge_Switch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rejudge_Switch.Depth = 0;
            this.rejudge_Switch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rejudge_Switch.Location = new System.Drawing.Point(103, 14);
            this.rejudge_Switch.Margin = new System.Windows.Forms.Padding(0);
            this.rejudge_Switch.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rejudge_Switch.MouseState = MaterialSkin.MouseState.HOVER;
            this.rejudge_Switch.Name = "rejudge_Switch";
            this.rejudge_Switch.Ripple = true;
            this.rejudge_Switch.Size = new System.Drawing.Size(171, 37);
            this.rejudge_Switch.TabIndex = 51;
            this.rejudge_Switch.Text = "Human Rejudge";
            this.rejudge_Switch.UseVisualStyleBackColor = true;
            this.rejudge_Switch.CheckedChanged += new System.EventHandler(this.rejudgeSwitch_CheckedChanged);
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.BackColor = System.Drawing.Color.White;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel3.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.materialLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel3.Location = new System.Drawing.Point(104, 38);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(101, 24);
            this.materialLabel3.TabIndex = 43;
            this.materialLabel3.Text = "Check item";
            // 
            // startButton
            // 
            this.startButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.startButton.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.startButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.startButton.Depth = 0;
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.startButton.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold);
            this.startButton.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.startButton.HighEmphasis = true;
            this.startButton.Icon = null;
            this.startButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.startButton.Location = new System.Drawing.Point(801, 572);
            this.startButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.startButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.startButton.Name = "startButton";
            this.startButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.startButton.Size = new System.Drawing.Size(102, 36);
            this.startButton.TabIndex = 37;
            this.startButton.Text = "          Start          ";
            this.startButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.startButton.UseAccentColor = true;
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.stopButton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.stopButton.Depth = 0;
            this.stopButton.Enabled = false;
            this.stopButton.HighEmphasis = true;
            this.stopButton.Icon = null;
            this.stopButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.stopButton.Location = new System.Drawing.Point(805, 624);
            this.stopButton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.stopButton.MouseState = MaterialSkin.MouseState.HOVER;
            this.stopButton.Name = "stopButton";
            this.stopButton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.stopButton.Size = new System.Drawing.Size(94, 36);
            this.stopButton.TabIndex = 38;
            this.stopButton.Text = "          Stop          ";
            this.stopButton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.stopButton.UseAccentColor = true;
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // TabControlHome
            // 
            this.TabControlHome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TabControlHome.Controls.Add(this.Home);
            this.TabControlHome.Controls.Add(this.ProductSetting);
            this.TabControlHome.Controls.Add(this.SystemSetting);
            this.TabControlHome.Controls.Add(this.AIAccuracy);
            this.TabControlHome.Controls.Add(this.Status);
            this.TabControlHome.Controls.Add(this.Folder);
            this.TabControlHome.Depth = 0;
            this.TabControlHome.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            this.TabControlHome.ImageList = this.imageList1;
            this.TabControlHome.Location = new System.Drawing.Point(17, 91);
            this.TabControlHome.MouseState = MaterialSkin.MouseState.HOVER;
            this.TabControlHome.Multiline = true;
            this.TabControlHome.Name = "TabControlHome";
            this.TabControlHome.SelectedIndex = 0;
            this.TabControlHome.ShowToolTips = true;
            this.TabControlHome.Size = new System.Drawing.Size(992, 779);
            this.TabControlHome.TabIndex = 44;
            // 
            // Type
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.White;
            this.Type.DefaultCellStyle = dataGridViewCellStyle34;
            this.Type.HeaderText = "Type";
            this.Type.Items.AddRange(new object[] {
            "Retype",
            "Bypass"});
            this.Type.Name = "Type";
            // 
            // AOI_Defect
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AOI_Defect.DefaultCellStyle = dataGridViewCellStyle35;
            this.AOI_Defect.HeaderText = "AOI_Defect";
            this.AOI_Defect.Name = "AOI_Defect";
            // 
            // Judge
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Judge.DefaultCellStyle = dataGridViewCellStyle36;
            this.Judge.HeaderText = "Judge";
            this.Judge.Items.AddRange(new object[] {
            "Equal",
            "Unequal",
            "-"});
            this.Judge.Name = "Judge";
            // 
            // AI_Result
            // 
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AI_Result.DefaultCellStyle = dataGridViewCellStyle37;
            this.AI_Result.HeaderText = "AI_Result";
            this.AI_Result.Items.AddRange(new object[] {
            "<<AnyResult>>",
            "-"});
            this.AI_Result.Name = "AI_Result";
            this.AI_Result.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.AI_Result.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // NewResult
            // 
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.NewResult.DefaultCellStyle = dataGridViewCellStyle38;
            this.NewResult.HeaderText = "NewResult";
            this.NewResult.Name = "NewResult";
            // 
            // materialLabel55
            // 
            this.materialLabel55.AutoSize = true;
            this.materialLabel55.Depth = 0;
            this.materialLabel55.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel55.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel55.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel55.Location = new System.Drawing.Point(636, 483);
            this.materialLabel55.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel55.Name = "materialLabel55";
            this.materialLabel55.Size = new System.Drawing.Size(76, 17);
            this.materialLabel55.TabIndex = 86;
            this.materialLabel55.Text = "defect code";
            // 
            // Mainform
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 870);
            this.Controls.Add(this.light2);
            this.Controls.Add(this.light1);
            this.Controls.Add(this.light4);
            this.Controls.Add(this.light3);
            this.Controls.Add(this.TabControlHome);
            this.Controls.Add(this.materialDrawer2);
            this.Controls.Add(this.materialDrawer1);
            this.DrawerHighlightWithAccent = false;
            this.DrawerIndicatorWidth = 5;
            this.DrawerShowIconsWhenHidden = true;
            this.DrawerTabControl = this.TabControlHome;
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.FormStyle = MaterialSkin.Controls.MaterialForm.FormStyles.ActionBar_64;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.Name = "Mainform";
            this.Padding = new System.Windows.Forms.Padding(0, 88, 3, 5);
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AUO Auto AI Judgment System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Mainform_FormClosing);
            this.Load += new System.EventHandler(this.Mainform_Load);
            this.Folder.ResumeLayout(false);
            this.Folder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.materialCard9.ResumeLayout(false);
            this.materialCard9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.auolicense)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otherlicense)).EndInit();
            this.materialCard6.ResumeLayout(false);
            this.materialCard6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe)).EndInit();
            this.materialCard5.ResumeLayout(false);
            this.materialCard5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logfiles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Images)).EndInit();
            this.materialCard4.ResumeLayout(false);
            this.materialCard4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Export)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Import)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Status.ResumeLayout(false);
            this.Status.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.AIAccuracy.ResumeLayout(false);
            this.AIAccuracy.PerformLayout();
            this.materialCard11.ResumeLayout(false);
            this.materialCard10.ResumeLayout(false);
            this.materialCard10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.SystemSetting.ResumeLayout(false);
            this.SystemSetting.PerformLayout();
            this.materialCard8.ResumeLayout(false);
            this.materialCard8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.system_setting)).EndInit();
            this.ProductSetting.ResumeLayout(false);
            this.ProductSetting.PerformLayout();
            this.materialCard7.ResumeLayout(false);
            this.materialCard7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GV_DefectTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.product_setting)).EndInit();
            this.Home.ResumeLayout(false);
            this.Home.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colorimg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.materialCard12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grayimg)).EndInit();
            this.materialCard1.ResumeLayout(false);
            this.materialCard1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe_OK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejudge_OK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AI_OK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejudge_NG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Recipe_NG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AI_NG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foldersetting_OK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foldersetting_NG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.materialCard3.ResumeLayout(false);
            this.materialCard2.ResumeLayout(false);
            this.materialCard2.PerformLayout();
            this.TabControlHome.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialDrawer materialDrawer1;
        private MaterialSkin.Controls.MaterialDrawer materialDrawer2;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ImageList imageList1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.ComponentModel.BackgroundWorker backgroundWorker3;
        private System.Windows.Forms.Label light3;
        private System.Windows.Forms.Label light4;
        private System.Windows.Forms.Label light2;
        private System.Windows.Forms.Label light1;
        private System.Windows.Forms.TabPage Folder;
        private System.Windows.Forms.PictureBox pictureBox15;
        private MaterialSkin.Controls.MaterialLabel materialLabel44;
        private MaterialSkin.Controls.MaterialCard materialCard9;
        private System.Windows.Forms.PictureBox auolicense;
        private System.Windows.Forms.PictureBox otherlicense;
        private MaterialSkin.Controls.MaterialLabel materialLabel38;
        private MaterialSkin.Controls.MaterialLabel materialLabel42;
        private MaterialSkin.Controls.MaterialLabel materialLabel43;
        private MaterialSkin.Controls.MaterialLabel materialLabel8;
        private MaterialSkin.Controls.MaterialLabel materialLabel12;
        private MaterialSkin.Controls.MaterialCard materialCard6;
        private System.Windows.Forms.PictureBox AI;
        private MaterialSkin.Controls.MaterialLabel materialLabel15;
        private System.Windows.Forms.PictureBox Recipe;
        private MaterialSkin.Controls.MaterialLabel materialLabel13;
        private MaterialSkin.Controls.MaterialLabel materialLabel14;
        private MaterialSkin.Controls.MaterialLabel materialLabel9;
        private MaterialSkin.Controls.MaterialCard materialCard5;
        private System.Windows.Forms.PictureBox logfiles;
        private System.Windows.Forms.PictureBox Images;
        private MaterialSkin.Controls.MaterialLabel materialLabel10;
        private MaterialSkin.Controls.MaterialLabel materialLabel11;
        private MaterialSkin.Controls.MaterialDrawer materialDrawer3;
        private MaterialSkin.Controls.MaterialCard materialCard4;
        private System.Windows.Forms.PictureBox Export;
        private System.Windows.Forms.PictureBox Import;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabPage Status;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TabPage AIAccuracy;
        private MaterialSkin.Controls.MaterialComboBox selectAiAccRange;
        private MaterialSkin.Controls.MaterialLabel modifieddateLabel;
        private MaterialSkin.Controls.MaterialCard materialCard11;
        private MaterialSkin.Controls.MaterialListView confusematrix;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private MaterialSkin.Controls.MaterialLabel materialLabel57;
        private MaterialSkin.Controls.MaterialCard materialCard10;
        private MaterialSkin.Controls.MaterialLabel totalpercent;
        private MaterialSkin.Controls.MaterialLabel materialLabel40;
        private MaterialSkin.Controls.MaterialProgressBar totalProgressBar;
        private MaterialSkin.Controls.MaterialLabel materialLabel36;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.TabPage SystemSetting;
        private MaterialSkin.Controls.MaterialButton systemsetting_save;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox4;
        private MaterialSkin.Controls.MaterialLabel materialLabel18;
        private MaterialSkin.Controls.MaterialCard materialCard8;
        private MaterialSkin.Controls.MaterialButton selectcsvfolderButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel28;
        private MaterialSkin.Controls.MaterialTextBox2 grayShareFolderTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel54;
        private MaterialSkin.Controls.MaterialLabel materialLabel53;
        private MaterialSkin.Controls.MaterialButton exportadd;
        private MaterialSkin.Controls.MaterialListBox exportFolderList;
        private MaterialSkin.Controls.MaterialButton exportremove;
        private MaterialSkin.Controls.MaterialTextBox2 delayAfterMonitorTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel39;
        private MaterialSkin.Controls.MaterialButton selectbackupButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel37;
        private MaterialSkin.Controls.MaterialTextBox2 backupTextBox;
        private MaterialSkin.Controls.MaterialTextBox2 systemNameTextBox;
        private MaterialSkin.Controls.MaterialTextBox2 monitorFreqTextBox;
        private MaterialSkin.Controls.MaterialButton selectsharefolderButton;
        private MaterialSkin.Controls.MaterialTextBox2 imageSaveFolderTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel30;
        private MaterialSkin.Controls.MaterialLabel materialLabel29;
        private MaterialSkin.Controls.MaterialTextBox2 rejudgeTimeOutTextBox;
        private MaterialSkin.Controls.MaterialTextBox2 portTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel27;
        private MaterialSkin.Controls.MaterialTextBox2 ipTextBox;
        private MaterialSkin.Controls.MaterialButton selectimportButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel25;
        private MaterialSkin.Controls.MaterialTextBox2 importFolderTextBox;
        private MaterialSkin.Controls.MaterialButton selectexportButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel24;
        private MaterialSkin.Controls.MaterialTextBox2 exportTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel23;
        private System.Windows.Forms.PictureBox system_setting;
        private System.Windows.Forms.TabPage ProductSetting;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox2;
        private MaterialSkin.Controls.MaterialLabel materialLabel16;
        private MaterialSkin.Controls.MaterialButton productsetting_save;
        private MaterialSkin.Controls.MaterialCard materialCard7;
        private MaterialSkin.Controls.MaterialTextBox2 productnameTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel32;
        private MaterialSkin.Controls.MaterialLabel materialLabel22;
        private MaterialSkin.Controls.MaterialButton selectAiModelButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel21;
        private MaterialSkin.Controls.MaterialLabel materialLabel20;
        private MaterialSkin.Controls.MaterialLabel materialLabel19;
        private MaterialSkin.Controls.MaterialTextBox2 aimodelTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel17;
        private System.Windows.Forms.PictureBox product_setting;
        private System.Windows.Forms.TabPage Home;
        private MaterialSkin.Controls.MaterialLabel materialLabel49;
        private System.Windows.Forms.PictureBox pictureBox4;
        private MaterialSkin.Controls.MaterialCard materialCard12;
        private MaterialSkin.Controls.MaterialSlider accuracySlider;
        private MaterialSkin.Controls.MaterialCard materialCard1;
        private System.Windows.Forms.PictureBox Recipe_OK;
        private System.Windows.Forms.PictureBox Rejudge_OK;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox AI_OK;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label2;
        private MaterialSkin.Controls.MaterialLabel materialLabel31;
        private System.Windows.Forms.PictureBox Rejudge_NG;
        private System.Windows.Forms.PictureBox Recipe_NG;
        private System.Windows.Forms.PictureBox AI_NG;
        private System.Windows.Forms.PictureBox foldersetting_OK;
        private System.Windows.Forms.Label label6;
        private MaterialSkin.Controls.MaterialLabel materialLabel35;
        private System.Windows.Forms.PictureBox foldersetting_NG;
        private MaterialSkin.Controls.MaterialLabel materialLabel34;
        private MaterialSkin.Controls.MaterialLabel materialLabel33;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialCard materialCard3;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox3;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox1;
        private System.Windows.Forms.Label label5;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialCard materialCard2;
        private MaterialSkin.Controls.MaterialSwitch backup_Switch;
        private MaterialSkin.Controls.MaterialSwitch rejudge_Switch;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialButton startButton;
        private MaterialSkin.Controls.MaterialButton stopButton;
        private MaterialSkin.Controls.MaterialTabControl TabControlHome;
        private MaterialSkin.Controls.MaterialLabel colorLabel;
        private System.Windows.Forms.PictureBox grayimg;
        private MaterialSkin.Controls.MaterialLabel grayLabel;
        private System.Windows.Forms.PictureBox colorimg;
        private MaterialSkin.Controls.MaterialComboBox selectAiAccModel;
        private MaterialSkin.Controls.MaterialButton bt_reflash;
        private MaterialSkin.Controls.MaterialTextBox2 unknownTHTextBox;
        private System.Windows.Forms.DataGridView GV_DefectTable;
        private MaterialSkin.Controls.MaterialButton btn_AreaCheckTool;
        private MaterialSkin.Controls.MaterialLabel materialLabel50;
        private MaterialSkin.Controls.MaterialLabel materialLabel41;
        private MaterialSkin.Controls.MaterialTextBox2 mindefectareaTextBox;
        private MaterialSkin.Controls.MaterialTextBox2 regionsizeTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel45;
        private MaterialSkin.Controls.MaterialSwitch shortAreaCheck_Switch;
        private MaterialSkin.Controls.MaterialLabel materialLabel46;
        private MaterialSkin.Controls.MaterialLabel materialLabel26;
        private MaterialSkin.Controls.MaterialRadioButton mode2RadioButton;
        private MaterialSkin.Controls.MaterialRadioButton mode1RadioButton;
        private MaterialSkin.Controls.MaterialButton selectAiYieldModelButton;
        private MaterialSkin.Controls.MaterialLabel materialLabel47;
        private MaterialSkin.Controls.MaterialTextBox2 aiYieldModelTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel48;
        private MaterialSkin.Controls.MaterialButton selectWorkFolderButton;
        private MaterialSkin.Controls.MaterialTextBox2 workFolderTextBox;
        private System.Windows.Forms.FlowLayoutPanel defectCodeFlowLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel detailDefectCodeFlowLayoutPanel;
        private MaterialSkin.Controls.MaterialLabel materialLabel51;
        private System.Windows.Forms.FlowLayoutPanel AiAccFlowLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel AreaCheckedflowLayoutPanel;
        private MaterialSkin.Controls.MaterialTextBox2 repairableTextBox;
        private MaterialSkin.Controls.MaterialTextBox2 nonrepairTextBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel52;
        private System.Windows.Forms.DataGridViewComboBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn AOI_Defect;
        private System.Windows.Forms.DataGridViewComboBoxColumn Judge;
        private System.Windows.Forms.DataGridViewComboBoxColumn AI_Result;
        private System.Windows.Forms.DataGridViewTextBoxColumn NewResult;
        private MaterialSkin.Controls.MaterialLabel materialLabel55;
    }
}

