﻿using MaterialSkin;
using MaterialSkin.Controls;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace KinsusAutoAOI
{
    public partial class Mainform : MaterialForm
    {

        CommonBase.Logger.InfoManager info;
        CommonBase.Network.Client client;

        //Initial
        PConfig pconfig = new PConfig();
        SConfig sconfig = new SConfig();
        Dictionary<string, string> AI_Transform = new Dictionary<string, string>();
        Dictionary<string, int> Label_Transform = new Dictionary<string, int>();
        Dictionary<string, string> AI_Detail_Transform = new Dictionary<string, string>();
        Dictionary<string, int> Label_Detail_Transform = new Dictionary<string, int>();

        public Mainform()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Color.FromArgb(255, 0, 80, 135),
                Color.FromArgb(240, 0, 80, 135), Color.FromArgb(255, 255, 255, 255),
                Color.FromArgb(255, 0, 80, 135), TextShade.WHITE);
        }
        private void Mainform_Load(object sender, EventArgs e)
        {
            try
            {
                //  初始化Logger
                info = new CommonBase.Logger.InfoManager(".\\log\\general",
                    ".\\log\\network", ".\\log\\warning", ".\\log\\error", ".\\log\\debug");
                info.SetGeneralTextBox(ref this.richTextBox1);
                info.SetErrorTextBox(ref this.richTextBox2);

                //  檢查product recipe資料夾
                DirectoryInfo dir1 = new DirectoryInfo(".\\Recipe\\product");
                if (!dir1.Exists) dir1.Create();
                //  載入產品參數
                if (!File.Exists(dir1 + "\\default.xml")) pconfig.CreateXML(pconfig, dir1 + "\\default.xml");
                else pconfig = pconfig.ReadXML(dir1 + "\\default.xml");
                FileInfo[] productlist = dir1.GetFiles();
                this.materialComboBox1.Items.Clear();
                this.materialComboBox2.Items.Clear();
                foreach (var product in productlist)
                {
                    this.materialComboBox1.Items.Add(product.ToString().Replace(".xml", ""));
                    this.materialComboBox2.Items.Add(product.ToString().Replace(".xml", ""));
                }

                //  檢查system recipe資料夾
                DirectoryInfo dir2 = new DirectoryInfo(".\\Recipe\\system");
                if (!dir2.Exists) dir2.Create();
                //  載入系統參數
                if (!File.Exists(dir2 + "\\default.xml")) sconfig.CreateXML(sconfig, dir2 + "\\default.xml");
                else sconfig = sconfig.ReadXML(dir2 + "\\default.xml");
                FileInfo[] systemlist = dir2.GetFiles();
                this.materialComboBox3.Items.Clear();
                this.materialComboBox4.Items.Clear();
                foreach (var system in systemlist)
                {
                    this.materialComboBox3.Items.Add(system.ToString().Replace(".xml", ""));
                    this.materialComboBox4.Items.Add(system.ToString().Replace(".xml", ""));
                }

                //Check Acc. Folder
                selectAiAccModel.Items.Clear();
                string path3 = ".\\Accuracy_predict\\";
                foreach (String d in Directory.GetDirectories(path3))
                {
                    selectAiAccModel.Items.Add(Path.GetFileName(d));
                }
                if (selectAiAccModel.Items.Count > 0)
                    selectAiAccModel.SelectedIndex = 0;

                // 檢查Accuracy_predict資料夾
                DirectoryInfo dir3 = new DirectoryInfo(".\\Accuracy_predict");
                if (!dir3.Exists) dir3.Create();

                // 檢查Share_folder資料夾
                string path4 = Application.StartupPath + ".\\Share_folder";
                DirectoryInfo dir4 = new DirectoryInfo(path4);
                if (!dir4.Exists) dir4.Create();
                if (sconfig.ColorMode == false) sconfig.GrayShareFolder = path4;

                //更新Ai accuracy介面
                selectAiAccRange.SelectedItem = "Today";
                Show_Ai_Accuracy(-1);

                //set run mode
                this.mode1RadioButton.Checked = true;
                this.mode2RadioButton.Checked = false;

                //check short area
                materialLabel41.Visible = true;
                materialLabel46.Visible = true;
                materialLabel50.Visible = true;
                mindefectareaTextBox.Visible = true;
                regionsizeTextBox.Visible = true;
                btn_AreaCheckTool.Enabled = true;
                btn_AreaCheckTool.Visible = true;
                shortAreaCheck_Switch.Checked = true;
                shortAreaCheck_Switch.Enabled = true;
                AreaCheckedflowLayoutPanel.Visible = true;

                //gray mode UI
                if (sconfig.ColorMode == false)
                {
                    materialLabel28.Visible = false;
                    materialLabel45.Visible = true;
                    grayShareFolderTextBox.Visible = false;
                    selectcsvfolderButton.Visible = false;
                    grayimg.Visible = true;
                    grayLabel.Visible = true;
                    colorimg.Visible = false;
                    colorLabel.Visible = false;
                    mindefectareaTextBox.Visible = true;
                    regionsizeTextBox.Visible = true;
                    exportTextBox.Hint = "Ex : \\\\CIMS_IP\\AiExport";

                    //lock human rejudge
                    rejudge_Switch.Checked = false;
                    rejudge_Switch.Enabled = false;

                    //yield AI model
                    aiYieldModelTextBox.Visible = false;
                    selectAiYieldModelButton.Visible = false;
                    materialLabel47.Visible = false;
                    detailDefectCodeFlowLayoutPanel.Visible = false;
                    materialLabel51.Visible = false;
                }
                //color mode UI
                else
                {
                    materialLabel28.Visible = true;
                    materialLabel45.Visible = false;
                    grayShareFolderTextBox.Visible = true;
                    selectcsvfolderButton.Visible = true;
                    grayimg.Visible = false;
                    grayLabel.Visible = false;
                    colorimg.Visible = true;
                    colorLabel.Visible = true;
                    exportTextBox.Hint = "Ex : \\\\CIMS_IP\\AutoVRS\\VRS_C-22013";

                    //unlock human rejudge
                    rejudge_Switch.Checked = true;
                    rejudge_Switch.Enabled = true;

                    //yield AI model
                    aiYieldModelTextBox.Visible = true;
                    selectAiYieldModelButton.Visible = true;
                    materialLabel47.Visible = true;
                    detailDefectCodeFlowLayoutPanel.Visible = true;
                    materialLabel51.Visible = true;
                }

                // 啟用呼吸燈
                backgroundWorker3.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                info.Error("Initial Fail.");
                info.Error(ex.ToString());
            }
        }

        private void Mainform_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Confirm exit"
                    , MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                {
                    if (this.info != null) this.info.Dispose();
                    if (client != null) client.Dispose();
                    backgroundWorker1.CancelAsync();
                    backgroundWorker2.CancelAsync();
                    backgroundWorker3.CancelAsync();
                    System.Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                    return;
                }
            }
            catch { return; }
        }

        #region Check

        private bool Check_environment()
        {
            Check_recipe();
            if (Recipe_OK.Visible != true) return false;
            Check_AI_Environment();
            Check_folder_setting();

            if (this.rejudge_Switch.Checked == true) Check_Rejudge_Center();
            else
            {
                this.Rejudge_OK.Visible = false;
                this.Rejudge_NG.Visible = false;
            }
            //check NG lights is closed            
            if (this.Rejudge_NG.Visible == false && this.AI_NG.Visible == false
                && foldersetting_NG.Visible == false && Recipe_NG.Visible == false)
            {
                info.General("Initial Successful.");
                if (materialComboBox1.Text == "") return false;
                else return true;
            }
            else
            {
                info.Error("Initial Fail.");
                return false;
            }
        }

        private void Check_recipe()
        {
            try
            {
                if (materialComboBox1.SelectedItem == null || materialComboBox3.SelectedItem == null)
                {
                    DialogResult result = MessageBox.Show("Please set Product Recipe and System Recipe!", "Warning"
                         , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.Recipe_OK.Visible = false;
                    this.Recipe_NG.Visible = true;
                }
                else
                {
                    pconfig = pconfig.ReadXML(".\\Recipe\\product\\" + materialComboBox1.SelectedItem.ToString() + ".xml");
                    sconfig = sconfig.ReadXML(".\\Recipe\\system\\" + materialComboBox3.SelectedItem.ToString() + ".xml");
                    this.Recipe_OK.Visible = true;
                    this.Recipe_NG.Visible = false;
                }
            }
            catch (Exception e)
            {
                info.Error(e.Message);
                this.Recipe_OK.Visible = false;
                this.Recipe_NG.Visible = true;
            }
        }

        private void Check_folder_setting()
        {
            bool status = true;

            if (!Directory.Exists(sconfig.ImportPath))
            {
                info.Error("CDB Import folder not found!");
                DialogResult result = MessageBox.Show("Import folder not found! Please set Import folder.", "Warning"
                        , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!Directory.Exists(sconfig.LocalSaveFolder))
            {
                info.Error("Save folder not found!");
                DialogResult result = MessageBox.Show("Save folder not found! Please set local save folder by share format.", "Warning"
                        , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!Directory.Exists(sconfig.BackupFolder))
            {
                info.Error("Backup folder not found!");
                DialogResult result = MessageBox.Show("Backup folder not found! Please set Backup folder.", "Warning"
                        , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }
            if (sconfig.ColorMode == true)
            {
                if (!Directory.Exists(sconfig.GrayShareFolder))
                {
                    info.Error("Gray share folder not found!");
                    DialogResult result = MessageBox.Show("Gray share folder not found! Please set Gray share folder.", "Warning"
                            , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    status = false;
                }
            }
            for (int i = 0; i < sconfig.ExportFolderList.Count; i++)
            {
                if (!Directory.Exists(sconfig.ExportFolderList[i].Text))
                {
                    info.Error("CDB Export folder " + sconfig.ExportFolderList[i].Text + " not found!");
                    DialogResult result = MessageBox.Show("Export folder " + sconfig.ExportFolderList[i].Text
                        + " not found! Please set Export folder.", "Warning"
                            , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    status = false;
                }
            }

            if (status == true)
            {
                this.foldersetting_OK.Visible = true;
                this.foldersetting_NG.Visible = false;
            }
            else
            {
                this.foldersetting_OK.Visible = false;
                this.foldersetting_NG.Visible = true;
                info.Error("Folder setting fail !");
            }
        }

        private void Check_AI_Environment()
        {
            bool status = true;
            if (!Directory.Exists(sconfig.WorkPath))
            {
                info.Error("Python work path not found!");
                MessageBox.Show("Python work path not found! Please set Import folder.", "Warning"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            string mainpy_path = Path.Combine(sconfig.WorkPath, "main.py");
            if (!File.Exists(mainpy_path))
            {
                info.Error("AI main code not found!");
                MessageBox.Show("AI main code not found! Please check main.py file.", "Warning"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!File.Exists(pconfig.AiModelPath))
            {
                info.Error("AI model (.onnx) not found!");
                MessageBox.Show("AI model (.onnx) not found! Please set AI model.", "Warning"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!File.Exists(pconfig.AiDetailModelPath) && sconfig.ColorMode == true)
            {
                info.Error("AI detail model (.onnx) not found!");
                MessageBox.Show("AI detail model (.onnx) not found! Please set AI detail model.", "Warning"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!File.Exists(pconfig.AiModelPath.Replace(".onnx", ".ini")))
            {
                info.Error("AI label name file (.ini) not found!");
                MessageBox.Show("AI label file (.ini) not found! Please check *.ini file is exist"
                    , "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (!File.Exists(pconfig.AiDetailModelPath.Replace(".onnx", ".ini")) && sconfig.ColorMode == true)
            {
                info.Error("AI detail label name file (.ini) not found!");
                MessageBox.Show("AI detail label file (.ini) not found! Please check *.ini file is exist"
                    , "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            string[] pyfilelist = {"ClsDataset.cp37-win_amd64.pyd"
                    ,"ClsPostprocessing.cp37-win_amd64.pyd"
                    ,"MAMC_model.cp37-win_amd64.pyd"
                    ,"ModelInference.cp37-win_amd64.pyd"
                    ,"UsingCsv.cp37-win_amd64.pyd"};
            foreach (string file in pyfilelist)
            {
                string pyd_path = Path.Combine(sconfig.WorkPath, "utils", file);
                if (!File.Exists(pyd_path))
                {
                    info.Error(pyd_path + " not found!");
                    MessageBox.Show("AI file not found! Please check " + pyd_path + " is exist!"
                        , "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    status = false;
                    break;
                }
            }

            if (pconfig.AiUnknownThreshold > 100 || pconfig.AiUnknownThreshold < 0)
            {
                info.Error("AI Unknown Threshold should between 0% to 100% !");
                MessageBox.Show("AI Unknown Threshold should between 0% to 100% !", "Warning"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                status = false;
            }

            if (status == true)
            {
                this.AI_OK.Visible = true;
                this.AI_NG.Visible = false;
            }
            else
            {
                this.AI_OK.Visible = false;
                this.AI_NG.Visible = true;
                info.Error("Check AI environment fail !");
            }
        }

        private void Check_Rejudge_Center()
        {
            // 定義中控Client            
            //check Rejudge center
            try
            {
                client = new CommonBase.Network.Client(sconfig.RejudgeCenterIp, Convert.ToInt32(sconfig.RejudgeCenterPort));
                client.StartConnect();
                client.StopConnect();
                this.Rejudge_OK.Visible = true;
                this.Rejudge_NG.Visible = false;
                //info.General("Check rejudge center OK !");
            }
            catch
            {
                this.Rejudge_OK.Visible = false;
                this.Rejudge_NG.Visible = true;
                info.Error("Cannot connect Rejudge center! Please check IP/Port, or reboot rejudge center.");
                DialogResult result = MessageBox.Show("Cannot connect Rejudge center! Please check IP/Port," +
                    " or setting rejudge center.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        #endregion

        private void startButton_Click(object sender, EventArgs e)
        {
            bool check_result = Check_environment();
            if (check_result == false) return;

            if (!backgroundWorker1.IsBusy)
            {
                this.rejudge_Switch.Enabled = false;
                this.backup_Switch.Enabled = false;
                this.shortAreaCheck_Switch.Enabled = false;
                this.materialComboBox1.Enabled = false;
                this.materialComboBox3.Enabled = false;
                this.productsetting_save.Enabled = false;
                this.systemsetting_save.Enabled = false;
                this.accuracySlider.Enabled = false;
                this.mode1RadioButton.Enabled = false;
                this.mode2RadioButton.Enabled = false;

                pconfig = pconfig.ReadXML(".\\Recipe\\product\\" + materialComboBox1.SelectedItem.ToString() + ".xml");
                sconfig = sconfig.ReadXML(".\\Recipe\\system\\" + materialComboBox3.SelectedItem.ToString() + ".xml");

                if (this.mode1RadioButton.Checked == true && this.mode2RadioButton.Checked == false)
                {
                    sconfig.YieldAnalysis = false;
                }
                else if (this.mode1RadioButton.Checked == false && this.mode2RadioButton.Checked == true)
                {
                    sconfig.YieldAnalysis = true;
                }
                else
                {
                    info.Error("Run mode select error!");
                    return;
                }

                pconfig.BypassStringList.Clear();
                foreach (DataRow r in pconfig.DefectRuleTable.Rows)
                {
                    if (r["Type"].ToString() == "Bypass")
                        pconfig.BypassStringList.Add(r["AOI_Defect"].ToString());
                }

                sconfig.CatchRate = Convert.ToDouble(accuracySlider.Value) / 100;
                Read_label_ini();
                this.startButton.Enabled = false;
                this.stopButton.Enabled = true;
                backgroundWorker1.RunWorkerAsync();
                backgroundWorker2.RunWorkerAsync();
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            if (backgroundWorker1.IsBusy)
            {
                this.rejudge_Switch.Enabled = true;
                this.backup_Switch.Enabled = true;
                if (sconfig.ColorMode == false) this.shortAreaCheck_Switch.Enabled = true;
                this.stopButton.Enabled = false;
                this.startButton.Enabled = true;
                this.materialComboBox1.Enabled = true;
                this.materialComboBox3.Enabled = true;
                this.productsetting_save.Enabled = true;
                this.systemsetting_save.Enabled = true;
                this.accuracySlider.Enabled = true;
                this.mode1RadioButton.Enabled = true;
                this.mode2RadioButton.Enabled = true;
                backgroundWorker1.CancelAsync();
                backgroundWorker2.CancelAsync();
            }
        }

        //Monitor new csv file
        private void MainWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                while (true)
                {
                    //monitor check cancel
                    if (backgroundWorker1.CancellationPending)
                    {
                        e.Cancel = true;
                        info.General("System Stop.");
                        break;
                    }
                    //do
                    DirectoryInfo[] monitorfolders = new DirectoryInfo[0];
                    string[] csvfilenames = new string[0];

                    foreach (MaterialListBoxItem item in sconfig.ExportFolderList)
                    {
                        if (sconfig.ColorMode == false) //Gray Mode monitor csv file
                        {
                            (List<DirectoryInfo> monitorfolder, List<string> csvfilename) = GetExportFile(item.Text);
                            monitorfolders = monitorfolders.Concat(monitorfolder).ToArray();
                            csvfilenames = csvfilenames.Concat(csvfilename).ToArray();
                        }
                        else //Color Mode monitor image folder
                        {
                            (DirectoryInfo[] monitorfolder, string[] csvfilename) = GetExportFolder(item.Text);
                            monitorfolders = monitorfolders.Concat(monitorfolder).ToArray();
                            csvfilenames = csvfilenames.Concat(csvfilename).ToArray();
                        }
                    }
                    if (monitorfolders.Length == 0)
                    {
                        Thread.Sleep(Convert.ToInt32(sconfig.MonitorFrequency) * 1000);
                        continue;
                    }
                    info.General("Find " + monitorfolders.Length.ToString() + " csv file.");
                    info.General("Delay " + sconfig.DelayAfterMonitor + " second after monitor.");
                    Thread.Sleep(Convert.ToInt32(sconfig.DelayAfterMonitor) * 1000);

                    for (int i = 0; i < monitorfolders.Length; i++)
                    {
                        //check cancel
                        if (backgroundWorker1.CancellationPending)
                        {
                            e.Cancel = true;
                            info.General("Work Stop.");
                            break;
                        }
                        //do
                        sconfig.WorkName = sconfig.NowMonitorTime.ToString("yyyyMMdd_HHmmss") + "_" + i.ToString();
                        info.General("Judge Panel ID:" + monitorfolders[i].Name);
                        sconfig.TargetPath = Cut_Export_files(monitorfolders[i].FullName);
                        KillEmptyExportFolder(monitorfolders[i].FullName);
                        if (csvfilenames[i] == "nocsvdata")
                            continue; //When color mode, if match gray csv fail, than pass.
                        else
                            sconfig.CsvFileName = csvfilenames[i];

                        if (sconfig.ColorMode == true) CopyCsvToTarget();

                        AI_Classification();
                        RejudgeCenter(this.rejudge_Switch.Checked); //include short area check
                        (List<string> Result, List<string> AI_Predict) = MergeResult(); //include retype and pypass
                        if (AI_Predict.Count() != 0) Save_AI_Accuracy_Data(AI_Predict);
                        WriteToCSV(Result);
                        MoveToSaveFolder();
                        KillEmptyWorkFolder(sconfig.LocalWorkFolder);

                        //backup
                        if (this.backup_Switch.Checked && sconfig.LocalSaveFolder + sconfig.SubPath != null)
                            sconfig.BackupWorkList.Add(sconfig.LocalSaveFolder + sconfig.SubPath);
                    }
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.Message);
            }
        }

        private void BackupWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                while (true)
                {
                    //worker cancel
                    if (backgroundWorker2.CancellationPending)
                    {
                        e.Cancel = true;
                        info.General("Backup Thread Stop.");
                        break;
                    }
                    else if (sconfig.BackupWorkList.Count != 0)
                    {
                        string sourcePath = sconfig.BackupWorkList[0];
                        string targetPath = sourcePath.Replace(sconfig.LocalSaveFolder, sconfig.BackupFolder);

                        //Now Create all of the directories
                        if (!Directory.Exists(targetPath))
                        {
                            Directory.CreateDirectory(targetPath);
                        }

                        if (!Directory.Exists(targetPath + "\\Ref\\") && sconfig.ColorMode == false)
                        {
                            Directory.CreateDirectory(targetPath + "\\Ref\\");
                        }

                        //backup
                        foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                        {
                            string destpath = newPath.Replace(sourcePath, targetPath);
                            if (!File.Exists(destpath))
                            {
                                File.Copy(newPath, destpath);
                            }
                        }

                        //remove bckup work list
                        sconfig.BackupWorkList.RemoveAt(0);
                    }
                    else
                    {
                        Thread.Sleep(50);
                    }
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.Message);
            }
        }

        private void BreathinglightWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                for (int i = 0; i < 180; i++)
                {
                    int color4 = Convert.ToInt32((Math.Sin(i * 0.0349) + 1) * 127);
                    int color3 = Convert.ToInt32((Math.Sin((i + 30) * 0.0349) + 1) * 127);
                    int color2 = Convert.ToInt32((Math.Sin((i + 60) * 0.0349) + 1) * 127);
                    int color1 = Convert.ToInt32((Math.Sin((i + 90) * 0.0349) + 1) * 127);
                    light4.BackColor = Color.FromArgb(color1, 242, 242, 242);
                    light3.BackColor = Color.FromArgb(color2, 242, 242, 242);
                    light2.BackColor = Color.FromArgb(color3, 242, 242, 242);
                    light1.BackColor = Color.FromArgb(color4, 242, 242, 242);
                    Thread.Sleep(15);
                }
            }
        }
        private (List<DirectoryInfo>, List<string> csvfilenames) GetExportFile(string path)//graymode get csv file
        {
            info.General("Monitor CSV file " + path);
            DirectoryInfo dir = new DirectoryInfo(@path);
            FileInfo[] csvfiles = dir.GetFiles("*.csv", SearchOption.AllDirectories)
                .OrderBy(p => p.LastAccessTime).ToArray();

            List<DirectoryInfo> csvfolders = new List<DirectoryInfo>();
            List<string> csvfilenames = new List<string>();
            for (int i = 0; i < csvfiles.Length; i++)
            {
                FileStream fs = null;
                try
                {
                    using (fs = new FileStream(csvfiles[i].FullName, FileMode.Open, FileAccess.Read, FileShare.None))
                        csvfolders.Add(csvfiles[i].Directory);
                    csvfilenames.Add(csvfiles[i].Name);
                }
                catch
                {
                    info.Warning("This csv file is used by other program so it can't open. " + csvfiles[i].FullName);
                }
            }
            sconfig.NowMonitorTime = DateTime.Now;
            return (csvfolders, csvfilenames);
        }

        private (DirectoryInfo[], string[]) GetExportFolder(string monitorpath)//color mode get images
        {
            info.General("Monitor AutoVRS folder : " + monitorpath);
            DirectoryInfo dir = new DirectoryInfo(@monitorpath);
            DirectoryInfo sharefolder = new DirectoryInfo(sconfig.GrayShareFolder);
            DirectoryInfo[] Panels = new DirectoryInfo[0];
            DirectoryInfo[] vrsfolders = new DirectoryInfo[0];
            string[] csvfilenames = new string[0];

            foreach (DirectoryInfo LotID in dir.GetDirectories("*", SearchOption.TopDirectoryOnly))
            {
                foreach (DirectoryInfo Layer in LotID.GetDirectories("*", SearchOption.TopDirectoryOnly))
                {
                    foreach (DirectoryInfo Lot in Layer.GetDirectories("*", SearchOption.TopDirectoryOnly))
                    {
                        Panels = Lot.GetDirectories("*", SearchOption.TopDirectoryOnly);
                        vrsfolders = vrsfolders.Concat(Panels).ToArray();
                    }
                }
            }
            //order by last access time
            vrsfolders.OrderBy(p => p.LastAccessTime).ToArray();
            //match csv
            foreach (DirectoryInfo vrsfolder in vrsfolders)
            {
                string[] panelinfo = vrsfolder.FullName.Split('\\');
                int infolength = panelinfo.Length;
                //use LotID~Layer~Lot to find the gray csv
                string endcsv = "*" + panelinfo[infolength - 3] + "~" + panelinfo[infolength - 2] + "~" + panelinfo[infolength - 1] + ".csv";
                FileInfo[] matchcsv = sharefolder.GetFiles(endcsv, SearchOption.TopDirectoryOnly);
                if (matchcsv.Length == 1)//normal case
                {
                    csvfilenames = csvfilenames.Append(matchcsv[0].Name).ToArray();
                }
                else if (matchcsv.Length > 1)//mach multiple csv case
                {
                    info.Error(endcsv + " match " + matchcsv.Length.ToString() + " csv file.");
                    csvfilenames = csvfilenames.Append("nocsvdata").ToArray();
                }
                else//no csv data
                {
                    info.Error(endcsv + " file not match.");
                    csvfilenames = csvfilenames.Append("nocsvdata").ToArray();
                }
            }
            sconfig.NowMonitorTime = DateTime.Now;
            return (vrsfolders, csvfilenames);
        }

        private void Read_label_ini()
        {
            try
            {
                //create label_transform
                AI_Transform.Clear();
                Label_Transform.Clear();
                StreamReader SR1 = new StreamReader(pconfig.AiModelPath.Replace(".onnx", ".ini"));
                while (SR1.Peek() >= 0)
                {
                    string ini_line = SR1.ReadLine();
                    if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                    {
                        continue;
                    }
                    string labelname = ini_line;
                    string[] Label_Names = labelname.Split('=');
                    //create transform dictionary
                    AI_Transform.Add(Label_Names[0], Label_Names[1]);
                    Label_Transform.Add(Label_Names[1], Convert.ToInt32(Label_Names[0]));
                }
                SR1.Close();

                if (sconfig.ColorMode == true)
                {
                    //create label_detail_transform
                    AI_Detail_Transform.Clear();
                    Label_Detail_Transform.Clear();
                    StreamReader SR2 = new StreamReader(pconfig.AiDetailModelPath.Replace(".onnx", ".ini"));
                    while (SR2.Peek() >= 0)
                    {
                        string ini_line = SR2.ReadLine();
                        if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                        {
                            continue;
                        }
                        string labelname = ini_line;
                        string[] Label_Names = labelname.Split('=');
                        //create transform dictionary
                        AI_Detail_Transform.Add(Label_Names[0], Label_Names[1]);
                        Label_Detail_Transform.Add(Label_Names[1], Convert.ToInt32(Label_Names[0]));
                    }
                    SR2.Close();
                }
            }
            catch (Exception e)
            {
                info.Error(e.Message);
            }
        }

        private String[] Read_label_ini(String file_name)
        {
            List<String> class_temp = new List<string>();
            //create label_transform
            if (File.Exists(file_name.Replace(".onnx", ".ini")))
            {

                StreamReader SR = new StreamReader(file_name.Replace(".onnx", ".ini"));
                while (SR.Peek() >= 0)
                {
                    string ini_line = SR.ReadLine();
                    if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                    {
                        continue;
                    }
                    string[] Label_Names = ini_line.Split('='); //0=PASS
                    //create transform dictionary
                    class_temp.Add(Label_Names[1]);
                }
                SR.Close();
            }
            else
            {
                MessageBox.Show("AI Model .ini檔案不存在，請確認檔案!");
            }
            return class_temp.ToArray();
        }

        private string Cut_Export_files(string folder)
        {
            string real_target = null;
            bool search_subpath = false;
            try
            {
                foreach (MaterialListBoxItem item in sconfig.ExportFolderList)
                {
                    if (folder.Contains(item.Text))
                    {
                        sconfig.SubPath = folder.Replace(item.Text, "");
                        search_subpath = true;
                    }
                }
                if (search_subpath == false)
                {
                    info.Error(folder + " doesn't include in export path.");
                }
                string targetfolder = sconfig.LocalWorkFolder + sconfig.SubPath;
                real_target = MoveFilesRecursively(folder, targetfolder);
            }
            catch (Exception e)
            {
                info.Error(e.Message);
            }
            return real_target;
        }

        private string MoveFilesRecursively(string sourcePath, string targetPath)
        {
            string shareFolderPath = "";
            //Now Create all of the directories
            if (!Directory.Exists(targetPath))
            {
                Directory.CreateDirectory(targetPath);
                if (sconfig.ColorMode == false)
                {
                    Directory.CreateDirectory(targetPath + "\\Ref\\");
                }
            }
            else
            {
                info.Warning("This panel has been judge before." + targetPath);
            }

            if (sconfig.ColorMode == false)
            {
                info.General("create ref folder of share folder");
                string[] subpathlist = sconfig.SubPath.Split('\\');
                shareFolderPath = sconfig.GrayShareFolder + "\\" + subpathlist[3] + "\\" + subpathlist[4] + "\\" + subpathlist[5];
                Directory.CreateDirectory(shareFolderPath + "\\Ref");
            }

            info.General("Copy data from monitor folder to local.");
            //Copy all the files & Replaces any files with the same name
            foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
            {
                //gray mode contain CAM and defect image
                if (sconfig.ColorMode == false)
                {
                    try
                    {
                        //move ref file from exporting folder to local
                        string local_folder;
                        string finalShareFolderPath;
                        if (newPath.Contains("_Ref."))
                        {
                            local_folder = newPath.Replace(sourcePath, targetPath + "\\Ref");
                            finalShareFolderPath = shareFolderPath + "\\Ref";
                        }
                        else
                        {
                            local_folder = newPath.Replace(sourcePath, targetPath);
                            finalShareFolderPath = shareFolderPath;
                        }
                        
                        if (File.Exists(local_folder))
                        {
                            File.Delete(local_folder);
                        }
                        else
                        {
                            File.Move(newPath, local_folder);
                        }

                        //copy file from local to share folder
                        string[] pathlist = newPath.Split('\\');
                        string filename = pathlist[pathlist.Length - 1];
                        string fullpath = finalShareFolderPath + "\\" + filename;
                        if (File.Exists(fullpath))
                        {
                            File.Delete(fullpath);
                        }
                        File.Copy(local_folder, fullpath);
                    }
                    catch (Exception ex)
                    {
                        info.Warning(ex.Message);
                        info.Warning("Can't move file so bypass: " + newPath);
                    }
                }
                //color mode contain only defect images
                else
                {
                    try
                    {
                        string destpath = newPath.Replace(sourcePath, targetPath);
                        if (File.Exists(destpath))
                        {
                            File.Delete(newPath);
                        }
                        else
                        {
                            File.Move(newPath, destpath);
                        }
                    }
                    catch
                    {
                        info.Warning("Can't move the file so bypass this image: " + newPath);
                    }
                }
            }
            return targetPath;
        }

        private void CopyCsvToTarget()
        {
            try
            {
                string targetpath = sconfig.TargetPath + "\\" + sconfig.CsvFileName;
                if (File.Exists(targetpath))
                {
                    File.Delete(targetpath);
                }

                string local_csv = sconfig.LocalSaveFolder + sconfig.SubPath + "\\" + sconfig.CsvFileName;
                if (File.Exists(local_csv))
                {
                    info.General("Find recent CSV file from local save folder.");
                    info.General("Copy CSV file to color work folder.");
                    File.Copy(local_csv, targetpath);
                }
                else
                {
                    info.General("Copy CSV file from gray share folder to color work folder.");
                    File.Copy(sconfig.GrayShareFolder + "\\" + sconfig.CsvFileName, targetpath);
                }
            }
            catch (Exception e)
            {
                info.Error(e.Message);
            }
        }

        private void KillEmptyExportFolder(string csvfolder)
        {
            //folder is null
            info.General("Delete empty folder.");
            try
            {
                while (Directory.GetFiles(csvfolder, "*.*", SearchOption.AllDirectories).Count() == 0)
                {
                    //folder is not export folder
                    foreach (MaterialListBoxItem item in sconfig.ExportFolderList)
                    {
                        if (csvfolder == item.Text)
                        {
                            return;
                        }
                    }
                    Directory.Delete(csvfolder, true);
                    //up folder
                    csvfolder = Path.GetDirectoryName(csvfolder);
                }
            }
            catch
            {
                info.Warning("Can't delete empty folder. " + csvfolder);
            }
        }

        private void KillEmptyWorkFolder(string workfolder)
        {
            //folder is null
            info.General("Delete empty work folder.");
            try
            {
                foreach (string item in Directory.GetFileSystemEntries(workfolder, "*", SearchOption.AllDirectories))
                {
                    if (!File.Exists(item))
                    {
                        if (Directory.Exists(item))
                        {
                            string[] nFiles = Directory.GetFiles(item, "*.*", SearchOption.AllDirectories);
                            if (nFiles.Count() == 0)
                            {
                                Directory.Delete(item, true);
                            }
                        }
                    }
                }
            }
            catch
            {
                info.Warning("Can't delete empty folder. " + workfolder);
            }
        }

        private void Run_AI(string Line)
        {
            Process p = new Process();
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.WorkingDirectory = sconfig.WorkPath;
            p.StartInfo.Arguments = "/k " + Line + " & exit";
            p.StartInfo.CreateNoWindow = true; //不跳出cmd視窗
            p.Start();
        }

        private void AI_Classification()
        {
            string Line;
            string selectAiModel;
            double selectThreshold;
            string aiModelPath = pconfig.AiModelPath;
            string aiDetailModelPath = pconfig.AiDetailModelPath;
            bool firstThree = false;
            string panelID = sconfig.TargetPath.Split('\\')[sconfig.TargetPath.Split('\\').Length - 1];
            if (panelID.EndsWith("001") || panelID.EndsWith("002") || panelID.EndsWith("003") ||
                panelID.EndsWith("049") || panelID.EndsWith("050") || panelID.EndsWith("051")) firstThree = true;

            if (sconfig.ColorMode == false)
            {
                selectAiModel = aiModelPath;
                //gray mode 1
                if (sconfig.YieldAnalysis == false)
                {
                    selectThreshold = Convert.ToDouble(pconfig.AiUnknownThreshold) / 100;
                    pconfig.UseDetailModel = false;
                }
                //gray mode2
                else
                {
                    if (firstThree == true)
                    {
                        selectThreshold = 1;
                        pconfig.UseDetailModel = false;
                    }
                    else
                    {
                        selectThreshold = Convert.ToDouble(pconfig.AiUnknownThreshold) / 100;
                        pconfig.UseDetailModel = false;
                    }
                }
            }
            else
            {
                selectThreshold = Convert.ToDouble(pconfig.AiUnknownThreshold) / 100;
                //color mode 1
                if (sconfig.YieldAnalysis == false)
                {
                    selectAiModel = aiModelPath;
                    pconfig.UseDetailModel = false;
                }
                //color mode 2
                else
                {
                    if (firstThree == true)
                    {
                        selectAiModel = aiDetailModelPath;
                        pconfig.UseDetailModel = true;
                    }
                    else
                    {
                        selectAiModel = aiModelPath;
                        pconfig.UseDetailModel = false;
                    }
                }
            }

            try
            {
                Line = @"python main.py --image_folder_path=" + sconfig.TargetPath
                    + " --model_path=" + selectAiModel + " --unknown_threshold="
                    + selectThreshold.ToString() + " --csv_name=" + sconfig.WorkName;
                info.General(Line);
                info.General("AI inference start.");
                Run_AI(Line);
                while (!File.Exists(sconfig.WorkPath + "/" + sconfig.WorkName + ".csv"))
                {
                    Thread.Sleep(500);
                }
                info.General("AI inference finish.");
                info.General("Save csv file: " + sconfig.WorkName + ".csv");
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }

        private void RejudgeCenter(bool rejudgeswitch)
        {
            try
            {
                //transfer unknown data and known data from csv
                (List<string> unknownDataList, List<string> knownDataList) = Readcsv();
                List<string> new_known_data = new List<string>();
                info.General("Transfer unknown data from csv");

                //known image not exist
                if (knownDataList.Count == 0)
                {
                    if (unknownDataList.Count == 0)
                    {
                        info.Warning("No image data.");
                        return;
                    }
                    if (unknownDataList.Count != 0)
                    {
                        info.General("All confidence is lower than the setting threshold.");
                    }
                }

                //have known image
                //gray mode / known data - put into short area check
                if (knownDataList.Count != 0 && sconfig.ColorMode == false)
                {
                    // area check always on
                    info.General("gray mode / known data - put into short area check");
                    new_known_data.Clear();
                    new_known_data = ShortAreaCheck(knownDataList);
                    Write_txt(new_known_data, sconfig.TargetPath, "known.txt");
                }

                //color mode / known data / get gray area check result
                if (knownDataList.Count() != 0 && sconfig.ColorMode == true)
                {
                    info.General("color mode / known data - put into short area check");
                    new_known_data.Clear();
                    new_known_data = GetGrayShoreAreaCheckResult(knownDataList);
                    Write_txt(new_known_data, sconfig.TargetPath, "known.txt");
                }

                //算要取出的個數
                if (sconfig.ColorMode == true)
                {
                    int catch_num = Convert.ToInt32(Math.Ceiling(new_known_data.Count * sconfig.CatchRate));
                    if (catch_num != 0)
                    {
                        //根據個數及範圍產生隨機整數
                        Random rnd = new Random();
                        List<int> randomList = Enumerable.Range(1, new_known_data.Count)
                            .OrderBy(x => rnd.Next()).Take(catch_num).ToList();

                        //select and write to MDC.txt
                        foreach (int randomindex in randomList)
                        {
                            string[] knownlinedata = new_known_data[randomindex - 1].Split(',');
                            if (knownlinedata[2] != "") 
                            {
                                //have short area result
                                unknownDataList.Add(knownlinedata[0] + ",NULL," + knownlinedata[2]);
                            }
                            else
                            {
                                unknownDataList.Add(knownlinedata[0] + ",NULL," + knownlinedata[1]);
                            }
                            
                        }
                        info.General("Write select known file to MDC for accuracy calculate");
                    }
                }

                //gray mode / unknown data - put into short area check
                //gray mode / unknown data - copy to share folder
                if (unknownDataList.Count != 0 && sconfig.ColorMode == false)
                {
                    info.General("gray mode / unknown data - put into short area check");
                    List<string> new_unknown_data = ShortAreaCheck(unknownDataList);
                    Write_txt(new_unknown_data, sconfig.TargetPath, "MDC.txt");
                    string[] subpathlist = sconfig.SubPath.Split('\\');
                    string shareFolderPath = sconfig.GrayShareFolder + "\\" + subpathlist[3] + "\\" + subpathlist[4] + "\\" + subpathlist[5];
                    Write_txt(new_unknown_data, shareFolderPath, "MDC.txt");
                }

                //color mode / unknown data / Add cam and gray image path
                if (unknownDataList.Count() != 0 && sconfig.ColorMode == true)
                {
                    List<string> newUnknownDataList = AddCamPath(unknownDataList);
                    info.General("Write cam and gray image path to MDC for show.");
                    Write_txt(newUnknownDataList, sconfig.TargetPath, "MDC.txt");
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }

            //if rejudge off, skip tcpip
            if (rejudgeswitch == false) return;

            //TCPIP
            try
            {
                string selectlabel;
                if (pconfig.UseDetailModel == false)
                {
                    selectlabel = pconfig.AiLabelString.Replace("SHORT", "REPAIRABLE,NONREPAIR");
                }
                else
                {
                    selectlabel = pconfig.AiDetailLabelString.Replace("SHORT", "REPAIRABLE,NONREPAIR"); ;
                }
                //by片確認中控連線
                try
                {
                    client.StartConnect();
                }
                catch
                {
                    client = new CommonBase.Network.Client(sconfig.RejudgeCenterIp, Convert.ToInt32(sconfig.RejudgeCenterPort));
                    client.StartConnect();
                }

                CommonBase.Network.Request request = new CommonBase.Network.Request();
                CommonBase.Network.Response response = null;
                // Prepare request
                request.Command = "ALARM";
                request.Param1 = sconfig.TargetPath;
                request.Param2 = sconfig.RejudgeCenterTimeout + "000";
                request.Param3 = pconfig.ProductName;
                request.Param4 = selectlabel;
                request.Param5 = sconfig.CsvFileName;
                info.General(request.Command + "," + request.Param1 + "," + request.Param2 + "," +
                    request.Param3 + "," + request.Param4 + "," + request.Param5);

                // Send request and wait 2*Timeout to Monitor Center
                response = this.client.SendRequest(request, Convert.ToInt32(sconfig.RejudgeCenterTimeout) * 1000 * 2);
                info.General(String.Format(">>> Recive Response >> Result: [{1}]", response.Result, response.Param1));
                this.client.StopConnect();
                info.General("Rejudge finish.");
            }
            catch (Exception)
            {
                info.Error("Rejudge Center disconnect, please check rejudge center computer.");
                info.Error("This Panel will pass human judge.");
            }
        }
        private List<string> GetGrayShoreAreaCheckResult(List<string> knownDataList)
        {
            Dictionary<string, string> fileNameMap = new Dictionary<string, string>();
            Dictionary<string, string> grayAreaCheckResultMap = new Dictionary<string, string>();
            List<string> newknowndata = new List<string>();
            try
            {
                List<string> defectlist = new List<string>();
                defectlist.Add("NULL");

                foreach (List<string> item in pconfig.AreaCheckTable)
                {
                    if (item[1] == "True")
                    {
                        defectlist.Add(item[0]);
                    }
                }

                string gray_csv = sconfig.TargetPath + "\\" + sconfig.CsvFileName;
                using (var reader = new StreamReader(gray_csv))
                {
                    while (!reader.EndOfStream)
                    {
                        string[] values = reader.ReadLine().Split(',');
                        fileNameMap.Add(values[1], values[0]);
                    }

                    string[] subpathlist = sconfig.SubPath.Split('\\');
                    string subpath = subpathlist[2] + "\\" + subpathlist[3] + "\\" + subpathlist[4];
                    string mdcPath = sconfig.GrayShareFolder + "\\" + subpath + "\\MDC.txt";

                    using(var mdcreader = new StreamReader(mdcPath))
                    {
                        while (!mdcreader.EndOfStream)
                        {
                            string[] values = mdcreader.ReadLine().Split(',');
                            string[] path = values[0].Split('\\');
                            string grayfilename = path[path.Length-1];
                            grayAreaCheckResultMap.Add(grayfilename, values[2]);
                        }
                    }

                    foreach (string knowndata in knownDataList)
                    {
                        if (defectlist.Contains(knowndata.Split(',')[1]))
                        {
                            string colorpath = knowndata.Split(',')[0];
                            string[] colorpathlist = colorpath.Split('\\');
                            string defectfile = colorpathlist[colorpathlist.Length - 1];
                            string defectid = defectfile.Split('.')[0];
                            string grayfilename = fileNameMap[defectid];
                            string areacheckresult = grayAreaCheckResultMap[grayfilename];
                            newknowndata.Add(knowndata + "," + areacheckresult + ",,");
                        }
                        else
                        {
                            newknowndata.Add(knowndata + ",,,");
                        }
                    }
                }
            }
            catch (KeyNotFoundException)
            {
                info.Warning("DefectID and Grayfilename and Areacheck match fail." + sconfig.CsvFileName);
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
            return newknowndata;
        }

        private List<string> AddCamPath(List<string> mdcdata)
        {

            Dictionary<string, string> fileNameMap = new Dictionary<string, string>();
            List<string> newmdcdata = new List<string>();

            //read gray csv and use color defectID to find the cam.jpg
            if (sconfig.ColorMode == true)
            {
                string defectid = null;
                try
                {
                    string gray_csv = sconfig.TargetPath + "\\" + sconfig.CsvFileName;
                    using (var reader = new StreamReader(gray_csv))
                    {
                        while (!reader.EndOfStream)
                        {
                            string[] values = reader.ReadLine().Split(',');
                            fileNameMap.Add(values[1], values[0]);
                        }
                    }

                    foreach (string data in mdcdata)
                    {
                        string writeinfo = data;
                        string colorpath = data.Split(',')[0];
                        string[] colorpathlist = colorpath.Split('\\');
                        string defectfile = colorpathlist[colorpathlist.Length - 1];
                        defectid = defectfile.Split('.')[0];
                        string grayfilename = fileNameMap[defectid];
                        string[] subpathlist = sconfig.SubPath.Split('\\');
                        string subpath = subpathlist[2] + "\\" + subpathlist[3] + "\\" + subpathlist[4];
                        string cam_image = sconfig.GrayShareFolder + "\\" + subpath + "\\Ref\\" + grayfilename.Replace(".jpg", "_Ref.jpg");
                        string gray_image = sconfig.GrayShareFolder + "\\" + subpath + "\\" + grayfilename;

                        //retry 3 times to find cam file
                        int retryTimes = 3;
                        for (int i = 1; i <= retryTimes; i++)
                        {
                            if (File.Exists(cam_image))
                            {
                                writeinfo = writeinfo + "," + cam_image;
                                break;
                            }
                            else
                            {
                                info.Warning("-MDC write- Retry " + i + " times to find cam image.");
                                Thread.Sleep(500);
                            }
                            if (i == retryTimes)
                            {
                                info.Warning("-MDC write- Cam image not exist. " + cam_image);
                                writeinfo = writeinfo + ",";
                            }
                        }
                        //retry 3 times to find gray file
                        for (int i = 1; i <= retryTimes; i++)
                        {
                            if (File.Exists(gray_image))
                            {
                                writeinfo = writeinfo + "," + gray_image;
                                break;
                            }
                            else
                            {
                                info.Warning("-MDC write- Retry " + i + " times to find cam image.");
                                Thread.Sleep(500);
                            }
                            if (i == retryTimes)
                            {
                                info.Warning("-MDC write- Gray image not exist. " + gray_image);
                                writeinfo = writeinfo + ",";
                            }
                        }
                        newmdcdata.Add(writeinfo);
                    }
                }
                catch (KeyNotFoundException)
                {
                    info.Warning("Defect ID : " + defectid + "is not found in csv file : " + sconfig.CsvFileName);
                }
                catch (Exception ex)
                {
                    info.Error(ex.ToString());
                }
                return newmdcdata;
            }
            else
            {
                return mdcdata;
            }
        }
        private void Write_txt(List<string> list, string targetPath, string output_filename)
        {
            if (File.Exists(@targetPath + "\\" + output_filename))
            {
                File.Delete(@targetPath + "\\" + output_filename);
            }
            FileStream fileStream = new FileStream(@targetPath + "\\" + output_filename, FileMode.Create);
            fileStream.Close();
            StreamWriter txt = new StreamWriter(@targetPath + "\\" + output_filename);

            // write list file path to txt
            for (int num = 0; num <= list.Count - 1; num++)
            {
                txt.Write(list[num]);
                txt.Write("\r\n");
            }
            txt.Close();
        }
        private (List<string>, List<string>) Readcsv()
        {
            string ai_output_csv_path = sconfig.WorkPath + sconfig.WorkName + ".csv";
            using (var reader = new StreamReader(ai_output_csv_path))
            {
                List<string> unknown_list = new List<string>();
                List<string> known_list = new List<string>();

                string img_path = "";
                int num_line = 0;
                while (!reader.EndOfStream)
                {
                    var values = reader.ReadLine().Split(',');

                    //get image path from csv
                    if (num_line == 0)
                    {
                        img_path = values[1];
                    }

                    //get unknown image path and known image path from csv
                    if (num_line >= 3)
                    {

                        //AI 輸出 csv 倒數最後一個欄位為unknown
                        Dictionary<string, string> selectTransform;
                        if (pconfig.UseDetailModel == false)
                        {
                            selectTransform = AI_Transform;
                        }
                        else
                        {
                            selectTransform = AI_Detail_Transform;
                        }
                        //.ini 最後一欄為unknown
                        if (values[2] == (selectTransform.Count - 1).ToString())
                        {
                            string[] paths = { @img_path, values[0] };

                            string fullPath = Path.Combine(paths);
                            if(sconfig.ColorMode == false)
                            {
                                unknown_list.Add(fullPath + ",NULL");
                            }
                            else
                            {
                                unknown_list.Add(fullPath + ",NULL,");
                            }
                        }
                        //AI 輸出 csv 倒數最後一個欄位有結果，known根據label轉換
                        else
                        {
                            string[] paths = { @img_path, values[0] };
                            string fullPath = Path.Combine(paths);
                            known_list.Add(fullPath + "," + selectTransform[values[2]]);
                        }
                    }
                    num_line = num_line + 1;
                }
                return (unknown_list, known_list);
            }
        }
        private (List<string>, List<string>) MergeResult()
        {
            List<string> write_result = new List<string>();
            List<string> ai_predict = new List<string>();
            try
            {
                //set known.txt
                string[] knownpath = { sconfig.TargetPath, "known.txt" };
                string knownfullPath = Path.Combine(knownpath);

                //set MDC.txt
                string[] mdcpath = { sconfig.TargetPath, "MDC.txt" };
                string mdcfullPath = Path.Combine(mdcpath);

                //merge result and tranfer to defect code
                string[,] result;
                string[] mdclines = { };
                string[] knownlines = { };

                //transfer known data
                if (File.Exists(knownfullPath))
                {
                    info.General("Transfer known data.");
                    foreach (string line in File.ReadLines(knownfullPath))
                    {
                        string datapath = line.Split(',')[0];
                        //以最後一欄為結果寫入
                        string write_class;
                        if (line.Split(',')[2] == "") //area check result
                        {
                            write_class = line.Split(',')[1];
                        }
                        else
                        {
                            write_class = line.Split(',')[2];
                        }
                        knownlines = knownlines.Append(datapath + ',' + write_class).ToArray();
                    }
                }
                else info.General("Known image data not found.");

                //transfer MDC data
                if (File.Exists(mdcfullPath))
                {
                    info.General("Transfer MDC data.");
                    string temp1 = "";
                    string temp2 = "";
                    foreach (string line in File.ReadLines(mdcfullPath))
                    {
                        string[] mdcdata = line.Split(',');
                        //mdcdata format -> color image, human judge result, AI result, cam image, gray image
                        if (mdcdata.Count() != 5)
                        {
                            info.Warning("MDC.txt format error !");
                            info.Warning(line);
                            continue;
                        }
                        if(mdcdata[2] == "")
                        {
                            temp1 = mdcdata[0] + "," + mdcdata[1];
                            mdclines = mdclines.Append(temp1).ToArray();
                        }
                        else
                        {
                            temp2 = mdcdata[0] + "," + mdcdata[1] + "," + mdcdata[2];
                            ai_predict.Add(temp2);
                        }
                    }
                }
                else
                {
                    info.Warning("MDC image data not found.");
                }

                result = Create_DefectCode_Result(knownlines.Concat(mdclines).ToArray());
                info.General("Merge result finish.");

                //read .csv file
                string[] csvpath = { sconfig.TargetPath, sconfig.CsvFileName };
                string csvfullPath = Path.Combine(csvpath);
                string[] csvlines = File.ReadAllLines(csvfullPath);

                //prepare csv data
                if (sconfig.ColorMode == false)
                    write_result.Add(csvlines[0] + ",AIscore,AIdefectcode");
                else
                    write_result.Add(csvlines[0]);

                for (int i = 1; i < csvlines.Length; i++)
                {
                    string[] csvdata = csvlines[i].Split(',');
                    string imagename;
                    string defectcode;
                    string AOI_code = csvdata[2];

                    //從csv找檔名，灰階為第一欄，彩圖為第二欄
                    if (sconfig.ColorMode == false)
                        imagename = csvdata[0];
                    else
                        imagename = csvdata[1];

                    //LINQ 根據檔名找對應 AI defect code
                    if (sconfig.ColorMode == false)
                    {
                        defectcode = (from j in Enumerable.Range(0, result.GetLength(0))
                                      where (result[j, 0] == imagename)
                                      select result[j, 1])
                                        .FirstOrDefault();
                    }
                    else
                    {
                        defectcode = (from j in Enumerable.Range(0, result.GetLength(0))
                                      where (result[j, 0] == imagename + ".jpg" || result[j, 0] == imagename + ".JPG")
                                      select result[j, 1])
                                        .FirstOrDefault();
                    }

                    //寫入輸出csv
                    //灰階直接加在後兩欄，彩圖直接取代後兩欄
                    //Check Defect Code Table

                    foreach (DataRow r in pconfig.DefectRuleTable.Rows)
                    {
                        if (r["Type"].ToString() == "Retype" && defectcode != null)
                        {
                            if (AOI_code == r["AOI_Defect"].ToString())
                            {
                                //AOI結果 = 任何AI結果 -> 修改AI結果為NewResult
                                string airesult = r["AI_Result"].ToString();
                                if (airesult == "<<AnyResult>>")
                                {
                                    defectcode = r["NewResult"].ToString().ToUpper();
                                }
                                //AOI結果 = AI結果 -> 修改AI結果為NewResult
                                if ((r["Judge"].ToString() == "Equal") && (r["AI_Result"].ToString().ToUpper() == defectcode.ToUpper()))
                                {
                                    defectcode = r["NewResult"].ToString().ToUpper();
                                }
                                //AOI結果 != AI結果 -> 修改AI結果為NewResult
                                if ((r["Judge"].ToString() == "Unequal") && (r["AI_Result"].ToString().ToUpper() != defectcode.ToUpper()))
                                {
                                    defectcode = r["NewResult"].ToString().ToUpper();
                                }
                            }
                        }
                    }

                    //限彩圖 : defect為bypass或csv有但沒有圖則不寫入，保留灰階資料
                    if (pconfig.BypassStringList.Contains(csvdata[2]) || defectcode == null)
                    {
                        write_result.Add(csvlines[i]);
                    }
                    //若defect code 為 NONE 嚴重度填0.99
                    else if (defectcode.ToUpper() == "NONE" || defectcode.ToUpper() == "UNKNOWN" || defectcode == "")
                    {
                        if (sconfig.ColorMode == true)
                            //彩圖判unknown保持灰階結果也
                            write_result.Add(csvlines[i]);
                        else
                            //灰階判unknown填 ,0.99,NONE
                            write_result.Add(csvlines[i] + ",0.99,NONE");
                    }
                    else
                    {
                        //有結果並寫入
                        if (sconfig.ColorMode == true)
                            write_result.Add(csvlines[i].Replace(",0.99,NONE", ",0.01," + defectcode.ToUpper()));
                        else
                            write_result.Add(csvlines[i] + ",0.01," + defectcode.ToUpper());
                    }
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
            return (write_result, ai_predict);
        }
        private void WriteToCSV(List<string> lines)
        {
            try
            {
                if (lines == null)
                {
                    info.General("No image data.");
                }
                else
                {
                    //write to import folder
                    string import_write_path = sconfig.ImportPath + sconfig.SubPath;
                    if (!Directory.Exists(import_write_path)) Directory.CreateDirectory(import_write_path);
                    using (FileStream FS_test = new FileStream(import_write_path + "\\" + sconfig.CsvFileName, FileMode.Create))
                    {
                        using (var file = new StreamWriter(FS_test))
                        {
                            for (int i = 0; i < lines.Count; i++)
                            {
                                file.WriteLine(lines[i]);
                            }
                        }
                    }

                    //write to work folder
                    string work_write_path = sconfig.LocalWorkFolder + sconfig.SubPath + "\\" + sconfig.CsvFileName;
                    if (File.Exists(work_write_path)) File.Delete(work_write_path);
                    using (FileStream FS_test = new FileStream(work_write_path, FileMode.Create))
                    {
                        using (var file = new StreamWriter(FS_test))
                        {
                            for (int i = 0; i < lines.Count; i++)
                            {
                                file.WriteLine(lines[i]);
                            }
                        }
                    }

                    //write to share folder
                    if (sconfig.ColorMode == false)
                    {
                        string copy_path = ".\\share_folder";
                        if (!Directory.Exists(copy_path)) Directory.CreateDirectory(copy_path);
                        File.Copy(work_write_path, copy_path + "\\" + sconfig.CsvFileName, true);
                    }
                    info.General("Write to CSV finish.");
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private string[,] Create_DefectCode_Result(string[] lines)
        {
            string[,] Result = new string[lines.Length, 2];
            try
            {
                //建立二維array儲存結果
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] result = lines[i].Split(',');
                    //set filename
                    Result.SetValue(result[0].Replace(sconfig.TargetPath + "\\", ""), i, 0);
                    //AI result to defect code
                    bool hasDefectCode = false;
                    if (pconfig.UseDetailModel)
                    {
                        foreach(List<string> item1 in pconfig.DetailDefectCodeTable)
                        {
                            if(result[1].ToUpper() == item1[0].ToUpper())
                            {
                                Result.SetValue(item1[1], i, 1);
                                hasDefectCode = true;
                                break;
                            }
                            if(result[1].ToUpper() == "NULL" && item1[0].ToUpper() == "UNKNOWN")
                            {
                                Result.SetValue(item1[1], i, 1);
                                hasDefectCode = true;
                                break;
                            }
                        }
                    }
                    else
                    {
                        foreach (List<string> item2 in pconfig.DefectCodeTable)
                        {
                            if (item2[0].ToUpper() == result[1].ToUpper())
                            {
                                Result.SetValue(item2[1], i, 1);
                                hasDefectCode = true;
                                break;
                            }
                            if (result[1].ToUpper() == "NULL" && item2[0].ToUpper() == "UNKNOWN")
                            {
                                Result.SetValue(item2[1], i, 1);
                                hasDefectCode = true;
                                break;
                            }
                        }
                    }

                    if (hasDefectCode == false)
                    {
                        info.Error("<<" + result[1] + ">> This label doesn't define.");
                    }
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
            return Result;
        }
        private void Save_AI_Accuracy_Data(List<string> ai_predict)
        {
            try
            {
                //By天儲存資料
                string accfilename;
                string classfilename;
                bool areacheck = false;
                Dictionary<string, int> selectTransform = new Dictionary<string, int>();

                if (pconfig.UseDetailModel == false)
                {
                    accfilename = ".\\Accuracy_predict\\" + Path.GetFileNameWithoutExtension(pconfig.AiModelPath) + "\\"
                        + DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
                    classfilename = ".\\Accuracy_predict\\" + Path.GetFileNameWithoutExtension(pconfig.AiModelPath) + "\\"
                                         + "label.txt";

                    //修改統計功能(只要看到SHORT類自動分成可修不可修)
                    foreach (KeyValuePair<string, int> item in Label_Transform)
                    {
                        if (item.Key.ToUpper() == "UNKNOWN") continue;

                        if (item.Key == "SHORT")
                        {
                            areacheck = true;
                        }
                        else
                        {
                            selectTransform.Add(item.Key,item.Value);
                        }
                    }
                    if(areacheck == true)
                    {
                        int cls = selectTransform.Count();
                        selectTransform.Add("REPAIRABLE", cls);
                        selectTransform.Add("NONREPAIR", cls+1);
                    }
                }
                else
                {
                    accfilename = ".\\Accuracy_predict\\" + Path.GetFileNameWithoutExtension(pconfig.AiDetailModelPath) + "\\"
                        + DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
                    classfilename = ".\\Accuracy_predict\\" + Path.GetFileNameWithoutExtension(pconfig.AiDetailModelPath) + "\\"
                                         + "label.txt";

                    //修改統計功能(只要看到SHORT類自動分成可修不可修)
                    foreach (KeyValuePair<string, int> item in Label_Detail_Transform)
                    {
                        if (item.Key.ToUpper() == "UNKNOWN") continue;

                        if (item.Key == "SHORT")
                        {
                            areacheck = true;
                        }
                        else
                        {
                            selectTransform.Add(item.Key, item.Value);
                        }
                    }
                    if (areacheck == true)
                    {
                        int cls = selectTransform.Count();
                        selectTransform.Add("REPAIRABLE", cls);
                        selectTransform.Add("NONREPAIR", cls + 1);
                    }
                }

                // add repair and nonrepair / unknown no need to calculate
                int label_count = selectTransform.Count;
                string zeros = "";
                for (int i = 0; i < label_count * label_count; i++)
                {
                    if (zeros == "")
                        zeros = "0";
                    else
                        zeros += ",0";
                }
                string[] num = zeros.Split(',');

                //若當天檔案存在則新增array
                if (File.Exists(accfilename))
                {
                    num = File.ReadAllText(accfilename).Split(',');
                }

                foreach (string aipredictdata in ai_predict)
                {
                    string[] aipredictitem = aipredictdata.Split(',');
                    //if human have judge ai predict data
                    if (aipredictitem[1].ToUpper() != "NULL" && aipredictitem[1].ToUpper() != "UNKNOWN" 
                        && aipredictitem[0].ToUpper() != "NULL" && aipredictitem[0].ToUpper() != "UNKNOWN")
                    {
                        int col;
                        int row;
                        try
                        {
                            col = selectTransform[aipredictitem[2]];
                        }
                        catch (KeyNotFoundException)
                        {
                            info.Warning("Key: " + aipredictitem[2] + "not found in .ini label.");
                            continue;
                        }
                        try
                        {
                            row = selectTransform[aipredictitem[1]];
                        }
                        catch (KeyNotFoundException)
                        {
                            info.Warning("Key: " + aipredictitem[1] + "not found in .ini label.");
                            continue;
                        }
                        num[row * label_count + col] = (Convert.ToInt32(num[row * label_count + col]) + 1).ToString();
                    }
                }
                string save_result = string.Join(",", num);
                Directory.CreateDirectory(Path.GetDirectoryName(accfilename));
                using (StreamWriter writer = new StreamWriter(accfilename)) writer.Write(save_result);

                if (!File.Exists(classfilename))
                {
                    String s = "";
                    for (int i = 0; i < selectTransform.Count; i++)
                    {
                        if (s == "")
                            s = selectTransform.Keys.ElementAt(i);
                        else
                            s += "," + selectTransform.Keys.ElementAt(i);
                    }
                    using (StreamWriter writer = new StreamWriter(classfilename)) writer.WriteLine(s);
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private void Show_Ai_Accuracy(double day_range)
        {
            if (selectAiAccModel.SelectedItem == null)
                return;
            try
            {
                //By天儲存資料
                string accfilename = ".\\Accuracy_predict\\" + selectAiAccModel.SelectedItem.ToString() + "\\"
                                     + DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
                string classfilename = ".\\Accuracy_predict\\" + selectAiAccModel.SelectedItem.ToString() + "\\"
                                     + "label.txt";
                String[] classinfo = { };
                if (File.Exists(classfilename))
                {
                    classinfo = File.ReadLines(classfilename).First().Split(',');
                }

                // except unknown class
                int label_count = classinfo.Length;
                string[] string_daynum = new string[label_count * label_count];
                int[] int_daynum = new int[label_count * label_count];
                int[] all_daynum = new int[label_count * label_count];

                //若當天檔案不存在則新增array並儲存
                if (!File.Exists(accfilename))
                {
                    string zeros = "";
                    for (int i = 0; i < label_count * label_count; i++)
                    {
                        if (zeros == "")
                            zeros = "0";
                        else
                            zeros += ",0";
                    }
                    Directory.CreateDirectory(Path.GetDirectoryName(accfilename));
                    using (StreamWriter writer = new StreamWriter(accfilename)) writer.WriteLine(zeros);
                }
                DateTime startday = DateTime.Now.AddDays(day_range);

                //讀取range內資料
                DirectoryInfo dir = new DirectoryInfo(".\\Accuracy_predict\\" + selectAiAccModel.SelectedItem.ToString());
                char[] splititem = { '_', '.' };
                FileInfo[] accfiles = dir.GetFiles("*_*_*.txt");
                foreach (FileInfo accfile in accfiles)
                {
                    string[] yyyymmdd = accfile.Name.Split(splititem);
                    int year = Convert.ToInt16(yyyymmdd[0]);
                    int month = Convert.ToInt16(yyyymmdd[1]);
                    int day = Convert.ToInt16(yyyymmdd[2]);
                    DateTime filedate = new DateTime(year, month, day);
                    if (filedate > startday && filedate <= DateTime.Now)
                    {
                        string_daynum = File.ReadAllText(accfile.FullName).Split(',');
                        int_daynum = Array.ConvertAll(string_daynum, s => int.Parse(s));
                        for (int i = 0; i < label_count * label_count; i++)
                        {
                            all_daynum[i] = all_daynum[i] + int_daynum[i];
                        }
                    }
                }

                confusematrix.Clear();
                // Create three items and three sets of subitems for each item.
                // Create Column
                confusematrix.Columns.Add("Truth\\Predict", 120, HorizontalAlignment.Left);
                for (int i = 0; i < classinfo.Length; i++)
                    confusematrix.Columns.Add(classinfo[i], classinfo[i].Length*17, HorizontalAlignment.Left);

                for (int i = 0; i < label_count; i++)
                {
                    ListViewItem item_temp = new ListViewItem(classinfo[i]);
                    for (int j = 0; j < label_count; j++)
                    {
                        int idx = i * label_count + j;
                        item_temp.SubItems.Add(all_daynum[idx].ToString());
                    }
                    confusematrix.Items.Add(item_temp);
                }
                double[] total_count = new double[label_count];
                double[] true_count = new double[label_count];
                for (int i = 0; i < label_count; i++)
                {
                    for (int j = 0; j < label_count; j++)
                    {
                        int idx = label_count * i + j;
                        total_count[i] += all_daynum[idx];
                        if (i == j)
                            true_count[i] += all_daynum[idx];
                    }
                }

                //calculate image number
                double total_imgnum = 0;
                foreach (double d in total_count)
                    total_imgnum += d;

                double correct_imgnum = 0;
                foreach (double d in true_count)
                    correct_imgnum += d;

                //calculate accuracy
                //total
                if (total_imgnum != 0)
                {
                    double total_acc = Math.Round(correct_imgnum * 100 / total_imgnum, 2, MidpointRounding.AwayFromZero);
                    totalProgressBar.Value = Convert.ToInt32(total_acc);
                    totalpercent.Text = total_acc.ToString() + "%";
                }
                else
                {
                    totalProgressBar.Value = 0;
                    totalpercent.Text = " -- %";
                }

                //show UI
                MaterialProgressBar bar;
                MaterialLabel percent;
                this.AiAccFlowLayoutPanel.Controls.Clear();
                this.AiAccFlowLayoutPanel.AutoScroll = true;
                
                for (int i = 0; i < total_count.Length; i++)
                {
                    bar = new MaterialProgressBar();
                    bar.Depth = 0;
                    bar.ForeColor = System.Drawing.SystemColors.ControlDark;
                    bar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
                    bar.MouseState = MaterialSkin.MouseState.HOVER;
                    bar.Size = new System.Drawing.Size(180, 17);
                    bar.TabIndex = 4;

                    percent = new MaterialLabel();
                    percent.AutoSize = true;
                    percent.Depth = 0;
                    percent.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
                    percent.ImeMode = System.Windows.Forms.ImeMode.NoControl;
                    percent.MouseState = MaterialSkin.MouseState.HOVER;
                    percent.Size = new System.Drawing.Size(47, 17);
                    percent.TabIndex = 15;
                    Padding pad = new Padding(12);
                    percent.Margin = pad;

                    if (total_count[i] != 0)
                    {
                        double acc = Math.Round(true_count[i] * 100 / total_count[i], 2, MidpointRounding.AwayFromZero);
                        bar.Value = Convert.ToInt32(acc);
                        percent.Text = classinfo[i] + "    " + acc.ToString() + "%";
                    }
                    else
                    {
                        bar.Value = 0;
                        percent.Text = classinfo[i] + "     -- %";
                    }
                    this.AiAccFlowLayoutPanel.Controls.Add(percent);
                    this.AiAccFlowLayoutPanel.Controls.Add(bar);
                }

                //update modified time
                modifieddateLabel.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private void MoveToSaveFolder()
        {
            foreach (string workfile in Directory.GetFiles(sconfig.LocalWorkFolder + sconfig.SubPath, "*.*", SearchOption.AllDirectories))
            {
                try
                {
                    string[] pathlist = workfile.Split('\\');
                    string filename = pathlist[pathlist.Length - 1];
                    string targetPath = sconfig.LocalSaveFolder + sconfig.SubPath;
                    string targetPath_Ref = sconfig.LocalSaveFolder + sconfig.SubPath + "\\Ref";
                    if (!Directory.Exists(targetPath)) Directory.CreateDirectory(targetPath);
                    if (sconfig.ColorMode == false && !Directory.Exists(targetPath_Ref)) Directory.CreateDirectory(targetPath_Ref);

                    //CAM images
                    if (filename.EndsWith("_Ref.jpg"))
                    {
                        if (File.Exists(targetPath_Ref + "\\" + filename))
                        {
                            File.Delete(targetPath_Ref + "\\" + filename);
                        }

                        File.Move(workfile, targetPath_Ref + "\\" + filename);
                    }
                    //defect images
                    else if (filename.EndsWith(".jpg") || filename.EndsWith(".JPG") || filename.EndsWith(".bmp") || filename.EndsWith(".png"))
                    {
                        if (File.Exists(targetPath + "\\" + filename))
                        {
                            File.Delete(targetPath + "\\" + filename);
                        }

                        File.Move(workfile, targetPath + "\\" + filename);
                    }

                    //MDC.txt and known.txt
                    if (filename.EndsWith(".txt"))
                    {
                        if (File.Exists(targetPath + "\\" + filename))
                        {
                            string[] lines = File.ReadAllLines(workfile);
                            File.AppendAllLines(targetPath + "\\" + filename, lines);
                            File.Delete(workfile);
                        }
                        else
                        {
                            File.Move(workfile, targetPath + "\\" + filename);
                        }
                    }
                    //csv file
                    if (filename.EndsWith(".csv"))
                    {
                        if (File.Exists(targetPath + "\\" + filename))
                        {
                            File.Delete(targetPath + "\\" + filename);
                        }
                        File.Move(workfile, targetPath + "\\" + filename);
                    }
                }
                catch
                {
                    info.Warning("Cannot move file from work path to save path. " + workfile);
                }
            }
        }
        private void rejudgeSwitch_CheckedChanged(object sender, EventArgs e)
        {
            if (rejudge_Switch.Checked == false)
            {
                this.Rejudge_NG.Visible = false;
                this.Rejudge_OK.Visible = false;
                this.accuracySlider.Enabled = false;
            }
            else
            {
                this.accuracySlider.Enabled = true;
            }
        }
        private void productRecipeSelectedIndexChanged(object sender, EventArgs e)
        {
            this.stopButton.Enabled = false;
            this.AI_NG.Visible = false;
            this.AI_OK.Visible = false;
            pconfig = pconfig.ReadXML(".\\Recipe\\product\\" + this.materialComboBox1.Text + ".xml");
        }
        private void systemRecipeSelectedIndexChanged(object sender, EventArgs e)
        {
            this.stopButton.Enabled = false;
            this.Recipe_NG.Visible = false;
            this.Recipe_OK.Visible = false;
            this.Rejudge_NG.Visible = false;
            this.Rejudge_OK.Visible = false;
            this.foldersetting_NG.Visible = false;
            this.foldersetting_OK.Visible = false;
            sconfig = sconfig.ReadXML(".\\Recipe\\system\\" + this.materialComboBox3.Text + ".xml");
        }
        private void exportFolderShortCutClick(object sender, EventArgs e)
        {
            if (sconfig.ExportFolderList.Count == 0)
            {
                MessageBox.Show("Database export path not exist, please set again!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            foreach (MaterialListBoxItem item in sconfig.ExportFolderList)
            {
                string path = item.Text;
                if (Directory.Exists(path))
                {
                    info.General("Press export folder button.");
                    System.Diagnostics.Process prc = new System.Diagnostics.Process();
                    prc.StartInfo.FileName = path;
                    prc.Start();
                }
                else
                {
                    info.Warning("Press export button not exist.");
                    MessageBox.Show("Database export path not exist, please set again!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        private void importFolderShortCutClick(object sender, EventArgs e)
        {
            string path = sconfig.ImportPath;

            if (Directory.Exists(path))
            {
                info.General("Press import folder button.");
                System.Diagnostics.Process prc = new System.Diagnostics.Process();
                prc.StartInfo.FileName = path;
                prc.Start();
            }
            else
            {
                info.Warning("Press import buttom not exist.");
                MessageBox.Show("Database import path not exist, please set again!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void imageSaveShortCutClick(object sender, EventArgs e)
        {
            string path = sconfig.LocalSaveFolder;

            if (Directory.Exists(path))
            {
                info.General("Press images history button.");
                System.Diagnostics.Process prc = new System.Diagnostics.Process();
                prc.StartInfo.FileName = path;
                prc.Start();
            }
            else
            {
                info.Warning("Press images history button not exist.");
                MessageBox.Show("Images history path not exist, please set again!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void logShortCutClick(object sender, EventArgs e)
        {
            string path = ".\\log";
            if (Directory.Exists(path))
            {
                System.Diagnostics.Process prc = new System.Diagnostics.Process();
                prc.StartInfo.FileName = path;
                prc.Start();
            }
            else
            {
                info.Warning("Press log files button not exist.");
                MessageBox.Show("Log files path not exist!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void AiShortCutClick(object sender, EventArgs e)
        {
            string path = sconfig.WorkPath;
            if (Directory.Exists(path))
            {
                System.Diagnostics.Process prc = new System.Diagnostics.Process();
                prc.StartInfo.FileName = path;
                prc.Start();
            }
            else
            {
                info.Warning("Press ai button not exist.");
                MessageBox.Show("AI work path not exist, please set again!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void recipeShortCutClick(object sender, EventArgs e)
        {
            string path = ".\\Recipe";
            if (Directory.Exists(path))
            {
                System.Diagnostics.Process prc = new System.Diagnostics.Process();
                prc.StartInfo.FileName = path;
                prc.Start();
            }
            else
            {
                info.Warning("Press recipe button not exist.");
                MessageBox.Show("Recipe path not exist, please set again!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void productSettingSelectedIndexChanged(object sender, EventArgs e)
        {
            string xmlpath = ".\\Recipe\\product\\" + materialComboBox2.Text + ".xml";

            if (File.Exists(xmlpath)) pconfig = pconfig.ReadXML(xmlpath);
            else
            {
                info.Error("Product recipe << " + xmlpath + " >> not exist");
                return;
            }

            //show defectcode textbox
            MaterialTextBox2 box1;
            this.defectCodeFlowLayoutPanel.Controls.Clear();
            this.defectCodeFlowLayoutPanel.AutoScroll = true;

            for (int i = 0; i < pconfig.DefectCodeTable.Count(); i++)
            {
                if (pconfig.DefectCodeTable[i][0].ToUpper() == "REPAIRABLE")
                {
                    repairableTextBox.Text = pconfig.DefectCodeTable[0][1];
                    continue;
                }
                if (pconfig.DefectCodeTable[i][0].ToUpper() == "NONREPAIR")
                {
                    nonrepairTextBox.Text = pconfig.DefectCodeTable[1][1];
                    continue; 
                }
                box1 = new MaterialTextBox2();
                box1.Hint = pconfig.DefectCodeTable[i][0];
                box1.Text = pconfig.DefectCodeTable[i][1];
                this.defectCodeFlowLayoutPanel.Controls.Add(box1);
            }

            //show areacheck ckeckbox
            MaterialCheckbox checkbox1;
            this.AreaCheckedflowLayoutPanel.Controls.Clear();
            this.AreaCheckedflowLayoutPanel.AutoScroll = true;
            foreach (List<string> item in pconfig.AreaCheckTable)
            {
                checkbox1 = new MaterialCheckbox();
                checkbox1.Text = item[0];
                checkbox1.Width = 180;
                if (item[1] == "True")
                {
                    checkbox1.Checked = true;
                }
                else
                {
                    checkbox1.Checked = false;
                }
                this.AreaCheckedflowLayoutPanel.Controls.Add(checkbox1);
            }

            if (sconfig.ColorMode == true) //color mode
            {
                //AI yield model
                aiYieldModelTextBox.Text = pconfig.AiDetailModelPath;

                //detail defect code
                MaterialTextBox2 box2;
                this.detailDefectCodeFlowLayoutPanel.Controls.Clear();
                this.detailDefectCodeFlowLayoutPanel.AutoScroll = true;
                foreach (List<string> item in pconfig.DetailDefectCodeTable)
                {
                    box2 = new MaterialTextBox2();
                    box2.Hint = item[0];
                    box2.Text = item[1];
                    this.detailDefectCodeFlowLayoutPanel.Controls.Add(box2);
                }
            }

            //other
            productnameTextBox.Text = pconfig.ProductName;
            aimodelTextBox.Text = pconfig.AiModelPath;
            unknownTHTextBox.Text = pconfig.AiUnknownThreshold.ToString();
            mindefectareaTextBox.Text = pconfig.DefectSize.ToString();
            regionsizeTextBox.Text = pconfig.RegionSize.ToString();

            GV_DefectTable.Rows.Clear();
            foreach (DataRow r in pconfig.DefectRuleTable.Rows)
            {
                var index = GV_DefectTable.Rows.Add();
                GV_DefectTable.Rows[index].Cells["Type"].Value = r["Type"].ToString();
                GV_DefectTable.Rows[index].Cells["Judge"].Value = r["Judge"].ToString();
                GV_DefectTable.Rows[index].Cells["AOI_Defect"].Value = r["AOI_Defect"].ToString();
                GV_DefectTable.Rows[index].Cells["AI_Result"].Value = r["AI_Result"].ToString();
                GV_DefectTable.Rows[index].Cells["NewResult"].Value = r["NewResult"].ToString();
            }
            //Add GV_DefectTable AI_Result combobox items
            DataGridViewComboBoxColumn dgvcCollection = (DataGridViewComboBoxColumn)GV_DefectTable.Columns["AI_Result"];
            foreach (string label in pconfig.AiLabelString.Split(','))
            {
                if (dgvcCollection.Items.Contains(label) == false)
                {
                    dgvcCollection.Items.Add(label);
                }
            }
        }
        private void systemSettingSelectedIndexChanged(object sender, EventArgs e)
        {
            string xmlpath = ".\\Recipe\\system\\" + materialComboBox4.Text + ".xml";
            if (File.Exists(xmlpath)) sconfig = sconfig.ReadXML(xmlpath);
            else
            {
                info.Error("System recipe << " + xmlpath + " >> not exist");
                return;
            }
            systemNameTextBox.Text = sconfig.SystemName;
            monitorFreqTextBox.Text = sconfig.MonitorFrequency;
            delayAfterMonitorTextBox.Text = sconfig.DelayAfterMonitor;
            importFolderTextBox.Text = sconfig.ImportPath;
            backupTextBox.Text = sconfig.BackupFolder;
            imageSaveFolderTextBox.Text = sconfig.LocalSaveFolder;
            workFolderTextBox.Text = sconfig.LocalWorkFolder;
            grayShareFolderTextBox.Text = sconfig.GrayShareFolder;
            rejudgeTimeOutTextBox.Text = sconfig.RejudgeCenterTimeout;
            ipTextBox.Text = sconfig.RejudgeCenterIp;
            portTextBox.Text = sconfig.RejudgeCenterPort;
            exportFolderList.Clear();
            foreach (MaterialListBoxItem item in sconfig.ExportFolderList)
            {
                exportFolderList.AddItem(item);
            }
        }
        private void selectAiModelButtonClick(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false;
            dialog.Title = "Please Select AI model File.";
            dialog.Filter = "AI model file|*.onnx";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.aimodelTextBox.Text = dialog.FileName;
                check_defect_table(aimodelTextBox.Text);
                CreateDefectCodePanel(aimodelTextBox.Text, this.defectCodeFlowLayoutPanel);
                CreateAreaCheckDefectPanel(aimodelTextBox.Text, this.AreaCheckedflowLayoutPanel);
                CreateGridViewAIResult(aimodelTextBox.Text, this.GV_DefectTable);
            }
        }
        private void selectYieldAiModelButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false;
            dialog.Title = "Please Select AI model File.";
            dialog.Filter = "AI model file|*.onnx";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.aiYieldModelTextBox.Text = dialog.FileName;
                check_defect_table(aiYieldModelTextBox.Text);
                CreateDefectCodePanel(aiYieldModelTextBox.Text, this.detailDefectCodeFlowLayoutPanel);
                CreateGridViewAIResult(aiYieldModelTextBox.Text, this.GV_DefectTable);
            }
        }
        private void CreateDefectCodePanel(string modelPath, FlowLayoutPanel panel)
        {
            panel.Controls.Clear();
            panel.AutoScroll = true;
            string inifile = modelPath.Replace(".onnx", ".ini");
            if (File.Exists(inifile) == false)
            {
                MessageBox.Show(inifile + " not found error.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            StreamReader sr = new StreamReader(inifile);
            MaterialTextBox2 temp;
            while (sr.Peek() >= 0)
            {
                string ini_line = sr.ReadLine();
                if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                {
                    continue;
                }
                string[] Label_Names = ini_line.Split('=');
                if (Label_Names[1].ToUpper() == "REPAIRABLE") continue;
                if (Label_Names[1].ToUpper() == "NONREPAIR") continue;
                temp = new MaterialTextBox2();
                temp.Width = 168;
                temp.Hint = Label_Names[1];
                if (Label_Names[1].ToUpper() == "UNKNOWN")
                {
                    temp.Text = "NONE";
                }
                else
                {
                    temp.Text = Label_Names[1];
                } 
                panel.Controls.Add(temp);
            }
        }
        private void CreateAreaCheckDefectPanel(string modelPath, FlowLayoutPanel panel)
        {
            panel.Controls.Clear();
            panel.AutoScroll = true;
            string inifile = modelPath.Replace(".onnx", ".ini");
            if (File.Exists(inifile) == false)
            {
                MessageBox.Show(inifile + " not found error.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            StreamReader sr = new StreamReader(inifile);
            MaterialCheckbox checkbox;
            while (sr.Peek() >= 0)
            {
                string ini_line = sr.ReadLine();
                if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                {
                    continue;
                }
                string[] Label_Names = ini_line.Split('=');
                checkbox = new MaterialCheckbox();
                checkbox.Text = Label_Names[1];
                if (Label_Names[1].ToUpper() == "SHORT" || Label_Names[1].ToUpper() == "REPAIRABLE" || 
                    Label_Names[1].ToUpper() == "NONREPAIR")
                {
                    checkbox.Checked = true;
                }
                else checkbox.Checked = false;
                checkbox.Width = 160;
                checkbox.Enabled = false;
                panel.Controls.Add(checkbox);
            }
        }
        private void CreateGridViewAIResult(string modelPath, DataGridView gridView)
        {
            string inifile = modelPath.Replace(".onnx", ".ini");
            if (File.Exists(inifile) == false)
            {
                MessageBox.Show(inifile + " not found error.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewComboBoxColumn dgvcCollection  = (DataGridViewComboBoxColumn)gridView.Columns["AI_Result"];
            StreamReader sr = new StreamReader(inifile);

            while (sr.Peek() >= 0)
            {
                string ini_line = sr.ReadLine();
                if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                {
                    continue;
                }
                string[] Label_Names = ini_line.Split('=');
                if (dgvcCollection.Items.Contains(Label_Names[1]) == false)
                {
                    dgvcCollection.Items.Add(Label_Names[1]);
                }
            }
        }
        private void selectExportButtonClick(object sender, EventArgs e)
        {
            if (exportFolderList.Count == 2)
            {
                MessageBox.Show("The number of export folder cannot be more than 2 !", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Export Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning");
                    return;
                }
                else
                {
                    char[] remove = { '\\' };
                    MaterialListBoxItem item = new MaterialListBoxItem();
                    item.Text = dialog.SelectedPath.TrimEnd(remove);
                    exportFolderList.Items.Insert(0, item);
                }
            }
        }
        private void selectImportButtonClick(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Import Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    this.importFolderTextBox.Text = dialog.SelectedPath;
                }
            }
        }
        private void selectShareFolderButtonClick(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Share Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    this.imageSaveFolderTextBox.Text = dialog.SelectedPath;
                }
            }
        }
        private void autoGetWorkFolder(object sender, EventArgs e)
        {
            //auto get work folder
            string workfolder = Application.StartupPath + "\\Work_folder";
            if (Directory.Exists(workfolder) && this.imageSaveFolderTextBox.Text.StartsWith("\\\\"))
            {
                string[] savefolderlist = this.imageSaveFolderTextBox.Text.Split('\\');
                string shareWorkFolder = workfolder.Replace("D:", "\\\\" + savefolderlist[2]);
                this.workFolderTextBox.Text = shareWorkFolder;
            }
        }
        private void selectWorkFolderButton_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Work Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    this.workFolderTextBox.Text = dialog.SelectedPath;
                }
            }
        }
        private void selectBackupButtonClick(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Backup Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    this.backupTextBox.Text = dialog.SelectedPath;
                }
            }
        }
        private void selectCsvFolderButtonClick(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select csv Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    this.grayShareFolderTextBox.Text = dialog.SelectedPath;
                }
            }
        }
        private void productSettingSaveClick(object sender, EventArgs e)
        {
            try
            {
                if (productnameTextBox.Text == "")
                {
                    MessageBox.Show("Product name can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (repairableTextBox.Text == "")
                {
                    MessageBox.Show("Repairable defect code can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (nonrepairTextBox.Text == "")
                {
                    MessageBox.Show("NonrepairTextBox defect code can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (aimodelTextBox.Text == "")
                {
                    MessageBox.Show("AI model can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    string inifile = aimodelTextBox.Text.Replace(".onnx", ".ini");
                    if (File.Exists(inifile) == false)
                    {
                        MessageBox.Show(inifile + " not found error.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    string tempData = "";
                    StreamReader SR1 = new StreamReader(inifile);
                    while (SR1.Peek() >= 0)
                    {
                        string ini_line = SR1.ReadLine();
                        if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                        {
                            continue;
                        }
                        string[] Label_Names = ini_line.Split('=');

                        if (tempData == "")
                        {
                            tempData = tempData + Label_Names[1];
                        }
                        else
                        {
                            tempData = tempData + "," + Label_Names[1];
                        }
                    }
                    pconfig.AiLabelString = tempData;
                    SR1.Close();
                }

                //save defect code
                List<List<string>> codetable = new List<List<string>>();
                //Add repairable defect code
                List<string> temp1 = new List<string>();
                temp1.Add(this.repairableTextBox.Hint);
                temp1.Add(this.repairableTextBox.Text);
                codetable.Add(temp1);
                //Add nonrepair defect code
                List<string> temp2 = new List<string>();
                temp2.Add(this.nonrepairTextBox.Hint);
                temp2.Add(this.nonrepairTextBox.Text);
                codetable.Add(temp2);

                foreach (MaterialTextBox2 box1 in defectCodeFlowLayoutPanel.Controls)
                {
                    if (box1.Text == "")
                    {
                        MessageBox.Show(box1.Hint + " Defect code can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    List<string> temp3 = new List<string>();
                    temp3.Add(box1.Hint);
                    temp3.Add(box1.Text);
                    codetable.Add(temp3);
                }
                pconfig.DefectCodeTable = codetable;

                //save area check defect
                pconfig.AreaCheckTable = new List<List<string>>();
                foreach(MaterialCheckbox checkbox1 in AreaCheckedflowLayoutPanel.Controls)
                {
                    List<string> temp4 = new List<string>();
                    temp4.Add(checkbox1.Text);
                    temp4.Add(checkbox1.Checked.ToString());
                    pconfig.AreaCheckTable.Add(temp4);
                }

                if (sconfig.ColorMode == true) //color mode
                {
                    if (aiYieldModelTextBox.Text == "")
                    {
                        MessageBox.Show("AI yield model can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    else
                    {
                        string inifile = aiYieldModelTextBox.Text.Replace(".onnx", ".ini");
                        if (File.Exists(inifile) == false)
                        {
                            MessageBox.Show(inifile + " not found error.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        string tempData = "";
                        StreamReader SR2 = new StreamReader(inifile);
                        while (SR2.Peek() >= 0)
                        {
                            string ini_line = SR2.ReadLine();
                            if (ini_line == "[CLASSES]" || ini_line == "[POSTPROCESSING]")
                            {
                                continue;
                            }
                            string[] Label_Names = ini_line.Split('=');

                            if (tempData == "")
                            {
                                tempData = tempData + Label_Names[1];
                            }
                            else
                            {
                                tempData = tempData + "," + Label_Names[1];
                            }
                        }
                        pconfig.AiDetailLabelString = tempData;
                        SR2.Close();
                    }

                    //save detail defect code
                    List<List<string>> detailcodetable = new List<List<string>>();
                    foreach (MaterialTextBox2 box2 in detailDefectCodeFlowLayoutPanel.Controls)
                    {
                        if (box2.Text == "")
                        {
                            MessageBox.Show(box2.Hint + "Defect code can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        List<string> temp5 = new List<string>();
                        temp5.Add(box2.Hint);
                        temp5.Add(box2.Text);
                        detailcodetable.Add(temp5);
                    }
                    pconfig.DetailDefectCodeTable = detailcodetable;
                }

                else //gray mode
                {
                    if (regionsizeTextBox.Text == "" || mindefectareaTextBox.Text == "")
                    {
                        MessageBox.Show("Area check Setting can't be Null!", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    try
                    {
                        pconfig.RegionSize = Convert.ToInt32(this.regionsizeTextBox.Text);
                    }
                    catch (FormatException)
                    {
                        MessageBox.Show("Region Size can only be number !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    try
                    {
                        pconfig.DefectSize = Convert.ToInt32(this.mindefectareaTextBox.Text);
                    }
                    catch (FormatException)
                    {
                        MessageBox.Show("Defect Size can only be number !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                DataTable dt = new DataTable("RuleTable");
                dt.Columns.Add("Type", typeof(String));
                dt.Columns.Add("Judge", typeof(String));
                dt.Columns.Add("AOI_Defect", typeof(String));
                dt.Columns.Add("AI_Result", typeof(String));
                dt.Columns.Add("NewResult", typeof(String));

                for (int i = 0; i < GV_DefectTable.Rows.Count; i++)
                {
                    //MessageBox.Show(GV_DefectTable.Rows[i].name)
                    String Type = "";
                    String Judge = "";
                    String AOI_Defect = "";
                    String AI_Result = "";
                    String NewResult = "";

                    if (GV_DefectTable.Rows[i].Cells["Type"].Value != null)
                        Type = GV_DefectTable.Rows[i].Cells["Type"].Value.ToString();
                    if (GV_DefectTable.Rows[i].Cells["Judge"].Value != null)
                        Judge = GV_DefectTable.Rows[i].Cells["Judge"].Value.ToString();
                    if (GV_DefectTable.Rows[i].Cells["AOI_Defect"].Value != null)
                        AOI_Defect = GV_DefectTable.Rows[i].Cells["AOI_Defect"].Value.ToString();
                    if (GV_DefectTable.Rows[i].Cells["AI_Result"].Value != null)
                        AI_Result = GV_DefectTable.Rows[i].Cells["AI_Result"].Value.ToString();
                    if (GV_DefectTable.Rows[i].Cells["NewResult"].Value != null)
                        NewResult = GV_DefectTable.Rows[i].Cells["NewResult"].Value.ToString();

                    if ((Type == "") && (Judge == "") && (AOI_Defect == "") && (AI_Result == "") && (NewResult == ""))
                    {
                        continue;
                    }

                    String error = "";
                    if (Type == "")
                    {
                        error += "Type can't be null!\n";
                    }
                    else if (Type == "Retype")
                    {
                        if (Judge == "")
                        {
                            error += "[Retype] Judge can't be null!\n";
                        }
                        if (AOI_Defect == "")
                        {
                            error += "[Retype] AOI_Defect can't be null!\n";
                        }
                        if (AI_Result == "")
                        {
                            error += "[Retype] AI_Result can't be null!\n";
                        }
                        if (NewResult == "")
                        {
                            error += "[Retype] NewResult can't be null!\n";
                        }
                    }
                    else
                    {
                        if (AOI_Defect == "")
                        {
                            error += "[Bypass] AOI_Defect can't be null!\n";
                        }
                    }
                    if (error != "")
                    {
                        MessageBox.Show(error, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    else
                    {
                        DataRow r = dt.NewRow();
                        r["Type"] = Type;
                        r["Judge"] = Judge;
                        r["AOI_Defect"] = AOI_Defect;
                        r["AI_Result"] = AI_Result;
                        r["NewResult"] = NewResult;
                        dt.Rows.Add(r);
                    }
                }

                pconfig.ProductName = this.productnameTextBox.Text;
                pconfig.AiModelPath = this.aimodelTextBox.Text;

                if (sconfig.ColorMode == true) //color mode
                {
                    pconfig.AiDetailModelPath = this.aiYieldModelTextBox.Text;
                }

                pconfig.DefectRuleTable = dt;
                try
                {
                    pconfig.AiUnknownThreshold = double.Parse(this.unknownTHTextBox.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("AI Unknown Threshold can only be number !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (double.Parse(this.unknownTHTextBox.Text) > 100 || double.Parse(this.unknownTHTextBox.Text) < 0)
                {
                    MessageBox.Show("AI Unknown Threshold should between 0 and 100 !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pconfig.CreateXML(pconfig, ".\\Recipe\\product\\" + pconfig.ProductName + ".xml");
                DirectoryInfo dir = new DirectoryInfo(".\\Recipe\\product\\");
                FileInfo[] productlist = dir.GetFiles();
                this.materialComboBox1.Items.Clear();
                this.materialComboBox2.Items.Clear();
                foreach (var product in productlist)
                {
                    this.materialComboBox1.Items.Add(product.ToString().Replace(".xml", ""));
                    this.materialComboBox2.Items.Add(product.ToString().Replace(".xml", ""));
                }
                info.General("Save <<" + pconfig.ProductName + ">> config.");
                MessageBox.Show(pconfig.ProductName + " recipe has been saved successfully!", "Successful",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private void systemSettingSaveClick(object sender, EventArgs e)
        {
            try
            {
                if (sconfig.ColorMode == true)
                {
                    if (grayShareFolderTextBox.Text == "")
                    {
                        MessageBox.Show("CSV folder can't be Null!", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (grayShareFolderTextBox.Text.StartsWith("\\") == false)
                    {
                        MessageBox.Show("Gray Share folder should be a share format!", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                if (systemNameTextBox.Text == "" || importFolderTextBox.Text == "" ||
                    imageSaveFolderTextBox.Text == "" || workFolderTextBox.Text == "" ||
                    exportFolderList.Count == 0 ||
                    monitorFreqTextBox.Text == "" || ipTextBox.Text == "" ||
                    portTextBox.Text == "" || rejudgeTimeOutTextBox.Text == "")
                {
                    MessageBox.Show("Setting can't be Null!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (imageSaveFolderTextBox.Text.StartsWith("\\\\") == false)
                {
                    MessageBox.Show("Image save folder should be a share format!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (workFolderTextBox.Text.StartsWith("\\\\") == false)
                {
                    MessageBox.Show("Work folder should be a share format!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (int.TryParse(this.monitorFreqTextBox.Text, out _) == false)
                {
                    MessageBox.Show("Monitor Frequency must be a number!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (int.TryParse(this.delayAfterMonitorTextBox.Text, out _) == false)
                {
                    MessageBox.Show("Delay after monitor must be a number!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (int.TryParse(this.rejudgeTimeOutTextBox.Text, out _) == false)
                {
                    MessageBox.Show("Rejudge Timeout must be a number!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (int.TryParse(this.portTextBox.Text, out _) == false)
                {
                    MessageBox.Show("Port must be a number!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (int.TryParse(this.ipTextBox.Text.Replace(".", ""), out _) == false)
                {
                    MessageBox.Show("IP format error!", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                //remove path end "\\"
                char[] remove = { '\\' };
                this.importFolderTextBox.Text = this.importFolderTextBox.Text.TrimEnd(remove);
                this.imageSaveFolderTextBox.Text = this.imageSaveFolderTextBox.Text.TrimEnd(remove);
                this.workFolderTextBox.Text = this.workFolderTextBox.Text.TrimEnd(remove);
                this.backupTextBox.Text = this.backupTextBox.Text.TrimEnd(remove);
                this.grayShareFolderTextBox.Text = this.grayShareFolderTextBox.Text.TrimEnd(remove);

                if (sconfig.ColorMode == true)
                {
                    sconfig.GrayShareFolder = this.grayShareFolderTextBox.Text;
                }
                else
                {
                    sconfig.GrayShareFolder = Application.StartupPath + "\\Share_folder";
                }

                sconfig.SystemName = this.systemNameTextBox.Text;
                sconfig.ImportPath = this.importFolderTextBox.Text;
                sconfig.ExportFolderList = this.exportFolderList.Items;
                sconfig.LocalSaveFolder = this.imageSaveFolderTextBox.Text;
                sconfig.LocalWorkFolder = this.workFolderTextBox.Text;
                sconfig.BackupFolder = this.backupTextBox.Text;
                sconfig.MonitorFrequency = this.monitorFreqTextBox.Text;
                sconfig.DelayAfterMonitor = this.delayAfterMonitorTextBox.Text;
                sconfig.RejudgeCenterIp = this.ipTextBox.Text;
                sconfig.RejudgeCenterPort = this.portTextBox.Text;
                sconfig.RejudgeCenterTimeout = this.rejudgeTimeOutTextBox.Text;
                sconfig.WorkPath = Application.StartupPath + "\\py\\";

                sconfig.CreateXML(sconfig, ".\\Recipe\\system\\" + sconfig.SystemName + ".xml");
                DirectoryInfo dir = new DirectoryInfo(".\\Recipe\\system");
                FileInfo[] systemlist = dir.GetFiles();
                this.materialComboBox3.Items.Clear();
                this.materialComboBox4.Items.Clear();
                foreach (var system in systemlist)
                {
                    this.materialComboBox3.Items.Add(system.ToString().Replace(".xml", ""));
                    this.materialComboBox4.Items.Add(system.ToString().Replace(".xml", ""));
                }
                info.General("Save <<" + sconfig.SystemName + ">> config.");
                MessageBox.Show(sconfig.SystemName + " recipe has been saved successfully!", "Successful",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private void pictureBox14_Click(object sender, EventArgs e)
        {
            new License().ShowDialog();
        }
        private void auolicense_Click(object sender, EventArgs e)
        {
            new Auolicense().ShowDialog();
        }
        private void exportadd_Click(object sender, EventArgs e)
        {
            if (exportFolderList.Count == 2)
            {
                MessageBox.Show("The number of export folder cannot be more than 2 !", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!String.IsNullOrWhiteSpace(exportTextBox.Text))
            {
                char[] remove = { '\\' };
                this.exportTextBox.Text = this.exportTextBox.Text.TrimEnd(remove);

                MaterialListBoxItem item = new MaterialListBoxItem();
                item.Text = exportTextBox.Text.Trim();
                exportFolderList.Items.Insert(0, item);
                exportTextBox.Clear();
            }
        }
        private void exportremove_Click(object sender, EventArgs e)
        {
            exportFolderList.RemoveItem(exportFolderList.SelectedItem);
        }
        private void selectAiAccRange_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (selectAiAccRange.SelectedItem)
                {
                    case "Today":
                        Show_Ai_Accuracy(-1);
                        break;
                    case "Last 3 Days":
                        Show_Ai_Accuracy(-3);
                        break;
                    case "Last 7 Days":
                        Show_Ai_Accuracy(-7);
                        break;
                    case "Last 14 Days":
                        Show_Ai_Accuracy(-14);
                        break;
                    case "Last 30 Days":
                        Show_Ai_Accuracy(-30);
                        break;
                    case "Last 180 Days":
                        Show_Ai_Accuracy(-180);
                        break;
                    case "Last 365 Days":
                        Show_Ai_Accuracy(-365);
                        break;
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private void selectAiAccModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectAiAccRange_SelectedIndexChanged(null, null);
        }
        private void AIAccuracy_Click(object sender, EventArgs e)
        {
            reflashAiAccuracy();
        }
        private void bt_reflash_Click(object sender, EventArgs e)
        {
            reflashAiAccuracy();
        }
        private void reflashAiAccuracy()
        {
            try
            {
                string select_item = null;
                if (selectAiAccModel.SelectedItem != null)
                {
                    select_item = selectAiAccModel.SelectedItem.ToString();
                }

                selectAiAccModel.Items.Clear();
                foreach (String d in Directory.GetDirectories(".\\Accuracy_predict\\"))
                {
                    selectAiAccModel.Items.Add(Path.GetFileName(d));
                }

                if (selectAiAccModel.Items.Count > 0 && select_item != null)
                {
                    selectAiAccModel.SelectedIndex = selectAiAccModel.Items.IndexOf(select_item);
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
        }
        private int check_defect_table(string model_path)
        {
            string[] classinfo = Read_label_ini(model_path);
            return classinfo.Length;
        }
        private void btn_AreaCheckTool_Click(object sender, EventArgs e)
        {
            if (mindefectareaTextBox.Text != "" && regionsizeTextBox.Text != "")
            {
                int mindefectarea = Convert.ToInt32(mindefectareaTextBox.Text);
                int region_size = Convert.ToInt32(regionsizeTextBox.Text);
                Form AreaCheckTool = new AreaCheckTool(mindefectarea, region_size);
                AreaCheckTool.ShowDialog(this);
                AreaCheckTool.Owner = this;
            }
            else
            {
                Form AreaCheckTool = new AreaCheckTool();
                AreaCheckTool.ShowDialog(this);
                AreaCheckTool.Owner = this;
            }
        }
        public void LoadAreaCheckTool(int defectsize, int regionsize)
        {
            mindefectareaTextBox.Text = defectsize.ToString();
            regionsizeTextBox.Text = regionsize.ToString();
        }
        private List<string> ShortAreaCheck(List<string> knownDataList)
        {
            List<string> newKnownData = new List<string>();

            try
            {
                Mat aoi_img = new Mat();
                Mat layout_img = new Mat();
                Mat region_mask = new Mat();
                Mat result_img = new Mat();
                Mat sub_color_img = new Mat();
                Mat sub_img = new Mat();
                Mat binary_img = new Mat();
                double region_size = pconfig.RegionSize * 0.01;
                List<string> defectlist = new List<string>();
                defectlist.Add("NULL");

                foreach (List<string> item in pconfig.AreaCheckTable)
                {
                    if (item[1] == "True")
                    {
                        defectlist.Add(item[0]);
                    }
                }

                foreach (string knowndata in knownDataList)
                {
                    if (defectlist.Contains(knowndata.Split(',')[1]))
                    {
                        string aoiFilename = knowndata.Split(',')[0];
                        if (File.Exists(aoiFilename))
                        {
                            aoi_img = Cv2.ImRead(@aoiFilename, ImreadModes.Grayscale);
                        }
                        else
                        {
                            newKnownData.Add(knowndata);
                            info.Error("Can't find aoi image.  >>" + aoiFilename);
                            info.Error("By pass Short Area Check.");
                            continue;
                        }
                        string layoutpath = Path.GetDirectoryName(knowndata.Split(',')[0]) + "\\Ref\\" + Path.GetFileName(knowndata.Split(',')[0]);
                        string layoutFileName = layoutpath.Insert(layoutpath.Length - 4, "_Ref");
                        if (File.Exists(layoutFileName))
                        {
                            layout_img = Cv2.ImRead(@layoutFileName, ImreadModes.Grayscale);
                        }
                        else
                        {
                            newKnownData.Add(knowndata);
                            info.Warning("Can't find layout image. >>" + layoutFileName);
                            continue;
                        }

                        Cv2.Threshold(aoi_img, binary_img, 0, 255, ThresholdTypes.Otsu);
                        Cv2.Subtract(binary_img, layout_img, sub_img);
                        InputArray kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(2, 2), new OpenCvSharp.Point(-1, -1));
                        Cv2.MorphologyEx(sub_img, sub_img, MorphTypes.Open, kernel, new OpenCvSharp.Point(-1, -1), 1, BorderTypes.Constant, Scalar.Gold);
                        region_mask = Mat.Zeros(aoi_img.Size(), MatType.CV_8UC1);
                        double roi_width = aoi_img.Width * region_size;
                        double roi_height = aoi_img.Height * region_size;
                        List<OpenCvSharp.Point> pts = new List<OpenCvSharp.Point>
                        {
                        new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
                        new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
                        new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2)),
                        new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2))
                        };
                        List<List<OpenCvSharp.Point>> ppts = new List<List<OpenCvSharp.Point>>() { pts };
                        Cv2.FillPoly(region_mask, ppts, new Scalar(255));
                        Cv2.BitwiseAnd(sub_img, region_mask, result_img);
                        Cv2.FindContours(
                            result_img,
                            contours: out OpenCvSharp.Point[][] contours,
                            hierarchy: out HierarchyIndex[] outputArray,
                            RetrievalModes.External,
                            ContourApproximationModes.ApproxNone);
                        double total_area = 0;
                        for (int i = 0; i < contours.Length; i++)
                        {
                            total_area += Cv2.ContourArea(contours[i]);
                        }

                        //rejudge by defect area and defect size
                        if (total_area >= pconfig.DefectSize)
                        {
                            newKnownData.Add(knowndata + ",NONREPAIR,,");
                        }
                        else
                        {
                            newKnownData.Add(knowndata + ",REPAIRABLE,,");
                        }
                    }
                    else newKnownData.Add(knowndata + ",,,");
                }
            }
            catch (Exception ex)
            {
                info.Error(ex.ToString());
            }
            return newKnownData;
        }
        private void DataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                for (int i = 0; i < GV_DefectTable.Rows.Count; i++)
                {
                    if (GV_DefectTable.Rows[i].Cells["Type"].Value != null)
                    {
                        if (GV_DefectTable.Rows[i].Cells["Type"].Value.ToString() == "Bypass")
                        {
                            GV_DefectTable.Rows[i].Cells["Judge"].Value = "-";
                            GV_DefectTable.Rows[i].Cells["AI_Result"].Value = "-";
                            GV_DefectTable.Rows[i].Cells["NewResult"].Value = "-";
                        }
                    }
                    if (GV_DefectTable.Rows[i].Cells["NewResult"].Value != null)
                    {
                        GV_DefectTable.Rows[i].Cells["NewResult"].Value = GV_DefectTable.Rows[i].Cells["NewResult"].Value.ToString().ToUpper();
                    }
                }
            }
            catch (ArgumentException)
            { return; }
        }
    }
}