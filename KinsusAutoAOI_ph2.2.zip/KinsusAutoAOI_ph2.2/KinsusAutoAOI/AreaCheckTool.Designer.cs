﻿
namespace KinsusAutoAOI
{
    partial class AreaCheckTool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sld_defectsize = new MaterialSkin.Controls.MaterialSlider();
            this.sld_regionsize = new MaterialSkin.Controls.MaterialSlider();
            this.materialCard2 = new MaterialSkin.Controls.MaterialCard();
            this.materialLabel22 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox_aoi = new System.Windows.Forms.PictureBox();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBox_detect = new System.Windows.Forms.PictureBox();
            this.pictureBox_layout = new System.Windows.Forms.PictureBox();
            this.btn_LoadImage = new MaterialSkin.Controls.MaterialButton();
            this.btn_SaveAreaCheckToolRecipe = new MaterialSkin.Controls.MaterialButton();
            this.materialCard1 = new MaterialSkin.Controls.MaterialCard();
            this.materialCard3 = new MaterialSkin.Controls.MaterialCard();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard4 = new MaterialSkin.Controls.MaterialCard();
            this.defect_area = new MaterialSkin.Controls.MaterialLabel();
            this.materialCard2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_aoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_detect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_layout)).BeginInit();
            this.materialCard1.SuspendLayout();
            this.materialCard3.SuspendLayout();
            this.materialCard4.SuspendLayout();
            this.SuspendLayout();
            // 
            // sld_defectsize
            // 
            this.sld_defectsize.Depth = 0;
            this.sld_defectsize.Enabled = false;
            this.sld_defectsize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sld_defectsize.Location = new System.Drawing.Point(202, 569);
            this.sld_defectsize.MouseState = MaterialSkin.MouseState.HOVER;
            this.sld_defectsize.Name = "sld_defectsize";
            this.sld_defectsize.Size = new System.Drawing.Size(681, 40);
            this.sld_defectsize.TabIndex = 1;
            this.sld_defectsize.Text = "Defect size";
            // 
            // sld_regionsize
            // 
            this.sld_regionsize.Depth = 0;
            this.sld_regionsize.Enabled = false;
            this.sld_regionsize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sld_regionsize.Location = new System.Drawing.Point(202, 511);
            this.sld_regionsize.MouseState = MaterialSkin.MouseState.HOVER;
            this.sld_regionsize.Name = "sld_regionsize";
            this.sld_regionsize.RangeMin = 1;
            this.sld_regionsize.Size = new System.Drawing.Size(681, 40);
            this.sld_regionsize.TabIndex = 0;
            this.sld_regionsize.Text = "Region size";
            this.sld_regionsize.ValueMax = 100;
            this.sld_regionsize.onValueChanged += Sld_regionsize_onValueChanged;
            // 
            // materialCard2
            // 
            this.materialCard2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard2.Controls.Add(this.materialLabel22);
            this.materialCard2.Controls.Add(this.pictureBox_aoi);
            this.materialCard2.Depth = 0;
            this.materialCard2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard2.Location = new System.Drawing.Point(60, 92);
            this.materialCard2.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard2.Name = "materialCard2";
            this.materialCard2.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard2.Size = new System.Drawing.Size(328, 342);
            this.materialCard2.TabIndex = 2;
            // 
            // materialLabel22
            // 
            this.materialLabel22.AutoSize = true;
            this.materialLabel22.Depth = 0;
            this.materialLabel22.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel22.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel22.Location = new System.Drawing.Point(129, 311);
            this.materialLabel22.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel22.Name = "materialLabel22";
            this.materialLabel22.Size = new System.Drawing.Size(67, 17);
            this.materialLabel22.TabIndex = 22;
            this.materialLabel22.Text = "AOI Image";
            // 
            // pictureBox_aoi
            // 
            this.pictureBox_aoi.Image = global::KinsusAutoAOI.Properties.Resources._2143344;
            this.pictureBox_aoi.Location = new System.Drawing.Point(17, 17);
            this.pictureBox_aoi.Name = "pictureBox_aoi";
            this.pictureBox_aoi.Size = new System.Drawing.Size(294, 276);
            this.pictureBox_aoi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_aoi.TabIndex = 0;
            this.pictureBox_aoi.TabStop = false;
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel2.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel2.Location = new System.Drawing.Point(118, 311);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(106, 17);
            this.materialLabel2.TabIndex = 24;
            this.materialLabel2.Text = "Detection Image";
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto Medium", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel1.FontType = MaterialSkin.MaterialSkinManager.fontType.Subtitle2;
            this.materialLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.materialLabel1.Location = new System.Drawing.Point(117, 312);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(88, 17);
            this.materialLabel1.TabIndex = 23;
            this.materialLabel1.Text = "Layout Image";
            // 
            // pictureBox_detect
            // 
            this.pictureBox_detect.Location = new System.Drawing.Point(16, 17);
            this.pictureBox_detect.Name = "pictureBox_detect";
            this.pictureBox_detect.Size = new System.Drawing.Size(294, 276);
            this.pictureBox_detect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_detect.TabIndex = 2;
            this.pictureBox_detect.TabStop = false;
            // 
            // pictureBox_layout
            // 
            this.pictureBox_layout.Location = new System.Drawing.Point(17, 18);
            this.pictureBox_layout.Name = "pictureBox_layout";
            this.pictureBox_layout.Size = new System.Drawing.Size(294, 276);
            this.pictureBox_layout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_layout.TabIndex = 1;
            this.pictureBox_layout.TabStop = false;
            // 
            // btn_LoadImage
            // 
            this.btn_LoadImage.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_LoadImage.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btn_LoadImage.Depth = 0;
            this.btn_LoadImage.HighEmphasis = true;
            this.btn_LoadImage.Icon = null;
            this.btn_LoadImage.Location = new System.Drawing.Point(385, 641);
            this.btn_LoadImage.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_LoadImage.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_LoadImage.Name = "btn_LoadImage";
            this.btn_LoadImage.NoAccentTextColor = System.Drawing.Color.Empty;
            this.btn_LoadImage.Size = new System.Drawing.Size(135, 36);
            this.btn_LoadImage.TabIndex = 3;
            this.btn_LoadImage.Text = "Load AOI Image";
            this.btn_LoadImage.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btn_LoadImage.UseAccentColor = false;
            this.btn_LoadImage.UseVisualStyleBackColor = true;
            this.btn_LoadImage.Click += new System.EventHandler(this.btn_LoadImage_Click);
            // 
            // btn_SaveAreaCheckToolRecipe
            // 
            this.btn_SaveAreaCheckToolRecipe.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_SaveAreaCheckToolRecipe.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.btn_SaveAreaCheckToolRecipe.Depth = 0;
            this.btn_SaveAreaCheckToolRecipe.HighEmphasis = true;
            this.btn_SaveAreaCheckToolRecipe.Icon = null;
            this.btn_SaveAreaCheckToolRecipe.Location = new System.Drawing.Point(644, 641);
            this.btn_SaveAreaCheckToolRecipe.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_SaveAreaCheckToolRecipe.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_SaveAreaCheckToolRecipe.Name = "btn_SaveAreaCheckToolRecipe";
            this.btn_SaveAreaCheckToolRecipe.NoAccentTextColor = System.Drawing.Color.Empty;
            this.btn_SaveAreaCheckToolRecipe.Size = new System.Drawing.Size(111, 36);
            this.btn_SaveAreaCheckToolRecipe.TabIndex = 4;
            this.btn_SaveAreaCheckToolRecipe.Text = "Save Recipe";
            this.btn_SaveAreaCheckToolRecipe.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.btn_SaveAreaCheckToolRecipe.UseAccentColor = false;
            this.btn_SaveAreaCheckToolRecipe.UseVisualStyleBackColor = true;
            this.btn_SaveAreaCheckToolRecipe.Click += new System.EventHandler(this.btn_SaveAreaCheckToolRecipe_Click);
            // 
            // materialCard1
            // 
            this.materialCard1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard1.Controls.Add(this.pictureBox_layout);
            this.materialCard1.Controls.Add(this.materialLabel1);
            this.materialCard1.Depth = 0;
            this.materialCard1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard1.Location = new System.Drawing.Point(402, 91);
            this.materialCard1.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard1.Name = "materialCard1";
            this.materialCard1.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard1.Size = new System.Drawing.Size(330, 342);
            this.materialCard1.TabIndex = 25;
            // 
            // materialCard3
            // 
            this.materialCard3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard3.Controls.Add(this.pictureBox_detect);
            this.materialCard3.Controls.Add(this.materialLabel2);
            this.materialCard3.Depth = 0;
            this.materialCard3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard3.Location = new System.Drawing.Point(744, 92);
            this.materialCard3.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard3.Name = "materialCard3";
            this.materialCard3.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard3.Size = new System.Drawing.Size(327, 340);
            this.materialCard3.TabIndex = 26;
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel3.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.materialLabel3.Location = new System.Drawing.Point(34, 14);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(178, 24);
            this.materialLabel3.TabIndex = 27;
            this.materialLabel3.Text = "Total defect area =\r\n\r\n";
            // 
            // materialCard4
            // 
            this.materialCard4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard4.Controls.Add(this.defect_area);
            this.materialCard4.Controls.Add(this.materialLabel3);
            this.materialCard4.Depth = 0;
            this.materialCard4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard4.Location = new System.Drawing.Point(744, 443);
            this.materialCard4.Margin = new System.Windows.Forms.Padding(14);
            this.materialCard4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialCard4.Name = "materialCard4";
            this.materialCard4.Padding = new System.Windows.Forms.Padding(14);
            this.materialCard4.Size = new System.Drawing.Size(327, 51);
            this.materialCard4.TabIndex = 28;
            // 
            // defect_area
            // 
            this.defect_area.AutoSize = true;
            this.defect_area.Depth = 0;
            this.defect_area.Font = new System.Drawing.Font("Roboto Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.defect_area.FontType = MaterialSkin.MaterialSkinManager.fontType.H6;
            this.defect_area.Location = new System.Drawing.Point(247, 14);
            this.defect_area.MouseState = MaterialSkin.MouseState.HOVER;
            this.defect_area.Name = "defect_area";
            this.defect_area.Size = new System.Drawing.Size(36, 24);
            this.defect_area.TabIndex = 28;
            this.defect_area.Text = "Null";
            // 
            // AreaCheckTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 706);
            this.Controls.Add(this.materialCard4);
            this.Controls.Add(this.materialCard3);
            this.Controls.Add(this.materialCard1);
            this.Controls.Add(this.btn_SaveAreaCheckToolRecipe);
            this.Controls.Add(this.btn_LoadImage);
            this.Controls.Add(this.materialCard2);
            this.Controls.Add(this.sld_defectsize);
            this.Controls.Add(this.sld_regionsize);
            this.Name = "AreaCheckTool";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AreaCheck Tool";
            this.materialCard2.ResumeLayout(false);
            this.materialCard2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_aoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_detect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_layout)).EndInit();
            this.materialCard1.ResumeLayout(false);
            this.materialCard1.PerformLayout();
            this.materialCard3.ResumeLayout(false);
            this.materialCard3.PerformLayout();
            this.materialCard4.ResumeLayout(false);
            this.materialCard4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialCard materialCard4;
        private MaterialSkin.Controls.MaterialLabel defect_area;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialCard materialCard3;
        private System.Windows.Forms.PictureBox pictureBox_detect;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialCard materialCard1;
        private System.Windows.Forms.PictureBox pictureBox_layout;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialButton btn_SaveAreaCheckToolRecipe;
        private MaterialSkin.Controls.MaterialButton btn_LoadImage;
        private MaterialSkin.Controls.MaterialCard materialCard2;
        private MaterialSkin.Controls.MaterialLabel materialLabel22;
        private System.Windows.Forms.PictureBox pictureBox_aoi;
        private MaterialSkin.Controls.MaterialSlider sld_defectsize;
        private MaterialSkin.Controls.MaterialSlider sld_regionsize;
    }
}