﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ace.Core.CDB;
using Ace.Core.FileContainers;
using Ace.Core.ScanResults;
using Ace.Core.InspectionResults;
using BasicElements.StringOperations;
using CDB_SDK;
using CDBReporting;
using CDBReportingServer;

namespace KinsusAutoAOI
{
    using Serializer = BasicElements.Serialization.Serializer;

	class ClsKinsusCDB
	{
		// members
		private Repository _repository; //Remote repository
		private InspectionImagesContainer _inspectionImagesContainer; //Images related access class
		private List<Defects_Clusters> _currentDefects;

		private CustomItem _selectedAOIJob;
		private CustomItem _selectedJob;
		private CustomItem _selectedLayer;
		private CustomItem _selectedLot;
		private CustomItem _selectedPanel;
		private CustomItem _selectedDefect;
		private DefectsContainer _defectsContainer;
		private DefectImageLoader _defectImageLoader;

		private  string _serverAddress = "localhost";
		private  string _imageShareFolder = "SHARE";
		private const string SETTINGS = "Settings";
		private const string EVENTS = "Events";
		private const string PANELS = "Physical Layers";

		private readonly Dictionary<uint, BasicPhysicalLayerInfo> _physicalLayersToProcess = new Dictionary<uint, BasicPhysicalLayerInfo>();
		private readonly Stopwatch _generalProcessDuration = new Stopwatch();
		private HashSet<ulong> _donePhysicalLayers;
		private List<Task> _convertTasksList;
		private readonly object _progressLock = new object();
		private List<Steps_Instances> _jobSteps;
		private List<Customer_Defects_Codes> _customerDefectCodes;
		private CancellationTokenSource _cancellationTokenSource;
		private const float NUMBER_OF_THREADS_FACTOR = 0.5f;

		public ClsKinsusCDB(string serverAddress, string imageShareFolder)
        {
			_serverAddress = serverAddress;
			_imageShareFolder = imageShareFolder;
		}

		public int Initialize()
        {
			InitializeCDB();
			if (_repository.IsConnected)
			{
				DuplicateConnection();
				return 1;
			}
			else
			{
				return 0;
			}
		}

		public int GetNewestPhysicalLayersID(DateTime mDatetime, ref uint mPhysicalLayersID)
        {
			var PhysicalID =
				(from pl in _repository.Physical_Layers
				 where pl.Scanned > mDatetime
				 select pl.id)
				 .First();

			mPhysicalLayersID = PhysicalID;
			//_selectedPanel = PhysicalID;

			return 1;
        }

		public int GetDataDetails(int mPhysicalLayersID)
        {

			return 1;
		}


		private void InitializeCDB()
		{
			//Connect repository to CDBReporting Server
			try
			{
				_repository?.Dispose();
				_repository = new Repository($"{WcfServer.DefaultSchema}://{_serverAddress}{WcfServer.DefaultServicePath}");
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception);
			}
			if (_repository == null || !_repository.IsConnected)
				MessageBox.Show(@"Can't connect to CDB, check that ReportingServer is running",
								@"Connection Failed",
								MessageBoxButtons.OK,
								MessageBoxIcon.Error);
			else
				_inspectionImagesContainer =
					new InspectionImagesContainer(_repository.CDB.ServerAddress,
												  _imageShareFolder,
												  _repository.CDB.DataBaseName);
		}

		private void DuplicateConnection()
		{
			if (_repository?.CDB == null)
				return;

			try
			{
				var cdb = new CDB_Connector
				{
					ServerAddress = _repository.CDB.ServerAddress,
					DataBaseName = _repository.CDB.DataBaseName,
					UserName = _repository.CDB.UserName,
					Password = _repository.CDB.Password
				};
				cdb.Connect(_repository.CDB.ServerAddress,
							_repository.CDB.DataBaseName,
							_repository.CDB.UserName,
							_repository.CDB.Password);
				_repository.CDB = cdb;
			}
			catch
			{
				// ignored
			}
		}

        private static bool IsContainerLoaded(DefectsContainer defectsContainer)
        {
            return defectsContainer?.Data != null && defectsContainer.Data.Defects.Any();
        }

        private void ProcessPhysicalLayer(Physical_Layers pl, IProgress<DetailedPhysicalLayerInfo> progress, CancellationToken cancellationToken)
        {
            var sw = new Stopwatch();
            sw.Start();

            var dpli = new DetailedPhysicalLayerInfo { PhysicalLayerID = pl.id, Status = eStatus.Initializing };
            // report panel started processing
            progress.Report(dpli);

            var lotName = _repository.Lots.First(x => x.id == pl.LotID).Name;
            var layer = _repository.Layer_Infos.First(x => x.id == pl.LayerInfoID);
            var layerName = layer.Name;
            var jobName = _repository.Jobs.First(x => x.id == layer.JobID).Name;

            // create images target path
            var targetImagesPath = Path.Combine("./defect_image/", _repository.CDB.DataBaseName, jobName, layerName, lotName, pl.PhysicalID.ToString());
            Directory.CreateDirectory($"{targetImagesPath}");

            // load images container
            var inspectionImagesContainer = new InspectionImagesContainer(_repository.CDB.GetExternalStorageSharePath(), _repository.CDB.DataBaseName);
            inspectionImagesContainer.Load(pl.id);
            if (inspectionImagesContainer.Data == null || inspectionImagesContainer.Data.Images.Count == 0)
            {
                dpli.Status = eStatus.Done;
                progress.Report(dpli);
                sw.Stop();
                return;
            }

            // load defects container
            var defectsContainer = new DefectsContainer(_repository.CDB.GetExternalStorageSharePath(), _repository.CDB.DataBaseName);
            defectsContainer.Load(pl.id);
            if (!IsContainerLoaded(defectsContainer))
            {
                dpli.Status = eStatus.Done;
                progress.Report(dpli);
                sw.Stop();
                return;
            }

            // process physical layer's defects
            var rnd = new Random();
            var dontCareCDC = _repository.Customer_Defects_Codes.First(x => ClassificationList.IsDefectDontCare(x.Severity)).id;
            var cdcIds = _repository.Customer_Defects_Codes.Where(x => x.Severity > 1 &&
                                                                       !InspectionDefectsData.SeverityIsScrapping(x.Severity))
                                                                       .Select(x => x.id).ToArray();

            var count = 0;
            dpli.TotalItems = defectsContainer.Data.Defects.Count;
            foreach (var d in defectsContainer.Data.Defects)
            {
                count++;
                dpli.CurrentItem = (ulong)count;

                if (cancellationToken.IsCancellationRequested)
                {
                    dpli.DefectImage = null;
                    dpli.Status = eStatus.Cancelled;
                    dpli.Duration = Math.Round(sw.ElapsedMilliseconds / 1000f / 60f, 3);
                    dpli.LastError = "Operation cancelled!";
                    progress.Report(dpli);
                    break;
                }

                // get defect's inspection and reference images and save to target path
                if (true) //chkExtractImages.Checked)
                {
                    var defectImages = GetDefectImages(d, inspectionImagesContainer, pl);

                    var hasImage = defectImages.Item1 != null
                                   || defectImages.Item2 != null
                                   || defectImages.Item3 != null;

                    if (hasImage)
                    {
                        var cdc = _repository.Customer_Defects_Codes.First(x => x.id == d.CustomerDefectCodeID);
                        defectImages.Item1?.Save(targetImagesPath + $"\\{d.id}_{d.CustomerDefectCodeID}_{cdc.Code}_ins.bmp");
                        //defectImages.Item2?.Save(targetImagesPath + $"\\{d.id}_{d.CustomerDefectCodeID}_{cdc.Code}_ref.bmp");
                        //if (chkIncludeVideo.Checked)
                        //	defectImages.Item3?.Save(targetImagesPath + $"\\{d.id}_{d.CustomerDefectCodeID}_{cdc.Code}_video.bmp");
                    }
                    else
                        Trace.WriteLine($"CDB_SDK_DEMO.ProcessPhysicalLayer() ===> No image found for defect #{d.id} in physical_layer #{pl.id}");

                    dpli.DefectImage = defectImages.Item1;
                    //dpli.LastError = hasImage ? string.Empty : $"No image found for defect #{d.id}";
                }


                dpli.Status = eStatus.Processing;
                dpli.Duration = Math.Round(sw.ElapsedMilliseconds / 1000f, 3);
                progress.Report(dpli);
            }

            sw.Stop();

            // report physical layer done
            dpli.DefectImage = null;
            dpli.Status = eStatus.Done;
            dpli.Duration = Math.Round(sw.ElapsedMilliseconds / 1000f, 3);
            progress.Report(dpli);
        }

        private Tuple<Bitmap, Bitmap, Bitmap> GetDefectImages(Defects_Clusters defect, InspectionImagesContainer inspectionImagesContainer, Physical_Layers pl)
        {
            try
            {
                //inspectionImagesContainer.Load(pl.id);
                Bitmap insBitmap = null;
                Bitmap refBitmap = null;
                Bitmap vidBitmap = null;
                var defectImage = inspectionImagesContainer.GetImageFromCenter(defect.Center); //will return ins & ref in one DI
                insBitmap = defectImage.GetBitmap(inspectionImagesContainer.Data.CompressionType);
                refBitmap = defectImage.RefImages.FirstOrDefault(i => i.Type == ImageType.Reference).GetBitmap(inspectionImagesContainer.Data.CompressionType);
                defectImage = inspectionImagesContainer.GetImageFromCenter(defect.Center, defect.id, true); //will return video image
                vidBitmap = defectImage.GetBitmap(inspectionImagesContainer.Data.CompressionType);
                /*if (defectImage == null)
                {
                    var uriVideo = GetDefectVideoImagePath(defect, pl);
                    vidBitmap = Helpers.GetVideoImageFromSharedFolder(uriVideo);
                }
                else
                    vidBitmap = defectImage.GetBitmap(inspectionImagesContainer.Data.CompressionType);*/

                return Tuple.Create(insBitmap, refBitmap, vidBitmap);
            }
            catch
            {
                return new Tuple<Bitmap, Bitmap, Bitmap>(null, null, null);
            }
        }
    }

}
