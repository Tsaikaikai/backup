﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace KinsusAutoAOI
{
    public partial class Login : MaterialForm
    {
        public Login()
        {
            InitializeComponent();
            this.Password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pasword_KeyPress);
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(
                Color.FromArgb(255, 0, 80, 135), Color.FromArgb(240, 0, 80, 135), Color.FromArgb(255, 255, 255, 255),
                Color.FromArgb(255, 0, 80, 135), TextShade.WHITE);
        }

        private void materialButton1_Click(object sender, EventArgs e)
        {
            if ((this.Username.Text == "OEM0620" && this.Password.Text == "AUO1234") || (this.Username.Text == "t" && this.Password.Text == "t"))
            {
                this.DialogResult = DialogResult.OK;    //返回一個登入成功的對話方塊狀態
                this.Close();    //關閉登入視窗
            }
            else
            {
                MessageBox.Show("No Account available with this username and password!");
            }
        }

        private void Pasword_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))//輸入enter
            {
                this.materialButton1_Click(sender, e);//觸發button事件
            }
        }
    }
}
