﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml.Serialization;
using System.IO;
using MaterialSkin;
using MaterialSkin.Controls;
using System.Data;
using System.Windows.Forms;

namespace KinsusAutoAOI
{
    public class PConfig
    {
        private string _productname = "";
        [Category("Product Setting"), DisplayName("Product_Name")]
        public string ProductName
        {
            get { return _productname; }
            set { _productname = value; }
        }

        private double _aiunknown_threshold = 90;
        [Category("Product Setting"), DisplayName("AI Unknown Threshold"), Description("Threshold of AI unknown confidence.")]
        public double AiUnknownThreshold
        {
            get { return _aiunknown_threshold; }
            set { _aiunknown_threshold = value; }
        }

        private string _aimodelPath = "";
        [Category("Product Setting"), DisplayName("AI Model Path")]
        public string AiModelPath
        {
            get { return _aimodelPath; }
            set { _aimodelPath = value; }
        }

        private List<List<string>> _defectcodetable;
        [Category("Product Setting"), DisplayName("Defect Code Table")]
        public List<List<string>> DefectCodeTable
        {
            get { return _defectcodetable; }
            set { _defectcodetable = value; }
        }

        private List<List<string>> _areachecktable;
        [Category("Product Setting"), DisplayName("Defect Code Table")]
        public List<List<string>> AreaCheckTable
        {
            get { return _areachecktable; }
            set { _areachecktable = value; }
        }

        private List<List<string>> _detaildefectcodetable;
        [Category("Product Setting"), DisplayName("Detail Defect Code Table")]
        public List<List<string>> DetailDefectCodeTable
        {
            get { return _detaildefectcodetable; }
            set { _detaildefectcodetable = value; }
        }

        private string _ailabelstring = "";
        [Category("Product Setting"), DisplayName("AI Label Name List")]
        public string AiLabelString
        {
            get { return _ailabelstring; }
            set { _ailabelstring = value; }
        }

        private string _aidetailmodelPath = "";
        [Category("Product Setting"), DisplayName("AI Detail Model Path")]
        public string AiDetailModelPath
        {
            get { return _aidetailmodelPath; }
            set { _aidetailmodelPath = value; }
        }

        private string _aidetaillabelstring = "";
        [Category("Product Setting"), DisplayName("AI Detail Label Name List")]
        public string AiDetailLabelString
        {
            get { return _aidetaillabelstring; }
            set { _aidetaillabelstring = value; }
        }

        private bool _usedetailmodel = false;
        [Category("Product Setting"), DisplayName("Use AI Detail Model")]
        public bool UseDetailModel
        {
            get { return _usedetailmodel; }
            set { _usedetailmodel = value; }
        }

        private int _region_size = 50;
        [Category("Product Setting"), DisplayName("Area Check Region Size")]
        public int RegionSize
        {
            get { return _region_size; }
            set { _region_size = value; }
        }

        private int _defect_size = 50;
        [Category("Product Setting"), DisplayName("Area Check Defect Size")]
        public int DefectSize
        {
            get { return _defect_size; }
            set { _defect_size = value; }
        }

        private List<string> _bypassstringlist;
        [Category("Product Setting"), DisplayName("Bypass Defect String List")]
        public List<string> BypassStringList
        {
            get { return _bypassstringlist; }
            set { _bypassstringlist = value; }
        }

        private DataTable _defectruletable = new DataTable("RuleTable");
        [Category("Product Setting"), DisplayName("Defect Rule Table")]
        public DataTable DefectRuleTable
        {
            get { return _defectruletable; }
            set { _defectruletable = value; }
        }

        public void CreateXML(PConfig clsRecipe, string filename)
        {
            // Create an instance of the XmlSerializer class;
            // specify the type of object to serialize.
            XmlSerializer serializer = new XmlSerializer(typeof(PConfig));
            TextWriter writer = new StreamWriter(filename);

            // Serialize the purchase order, and close the TextWriter.
            serializer.Serialize(writer, clsRecipe);
            writer.Close();
        }

        public PConfig ReadXML(string filename)
        {
            // Create an instance of the XmlSerializer class;
            // specify the type of object to be deserialized.
            XmlSerializer serializer = new XmlSerializer(typeof(PConfig));
            FileStream fp = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            PConfig Sfp = (PConfig)serializer.Deserialize(fp);
            fp.Close();
            return Sfp;
        }
    }

    public class SConfig
    {
        private string _systemname = "";
        [Category("System Setting"), DisplayName("System Name")]
        public string SystemName
        {
            get { return _systemname; }
            set { _systemname = value; }
        }

        private ObservableCollection<MaterialListBoxItem> _exportfolderlist;
        [Category("System Setting"), DisplayName("Export Folder List")]
        public ObservableCollection<MaterialListBoxItem> ExportFolderList
        {
            get { return _exportfolderlist; }
            set { _exportfolderlist = value; }
        }

        private string _importpath = ".\\Import_folder";
        [Category("System Setting"), DisplayName("Import Path of Database")]
        public string ImportPath
        {
            get { return _importpath; }
            set { _importpath = value; }
        }

        private string _monitor_freq = "5";
        [Category("System Setting"), DisplayName("Monitoring Frequency (sec)")]
        public string MonitorFrequency
        {
            get { return _monitor_freq; }
            set { _monitor_freq = value; }
        }

        private string _delayaftermonitor = "5";
        [Category("System Setting"), DisplayName("Delay After Monitor (sec)")]
        public string DelayAfterMonitor
        {
            get { return _delayaftermonitor; }
            set { _delayaftermonitor = value; }
        }

        private string _rejudgeCenter_ip = "127.0.0.2";
        [Category("System Setting"), DisplayName("Rejudge System IP Address")]
        public string RejudgeCenterIp
        {
            get { return _rejudgeCenter_ip; }
            set { _rejudgeCenter_ip = value; }
        }

        private string _rejudgeCenter_timeout = "50";
        [Category("System Setting"), DisplayName("Rejudge System Timeout(sec)")]
        public string RejudgeCenterTimeout
        {
            get { return _rejudgeCenter_timeout; }
            set { _rejudgeCenter_timeout = value; }
        }

        private string _rejudgeCenter_port = "9001";
        [Category("System Setting"), DisplayName("Rejudge System Port")]
        public string RejudgeCenterPort
        {
            get { return _rejudgeCenter_port; }
            set { _rejudgeCenter_port = value; }
        }

        private string _localworkfolder = ".\\Work_images";
        [Category("System Setting"), DisplayName("Local Work Folder")]
        public string LocalWorkFolder
        {
            get { return _localworkfolder; }
            set { _localworkfolder = value; }
        }

        private string _localsavefolder = ".\\Save_images";
        [Category("System Setting"), DisplayName("Local Save Folder")]
        public string LocalSaveFolder
        {
            get { return _localsavefolder; }
            set { _localsavefolder = value; }
        }


        private string _backupfolder = ".\\backup";
        [Category("System Setting"), DisplayName("Backup Folder")]
        public string BackupFolder
        {
            get { return _backupfolder; }
            set { _backupfolder = value; }
        }

        private string _graysharefolder = ".\\share_folder";
        [Category("System Setting"), DisplayName("Gray Share Folder")]
        public string GrayShareFolder
        {
            get { return _graysharefolder; }
            set { _graysharefolder = value; }
        }

        private bool _colormode = false;
        [Category(""), DisplayName("Color Mode")]
        public bool ColorMode
        {
            get { return _colormode; }
            set { _colormode = value; }
        }

        private bool _runmode = false;
        [Category(""), DisplayName("Run Mode")]
        public bool YieldAnalysis
        {
            get { return _runmode; }
            set { _runmode = value; }
        }

        private string _workpath = ".\\py";
        [Category(""), DisplayName("Python Work Path")]
        public string WorkPath
        {
            get { return _workpath; }
            set { _workpath = value; }
        }

        private string _subpath = null;
        [Category(""), DisplayName("CSV Subpath")]
        public string SubPath
        {
            get { return _subpath; }
            set { _subpath = value; }
        }

        private string _csvfilename;
        [Category(""), DisplayName("CSV File Name")]
        public string CsvFileName
        {
            get { return _csvfilename; }
            set { _csvfilename = value; }
        }

        private string _workname = "test";
        [Category(""), DisplayName("Work Name")]
        public string WorkName
        {
            get { return _workname; }
            set { _workname = value; }
        }

        private string _targetpath;
        [Category(""), DisplayName("Target Local Path")]
        public string TargetPath
        {
            get { return _targetpath; }
            set { _targetpath = value; }
        }

        private DateTime _nowmonitortime;
        [Category(""), DisplayName("Now Monitor Time")]
        public DateTime NowMonitorTime
        {
            get { return _nowmonitortime; }
            set { _nowmonitortime = value; }
        }

        private List<string> _backupworklist;
        [Category(""), DisplayName("Backup Work List")]
        public List<string> BackupWorkList
        {
            get { return _backupworklist; }
            set { _backupworklist = value; }
        }

        private double _catch_rate = 0.2;
        [Category(""), DisplayName("Catch Rate")]
        public double CatchRate
        {
            get { return _catch_rate; }
            set { _catch_rate = value; }
        }


        public void CreateXML(SConfig clsRecipe, string filename)
        {
            // Create an instance of the XmlSerializer class;
            // specify the type of object to serialize.
            XmlSerializer serializer = new XmlSerializer(typeof(SConfig));
            TextWriter writer = new StreamWriter(filename);

            // Serialize the purchase order, and close the TextWriter.
            serializer.Serialize(writer, clsRecipe);
            writer.Close();
        }

        public SConfig ReadXML(string filename)
        {
            // Create an instance of the XmlSerializer class;
            // specify the type of object to be deserialized.
            XmlSerializer serializer = new XmlSerializer(typeof(SConfig));
            FileStream fp = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            SConfig Sfp = (SConfig)serializer.Deserialize(fp);
            fp.Close();
            return Sfp;
        }
    }

}
