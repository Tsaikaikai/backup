﻿namespace KinsusAutoAOI
{
	public class CustomItem
	{
		public CustomItem(ulong id, string text)
		{
			Text = text;
			ID = id;
		}

		// ReSharper disable once MemberCanBePrivate.Global
		public string Text { get; }

		public ulong ID { get; }

		public override string ToString()
		{
			return Text;
		}
	}
}