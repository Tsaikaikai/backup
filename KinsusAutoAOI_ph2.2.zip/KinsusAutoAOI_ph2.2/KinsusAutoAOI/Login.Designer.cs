﻿
namespace KinsusAutoAOI
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginbutton = new MaterialSkin.Controls.MaterialButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Username = new MaterialSkin.Controls.MaterialTextBox2();
            this.Password = new MaterialSkin.Controls.MaterialTextBox2();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // loginbutton
            // 
            this.loginbutton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.loginbutton.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.loginbutton.Depth = 0;
            this.loginbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginbutton.HighEmphasis = true;
            this.loginbutton.Icon = null;
            this.loginbutton.Location = new System.Drawing.Point(143, 380);
            this.loginbutton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.loginbutton.MouseState = MaterialSkin.MouseState.HOVER;
            this.loginbutton.Name = "loginbutton";
            this.loginbutton.NoAccentTextColor = System.Drawing.Color.Empty;
            this.loginbutton.Size = new System.Drawing.Size(64, 36);
            this.loginbutton.TabIndex = 2;
            this.loginbutton.Text = "Login";
            this.loginbutton.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.loginbutton.UseAccentColor = false;
            this.loginbutton.UseVisualStyleBackColor = true;
            this.loginbutton.Click += new System.EventHandler(this.materialButton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::KinsusAutoAOI.Properties.Resources.login;
            this.pictureBox1.Location = new System.Drawing.Point(115, 85);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Username
            // 
            this.Username.AnimateReadOnly = false;
            this.Username.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Username.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Username.Depth = 0;
            this.Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Username.HideSelection = true;
            this.Username.Hint = "Username";
            this.Username.LeadingIcon = null;
            this.Username.Location = new System.Drawing.Point(36, 227);
            this.Username.MaxLength = 32767;
            this.Username.MouseState = MaterialSkin.MouseState.OUT;
            this.Username.Name = "Username";
            this.Username.PasswordChar = '\0';
            this.Username.PrefixSuffixText = null;
            this.Username.ReadOnly = false;
            this.Username.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Username.SelectedText = "";
            this.Username.SelectionLength = 0;
            this.Username.SelectionStart = 0;
            this.Username.ShortcutsEnabled = true;
            this.Username.Size = new System.Drawing.Size(278, 48);
            this.Username.TabIndex = 4;
            this.Username.TabStop = false;
            this.Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Username.TrailingIcon = null;
            this.Username.UseSystemPasswordChar = false;
            // 
            // Password
            // 
            this.Password.AnimateReadOnly = false;
            this.Password.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Password.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Password.Depth = 0;
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Password.HideSelection = true;
            this.Password.Hint = "Password";
            this.Password.LeadingIcon = null;
            this.Password.Location = new System.Drawing.Point(36, 298);
            this.Password.MaxLength = 20;
            this.Password.MouseState = MaterialSkin.MouseState.OUT;
            this.Password.Name = "Password";
            this.Password.PasswordChar = '*';
            this.Password.PrefixSuffixText = null;
            this.Password.ReadOnly = false;
            this.Password.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Password.SelectedText = "";
            this.Password.SelectionLength = 0;
            this.Password.SelectionStart = 0;
            this.Password.ShortcutsEnabled = true;
            this.Password.Size = new System.Drawing.Size(278, 48);
            this.Password.TabIndex = 5;
            this.Password.TabStop = false;
            this.Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Password.TrailingIcon = null;
            this.Password.UseSystemPasswordChar = false;
            // 
            // Login
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(355, 460);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.loginbutton);
            this.MaximizeBox = false;
            this.Name = "Login";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialButton loginbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MaterialSkin.Controls.MaterialTextBox2 Username;
        private MaterialSkin.Controls.MaterialTextBox2 Password;
    }
}