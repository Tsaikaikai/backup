﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace KinsusAutoAOI
{
    public partial class AreaCheckTool : MaterialForm
    {
        Mat sub_color_img = new Mat();
        Mat sub_img = new Mat();
        Mat region_mask = new Mat();
        Mat result_img = new Mat();
        double region_size, roi_width, roi_height;        
        public Mat layout_img { get; private set; }
        public Mat aoi_img { get; private set; }


        public AreaCheckTool(int defectsize, int regionsize)
        {
            InitializeComponent();
            Defectsize = defectsize;
            Regionsize = regionsize;
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(
                Color.FromArgb(255, 0, 80, 135), Color.FromArgb(240, 0, 80, 135), Color.FromArgb(255, 255, 255, 255),
                Color.FromArgb(255, 0, 80, 135), TextShade.WHITE);
        }
        public AreaCheckTool()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(
                Color.FromArgb(255, 0, 80, 135), Color.FromArgb(240, 0, 80, 135), Color.FromArgb(255, 255, 255, 255),
                Color.FromArgb(255, 0, 80, 135), TextShade.WHITE);
        }

        private void btn_SaveAreaCheckToolRecipe_Click(object sender, EventArgs e)
        {
            Mainform f1 = (Mainform)this.Owner;
            f1.LoadAreaCheckTool(sld_defectsize.Value, sld_regionsize.Value);
            this.Close();
        }

        public int Defectsize
        {
            set
            {
                sld_defectsize.Value = value;
            }
            get
            {
                return sld_defectsize.Value;
            }
        }
        public int Regionsize
        {
            set
            {
                sld_regionsize.Value = value;
            }
            get
            {
                return sld_regionsize.Value;
            }
        }



        private void btn_LoadImage_Click(object sender, EventArgs e)
        {
            //Mat layout_img = new Mat();
            //Mat aoi_img = new Mat();

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false; //是否可以選擇多個檔案
            dialog.Title = "Please Select AOI image.";
            dialog.Filter = "Image Files|*.jpg;*.jpg;*.png;*.gif;*.tif;*.bmp;";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                aoi_img = Cv2.ImRead(@dialog.FileName, ImreadModes.Grayscale);
                Bitmap aoi_bitmap = BitmapConverter.ToBitmap(aoi_img);
                pictureBox_aoi.Image = aoi_bitmap;

                string layoutFileName1 = dialog.FileName.Insert(dialog.FileName.Length - 4, "_Ref");
                string layoutFileName2 = Path.GetDirectoryName(dialog.FileName) + "\\Ref\\" + 
                    Path.GetFileName(dialog.FileName.Insert(dialog.FileName.Length - 4, "_Ref"));

                if (File.Exists(layoutFileName1))
                {
                    layout_img = Cv2.ImRead(@layoutFileName1, ImreadModes.Grayscale);
                }
                else if (File.Exists(layoutFileName2))
                {
                    layout_img = Cv2.ImRead(@layoutFileName2, ImreadModes.Grayscale);
                }
                else
                {
                    MessageBox.Show("Can't find paired layout image.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else { return; }

            Bitmap layout_bitmap = BitmapConverter.ToBitmap(layout_img);
            pictureBox_layout.Image = layout_bitmap;

            Mat binary_img = new Mat();
            Cv2.Threshold(aoi_img, binary_img, 0, 255, ThresholdTypes.Otsu);
            Cv2.Subtract(binary_img, layout_img, sub_img);
            InputArray kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(2, 2), new OpenCvSharp.Point(-1, -1));
            Cv2.MorphologyEx(sub_img, sub_img, MorphTypes.Open, kernel, new OpenCvSharp.Point(-1, -1), 1, BorderTypes.Constant, Scalar.Gold);

            //Mat region_mask = new Mat(aoi_img.Width, aoi_img.Height, MatType.CV_8UC3, new Scalar(0, 0, 0));
            region_mask = Mat.Zeros(aoi_img.Size(), MatType.CV_8UC3);
            region_size = sld_regionsize.Value * 0.01;
            roi_width = aoi_img.Width * region_size;
            roi_height = aoi_img.Height * region_size;
            sld_defectsize.RangeMax = Convert.ToInt32(roi_width * roi_height/8);
            List<OpenCvSharp.Point> pts = new List<OpenCvSharp.Point>
            {
            new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
            new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
            new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2)),
            new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2))
            };
            List<List<OpenCvSharp.Point>> ppts = new List<List<OpenCvSharp.Point>>() { pts };

            Cv2.CvtColor(sub_img, sub_color_img, ColorConversionCodes.GRAY2RGB);
            Cv2.CvtColor(aoi_img, aoi_img, ColorConversionCodes.GRAY2RGB);
            Cv2.FillPoly(region_mask, ppts, new Scalar(0, 0, 255));
            Cv2.AddWeighted(sub_color_img, 0.7, region_mask, 0.4, 0, result_img);
            Cv2.AddWeighted(aoi_img, 0.5, result_img, 0.5, 0, result_img);
            Bitmap result_bitmap = BitmapConverter.ToBitmap(result_img);
            pictureBox_detect.Image = result_bitmap;

            Mat region_mask2 = Mat.Zeros(aoi_img.Size(), MatType.CV_8UC1);
            Mat result_img2 = new Mat();
            Cv2.FillPoly(region_mask2, ppts, new Scalar(255));
            Cv2.BitwiseAnd(sub_img, region_mask2, result_img2);
            Cv2.FindContours(
                result_img2,
                contours: out OpenCvSharp.Point[][] contours,
                hierarchy: out HierarchyIndex[] outputArray,
                RetrievalModes.External,
                ContourApproximationModes.ApproxNone);

            double total_area = 0;
            for (int i = 0; i < contours.Length; i++)
            {
                double area = Cv2.ContourArea(contours[i]);
                total_area += area;
            }
            this.defect_area.Text = total_area.ToString();
            sld_defectsize.Enabled = true;
            sld_regionsize.Enabled = true;
        }

        private void Sld_regionsize_onValueChanged(object sender, int newvalue)
        {
            //throw new System.NotImplementedException();
            region_mask = Mat.Zeros(aoi_img.Size(), MatType.CV_8UC3);
            region_size = sld_regionsize.Value * 0.01;
            roi_width = aoi_img.Width * region_size;
            roi_height = aoi_img.Height * region_size;
            int roi_area = Convert.ToInt32(roi_width * roi_height);
            if (roi_area < 4) roi_area = 4;
            sld_defectsize.RangeMax = roi_area/4;
            List<OpenCvSharp.Point> pts = new List<OpenCvSharp.Point>
            {
                new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
                new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 - roi_height / 2)),
                new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 + roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2)),
                new OpenCvSharp.Point(Convert.ToInt32(aoi_img.Width / 2 - roi_width / 2),Convert.ToInt32(aoi_img.Height / 2 + roi_height / 2))
            };
            List<List<OpenCvSharp.Point>> ppts = new List<List<OpenCvSharp.Point>>() { pts };
            Cv2.FillPoly(region_mask, ppts, new Scalar(0, 0, 255));
            Cv2.AddWeighted(sub_color_img, 0.7, region_mask, 0.4, 0, result_img);
            Cv2.AddWeighted(aoi_img, 0.5, result_img, 0.5, 0, result_img);
            Bitmap result_bitmap = BitmapConverter.ToBitmap(result_img);
            pictureBox_detect.Image = result_bitmap;

            Mat region_mask2 = Mat.Zeros(aoi_img.Size(), MatType.CV_8UC1);
            Mat result_img2 = new Mat();
            Cv2.FillPoly(region_mask2, ppts, new Scalar(255));
            Cv2.BitwiseAnd(sub_img, region_mask2, result_img2);
            Cv2.FindContours(
                result_img2,
                contours: out OpenCvSharp.Point[][] contours,
                hierarchy: out HierarchyIndex[] outputArray,
                RetrievalModes.External,
                ContourApproximationModes.ApproxNone);

            double total_area = 0;
            for (int i = 0; i < contours.Length; i++)
            {
                double area = Cv2.ContourArea(contours[i]);
                total_area += area;
            }
            this.defect_area.Text = total_area.ToString();
        }
    }
}
