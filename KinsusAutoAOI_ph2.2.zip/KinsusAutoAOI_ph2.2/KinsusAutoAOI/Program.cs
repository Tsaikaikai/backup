﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KinsusAutoAOI
{
    static class Program
    {
        private static System.Threading.Mutex mutex;
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Prevent repeated opening
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            mutex = new System.Threading.Mutex(true, "OnlyRun");

            if (mutex.WaitOne(0, false))
            {
                //login
                Login fl = new Login();
                fl.ShowDialog();
                if (fl.DialogResult == DialogResult.OK)
                {
                    Form myform = new Mainform();
                    myform.Size = new Size(1060, 870);
                    Application.Run(myform);
                }
                else
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show("Application is already open！", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
        }
    }
}
