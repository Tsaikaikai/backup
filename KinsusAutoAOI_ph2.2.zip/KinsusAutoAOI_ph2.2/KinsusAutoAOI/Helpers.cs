﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Ace.Core.CDB;
using Ace.Core.FileContainers;
using Ace.Core.ScanResults;
using BasicElements.NumbersOperations;
using CDB_SDK;


namespace KinsusAutoAOI
{
	public static class Helpers
	{
		public static bool IsAfterAI(this Defects_Clusters defect)
			=> defect.FilteredByAI;

		public static bool IsClassification(this Defects_Clusters defect, ClassificationFlags classification)
			=> ((ClassificationFlags)defect.Severity & classification) == classification;

		internal static Bitmap TryGetBitmap(this DefectImage defectImage, CompressionType compressionType)
		{
			try
			{
				return defectImage.GetBitmap(compressionType);
			}
			catch
			{
				return null;
			}
		}

		internal static RotateFlipType GetInversedManipulation(this byte[] bytes)
		{
			if (bytes == null || bytes.Length < 4 * sizeof(float))
				return RotateFlipType.RotateNoneFlipNone;

			var matrix = CDBDAL.ConvertMatrixFromBytes(bytes);
			return matrix.GetInversedManipulation();
		}

		internal static RotateFlipType GetInversedManipulation(this double[] matrix)
		{
			var type = matrix.GetManipulation();
			switch (type)
			{
				case RotateFlipType.Rotate90FlipNone:
					return RotateFlipType.Rotate270FlipNone;
				case RotateFlipType.Rotate270FlipNone:
					return RotateFlipType.Rotate90FlipNone;
				default:
					return type;
			}
		}

		internal static RotateFlipType GetManipulation(this byte[] bytes)
		{
			if (bytes == null || bytes.Length < 4 * sizeof(float))
				return RotateFlipType.RotateNoneFlipNone;

			var matrix = CDBDAL.ConvertMatrixFromBytes(bytes);
			return matrix.GetManipulation();
		}

		internal static RotateFlipType GetManipulation(this double[] matrix)
		{
			if (matrix.Length == 6)
				matrix = new[] { matrix[0], matrix[1], matrix[3], matrix[4] };
			if (NumbersUtils.DoublesEqual(matrix[0], 0.0))
			{
				if (matrix[1] < 0.0 && matrix[2] > 0.0)
					return RotateFlipType.Rotate270FlipNone;
				if (matrix[1] < 0.0 && matrix[2] < 0.0)
					return RotateFlipType.Rotate90FlipX;
				if (matrix[1] > 0.0 && matrix[2] < 0.0)
					return RotateFlipType.Rotate90FlipNone;

				return RotateFlipType.Rotate270FlipX;
			}

			if (matrix[0] < 0.0 && matrix[3] > 0.0)
				return RotateFlipType.RotateNoneFlipX;
			if (matrix[0] < 0.0 && matrix[3] < 0.0)
				return RotateFlipType.Rotate180FlipNone;
			if (matrix[0] > 0.0 && matrix[3] < 0.0)
				return RotateFlipType.Rotate180FlipX;

			return RotateFlipType.RotateNoneFlipNone;
		}

		internal static double GetScale(this double[] matrix)
		{
			return Math.Abs(NumbersUtils.DoublesEqual(matrix[0], 0D) ? matrix[1] : matrix[0]);
		}

		internal static bool RequiresManipulationFix(double[] matAvi, double[] matPvs)
		{
			RotateFlipType rftAvi = matAvi.GetManipulation(),
						   rftPvs = matPvs.GetManipulation();

			return rftAvi == rftPvs;
		}

		internal static RotateFlipType GetAviManipulation(double[] matAvi, double[] matPvs)
		{
			RotateFlipType rftAvi = matAvi.GetManipulation(),
				rftPvs = matPvs.GetManipulation();

			if (rftAvi != rftPvs)
				return rftAvi;

			switch (rftPvs)
			{
				case RotateFlipType.Rotate90FlipNone:
					//case RotateFlipType.Rotate270FlipXY:
					return RotateFlipType.Rotate270FlipNone;
				case RotateFlipType.Rotate270FlipNone:
					//case RotateFlipType.Rotate90FlipXY:
					return RotateFlipType.Rotate90FlipNone;
				case RotateFlipType.Rotate90FlipX:
					//case RotateFlipType.Rotate270FlipY:
					return RotateFlipType.Rotate90FlipNone;
				case RotateFlipType.Rotate270FlipX:
					return RotateFlipType.Rotate270FlipNone;
				case RotateFlipType.RotateNoneFlipX:
					return RotateFlipType.RotateNoneFlipNone;
				case RotateFlipType.Rotate180FlipX:
				case RotateFlipType.Rotate180FlipNone:
					return RotateFlipType.Rotate180FlipNone;
				default:
					return rftPvs;
			}
		}

		internal static Bitmap Crop(this Bitmap bmp, int width, int height)
		{
			int dx = Math.Max((bmp.Width - width) / 2, 0),
				dy = Math.Max((bmp.Height - height) / 2, 0),
				srcWidth = bmp.Width - 2 * dx,
				srcHeight = bmp.Height - 2 * dy;
			RectangleF srcRect = new RectangleF(dx, dy, srcWidth, srcHeight),
					   dstRect = new RectangleF(Math.Max((width - bmp.Width) / 2, 0),
												Math.Max((height - bmp.Height) / 2, 0),
												srcWidth,
												srcHeight);
			var res = new Bitmap(width, height, bmp.PixelFormat);

			using (var g = Graphics.FromImage(res))
				g.DrawImage(bmp, dstRect, srcRect, GraphicsUnit.Pixel);
			return res;
		}
		internal static List<uint> ExtractPanelIDsFromString(string panelsString)
		{
			try
			{
				return panelsString.Split(',')
								   .Select(x => x.Split('-'))
								   .Select(p => new { First = int.Parse(p.First()), Last = int.Parse(p.Last()) })
								   .SelectMany(x => Enumerable.Range(x.First, x.Last - x.First + 1))
								   .OrderBy(z => z)
								   .Select(x => (uint)x)
								   .Distinct()
								   .ToList();
			}
			catch
			{
				return new List<uint>();
			}
		}

		internal static Bitmap GetVideoImageFromSharedFolder(string uriVideo)
		{
			if (string.IsNullOrWhiteSpace(uriVideo) || !File.Exists(uriVideo))
				return null;

			try
			{
				return new Bitmap(uriVideo);
			}
			catch (Exception ex)
			{
				MessageBox.Show(@"Failed to create video image from file, defaulting to empty." + Environment.NewLine + ex.Message,
								@"Defect Video Image",
								MessageBoxButtons.OK);
			}

			return null;
		}
	}

	internal class DetailedPhysicalLayerInfo : BasicPhysicalLayerInfo
	{

		public Bitmap DefectImage { get; set; }
		public string LastError { get; set; }
		public eStatus Status { get; set; }
		public override string ToString()
		{
			return $"{Status}: #{PhysicalLayerID}, {CurrentItem}/{TotalItems}";
		}
	}

	internal class BasicPhysicalLayerInfo
	{
		public int ID { get; set; }
		public uint PhysicalLayerID { get; set; }
		public ulong CurrentItem { get; set; }
		public int TotalItems { get; set; }
		public double Duration { get; set; }
	}

	internal enum ConversionMode
	{
		Schema,
		Job,
		Layer,
		Lot
	}
	internal enum eStatus
	{
		Initializing,
		Processing,
		Done,
		Cancelled,
		Failed,
	}
}
