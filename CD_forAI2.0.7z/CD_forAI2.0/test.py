# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 13:58:33 2022

@author: AOI
"""
import os
#import time
import argparse
import torch
from torch.utils.data import DataLoader
import change_detection_pytorch as cdp
from change_detection_pytorch.datasets import LEVIR_CD_Dataset
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

def set_arg():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", help="set name", type=str, default='Unet_best_model')
    parser.add_argument("--dataroot", help="set test data path. Ex:./data/test/", type=str, default='./datasets/test1/')
    parser.add_argument("--input_nc", help="number of image channel. gray=1,color=3", type=int, default=3)
    parser.add_argument("--crop_size", help="set_model_img_size", type=int, default=512)
    return parser.parse_args()

if __name__ == '__main__':
    args = set_arg()
    if os.path.exists('.\\result\\'+args.name)==False:
        os.makedirs('.\\result\\'+args.name)
        print('make Output directory : ./onnx/')
        
    model = torch.load('./model/' + args.name + '.pt')
    Valid_data = args.dataroot + 'test'
    all_file_name = os.listdir(os.path.realpath(Valid_data)+'\A')
    suffix = os.path.splitext(all_file_name[0])[1]
    valid_dataset = LEVIR_CD_Dataset(Valid_data,
                                     sub_dir_1='A',
                                     sub_dir_2='B',
                                     img_suffix=suffix,
                                     size=args.crop_size,
                                     debug=False,
                                     test_mode=True)
    
    valid_loader = DataLoader(valid_dataset, batch_size=1, shuffle=False, num_workers=0)
    
    loss = cdp.utils.losses.CrossEntropyLoss()
    metrics = [
        cdp.utils.metrics.Fscore(activation='argmax2d'),
        cdp.utils.metrics.Precision(activation='argmax2d'),
        cdp.utils.metrics.Recall(activation='argmax2d'),
    ]
    
    valid_epoch = cdp.utils.train.ValidEpoch(
        model,
        loss=loss,
        metrics=metrics,
        device=DEVICE,
        verbose=True,)
    
    #start = time.time()
    valid_epoch.infer_vis(valid_loader ,evaluate=False ,save=True, slide=False, save_dir='.\\result\\'+args.name)
    #TT = time.time()-start
    print('Testing successful.')
