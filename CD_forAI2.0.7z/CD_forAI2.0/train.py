import torch
import argparse
import os
from torch.utils.data import DataLoader, Dataset
import albumentations as A
import change_detection_pytorch as cdp
from change_detection_pytorch.datasets import LEVIR_CD_Dataset, SVCD_Dataset
from change_detection_pytorch.utils.lr_scheduler import GradualWarmupScheduler
from change_detection_pytorch.datasets.transforms.albu import ChunkImage, ToTensorTest
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


def set_arg():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataroot", help="set train and test data path. Ex:./datasets/", type=str, default='./datasets/test1/')
    parser.add_argument("--name", help="set name", type=str, default='test')
    parser.add_argument("--batch_size", help="set batch size of train and test", type=int, default=4)    
    parser.add_argument("--input_nc", help="number of image channel. gray=1,color=3", type=int, default=3)    
    parser.add_argument("--crop_size", help="set_model_img_size", type=int, default=512)
    parser.add_argument("--n_epochs", help="set training epoch", type=int, default=10)
    parser.add_argument("--learning_rate", help="set learning rate", type=float, default=0.0001)
    parser.add_argument("--continue_train", help="true or flase retrain",action='store_true')
    return parser.parse_args()

if __name__ == '__main__':
    args = set_arg()
    Train_data = args.dataroot + 'train'
    Valid_data = args.dataroot + 'valid'
    
    if os.path.exists('.\\model'):
        print("Model directory already exists: ./model/")
    else :
        os.makedirs('.\\model\\')
        print('make Output directory : ./output/')
    
    if args.continue_train == True:
        model = torch.load('./model/' + args.name + '.pt')
        print('\nload pretrain model from '+args.name + '.pt')

    else:
        model = cdp.Unet(
            encoder_name="resnet18",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
            encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
            in_channels=args.input_nc,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
            classes=2,  # model output channels (number of classes in your datasets)
            siam_encoder=True,  # whether to use a siamese encoder
            fusion_form='concat',  # the form of fusing features from two branches. e.g. concat, sum, diff, or abs_diff.
            )
        print('\nload model...')

    all_file_name = os.listdir(os.path.realpath(Train_data)+'\A')
    suffix = os.path.splitext(all_file_name[0])[1]

    train_dataset = LEVIR_CD_Dataset(Train_data,
                                     sub_dir_1='A',
                                     sub_dir_2='B',
                                     img_suffix=suffix,
                                     size=args.crop_size,
                                     ann_dir=Train_data+'/label',
                                     debug=False)
    
    valid_dataset = LEVIR_CD_Dataset(Valid_data,
                                     sub_dir_1='A',
                                     sub_dir_2='B',
                                     img_suffix=suffix,
                                     size=args.crop_size,
                                     ann_dir=Valid_data+'/label',
                                     debug=False,
                                     test_mode=True)
    
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
    valid_loader = DataLoader(valid_dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)
    
    loss = cdp.utils.losses.CrossEntropyLoss()
    metrics = [
        cdp.utils.metrics.Fscore(activation='argmax2d'),
        cdp.utils.metrics.Precision(activation='argmax2d'),
        cdp.utils.metrics.Recall(activation='argmax2d'),
    ]
    
    optimizer = torch.optim.Adam([
        dict(params=model.parameters(), lr=args.learning_rate),
    ])
    
    scheduler_steplr = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50, ], gamma=0.1)
    
    # create epoch runners
    # it is a simple loop of iterating over dataloader`s samples
    train_epoch = cdp.utils.train.TrainEpoch(
        model,
        loss=loss,
        metrics=metrics,
        optimizer=optimizer,
        device=DEVICE,
        verbose=True,)
    
    valid_epoch = cdp.utils.train.ValidEpoch(
        model,
        loss=loss,
        metrics=metrics,
        device=DEVICE,
        verbose=True,)
        
    max_score = 0
    
    for i in range(args.n_epochs):
    
        print('\nEpoch: {}'.format(i))
        train_logs = train_epoch.run(train_loader)
        valid_logs = valid_epoch.run(valid_loader)
        scheduler_steplr.step()
    
        # do something (save model, change lr, etc.)
        if max_score < valid_logs['fscore']:
            max_score = valid_logs['fscore']
            torch.save(model, './model/'+args.name+'.pt')
            print('Model saved!')
    
    #save results (change maps)
    
    # test_transform = A.Compose([
    #     A.Normalize(),ChunkImage(1024),
    #     ToTensorTest(),
    # ], additional_targets={'image_2': 'image'})
    
    # valid_epoch.infer_vis(valid_loader, save=True, slide=True, save_dir='./res')
