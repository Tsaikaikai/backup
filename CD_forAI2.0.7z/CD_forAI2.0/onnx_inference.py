# -*- coding: utf-8 -*-
"""
Created on Wed Dec 28 11:40:39 2022

@author: AOI
"""

import onnxruntime
import numpy as np
import cv2
import torch
def to_numpy(tensor):
    return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

def normalize(img):
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img/255.0
    mean=[0.485, 0.456, 0.406]
    std=[0.229, 0.224, 0.225]
    
    img[..., 0] -= mean[0]
    img[..., 1] -= mean[1]
    img[..., 2] -= mean[2]
    
    img[..., 0] /= std[0]
    img[..., 1] /= std[1]
    img[..., 2] /= std[2]
    return img

onnx_model_path = "./onnx/Unet_best_model.onnx"
img1 = cv2.imread("./onnx/(7)_A.png")
img1 = normalize(img1)
img1 = np.transpose(img1, axes = [2,0,1])
# img1 = cv2.resize(img1, (1024, 1024), interpolation=cv2.INTER_CUBIC)
img2 = cv2.imread("./onnx/(7)_B.png")
img2 = normalize(img2)
img2 = np.transpose(img2, axes = [2,0,1])
# img2 = cv2.resize(img2, (1024, 1024), interpolation=cv2.INTER_CUBIC)

img1 = torch.tensor([img1],dtype=torch.float32)
img2 = torch.tensor([img2],dtype=torch.float32)
# img1 = img1.unsqueeze_(0)
# img2 = img2.unsqueeze_(0)

##onnx测试
session = onnxruntime.InferenceSession(onnx_model_path)
#compute ONNX Runtime output prediction
outputs = session.run(None, {
    "ChangeDetection_input1": to_numpy(img1),
    "ChangeDetection_input2": to_numpy(img2)
})
y_pred = torch.tensor(outputs[0],dtype=torch.float32)

y_pred = torch.argmax(y_pred, dim=1).squeeze().cpu().numpy().round()
y_pred = y_pred * 255
cv2.imwrite("./onnx/(7)_pred.png",y_pred)