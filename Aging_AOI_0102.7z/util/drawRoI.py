import cv2
from time import sleep
import math

# Implement selectROI
class drawRoI:

    def __init__(self, width, height):

        self.drawing = False
        self.width = width
        self.height = height
        self.roi_coordinates = []
        
    def is_intersect(self, coordinates):

        def ccw(A,B,C):
            return (C[1]-A[1]) * (B[0]-A[0]) > (B[1]-A[1]) * (C[0]-A[0])
        
        for i in range(-1, 1):

            A = coordinates[i]
            B = coordinates[i+1]
            C = coordinates[i+2]
            D = coordinates[i+3]
            if ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D) :
                return True

        return False
    
    def get_clockwise_points(self, points):
                
        # 計算兩點之間的弧度
        def calc_angle(p1, p2):
            return math.atan2(p2[1] - p1[1], p2[0] - p1[0])

        if len(points) == 0 : return []

        # 取得中心點
        cx = sum(p[0] for p in points) / len(points)
        cy = sum(p[1] for p in points) / len(points)

        center_point = (cx, cy)

        # 根據中心點對每個點的弧度進行排序，並且使其順時鐘旋轉
        clockwise_points = sorted(points, key=lambda point: -calc_angle(center_point, point))

        return clockwise_points
    
    
    def draw(self, event, x, y, flags, param):

        #x, y = event.x, event.y
        point = [int(x), int(y)]
        
        drawing = False
    
        if event == cv2.EVENT_LBUTTONDOWN:
            if len(self.roi_coordinates) == 4:
                return
            
            self.roi_coordinates.append(point)
            drawing = True

        elif event == cv2.EVENT_RBUTTONDOWN:
            if not self.roi_coordinates:
                return
            self.roi_coordinates.pop()
            drawing = True
            
        if drawing:
            image_copy = self.original_image.copy()

            if len(self.roi_coordinates) == 4:
                if self.is_intersect(self.roi_coordinates): 
                    self.roi_coordinates = self.get_clockwise_points(self.roi_coordinates)

            for i, point in enumerate(self.roi_coordinates):
                image_copy = cv2.circle(image_copy, tuple(point), 11, (0, 0, 255), -1)
                if i >= 1 :
                    image_copy = cv2.line(image_copy, tuple(self.roi_coordinates[i-1]), tuple(self.roi_coordinates[i]), (0, 0, 255), 3) 
                if i == 3 :
                    image_copy = cv2.line(image_copy, tuple(self.roi_coordinates[0]), tuple(self.roi_coordinates[3]), (0, 0, 255), 3)
                
            self.clone_image = image_copy

    
    def show_image(self):
        return self.clone_image


    def call(self, frame, win_name):
        self.original_image = frame
        self.clone_image = frame.copy()
        
        #cv2.namedWindow("Cut Image")
        cv2.setMouseCallback(win_name, self.draw)