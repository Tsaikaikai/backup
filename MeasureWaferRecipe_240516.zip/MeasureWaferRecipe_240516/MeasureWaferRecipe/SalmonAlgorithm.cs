﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MeasureWaferRecipe
{
    public class SalmonAlgorithm
    {
        CAlgorithmConfig Config = new CAlgorithmConfig();

        public SalmonAlgorithm()
        {

        }

        public bool LoadConfig(string ConfigPath)
        {
            try
            {
                Config = Config.ReadXmlConfig(ConfigPath);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SaveConfig(string ConfigPath)
        {
            try
            {
                Config.WriteXmlConfig(ConfigPath);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DoCheckGrinding(HObject SourceImage, ref HObject ResultImage, ref bool Grinding)
        {
            HTuple tempGrinding = new HTuple();
            try
            {
                HalconFunction.CheckBeforeOrAfterGrinding(SourceImage, out ResultImage, Config.GrindingModelPath, Config.UnGrindingModelPath,
                    Config.GrindingRotate, Config.GrindingMinScore, Config.GrindingOpenClose, out tempGrinding);

                Grinding = Convert.ToBoolean((int)tempGrinding);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("CheckGrinding Fail.", ex);
            }
            finally
            {
                tempGrinding.Dispose();
            }
        }

        public bool DoAlignment(HObject[] SourceImageArr, ref HObject AlignedImage, ref HObject LineScanNotchImage, ref int NotchLocate, ref HTuple CropRows, ref HTuple CropCols)
        {
            HObject concatImage = new HObject();
            HObject ho_rawImage = new HObject();
            HObject tempAlignImg = new HObject();
            HObject tempNotchImg = new HObject();
            HTuple tempRows = new HTuple();
            HTuple tempCols = new HTuple();
            HTuple hv_ErrMsg = new HTuple();
            HTuple NotchModel = new HTuple();
            HTuple tempNotchRow = new HTuple();
            HTuple tempNotchColumn = new HTuple();
            try
            {
                //check image size
                if (SourceImageArr.Length == Config.LineScanSlice)
                {
                    int eachH = Config.LineScanHeight / Config.LineScanSlice;

                    Parallel.For(0, SourceImageArr.Length, i =>
                    //for (int i = 0; i < SourceImageArr.Length; i++)
                    {
                        HOperatorSet.GetImageSize(SourceImageArr[i], out HTuple w, out HTuple h);
                        if (w != Config.LineScanWidth || h != eachH)
                        {
                            throw new Exception("Image size not match. Input WH: " +
                                w.ToString() + "," + h.ToString() +
                                ". But Setting : " +
                                Convert.ToString(Config.LineScanWidth) + "," + Convert.ToString(eachH)
                                );
                        }
                    });
                    //}
                }
                else
                {
                    throw new Exception("Image slice number not match. Input : " +
                        Convert.ToString(SourceImageArr.Length) +
                        " slice. But Setting : " +
                        Convert.ToString(Config.LineScanSlice) + " slice."
                        );
                }

                //TileImages
                concatImage.Dispose();
                HOperatorSet.GenEmptyObj(out concatImage);
                foreach (HObject hobj_temp in SourceImageArr)
                {
                    HOperatorSet.ConcatObj(concatImage, hobj_temp, out concatImage);
                }
                ho_rawImage.Dispose();
                HOperatorSet.TileImages(concatImage, out ho_rawImage, 1, "vertical");

                tempAlignImg.Dispose();
                HalconFunction.AlignmentNotchAndPutCenter(ho_rawImage, out tempAlignImg, Config.NotchModelPath, Config.AlignMinScore, Config.SearchScaleRange,Config.SearchAngleRange,
                    out tempNotchRow,out tempNotchColumn);

                if (tempNotchRow > Config.LineScanHeight)
                {
                    tempNotchRow = tempNotchRow - Config.LineScanHeight;
                }
                //check notch exist
                if (tempNotchRow.D == -1)
                {
                    throw new Exception("Can't find LineScan Notch in image.");
                }

                NotchModel.Dispose();
                HOperatorSet.ReadShapeModel(Config.NotchModelPath, out NotchModel);

                tempNotchImg.Dispose();
                HalconFunction.CalculateEdgePntAndCropNotch(tempAlignImg, out tempNotchImg, NotchModel,
                    Config.CropNotchWidth, Config.InsideInspectWidth, Config.LineScanPixelSize, Config.CropSize, Config.AlignMinScore,
                    Config.MeasureThrshold, Config.MeasureSigma,Config.SearchScaleRange,Config.SearchAngleRange,Config.AlignMinScore,
                    out tempRows, out tempCols,out hv_ErrMsg);

                AlignedImage = new HObject(tempAlignImg);
                LineScanNotchImage = new HObject(tempNotchImg);
                NotchLocate = Convert.ToInt32(tempNotchRow.D);
                CropRows = new HTuple(tempRows);
                CropCols = new HTuple(tempCols);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Alignment Fail.", ex);
            }
            finally
            {
                concatImage.Dispose();
                ho_rawImage.Dispose();
                NotchModel.Dispose();
                tempAlignImg.Dispose();
                tempNotchImg.Dispose();
                tempRows.Dispose();
                tempCols.Dispose();
                hv_ErrMsg.Dispose();
                tempNotchRow.Dispose();
                tempNotchColumn.Dispose();
            }
        }

        public bool DoNotchMeasure(HObject[] AreaNotchImageArr, ref HObject ResultImage, ref NotchMeasureResult Result)
        {
            List<NotchMeasureResult> totalResult = new List<NotchMeasureResult>();
            HTuple hv_Mean_L = new HTuple();
            HTuple hv_Mean_R = new HTuple();
            HTuple hv_Mean_T = new HTuple();
            HTuple hv_Mean_B = new HTuple();
            HTuple hv_RectangleL = new HTuple();
            HTuple hv_RectangleR = new HTuple();
            HTuple hv_RectangleT = new HTuple();
            HTuple hv_RectangleB = new HTuple();
            HTuple hv_Deviation_L = new HTuple();
            HTuple hv_Deviation_R = new HTuple();
            HTuple hv_Deviation_T = new HTuple();
            HTuple hv_Deviation_B = new HTuple();
            HTuple hv_Min_L = new HTuple();
            HTuple hv_Min_R = new HTuple();
            HTuple hv_Min_T = new HTuple();
            HTuple hv_Min_B = new HTuple();
            HTuple hv_Max_L = new HTuple();
            HTuple hv_Max_R = new HTuple();
            HTuple hv_Max_T = new HTuple();
            HTuple hv_Max_B = new HTuple();
            HTuple hv_Contrast_L = new HTuple();
            HTuple hv_Contrast_R = new HTuple();
            HTuple hv_Contrast_T = new HTuple();
            HTuple hv_Contrast_B = new HTuple();

            HTuple hv_raw = new HTuple();
            HTuple hv_col = new HTuple();

            List<double> listVh = new List<double>();
            List<double> listVw = new List<double>();
            List<double> listVr = new List<double>();
            List<double> listP1 = new List<double>();
            List<double> listP2 = new List<double>();
            List<double> listAngV = new List<double>();
            List<double> listVR1 = new List<double>();
            List<double> listVR2 = new List<double>();

            HObject outputResultImage = new HObject();

            try
            {
                //measure each image
                //for (int i = 0; i < AreaNotchImageArr.Length; i++)
                Parallel.For(0, AreaNotchImageArr.Length, i =>
                {

                    HObject ho_ResultImage = new HObject();
                    HObject ho_OrgImage = new HObject();
                    HTuple hv_Vh = new HTuple();
                    HTuple hv_Vw = new HTuple();
                    HTuple hv_Vr = new HTuple();
                    HTuple hv_P1 = new HTuple();
                    HTuple hv_P2 = new HTuple();
                    HTuple hv_AngV = new HTuple();
                    HTuple hv_VR1 = new HTuple();
                    HTuple hv_VR2 = new HTuple();
                    HTuple hv_ErrorMsg = new HTuple();
                    NotchMeasureResult eachResult = new NotchMeasureResult();
                    try
                    {
                        //check image
                        HalconFunction.CheckWaferAndNotchGray(AreaNotchImageArr[i], Config.NotchMeasureCheckRate,
                            out hv_Mean_L, out hv_Mean_R, out hv_Mean_T, out hv_Mean_B,
                            out hv_RectangleL, out hv_RectangleR, out hv_RectangleT, out hv_RectangleB,
                            out hv_Deviation_L, out hv_Deviation_R, out hv_Deviation_T, out hv_Deviation_B,
                            out hv_Min_L, out hv_Min_R, out hv_Min_T, out hv_Min_B,
                            out hv_Max_L, out hv_Max_R, out hv_Max_T, out hv_Max_B,
                            out hv_Contrast_L, out hv_Contrast_R, out hv_Contrast_T, out hv_Contrast_B);

                        if (hv_Mean_T > 5 || hv_Mean_B < 254 || hv_Min_B < 200)
                        {
                            throw new Exception("Input image is not in spec.");
                        }
                        //check notch exist
                        HalconFunction.CheckNotchExist(AreaNotchImageArr[i], Config.NotchAreaModelPath, Config.NotchMatchMinScore, out hv_raw, out hv_col);
                        if (hv_raw.Length == 0 || hv_col.Length == 0)
                        {
                            throw new Exception("Can't find area scan notch.");
                        }

                        //do
                        ho_ResultImage.Dispose();
                        ho_OrgImage.Dispose();
                        HalconFunction.MeasureNotch(AreaNotchImageArr[i], out ho_ResultImage, out ho_OrgImage,
                             Config.NotchMeasurePixSize, Config.NotchMeasureRotate, Config.NotchMeasureResizeRate, Config.NotchGrayMin,
                             Config.B1Ang, Config.B2Ang, Config.U1, Config.U2, Config.RWidthLeft,
                             Config.RWidthRight, Config.PinR, Config.VRAng, Config.NotchAreaModelPath, Config.NotchMatchMinScore, out hv_Vh, out hv_Vw,
                            out hv_Vr, out hv_P1, out hv_P2, out hv_AngV, out hv_VR1,
                            out hv_VR2, out hv_ErrorMsg);

                        //Measurement OK
                        if (hv_Vh.Type != HTupleType.EMPTY &&
                        hv_Vw.Type != HTupleType.EMPTY &&
                        hv_Vr.Type != HTupleType.EMPTY &&
                        hv_P1.Type != HTupleType.EMPTY &&
                        hv_P2.Type != HTupleType.EMPTY &&
                        hv_AngV.Type != HTupleType.EMPTY &&
                        hv_VR1.Type != HTupleType.EMPTY &&
                        hv_VR2.Type != HTupleType.EMPTY
                        )
                        {

                            eachResult.Vh = new HTuple(hv_Vh);
                            eachResult.Vw = new HTuple(hv_Vw);
                            eachResult.Vr = new HTuple(hv_Vr);
                            eachResult.P1 = new HTuple(hv_P1);
                            eachResult.P2 = new HTuple(hv_P2);
                            eachResult.AngV = new HTuple(hv_AngV);
                            eachResult.Vr1 = new HTuple(hv_VR1);
                            eachResult.Vr2 = new HTuple(hv_VR2);
                            totalResult.Add(eachResult);
                            outputResultImage = new HObject(ho_ResultImage);
                        }
                    }
                    catch (Exception)
                    {
                    }
                    finally
                    {
                        ho_ResultImage.Dispose();
                        ho_OrgImage.Dispose();
                        hv_Vh.Dispose();
                        hv_Vw.Dispose();
                        hv_Vr.Dispose();
                        hv_P1.Dispose();
                        hv_P2.Dispose();
                        hv_AngV.Dispose();
                        hv_VR1.Dispose();
                        hv_VR2.Dispose();
                        hv_ErrorMsg.Dispose();
                    }
                });
                //}

                if (totalResult.Count != 0)
                {
                    //average
                    foreach (NotchMeasureResult result in totalResult)
                    {
                        listVh.Add(result.Vh);
                        listVw.Add(result.Vw);
                        listVr.Add(result.Vr);
                        listP1.Add(result.P1);
                        listP2.Add(result.P2);
                        listAngV.Add(result.AngV);
                        listVR1.Add(result.Vr1);
                        listVR2.Add(result.Vr2);
                    }

                    Result.Vh = listVh.Average();
                    Result.Vw = listVw.Average();
                    Result.Vr = listVr.Average();
                    Result.P1 = listP1.Average();
                    Result.P2 = listP2.Average();
                    Result.AngV = listAngV.Average();
                    Result.Vr1 = listVR1.Average();
                    Result.Vr2 = listVR2.Average();

                    ResultImage = new HObject(outputResultImage);
                    return true;
                }
                else
                {
                    Result.Vh = 9999;
                    Result.Vw = 9999;
                    Result.Vr = 9999;
                    Result.P1 = 9999;
                    Result.P2 = 9999;
                    Result.AngV = 9999;
                    Result.Vr1 = 9999;
                    Result.Vr2 = 9999;
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Notch Measure Fail.", ex);
            }
            finally
            {
                outputResultImage.Dispose();

                hv_Mean_L.Dispose();
                hv_Mean_R.Dispose();
                hv_Mean_T.Dispose();
                hv_Mean_B.Dispose();
                hv_RectangleL.Dispose();
                hv_RectangleR.Dispose();
                hv_RectangleT.Dispose();
                hv_RectangleB.Dispose();
                hv_Deviation_L.Dispose();
                hv_Deviation_R.Dispose();
                hv_Deviation_T.Dispose();
                hv_Deviation_B.Dispose();
                hv_Min_L.Dispose();
                hv_Min_R.Dispose();
                hv_Min_T.Dispose();
                hv_Min_B.Dispose();
                hv_Max_L.Dispose();
                hv_Max_R.Dispose();
                hv_Max_T.Dispose();
                hv_Max_B.Dispose();
                hv_Contrast_L.Dispose();
                hv_Contrast_R.Dispose();
                hv_Contrast_T.Dispose();
                hv_Contrast_B.Dispose();

                hv_raw.Dispose();
                hv_col.Dispose();

                totalResult.Clear();
            }
        }

        public bool DoNotchInspect(HObject LineScanNotchImage, ref HObject ResultImage, ref List<Rectangle> TotalGlobalDefectList)
        {
            List<Rectangle> tempTotalGlobalDefectList = new List<Rectangle>();

            HTuple hv_Mean_L = new HTuple();
            HTuple hv_Mean_R = new HTuple();
            HTuple hv_Mean_T = new HTuple();
            HTuple hv_Mean_B = new HTuple();
            HTuple hv_RectangleL = new HTuple();
            HTuple hv_RectangleR = new HTuple();
            HTuple hv_RectangleT = new HTuple();
            HTuple hv_RectangleB = new HTuple();
            HTuple hv_Deviation_L = new HTuple();
            HTuple hv_Deviation_R = new HTuple();
            HTuple hv_Deviation_T = new HTuple();
            HTuple hv_Deviation_B = new HTuple();
            HTuple hv_Min_L = new HTuple();
            HTuple hv_Min_R = new HTuple();
            HTuple hv_Min_T = new HTuple();
            HTuple hv_Min_B = new HTuple();
            HTuple hv_Max_L = new HTuple();
            HTuple hv_Max_R = new HTuple();
            HTuple hv_Max_T = new HTuple();
            HTuple hv_Max_B = new HTuple();
            HTuple hv_Contrast_L = new HTuple();
            HTuple hv_Contrast_R = new HTuple();
            HTuple hv_Contrast_T = new HTuple();
            HTuple hv_Contrast_B = new HTuple();

            HTuple defectNum = new HTuple();
            HTuple hv_DefectRow1 = new HTuple();
            HTuple hv_DefectCol1 = new HTuple();
            HTuple hv_DefectRow2 = new HTuple();
            HTuple hv_DefectCol2 = new HTuple();

            try
            {
                //check image
                HalconFunction.CheckWaferAndNotchGray(LineScanNotchImage, Config.NotchInspectCheckRate, out hv_Mean_L,
                    out hv_Mean_R, out hv_Mean_T, out hv_Mean_B, out hv_RectangleL,
                    out hv_RectangleR, out hv_RectangleT, out hv_RectangleB,
                    out hv_Deviation_L, out hv_Deviation_R, out hv_Deviation_T,
                    out hv_Deviation_B, out hv_Min_L, out hv_Min_R, out hv_Min_T,
                    out hv_Min_B, out hv_Max_L, out hv_Max_R, out hv_Max_T,
                    out hv_Max_B, out hv_Contrast_L, out hv_Contrast_R, out hv_Contrast_T,
                    out hv_Contrast_B);

                if (hv_Contrast_R > 0.1 || hv_Mean_R < 254 || hv_Mean_L > 200)
                {
                    throw new Exception("Input image is not in spec." +
                                        "\nContrast_Right = " + hv_Contrast_R +
                                        "\nMean_Right = " + hv_Mean_R +
                                        "\nMean_Left = " + hv_Mean_L);
                }

                HalconFunction.InspectNotchDefect_v2(LineScanNotchImage, out ResultImage, out HObject teachImage, out HObject teachCoutour,
                    Config.BackWhiteMinGray, Config.NotchInspectDisplayDilation, Config.NotchInnerDefectMaxGray, Config.NotchVmRowUp, Config.NotchVmRowDown,
                    Config.NotchBlackWidth, Config.InnerDefectMinWidth, Config.OutDefectMinWidth, out defectNum,
                    out hv_DefectRow1, out hv_DefectCol1, out hv_DefectRow2, out hv_DefectCol2);

                Parallel.For(0, hv_DefectRow1.Length, j =>
                {
                    Rectangle defectLocate = new Rectangle(hv_DefectCol1[j], hv_DefectRow1[j],
                                                           hv_DefectCol2[j] - hv_DefectCol1[j],
                                                           hv_DefectRow2[j] - hv_DefectRow1[j]);
                    tempTotalGlobalDefectList.Add(defectLocate);
                });

                TotalGlobalDefectList = new List<Rectangle>(tempTotalGlobalDefectList);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Notch Inspect Fail : ", ex);
            }
            finally
            {
                tempTotalGlobalDefectList.Clear();
                hv_Mean_L.Dispose();
                hv_Mean_R.Dispose();
                hv_Mean_T.Dispose();
                hv_Mean_B.Dispose();
                hv_RectangleL.Dispose();
                hv_RectangleR.Dispose();
                hv_RectangleT.Dispose();
                hv_RectangleB.Dispose();
                hv_Deviation_L.Dispose();
                hv_Deviation_R.Dispose();
                hv_Deviation_T.Dispose();
                hv_Deviation_B.Dispose();
                hv_Min_L.Dispose();
                hv_Min_R.Dispose();
                hv_Min_T.Dispose();
                hv_Min_B.Dispose();
                hv_Max_L.Dispose();
                hv_Max_R.Dispose();
                hv_Max_T.Dispose();
                hv_Max_B.Dispose();
                hv_Contrast_L.Dispose();
                hv_Contrast_R.Dispose();
                hv_Contrast_T.Dispose();
                hv_Contrast_B.Dispose();

                defectNum.Dispose();
                hv_DefectRow1.Dispose();
                hv_DefectCol1.Dispose();
                hv_DefectRow2.Dispose();
                hv_DefectCol2.Dispose();
            }
        }

        public bool DoDiameterMeasure(HObject AlignedImage, ref double Diameter)
        {
            HTuple hv_EdgeY = new HTuple();
            HTuple hv_EdgeX = new HTuple();
            List<double> totalDiameter = new List<double>();

            try
            {
                //SourceImage 必須將 Notch 置中
                HalconFunction.MeasureEdgePoints(AlignedImage, Config.Direction, Config.Sigma,
                    Config.Amplitude, Config.MeasurePosLength, Config.MeasurePosWidth, Config.MeasureGap,
                    out hv_EdgeY, out hv_EdgeX);

                //去除 Notch 位置，及圓形對面的點
                double[] totalX = hv_EdgeX.ToDArr();
                double[] totalY = hv_EdgeY.ToDArr();

                int skipStart = (Config.LineScanHeight / 2) - (Config.NotchWidth / 2);
                int skipEnd = (Config.LineScanHeight / 2) + (Config.NotchWidth / 2);

                for (int i = 0; i < totalY.Length; i++)
                {
                    if (totalY[i] > (Config.NotchWidth / 2) && totalY[i] < skipStart)
                    {
                        totalDiameter.Add(totalX[i]);
                    }

                    if (totalY[i] > skipEnd && totalY[i] < (Config.LineScanHeight - (Config.NotchWidth / 2)))
                    {
                        totalDiameter.Add(totalX[i]);
                    }
                }

                double calculateDiameter = totalDiameter.Average();

                //偏心校正
                Diameter = Config.Alpha * calculateDiameter + Config.Beta;

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Diameter Measure Fail.", ex);
            }
            finally
            {
                hv_EdgeY.Dispose();
                hv_EdgeX.Dispose();
                totalDiameter.Clear();
            }
        }

        public bool DoDefectInspectTop(HObject SourceImage, HTuple CropRows, HTuple CropCols, ref HObject ResultImage, ref List<InspectDefect> TotalDefectList)
        {
            object locker1 = new object();
            object locker2 = new object();
            List<DefectInspectCropImage> tempImageList = new List<DefectInspectCropImage>();
            TotalDefectList?.Clear();
            TotalDefectList = new List<InspectDefect>();

            try
            {
                if (CropRows.Length != CropCols.Length)
                {
                    throw new Exception("DefectInspect Fail. => Number of CropRows and CropCols not match.");
                }

                //Parallel.For(0, CropRows.Length, i =>
                for (int i = 0; i < CropRows.Length; i++)
                {
                    HObject cropImage = new HObject();
                    HObject cropAiImage = new HObject();
                    DefectInspectCropImage image = new DefectInspectCropImage();
                    HObject tempCropResultImage = new HObject();
                    List<InspectDefect> tempDefectList = new List<InspectDefect>();
                    HTuple hv_AoiDefectNumber = new HTuple();
                    HTuple hv_DefectRow1 = new HTuple();
                    HTuple hv_DefectCol1 = new HTuple();
                    HTuple hv_DefectRow2 = new HTuple();
                    HTuple hv_DefectCol2 = new HTuple();
                    HTuple hv_AiDefectNumber = new HTuple();
                    HTuple hv_Area = new HTuple();

                    try
                    {
                        cropImage.Dispose();
                        cropAiImage.Dispose();
                        tempCropResultImage.Dispose();

                        HalconFunction.CropDomainImage(SourceImage, out cropImage, out cropAiImage, Config.LineScanPixelSize,
                                                       Config.CropSize, Config.InsideInspectWidth, CropRows[i], CropCols[i], Config.AIDrawStartX);

                        HalconFunction.InspectWaferEdgeDefectAndDrawAi(cropImage, cropAiImage,
                                               out tempCropResultImage, Config.ROIWidthtoBevelCenterT, Config.BevelWidthT,
                                               Config.DisplayDilation, Config.BevelDefectMaxGrayT, Config.AIDefectSize,
                                               Config.AIMinGray, Config.InnerDefectAreaSizeT, Config.InnerDefectMaxGrayT, Config.OutDefectMinWidth,
                                               Convert.ToInt16(Config.PaintResult), Convert.ToInt16(Config.HaveSecondEdge), Config.LineBypassWidth,
                                               Config.GammaT, Config.FindLineMaskT, Config.FindLineLowT, Config.FindLineHighT, Convert.ToInt16(Config.OnlyInspectEdge),
                                               out hv_AoiDefectNumber, out hv_DefectRow1, out hv_DefectCol1,
                                               out hv_DefectRow2, out hv_DefectCol2, out hv_AiDefectNumber, out hv_Area);


                        Parallel.For(0, hv_DefectRow1.Length, j =>
                        //for (int j = 0; j < hv_DefectRow1.Length; j++)
                        {
                            Rectangle tempLocalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow1.DArr[j],
                                                                        (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                            Rectangle tempGlobalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j] + (Int32)CropCols.DArr[i],
                                                                        (Int32)hv_DefectRow1.DArr[j] + (Int32)CropRows.DArr[i],
                                                                        (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                            double tempAngle = (tempGlobalPosition.Y - (Config.LineScanHeight / 2)) / (double)Config.LineScanHeight * 360.0;
                            if (tempAngle < 0) tempAngle = tempAngle + 360;

                            InspectDefect tempDefect = new InspectDefect();
                            tempDefect.Angle = tempAngle;
                            tempDefect.Area = (Int32)hv_Area.DArr[j];
                            tempDefect.LocalPosition = tempLocalPosition;
                            tempDefect.GlobalPosition = tempGlobalPosition;
                            lock (locker1)
                            {
                                tempDefectList.Add(tempDefect);
                            }
                        });

                        image.SourceCropImage = new HObject(cropImage);
                        image.CropResultImage = new HObject(tempCropResultImage);
                        image.GlobalX = (Int32)CropCols.DArr[i];
                        image.GlobalY = (Int32)CropRows.DArr[i];
                        image.DefectList = new List<InspectDefect>(tempDefectList);

                        lock (locker2)
                        {
                            tempImageList.Add(image);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Defect Inspect Fail : ", ex);
                    }
                    finally
                    {
                        cropImage.Dispose();
                        cropAiImage.Dispose();
                        tempCropResultImage.Dispose();
                        tempDefectList.Clear();
                        hv_AoiDefectNumber.Dispose();
                        hv_DefectRow1.Dispose();
                        hv_DefectCol1.Dispose();
                        hv_DefectRow2.Dispose();
                        hv_DefectCol2.Dispose();
                        hv_AiDefectNumber.Dispose();
                        hv_Area.Dispose();
                    }
                    //});
                }
                //sort list by GlobalY
                //imageList.Sort(new ImageYComparer());
                List<DefectInspectCropImage> imageList = new List<DefectInspectCropImage>
                    (
                    tempImageList.OrderBy(DefectInspectCropImage => DefectInspectCropImage.GlobalY).ToList()
                    );

                //Tile Images and merge global defect
                HObject[] cropResultImages = new HObject[imageList.Count()];
                for (int i = 0; i < imageList.Count(); i++)
                {
                    cropResultImages[i] = imageList[i].CropResultImage;
                    TotalDefectList = TotalDefectList.Concat(imageList[i].DefectList).ToList();
                }

                ResultImage.Dispose();
                HalconFunction.TileAllImages(cropResultImages, out ResultImage);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Defect Inspect Fail : ", ex);
            }
            finally
            {
                tempImageList.Clear();
            }
        }

        public bool DoDefectInspectBottom(HObject SourceImage, HTuple CropRows, HTuple CropCols, ref HObject ResultImage, ref List<InspectDefect> TotalDefectList)
        {
            object locker1 = new object();
            object locker2 = new object();
            List<DefectInspectCropImage> tempImageList = new List<DefectInspectCropImage>();
            TotalDefectList?.Clear();
            TotalDefectList = new List<InspectDefect>();

            try
            {
                if (CropRows.Length != CropCols.Length)
                {
                    throw new Exception("DefectInspect Fail. => Number of CropRows and CropCols not match.");
                }

                //Parallel.For(0, CropRows.Length, i =>
                for (int i = 0; i < CropRows.Length; i++)
                {
                    HObject cropImage = new HObject();
                    HObject cropAiImage = new HObject();
                    DefectInspectCropImage image = new DefectInspectCropImage();
                    HObject tempCropResultImage = new HObject();
                    List<InspectDefect> tempDefectList = new List<InspectDefect>();
                    HTuple hv_AoiDefectNumber = new HTuple();
                    HTuple hv_DefectRow1 = new HTuple();
                    HTuple hv_DefectCol1 = new HTuple();
                    HTuple hv_DefectRow2 = new HTuple();
                    HTuple hv_DefectCol2 = new HTuple();
                    HTuple hv_AiDefectNumber = new HTuple();
                    HTuple hv_Area = new HTuple();

                    try
                    {
                        cropImage.Dispose();
                        cropAiImage.Dispose();
                        tempCropResultImage.Dispose();

                        HalconFunction.CropDomainImage(SourceImage, out cropImage, out cropAiImage, Config.LineScanPixelSize, Config.CropSize,
                                                       Config.InsideInspectWidth, CropRows[i], CropCols[i], Config.AIDrawStartX);

                        HalconFunction.InspectWaferEdgeDefectAndDrawAi(cropImage, cropAiImage,
                           out tempCropResultImage, Config.ROIWidthtoBevelCenterB, Config.BevelWidthB,
                             Config.DisplayDilation, Config.BevelDefectMaxGrayB, Config.AIDefectSize,
                             Config.AIMinGray, Config.InnerDefectAreaSizeB, Config.InnerDefectMaxGrayB, Config.OutDefectMinWidth,
                             Convert.ToInt16(Config.PaintResult), Convert.ToInt16(Config.HaveSecondEdge), Config.LineBypassWidth,
                            Config.GammaB, Config.FindLineMaskB, Config.FindLineLowB, Config.FindLineHighB, Convert.ToInt16(Config.OnlyInspectEdge),
                            out hv_AoiDefectNumber, out hv_DefectRow1, out hv_DefectCol1,
                           out hv_DefectRow2, out hv_DefectCol2, out hv_AiDefectNumber, out hv_Area);

                        Parallel.For(0, hv_DefectRow1.Length, j =>
                        //for (int j = 0; j < hv_DefectRow1.Length; j++)
                        {

                            Rectangle tempLocalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow1.DArr[j],
                                                                        (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                            Rectangle tempGlobalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j] + (Int32)CropCols.DArr[i],
                                                                        (Int32)hv_DefectRow1.DArr[j] + (Int32)CropRows.DArr[i],
                                                                        (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                        (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                            double tempAngle = (tempGlobalPosition.Y - (Config.LineScanHeight / 2)) / (double)Config.LineScanHeight * 360.0;
                            if (tempAngle < 0) tempAngle = tempAngle + 360;

                            InspectDefect tempDefect = new InspectDefect();
                            tempDefect.Angle = tempAngle;
                            tempDefect.Area = (Int32)hv_Area.DArr[j];
                            tempDefect.LocalPosition = tempLocalPosition;
                            tempDefect.GlobalPosition = tempGlobalPosition;
                            lock (locker1)
                            {
                                tempDefectList.Add(tempDefect);
                            }
                        });

                        image.SourceCropImage = new HObject(cropImage);
                        image.CropResultImage = new HObject(tempCropResultImage);
                        image.GlobalX = (Int32)CropCols.DArr[i];
                        image.GlobalY = (Int32)CropRows.DArr[i];
                        image.DefectList = new List<InspectDefect>(tempDefectList);

                        lock (locker2)
                        {
                            tempImageList.Add(image);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Defect Inspect Fail : ", ex);
                    }
                    finally
                    {
                        cropImage.Dispose();
                        cropAiImage.Dispose();
                        tempCropResultImage.Dispose();
                        tempDefectList.Clear();
                        hv_AoiDefectNumber.Dispose();
                        hv_DefectRow1.Dispose();
                        hv_DefectCol1.Dispose();
                        hv_DefectRow2.Dispose();
                        hv_DefectCol2.Dispose();
                        hv_AiDefectNumber.Dispose();
                        hv_Area.Dispose();
                    }

                    //});
                }
                //sort list by GlobalY
                //imageList.Sort(new ImageYComparer());
                List<DefectInspectCropImage> imageList = new List<DefectInspectCropImage>
                                    (
                                    tempImageList.OrderBy(DefectInspectCropImage => DefectInspectCropImage.GlobalY).ToList()
                                    );

                //Tile Images and merge global defect
                HObject[] cropResultImages = new HObject[imageList.Count()];

                for (int i = 0; i < imageList.Count(); i++)
                {
                    cropResultImages[i] = imageList[i].CropResultImage;
                    TotalDefectList = TotalDefectList.Concat(imageList[i].DefectList).ToList();
                }

                ResultImage.Dispose();
                HalconFunction.TileAllImages(cropResultImages, out ResultImage);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Defect Inspect Fail : ", ex);
            }
            finally
            {
                tempImageList.Clear();
            }
        }

        public bool DoEdgeMeasure(HObject[] EdgeSourceImageArr, int NotchLocY, ref List<EdgeMeasureResult> ResultImageList,
            ref EdgeMeasureResultData STDResultData, ref EdgeMeasureResultData AvgResultData, ref EdgeMeasureResultData PpResultData)
        {
            List<EdgeMeasureResult> resultList = new List<EdgeMeasureResult>();
            EdgeMeasureResultData[] statisticResult = new EdgeMeasureResultData[3];
            try
            {
                int lineScanPixGap = Config.LineScanHeight / EdgeSourceImageArr.Length; //120000 / 72 = 1666.66
                int degGap = Config.LineScanHeight / 360; //120000 / 360 = 333.33

                Parallel.For(0, EdgeSourceImageArr.Length, i =>
                //for (int i = 0; i < EdgeSourceImageArr.Length; i++)
                {
                    EdgeMeasureResultData resultData = new EdgeMeasureResultData();
                    EdgeMeasureResult measureResult = new EdgeMeasureResult();

                    HTuple hv_Mean_L = new HTuple();
                    HTuple hv_Mean_R = new HTuple();
                    HTuple hv_Mean_T = new HTuple();
                    HTuple hv_Mean_B = new HTuple();
                    HTuple hv_RectangleL = new HTuple();
                    HTuple hv_RectangleR = new HTuple();
                    HTuple hv_RectangleT = new HTuple();
                    HTuple hv_RectangleB = new HTuple();
                    HTuple hv_Deviation_L = new HTuple();
                    HTuple hv_Deviation_R = new HTuple();
                    HTuple hv_Deviation_T = new HTuple();
                    HTuple hv_Deviation_B = new HTuple();
                    HTuple hv_Min_L = new HTuple();
                    HTuple hv_Min_R = new HTuple();
                    HTuple hv_Min_T = new HTuple();
                    HTuple hv_Min_B = new HTuple();
                    HTuple hv_Max_L = new HTuple();
                    HTuple hv_Max_R = new HTuple();
                    HTuple hv_Max_T = new HTuple();
                    HTuple hv_Max_B = new HTuple();
                    HTuple hv_Contrast_L = new HTuple();
                    HTuple hv_Contrast_R = new HTuple();
                    HTuple hv_Contrast_T = new HTuple();
                    HTuple hv_Contrast_B = new HTuple();

                    HObject ho_ImageOut = new HObject();
                    HObject ho_rotateImage = new HObject();

                    HTuple hv_A1 = new HTuple();
                    HTuple hv_A2 = new HTuple();
                    HTuple hv_B1 = new HTuple();
                    HTuple hv_B2 = new HTuple();
                    HTuple hv_BC = new HTuple();
                    HTuple hv_C1 = new HTuple();
                    HTuple hv_C2 = new HTuple();
                    HTuple hv_R1 = new HTuple();
                    HTuple hv_R2 = new HTuple();
                    HTuple hv_t = new HTuple();
                    HTuple hv_Ang1 = new HTuple();
                    HTuple hv_Ang2 = new HTuple();
                    HTuple hv_ErrorMsg = new HTuple();
                    HTuple hv_Phi_OrgX_OrgY = new HTuple();
                    HTuple hv_Cir_c1 = new HTuple();
                    HTuple hv_Cir_c2 = new HTuple();
                    HTuple hv_LinesX1 = new HTuple();
                    HTuple hv_LinesY1 = new HTuple();
                    HTuple hv_LinesX2 = new HTuple();
                    HTuple hv_LinesY2 = new HTuple();
                    HTuple hv_TextsText = new HTuple();
                    HTuple hv_TextsX = new HTuple();
                    HTuple hv_TextsY = new HTuple();

                    try
                    {
                        measureResult.SourceImage = EdgeSourceImageArr[i];

                        //check image
                        HalconFunction.CheckWaferAndNotchGray(EdgeSourceImageArr[i], Config.EdgeRegionRate, out hv_Mean_L,
                            out hv_Mean_R, out hv_Mean_T, out hv_Mean_B, out hv_RectangleL,
                            out hv_RectangleR, out hv_RectangleT, out hv_RectangleB,
                            out hv_Deviation_L, out hv_Deviation_R, out hv_Deviation_T,
                            out hv_Deviation_B, out hv_Min_L, out hv_Min_R, out hv_Min_T,
                            out hv_Min_B, out hv_Max_L, out hv_Max_R, out hv_Max_T,
                            out hv_Max_B, out hv_Contrast_L, out hv_Contrast_R, out hv_Contrast_T,
                            out hv_Contrast_B);

                        if (hv_Mean_L < 254 || hv_Mean_R < 254 || hv_Mean_B < 254 ||
                            hv_Deviation_L > 2 || hv_Deviation_R > 2 || hv_Deviation_B > 2)
                        {
                            measureResult.ResultImage = EdgeSourceImageArr[i];
                            measureResult.ProcessStatus = false;
                        }
                        else if (hv_Contrast_T < 0.3)
                        {
                            measureResult.ResultImage = EdgeSourceImageArr[i];
                            measureResult.ProcessStatus = false;
                        }
                        else
                        {
                            //do
                            try
                            {
                                HalconFunction.MeasureWaferEdgeB(EdgeSourceImageArr[i], out ho_ImageOut, out ho_rotateImage,
                                    Config.SidePixelSize, Config.EdgeRotateAngle, Config.EdgeGrayMax,
                                    Config.EdgeRoiY1, Config.EdgeRoiX1, Config.EdgeRoiY2, Config.EdgeRoiX2, Config.A1Ang, Config.A2Ang,
                                    Config.C1Ang, Config.C2Ang, Config.Bu11, Config.Bv11, Config.Bu22,
                                    Config.Bv22, Config.ExAngle, Config.ScaleW, Config.ScaleH, Config.BevelMeasureNum,
                                    out hv_A1, out hv_A2, out hv_B1, out hv_B2, out hv_BC,
                                    out hv_C1, out hv_C2, out hv_R1, out hv_R2, out hv_t,
                                    out hv_Ang1, out hv_Ang2, out hv_ErrorMsg, out hv_Phi_OrgX_OrgY,
                                    out hv_Cir_c1, out hv_Cir_c2, out hv_LinesX1, out hv_LinesY1,
                                    out hv_LinesX2, out hv_LinesY2, out hv_TextsText, out hv_TextsX,
                                    out hv_TextsY);

                                //執行完結果為empty視為失敗填9999
                                resultData.A1 = hv_A1.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_A1);
                                resultData.A2 = hv_A2.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_A2);
                                resultData.B1 = hv_B1.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_B1);
                                resultData.B2 = hv_B2.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_B2);
                                resultData.BC = hv_BC.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_BC);
                                resultData.C1 = hv_C1.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_C1);
                                resultData.C2 = hv_C2.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_C2);
                                resultData.R1 = hv_R1.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_R1);
                                resultData.R2 = hv_R2.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_R2);
                                resultData.t = hv_t.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_t);
                                resultData.Ang1 = hv_Ang1.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_Ang1);
                                resultData.Ang2 = hv_Ang2.Type == HTupleType.EMPTY ? new HTuple(9999) : new HTuple(hv_Ang2);
                                measureResult.ResultImage = new HObject(ho_ImageOut);
                            }
                            catch
                            {
                                //執行時有error視為失敗填9999
                                resultData.A1 = 9999;
                                resultData.A2 = 9999;
                                resultData.B1 = 9999;
                                resultData.B2 = 9999;
                                resultData.BC = 9999;
                                resultData.C1 = 9999;
                                resultData.C2 = 9999;
                                resultData.R1 = 9999;
                                resultData.R2 = 9999;
                                resultData.t = 9999;
                                resultData.Ang1 = 9999;
                                resultData.Ang2 = 9999;
                                measureResult.ResultImage = new HObject(ho_ImageOut);
                            }

                            if (resultData.A1 == 9999 ||
                                resultData.A2 == 9999 ||
                                resultData.B1 == 9999 ||
                                resultData.B2 == 9999 ||
                                resultData.BC == 9999 ||
                                resultData.C1 == 9999 ||
                                resultData.C2 == 9999 ||
                                resultData.R1 == 9999 ||
                                resultData.R2 == 9999 ||
                                resultData.t == 9999 ||
                                resultData.Ang1 == 9999 ||
                                resultData.Ang2 == 9999)
                            {
                                measureResult.ProcessStatus = false;
                            }
                            else
                            {
                                //measure successful
                                measureResult.ProcessStatus = true;
                            }
                        }

                        //calculate angle
                        double transDegree = (double)(i * lineScanPixGap - NotchLocY) / degGap;
                        while (transDegree < 0) transDegree = transDegree + 360;
                        measureResult.CapIndex = i;
                        measureResult.ResultData = resultData;
                        measureResult.Angle = transDegree;
                        resultList.Add(measureResult);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Side Measure Fail.", ex);
                    }
                    finally
                    {
                        hv_Mean_L.Dispose();
                        hv_Mean_R.Dispose();
                        hv_Mean_T.Dispose();
                        hv_Mean_B.Dispose();
                        hv_RectangleL.Dispose();
                        hv_RectangleR.Dispose();
                        hv_RectangleT.Dispose();
                        hv_RectangleB.Dispose();
                        hv_Deviation_L.Dispose();
                        hv_Deviation_R.Dispose();
                        hv_Deviation_T.Dispose();
                        hv_Deviation_B.Dispose();
                        hv_Min_L.Dispose();
                        hv_Min_R.Dispose();
                        hv_Min_T.Dispose();
                        hv_Min_B.Dispose();
                        hv_Max_L.Dispose();
                        hv_Max_R.Dispose();
                        hv_Max_T.Dispose();
                        hv_Max_B.Dispose();
                        hv_Contrast_L.Dispose();
                        hv_Contrast_R.Dispose();
                        hv_Contrast_T.Dispose();
                        hv_Contrast_B.Dispose();

                        ho_ImageOut.Dispose();
                        ho_rotateImage.Dispose();

                        hv_A1.Dispose();
                        hv_A2.Dispose();
                        hv_B1.Dispose();
                        hv_B2.Dispose();
                        hv_BC.Dispose();
                        hv_C1.Dispose();
                        hv_C2.Dispose();
                        hv_R1.Dispose();
                        hv_R2.Dispose();
                        hv_t.Dispose();
                        hv_Ang1.Dispose();
                        hv_Ang2.Dispose();
                        hv_ErrorMsg.Dispose();
                        hv_Phi_OrgX_OrgY.Dispose();
                        hv_Cir_c1.Dispose();
                        hv_Cir_c2.Dispose();
                        hv_LinesX1.Dispose();
                        hv_LinesY1.Dispose();
                        hv_LinesX2.Dispose();
                        hv_LinesY2.Dispose();
                        hv_TextsText.Dispose();
                        hv_TextsX.Dispose();
                        hv_TextsY.Dispose();
                    }
                });
                //};

                //按角度排序並輸出總結果
                ResultImageList = new List<EdgeMeasureResult>(resultList.OrderBy(x => x.Angle).ToList());
                //輸出統計結果
                statisticResult = HalconFunction.StatisticsMeasureEdgeResult(resultList);
                //一倍標準差
                STDResultData = statisticResult[0];
                //平均
                AvgResultData = statisticResult[1];
                //峰對峰值
                PpResultData = statisticResult[2];
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Side Measure Fail.", ex);
            }
            finally
            {
                resultList.Clear();
            }
        }
    }

    [Serializable]
    public class EdgeMeasureResult
    {
        public HObject SourceImage;
        public HObject ResultImage;
        public EdgeMeasureResultData ResultData;
        public double Angle;
        public int CapIndex;
        public bool ProcessStatus;
        public EdgeMeasureResult()
        {
        }

        public EdgeMeasureResult(EdgeMeasureResult r)
        {
            if (r.SourceImage != null) SourceImage = new HObject(r.SourceImage);
            if (r.ResultImage != null) ResultImage = new HObject(r.ResultImage);
            ResultData = new EdgeMeasureResultData(r.ResultData);
            Angle = r.Angle;
            CapIndex = r.CapIndex;
            ProcessStatus = r.ProcessStatus;
        }

        public void Dispose()
        {
            SourceImage?.Dispose();
            ResultImage?.Dispose();
            GC.Collect();
            Thread.Yield();
        }
    }

    [Serializable]
    public class EdgeMeasureResultData
    {
        public double A1 = 9999;
        public double A2 = 9999;
        public double B1 = 9999;
        public double B2 = 9999;
        public double BC = 9999;
        public double C1 = 9999;
        public double C2 = 9999;
        public double R1 = 9999;
        public double R2 = 9999;
        public double t = 9999;
        public double Ang1 = 9999;
        public double Ang2 = 9999;

        public EdgeMeasureResultData()
        {

        }
        public EdgeMeasureResultData(EdgeMeasureResultData d)
        {
            A1 = d.A1;
            A2 = d.A2;
            B1 = d.B1;
            B2 = d.B2;
            BC = d.BC;
            C1 = d.C1;
            C2 = d.C2;
            R1 = d.R1;
            R2 = d.R2;
            t = d.t;
            Ang1 = d.Ang1;
            Ang2 = d.Ang2;
        }
    }

    [Serializable]
    public class NotchMeasureResult
    {
        public double Vh;
        public double Vw;
        public double Vr;
        public double P1;
        public double P2;
        public double AngV;
        public double Vr1;
        public double Vr2;

        public NotchMeasureResult()
        {

        }
        public NotchMeasureResult(NotchMeasureResult r)
        {
            Vh = r.Vh;
            Vw = r.Vw;
            Vr = r.Vr;
            P1 = r.P1;
            P2 = r.P2;
            AngV = r.AngV;
            Vr1 = r.Vr1;
            Vr2 = r.Vr2;
        }
        public void Dispose()
        {
        }
    }

    [Serializable]
    public class DefectInspectCropImage
    {
        public HObject SourceCropImage;
        public HObject CropResultImage;
        public int GlobalX;
        public int GlobalY;
        public List<InspectDefect> DefectList;
        public DefectInspectCropImage()
        {
        }

        public void Dispose()
        {
            SourceCropImage?.Dispose();
            CropResultImage?.Dispose();
            DefectList?.Clear();
        }
    }

    [Serializable]
    public class InspectDefect
    {
        public double Angle;
        public int Area;
        public Rectangle LocalPosition;
        public Rectangle GlobalPosition;

        public InspectDefect()
        {
        }
        public InspectDefect(InspectDefect d)
        {
            Angle = d.Angle;
            Area = d.Area;
            LocalPosition = d.LocalPosition;
            GlobalPosition = d.GlobalPosition;
        }
        public void Dispose()
        {
        }
    }
}
