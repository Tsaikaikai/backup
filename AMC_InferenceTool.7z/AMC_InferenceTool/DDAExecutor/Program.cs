﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using DDABridge;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Windows.Forms;
using AMC_InferenceTool;
using System.Collections.Generic;

namespace DDAExecutor
{
    static class Program
    {
        private static System.Threading.Mutex mutex;
        private static FlaskClient client;
        private static readonly string baseUrl = "http://localhost:5000";

        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            mutex = new System.Threading.Mutex(true, "OnlyRun");

            if (mutex.WaitOne(0, false))
            {
                Form myform = new InferenceTool();
                Application.Run(myform);
            }
            else
            {
                MessageBox.Show("Application is already open！", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
        }

        public static void OriginalTest()
        {
            client = new FlaskClient(baseUrl);

            //TestTrain();
            TestPredict();
            Console.ReadLine();
        }

        public static void TestTrain()
        {
            //string jsonContentString = File.ReadAllText("C:/Users/Administrator/experiment/dda/faster_autoaugment/config/train.json");
            //JObject config = JObject.Parse(jsonContentString);
            JObject config = CreateTrainConfig();

            Console.WriteLine("start");
            var startTrainingResponse = client.StartTraining(config);
            Console.WriteLine(startTrainingResponse);

            var data = JObject.Parse(startTrainingResponse);
            var taskId = data["task_id"].ToString();

            TestGetTaskStatus(taskId);

            Console.WriteLine("stop");
            var stopTrainingResponse = client.StopTraining();
            Console.WriteLine(stopTrainingResponse);
        }

        static void TestGetTaskStatus(string taskId)
        {
            Console.WriteLine("check - 1");
            var taskStatusResponse1 = client.GetTaskStatus(taskId);
            Console.WriteLine(taskStatusResponse1);

            System.Threading.Thread.Sleep(10000);

            Console.WriteLine("check - 2");
            var taskStatusResponse2 = client.GetTaskStatus(taskId);
            Console.WriteLine(taskStatusResponse2);
        }

        static void TestPredict()
        {
            //string jsonContentString = File.ReadAllText("C:/Users/Administrator/experiment/dda/faster_autoaugment/config/predict.json");
            string jsonContentString = File.ReadAllText("D:/NCCU/dda/faster_autoaugment/config/predict.json");
            JObject jsonContent = JObject.Parse(jsonContentString);

            var loadModelResponse = client.LoadModel(jsonContent);
            Console.WriteLine("Load Model Response: " + loadModelResponse);

            JArray imagePaths = new JArray
            {
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G2TH60T0321_C4_4_PM_L92_PL1_TWhiteGapSpot_X2452_Y287_D6997_G664.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G2TH60T0920_C4_3_PM_L92_PL1_TWhiteGapSpot_X518_Y581_D4074_G114.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G3HX50T1211_C4_4_PM_L92_PL1_TWhiteGapSpot_X2473_Y1359_D7029_G1210.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G3HX50T1332_C4_4_PM_L92_PL1_TWhiteGapSpot_X2200_Y191_D6613_G615.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G3HX50T1510_C4_1_PM_L92_PL1_TWhiteGapSpot_X1228_Y548_D1297_G86.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/0/MM11G3HX50T1511_C4_3_PM_L92_PL1_TWhiteGapSpot_X228_Y1976_D3633_G821.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/LA11G8UJ90T3005_C4_4_PM_L92_PL1_TWhiteGapSpot_X1511_Y712_D7204_G838 - #U255c#U255e#U2557s.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/LA11G8UJ90T3005_C4_4_PM_L92_PL1_TWhiteGapSpot_X1511_Y712_D7204_G838.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/LA11G8VM40T0714_C4_1_PM_L92_PL1_TWhiteGapSpot_X1470_Y839_D3044_G388 - #U255c#U255e#U2557s.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/MM11G1TT00T0800_C4_3_PM_L92_PL1_TWhiteGapSpot_X2586_Y1071_D7099_G316 - #U255c#U255e#U2557s.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/MM11G2TH60T1421_C4_4_PM_L92_PL1_TWhiteGapSpot_X952_Y1175_D4714_G1116.bmp",
                "D:/NCCU/dda/faster_autoaugment/data/test/1/MM11G3HX50T1532_C4_1_PM_L92_PL1_TWhiteGapSpot_X1249_Y985_D1329_G305.bmp",
            };
            var predictData = new JObject
            {
                { "image_paths", imagePaths },
                { "config", jsonContent }
            };

            Stopwatch stopwatch = new Stopwatch(); // Create a new stopwatch
            stopwatch.Start(); // Start measuring time

            var predictResponse = client.Predict(predictData);
            Console.WriteLine("Predict Response: " + predictResponse);

            stopwatch.Stop(); // Stop measuring time
            TimeSpan ts = stopwatch.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}.{1:000} seconds", ts.Seconds, ts.Milliseconds);
            Console.WriteLine("Predict RunTime " + elapsedTime);
        }

        public static string TestPredict(string predictJsonPath, JArray imagePaths)
        {
            client = new FlaskClient(baseUrl);
            string jsonContentString = File.ReadAllText(predictJsonPath);
            JObject jsonContent = JObject.Parse(jsonContentString);

            var loadModelResponse = client.LoadModel(jsonContent);
            Console.WriteLine("Load Model Response: " + loadModelResponse);

            var predictData = new JObject
            {
                { "image_paths", imagePaths },
                { "config", jsonContent }
            };

            Stopwatch stopwatch = new Stopwatch(); // Create a new stopwatch
            stopwatch.Start(); // Start measuring time

            var predictResponse = client.Predict(predictData);
            Console.WriteLine("Predict Response: " + predictResponse);

            stopwatch.Stop(); // Stop measuring time
            TimeSpan ts = stopwatch.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}.{1:000} seconds", ts.Seconds, ts.Milliseconds);
            Console.WriteLine("Predict RunTime " + elapsedTime);

            return predictResponse;
        }

        static JObject CreateTrainConfig()
        {
            return new JObject
            {
                { "model", new JObject
                    {
                        { "cls_factor", 1.0 },
                        { "plc_factor", 0.01 },
                        { "gp_factor", 10 },
                        { "name", "wrn28_2" },
                        { "num_classes", 2 },
                        { "temperature", 0.05 },
                        { "num_sub_policies", 10 },
                        { "num_chunks", 8 },
                        { "operation_count", 4 }
                    }
                },
                { "data", new JObject
                    {
                        { "name", "my_experiment_0" },
                        { "train", new JObject
                            {
                                { "path", "data/train" }
                            }
                        },
                        { "test", new JObject
                            {
                                { "path", "data/test" }
                            }
                        },
                        { "batch_size", 192 }
                    }
                },
                { "optim", new JObject
                    {
                        { "epochs", 300 },
                        { "main_lr", 0.001 },
                        { "policy_lr", 0.001 }
                    }
                },
                { "cwd", new JObject
                    {
                        { "path", "C:/Users/test/Desktop/AI_TOOL_NCCU/dda/faster_autoaugment" }
                    }
                },
                { "gpu", 0 },
                { "seed", 1 }
            };
        }

        static JObject CreateTrainConfig(string cwdPath)
        {
            return new JObject
            {
                { "model", new JObject
                    {
                        { "cls_factor", 1.0 },
                        { "plc_factor", 0.01 },
                        { "gp_factor", 10 },
                        { "name", "wrn28_2" },
                        { "num_classes", 2 },
                        { "temperature", 0.05 },
                        { "num_sub_policies", 10 },
                        { "num_chunks", 8 },
                        { "operation_count", 4 }
                    }
                },
                { "data", new JObject
                    {
                        { "name", "my_experiment_0" },
                        { "train", new JObject
                            {
                                { "path", "data/train" }
                            }
                        },
                        { "test", new JObject
                            {
                                { "path", "data/test" }
                            }
                        },
                        { "batch_size", 192 }
                    }
                },
                { "optim", new JObject
                    {
                        { "epochs", 300 },
                        { "main_lr", 0.001 },
                        { "policy_lr", 0.001 }
                    }
                },
                { "cwd", new JObject
                    {
                        { "path", cwdPath }
                    }
                },
                { "gpu", 0 },
                { "seed", 1 }
            };
        }

    }
}
