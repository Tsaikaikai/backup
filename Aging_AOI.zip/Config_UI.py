import os
import tkinter as tk
from tkinter import filedialog, OptionMenu
from tkinter import messagebox
from PIL import Image, ImageTk
import cv2
from util.drawRoI import drawRoI
from util.HsvTool import HsvTool
from util.Aging_detect_config import Aging_detect_config
import json
import ast
import numpy as np
import sys

def roi_select(frame):
    winname = "ROI Select"
    img = frame.copy()
    h, w = img.shape[:2]
    draw = drawRoI(width = w, height = h)
    cv2.namedWindow(winname, cv2.WINDOW_NORMAL)
    draw.call(frame, winname)
    
    while cv2.getWindowProperty(winname, cv2.WND_PROP_VISIBLE) >= 1:
        cv2.resizeWindow(winname, 360, 640)
        cv2.imshow(winname, draw.show_image())
        key = cv2.waitKey(1)
        if key != -1 :
            break
    cv2.destroyAllWindows()
    result = draw.get_clockwise_points(draw.roi_coordinates)
    if len(result)!=4:
        result = []
        
    return result

class ImageViewer:
    def __init__(self, main_window, img_path = "", config_path = ""):
        self.win = main_window
        self.img_path = img_path
        self.config_path = config_path
        self.index = 0
        self.images = []
            
        main_window.title("AGING Config Setting")
        lb_font = ("Times New Roman", 10)

        #config setting variable
        self.config_info = {}
        self.roi_list = []
        self.pattern_list = []
        
        self.config_info_var = tk.StringVar()
        self.roi_list_var = tk.StringVar()
        self.pattern_list_var = tk.StringVar()
        
        self.config_info_var.set(self.config_info)
        self.roi_list_var.set(self.roi_list)
        self.pattern_list_var.set(self.pattern_list)

        bt_save = tk.Button(self.win, text="儲存", command=self.Recipe_save)
        bt_save.grid(row=0,column=0, padx=80, pady=10, sticky="w")

        bt_save = tk.Button(self.win, text="另存新檔", command=self.Recipe_save_another)
        bt_save.grid(row=0,column=0, padx=130, pady=10, sticky="w")

        bt_load = tk.Button(self.win, text="匯入參數", command=self.Recipe_load)
        bt_load.grid(row=0,column=0, padx=5, pady=10, sticky="w")

        self.update_pathUI()

        # Light On 
        f1 = tk.Frame(main_window)
        self.Tb_gray_spec_lower = tk.Entry(f1, width=18)
        self.Tb_gray_spec_upper = tk.Entry(f1, width=18)
        self.Tb_occur_ratio = tk.Entry(f1, width=18)
        self.Tb_detect_roi = tk.Entry(f1, width=52)

        tk.Label(main_window, text="Step 1. 點燈設定", font=("Times New Roman", 12)).grid(row=1,column=0, sticky="ew")
        f1.grid(row=2, column=0, padx=5, pady=10, sticky="ew")

        # Light On Setting #
        tk.Label(f1, text="最小點燈亮度:", font=lb_font).grid(row=2, column=0, padx=5, pady=3, sticky="e")
        self.Tb_gray_spec_lower.grid(row=2, column=1, padx=5, pady=3, sticky="w")
        tk.Label(f1, text="最大點燈亮度:", font=lb_font).grid(row=2, column=2, padx=5, pady=3, sticky="e")
        self.Tb_gray_spec_upper.grid(row=2,column=3, padx=5, pady=3, sticky="w")

        tk.Label(f1, text="全局點燈檢測 ROI", font=lb_font).grid(row=4, column=0, padx=5, pady=3, sticky="e")
        self.Tb_detect_roi.grid(row=4,column=1, padx=5, pady=3, columnspan=5, sticky="w")
        self.Tb_detect_roi.bind('<Double-Button>', lambda x: self.Edit_ROI_box("detect_roi"))


        # ROI_list
        f2 = tk.Frame(main_window)
        self.listbox_roi_list = tk.Listbox(f2, listvariable=self.roi_list_var, font=("Times New Roman", 12), height=13, width=15)
        self.listbox_roi_list.bind('<Double-Button>', lambda x: self.Load_List_Data("obj_list"))

        tk.Label(main_window, text="Step 2. 面板 ROI 設定", font=("Times New Roman", 12)).grid(row=3,column=0, sticky="ew")
        f2.grid(row=4, column=0, padx=5, pady=10, sticky="ew")

        self.Tb_roi_no = tk.Entry(f2, width=14)
        self.Tb_roi_box = tk.Entry(f2, width=40)
        self.Tb_area_spec_lower = tk.Entry(f2, width=14)
        self.Tb_area_spec_upper = tk.Entry(f2, width=14)
        self.Tb_width_spec_lower = tk.Entry(f2, width=14)
        self.Tb_width_spec_upper = tk.Entry(f2, width=14)
        self.Tb_height_spec_lower = tk.Entry(f2, width=14)
        self.Tb_height_spec_upper = tk.Entry(f2, width=14)

        bt_insert_roi = tk.Button(f2, text="新增", command = self.Add_ROI_list)
        bt_insert_roi.grid(row=8, column=0, padx=5,sticky="w")
        bt_delete_roi = tk.Button(f2, text="刪除", command = self.Del_Obj_list)
        bt_delete_roi.grid(row=8, column=0, padx=5,sticky="e")

        # ROI Setting #
        self.listbox_roi_list.grid(row=0, column=0, padx=5, pady=5, rowspan = 8)

        tk.Label(f2, text="面板編號", font=lb_font).grid(row=0, column=1, padx=5, pady=3, sticky="e")
        self.Tb_roi_no.grid(row=0, column=2, padx=5, pady=2, sticky="w")

        tk.Label(f2, text="面板 ROI", font=lb_font).grid(row=1, column=1, padx=5, pady=3, sticky="e")
        self.Tb_roi_box.grid(row=1,column=2, padx=5, pady=2, columnspan=3, sticky="w")
        self.Tb_roi_box.bind('<Double-Button>', lambda x: self.Edit_ROI_box("roi_pox"))
        
        tk.Label(f2, text="面積規格", font=lb_font).grid(row=2, column=1, padx=5, pady=3, sticky="e")
        tk.Label(f2, text="最小值:", font=lb_font).grid(row=3, column=1, padx=5, pady=3, sticky="e")
        self.Tb_area_spec_lower.grid(row=3, column=2, padx=5, pady=3, sticky="w")
        tk.Label(f2, text="最大值:", font=lb_font).grid(row=3, column=3, padx=5, pady=3, sticky="e")
        self.Tb_area_spec_upper.grid(row=3, column=4, padx=5, pady=3, sticky="w")

        tk.Label(f2, text="寬度規格", font=lb_font).grid(row=4, column=1, padx=5, pady=3, sticky="e")
        tk.Label(f2, text="最小值:", font=lb_font).grid(row=5, column=1, padx=5, pady=3, sticky="e")
        self.Tb_width_spec_lower.grid(row=5, column=2, padx=5, pady=3, sticky="w")
        tk.Label(f2, text="最大值:", font=lb_font).grid(row=5, column=3, padx=5, pady=3, sticky="e")
        self.Tb_width_spec_upper.grid(row=5, column=4, padx=5, pady=3, sticky="w")

        tk.Label(f2, text="高度規格", font=lb_font).grid(row=6, column=1, padx=5, pady=3, sticky="e")
        tk.Label(f2, text="最小值:", font=lb_font).grid(row=7, column=1, padx=5, pady=3, sticky="e")
        self.Tb_height_spec_lower.grid(row=7, column=2, padx=5, pady=3, sticky="w")
        tk.Label(f2, text="最大值:", font=lb_font).grid(row=7, column=3, padx=5, pady=3, sticky="e")
        self.Tb_height_spec_upper.grid(row=7, column=4, padx=5, pady=3, sticky="w")

        bt_moveup_roi = tk.Button(f2, text=" ↑ ", command = self.ROI_list_up)
        bt_moveup_roi.grid(row=9,column=0, padx=5, pady=3, sticky="w")

        bt_movedown_roi = tk.Button(f2, text=" ↓ ", command = self.ROI_list_down)
        bt_movedown_roi.grid(row=9,column=0, padx=5, pady=3, sticky="e")

        # Pattern list
        f3 = tk.Frame(main_window)
        self.listbox_pattern_list = tk.Listbox(f3, listvariable = self.pattern_list_var, font=("Times New Roman", 12), height=8, width=15,selectmode = "single")
        self.listbox_pattern_list.bind('<Double-Button>', lambda x: self.Load_List_Data("detect_list"))
        self.listbox_pattern_list.grid(row=0, column=0, padx=5, pady=5, rowspan=6)

        # Pattern Setting #
        tk.Label(main_window, text="Step 3. Pattern 設定", font=("Times New Roman", 12)).grid(row=5, column=0, sticky="ew")
        f3.grid(row=6, column=0, padx=5, pady=10, sticky="ew")

        tk.Label(f3, text="Pattern 名稱", font=lb_font).grid(row=0, column=1, padx=5, pady=3, sticky="w")
        self.Tb_pattern_name = tk.Entry(f3, width=12)
        self.Tb_pattern_name.grid(row=0, column=1, padx=85, pady=3, sticky="w")
        
        bt_insert_pattern = tk.Button(f3, text="新增", command = self.Add_Pattern_list)
        bt_insert_pattern.grid(row=6,column=0, padx=5,sticky="w")

        bt_delete_pattern = tk.Button(f3, text="刪除", command = self.Del_Pattern_list)
        bt_delete_pattern.grid(row=6,column=0, padx=5,sticky="e")

        bt_moveup_pattern = tk.Button(f3, text=" ↑ ", command = self.Pattern_list_up)
        bt_moveup_pattern.grid(row=7,column=0, padx=5, pady=3, sticky="w")

        bt_movedown_pattern = tk.Button(f3, text=" ↓ ", command = self.Pattern_list_down)
        bt_movedown_pattern.grid(row=7,column=0, padx=5, pady=3, sticky="e")

        tk.Label(f3, text="Golden 圖", font=lb_font).grid(row=1, column=1, padx=5, pady=3, sticky="w")
        self.Tb_golden_pattern = tk.Entry(f3, width=37)
        self.Tb_golden_pattern.grid(row=1, column=1, padx=85, pady=3, sticky="w")
        self.Tb_golden_pattern.bind('<Double-Button>', lambda x: self.Choose_image())

        tk.Label(f3, text="Step 4. HSV 設定 (透過 HSV Tool 自動填入)", font=("Times New Roman", 12)).grid(row=3, column=1, padx=80, pady=3, sticky="w")

        tk.Label(f3, text="最小值:", font=lb_font).grid(row=4, column=1, padx=5, pady=3 ,sticky="w")
        self.Tb_hsv_lower = tk.Entry(f3, width=13)
        self.Tb_hsv_lower.grid(row=4,column=1, padx=85, pady=3, sticky="w")

        tk.Label(f3, text="最大值:", font=lb_font).grid(row=4, column=1, padx=186, pady=3,sticky="w")
        self.Tb_hsv_upper = tk.Entry(f3, width=13)
        self.Tb_hsv_upper.grid(row=4, column=1, padx=251, pady=3, sticky="w")

        bt_open_HSVTool = tk.Button(f3, text="HSV Tool", command = self.Edit_HSV)
        bt_open_HSVTool.grid(row=6,column=1, padx=135,sticky="w")

        #show image
        f_img = tk.Frame(main_window)
        bt_load_img = tk.Button(f_img, text="Load Images", command=self.load_images)
        bt_next_img = tk.Button(f_img, text="Next", command=self.next_image)
        bt_pre_img = tk.Button(f_img, text="Previous", command=self.prev_image)
        self.canvas = tk.Canvas(f_img, width=360, height=640)
        self.canvas_result = tk.Canvas(f_img, width=360, height=640)
        
        result_type = ["Gray detect", "ROI detect", "HSV detect"]
        
        self.var_result_type = tk.StringVar()
        self.var_result_type.set(result_type[0])
        self.var_result_type.trace("w", self.result_type_change)
        
        self.result_type_menu = tk.OptionMenu(f_img, self.var_result_type, *result_type)
        self.result_type_menu.config(width=10)

        bt_load_img.grid(row=0,column=0, padx=5, pady=0, sticky="w")
        self.result_type_menu.grid(row=0,column=1, padx=5, pady=2, sticky="w")
        
        self.canvas.grid(row=1,column=0, padx=3, pady=5, sticky="w")
        self.canvas_result.grid(row=1,column=1, padx=3, pady=5, sticky="w")
        bt_pre_img.grid(row=2,column=0, padx=5, pady=2, sticky="w")
        bt_next_img.grid(row=2,column=0, padx=5, pady=2, sticky="e")
        f_img.grid(row=1, column=1,rowspan=6, sticky="ew")

        if img_path !="":
            self.pre_load_images(self.img_path)
            if config_path != "":
                self.pre_load_recipe(self.config_path)
        
    def update_pathUI(self):

        lb_font = ("Times New Roman", 10)
        tk.Label(self.win, text="參數路徑 : ", font=lb_font).grid(row=0,column=1, padx=0, pady=0, sticky="w")
        tk.Label(self.win, text="                                                            ", font=lb_font).grid(row=0,column=1, padx=60, pady=0, sticky="w")
        tk.Label(self.win, text=self.config_path, font=lb_font).grid(row=0,column=1, padx=60, pady=0, sticky="w")

        tk.Label(self.win, text="圖檔路徑 : ", font=lb_font).grid(row=1,column=1, padx=0, pady=5, sticky="w")
        tk.Label(self.win, text="                                                                                                             ", font=lb_font)\
            .grid(row=1,column=1, padx=60, pady=5, sticky="w")
        tk.Label(self.win, text=self.img_path, font=lb_font).grid(row=1,column=1, padx=60, pady=5, sticky="w")


    def result_type_change(self, *args):
        self.show_image(self.images[self.index])
        
    def Edit_ROI_box(self, tp):
        if len(self.images) == 0:
            messagebox.showinfo('No Directory Selected', 'Please load images first.')
            return
        
        image = cv2.imread(self.images[self.index])
        roi_ = roi_select(image.copy())
        if (tp == "detect_roi"):
            self.set_value(self.Tb_detect_roi, str(roi_))
        if (tp == "roi_pox"):
            self.set_value(self.Tb_roi_box, str(roi_))
            
        self.show_image(self.images[self.index])
    

    def Recipe_load(self): 
        if len(self.images)==0:
            tk.messagebox.showinfo('Information','Please load images first !!')
            return
        
        file_path = filedialog.askopenfilename(filetypes=[('JSON files', '*.json')])
        if not file_path:
            return
        with open(file_path, "r") as f:
            data = json.load(f)
 
        self.config_info = data
        self.roi_list = self.config_info["obj_list"]
        self.pattern_list = self.config_info["detect_list"]
    
        self.set_value(self.Tb_gray_spec_lower,data["obj_gray_spec"][0])
        self.set_value(self.Tb_gray_spec_upper,data["obj_gray_spec"][1])
        self.set_value(self.Tb_detect_roi,data["detect_roi"])
        
        self.roi_list_var.set([i["obj_no"] for i in data["obj_list"]])
        self.pattern_list_var.set([i["type_name"] for i in data["detect_list"]])
        self.show_image(self.images[self.index])
        self.config_path = file_path
        self.update_pathUI()


    def pre_load_recipe(self, file_path): 
        if len(self.images)==0:
            tk.messagebox.showinfo('Information','Please load images first !!')
            return
        
        #file_path = filedialog.askopenfilename(filetypes=[('JSON files', '*.json')])
        if not file_path:
            return
        with open(file_path, "r") as f:
            data = json.load(f)

        self.config_info = data
        self.roi_list = self.config_info["obj_list"]
        self.pattern_list = self.config_info["detect_list"]
    
        self.set_value(self.Tb_gray_spec_lower,data["obj_gray_spec"][0])
        self.set_value(self.Tb_gray_spec_upper,data["obj_gray_spec"][1])
        self.set_value(self.Tb_detect_roi,data["detect_roi"])
        
        self.roi_list_var.set([i["obj_no"] for i in data["obj_list"]])
        self.pattern_list_var.set([i["type_name"] for i in data["detect_list"]])
        self.show_image(self.images[self.index])
        self.Load_List_Data(tp="obj_list")
        self.Load_List_Data(tp="detect_list")
        self.config_path = file_path
        self.update_pathUI()


    def Recipe_save_another(self):
        if ((self.roi_list == []) or (self.pattern_list == [])): return
        self.Add_ROI_list()
        self.Add_Pattern_list()
        obj = {
            "obj_gray_spec": [int(str(self.Tb_gray_spec_lower.get())),int(str(self.Tb_gray_spec_upper.get()))],
            "obj_occur_ratio": float(0.3),
            "detect_roi": ast.literal_eval(str(self.Tb_detect_roi.get())),
            "obj_list": self.roi_list,
            "detect_list": self.pattern_list
            }
        
        f = filedialog.asksaveasfile(mode='w', defaultextension=".json")
        if f is None: # asksaveasfile return `None` if dialog closed with "cancel".
            return
        
        json.dump(obj, f)
        f.close()
        tk.messagebox.showinfo('Successful','Recipe save successful !')

    def Recipe_save(self):
        if ((self.roi_list == []) or (self.pattern_list == [])): return
        self.Add_ROI_list()
        self.Add_Pattern_list()
        obj = {
            "obj_gray_spec": [int(str(self.Tb_gray_spec_lower.get())),int(str(self.Tb_gray_spec_upper.get()))],
            "obj_occur_ratio": float(0.3),
            "detect_roi": ast.literal_eval(str(self.Tb_detect_roi.get())),
            "obj_list": self.roi_list,
            "detect_list": self.pattern_list
            }
        
        if self.config_path == "": # asksaveasfile return `None` if dialog closed with "cancel".
            return
        
        with open(self.config_path, 'w') as f:
            json.dump(obj, f)
        tk.messagebox.showinfo('Successful','Recipe save successful !')

    def Choose_image(self):

        file_path = filedialog.askopenfilename(filetypes=[('JPEG files', '*.jpeg'),('JPG files','*.jpg'),('PNG files','*.png'),('BMP files','*.bmp'),('All files','*')])
        if not file_path:
            return
        self.set_value(self.Tb_golden_pattern, file_path)


    def Add_ROI_list(self):
        
        if  (str(self.Tb_roi_no.get()) == '') or (str(self.Tb_roi_box.get()) == '') or \
            (str(self.Tb_area_spec_lower.get()) == '') or (str(self.Tb_area_spec_upper.get()) == '') or \
            (str(self.Tb_width_spec_lower.get()) == '') or (str(self.Tb_width_spec_upper.get()) == '') or \
            (str(self.Tb_height_spec_lower.get()) == '') or (str(self.Tb_height_spec_upper.get()) == ''):

            tk.messagebox.showinfo('Warning','setting cannot be null !!')
            return

        obj_no = str(self.Tb_roi_no.get())
        roi_pox = ast.literal_eval(str(self.Tb_roi_box.get()))
        area_spec = [int(str(self.Tb_area_spec_lower.get())), int(str(self.Tb_area_spec_upper.get()))]
        width_spec = [int(str(self.Tb_width_spec_lower.get())), int(str(self.Tb_width_spec_upper.get()))]
        height_spec = [int(str(self.Tb_height_spec_lower.get())), int(str(self.Tb_height_spec_upper.get()))]
        
        edit = False
        for i, obj in enumerate(self.roi_list):
            if obj["obj_no"] == str(obj_no):
                self.roi_list.pop(i)
                edit = True
                edit_index = i

        #obj_info = [self.roi_list.pop(i) for i, obj in enumerate(self.roi_list) if obj["obj_no"] == obj_no]
        obj_info = {}
        obj_info["obj_no"] = obj_no
        obj_info["roi_pox"] = roi_pox
        obj_info["area_spec"] = area_spec
        obj_info["width_spec"] = width_spec
        obj_info["height_spec"] = height_spec

        if edit:
            self.roi_list.insert(edit_index, obj_info)
        else:
            self.roi_list.append(obj_info)
        
        self.roi_list_var.set([i["obj_no"] for i in self.roi_list])
        #tk.messagebox.showinfo('EDIT','Successful !!')
        
    def Add_Pattern_list(self):

        pattern_name = str(self.Tb_pattern_name.get())
        golden_pattern = str(self.Tb_golden_pattern.get())

        if (pattern_name == '') or (golden_pattern == ''):
            tk.messagebox.showinfo('Warning','setting cannot be null !!')
            return

        if str(self.Tb_hsv_lower.get()) == '':
            HSV_LOWER = []
        else:
            HSV_LOWER = ast.literal_eval(str(self.Tb_hsv_lower.get()))

        if str(self.Tb_hsv_lower.get()) == '':
            HSV_UPPER = []
        else:
            HSV_UPPER = ast.literal_eval(str(self.Tb_hsv_upper.get()))
        
        edit = False
        for i, detect in enumerate(self.pattern_list):
            if detect["type_name"] == str(pattern_name):
                self.pattern_list.pop(i)
                edit = True
                edit_index = i

        #pattern_info = [self.pattern_list.pop(i) for i, detect in enumerate(self.pattern_list) if detect["type_name"] == str(pattern_name)]
        pattern_info = {}
        pattern_info["type_name"] = pattern_name
        pattern_info["golden_pattern"] = golden_pattern
        pattern_info["HSV_LOWER"] = HSV_LOWER
        pattern_info["HSV_UPPER"] = HSV_UPPER
        pattern_info["Judge"] = "OK"
        if edit:
            self.pattern_list.insert(edit_index, pattern_info)
        else:
            self.pattern_list.append(pattern_info)

        self.pattern_list_var.set([i["type_name"] for i in self.pattern_list])
        #tk.messagebox.showinfo('EDIT','Successful !!')
        
    def Pattern_list_up(self):
        if self.listbox_pattern_list.curselection() == () : return
        select_no = self.listbox_pattern_list.curselection()[0]
        if select_no == 0: return
        temp = self.pattern_list[select_no]
        self.pattern_list.pop(select_no)
        self.pattern_list.insert(select_no-1, temp)
        self.pattern_list_var.set([i["type_name"] for i in self.pattern_list])
        self.listbox_pattern_list.select_set(select_no - 1)
        self.listbox_pattern_list.select_clear(select_no)
        return

    def Pattern_list_down(self):
        if self.listbox_pattern_list.curselection() == () : return
        select_no = self.listbox_pattern_list.curselection()[0]
        if select_no == len(self.pattern_list)-1: return
        temp = self.pattern_list[select_no]
        self.pattern_list.pop(select_no)
        self.pattern_list.insert(select_no+1, temp)
        self.pattern_list_var.set([i["type_name"] for i in self.pattern_list])
        self.listbox_pattern_list.select_set(select_no + 1)
        self.listbox_pattern_list.select_clear(select_no)
        return
    
    def ROI_list_up(self):
        if self.listbox_roi_list.curselection() == () : return
        select_no = self.listbox_roi_list.curselection()[0]
        if select_no == 0: return
        temp = self.roi_list[select_no]
        self.roi_list.pop(select_no)
        self.roi_list.insert(select_no-1, temp)
        self.roi_list_var.set([i["obj_no"] for i in self.roi_list])
        self.listbox_roi_list.select_set(select_no - 1)
        self.listbox_roi_list.select_clear(select_no)
        return

    def ROI_list_down(self):
        if self.listbox_roi_list.curselection() == () : return
        select_no = self.listbox_roi_list.curselection()[0]
        if select_no == len(self.roi_list)-1: return
        temp = self.roi_list[select_no]
        self.roi_list.pop(select_no)
        self.roi_list.insert(select_no+1, temp)
        self.roi_list_var.set([i["obj_no"] for i in self.roi_list])
        self.listbox_roi_list.select_set(select_no + 1)
        self.listbox_roi_list.select_clear(select_no)
        return

    def Del_Obj_list(self):
        if self.listbox_roi_list.curselection() == () : return
        obj_no = self.listbox_roi_list.get(self.listbox_roi_list.curselection()[0])
        obj_info = [self.roi_list.pop(i) for i, obj in enumerate(self.roi_list) if obj["obj_no"] == obj_no]
        self.roi_list_var.set([i["obj_no"] for i in self.roi_list])
            
    def Del_Pattern_list(self):
        if self.listbox_pattern_list.curselection() == () : return
        type_name = self.listbox_pattern_list.get(self.listbox_pattern_list.curselection()[0])
        detect_info = [self.pattern_list.pop(i) for i, detect in enumerate(self.pattern_list) if detect["type_name"] == str(type_name)]
        self.pattern_list_var.set([i["type_name"] for i in self.pattern_list])

    def Load_List_Data(self, tp):
        if ( tp == "obj_list" ):

            if (str(self.Tb_roi_no.get()) != ''):
                self.Add_ROI_list()

            if(self.listbox_roi_list.size()==0):
                return

            try:
                obj_no = self.listbox_roi_list.get(self.listbox_roi_list.curselection()[0])
            except(IndexError):
                obj_no = self.listbox_roi_list.get(0)

            obj_info = [i for i in self.roi_list if i["obj_no"] == str(obj_no)][0]
            self.set_value(self.Tb_roi_no, obj_info["obj_no"])
            self.set_value(self.Tb_roi_box, obj_info["roi_pox"])
            self.set_value(self.Tb_area_spec_lower, obj_info["area_spec"][0])
            self.set_value(self.Tb_area_spec_upper, obj_info["area_spec"][1])
            self.set_value(self.Tb_width_spec_lower, obj_info["width_spec"][0])
            self.set_value(self.Tb_width_spec_upper, obj_info["width_spec"][1])
            self.set_value(self.Tb_height_spec_lower, obj_info["height_spec"][0])
            self.set_value(self.Tb_height_spec_upper, obj_info["height_spec"][1])
            self.var_result_type.set('ROI detect')
            self.result_type_change()
            
        elif (tp == "detect_list"):

            if ((str(self.Tb_pattern_name.get()) != '')):
                self.Add_Pattern_list()

            if(self.listbox_pattern_list.size()==0):
                return
            
            try:
                type_name = self.listbox_pattern_list.get(self.listbox_pattern_list.curselection()[0])
            except(IndexError):
                type_name = self.listbox_pattern_list.get(0)

            pattern_info = [i for i in self.pattern_list if i["type_name"] == str(type_name)][0]
            self.set_value(self.Tb_pattern_name, pattern_info["type_name"])
            self.set_value(self.Tb_golden_pattern, pattern_info["golden_pattern"])
            self.set_value(self.Tb_hsv_lower, pattern_info["HSV_LOWER"])
            self.set_value(self.Tb_hsv_upper, pattern_info["HSV_UPPER"])
            self.var_result_type.set('HSV detect')
            self.result_type_change()
        
    def Edit_HSV(self):

        if len(self.pattern_list) == 0:
            messagebox.showinfo('Information','Please set pattern first !!')
            return
        if self.Tb_pattern_name.get() == "":
            messagebox.showinfo('Information','Please select pattern first !!')
            return
        
        self.Add_Pattern_list()

        pattern_list = []
        golden_imagepath_list = []

        for pattern_info in self.pattern_list:
            pattern_name = pattern_info["type_name"]
            golden_img_path = pattern_info["golden_pattern"]
            if os.path.isfile(golden_img_path) == False:
                messagebox.showinfo('Information',pattern_name + ' pattern golden image not found !')
                return
            pattern_list.append(pattern_name)
            golden_imagepath_list.append(golden_img_path)

        if str(self.Tb_hsv_lower.get())!="" and str(self.Tb_hsv_upper.get()) != "" and str(self.Tb_hsv_lower.get())!="[]" and str(self.Tb_hsv_upper.get())!="[]":
            HSV_LOWER = ast.literal_eval(str(self.Tb_hsv_lower.get()))
            HSV_UPPER = ast.literal_eval(str(self.Tb_hsv_upper.get()))

        else:
            if self.Tb_pattern_name.get() == "R" or self.Tb_pattern_name.get() == "Red" or self.Tb_pattern_name.get() == "RED":
                HSV_LOWER = [160, 179, 50]
                HSV_UPPER = [268, 255, 255]
            elif self.Tb_pattern_name.get() == "G" or self.Tb_pattern_name.get() == "Green" or self.Tb_pattern_name.get() == "GREEN":
                HSV_LOWER = [49, 147, 141]
                HSV_UPPER = [104, 255, 255]
            elif self.Tb_pattern_name.get() == "B" or self.Tb_pattern_name.get() == "Blue" or self.Tb_pattern_name.get() == "BLUE":
                HSV_LOWER = [94, 139, 101]
                HSV_UPPER = [168, 255, 255]
            elif self.Tb_pattern_name.get() == "L255" or self.Tb_pattern_name.get() == "White" or self.Tb_pattern_name.get() == "WHITE" or \
                self.Tb_pattern_name.get() == "l255" or self.Tb_pattern_name.get() == "W255" or self.Tb_pattern_name.get() == "w255":
                HSV_LOWER = [0, 0, 139]
                HSV_UPPER = [255, 102, 255]
            else:
                HSV_LOWER = [0, 0, 0]
                HSV_UPPER = [255, 255, 255]

        hsvtool = HsvTool(pattern_list,golden_imagepath_list,HSV_LOWER,HSV_UPPER)

        lower, upper = hsvtool.getHSVvalue()
        self.set_value(self.Tb_hsv_lower, str(lower))
        self.set_value(self.Tb_hsv_upper, str(upper))
        self.Add_Pattern_list()
        if len(self.images) != 0 :
            self.show_image(self.images[self.index])

    def set_value(self, tb, value):
        tb.delete(0,"end")
        tb.insert(0,str(value))
    
    def load_images(self):
        
        folder_path = filedialog.askdirectory()
        
        if folder_path:
            self.images = []
            self.index  = 0
            
            image_files = [f for f in os.listdir(folder_path) 
                           if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            
            if len(image_files) == 0: return
            for image_file in image_files:
                self.images.append(os.path.join(folder_path, image_file))

            self.show_image(self.images[self.index])
            self.img_path = folder_path
            self.update_pathUI()
        else:
            messagebox.showinfo('No Directory Selected', 'Please select a directory.')

    def pre_load_images(self, folder_path):        
        if folder_path:
            self.images = []
            self.index  = 0
            
            image_files = [f for f in os.listdir(folder_path) 
                           if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            
            if len(image_files) == 0: return
            for image_file in image_files:
                self.images.append(os.path.join(folder_path, image_file))

            self.show_image(self.images[self.index])
            self.img_path = folder_path
            self.update_pathUI()
        else:
            messagebox.showinfo('No Directory Selected', 'Please select a directory.')

    def next_image(self):
        if self.images:
            self.index = (self.index + 1) % len(self.images)
            self.show_image(self.images[self.index])
        else:
            messagebox.showinfo('No Images Loaded', 'Please load images.')

    def prev_image(self):
        if self.images:
            self.index = (self.index - 1) % len(self.images)
            self.show_image(self.images[self.index])
        else:
            messagebox.showinfo('No Images Loaded', 'Please load images.')

    def show_image(self, img_file):
        
        img = cv2.imread(img_file)
        img_result = img.copy()
        img_result = self.judge_image(img_result)
        if str(self.Tb_detect_roi.get()) != "":
            detect_roi = ast.literal_eval(str(self.Tb_detect_roi.get()))
            pts = np.array(detect_roi, np.int32)
            pts = pts.reshape((-1, 1, 2))
            cv2.polylines(img, [pts], True, (0, 0, 255), 9)
        
        pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        pil_img_result = Image.fromarray(cv2.cvtColor(img_result, cv2.COLOR_BGR2RGB))
        
        pil_img.thumbnail((360, 640), Image.ANTIALIAS)
        pil_img_result.thumbnail((360, 640), Image.ANTIALIAS)
        tk_image = ImageTk.PhotoImage(pil_img)
        tk_image_result = ImageTk.PhotoImage(pil_img_result)
        
        self.canvas.create_image(0, 0, anchor='nw', image=tk_image)
        self.canvas.image = tk_image  # keep a reference to avoid garbage collection
        
        self.canvas_result.create_image(0, 0, anchor='nw', image=tk_image_result)
        self.canvas_result.image = tk_image_result  # keep a reference to avoid garbage collection
    
    def judge_image(self,img):
        
        judge_type = self.var_result_type.get()
        obj_gray_spec = []
        detect_roi = []
        obj_list = []
        detect_list = []
        
        if str(self.Tb_gray_spec_lower.get()) != "" and str(self.Tb_gray_spec_upper.get()) != "":
            obj_gray_spec = [int(str(self.Tb_gray_spec_lower.get())),int(str(self.Tb_gray_spec_upper.get()))]
        if str(self.Tb_detect_roi.get()) != "":
            detect_roi = ast.literal_eval(str(self.Tb_detect_roi.get()))
            
        obj_no = str(self.Tb_roi_no.get())
        roi_pox = []
        area_spec = []
        width_spec = []
        height_spec = []
        
        if str(self.Tb_roi_box.get()) != "":
            roi_pox = ast.literal_eval(str(self.Tb_roi_box.get()))
        if str(self.Tb_area_spec_lower.get()) != "" and str(self.Tb_area_spec_upper.get())!="":
            area_spec = [int(str(self.Tb_area_spec_lower.get())), int(str(self.Tb_area_spec_upper.get()))]
        if str(self.Tb_width_spec_lower.get()) != "" and str(self.Tb_width_spec_upper.get())!="":
            width_spec = [int(str(self.Tb_width_spec_lower.get())), int(str(self.Tb_width_spec_upper.get()))]
        if str(self.Tb_height_spec_lower.get()) != "" and str(self.Tb_height_spec_upper.get())!="":
            height_spec = [int(str(self.Tb_height_spec_lower.get())), int(str(self.Tb_height_spec_upper.get()))]
            
        obj_info = {}
        obj_info["obj_no"] = obj_no
        obj_info["roi_pox"] = roi_pox
        obj_info["area_spec"] = area_spec
        obj_info["width_spec"] = width_spec
        obj_info["height_spec"] = height_spec
        obj_list = [obj_info]
        
        type_name = str(self.Tb_pattern_name.get())
        HSV_LOWER = []
        HSV_UPPER = []
        if str(self.Tb_hsv_lower.get())!="":
            HSV_LOWER = ast.literal_eval(str(self.Tb_hsv_lower.get()))
        if str(self.Tb_hsv_upper.get())!="":
            HSV_UPPER = ast.literal_eval(str(self.Tb_hsv_upper.get()))
        
        detect_info = {}
        detect_info["type_name"] = type_name
        detect_info["HSV_LOWER"] = HSV_LOWER
        detect_info["HSV_UPPER"] = HSV_UPPER
        detect_info["Judge"] = "OK"
        detect_list = [detect_info]
        
        aging_judge = Aging_detect_config(img, judge_type, obj_gray_spec, detect_roi, obj_list, detect_list)
        
        return aging_judge.Get_judge_image()
        

if __name__ == '__main__':
    root = tk.Tk()
    arg_num = len(sys.argv)
    if arg_num == 1:
        viewer = ImageViewer(root)
    elif arg_num == 2:
        img_path = sys.argv[1]
        viewer = ImageViewer(root,img_path)
    elif arg_num == 3:
        img_path = sys.argv[1]
        recipe_path = sys.argv[2]
        viewer = ImageViewer(root,img_path,recipe_path)
    else:
        print("argment number error !")
        exit()

    root.mainloop()

'''

if __name__ == '__main__':
    root = tk.Tk()
    img_path = "D:\\Aging_AOI\\dataset\\231219_ABCDEFG\\1"
    recipe_path = "D:\\Aging_AOI\\config\\1205.json"
    viewer = ImageViewer(root, img_path, recipe_path)
    root.mainloop()


if __name__ == '__main__':
    root = tk.Tk()
    viewer = ImageViewer(root)
    root.mainloop()
'''
