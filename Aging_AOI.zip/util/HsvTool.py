import cv2
import os
import numpy as np


# Implement selectROI
class HsvTool:

#HsvTool(pattern_list,golden_imagepath_list,HSV_LOWER,HSV_UPPER)

    def __init__(self, pattern_name_list, golden_imagepath_list, hsv_lower=[0,0,0], hsv_upper=[255,255,255]):

        self.pattern_name_list = pattern_name_list
        self.golden_imagepath_list = golden_imagepath_list
        if len(hsv_lower) != 3: hsv_lower=[0,0,0]
        if len(hsv_upper) != 3: hsv_upper=[255,255,255]
        self.hsv_lower = [int(hsv_lower[0]),int(hsv_lower[1]),int(hsv_lower[2])]
        self.hsv_upper = [int(hsv_upper[0]),int(hsv_upper[1]),int(hsv_upper[2])]
        self.img_h = 480
        self.img_w = 270
        img_size = (270,480)

        # concat golden images
        for i in range(0, len(self.pattern_name_list),2):
            golden_image1 = cv2.imread(self.golden_imagepath_list[i])
            golden_image1 = cv2.resize(golden_image1, (self.img_w,self.img_h))

            try:
                golden_image2 = cv2.imread(self.golden_imagepath_list[i+1])
                golden_image2 = cv2.resize(golden_image2, (self.img_w,self.img_h))
            except IndexError:
                golden_image2 = np.zeros((self.img_h,self.img_w,3), np.uint8)

            updown_concat = cv2.vconcat([golden_image1,golden_image2])

            if i == 0:
                big_image = updown_concat
            else:
                big_image = cv2.hconcat([big_image, updown_concat])


        self.img_hsv = cv2.cvtColor(big_image,cv2.COLOR_BGR2HSV)



    def getHSVvalue(self):
    
        def nothing(x):
            pass

        if len(self.pattern_name_list) == 0: return

        #calculate windows size
        (quo,rem) = divmod(len(self.pattern_name_list), 2)
        if (quo == 0) and (rem == 1):
            h_num = 1
            w_num = 1
        else:
            h_num = 2
            w_num = quo

        if rem != 0:
            w_num = w_num + 1
        
        winname1 = "HSV Tool"
        cv2.namedWindow(winname1, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(winname1, self.img_w * w_num, self.img_h * h_num)
        
        winName = 'HSV config'
        cv2.namedWindow(winName)

        cv2.createTrackbar('LowerH',winName,self.hsv_lower[0],255,nothing)

        cv2.createTrackbar('UpperH',winName,self.hsv_upper[0],320,nothing)

        cv2.createTrackbar('LowerS',winName,self.hsv_lower[1],255,nothing)

        cv2.createTrackbar('UpperS',winName,self.hsv_upper[1],255,nothing)

        cv2.createTrackbar('LowerV',winName,self.hsv_lower[2],255,nothing)

        cv2.createTrackbar('UpperV',winName,self.hsv_upper[2],255,nothing)
        
        
        while(1):

            LowerH = cv2.getTrackbarPos('LowerH',winName)
            UpperH = cv2.getTrackbarPos('UpperH',winName)

            LowerS = cv2.getTrackbarPos('LowerS',winName)
            UpperS = cv2.getTrackbarPos('UpperS',winName)
            
            LowerV = cv2.getTrackbarPos('LowerV',winName)
            UpperV = cv2.getTrackbarPos('UpperV',winName)
            
            lower = np.array([LowerH, LowerS, LowerV])
            upper = np.array([UpperH, UpperS, UpperV])

            
            #紅色 Hue 會跨255 分段處理
            if (UpperH <= 255):

                mask = cv2.inRange(self.img_hsv, lower, upper)
                result_hsv = cv2.bitwise_and(self.img_hsv, self.img_hsv, mask=mask)

            else:

                LowerH1 = LowerH
                UpperH1 = 255
                LowerH2 = 0
                UpperH2 = UpperH - 255

                lower1 = np.array([LowerH1, LowerS, LowerV])
                upper1 = np.array([UpperH1, UpperS, UpperV])
                lower2 = np.array([LowerH2, LowerS, LowerV])
                upper2 = np.array([UpperH2, UpperS, UpperV])

                mask1 = cv2.inRange(self.img_hsv, lower1, upper1)
                mask2 = cv2.inRange(self.img_hsv, lower2, upper2)
                mask = cv2.bitwise_or(mask1, mask2)
                result_hsv = cv2.bitwise_and(self.img_hsv, self.img_hsv, mask=mask)
            
            #put pattern name text
            shift = 10

            for i in range(len(self.pattern_name_list)):
                (quo,rem) = divmod(i, 2)
                x = quo * self.img_w + shift
                if rem == 0: 
                    y = shift + 30
                else:
                    y = self.img_h + shift + 30
                cv2.putText(result_hsv,self.pattern_name_list[i],(x,y),cv2.FONT_HERSHEY_SIMPLEX,1.2,(255,255,255),3,cv2.LINE_AA)


            cv2.imshow(winname1, result_hsv)
            key = cv2.waitKey(1)
            if key != -1 :
                cv2.destroyAllWindows()
                break

            
        return lower.tolist(), upper.tolist()
    