"""
Created on Mon Jan 23 12:00:00 2022
@author: OtisChang
"""
from utils import MMFA_model

image_folder_path = "./TOP10"
model_path        = "./TOP10model.onnx" # onnx file (the file name must include "TOP10" or "VRS" in capital letter.)

if __name__ == '__main__':
    finalResult = MMFA_model.inference(image_folder_path, model_path)
    for i in range(len(finalResult['FileName'])):
        print("FileName: {:20s} / Prediction: {:15s}".format(finalResult['FileName'][i], finalResult['Prediction'][i]))
        print("Confidence: {}".format(finalResult['Confidence'][i]))