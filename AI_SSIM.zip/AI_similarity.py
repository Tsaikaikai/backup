import os
import sys
import torch
import warnings
import torchvision.transforms as transforms
import torchvision.models as models
from PIL import Image
import numpy as np

def Load_Model(device):
    os.environ['TORCH_HOME'] = '.\\'
    model = models.vgg16(pretrained=True)
    model.to(device)
    #print("load model success !")
    return device , model

def RUN_CNN_SIM(device , model , golden_path, compare_path):

    transform = transforms.Compose([
        transforms.Resize(512),
        transforms.ToTensor(),
        transforms.Lambda(lambda x: x.repeat(3, 1, 1) if x.size(0)==1 else x),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225])
    ])

    golden_img = Image.open(golden_path)
    golden_img = transform(golden_img).unsqueeze(0)
    golden_img = golden_img.to(device)

    compare_img = Image.open(compare_path)
    compare_img = transform(compare_img).unsqueeze(0)
    compare_img = compare_img.to(device)

    golden_feat = model.features(golden_img).view(golden_img.size(0), -1)
    compare_feat = model.features(compare_img).view(compare_img.size(0), -1)
    similarity_score = torch.nn.functional.cosine_similarity(golden_feat, compare_feat)

    return round(similarity_score.item() ,4)


if __name__ == '__main__':
    warnings.filterwarnings('ignore')
    golden_image = sys.argv[1]
    compare_image_path = sys.argv[2]
    mode = sys.argv[3]
    '''
    golden_image = "VOR_Model.bmp"
    compare_image_path = "./test/"
    mode = "cpu"
    '''

    if mode == "gpu":
        device = torch.device("cuda:0") #gpu mode
    elif mode =="cpu":
        device = torch.device("cpu") #cpu mode
    else:
        print("mode error !")
        exit()

    device , model = Load_Model(device)

    files = os.listdir(compare_image_path)

    for file in files:
        fullpath = os.path.join(compare_image_path, file)
        score = RUN_CNN_SIM(device , model, golden_image, fullpath)
        print(file)
        print("Score = " + str(score) + "\n")