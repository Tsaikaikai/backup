﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_Cudnn = new System.Windows.Forms.Button();
            this.label_windows = new System.Windows.Forms.Label();
            this.btn_Cuda = new System.Windows.Forms.Button();
            this.btn_Python = new System.Windows.Forms.Button();
            this.btn_PythonWHL = new System.Windows.Forms.Button();
            this.label_python = new System.Windows.Forms.Label();
            this.ckb_python = new System.Windows.Forms.CheckBox();
            this.label_cuda = new System.Windows.Forms.Label();
            this.ckb_cuda = new System.Windows.Forms.CheckBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.ckb_cudnn = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ckb_pythonwhl = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label_Driver = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Cudnn
            // 
            this.btn_Cudnn.Location = new System.Drawing.Point(43, 241);
            this.btn_Cudnn.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cudnn.Name = "btn_Cudnn";
            this.btn_Cudnn.Size = new System.Drawing.Size(100, 71);
            this.btn_Cudnn.TabIndex = 0;
            this.btn_Cudnn.Text = "2.Cudnn安裝";
            this.btn_Cudnn.UseVisualStyleBackColor = true;
            this.btn_Cudnn.Click += new System.EventHandler(this.btn_Cudnn_Click);
            // 
            // label_windows
            // 
            this.label_windows.AutoSize = true;
            this.label_windows.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_windows.Location = new System.Drawing.Point(46, 16);
            this.label_windows.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_windows.Name = "label_windows";
            this.label_windows.Size = new System.Drawing.Size(115, 23);
            this.label_windows.TabIndex = 1;
            this.label_windows.Text = "偵測系統：";
            // 
            // btn_Cuda
            // 
            this.btn_Cuda.Location = new System.Drawing.Point(43, 150);
            this.btn_Cuda.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cuda.Name = "btn_Cuda";
            this.btn_Cuda.Size = new System.Drawing.Size(100, 70);
            this.btn_Cuda.TabIndex = 0;
            this.btn_Cuda.Text = "1.Cuda安裝";
            this.btn_Cuda.UseVisualStyleBackColor = true;
            this.btn_Cuda.Click += new System.EventHandler(this.btn_Cuda_Click);
            // 
            // btn_Python
            // 
            this.btn_Python.Location = new System.Drawing.Point(161, 150);
            this.btn_Python.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Python.Name = "btn_Python";
            this.btn_Python.Size = new System.Drawing.Size(100, 70);
            this.btn_Python.TabIndex = 2;
            this.btn_Python.Text = "3.Python安裝";
            this.btn_Python.UseVisualStyleBackColor = true;
            this.btn_Python.Click += new System.EventHandler(this.btn_Python_Click);
            // 
            // btn_PythonWHL
            // 
            this.btn_PythonWHL.Location = new System.Drawing.Point(161, 242);
            this.btn_PythonWHL.Margin = new System.Windows.Forms.Padding(2);
            this.btn_PythonWHL.Name = "btn_PythonWHL";
            this.btn_PythonWHL.Size = new System.Drawing.Size(100, 70);
            this.btn_PythonWHL.TabIndex = 2;
            this.btn_PythonWHL.Text = "4.Python插件";
            this.btn_PythonWHL.UseVisualStyleBackColor = true;
            this.btn_PythonWHL.Click += new System.EventHandler(this.btn_PythonWHL_Click);
            // 
            // label_python
            // 
            this.label_python.AutoSize = true;
            this.label_python.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_python.Location = new System.Drawing.Point(139, 42);
            this.label_python.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_python.Name = "label_python";
            this.label_python.Size = new System.Drawing.Size(99, 23);
            this.label_python.TabIndex = 1;
            this.label_python.Text = "Python3.6";
            // 
            // ckb_python
            // 
            this.ckb_python.AutoCheck = false;
            this.ckb_python.AutoSize = true;
            this.ckb_python.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ckb_python.Location = new System.Drawing.Point(252, 48);
            this.ckb_python.Margin = new System.Windows.Forms.Padding(2);
            this.ckb_python.Name = "ckb_python";
            this.ckb_python.Size = new System.Drawing.Size(15, 14);
            this.ckb_python.TabIndex = 3;
            this.ckb_python.UseVisualStyleBackColor = true;
            // 
            // label_cuda
            // 
            this.label_cuda.AutoSize = true;
            this.label_cuda.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cuda.Location = new System.Drawing.Point(46, 42);
            this.label_cuda.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_cuda.Name = "label_cuda";
            this.label_cuda.Size = new System.Drawing.Size(62, 23);
            this.label_cuda.TabIndex = 1;
            this.label_cuda.Text = "Cuda";
            // 
            // ckb_cuda
            // 
            this.ckb_cuda.AutoCheck = false;
            this.ckb_cuda.AutoSize = true;
            this.ckb_cuda.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ckb_cuda.Location = new System.Drawing.Point(112, 48);
            this.ckb_cuda.Margin = new System.Windows.Forms.Padding(2);
            this.ckb_cuda.Name = "ckb_cuda";
            this.ckb_cuda.Size = new System.Drawing.Size(15, 14);
            this.ckb_cuda.TabIndex = 3;
            this.ckb_cuda.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cudnn";
            // 
            // ckb_cudnn
            // 
            this.ckb_cudnn.AutoCheck = false;
            this.ckb_cudnn.AutoSize = true;
            this.ckb_cudnn.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ckb_cudnn.Location = new System.Drawing.Point(112, 75);
            this.ckb_cudnn.Margin = new System.Windows.Forms.Padding(2);
            this.ckb_cudnn.Name = "ckb_cudnn";
            this.ckb_cudnn.Size = new System.Drawing.Size(15, 14);
            this.ckb_cudnn.TabIndex = 3;
            this.ckb_cudnn.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(138, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Python插件";
            // 
            // ckb_pythonwhl
            // 
            this.ckb_pythonwhl.AutoCheck = false;
            this.ckb_pythonwhl.AutoSize = true;
            this.ckb_pythonwhl.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ckb_pythonwhl.Location = new System.Drawing.Point(252, 75);
            this.ckb_pythonwhl.Margin = new System.Windows.Forms.Padding(2);
            this.ckb_pythonwhl.Name = "ckb_pythonwhl";
            this.ckb_pythonwhl.Size = new System.Drawing.Size(15, 14);
            this.ckb_pythonwhl.TabIndex = 3;
            this.ckb_pythonwhl.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Aqua;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(36, 142);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(114, 174);
            this.panel1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 76);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 23);
            this.label3.TabIndex = 1;
            this.label3.Text = "Inference";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Green;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(29, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 183);
            this.panel2.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label4.Location = new System.Drawing.Point(155, 80);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 23);
            this.label4.TabIndex = 1;
            this.label4.Text = "Train";
            // 
            // label_Driver
            // 
            this.label_Driver.AutoSize = true;
            this.label_Driver.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Driver.ForeColor = System.Drawing.Color.Red;
            this.label_Driver.Location = new System.Drawing.Point(46, 98);
            this.label_Driver.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Driver.Name = "label_Driver";
            this.label_Driver.Size = new System.Drawing.Size(171, 23);
            this.label_Driver.TabIndex = 1;
            this.label_Driver.Text = "Nvidia Driver:N/A";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 98);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(313, 324);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ckb_cudnn);
            this.Controls.Add(this.ckb_cuda);
            this.Controls.Add(this.ckb_pythonwhl);
            this.Controls.Add(this.ckb_python);
            this.Controls.Add(this.btn_PythonWHL);
            this.Controls.Add(this.btn_Python);
            this.Controls.Add(this.label_Driver);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_cuda);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_python);
            this.Controls.Add(this.label_windows);
            this.Controls.Add(this.btn_Cuda);
            this.Controls.Add(this.btn_Cudnn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "AUO AI Install 211118";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cudnn;
        private System.Windows.Forms.Label label_windows;
        private System.Windows.Forms.Button btn_Cuda;
        private System.Windows.Forms.Button btn_Python;
        private System.Windows.Forms.Button btn_PythonWHL;
        private System.Windows.Forms.Label label_python;
        private System.Windows.Forms.CheckBox ckb_python;
        private System.Windows.Forms.Label label_cuda;
        private System.Windows.Forms.CheckBox ckb_cuda;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox ckb_cudnn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox ckb_pythonwhl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_Driver;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

