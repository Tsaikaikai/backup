﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    enum WindowsType
    {
        Win7,
        Win10
    };

    public partial class Form1 : Form
    {
        WindowsType _windows = WindowsType.Win10;
        string CUDAFILE;
        string CUDADNNFILE;
        string PYTHON_INSTALL_FILE;
        bool IsPythonWhl = false;
        bool IsCheckPythonWhlRuning = false;
        double CUDAVERSION_CU111 = 456.81;
        double CUDAVERSION_CU102 = 441.22;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            CheckWindowOS();
            WriteBat();
            timer1.Start();
            ToolTip toolTip1 = new ToolTip();
            string tips = "Win10 Driver >= 456.81" + Environment.NewLine 
                + "Win7 Driver >= 441.22";
            toolTip1.SetToolTip(pictureBox1, tips);
            toolTip1.ToolTipIcon = ToolTipIcon.Info;
            toolTip1.ForeColor = Color.Blue;
            toolTip1.BackColor = Color.Gray;
            toolTip1.AutoPopDelay = 5000;
            toolTip1.ToolTipTitle = "提示訊息";
        }
        public static bool IsWin7 => Environment.OSVersion.Version.Major == 6
               && Environment.OSVersion.Version.Minor == 1;

        private void CheckWindowOS()
        {
            if (IsWin7)
            {
                _windows = WindowsType.Win7;
                label_windows.Text = "偵測系統：Win7";
                CUDAFILE = "cuda_10.2.89_441.22_windows.exe";
                CUDADNNFILE = "cudnn-10.2-windows10-x64-v8.0.4.30.zip";
                PYTHON_INSTALL_FILE = "SetupwithCuda10.bat";
            }
            else
            {
                _windows = WindowsType.Win10;
                label_windows.Text = "偵測系統：Win10";
                CUDAFILE = "cuda_11.1.1_456.81_win10.exe";
                CUDADNNFILE = "cudnn-11.1-windows-x64-v8.0.4.30.zip";
                PYTHON_INSTALL_FILE = "SetupwithCuda11.bat";
            }
            ckb_cudnn.Checked = CheckCudnn();
            ckb_cuda.Checked = CheckCuda();
            ckb_python.Checked = CheckPython();
            ckb_pythonwhl.Checked = IsPythonWhl;
            CheckNvidiaDriver();
        }

        private bool CheckCuda()
        {
            bool state = false;
            var envirormentVariables = Environment.GetEnvironmentVariables(EnvironmentVariableTarget.Machine);
            switch (_windows)
            {
                case WindowsType.Win7:
                    {
                        if (envirormentVariables.Contains("CUDA_PATH_V10_2"))
                            state = true;
                        break;
                    }
                case WindowsType.Win10:
                    {
                        if (envirormentVariables.Contains("CUDA_PATH_V11_1"))
                            state = true;
                        break;
                    }

                default:
                    break;
            }
            return state;
        }

        private bool CheckCudnn()
        {
            bool state = false;
            var path = @"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA";
            switch (_windows)
            {
                case WindowsType.Win7:
                    {
                        path += @"\v10.2\bin\cudnn64_8.dll";
                        if (File.Exists(path))
                            state = true;
                        break;
                    }
                case WindowsType.Win10:
                    {
                        path += @"\v11.1\bin\cudnn64_8.dll";
                        if (File.Exists(path))
                            state = true;
                        break;
                    }

                default:
                    break;
            }
            return state && CheckCuda();
        }

        private bool CheckPython()
        {
            bool state = false;

            string pythonPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
    + @"\Programs\Python\Python36\python.exe";

            string pipPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
+ @"\Programs\Python\Python36\Scripts\pip3.6.exe";

            if (File.Exists(pythonPath) &&
                File.Exists(pipPath))
                state = true;
            return state;
        }

        public void CheckPythonWhl()
        {
            if (IsCheckPythonWhlRuning)
                return;
            IsCheckPythonWhlRuning = true;
            Task.Run(() =>
            {
                bool state = false;
                string pipPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
+ @"\Programs\Python\Python36\Scripts\pip3.6.exe";
                if (!File.Exists(pipPath))
                {
                    IsCheckPythonWhlRuning = false;
                    IsPythonWhl = false;
                    return;
                }

                Process p = new Process();
                p.StartInfo.FileName = pipPath;
                string sArguments = " list";

                p.StartInfo.Arguments = sArguments;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardInput = true;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                var outputText = output.Split(new[] { Environment.NewLine },
        StringSplitOptions.None);
                p.WaitForExit();

                if (outputText.Length >= 104)
                    state = true;
                IsPythonWhl = state;
                IsCheckPythonWhlRuning = false;
            });           
        }

        public void CheckNvidiaDriver()
        {
            if (!ckb_cuda.Checked)
                return ;
            Process p = new Process();
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.Arguments = @"/C nvidia-smi.exe";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = true;
            p.Start();
            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            p.Close();

            string[] outputText = output.Split(new[] { Environment.NewLine },
                    StringSplitOptions.None);
            if (outputText.Length>=20)
            {
                outputText = outputText[2].Split(new[] { " " },StringSplitOptions.None);
                double dirver_version = Convert.ToDouble(outputText[11]);
                if(dirver_version>0)
                {
                    label_Driver.Text = "Nvidia Driver:" + dirver_version;
                    switch (_windows)
                    {
                        case WindowsType.Win7:
                            {
                                if (dirver_version - CUDAVERSION_CU102 > 0)
                                {
                                    label_Driver.Text += "(OK)";
                                    label_Driver.ForeColor = Color.Green;
                                }
                                else
                                {
                                    label_Driver.Text += "(NG)";
                                    label_Driver.ForeColor = Color.Red;
                                }

                                break;
                            }
                        case WindowsType.Win10:
                            {
                                if (dirver_version - CUDAVERSION_CU111 > 0)
                                {
                                    label_Driver.Text += "(OK)";
                                    label_Driver.ForeColor = Color.Green;
                                }
                                else
                                {
                                    label_Driver.Text += "(NG)";
                                    label_Driver.ForeColor = Color.Red;
                                }
                                break;
                            }

                        default:
                            label_Driver.Text += "(NG)";
                            label_Driver.ForeColor = Color.Red;
                            break;
                    }

                }
                else
                {
                    label_Driver.Text = "Nvidia Driver:N/A";
                    label_Driver.ForeColor = Color.Red;
                }  
            }
            return ;
        }

        private void btn_Cudnn_Click(object sender, EventArgs e)
        {
            if(CheckCuda())
            {
                if (CheckCudnn())
                {
                    if (MessageBox.Show("偵測已經安裝Cudnn，是否繼續?", "注意",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        return;
                    }
                }

                var wi = WindowsIdentity.GetCurrent();
                var wp = new WindowsPrincipal(wi);
                if (!wp.IsInRole(WindowsBuiltInRole.Administrator))
                {
                    MessageBox.Show("請使用管理員權限");
                    return;
                }
                string str = System.IO.Directory.GetCurrentDirectory();
                string zipFilePath = str + @"\bin\" + CUDADNNFILE;
                if(!File.Exists(zipFilePath))
                {
                    MessageBox.Show("找不到Cudnn壓縮檔");
                    return;
                }
                btn_Cudnn.Enabled = false;
                btn_Cuda.Enabled = false;
                Task.Run(() => ExtraZipFile());
            }
            else
            {
                MessageBox.Show("未偵測到Cuda安裝");
            }
        }

        private void btn_Cuda_Click(object sender, EventArgs e)
        {
            if(CheckCuda())
            {
                if (MessageBox.Show("偵測已經安裝Cuda，是否繼續?", "注意", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
            }
            string str = System.IO.Directory.GetCurrentDirectory();
            string filePath = str + @"\bin\"+CUDAFILE;
            if(File.Exists(filePath))
            {
                Process process = new Process();
                process.StartInfo.FileName = filePath;
                process.Start();
            }
            else
            {
                MessageBox.Show("找不到Cuda安裝檔");
            }
        }

        private void btn_Python_Click(object sender, EventArgs e)
        {
            if (CheckPython())
            {
                if (MessageBox.Show("偵測已經安裝Python，是否安裝Python?", "注意",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }        
            }
            string str = System.IO.Directory.GetCurrentDirectory();
            string filePath = str + @"\bin\" + "python-3.6.8-amd64.exe";
            if (File.Exists(filePath))
            {
                Process process = new Process();
                process.StartInfo.FileName = filePath;
                process.Start();
            }
            else
            {
                MessageBox.Show("找不到Python安裝檔");
            }
        }

        private void btn_PythonWHL_Click(object sender, EventArgs e)
        {
            if (CheckPython())
            {
                if (IsPythonWhl)
                {
                    if (MessageBox.Show("已偵測安裝Python插件，是否繼續?", "注意",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        return;
                    }
                }
                string str = System.IO.Directory.GetCurrentDirectory();
                string filePath = str + @"\"+ PYTHON_INSTALL_FILE;
                if (File.Exists(filePath))
                {
                    Process process = new Process();
                    process.StartInfo.FileName = filePath;
                    process.StartInfo.UseShellExecute = true;
                    process.Start();
                }
                else
                {
                    MessageBox.Show("找不到python插件安裝檔");
                }
            }
            else
            {
                MessageBox.Show("找不到python環境");
            }
        }
        private void WriteBat()
        {
            string pipPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
+ @"\Programs\Python\Python36\Scripts\pip3.6.exe";
            switch (_windows)
            {
                case WindowsType.Win7:
                    {
                        string str = System.IO.Directory.GetCurrentDirectory() + @"\SetupwithCuda10.bat";
                        if(File.Exists(str))
                        {
                            File.Delete(str);
                        }
                        using (StreamWriter sw = new StreamWriter(str))   //小寫TXT     
                        {
                            sw.WriteLine("@echo off");
                            sw.WriteLine(pipPath + @" install --no-index --find-links=.\spark-libs -r requirements.txt");
                            sw.WriteLine(pipPath + @" install --no-index --find-links=.\cu10.2 -r requirements10.txt");
                            sw.WriteLine("pause");
                        }
                    }
                    break;
                case WindowsType.Win10:
                    {
                        string str = System.IO.Directory.GetCurrentDirectory() + @"\SetupwithCuda11.bat";
                        if (File.Exists(str))
                        {
                            File.Delete(str);
                        }
                        using (StreamWriter sw = new StreamWriter(str))   //小寫TXT     
                        {
                            sw.WriteLine("@echo off");
                            sw.WriteLine(pipPath + @" install --no-index --find-links=.\spark-libs -r requirements.txt");
                            sw.WriteLine(pipPath + @" install --no-index --find-links=.\cu11 -r requirements11.txt");
                            sw.WriteLine("pause");
                        }
                    }
                    break;
                default:
                    break;
            }
            
        }
        private void ExtraZipFile()
        {
            string str = System.IO.Directory.GetCurrentDirectory();
            string zipFilePath = str + @"\bin\"+CUDADNNFILE;
            string extractionPath = str + @"\bin\";
            if (Directory.Exists(extractionPath + "cuda"))
                Directory.Delete(extractionPath + "cuda", true);
            ZipFile.ExtractToDirectory(zipFilePath, extractionPath);

            if(_windows == WindowsType.Win10)
            {
                bool state = CopyDirectory(extractionPath + "cuda",
    @"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.1", true);
            }
            else
            {
                bool state = CopyDirectory(extractionPath + "cuda",
@"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.2", true);
            }


            Console.WriteLine("Extracted Successfully");
            MessageBox.Show("Cudnn 安裝完成");

            btn_Cudnn.Invoke(new MethodInvoker(delegate ()
            {
                btn_Cudnn.Enabled = true;
                btn_Cuda.Enabled = true;
            }));
        }

        private static bool CopyDirectory(string SourcePath, string DestinationPath, bool overwriteexisting)
        {
            bool ret = false;
            try
            {
                SourcePath = SourcePath.EndsWith(@"\") ? SourcePath : SourcePath + @"\";
                DestinationPath = DestinationPath.EndsWith(@"\") ? DestinationPath : DestinationPath + @"\";

                if (Directory.Exists(SourcePath))
                {
                    if (Directory.Exists(DestinationPath) == false)
                        Directory.CreateDirectory(DestinationPath);

                    foreach (string fls in Directory.GetFiles(SourcePath))
                    {
                        FileInfo flinfo = new FileInfo(fls);
                        flinfo.CopyTo(DestinationPath + flinfo.Name, overwriteexisting);
                    }
                    foreach (string drs in Directory.GetDirectories(SourcePath))
                    {
                        DirectoryInfo drinfo = new DirectoryInfo(drs);
                        if (CopyDirectory(drs, DestinationPath + drinfo.Name, overwriteexisting) == false)
                            ret = false;
                    }
                }
                ret = true;
            }
            catch (Exception ex)
            {
                ret = false;
            }
            return ret;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            CheckWindowOS();
            CheckPythonWhl();
        }


    }
}
