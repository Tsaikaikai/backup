﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Algorithm.ROI;
using HalconDotNet;
using Logging;

namespace Algorithm.Controls
{
    public partial class HControl : UserControl
    {
        /// <summary>
        /// HControl Paint Event Handler
        /// </summary>
        public event HPaintEventHandler HPaintChanged;

        /// <summary>No action is performed on mouse events</summary>
        public const int MODE_VIEW_NONE = 10;
        /// <summary>Zoom is performed on mouse events</summary>
        public const int MODE_VIEW_ZOOM = 11;
        /// <summary>Move is performed on mouse events</summary>
        public const int MODE_VIEW_MOVE = 12;

        //fields
        private Size m_ImageSize = new Size(640, 480);
        private PointF m_MouseDown;
        private PointF m_ViewPort;
        private HImage m_Himage;
        private HWindow m_Window;
        private ROIController m_RoiManager;

        private int m_BorderWidth = 0;
        private int m_DispROI = 0;
        private int m_StateView = 0;
        private bool m_MousePressed;
        private float m_Zoom = 1.0f;
        private int _Multiplication=1;

        //property
        public ToolsControl FormToolCotrol { get; set; }

        public float Zoom
        {

            get { return m_Zoom; }
        }
        /// <summary>
        /// 
        /// </summary>
        public HWindow Window
        {
            get { return m_Window; }
        }
        /// <summary>
        /// constructor
        /// </summary>
        public HControl()
        {
            initialValue();
            //init
            base.Resize += new EventHandler(this.resize);
            this.MouseUp += new MouseEventHandler(this.mouseUp);
            this.MouseDown += new MouseEventHandler(this.mouseDown);
            this.MouseMove += new MouseEventHandler(this.mouseMove);
        }

        #region public method

        /// <summary>
        /// Create HWindows
        /// </summary>
        public void CreateWindow()
        {
            if (this.m_Window == null)
            {
                int r, c, h, w;

                r = m_BorderWidth;
                c = m_BorderWidth;

                w = base.Width - (2 * m_BorderWidth);
                h = base.Height - (2 * m_BorderWidth);

                HOperatorSet.SetCheck("~father");
                this.m_Window = new HWindow(r, c, w, h, base.Handle, "visible", "");

                Reset(true);
            }
        }

        /// <summary>
        /// Create HWindows
        /// </summary>
        public void CreateWindow(int multiplication)
        {
            if (this.m_Window == null)
            {
                int r, c, h, w;

                r = this.m_BorderWidth;
                c = this.m_BorderWidth;

                w = base.Width - (2 * this.m_BorderWidth);
                h = base.Height - (2 * this.m_BorderWidth);

                HOperatorSet.SetCheck("~father");
                this.m_Window = new HWindow(r, c, w, h, base.Handle, "visible", "");
                this._Multiplication = multiplication;
                Reset(true);
            }
        }

        /// <summary>
        /// Add HObject to 
        /// </summary>
        /// <param name="obj"></param>
        public void AddIconicVar(HObject obj)
        {
            int h, w;
            string s;

            if (obj == null)
            {
                return;
            }
            m_Himage = (HImage)obj;

            m_Himage.GetImagePointer1(out s, out w, out h);

            this.m_ImageSize = new Size(w, h);

            Reset(true);

            this.Focus();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ptr"></param>
        public void AddIconicVar(IntPtr ptr)
        {
            Rectangle rect = new Rectangle()
            {
                X = 0,
                Y = 0,
                Width = base.Width,
                Height = base.Height
            };
            DrawImage(ptr, rect);
        }
        /// <summary>
        /// reset View port
        /// </summary>
        /// <param name="resetViewport"></param>
        public void Reset(bool resetViewport)
        {
            if (m_Window != null)
            {
                if (resetViewport)
                {
                    initialValue();

                    if (m_RoiManager != null)
                    {
                        m_RoiManager.reset();
                    }
                    SetViewPort(new RectangleF(0, 0, m_ImageSize.Width, m_ImageSize.Height));
                }
            }
        }

        /// <summary>
        /// Repaint 
        /// </summary>
        public void Repaint()
        {
            if (m_Himage == null)
            {
                return;
            }

            int x, y;
            float w = base.Width / m_Zoom;
            float h = base.Height / m_Zoom;

            //Do checks the reason 30,000 is used is because much over this will cause DrawImage to crash
            if (w > 30000.0f)
            {
                m_Zoom = base.Width / 30000.0f;
                w = 30000.0f;
            }
            if (h > 30000.0f)
            {
                m_Zoom = base.Height / 30000.0f;
                h = 30000.0f;
            }

            //we stop at 2 because at this point you have almost zoomed into a single pixel
            if (w < 2.0f)
            {
                m_Zoom = base.Width / 2.0f;
                w = 2.0f;
            }
            if (h < 2.0f)
            {
                m_Zoom = base.Height / 2.0f;
                h = 2.0f;
            }

            int wz2 = (int)Math.Round(w / 2.0f);
            int hz2 = (int)Math.Round(h / 2.0f);


            x = (int)(m_ViewPort.X - wz2);
            y = (int)(m_ViewPort.Y - hz2);

            Rectangle rect = new Rectangle(x, y, (int)(w), (int)(h));
            HTuple r1, c1, r2, c2;

            //m_ViewPort = new PointF(rect.X, rect.Y);
            r1 = rect.Y;
            c1 = rect.X;
            r2 = rect.Y + rect.Height;
            c2 = rect.X + rect.Width;

            DrawImage(r1, c1, r2, c2);

            drawROI();
            //SetRectangle(new System.Drawing.Rectangle(0, 0, (int)(8192 / m_Zoom), (int)(15000 / m_Zoom)));
            //this.Text = string.Format(m_FormatHdr, m_ViewPort.X, m_ViewPort.Y, m_Zoom * 100);
        }

        /// <summary>
        /// 從IntPtr 
        /// </summary>
        /// <param name="rect"></param>
        public void DrawImage(IntPtr ptr, Rectangle rect)
        {

            /*byte[] byteArray = m_ImageRowData.Get<byte>(m_ViewPort.X, m_ViewPort.Y, m_ViewPort.Width, m_ViewPort.Height);

            GCHandle handle = GCHandle.Alloc(byteArray, GCHandleType.Pinned);

            HImage m_Himage = new HImage("byte", m_ViewPort.Width, m_ViewPort.Height, handle.AddrOfPinnedObject());

            DrawImage(r1, c1, r2, c2);*/
        }
        public void SetViewState(int mode)
        {
            m_StateView = mode;

            if (m_RoiManager != null)
                m_RoiManager.resetROI();
        }

        #region Draw

        /// <summary>
        /// Draw Rectangle
        /// </summary>
        public void DrawRectangle()
        {
            if (m_Window == null)
            {
                return;
            }
            //drawStart();
            string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
            int fontSize = (int)(18);
            HTuple font = string.Format(fontFormat, fontSize);

            int lineSize = 5;
            HOperatorSet.SetLineStyle(m_Window, 0);
            HOperatorSet.SetColor(m_Window, "red");
            HOperatorSet.SetDraw(m_Window, "margin");

            HOperatorSet.SetTposition(m_Window, 480, 640);
            HOperatorSet.SetFont(m_Window, font);
            HOperatorSet.WriteString(m_Window, "1:1");

            HOperatorSet.DispRectangle1(m_Window, 640, 480, 1024, 768);

            //drawEnd();
        }

        /// <summary>
        /// Draw Font
        /// </summary>
        public void DrawFont(string value)
        {
            string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
            int fontSize = (int)(10 * m_Zoom);
            HTuple font = string.Format(fontFormat, fontSize);
            HOperatorSet.SetFont(m_Window, font);
            HOperatorSet.WriteString(m_Window, value);
        }

        #endregion

        #region ROI

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rC"></param>
        public void UseROIController(ROIController rC)
        {
            m_RoiManager = rC;
            rC.setViewController(this);
        }

        private void drawROI()
        {
            if (m_RoiManager != null && (m_DispROI == 1))
            {
                m_RoiManager.paintData(m_Window);
            }
        }

        #endregion

        #endregion

        #region private

        private void initialValue()
        {
            this.m_DispROI = 1;
            this.m_BorderWidth = 0;
            this.m_StateView = MODE_VIEW_NONE;
            this.m_MousePressed = false;
            this.m_Zoom = 1.0f;
        }

        private void resize(object sender, EventArgs e)
        {
            try
            {
                lock (this)
                {
                    if (m_Window == null)
                    {
                        return;
                    }
                    HOperatorSet.SetWindowExtents(m_Window, 0, 0, base.Width, base.Height);
                    Repaint();
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void mouseDown(object sender, MouseEventArgs e)
        {
            lock (this)
            {
                try
                {
                    if (m_Window == null)
                    {
                        return;
                    }
                    m_MousePressed = true;
                    int activeROIidx = -1;

                    HTuple r, c, b;
                    HOperatorSet.GetMposition(m_Window, out r, out c, out b);
                    Log.Trace(string.Format("X : {0} Y : {1} ", e.X , e.Y));
                    m_MouseDown = new Point(c, r);

                    if (m_RoiManager != null)
                    {
                        activeROIidx = m_RoiManager.mouseDownAction(c, r);
                    }
                    if (activeROIidx == -1)
                    {
                        switch (m_StateView)
                        {
                            case MODE_VIEW_MOVE:
                                m_MouseDown = new Point(c, r);
                                break;
                            case MODE_VIEW_ZOOM:
                                //if (e.Button == System.Windows.Forms.MouseButtons.Left)
                                //    scale = 0.9;
                                //else
                                //    scale = 1 / 0.9;
                                //zoomImage(e.X, e.Y, scale);
                                break;
                            case MODE_VIEW_NONE:
                                break;
                            default:
                                break;
                        }
                    }
                    setText();
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void mouseMove(object sender, MouseEventArgs e)
        {
            lock (this)
            {
                try
                {
                    PointF mousePosNow;
                    if (m_Window == null)
                    {
                        return;
                    }
                    MouseEventArgs mouse = e as MouseEventArgs;

                    HTuple r, c, b;
                    HOperatorSet.GetMposition(m_Window, out r, out c, out b);
                    mousePosNow = new Point(c, r);

                    if (mouse.Button == MouseButtons.Left)
                    {
                        if (!m_MousePressed)
                        {
                            return;
                        }

                        if (m_RoiManager != null && (m_RoiManager.activeROIidx != -1))
                        {
                            m_RoiManager.mouseMoveAction(c, r);
                        }
                        else
                        {
                            // the distance the mouse has been moved since mouse was pressed
                            float deltaX = mousePosNow.X - m_MouseDown.X;
                            float deltaY = mousePosNow.Y - m_MouseDown.Y;
                            // calculate new offset of image based on the current zoom factor
                            float x = m_ViewPort.X + (-deltaX);
                            float y = m_ViewPort.Y + (-deltaY);
                            m_ViewPort = new PointF(x, y);
                            //repaint image
                            Repaint();

                        }
                    }
                    int nowX = (int)(mousePosNow.X * this._Multiplication);
                    int nowY = (int)(mousePosNow.Y * this._Multiplication);
                    PerformPaintEvent((int)nowX, (int)nowY, this.m_Zoom);
                    PerformPaintEvent((int)mousePosNow.X, (int)mousePosNow.Y, this.m_Zoom);
                }
                catch (Exception ex)
                {
                    Log.Trace(ex.ToString());
                }
            }
        }

        private void mouseUp(object sender, MouseEventArgs e)
        {
            m_MousePressed = false;

            if ((m_RoiManager != null) && (m_RoiManager.activeROIidx != -1) && (m_DispROI == 1))
            {
                m_RoiManager.defineModelROI();

            }
            //Size 
            setText();
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            try
            {
                float oldzoom = m_Zoom;

                m_Zoom += m_Zoom * (e.Delta / 1200.0f);

                //if (e.Delta > 0)
                //{
                //    float x = m_ViewPort.X + ((e.X - (base.Width / 2)) / (2 * m_Zoom));
                //    float y = m_ViewPort.Y + ((e.Y - (base.Height / 2)) / (2 * m_Zoom));

                //    m_ViewPort = new PointF(x, y);
                //}

                Repaint();
                setText();
            }
            catch (Exception ex)
            {
            }
        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            const int WM_KEYDOWN = 0x100;
            const int WM_SYSKEYDOWN = 0x104;

            if ((msg.Msg == WM_KEYDOWN) || (msg.Msg == WM_SYSKEYDOWN))
            {
                switch (keyData)
                {
                    case Keys.Right:
                        m_ViewPort.X += (int)(base.Width * 0.1F / m_Zoom);
                        Repaint();
                        break;

                    case Keys.Left:
                        m_ViewPort.X -= (int)(base.Width * 0.1F / m_Zoom);
                        Repaint();
                        break;

                    case Keys.Down:
                        m_ViewPort.Y += (int)(base.Height * 0.1F / m_Zoom);
                        Repaint();
                        break;

                    case Keys.Up:
                        m_ViewPort.Y -= (int)(base.Height * 0.1F / m_Zoom);
                        Repaint();
                        break;

                    case Keys.PageDown:
                        m_ViewPort.Y += (int)(base.Height * 0.90F / m_Zoom);
                        Repaint();
                        break;

                    case Keys.PageUp:
                        m_ViewPort.Y -= (int)(base.Height * 0.90F / m_Zoom);
                        Repaint();
                        break;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void setText()
        {
            int x = (int)(this.m_MouseDown.X * this._Multiplication);
            int y = (int)(this.m_MouseDown.Y * this._Multiplication);
            PerformPaintEvent((int)m_MouseDown.X, (int)m_MouseDown.Y, m_Zoom);
        }

        private void SetViewPort(RectangleF rect)
        {
            //Find smallest screen extent and zoom to that
            if (rect.Height > rect.Width)
            {
                this.m_Zoom = rect.Width / m_ImageSize.Width;
            }
            else
            {
                this.m_Zoom = rect.Height / m_ImageSize.Height;
            }

            float centerX = rect.X + (rect.Width / 2.0f);
            float centerY = rect.Y + (rect.Height / 2.0f);
            m_ViewPort = new PointF(centerX, centerY);
        }

        private void DrawStart()
        {
            HOperatorSet.SetSystem("flush_graphic", "false");
            HOperatorSet.ClearWindow(m_Window);
        }

        private void DrawEnd()
        {
            HOperatorSet.SetSystem("flush_graphic", "true");
            HOperatorSet.SetColor(m_Window, "black");
            HOperatorSet.DispLine(m_Window, -100.0, -100.0, -101.0, -101.0);
        }

        private void DrawImage(HTuple row1, HTuple col1, HTuple row2, HTuple col2)
        {
            if (m_Himage == null)
            {
                return;
            }
            //draw start
            DrawStart();
            HOperatorSet.SetPart(m_Window, row1, col1, row2, col2);
            HOperatorSet.DispImage(m_Himage, m_Window);
            //draw end
            DrawEnd();
        }

        private void PerformPaintEvent(Size size)
        {
            if (HPaintChanged != null)
            {
                HPaintEventArgs args = new HPaintEventArgs(size);
                AsyncInvoke(HPaintChanged, args);
            }
        }

        private void PerformPaintEvent(int x, int y, float zoom)
        {
            if (HPaintChanged != null)
            {
                HPaintEventArgs args = new HPaintEventArgs(x, y, zoom);
                AsyncInvoke(HPaintChanged, args);
            }
        }

        /// Async Invoke to target form
        private void AsyncInvoke(HPaintEventHandler handler, HPaintEventArgs args)
        {
            Delegate[] tpcs = handler.GetInvocationList();
            foreach (HPaintEventHandler tpc in tpcs)
            {
                if (tpc.Target is System.Windows.Forms.Control)
                {
                    Control targetForm = tpc.Target as System.Windows.Forms.Control;
                    targetForm.BeginInvoke(tpc, new object[] { this, args });
                }
                else
                {
                    tpc.BeginInvoke(this, args, null, null);
                }
            }
        }
        #endregion


        #region Halcon Operation

        public void SetCross()
        {
            //DrawStart();

            HOperatorSet.SetColor(m_Window, "red");
            HOperatorSet.DispCross(m_Window, 10, 10, 4, 0);
            //HOperatorSet.DispLine(m_Window, -100.0, -100.0, -101.0, -101.0);
            //DrawEnd();
        }

        public void SetCross(double row, double col)
        {
            HOperatorSet.SetColor(m_Window, "red");
            HOperatorSet.DispCross(m_Window, row, col, 4, 0);
        }

        public void SetRectangle(Rectangle rect)
        {
            HOperatorSet.SetDraw(m_Window, "margin");
            HOperatorSet.SetColor(m_Window, "blue");
            //HOperatorSet.SetLineWidth(hWinHandle, linewidth);
            HOperatorSet.DispRectangle1(m_Window, rect.Y, rect.X, (double)(rect.Y + rect.Height-1), (double)(rect.X + rect.Width - 1));

            //HOperatorSet.SetLineStyle(m_Window, 10);

            //HOperatorSet.SetColor(m_Window, "blue");

            //int row2 = (rect.Y + rect.Height);
            //int col2 = (rect.X + rect.Width);
            //HOperatorSet.DispRectangle1(m_Window, rect.Y, rect.X, row2, col2);
        }
        #endregion

    }
}
