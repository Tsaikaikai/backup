﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeasureWaferRecipe
{
    public class SalmonAlgorithm
    {
        CAlgorithmConfig Config = new CAlgorithmConfig();

        public SalmonAlgorithm()
        {

        }

        public bool LoadConfig(string ConfigPath)
        {
            try
            {
                Config = Config.ReadXmlConfig(ConfigPath);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SaveConfig(string ConfigPath)
        {
            try
            {
                Config.WriteXmlConfig(ConfigPath);     
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DoAlignment(HObject[] SourceImageArr, ref HObject AlignedImage, ref HObject LineScanNotchImage,
                                ref int NotchLocate, ref HTuple CropRows, ref HTuple CropCols)
        {
            try
            {
                HObject tempAlignImg = new HObject();
                HObject tempNotchImg = new HObject();
                HTuple tempRows = new HTuple();
                HTuple tempCols = new HTuple();
                int tempNotchLocate = -1;

                //check image size
                if (SourceImageArr.Length == Config.LineScanSlice)
                {
                    for (int i = 0; i < SourceImageArr.Length; i++)
                    {
                        HOperatorSet.GetImageSize(SourceImageArr[i], out HTuple w, out HTuple h);
                        int eachH = Config.LineScanHeight / Config.LineScanSlice;
                        if (w != Config.LineScanWidth || h != eachH)
                        {
                            throw new Exception("Image size not match.");
                        }
                    }
                }
                else
                {
                    throw new Exception("Image slice number not match.");
                }


                HOperatorSet.ReadShapeModel(Config.NotchModelPath, out HTuple NotchModel);
                HalconFunction.MatchNotch2HObject(out HObject HO_img_raw, out tempAlignImg, out tempNotchLocate,
                    SourceImageArr, NotchModel, Config.AlignMinScore, Config.LineScanWidth, Config.LineScanHeight);

                //check notch exist
                if (tempNotchLocate == -1)
                {
                    throw new Exception("Can't find notch in image.");
                }

                HalconFunction.CalculateEdgePntAndCropNotch(tempAlignImg, out tempNotchImg, NotchModel,
                    Config.CropNotchWidth, Config.InsideInspectWidth, Config.LineScanPixelSize, Config.CropSize, Config.AlignMinScore,
                    out tempRows, out tempCols, out HTuple hv_ErrMsg, out HTuple notch_location);

                AlignedImage = tempAlignImg;
                LineScanNotchImage = tempNotchImg;
                NotchLocate = tempNotchLocate;
                CropRows = tempRows;
                CropCols = tempCols;

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Alignment Fail." + ex);
            }
        }

        public bool DoNotchMeasure(HObject AreaNotchImage, ref HObject ResultImage, ref NotchMeasureResult Result)
        {
            try
            {
                //check image
                HalconFunction.CheckWaferAndNotchGray(AreaNotchImage, Config.NotchMeasureCheckRate,
                    out HTuple hv_Mean_L, out HTuple hv_Mean_R, out HTuple hv_Mean_T, out HTuple hv_Mean_B,
                    out HTuple hv_RectangleL, out HTuple hv_RectangleR, out HTuple hv_RectangleT, out HTuple hv_RectangleB,
                    out HTuple hv_Deviation_L, out HTuple hv_Deviation_R, out HTuple hv_Deviation_T, out HTuple hv_Deviation_B,
                    out HTuple hv_Min_L, out HTuple hv_Min_R, out HTuple hv_Min_T, out HTuple hv_Min_B,
                    out HTuple hv_Max_L, out HTuple hv_Max_R, out HTuple hv_Max_T, out HTuple hv_Max_B,
                    out HTuple hv_Contrast_L, out HTuple hv_Contrast_R, out HTuple hv_Contrast_T, out HTuple hv_Contrast_B);

                if (hv_Mean_T > 5 || hv_Mean_B < 254 || hv_Min_B < 200)
                {
                    throw new Exception("Input image is not in spec.");
                }
                //check notch exist
                HalconFunction.CheckNotchExist(AreaNotchImage, Config.NotchAreaModelPath, Config.NotchMatchMinScore, out HTuple hv_raw, out HTuple hv_col);
                if (hv_raw.Length == 0 || hv_col.Length == 0)
                {
                    throw new Exception("Can't find notch.");
                }

                //do
                HalconFunction.MeasureNotch(AreaNotchImage, out HObject ho_ResultImage, out HObject ho_OrgImage,
                     Config.NotchMeasurePixSize, Config.NotchMeasureRotate, Config.NotchMeasureResizeRate, Config.NotchGrayMin,
                     Config.B1Ang, Config.B2Ang, Config.U1, Config.U2, Config.RWidthLeft,
                     Config.RWidthRight, Config.PinR, Config.VRAng, Config.NotchAreaModelPath, Config.NotchMatchMinScore, out HTuple hv_Vh, out HTuple hv_Vw,
                    out HTuple hv_Vr, out HTuple hv_P1, out HTuple hv_P2, out HTuple hv_AngV, out HTuple hv_VR1,
                    out HTuple hv_VR2, out HTuple hv_ErrorMsg);

                NotchMeasureResult tempResult = new NotchMeasureResult();
                tempResult.Vh = hv_Vh;
                tempResult.Vw = hv_Vw;
                tempResult.Vr = hv_Vr;
                tempResult.P1 = hv_P1;
                tempResult.P2 = hv_P2;
                tempResult.AngV = hv_AngV;
                tempResult.Vr1 = hv_VR1;
                tempResult.Vr2 = hv_VR2;

                Result = tempResult;
                ResultImage = ho_ResultImage;

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Notch Measure Fail." + ex);
            }
        }

        public bool DoNotchInspect(HObject LineScanNotchImage, ref HObject ResultImage, ref List<Rectangle> TotalGlobalDefectList)
        {
            try
            {
                //check image
                HalconFunction.CheckWaferAndNotchGray(LineScanNotchImage, Config.NotchInspectCheckRate, out HTuple hv_Mean_L,
                    out HTuple hv_Mean_R, out HTuple hv_Mean_T, out HTuple hv_Mean_B, out HTuple hv_RectangleL,
                    out HTuple hv_RectangleR, out HTuple hv_RectangleT, out HTuple hv_RectangleB,
                    out HTuple hv_Deviation_L, out HTuple hv_Deviation_R, out HTuple hv_Deviation_T,
                    out HTuple hv_Deviation_B, out HTuple hv_Min_L, out HTuple hv_Min_R, out HTuple hv_Min_T,
                    out HTuple hv_Min_B, out HTuple hv_Max_L, out HTuple hv_Max_R, out HTuple hv_Max_T,
                    out HTuple hv_Max_B, out HTuple hv_Contrast_L, out HTuple hv_Contrast_R, out HTuple hv_Contrast_T,
                    out HTuple hv_Contrast_B);

                if (hv_Contrast_R > 0.1 || hv_Mean_R < 254 || hv_Mean_L > 200)
                {
                    throw new Exception("Input image is not in spec." +
                                        "\nContrast_Right = " + hv_Contrast_R +
                                        "\nMean_Right = " + hv_Mean_R +
                                        "\nMean_Left = " + hv_Mean_L);
                }

                HObject tempResultImage = new HObject();

                HalconFunction.InspectNotchDefect_v2(LineScanNotchImage, out tempResultImage, out HObject teachImage, out HObject teachCoutour,
                    Config.BackWhiteMinGray, Config.NotchInspectDisplayDilation, Config.NotchInnerDefectMaxGray, Config.NotchVmRowUp, Config.NotchVmRowDown,
                    Config.NotchBlackWidth, Config.InnerDefectMinWidth, Config.OutDefectMinWidth, out HTuple defectNum,
                    out HTuple hv_DefectRow1, out HTuple hv_DefectCol1, out HTuple hv_DefectRow2, out HTuple hv_DefectCol2);

                List<Rectangle> tempDefectList = new List<Rectangle>();
                Parallel.For(0, hv_DefectRow1.Length, j =>
                {
                    Rectangle defectLocate = new Rectangle(hv_DefectCol1[j], hv_DefectRow1[j],
                                                           hv_DefectCol2[j] - hv_DefectCol1[j],
                                                           hv_DefectRow2[j] - hv_DefectRow1[j]);
                    tempDefectList.Add(defectLocate);
                });

                TotalGlobalDefectList = tempDefectList;
                ResultImage = tempResultImage;
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Notch Inspect Fail : " + ex);
            }
        }

        public bool DoDiameterMeasure(HObject AlignedImage, ref double Diameter)
        {
            try
            {
                //SourceImage 必須將 Notch 置中
                HalconFunction.MeasureEdgePoints(AlignedImage, Config.Direction, Config.Sigma,
                    Config.Amplitude, Config.MeasurePosLength, Config.MeasurePosWidth, Config.MeasureGap,
                    out HTuple hv_EdgeY, out HTuple hv_EdgeX);


                //去除 Notch 位置，及圓形對面的點
                List<double> totalDiameter = new List<double>();
                double[] totalX = hv_EdgeX.ToDArr();
                double[] totalY = hv_EdgeY.ToDArr();

                int skipStart = (Config.LineScanHeight / 2) - (Config.NotchWidth / 2);
                int skipEnd = (Config.LineScanHeight / 2) + (Config.NotchWidth / 2);

                for (int i = 0; i < totalY.Length; i++)
                {
                    if (totalY[i] > (Config.NotchWidth / 2) && totalY[i] < skipStart)
                    {
                        totalDiameter.Add(totalX[i]);
                    }

                    if (totalY[i] > skipEnd && totalY[i] < (Config.LineScanHeight - (Config.NotchWidth / 2)))
                    {
                        totalDiameter.Add(totalX[i]);
                    }
                }

                double calculateDiameter = totalDiameter.Average();

                //偏心校正
                Diameter = Config.Alpha * calculateDiameter + Config.Beta;

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Diameter Measure Fail." + ex);
            }
        }

        public bool DoDefectInspect(HObject SourceImage, HTuple CropRows, HTuple CropCols, ref HObject ResultImage,
                                    ref List<InspectDefect> TotalDefectList)
        {
            try
            {
                if (CropRows.Length != CropCols.Length)
                {
                    throw new Exception("DefectInspect Fail. => Number of CropRows and CropCols not match.");
                }

                object locker1 = new object();
                object locker2 = new object();
                List<DefectInspectCropImage> tempImageList = new List<DefectInspectCropImage>();

                //Parallel.For(0, CropRows.Length, i =>
                for (int i = 0; i < CropRows.Length; i++)
                {
                    DefectInspectCropImage image = new DefectInspectCropImage();
                    HObject tempCropResultImage = new HObject();

                    HalconFunction.CropDomainImage(SourceImage, out HObject cropImage, out HObject cropAiImage, Config.LineScanPixelSize, Config.CropSize,
                                                   Config.InsideInspectWidth, CropRows[i], CropCols[i], Config.AIDrawStartX);

                    HalconFunction.InspectWaferEdgeDefectAndDrawAi(cropImage, cropAiImage,
                       out tempCropResultImage, Config.ROIWidthtoBevelCenter, Config.BevelWidth,
                         Config.DisplayDilation, Config.InnerThresholdMax, Config.AIDefectSize,
                         Config.AIMinGray, Config.InnerDefectAreaSize, Config.InnerDefectMaxGray, Config.OutDefectMinWidth,Convert.ToInt16(Config.PaintResult),
                       out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
                       out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber, out HTuple hv_Area);

                    List<InspectDefect> tempDefectList = new List<InspectDefect>();

                    //Parallel.For(0, hv_DefectRow1.Length, j =>
                    for (int j = 0; j < hv_DefectRow1.Length; j++)
                    {
                        InspectDefect tempDefect = new InspectDefect();
                        Rectangle tempLocalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j],
                                                                    (Int32)hv_DefectRow1.DArr[j],
                                                                    (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                    (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                        Rectangle tempGlobalPosition = new Rectangle((Int32)hv_DefectCol1.DArr[j] + (Int32)CropCols.DArr[i],
                                                                    (Int32)hv_DefectRow1.DArr[j] + (Int32)CropRows.DArr[i],
                                                                    (Int32)hv_DefectCol2.DArr[j] - (Int32)hv_DefectCol1.DArr[j],
                                                                    (Int32)hv_DefectRow2.DArr[j] - (Int32)hv_DefectRow1.DArr[j]);

                        double tempAngle = (tempGlobalPosition.Y - (Config.LineScanHeight / 2)) / (double)Config.LineScanHeight * 360.0;
                        if (tempAngle < 0) tempAngle = tempAngle + 360;
                        tempDefect.Angle = tempAngle;
                        tempDefect.Area = (Int32)hv_Area.DArr[j];
                        tempDefect.LocalPosition = tempLocalPosition;
                        tempDefect.GlobalPosition = tempGlobalPosition;
                        lock (locker1)
                        {
                            tempDefectList.Add(tempDefect);
                        }
                    };

                    image.SourceCropImage = cropImage;
                    image.CropResultImage = tempCropResultImage;
                    image.GlobalX = (Int32)CropCols.DArr[i];
                    image.GlobalY = (Int32)CropRows.DArr[i];
                    image.DefectList = tempDefectList;
                    lock (locker2)
                    {
                        tempImageList.Add(image);
                    }
                };

                //sort list by GlobalY
                //imageList.Sort(new ImageYComparer());
                List<DefectInspectCropImage> imageList = tempImageList.OrderBy(DefectInspectCropImage => DefectInspectCropImage.GlobalY).ToList();

                //Tile Images and merge global defect
                HObject[] cropResultImages = new HObject[imageList.Count()];

                TotalDefectList?.Clear();
                TotalDefectList = new List<InspectDefect>();

                for (int i = 0; i < imageList.Count(); i++)
                {
                    cropResultImages[i] = imageList[i].CropResultImage;
                    TotalDefectList = TotalDefectList.Concat(imageList[i].DefectList).ToList();
                }

                HalconFunction.TileAllImages(cropResultImages, out HObject resultImage);
                ResultImage = resultImage;
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Defect Inspect Fail : " + ex);
            }
        }

        public bool DoEdgeMeasure(HObject[] EdgeSourceImageArr, int NotchLocY, ref List<EdgeMeasureResult> ResultImageList,
                                  ref EdgeMeasureResultData STDResultData)
        {
            try
            {
                List<EdgeMeasureResult> resultList = new List<EdgeMeasureResult>();

                int lineScanPixGap = Config.LineScanHeight / EdgeSourceImageArr.Length; //120000 / 72 = 1666.66
                int degGap = Config.LineScanHeight / 360; //120000 / 360 = 333.33

                Parallel.For(0, EdgeSourceImageArr.Length, i =>
                //for (int i = 0; i < SideSourceImageArr.Length; i++)
                {
                    EdgeMeasureResultData resultData = new EdgeMeasureResultData();
                    EdgeMeasureResult measureResult = new EdgeMeasureResult();

                    //check image
                    HalconFunction.CheckWaferAndNotchGray(EdgeSourceImageArr[i], Config.EdgeRegionRate, out HTuple hv_Mean_L,
                        out HTuple hv_Mean_R, out HTuple hv_Mean_T, out HTuple hv_Mean_B, out HTuple hv_RectangleL,
                        out HTuple hv_RectangleR, out HTuple hv_RectangleT, out HTuple hv_RectangleB,
                        out HTuple hv_Deviation_L, out HTuple hv_Deviation_R, out HTuple hv_Deviation_T,
                        out HTuple hv_Deviation_B, out HTuple hv_Min_L, out HTuple hv_Min_R, out HTuple hv_Min_T,
                        out HTuple hv_Min_B, out HTuple hv_Max_L, out HTuple hv_Max_R, out HTuple hv_Max_T,
                        out HTuple hv_Max_B, out HTuple hv_Contrast_L, out HTuple hv_Contrast_R, out HTuple hv_Contrast_T,
                        out HTuple hv_Contrast_B);

                    if (hv_Mean_L < 254 || hv_Mean_R < 254 || hv_Mean_B < 254 ||
                        hv_Deviation_L > 2 || hv_Deviation_R > 2 || hv_Deviation_B > 2)
                    {
                        measureResult.ResultImage = EdgeSourceImageArr[i];
                    }
                    else if (hv_Contrast_T < 0.3)
                    {
                        measureResult.ResultImage = EdgeSourceImageArr[i];
                    }
                    else
                    {
                        //do
                        HalconFunction.MeasureWaferEdgeB(EdgeSourceImageArr[i], out HObject ho_ImageOut, out HObject ho_rotateImage,
                            Config.SidePixelSize, Config.EdgeRotateAngle, Config.EdgeGrayMax,
                            Config.EdgeRoiY1, Config.EdgeRoiX1, Config.EdgeRoiY2, Config.EdgeRoiX2, Config.A1Ang, Config.A2Ang,
                            Config.C1Ang, Config.C2Ang, Config.Bu11, Config.Bv11, Config.Bu22,
                            Config.Bv22, Config.ExAngle, Config.ScaleW, Config.ScaleH, Config.BevelMeasureNum,
                            out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
                            out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
                            out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
                            out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
                            out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
                            out HTuple hv_TextsY);

                        resultData.A1 = hv_A1;
                        resultData.A2 = hv_A2;
                        resultData.B1 = hv_B1;
                        resultData.B2 = hv_B2;
                        resultData.BC = hv_BC;
                        resultData.C1 = hv_C1;
                        resultData.C2 = hv_C2;
                        resultData.R1 = hv_R1;
                        resultData.R2 = hv_R2;
                        resultData.t = hv_t;
                        resultData.Ang1 = hv_Ang1;
                        resultData.Ang2 = hv_Ang2;
                        measureResult.ResultImage = ho_ImageOut;
                    }

                    //calculate angle
                    double transDegree = (i * lineScanPixGap - NotchLocY) / degGap;
                    if (transDegree < 0) transDegree = transDegree + 360;

                    measureResult.SourceImage = EdgeSourceImageArr[i];
                    measureResult.ResultData = resultData;
                    measureResult.Angle = transDegree;
                    resultList.Add(measureResult);
                });

                //按角度排序並輸出總結果
                ResultImageList = resultList.OrderBy(SideMeasureResult => SideMeasureResult.Angle).ToList();
                //輸出統計一倍標準差結果
                STDResultData = HalconFunction.StatisticsMeasureEdgeResult(resultList);

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Side Measure Fail." + ex);
            }
        }
    }

    [Serializable]
    public class EdgeMeasureResult
    {
        public HObject SourceImage;
        public HObject ResultImage;
        public EdgeMeasureResultData ResultData;
        public double Angle;
        public EdgeMeasureResult()
        {
        }

        public void Dispose()
        {
            SourceImage?.Dispose();
            ResultImage?.Dispose();
        }
    }

    [Serializable]
    public class EdgeMeasureResultData
    {
        public double A1 = -1;
        public double A2 = -1;
        public double B1 = -1;
        public double B2 = -1;
        public double BC = -1;
        public double C1 = -1;
        public double C2 = -1;
        public double R1 = -1;
        public double R2 = -1;
        public double t = -1;
        public double Ang1 = -1;
        public double Ang2 = -1;
    }

    [Serializable]
    public class NotchMeasureResult
    {
        public double Vh;
        public double Vw;
        public double Vr;
        public double P1;
        public double P2;
        public double AngV;
        public double Vr1;
        public double Vr2;

        public NotchMeasureResult()
        {

        }
        public void Dispose()
        {
            SourceImage?.Dispose();
            ResultImage?.Dispose();
        }
    }

    [Serializable]
    public class DefectInspectCropImage
    {
        public HObject SourceCropImage;

        public int GlobalX;

        public int GlobalY;

        public HObject CropResultImage;

        public List<InspectDefect> DefectList;


        public DefectInspectCropImage()
        {
        }

        public void Dispose()
        {
            SourceCropImage?.Dispose();
            CropResultImage?.Dispose();
        }

    }

    [Serializable]
    public class InspectDefect
    {
        public double Angle;
        public int Area;
        public Rectangle LocalPosition;
        public Rectangle GlobalPosition;
    }

    [Serializable]
    class ImageYComparer : IComparer<DefectInspectCropImage>
    {
        public int Compare(DefectInspectCropImage a, DefectInspectCropImage b)
        {
            return a.GlobalY.CompareTo(b.GlobalY);
        }
    }

}
