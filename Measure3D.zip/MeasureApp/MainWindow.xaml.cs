using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HalconDotNet;
using Halcon3DLibrary;
using System.Diagnostics;

namespace MeasureApp
{
    public partial class MainWindow : Window
    {
        // === 測試用硬編碼參數（實際部署改從設定檔或 UI 讀取）===
        private const double XResolution = 0.02;    // mm/pixel
        private const double YResolution = 0.02;    // mm/line
        private const double ZScale = 1;   // count → mm (Keyence LJ-X8000)
        private const double CenterU = 750;      // 影像中心點 U 座標（實測時通常填 影像寬度/2）
        private const double ZInvalidThreshold = 0; // 深度值無效的閾值（實際情況根據相機特性調整）


        // 檔案路徑：VirtualMode 下不會真的去讀，填假路徑也無妨
        private string _depthPath = @"D:\TestData\scan.tiff";
        private string _modelPath = @"D:\TestData\model.shm";

        // === Pipeline 狀態 ===
        private MeasureContext _ctx;                 // 跨步驟共用的資料容器
        private List<StepItem> _steps;               // 所有步驟的狀態物件
        private int _nextStepIndex;                  // 下一個要執行的步驟索引
        private bool _virtualMode = true;
        private bool _useGpu = false;

        public MainWindow()
        {
            InitializeComponent();
            // 改用 Loaded 事件：確保所有 x:Name 控制項都已 ready 後才組 pipeline，
            // 避免在建構子階段訪問未初始化的 TxtDepthPath/StepsList 等造成 NRE。
            Loaded += (s, e) => BuildPipeline();
        }

        // =========================================================
        // 組裝 Pipeline（建立所有步驟的 IAlgorithmModule 實例）
        // =========================================================
        private void BuildPipeline()
        {
            // 若 UI 已 ready，從 TextBox 同步最新路徑；否則用 field 的預設值
            if (TxtDepthPath != null) _depthPath = TxtDepthPath.Text;
            if (TxtModelPath != null) _modelPath = TxtModelPath.Text;
            var depthPath = _depthPath;
            var modelPath = _modelPath;

            _steps = new List<StepItem>
            {
                new StepItem("1. DepthImageLoader", "載入深度圖 → ctx.DepthImage",
                    new DepthImageLoader
                    {
                        FilePath    = depthPath,
                        OutputName  = "",
                        VirtualMode = _virtualMode,
                    }),

                new StepItem("2. DepthImageFilter (Gaussian)", "濾波 → ctx.FilteredDepthImage",
                    new DepthImageFilter
                    {
                        FilterType      = "Gaussian",
                        MaskSize        = 5,
                        InputImageName  = "",
                        OutputImageName = "",
                        VirtualMode     = _virtualMode,
                    }),

                new StepItem("3. Shape25DAlignment", "2.5D 對位 → ctx.CurrentPose + ctx.AlignedCloud",
                    new Shape25DAlignment
                    {
                        ModelPath         = modelPath,
                        MinScore          = 0.5,
                        NumMatches        = 1,
                        AngleStart        = -Math.PI,
                        AngleExtent       = 2 * Math.PI,
                        Greediness        = 0.9,
                        PrincipalCol      = 0,       // 實測時通常填 影像寬度/2
                        PrincipalRow      = 0,
                        OffsetX           = 0,
                        OffsetY           = 0,
                        DepthOffset       = 0,
                        ZInvalidThreshold = 0,
                        InputDepthName    = "",
                        OutputCloudName   = "",
                        VirtualMode       = _virtualMode,
                    }),

                new StepItem("4a. RegionSelectorBox (Line1_ROI)", "切左半邊 ROI",
                    new RegionSelectorBox
                    {
                        OutputName     = "Line1_ROI",
                        MinX = 650 * 0.02,  MaxX = 700 * 0.02,
                        MinY = 1170 * 0.02, MaxY = 1670 * 0.02,
                        MinZ = 20.0 / 0.02,        MaxZ = 46.0 / 0.02,
                        InputCloudName = "",
                        VirtualMode    = _virtualMode,
                    }),

                new StepItem("4b. RegionSelectorBox (Line2_ROI)", "切右半邊 ROI",
                    new RegionSelectorBox
                    {
                        OutputName     = "Line2_ROI",
                        MinX = 970* 0.02, MaxX = 1070* 0.02,
                        MinY = 1730* 0.02, MaxY = 2130* 0.02,
                        MinZ = 20.0 / 0.02,        MaxZ = 46.0 / 0.02,
                        InputCloudName = "",
                        VirtualMode    = _virtualMode,
                    }),

                new StepItem("5a. LineFitter (Line1)", "擬合第一條線",
                    new LineFitter
                    {
                        InputCloudName    = "Line1_ROI",
                        OutputName        = "Line1",
                        ForceXY           = true,
                        MinLinearityRatio = 10.0,
                        VirtualMode       = _virtualMode,
                    }),

                new StepItem("5b. LineFitter (Line2)", "擬合第二條線",
                    new LineFitter
                    {
                        InputCloudName    = "Line2_ROI",
                        OutputName        = "Line2",
                        ForceXY           = true,
                        MinLinearityRatio = 10.0,
                        VirtualMode       = _virtualMode,
                    }),

                new StepItem("6. MeasureLineToLine3D", "量測兩線距離 → ctx.MeasureResults[\"Dist_L2L\"]",
                    new MeasureLineToLine3D
                    {
                        LineAName   = "Line1",
                        LineBName   = "Line2",
                        OutputKey   = "Dist_L2L",
                        VirtualMode = _virtualMode,
                    }),
            };

            // null-safe：建構子內呼叫此方法時 StepsList 可能尚未初始化完畢
            if (StepsList != null)
                StepsList.ItemsSource = _steps;
            _nextStepIndex = 0;

            // 建立新的 context
            _ctx?.Dispose();
            _ctx = new MeasureContext();
            //設定解析度參數（實際情況可從設定檔或 UI 讀取
            _ctx.XResolution = XResolution;
            _ctx.YResolution = YResolution;
            _ctx.ZScale = ZScale;
            _ctx.CenterU = CenterU;
            string status = MeasureContext.SetGpuMode(_useGpu);
            _ctx.AddLog($"GPU 狀態: {status}");
            UpdateUI();
        }

        // =========================================================
        // Button Handlers
        // =========================================================

        private void BtnStep_Click(object sender, RoutedEventArgs e)
        {
            if (_nextStepIndex >= _steps.Count)
            {
                AppendLog("── Pipeline 已完成，請按「重置」重新開始 ──");
                return;
            }

            ExecuteStep(_nextStepIndex); 
            if (true)
            {
                float[] depthData = new float[0];
                depthData = Tool.HImageToFloatArray(_ctx.DepthImage);
            }
            _nextStepIndex++;
            UpdateUI();

            if (_nextStepIndex >= _steps.Count)
                ShowFinalResult();
        }

        private void BtnRunAll_Click(object sender, RoutedEventArgs e)
        {
            while (_nextStepIndex < _steps.Count)
            {
                bool ok = ExecuteStep(_nextStepIndex);
                _nextStepIndex++;
                UpdateUI();
                if (!ok) break;    // 任一步失敗就停止
            }

            if (_nextStepIndex >= _steps.Count)
                ShowFinalResult();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            TxtLog.Clear();
            LblFinalResult.Text = "最終結果將顯示於此";
            LblFinalResult.Foreground = Brushes.Black;
            BuildPipeline();
            AppendLog("── 已重置，Pipeline 準備就緒 ──");
        }

        private void VirtualMode_Changed(object sender, RoutedEventArgs e)
        {
            _virtualMode = ChkVirtualMode.IsChecked == true;
            // VirtualMode 切換時要重建 pipeline（VirtualMode 是屬性，需重新設定）
            BuildPipeline();
            AppendLog($"── VirtualMode = {_virtualMode}，Pipeline 已重建 ──");
        }

        private void UseGpu_Changed(object sender, RoutedEventArgs e)
        {
            _useGpu = ChkUseGpu.IsChecked == true;
            string status = MeasureContext.SetGpuMode(_useGpu);
            AppendLog($"── UseGPU = {_useGpu}，GPU 狀態: {status} ──");
        }

        // =========================================================
        // 核心：執行單一步驟
        // =========================================================
        private bool ExecuteStep(int index)
        {
            var step = _steps[index];
            step.Status = StepStatus.Running;
            step.NotifyChanged();
            AppendLog($"\n[{index + 1}/{_steps.Count}] ▶ 執行 {step.Name}");
            AppendLog($"    {step.Description}");
            int ctxLogBefore = _ctx.Log.Count;

            var sw = Stopwatch.StartNew(); // ← 開始計時

            try
            {
                var result = step.Module.Execute(_ctx);
                sw.Stop(); // ← 停止計時

                for (int i = ctxLogBefore; i < _ctx.Log.Count; i++)
                    AppendLog("    " + _ctx.Log[i]);

                if (result.IsSuccess)
                {
                    step.Status = StepStatus.Success;
                    step.OutputKeys = result.OutputKeys != null
                        ? string.Join(", ", result.OutputKeys)
                        : "";
                    AppendLog($"    ✓ 成功  輸出: [{step.OutputKeys}]  耗時: {FormatElapsed(sw.Elapsed)}");
                }
                else
                {
                    step.Status = StepStatus.Failed;
                    step.ErrorMessage = result.ErrorMessage;
                    AppendLog($"    ✗ 失敗：{result.ErrorMessage}  耗時: {FormatElapsed(sw.Elapsed)}");
                }
                step.NotifyChanged();
                return result.IsSuccess;
            }
            catch (Exception ex)
            {
                sw.Stop(); // ← 例外也要停
                step.Status = StepStatus.Failed;
                step.ErrorMessage = ex.Message;
                step.NotifyChanged();
                AppendLog($"    ✗ 擲例外：{ex.Message}  耗時: {FormatElapsed(sw.Elapsed)}");
                return false;
            }
        }

        private static string FormatElapsed(TimeSpan t)
        {
            if (t.TotalSeconds >= 60)
                return string.Format("{0:mm\\:ss\\.ff}", t);
            else if (t.TotalSeconds >= 1)
                return string.Format("{0:F2} s", t.TotalSeconds);
            else
                return string.Format("{0:F0} ms", t.TotalMilliseconds);
        }

        // =========================================================
        // UI 更新
        // =========================================================

        private void UpdateUI()
        {
            // null-safe：在 Window 完成載入前（BuildPipeline 於建構子呼叫時），
            // 部分控制項可能尚未初始化完畢，保護性檢查可避免 NRE
            if (LblCurrentStep == null) return;

            // 更新「當前步驟」面板
            if (_nextStepIndex < _steps.Count)
            {
                var next = _steps[_nextStepIndex];
                LblCurrentStep.Text = $"下一步：{next.Name}";
                LblOutputKeys.Text = next.Description;
            }
            else
            {
                LblCurrentStep.Text = "Pipeline 全部完成";
                LblOutputKeys.Text = "";
            }

            // 更新 ctx 即時快照
            LblCtxSnapshot.Text = BuildCtxSnapshot();

            // 按鈕啟用狀態
            BtnStep.IsEnabled = _nextStepIndex < _steps.Count;
            BtnRunAll.IsEnabled = _nextStepIndex < _steps.Count;
        }

        private string BuildCtxSnapshot()
        {
            var parts = new List<string>();
            parts.Add(_ctx.DepthImage != null ? "DepthImage✓" : "DepthImage✗");
            parts.Add(_ctx.FilteredDepthImage != null ? "FilteredDepthImage✓" : "FilteredDepthImage✗");
            parts.Add(_ctx.AlignedCloud != null ? "AlignedCloud✓" : "AlignedCloud✗");
            parts.Add($"NamedClouds={_ctx.NamedClouds.Count}");
            parts.Add($"FittedGeometries={_ctx.FittedGeometries.Count}");
            parts.Add($"MeasureResults={_ctx.MeasureResults.Count}");

            var snapshot = "Context: " + string.Join(" | ", parts);

            // 若 Pose 已算出，附上數值
            if (_ctx.CurrentPose != null && _ctx.CurrentPose.Length >= 6)
            {
                snapshot += $"\nPose: X={_ctx.CurrentPose[0].D:F3}, Y={_ctx.CurrentPose[1].D:F3}, " +
                            $"Z={_ctx.CurrentPose[2].D:F3}, Rz={_ctx.CurrentPose[5].D:F2}°";
            }
            return snapshot;
        }

        private void ShowFinalResult()
        {
            bool anyFailed = _steps.Any(s => s.Status == StepStatus.Failed);
            if (anyFailed)
            {
                var failed = _steps.First(s => s.Status == StepStatus.Failed);
                LblFinalResult.Text = $"✗ 失敗於：{failed.Name}  —  {failed.ErrorMessage}";
                LblFinalResult.Foreground = Brushes.Red;
                return;
            }

            if (_ctx.MeasureResults.TryGetValue("Dist_L2L", out var dist))
            {
                LblFinalResult.Text = $"✓ 量測成功：兩線距離 Dist_L2L = {dist:F4} mm";
                LblFinalResult.Foreground = Brushes.Green;
            }
            else
            {
                LblFinalResult.Text = "✓ Pipeline 執行完成，但未找到 Dist_L2L";
                LblFinalResult.Foreground = Brushes.DarkOrange;
            }
        }

        // 在 TxtLog 還沒 ready 之前（例如 XAML 解析階段觸發的事件），
        // 先把訊息暫存起來，等視窗 Loaded 後再 flush 到 UI
        private readonly List<string> _pendingLogs = new List<string>();

        private void AppendLog(string msg)
        {
            if (TxtLog == null)
            {
                _pendingLogs.Add(msg);
                return;
            }

            // 首次 TxtLog ready 時，把之前暫存的訊息 flush 出來
            if (_pendingLogs.Count > 0)
            {
                foreach (var m in _pendingLogs)
                    TxtLog.AppendText(m + "\n");
                _pendingLogs.Clear();
            }

            TxtLog.AppendText(msg + "\n");
            TxtLog.ScrollToEnd();
        }

        protected override void OnClosed(EventArgs e)
        {
            _ctx?.Dispose();
            base.OnClosed(e);
        }
    }

    // =========================================================
    // 步驟資料類別（綁定 ItemsControl 用）
    // =========================================================
    public enum StepStatus { Pending, Running, Success, Failed }

    public class StepItem : INotifyPropertyChanged
    {
        public string Name { get; }
        public string Description { get; }
        public IAlgorithmModule Module { get; }

        public StepStatus Status { get; set; } = StepStatus.Pending;
        public string OutputKeys { get; set; } = "";
        public string ErrorMessage { get; set; } = "";

        public StepItem(string name, string description, IAlgorithmModule module)
        {
            Name = name;
            Description = description;
            Module = module;
        }

        // 狀態顏色 & 圖示（透過 binding 顯示在 UI）
        public Brush StatusBrush
        {
            get
            {
                switch (Status)
                {
                    case StepStatus.Running: return Brushes.DodgerBlue;
                    case StepStatus.Success: return Brushes.SeaGreen;
                    case StepStatus.Failed: return Brushes.Crimson;
                    default: return Brushes.Gray;
                }
            }
        }

        public string StatusIcon
        {
            get
            {
                switch (Status)
                {
                    case StepStatus.Running: return "⏳";
                    case StepStatus.Success: return "✓";
                    case StepStatus.Failed: return "✗";
                    default: return "○";
                }
            }
        }

        public string DisplayInfo
        {
            get
            {
                if (Status == StepStatus.Success && !string.IsNullOrEmpty(OutputKeys))
                    return $"輸出: {OutputKeys}";
                if (Status == StepStatus.Failed && !string.IsNullOrEmpty(ErrorMessage))
                    return $"錯誤: {ErrorMessage}";
                return Description;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        // 手動通知所有綁定屬性更新
        public void NotifyChanged()
        {
            OnPropertyChanged(nameof(Status));
            OnPropertyChanged(nameof(StatusBrush));
            OnPropertyChanged(nameof(StatusIcon));
            OnPropertyChanged(nameof(OutputKeys));
            OnPropertyChanged(nameof(ErrorMessage));
            OnPropertyChanged(nameof(DisplayInfo));
        }

        protected void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}