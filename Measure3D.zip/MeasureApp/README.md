# MeasureApp - 3D 量測平台 Step-by-Step 測試介面

用於呼叫 `Halcon3DLibrary.dll` 執行 2.5D 對位 + 雙線距離量測流程，
支援 Step-by-step 執行觀察每一步的狀態變化。

## 專案結構

```
MeasureApp/
├── MeasureApp.csproj      # 專案檔（需修改 DLL 參考路徑）
├── App.xaml               # WPF 進入點
├── App.xaml.cs
├── MainWindow.xaml        # 主視窗 UI
└── MainWindow.xaml.cs     # Pipeline 執行邏輯
```

## 首次設定

### 1. 修改 `.csproj` 中兩個 DLL 的路徑

打開 `MeasureApp.csproj`，修改這兩行的 `HintPath`：

```xml
<Reference Include="Halcon3DLibrary">
  <HintPath>..\Halcon3DLibrary\bin\Release\Halcon3DLibrary.dll</HintPath>
</Reference>
<Reference Include="halcondotnet">
  <HintPath>C:\Program Files\MVTec\HALCON-...\halcondotnet.dll</HintPath>
</Reference>
```

### 2. 編譯

Visual Studio 開啟，或命令列：

```
dotnet build -c Release
```

### 3. 執行

```
bin\Release\net48\MeasureApp.exe
```

## 使用方式

### 首次測試（VirtualMode）

1. 程式啟動時預設勾選 **Virtual Mode**
2. 按 **▶ 執行下一步** 一步一步跑，觀察左側列表狀態變化
3. 每步執行後右側會顯示：
   - 本步驟的輸出 key
   - Context 當前內容（DepthImage/AlignedCloud 是否存在、已產生幾個 NamedClouds 等）
   - 詳細 Log 訊息
4. 跑完 8 步會在底部顯示「✓ 量測成功」（VirtualMode 的距離為 0.0）

### 真實資料測試

1. 取消 **Virtual Mode** 勾選（會自動重建 pipeline）
2. 修改頂端兩個路徑：**深度圖** 與 **Shape Model**
3. 檢查 `MainWindow.xaml.cs` 中的感測器參數（PixelSizeX/Y、ZScale）是否符合你的感測器
4. 按 **▶ 執行下一步** 或 **⏩ 全部執行**

## Pipeline 8 步驟對照

| # | 模組 | 輸出 |
|---|---|---|
| 1 | DepthImageLoader | ctx.DepthImage |
| 2 | DepthImageFilter (Gaussian) | ctx.FilteredDepthImage |
| 3 | Shape25DAlignment | ctx.CurrentPose + ctx.AlignedCloud |
| 4a | RegionSelectorBox (Line1_ROI) | ctx.NamedClouds["Line1_ROI"] |
| 4b | RegionSelectorBox (Line2_ROI) | ctx.NamedClouds["Line2_ROI"] |
| 5a | LineFitter (Line1) | ctx.FittedGeometries["Line1"] |
| 5b | LineFitter (Line2) | ctx.FittedGeometries["Line2"] |
| 6 | MeasureLineToLine3D | ctx.MeasureResults["Dist_L2L"] |

## 常見問題

### Q1: VirtualMode 切換後要重跑？
是。VirtualMode 是模組屬性，切換時需要重建整個 pipeline（程式已自動處理）。

### Q2: 真實資料下 Step 3 對位失敗？
- 降低 `MinScore`（0.5 → 0.3）
- 檢查深度圖與 Shape Model 是否同一個感測器/同一個工件
- `NumLevels` 從 0（自動）改為手動指定 3~4 看看

### Q3: Step 4 切 ROI 無點？
右側 Context 快照會顯示 AlignedCloud 是否存在。如果有，表示 ROI 範圍設錯了——
需要先用 HDevelop 查看 AlignedCloud 的 X/Y/Z 實際範圍，再回來調整 MinX~MaxZ。

### Q4: Step 5 LineFitter 線性度不足？
`MinLinearityRatio` 從 10 降到 3~5，或改用 `ForceXY=false` 看看原生 3D 擬合。

## 進階擴充方向

- 把 Pipeline 定義改成從 JSON 載入（使用者不必改 code）
- 加入模組參數的 UI 編輯面板（用 `GetSchema()` 動態產生）
- 把 `AlignedCloud` 用 Halcon 3D viewer 視覺化
- 加入執行時間統計（每步 elapsed ms）
