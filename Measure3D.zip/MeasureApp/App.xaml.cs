using System.Windows;

namespace MeasureApp
{
    public partial class App : Application
    {
    }
}
