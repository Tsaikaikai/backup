using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.ComTypes;

namespace Halcon3DLibrary
{
    // =========================================================
    // MeasureContext：所有模組共用的資料容器
    // =========================================================
    public class MeasureContext : IDisposable
    {
        /// <summary> 當前主點雲（未套用 Pose）</summary>
        public HObjectModel3D Cloud { get; set; }

        /// <summary> 套用 Pose 後的點雲（量測模組應讀這個）</summary>
        public HObjectModel3D AlignedCloud { get; set; }

        /// <summary> Surface Matching 對位結果 Pose </summary>
        public HTuple CurrentPose { get; set; }

        /// <summary> 命名子點雲（RegionSelector 切割後存這裡）</summary>
        public Dictionary<string, HObjectModel3D> NamedClouds { get; set; }
            = new Dictionary<string, HObjectModel3D>();

        // ── 2.5D 深度圖欄位 ──────────────────────────────────

        /// <summary>
        /// 原始深度圖（線掃描儀直接輸出）。
        /// 型別通常為 uint16（每個 pixel 為高度 count）或 float32（單位 mm）。
        /// </summary>
        public HImage DepthImage { get; set; }

        /// <summary>
        /// 濾波後深度圖。DepthToCloud 優先讀取此欄位；
        /// 若為 null 則回退到 DepthImage。
        /// </summary>
        public HImage FilteredDepthImage { get; set; }

        /// <summary>
        /// 橫向（X 軸）物理解析度（mm/pixel）。
        /// 用於座標換算：X = (u - CenterU) * XResolution
        /// </summary>
        public double XResolution { get; set; }

        /// <summary>
        /// 縱向（Y 軸）行間距（mm/line），由輸送速度與掃描頻率決定。
        /// 用於座標換算：Y = row * YResolution
        /// </summary>
        public double YResolution { get; set; }

        /// <summary>
        /// 深度像素值 → 實際高度的縮放係數（mm/count）。
        /// Keyence LJ-X8000 = 0.001；LMI Gocator = 1.0（已輸出 mm）
        /// </summary>
        public double ZScale { get; set; }

        /// <summary>
        /// 無效深度門檻；pixel_value &lt;= 此值的點不加入點雲。
        /// 依感測器規格設定，Keyence / Gocator 通常為 0。
        /// </summary>
        public double ZInvalidThreshold { get; set; } = double.MaxValue;

        /// <summary>
        /// 光學中心像素（X 軸原點基準）。
        /// -1 = 自動取影像寬度的一半；有安裝偏移或經相機標定時須手動指定。
        /// </summary>
        public double CenterU { get; set; } = 0;

        /// <summary> 命名深度圖（支援多視角或多鏡頭場景）</summary>
        public Dictionary<string, HImage> DepthImages { get; set; }
            = new Dictionary<string, HImage>();

        // ── 通用欄位 ─────────────────────────────────────────

        /// <summary>
        /// 幾何擬合結果，統一格式：
        ///   Line  → [px, py, pz, dx, dy, dz]   (通過點 + 單位方向向量)
        ///   Plane → [nx, ny, nz, d]              (單位法向量 + 原點距離)
        /// </summary>
        public Dictionary<string, HTuple> FittedGeometries { get; set; }
            = new Dictionary<string, HTuple>();

        /// <summary> 量測數值結果（單位 mm / deg）</summary>
        public Dictionary<string, double> MeasureResults { get; set; }
            = new Dictionary<string, double>();

        public List<string> Log { get; set; } = new List<string>();

        public void AddLog(string msg)
            => Log.Add($"[{DateTime.Now:HH:mm:ss.fff}] {msg}");

        /// <summary>
        /// 全局 GPU 加速開關
        /// </summary>
        public static string SetGpuMode(bool useGpu)
        {
            try
            {
                if (!useGpu)
                {
                    HOperatorSet.DeactivateAllComputeDevices();
                    return "CPU";
                }

                // 查詢可用裝置（回傳的是裝置 index 列表，不是 Handle）
                HOperatorSet.QueryAvailableComputeDevices(out HTuple deviceIndices);

                if (deviceIndices.Length == 0)
                {
                    return "No compute devices available, using CPU";
                }

                // 取第一個裝置的 index
                HTuple deviceIndex = deviceIndices.TupleSelect(1);

                // 取得裝置名稱（用 index 查詢）
                HOperatorSet.GetComputeDeviceInfo(deviceIndex, "name", out HTuple deviceName);

                // OpenComputeDevice 才會回傳真正的 Handle
                HOperatorSet.OpenComputeDevice(deviceIndex, out HTuple deviceHandle);

                // 初始化（此時 deviceHandle 型別才正確）
                HOperatorSet.InitComputeDevice(deviceHandle, new HTuple());

                // 啟用
                HOperatorSet.ActivateComputeDevice(deviceHandle);

                return $"GPU [0]: {deviceName.S}";
            }
            catch (Exception ex)
            {
                try { HOperatorSet.DeactivateAllComputeDevices(); } catch { }
                return $"Error (fallback to CPU): {ex.Message}";
            }
        }

        public void Dispose()
        {
            Cloud?.Dispose();
            AlignedCloud?.Dispose();
            foreach (var c in NamedClouds.Values) c?.Dispose();
            DepthImage?.Dispose();
            FilteredDepthImage?.Dispose();
            foreach (var img in DepthImages.Values) img?.Dispose();
        }
    }

    // =========================================================
    // 參數描述 Schema（供 UI 自動建立設定介面）
    // =========================================================
    public class ParameterDef
    {
        public string Name { get; set; }
        public string Type { get; set; }   // "double"/"int"/"string"/"bool"
        public object DefaultValue { get; set; }
        public object Min { get; set; }
        public object Max { get; set; }
        public string Description { get; set; }
    }

    public class ModuleParameterSchema
    {
        public List<ParameterDef> Parameters { get; set; } = new List<ParameterDef>();
    }

    // =========================================================
    // 模組執行結果
    // =========================================================
    public class ModuleResult
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public List<string> OutputKeys { get; set; } = new List<string>();

        public static ModuleResult Success(params string[] keys) =>
            new ModuleResult { IsSuccess = true, OutputKeys = new List<string>(keys) };

        public static ModuleResult Fail(string error) =>
            new ModuleResult { IsSuccess = false, ErrorMessage = error };
    }

    // =========================================================
    // 算法模組統一介面
    // =========================================================
    public interface IAlgorithmModule
    {
        string ModuleName { get; }

        /// <summary>
        /// 模組類別：
        ///   "DepthImage" – 深度圖前處理（濾波 / 採樣 / 轉換）
        ///   "Alignment"  – 3D 點雲對位
        ///   "Filter"     – 3D 點雲 ROI 切割
        ///   "Fitting"    – 幾何擬合
        ///   "Measure"    – 幾何量測
        /// </summary>
        string ModuleCategory { get; }

        /// <summary>
        /// 虛擬模式：只執行輸入驗證，跳過所有 Halcon 演算法，並寫入假資料。
        /// </summary>
        bool VirtualMode { get; set; }

        ModuleParameterSchema GetSchema();
        ModuleResult Execute(MeasureContext ctx);
    }

    // =========================================================
    // 3D 向量工具
    // =========================================================
    internal static class Vec3
    {
        public static double[] Sub(double[] a, double[] b) =>
            new[] { a[0]-b[0], a[1]-b[1], a[2]-b[2] };

        public static double[] Cross(double[] a, double[] b) => new[]
        {
            a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]
        };

        public static double Dot(double[] a, double[] b) =>
            a[0]*b[0] + a[1]*b[1] + a[2]*b[2];

        private static double[] Scale(double[] a, double s) =>
            new[] { a[0] * s, a[1] * s, a[2] * s };

        private static double[] Add(double[] a, double[] b) =>
            new[] { a[0] + b[0], a[1] + b[1], a[2] + b[2] };

        public static double Norm(double[] a) =>
            Math.Sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]);

        public static double[] Normalize(double[] a)
        {
            double n = Norm(a);
            return n < 1e-12 ? new double[]{ 1,0,0 } : new[]{ a[0]/n, a[1]/n, a[2]/n };
        }

        public static bool TryGetLine(MeasureContext ctx, string name,
            out double[] point, out double[] dir)
        {
            point = null; dir = null;
            if (!ctx.FittedGeometries.TryGetValue(name, out HTuple g) || g.Length < 6)
                return false;
            point = new[]{ g[0].D, g[1].D, g[2].D };
            dir   = new[]{ g[3].D, g[4].D, g[5].D };
            return true;
        }

        public static bool TryGetPlane(MeasureContext ctx, string name,
            out double[] normal, out double d)
        {
            normal = null; d = 0;
            if (!ctx.FittedGeometries.TryGetValue(name, out HTuple g) || g.Length < 4)
                return false;
            normal = new[]{ g[0].D, g[1].D, g[2].D };
            d = g[3].D;
            return true;
        }

        public static double LineToLine(double[] p1, double[] d1,
                                        double[] p2, double[] d2)
        {
            double[] cross = Cross(d1, d2);
            double   len   = Norm(cross);
            double[] diff  = Sub(p2, p1);
            return len < 1e-9
                ? Norm(Cross(diff, d1)) / Math.Max(Norm(d1), 1e-12)
                : Math.Abs(Dot(diff, cross)) / len;
        }

        /// <summary>
        /// 計算兩條線段之間的最短距離。
        /// p1, p2 為各線段起點；d1, d2 為方向向量（長度即線段長度，或另傳 len1/len2）。
        /// </summary>
        public static double SegmentToSegment(
            double[] p1, double[] d1,
            double[] p2, double[] d2)
        {
            // 線段長度
            double len1 = Norm(d1);
            double len2 = Norm(d2);

            // 方向單位向量（零長度線段視為點）
            double[] u = len1 > 1e-12 ? Scale(d1, 1.0 / len1) : d1;
            double[] v = len2 > 1e-12 ? Scale(d2, 1.0 / len2) : d2;

            double[] w0 = Sub(p1, p2);   // 起點差向量

            double a = Dot(u, u);        // uu （= 1 if 已單位化）
            double b = Dot(u, v);        // uv
            double c = Dot(v, v);        // vv （= 1 if 已單位化）
            double d = Dot(u, w0);       // u·w0
            double e = Dot(v, w0);       // v·w0

            double denom = a * c - b * b; // = 1 - cos²θ，平行時趨近 0

            double t, s;

            if (denom < 1e-10)
            {
                // ── 平行 / 共線：固定 t=0，對 s 做 clamp ──
                t = 0.0;
                s = (c > 1e-12) ? (-e / c) : 0.0;
            }
            else
            {
                // ── 一般情況：無限直線最近點參數 ──
                t = (b * e - c * d) / denom;
                s = (a * e - b * d) / denom;
            }

            // ── Clamp 到各自線段範圍 [0, length] ──
            t = Math.Max(0.0, Math.Min(len1, t));
            s = Math.Max(0.0, Math.Min(len2, s));

            // Clamp 後需重新修正對側參數，確保最近點對
            // 固定 t，重算 s
            double[] closestOnA = Add(p1, Scale(u, t));
            double[] diff_ts = Sub(closestOnA, p2);
            s = Dot(diff_ts, v);
            s = Math.Max(0.0, Math.Min(len2, s));

            // 固定 s，重算 t
            double[] closestOnB = Add(p2, Scale(v, s));
            double[] diff_st = Sub(closestOnB, p1);
            t = Dot(diff_st, u);
            t = Math.Max(0.0, Math.Min(len1, t));

            // ── 最終最近點與距離 ──
            closestOnA = Add(p1, Scale(u, t));
            closestOnB = Add(p2, Scale(v, s));

            return Norm(Sub(closestOnA, closestOnB));
        }

        public static double PointToLine(double[] pt, double[] lp, double[] ld)
        {
            double[] diff = Sub(pt, lp);
            return Norm(Cross(diff, ld)) / Math.Max(Norm(ld), 1e-12);
        }

        public static double AngleWithAxis(double[] dir, double[] axis)
        {
            double cosA = Math.Abs(Dot(Normalize(dir), Normalize(axis)));
            return Math.Acos(Math.Min(1.0, cosA));
        }

        public static double AngleBetweenLines(double[] d1, double[] d2)
        {
            double cosA = Math.Abs(Dot(Normalize(d1), Normalize(d2)));
            return Math.Acos(Math.Min(1.0, cosA));
        }
    }

    // =========================================================
    // CloudResolver：統一解析輸入點雲來源
    // =========================================================
    internal static class CloudResolver
    {
        public static bool TryResolve(
            MeasureContext ctx,
            string inputCloudName,
            out HObjectModel3D source,
            out ModuleResult error)
        {
            if (!string.IsNullOrEmpty(inputCloudName))
            {
                if (!ctx.NamedClouds.TryGetValue(inputCloudName, out source))
                {
                    error = ModuleResult.Fail($"找不到點雲：{inputCloudName}");
                    return false;
                }
            }
            else
            {
                source = ctx.AlignedCloud ?? ctx.Cloud;
                if (source == null)
                {
                    string hint = (ctx.DepthImage != null || ctx.FilteredDepthImage != null ||
                                   ctx.DepthImages.Count > 0)
                        ? "（偵測到深度圖，請先執行 DepthToCloud 將深度圖轉換為點雲）"
                        : "（請先執行 DepthToCloud 或載入點雲）";
                    error = ModuleResult.Fail($"點雲為空，請先對位或指定 InputCloudName {hint}");
                    return false;
                }
            }
            error = null;
            return true;
        }
    }

    // =========================================================
    // DepthImageResolver：統一解析深度圖來源
    //   InputImageName == "" → ctx.FilteredDepthImage ?? ctx.DepthImage
    //   InputImageName != "" → ctx.DepthImages[InputImageName]
    // =========================================================
    internal static class DepthImageResolver
    {
        public static bool TryResolve(
            MeasureContext ctx,
            string inputImageName,
            out HImage image,
            out ModuleResult error)
        {
            if (!string.IsNullOrEmpty(inputImageName))
            {
                if (!ctx.DepthImages.TryGetValue(inputImageName, out image))
                {
                    error = ModuleResult.Fail($"找不到深度圖：{inputImageName}");
                    return false;
                }
            }
            else
            {
                image = ctx.FilteredDepthImage ?? ctx.DepthImage;
                if (image == null)
                {
                    error = ModuleResult.Fail("深度圖為空，請先執行 DepthImageLoader 或設定 ctx.DepthImage");
                    return false;
                }
            }
            error = null;
            return true;
        }
    }

    // =========================================================
    // [DepthImage] 深度圖載入
    //
    //   從檔案載入深度圖並寫入 MeasureContext。
    //   支援格式：
    //     .tiff / .png / .bmp  → uint16（Keyence/LMI/Cognex 原始輸出），自動轉為 float32
    //     .hobj                → float32（HALCON 自訂格式）
    //   ctx.XResolution / YResolution / ZScale 請由外部呼叫端在 Execute 前手動設定。
    //   OutputName == ""  → 寫入 ctx.DepthImage
    //   OutputName != ""  → 寫入 ctx.DepthImages[OutputName]
    // =========================================================
    public class DepthImageLoader : IAlgorithmModule
    {
        public string ModuleName => "DepthImageLoader";
        public string ModuleCategory => "DepthImage";

        public string FilePath { get; set; } = "";
        public string OutputName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        /// <summary>
        /// 由外部在執行前直接賦值；設定後優先於 FilePath。
        /// Width / Height 必須同時提供。
        /// </summary>
        public float[] InjectArray { get; set; } = null;
        public int ArrayWidth { get; set; } = 0;
        public int ArrayHeight { get; set; } = 0;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(FilePath),    Type="string", DefaultValue="",
                    Description="深度圖路徑（.tiff/.png/.bmp/.hobj）" },
                new ParameterDef { Name=nameof(OutputName),  Type="string", DefaultValue="",
                    Description="輸出名稱（留空 = ctx.DepthImage）" },
                new ParameterDef { Name=nameof(ArrayWidth),  Type="int",    DefaultValue="0",
                    Description="float[] 注入時的影像寬度" },
                new ParameterDef { Name=nameof(ArrayHeight), Type="int",    DefaultValue="0",
                    Description="float[] 注入時的影像高度" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (VirtualMode)
                {
                    var dummy = new HImage();
                    dummy.GenImageConst("uint2", 1, 1);
                    StoreImage(ctx, dummy);
                    ctx.AddLog($"[VirtualMode] DepthImageLoader：假深度圖已寫入 {OutDesc}");
                    return ModuleResult.Success(SuccessTag);
                }

                HImage img;

                // 優先：float[] 注入路徑
                if (InjectArray != null)
                {
                    img = FloatArrayToHImage(InjectArray, ArrayWidth, ArrayHeight, ctx.ZScale);
                    StoreImage(ctx, img);
                    ctx.AddLog($"DepthImageLoader：{OutDesc}  {ArrayWidth}×{ArrayHeight}  從 float[]");
                    return ModuleResult.Success(SuccessTag);
                }

                // 原有：檔案路徑
                if (string.IsNullOrEmpty(FilePath))
                    return ModuleResult.Fail(
                        "FilePath 未設定（若要直接注入影像請跳過此模組，或設定 InjectArray）");

                img = new HImage();
                img.ReadImage(FilePath);

                // uint16 → float32：統一下游型別，並順便讀取私有 TIFF Tag
                img = ConvertToRealIfNeeded(img);

                StoreImage(ctx, img);
                HOperatorSet.GetImageSize(img, out HTuple w, out HTuple h);
                ctx.AddLog($"DepthImageLoader：{OutDesc}  {w[0].I}×{h[0].I}  從 {FilePath}");
                return ModuleResult.Success(SuccessTag);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }

        /// <summary>
        /// 若影像為 uint16（uint2），轉為 float32（real）。
        /// 數值不縮放，保留原始 count；ZScale 由外部設定 ctx 統一管理。
        /// </summary>
        private static HImage ConvertToRealIfNeeded(HImage img)
        {
            HOperatorSet.GetImageType(img, out HTuple typeStr);
            if (typeStr[0].S == "uint2")
            {
                HOperatorSet.ConvertImageType(img, out HObject floatObj, "real");
                img.Dispose();
                return new HImage(floatObj);
            }
            return img;
        }

        // 核心轉換：float[] → HImage (float channel) 
        private static HImage FloatArrayToHImage(float[] data, int width, int height, double zscale)
        {
            if (data.Length != width * height)
                throw new ArgumentException(
                    $"float[] 長度 {data.Length} 與 {width}×{height}={width * height} 不符");
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = (float)(data[i] / zscale);
            }
            // 將 managed float[] pin 住，透過 GenImageConst 建立同尺寸影像後
            // 再用 SetImagePointer 一次寫入，避免逐像素複製
            HImage img = new HImage();
            unsafe
            {
                fixed (float* ptr = data)
                {
                    img.GenImage1("real", width, height, (IntPtr)ptr);
                }
            }
            return img;
        }

        private void StoreImage(MeasureContext ctx, HImage img)
        {
            if (string.IsNullOrEmpty(OutputName)) ctx.DepthImage = img;
            else ctx.DepthImages[OutputName] = img;
        }

        private string OutDesc => string.IsNullOrEmpty(OutputName)
                                         ? "ctx.DepthImage"
                                         : $"ctx.DepthImages[\"{OutputName}\"]";
        private string SuccessTag => string.IsNullOrEmpty(OutputName) ? "DepthImage" : OutputName;
    }

    // =========================================================
    // [DepthImage] 深度圖濾波
    //
    //   對深度圖執行影像濾波，去除感測器雜訊並平滑深度值。
    //
    //   FilterType 對應 HALCON 算子：
    //     Averaging → mean_image          平均濾波（快速，輕度模糊）
    //     Median    → median_image        中值濾波（保邊去椒鹽雜訊）
    //     Gaussian  → gauss_image         高斯濾波（平滑，保留大結構）
    //     Erosion   → gray_erosion_shape  灰階侵蝕（消退局部高點/毛刺）
    //     Dilation  → gray_dilation_shape 灰階膨脹（填補局部凹陷/空洞）
    //     Opening   → gray_opening_shape  開運算（去除小突起，整體不縮）
    //     Closing   → gray_closing_shape  閉運算（填補小空洞，整體不漲）
    //
    //   型別處理：
    //     uint16 原始圖在形態學操作前自動轉 float，完成後轉回 uint16。
    //
    //   輸出：
    //     OutputImageName == "" → ctx.FilteredDepthImage（DepthToCloud 優先讀取）
    //     OutputImageName != "" → ctx.DepthImages[OutputImageName]
    // =========================================================
    public class DepthImageFilter : IAlgorithmModule
    {
        public string ModuleName     => "DepthImageFilter";
        public string ModuleCategory => "DepthImage";

        /// <summary>
        /// 濾波類型：Averaging / Median / Gaussian / Erosion / Dilation / Opening / Closing
        /// </summary>
        public string FilterType { get; set; } = "Gaussian";

        /// <summary>濾波核心大小（像素，必須為奇數；形態學算子為結構元素邊長）</summary>
        public int MaskSize { get; set; } = 5;

        /// <summary>輸入深度圖名稱（留空 = ctx.FilteredDepthImage ?? ctx.DepthImage）</summary>
        public string InputImageName { get; set; } = "";

        /// <summary>輸出名稱（留空 = ctx.FilteredDepthImage；有值 = ctx.DepthImages[OutputImageName]）</summary>
        public string OutputImageName { get; set; } = "";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(FilterType),      Type="string", DefaultValue="Gaussian",
                    Description="Averaging/Median/Gaussian/Erosion/Dilation/Opening/Closing" },
                new ParameterDef { Name=nameof(MaskSize),        Type="int",    DefaultValue=5, Min=3, Max=99,
                    Description="核心大小（奇數像素）" },
                new ParameterDef { Name=nameof(InputImageName),  Type="string", DefaultValue="",
                    Description="輸入深度圖名稱（留空 = 主深度圖）" },
                new ParameterDef { Name=nameof(OutputImageName), Type="string", DefaultValue="",
                    Description="輸出名稱（留空 = ctx.FilteredDepthImage）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!DepthImageResolver.TryResolve(ctx, InputImageName, out HImage src, out var err))
                    return err;

                if (VirtualMode)
                {
                    StoreResult(ctx, src);
                    ctx.AddLog($"[VirtualMode] DepthImageFilter ({FilterType})：輸入驗證通過");
                    return ModuleResult.Success(string.IsNullOrEmpty(OutputImageName) ? "FilteredDepthImage" : OutputImageName);
                }

                int sz = MaskSize % 2 == 0 ? MaskSize + 1 : MaskSize;
                HImage result = ApplyFilter(src, FilterType.Trim(), sz);

                StoreResult(ctx, result);
                string outDesc = string.IsNullOrEmpty(OutputImageName)
                    ? "ctx.FilteredDepthImage"
                    : $"ctx.DepthImages[\"{OutputImageName}\"]";
                ctx.AddLog($"DepthImageFilter：{FilterType} MaskSize={sz} → {outDesc}");
                return ModuleResult.Success(string.IsNullOrEmpty(OutputImageName) ? "FilteredDepthImage" : OutputImageName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }

        private static HImage ApplyFilter(HImage src, string filterType, int sz)
        {
            HOperatorSet.GetImageType(src, out HTuple imgType);
            bool needConvert = (filterType == "Erosion" || filterType == "Dilation" ||
                                filterType == "Opening" || filterType == "Closing") &&
                               imgType[0].S == "uint2";

            HImage workImg = src;
            HImage convertedWork = null;  // needConvert 時的中間 HImage（需 Dispose）
            if (needConvert)
            {
                HOperatorSet.ConvertImageType(src, out HObject floatObj, "real");
                convertedWork = new HImage(floatObj);  // HImage 接管 floatObj
                workImg = convertedWork;
            }

            HImage filtered = null;
            HImage finalResult = null;
            try
            {
                HObject rawResult;
                switch (filterType)
                {
                    case "Averaging":
                        HOperatorSet.MeanImage(workImg, out rawResult, sz, sz);
                        break;
                    case "Median":
                        HOperatorSet.MedianImage(workImg, out rawResult, "circle", sz / 2, "mirrored");
                        break;
                    case "Gaussian":
                        HOperatorSet.GaussImage(workImg, out rawResult, sz);
                        break;
                    case "Erosion":
                        HOperatorSet.GrayErosionShape(workImg, out rawResult, sz, sz, "octagon");
                        break;
                    case "Dilation":
                        HOperatorSet.GrayDilationShape(workImg, out rawResult, sz, sz, "octagon");
                        break;
                    case "Opening":
                        HOperatorSet.GrayOpeningShape(workImg, out rawResult, sz, sz, "octagon");
                        break;
                    case "Closing":
                        HOperatorSet.GrayClosingShape(workImg, out rawResult, sz, sz, "octagon");
                        break;
                    default:
                        throw new ArgumentException($"未知 FilterType：{filterType}");
                }
                filtered = new HImage(rawResult);  // HImage 接管 rawResult

                if (needConvert)
                {
                    // 轉回 uint16
                    HOperatorSet.ConvertImageType(filtered, out HObject uint2Obj, "uint2");
                    finalResult = new HImage(uint2Obj);
                }
                else
                {
                    finalResult = filtered;
                    filtered = null;  // 所有權移交 finalResult，避免 finally 重複釋放
                }

                HImage ret = finalResult;
                finalResult = null;  // 所有權移交給呼叫方
                return ret;
            }
            finally
            {
                // 只釋放中間產物：filtered（若 needConvert 成功則需釋放；否則所有權已移交）
                //                convertedWork（needConvert 時的浮點中間圖）
                //                finalResult（僅在擲例外未成功移交時會非 null）
                filtered?.Dispose();
                convertedWork?.Dispose();
                finalResult?.Dispose();
            }
        }

        private void StoreResult(MeasureContext ctx, HImage img)
        {
            if (string.IsNullOrEmpty(OutputImageName))
                ctx.FilteredDepthImage = img;
            else
                ctx.DepthImages[OutputImageName] = img;
        }
    }


    public class DepthImageDecimation : IAlgorithmModule
    {
        public string ModuleName     => "DepthImageDecimation";
        public string ModuleCategory => "DepthImage";

        /// <summary>X 方向降採樣步長（像素），例如 2 = 寬度縮半</summary>
        public int StepX { get; set; } = 2;

        /// <summary>Y 方向降採樣步長（像素），例如 2 = 高度縮半</summary>
        public int StepY { get; set; } = 2;

        /// <summary>採樣前是否自動 Gaussian 預濾波（建議 true，防鋸齒）</summary>
        public bool AntiAlias { get; set; } = true;

        /// <summary>輸入深度圖名稱（留空 = ctx.FilteredDepthImage ?? ctx.DepthImage）</summary>
        public string InputImageName { get; set; } = "";

        /// <summary>輸出名稱（留空 = ctx.FilteredDepthImage；有值 = ctx.DepthImages[OutputImageName]）</summary>
        public string OutputImageName { get; set; } = "";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(StepX),           Type="int",    DefaultValue=2,    Min=1, Max=16,
                    Description="X 降採樣步長（像素）" },
                new ParameterDef { Name=nameof(StepY),           Type="int",    DefaultValue=2,    Min=1, Max=16,
                    Description="Y 降採樣步長（像素）" },
                new ParameterDef { Name=nameof(AntiAlias),       Type="bool",   DefaultValue=true,
                    Description="採樣前 Gaussian 預濾波（防摩爾紋）" },
                new ParameterDef { Name=nameof(InputImageName),  Type="string", DefaultValue="",
                    Description="輸入深度圖名稱（留空 = 主深度圖）" },
                new ParameterDef { Name=nameof(OutputImageName), Type="string", DefaultValue="",
                    Description="輸出名稱（留空 = ctx.FilteredDepthImage）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!DepthImageResolver.TryResolve(ctx, InputImageName, out HImage src, out var err))
                    return err;

                if (VirtualMode)
                {
                    StoreResult(ctx, src);
                    ctx.AddLog($"[VirtualMode] DepthImageDecimation：StepX={StepX} StepY={StepY} 輸入驗證通過");
                    return ModuleResult.Success(string.IsNullOrEmpty(OutputImageName) ? "FilteredDepthImage" : OutputImageName);
                }

                HImage workImg = src;
                HImage antiAliasTmp = null;  // 追蹤防鋸齒中間產物，以便 finally 釋放

                try
                {
                    if (AntiAlias && (StepX > 1 || StepY > 1))
                    {
                        // gauss_image mask size 僅允許 {3,5,7,9,11}，需 clamp
                        int desired = Math.Max(StepX, StepY);
                        if (desired % 2 == 0) desired += 1;
                        int kernelSz = Math.Max(3, Math.Min(11, desired));

                        HOperatorSet.GetImageType(src, out HTuple imgType);
                        bool isUint16 = imgType[0].S == "uint2";

                        HImage floatTmp = null;  // uint16 → float 中間圖
                        HImage blurImg = null;   // 模糊後影像
                        try
                        {
                            HImage gaussInput;
                            if (isUint16)
                            {
                                HOperatorSet.ConvertImageType(src, out HObject floatObj, "real");
                                floatTmp = new HImage(floatObj);
                                gaussInput = floatTmp;
                            }
                            else
                            {
                                gaussInput = src;
                            }

                            HOperatorSet.GaussImage(gaussInput, out HObject blurObj, kernelSz);
                            blurImg = new HImage(blurObj);

                            if (isUint16)
                            {
                                HOperatorSet.ConvertImageType(blurImg, out HObject u2Obj, "uint2");
                                antiAliasTmp = new HImage(u2Obj);
                                workImg = antiAliasTmp;
                            }
                            else
                            {
                                antiAliasTmp = blurImg;
                                blurImg = null;  // 所有權移交 antiAliasTmp，避免 finally 重複 Dispose
                                workImg = antiAliasTmp;
                            }
                        }
                        finally
                        {
                            blurImg?.Dispose();
                            floatTmp?.Dispose();
                        }
                    }

                    double scaleX = 1.0 / StepX;
                    double scaleY = 1.0 / StepY;
                    HOperatorSet.ZoomImageFactor(workImg, out HObject zoomObj,
                        scaleX, scaleY, "nearest_neighbor");
                    HImage result = new HImage(zoomObj);

                    HOperatorSet.GetImageSize(src,    out HTuple srcW,  out HTuple srcH);
                    HOperatorSet.GetImageSize(result, out HTuple dstW,  out HTuple dstH);
                    StoreResult(ctx, result);
                    string outDesc = string.IsNullOrEmpty(OutputImageName)
                        ? "ctx.FilteredDepthImage"
                        : $"ctx.DepthImages[\"{OutputImageName}\"]";
                    ctx.AddLog($"DepthImageDecimation：{srcW[0].I}×{srcH[0].I} → {dstW[0].I}×{dstH[0].I}" +
                               $"  Step=({StepX},{StepY})  AntiAlias={AntiAlias} → {outDesc}");
                    return ModuleResult.Success(string.IsNullOrEmpty(OutputImageName) ? "FilteredDepthImage" : OutputImageName);
                }
                finally
                {
                    antiAliasTmp?.Dispose();
                }
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }

        private void StoreResult(MeasureContext ctx, HImage img)
        {
            if (string.IsNullOrEmpty(OutputImageName))
                ctx.FilteredDepthImage = img;
            else
                ctx.DepthImages[OutputImageName] = img;
        }
    }

    // =========================================================
    // [DepthImage] 深度圖轉點雲（核心 2.5D → 3D 橋接模組）
    //
    //   將線掃描儀深度圖轉換為 HALCON HObjectModel3D 點雲，
    //   作為後續所有 Filter / Fitting / Measure 模組的輸入。
    //
    //   座標換算（單位 mm）：
    //     X = (u - CenterU) * XResolution   ← 掃描頭橫向
    //     Y = v * YResolution                ← 掃描前進方向
    //     Z = pixel_value * ZScale           ← 高度值（count → mm）
    //
    //   典型感測器設定：
    //     Keyence LJ-X8000 ：ZScale=0.001（1 count = 1 µm）
    //     LMI Gocator 2xxx ：ZScale=1.0（感測器已輸出 mm）
    //     Cognex DS1300    ：ZScale 依設定
    //
    //   無效點過濾：pixel_value <= ZInvalidThreshold 的點不加入點雲
    //
    //   輸出：
    //     OutputCloudName == "" → ctx.Cloud
    //     OutputCloudName != "" → ctx.NamedClouds[OutputCloudName]
    // =========================================================
    public class DepthToCloud : IAlgorithmModule
    {
        public string ModuleName     => "DepthToCloud";
        public string ModuleCategory => "DepthImage";

        /// <summary>輸入深度圖名稱（留空 = ctx.FilteredDepthImage ?? ctx.DepthImage）</summary>
        public string InputImageName { get; set; } = "";

        /// <summary>輸出點雲名稱（留空 = ctx.Cloud；有值 = ctx.NamedClouds[OutputCloudName]）</summary>
        public string OutputCloudName { get; set; } = "";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(InputImageName),    Type="string", DefaultValue="",
                    Description="輸入深度圖名稱（留空 = 主深度圖）" },
                new ParameterDef { Name=nameof(OutputCloudName),   Type="string", DefaultValue="",
                    Description="輸出點雲名稱（留空 = ctx.Cloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!DepthImageResolver.TryResolve(ctx, InputImageName, out HImage depthImg, out var err))
                    return err;

                if (VirtualMode)
                {
                    HOperatorSet.GenEmptyObjectModel3d(out HTuple dummyId);
                    var dummyCloud = new HObjectModel3D(dummyId);
                    StoreCloud(ctx, dummyCloud);
                    ctx.AddLog($"[VirtualMode] DepthToCloud：輸入驗證通過，假點雲已寫入");
                    return ModuleResult.Success(string.IsNullOrEmpty(OutputCloudName) ? "Cloud" : OutputCloudName);
                }

                HOperatorSet.GetImageSize(depthImg, out HTuple imgW, out HTuple imgH);
                double centerU = (ctx.CenterU < 0) ? (imgW[0].I / 2.0) : ctx.CenterU;

                HOperatorSet.GetImageType(depthImg, out HTuple imgType);
                HImage workImg = depthImg;
                HImage convertedFloat = null;  // uint16 → float 中間 HImage（需 Dispose）
                if (imgType[0].S == "uint2")
                {
                    HOperatorSet.ConvertImageType(depthImg, out HObject floatObj, "real");
                    convertedFloat = new HImage(floatObj);  // HImage 接管 floatObj
                    workImg = convertedFloat;
                }

                HObject validRegion = null;
                HTuple rows, cols, zVals;
                try
                {
                    // 過濾無效深度值：使用嚴格大於 ZInvalidThreshold（含負值、0 皆合法）
                    // Threshold 是閉區間 [lower, upper]，為了符合「pixel > ZInvalidThreshold」語意，
                    // 使用 ZInvalidThreshold + 極小 epsilon 作下界
                    double lowerBound = ctx.ZInvalidThreshold + 1e-9;
                    HOperatorSet.Threshold(workImg, out validRegion, lowerBound, 1e10);
                    HOperatorSet.GetRegionPoints(validRegion, out rows, out cols);

                    if (rows.Length == 0)
                        return ModuleResult.Fail(
                            $"DepthToCloud：無有效深度點（全部被 ZInvalidThreshold={ctx.ZInvalidThreshold} 過濾）");

                    // 取對應像素的 Z 灰階值
                    HOperatorSet.GetGrayval(workImg, rows, cols, out zVals);
                }
                finally
                {
                    validRegion?.Dispose();
                    convertedFloat?.Dispose();
                }

                // 座標轉換
                // X = (col - centerU) * XResolution
                // Y = row * YResolution
                // Z = zVal * ZScale
                HTuple xVals = (cols - centerU) * ctx.XResolution;
                HTuple yVals = rows * (double)ctx.YResolution;
                HTuple zScaled = zVals * ctx.ZScale;

                // 建立 3D 點雲
                HTuple cloudId;
                HOperatorSet.GenObjectModel3dFromPoints(xVals, yVals, zScaled, out cloudId);

                var cloud = new HObjectModel3D(cloudId);

                HOperatorSet.GetObjectModel3dParams(cloud, "num_points", out HTuple numPts);

                StoreCloud(ctx, cloud);

                string outDesc = string.IsNullOrEmpty(OutputCloudName)
                    ? "ctx.Cloud"
                    : $"ctx.NamedClouds[\"{OutputCloudName}\"]";

                ctx.AddLog($"DepthToCloud：{numPts[0].I} 點 → {outDesc}" +
                           $"  XRes={ctx.XResolution} YRes={ctx.YResolution} ZScale={ctx.ZScale}" +
                           $"  CenterU={centerU:F1}  ZInvalidThreshold={ctx.ZInvalidThreshold}");

                return ModuleResult.Success(string.IsNullOrEmpty(OutputCloudName) ? "Cloud" : OutputCloudName);
            }
            catch (Exception ex)
            {
                return ModuleResult.Fail(ex.Message);
            }
        }

        private void StoreCloud(MeasureContext ctx, HObjectModel3D cloud)
        {
            if (string.IsNullOrEmpty(OutputCloudName))
                ctx.Cloud = cloud;
            else
                ctx.NamedClouds[OutputCloudName] = cloud;
        }
    }

    // =========================================================
    // [Alignment] Surface Matching 對位
    // =========================================================
    public class SurfaceAlignment : IAlgorithmModule
    {
        public string ModuleName => "SurfaceAlignment";
        public string ModuleCategory => "Alignment";

        public string ModelPath { get; set; } = "";
        public double RelSamplingDistance { get; set; } = 0.05;
        public double MinScore { get; set; } = 0.3;
        public string InputCloudName { get; set; } = "";
        public string OutputCloudName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        private HTuple _surfaceModelID;
        private bool _modelLoaded = false;

        public void LoadModel()
        {
            if (string.IsNullOrEmpty(ModelPath))
                throw new InvalidOperationException("ModelPath 未設定");
            HOperatorSet.ReadSurfaceModel(ModelPath, out HTuple id);
            _surfaceModelID = id;
            _modelLoaded = true;
        }

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(ModelPath),           Type="string", DefaultValue="",   Description=".sfm 模型路徑" },
                new ParameterDef { Name=nameof(RelSamplingDistance), Type="double", DefaultValue=0.05, Min=0.01, Max=0.5,  Description="採樣距離（越小越精確）" },
                new ParameterDef { Name=nameof(MinScore),            Type="double", DefaultValue=0.3,  Min=0.0,  Max=1.0,  Description="最低接受分數" },
                new ParameterDef { Name=nameof(InputCloudName),      Type="string", DefaultValue="",   Description="輸入點雲名稱（留空 = ctx.Cloud）" },
                new ParameterDef { Name=nameof(OutputCloudName),     Type="string", DefaultValue="",   Description="輸出點雲名稱（留空 = ctx.AlignedCloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                HObjectModel3D inputCloud;
                if (!string.IsNullOrEmpty(InputCloudName))
                {
                    if (!ctx.NamedClouds.TryGetValue(InputCloudName, out inputCloud))
                        return ModuleResult.Fail($"找不到點雲：{InputCloudName}");
                }
                else
                {
                    inputCloud = ctx.Cloud;
                    if (inputCloud == null)
                    {
                        string hint = (ctx.DepthImage != null || ctx.FilteredDepthImage != null)
                            ? "（偵測到深度圖，請先執行 DepthToCloud）"
                            : "";
                        return ModuleResult.Fail($"Cloud 為空 {hint}");
                    }
                }

                if (VirtualMode)
                {
                    ctx.CurrentPose = new HTuple(new double[] { 0, 0, 0, 0, 0, 0, 1 });
                    ctx.AlignedCloud = inputCloud;
                    if (!string.IsNullOrEmpty(OutputCloudName))
                        ctx.NamedClouds[OutputCloudName] = inputCloud;
                    ctx.AddLog($"[VirtualMode] SurfaceAlignment：輸入驗證通過，假 Pose 已寫入");
                    var vKeys = string.IsNullOrEmpty(OutputCloudName)
                        ? new[] { "CurrentPose", "AlignedCloud" }
                        : new[] { "CurrentPose", "AlignedCloud", OutputCloudName };
                    return ModuleResult.Success(vKeys);
                }

                if (!_modelLoaded) LoadModel();

                HOperatorSet.FindSurfaceModel(
                    _surfaceModelID, inputCloud,
                    RelSamplingDistance, 0.3, MinScore,
                    "false", new HTuple(), new HTuple(),
                    out HTuple pose, out HTuple score, out HTuple _);

                if (score.Length == 0 || score[0].D < MinScore)
                    return ModuleResult.Fail(
                        $"對位失敗，分數 {(score.Length > 0 ? score[0].D : 0):F3} 低於門檻 {MinScore}");

                HOperatorSet.ConvertPoseType(pose, "Rp+T", "gba", "point", out HTuple poseConverted);
                ctx.CurrentPose = poseConverted;

                HOperatorSet.RigidTransObjectModel3d(inputCloud, ctx.CurrentPose, out HTuple alignedID);
                var alignedCloud = new HObjectModel3D(alignedID);

                ctx.AlignedCloud?.Dispose();
                ctx.AlignedCloud = alignedCloud;
                if (!string.IsNullOrEmpty(OutputCloudName))
                    ctx.NamedClouds[OutputCloudName] = alignedCloud;

                string outputDesc = string.IsNullOrEmpty(OutputCloudName)
                    ? "AlignedCloud"
                    : $"AlignedCloud + NamedClouds[\"{OutputCloudName}\"]";
                ctx.AddLog($"SurfaceAlignment：成功，分數 {score[0].D:F3}，輸出至 {outputDesc}");

                var outputKeys = string.IsNullOrEmpty(OutputCloudName)
                    ? new[] { "CurrentPose", "AlignedCloud" }
                    : new[] { "CurrentPose", "AlignedCloud", OutputCloudName };
                return ModuleResult.Success(outputKeys);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }

        public void Dispose()
        {
            if (_surfaceModelID != null && _surfaceModelID.Length > 0)
                HOperatorSet.ClearSurfaceModel(_surfaceModelID);
        }
    }

    // =========================================================
    // [Alignment] 2.5D Shape Matching 對位
    // 使用 Halcon Shape-Based Matching 在深度圖上找 2D Pose (Row, Col, Angle),
    // 再從深度圖對應位置取 Z 值,組成 2.5D Pose (X, Y, Z, Rz)
    // 適用平放/半平放物件,速度遠快於 Surface Matching
    // =========================================================
    public class Shape25DAlignment : IAlgorithmModule
    {
        public string ModuleName => "Shape25DAlignment";
        public string ModuleCategory => "Alignment";

        // === 模型參數 ===
        public string ModelPath { get; set; } = "";          // .shm 模型路徑
        public double AngleStart { get; set; } = -Math.PI;
        public double AngleExtent { get; set; } = 2 * Math.PI;
        public double MinScore { get; set; } = 0.5;
        public int NumMatches { get; set; } = 1;
        public double MaxOverlap { get; set; } = 0.5;
        public string SubPixel { get; set; } = "least_squares";
        public int NumLevels { get; set; } = 0;              // 0 = 自動
        public double Greediness { get; set; } = 0.9;

        // === 來源深度圖選擇 ===
        // 留空 = 優先使用 ctx.FilteredDepthImage, 否則用 ctx.DepthImage
        // 指定名稱 = 從 ctx.DepthImages[name] 取出
        public string InputDepthName { get; set; } = "";

        // === Z 取樣鄰域半徑 (像素),用中位數避免單點雜訊 ===
        public int ZSampleRadius { get; set; } = 3;

        // === 像素 → 世界座標換算 ===
        // 對位時：worldX = (mCol - PrincipalCol) * PixelSizeX + OffsetX
        //         worldY = (mRow - PrincipalRow) * PixelSizeY + OffsetY
        // 產生點雲時：每個像素套相同公式，Z = pixel_value * DepthScale + DepthOffset
        // 這些參數同時用於「找 Pose」與「內建 DepthToCloud」，確保兩者座標系一致
        public double PrincipalCol { get; set; } = 0.0;
        public double PrincipalRow { get; set; } = 0.0;
        public double OffsetX { get; set; } = 0.0;           // mm
        public double OffsetY { get; set; } = 0.0;           // mm
        public double DepthOffset { get; set; } = 0.0;       // mm

        /// <summary>
        /// 無效深度門檻：pixel_value &lt;= 此值的像素不進入 AlignedCloud。
        /// 預設 0 表示排除 0 值（常見無效像素標記）；負高度場景可設為更低的負值。
        /// </summary>
        public double ZInvalidThreshold { get; set; } = 0.0;

        // === 輸出點雲命名 ===
        // 留空 = 寫入 ctx.AlignedCloud
        // 有值 = 同時寫入 ctx.AlignedCloud 和 ctx.NamedClouds[OutputCloudName]
        public string OutputCloudName { get; set; } = "";

        public bool VirtualMode { get; set; } = false;

        private HTuple _shapeModelID;
        private bool _modelLoaded = false;

        public void LoadModel()
        {
            if (string.IsNullOrEmpty(ModelPath))
                throw new InvalidOperationException("ModelPath 未設定");
            HOperatorSet.ReadShapeModel(ModelPath, out HTuple id);
            _shapeModelID = id;
            _modelLoaded = true;
        }

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(ModelPath),         Type="string", DefaultValue="",        Description=".shm 模型路徑" },
                new ParameterDef { Name=nameof(AngleStart),        Type="double", DefaultValue=-Math.PI,  Min=-Math.PI, Max=Math.PI, Description="搜尋角度起 (rad)" },
                new ParameterDef { Name=nameof(AngleExtent),       Type="double", DefaultValue=2*Math.PI, Min=0, Max=2*Math.PI,      Description="搜尋角度範圍 (rad)" },
                new ParameterDef { Name=nameof(MinScore),          Type="double", DefaultValue=0.5, Min=0.0, Max=1.0,  Description="最低接受分數" },
                new ParameterDef { Name=nameof(NumMatches),        Type="int",    DefaultValue=1,   Min=1,   Max=100,  Description="最多匹配數" },
                new ParameterDef { Name=nameof(MaxOverlap),        Type="double", DefaultValue=0.5, Min=0.0, Max=1.0,  Description="最大重疊比例" },
                new ParameterDef { Name=nameof(SubPixel),          Type="string", DefaultValue="least_squares",        Description="次像素方法" },
                new ParameterDef { Name=nameof(NumLevels),         Type="int",    DefaultValue=0,   Min=0,   Max=10,   Description="金字塔層數 (0=自動)" },
                new ParameterDef { Name=nameof(Greediness),        Type="double", DefaultValue=0.9, Min=0.0, Max=1.0,  Description="貪婪度" },
                new ParameterDef { Name=nameof(InputDepthName),    Type="string", DefaultValue="",        Description="輸入深度圖名稱(留空=ctx.FilteredDepthImage/DepthImage)" },
                new ParameterDef { Name=nameof(ZSampleRadius),     Type="int",    DefaultValue=3,   Min=0,   Max=50,   Description="Z 取樣鄰域半徑(px)" },
                new ParameterDef { Name=nameof(PrincipalCol),      Type="double", DefaultValue=0.0,                    Description="影像中心 Col" },
                new ParameterDef { Name=nameof(PrincipalRow),      Type="double", DefaultValue=0.0,                    Description="影像中心 Row" },
                new ParameterDef { Name=nameof(OffsetX),           Type="double", DefaultValue=0.0,                    Description="X 世界座標偏移(mm)" },
                new ParameterDef { Name=nameof(OffsetY),           Type="double", DefaultValue=0.0,                    Description="Y 世界座標偏移(mm)" },
                new ParameterDef { Name=nameof(DepthOffset),       Type="double", DefaultValue=0.0,                    Description="深度值偏移(mm)" },
                new ParameterDef { Name=nameof(ZInvalidThreshold), Type="double", DefaultValue=0.0,                    Description="無效深度門檻(pixel_value<=此值視為無資料)" },
                new ParameterDef { Name=nameof(OutputCloudName),   Type="string", DefaultValue="",        Description="輸出點雲名稱(留空=ctx.AlignedCloud)" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            HObject byteImage = null;
            try
            {
                // ---------- 取得深度圖 ----------
                HImage depthImage;
                if (!string.IsNullOrEmpty(InputDepthName))
                {
                    if (!ctx.DepthImages.TryGetValue(InputDepthName, out depthImage) || depthImage == null)
                        return ModuleResult.Fail($"找不到深度圖：{InputDepthName}");
                }
                else
                {
                    depthImage = ctx.FilteredDepthImage ?? ctx.DepthImage;
                    if (depthImage == null)
                        return ModuleResult.Fail("DepthImage / FilteredDepthImage 皆為空，2.5D Matching 需要深度圖");
                }

                // ---------- Virtual Mode ----------
                if (VirtualMode)
                {
                    ctx.CurrentPose = new HTuple(new double[] { 0, 0, 0, 0, 0, 0, 1 });

                    HOperatorSet.GenEmptyObjectModel3d(out HTuple dummyId);
                    var dummyCloud = new HObjectModel3D(dummyId.H);
                    ctx.AlignedCloud?.Dispose();
                    ctx.AlignedCloud = dummyCloud;
                    if (!string.IsNullOrEmpty(OutputCloudName))
                        ctx.NamedClouds[OutputCloudName] = dummyCloud;

                    ctx.AddLog($"[VirtualMode] Shape25DAlignment：輸入驗證通過，假 Pose 與空點雲已寫入");
                    var vKeys = string.IsNullOrEmpty(OutputCloudName)
                        ? new[] { "CurrentPose", "AlignedCloud" }
                        : new[] { "CurrentPose", "AlignedCloud", OutputCloudName };
                    return ModuleResult.Success(vKeys);
                }

                if (!_modelLoaded) LoadModel();

                // ---------- 深度圖 → byte (Shape Matching 在 byte 上最穩) ----------
                byteImage = ConvertToByteIfNeeded(depthImage);

                // ---------- Shape-Based Matching ----------
                HOperatorSet.FindShapeModel(
                    byteImage, _shapeModelID,
                    AngleStart, AngleExtent,
                    MinScore, NumMatches, MaxOverlap,
                    SubPixel, NumLevels, Greediness,
                    out HTuple row, out HTuple col, out HTuple angle, out HTuple score);

                if (score.Length == 0 || score[0].D < MinScore)
                    return ModuleResult.Fail(
                        $"2.5D 對位失敗，分數 {(score.Length > 0 ? score[0].D : 0):F3} 低於門檻 {MinScore}");

                double mRow = row[0].D;
                double mCol = col[0].D;
                double mAng = angle[0].D;      // 繞 Z 軸旋轉 (rad)
                double mScore = score[0].D;

                // ---------- 從深度圖取 Z 值 (鄰域中位數) ----------
                double zRaw = SampleDepthMedian(depthImage, mRow, mCol, ZSampleRadius);
                if (double.IsNaN(zRaw))
                    return ModuleResult.Fail("無法從深度圖取得有效 Z 值 (可能落在無效/零值區)");
                double worldZ = zRaw * ctx.ZScale + DepthOffset;

                // ---------- 像素 → 世界座標 ----------
                double worldX, worldY;
                if (ctx.XResolution > 0 && ctx.YResolution > 0)
                {
                    worldX = (mCol - PrincipalCol) * ctx.XResolution + OffsetX;
                    worldY = (mRow - PrincipalRow) * ctx.YResolution + OffsetY;
                }
                else
                {
                    // 未設定像素尺寸 → 退回像素座標 (僅供 debug)
                    worldX = mCol;
                    worldY = mRow;
                }

                // ---------- 組成 3D Pose (只有 X, Y, Z, Rz) ----------
                // 使用 CreatePose 明確指定 pose 型式，避免手動組 tuple 時的 Type code 陷阱
                // Rp+T: 旋轉矩陣 R 先作用於點，再加上平移 T
                // gba: 旋轉順序為 R = Rγ(Z) · Rβ(Y) · Rα(X)，此處 α=β=0，γ=rotZdeg
                // point: pose 為絕對座標（非相對變換）
                double rotZdeg = mAng * 180.0 / Math.PI;
                HOperatorSet.CreatePose(
                    worldX, worldY, worldZ,
                    0.0, 0.0, rotZdeg,
                    "Rp+T", "gba", "point",
                    out HTuple pose);
                ctx.CurrentPose = pose;

                // ---------- 內建 DepthToCloud：直接從深度圖產出 AlignedCloud ----------
                // 2.5D 掃描的座標系就是物理世界座標系，深度圖每個像素天然對應 mm 位置。
                // 換算公式（與 Shape Matching 的 Pose 換算使用同一組參數，保證座標系一致）：
                //   X_mm = (col - PrincipalCol) * PixelSizeX + OffsetX
                //   Y_mm = (row - PrincipalRow) * PixelSizeY + OffsetY
                //   Z_mm = pixel_value * DepthScale + DepthOffset
                // AlignedCloud 保留在「場景原位」，Pose 僅作為偵測結果紀錄，不對點雲做剛體變換。
                HObjectModel3D alignedCloud = BuildAlignedCloudFromDepth(ctx, depthImage);
                if (alignedCloud == null)
                    return ModuleResult.Fail("無法從深度圖建立點雲（全部被 ZInvalidThreshold 過濾）");

                ctx.AlignedCloud?.Dispose();
                ctx.AlignedCloud = alignedCloud;
                if (!string.IsNullOrEmpty(OutputCloudName))
                    ctx.NamedClouds[OutputCloudName] = alignedCloud;

                HOperatorSet.GetObjectModel3dParams(alignedCloud, "num_points", out HTuple numPts);
                string outputDesc = string.IsNullOrEmpty(OutputCloudName)
                    ? "AlignedCloud"
                    : $"AlignedCloud + NamedClouds[\"{OutputCloudName}\"]";

                ctx.AddLog(
                    $"Shape25DAlignment：成功，分數 {mScore:F3}，" +
                    $"Pose=(X={worldX:F3}, Y={worldY:F3}, Z={worldZ:F3}, Rz={rotZdeg:F2}°)，" +
                    $"AlignedCloud={numPts[0].I} 點 → {outputDesc}");

                var outputKeys = string.IsNullOrEmpty(OutputCloudName)
                    ? new[] { "CurrentPose", "AlignedCloud" }
                    : new[] { "CurrentPose", "AlignedCloud", OutputCloudName };
                return ModuleResult.Success(outputKeys);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
            finally
            {
                byteImage?.Dispose();
            }
        }

        /// <summary>
        /// 從深度圖直接建立場景座標系的點雲（內建 DepthToCloud 邏輯）。
        /// 使用 Shape25DAlignment 自己的 PixelSize/DepthScale 等欄位做 pixel → mm 換算，
        /// 保證產出的點雲和 Pose 在同一個座標系。
        /// </summary>
        private HObjectModel3D BuildAlignedCloudFromDepth(MeasureContext ctx, HImage depthImage)
        {
            HImage workImg = depthImage;
            HImage convertedFloat = null;  // uint16 → float 中間 HImage（需 Dispose）
            HObject validRegion = null;
            try
            {
                HOperatorSet.GetImageType(depthImage, out HTuple imgType);
                if (imgType[0].S == "uint2")
                {
                    HOperatorSet.ConvertImageType(depthImage, out HObject floatObj, "real");
                    convertedFloat = new HImage(floatObj);
                    workImg = convertedFloat;
                }

                // 過濾無效深度值：嚴格大於 ZInvalidThreshold（Threshold 是閉區間，加極小 epsilon）
                double lowerBound = ZInvalidThreshold + 1e-9;
                HOperatorSet.Threshold(workImg, out validRegion, lowerBound, 1e10);
                HOperatorSet.GetRegionPoints(validRegion, out HTuple rows, out HTuple cols);
                if (rows.Length == 0) return null;

                HOperatorSet.GetGrayval(workImg, rows, cols, out HTuple zVals);

                // 逐像素換算到 mm（與 Shape Matching 的 Pose 換算公式一致）
                HTuple xVals, yVals;
                if (ctx.XResolution > 0 && ctx.YResolution > 0)
                {
                    xVals = (cols - PrincipalCol) * ctx.XResolution + OffsetX;
                    yVals = (rows - PrincipalRow) * ctx.YResolution + OffsetY;
                }
                else
                {
                    // 未設 PixelSize → 退回像素座標（僅供 debug；Pose 也會退回像素座標）
                    xVals = new HTuple(cols);
                    yVals = new HTuple(rows);
                }
                HTuple zScaled = zVals * ctx.ZScale + DepthOffset;

                HOperatorSet.GenObjectModel3dFromPoints(xVals, yVals, zScaled, out HTuple cloudId);
                return new HObjectModel3D(cloudId.H);
            }
            finally
            {
                validRegion?.Dispose();
                convertedFloat?.Dispose();
            }
        }

        /// <summary>
        /// 若輸入深度圖不是 byte 型別,先正規化到 0~255 再轉 byte,供 Shape Matching 使用。
        /// 會先用 threshold 排除 0 值（常見無效像素標記），以保留有效值域的對比度。
        /// </summary>
        // 模組屬性，從 HALCON 腳本抄入
        /// <summary>
        /// ScaleMult / ScaleAdd 必須與製作 shm 腳本的 scale_image 參數完全一致，否則灰階分佈不同導致對位失敗。
        /// shm 腳本用 scale_image(img, 0.0039065, 0) ，故預設值為 0.0039065 / 0。
        /// </summary>
        public double ScaleMult { get; set; } = 0.0039065;
        public double ScaleAdd  { get; set; } = 0.0;

        private HObject ConvertToByteIfNeeded(HImage depthImage)
        {
            HOperatorSet.GetImageType(depthImage, out HTuple imgType);
            if (imgType.S == "byte")
            {
                HOperatorSet.CopyImage(depthImage, out HObject copy);
                return copy;
            }

            HObject scaled = null;
            try
            {
                HOperatorSet.ScaleImage(depthImage, out scaled, ScaleMult, ScaleAdd);
                HOperatorSet.ConvertImageType(scaled, out HObject byteImg, "byte");
                return byteImg;
            }
            finally
            {
                scaled?.Dispose();
            }
        }

        /// <summary>
        /// 取深度圖在 (row, col) 附近的中位數 Z。過濾 0 值 (常見無效像素標記)
        /// </summary>
        private double SampleDepthMedian(HImage depthImage, double row, double col, int radius)
        {
            HObject rect = null;
            try
            {
                HOperatorSet.GetImageSize(depthImage, out HTuple w, out HTuple h);
                int r0 = Math.Max(0, (int)Math.Round(row - radius));
                int r1 = Math.Min(h.I - 1, (int)Math.Round(row + radius));
                int c0 = Math.Max(0, (int)Math.Round(col - radius));
                int c1 = Math.Min(w.I - 1, (int)Math.Round(col + radius));

                if (r1 < r0 || c1 < c0) return double.NaN;

                HOperatorSet.GenRectangle1(out rect, r0, c0, r1, c1);
                HOperatorSet.GrayFeatures(rect, depthImage, "median", out HTuple med);

                if (med.Length == 0) return double.NaN;
                double v = med[0].D;
                return (Math.Abs(v) < 1e-12) ? double.NaN : v;
            }
            catch { return double.NaN; }
            finally
            {
                rect?.Dispose();
            }
        }

        public void Dispose()
        {
            if (_shapeModelID != null && _shapeModelID.Length > 0)
                HOperatorSet.ClearShapeModel(_shapeModelID);
        }
    }

    // =========================================================
    // [Filter] X 軸範圍切割
    //   2.5D 物理意義：X = 掃描頭橫向（剖面寬度方向），單位 mm
    // =========================================================
    public class RegionSelectorX : IAlgorithmModule
    {
        public string ModuleName => "RegionSelectorX";
        public string ModuleCategory => "Filter";
        public string OutputName { get; set; } = "ROI";

        /// <summary>X 最小值（mm）── 掃描頭橫向左邊界</summary>
        public double MinX { get; set; } = 0.0;

        /// <summary>X 最大值（mm）── 掃描頭橫向右邊界</summary>
        public double MaxX { get; set; } = 100.0;

        public string InputCloudName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(OutputName),     Type="string", DefaultValue="ROI" },
                new ParameterDef { Name=nameof(MinX),           Type="double", DefaultValue=0.0,   Min=-10000.0, Max=10000.0,
                    Description="X 最小值（mm）── 2.5D 橫向左邊界" },
                new ParameterDef { Name=nameof(MaxX),           Type="double", DefaultValue=100.0, Min=-10000.0, Max=10000.0,
                    Description="X 最大值（mm）── 2.5D 橫向右邊界" },
                new ParameterDef { Name=nameof(InputCloudName), Type="string", DefaultValue="",
                    Description="輸入點雲名稱（留空 = AlignedCloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!CloudResolver.TryResolve(ctx, InputCloudName, out var source, out var err))
                    return err;

                if (VirtualMode)
                {
                    ctx.NamedClouds[OutputName] = source;
                    ctx.AddLog($"[VirtualMode] RegionSelectorX：{OutputName} 輸入驗證通過");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D filtered = source.SelectPointsObjectModel3d("point_coord_x", MinX, MaxX);
                HOperatorSet.GetObjectModel3dParams(filtered, "num_points", out HTuple numPoints);

                if (numPoints[0].I == 0)
                    return ModuleResult.Fail($"X 範圍 [{MinX:F3}, {MaxX:F3}] mm 內沒有點");

                ctx.NamedClouds[OutputName] = filtered;
                ctx.AddLog($"RegionSelectorX：{OutputName} 取得 {numPoints[0].I} 點  [{MinX:F3}, {MaxX:F3}] mm");
                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Filter] Y 軸範圍切割
    //   2.5D 物理意義：Y = 掃描前進方向（行號 × 行間距），單位 mm
    // =========================================================
    public class RegionSelectorY : IAlgorithmModule
    {
        public string ModuleName => "RegionSelectorY";
        public string ModuleCategory => "Filter";
        public string OutputName { get; set; } = "ROI";

        /// <summary>Y 最小值（mm）── 掃描前進方向起點</summary>
        public double MinY { get; set; } = 0.0;

        /// <summary>Y 最大值（mm）── 掃描前進方向終點</summary>
        public double MaxY { get; set; } = 100.0;

        public string InputCloudName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(OutputName),     Type="string", DefaultValue="ROI" },
                new ParameterDef { Name=nameof(MinY),           Type="double", DefaultValue=0.0,   Min=-10000.0, Max=10000.0,
                    Description="Y 最小值（mm）── 2.5D 掃描方向起點" },
                new ParameterDef { Name=nameof(MaxY),           Type="double", DefaultValue=100.0, Min=-10000.0, Max=10000.0,
                    Description="Y 最大值（mm）── 2.5D 掃描方向終點" },
                new ParameterDef { Name=nameof(InputCloudName), Type="string", DefaultValue="",
                    Description="輸入點雲名稱（留空 = AlignedCloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!CloudResolver.TryResolve(ctx, InputCloudName, out var source, out var err))
                    return err;

                if (VirtualMode)
                {
                    ctx.NamedClouds[OutputName] = source;
                    ctx.AddLog($"[VirtualMode] RegionSelectorY：{OutputName} 輸入驗證通過");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D filtered = source.SelectPointsObjectModel3d("point_coord_y", MinY, MaxY);
                HOperatorSet.GetObjectModel3dParams(filtered, "num_points", out HTuple numPoints);

                if (numPoints[0].I == 0)
                    return ModuleResult.Fail($"Y 範圍 [{MinY:F3}, {MaxY:F3}] mm 內沒有點");

                ctx.NamedClouds[OutputName] = filtered;
                ctx.AddLog($"RegionSelectorY：{OutputName} 取得 {numPoints[0].I} 點  [{MinY:F3}, {MaxY:F3}] mm");
                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Filter] Z 軸範圍切割
    //   2.5D 物理意義：Z = 高度值（最常用的 ROI 切割維度），單位 mm
    // =========================================================
    public class RegionSelectorZ : IAlgorithmModule
    {
        public string ModuleName => "RegionSelectorZ";
        public string ModuleCategory => "Filter";

        public string OutputName { get; set; } = "ROI";

        /// <summary>Z 最小值（mm）── 高度下限門檻</summary>
        public double MinZ { get; set; } = 0.0;

        /// <summary>Z 最大值（mm）── 高度上限門檻</summary>
        public double MaxZ { get; set; } = 10.0;

        public string InputCloudName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(OutputName),     Type="string", DefaultValue="ROI" },
                new ParameterDef { Name=nameof(MinZ),           Type="double", DefaultValue=0.0,  Min=-10000.0, Max=10000.0,
                    Description="Z 高度下限（mm）── 2.5D 最常用 ROI 維度" },
                new ParameterDef { Name=nameof(MaxZ),           Type="double", DefaultValue=10.0, Min=-10000.0, Max=10000.0,
                    Description="Z 高度上限（mm）" },
                new ParameterDef { Name=nameof(InputCloudName), Type="string", DefaultValue="",
                    Description="輸入點雲名稱（留空 = AlignedCloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!CloudResolver.TryResolve(ctx, InputCloudName, out var source, out var err))
                    return err;

                if (VirtualMode)
                {
                    ctx.NamedClouds[OutputName] = source;
                    ctx.AddLog($"[VirtualMode] RegionSelectorZ：{OutputName} 輸入驗證通過");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D filtered = source.SelectPointsObjectModel3d("point_coord_z", MinZ, MaxZ);
                HOperatorSet.GetObjectModel3dParams(filtered, "num_points", out HTuple numPoints);

                if (numPoints[0].I == 0)
                    return ModuleResult.Fail($"Z 高度範圍 [{MinZ:F3}, {MaxZ:F3}] mm 內沒有點");

                ctx.NamedClouds[OutputName] = filtered;
                ctx.AddLog($"RegionSelectorZ：{OutputName} 取得 {numPoints[0].I} 點  [{MinZ:F3}, {MaxZ:F3}] mm");
                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Filter] 3D Box 切割（X/Y/Z 三軸範圍，單位 mm）
    // =========================================================
    public class RegionSelectorBox : IAlgorithmModule
    {
        public string ModuleName => "RegionSelectorBox";
        public string ModuleCategory => "Filter";

        public string OutputName { get; set; } = "ROI_Box";
        public double MinX { get; set; } = -50.0;  public double MaxX { get; set; } = 50.0;
        public double MinY { get; set; } = -50.0;  public double MaxY { get; set; } = 50.0;
        public double MinZ { get; set; } =   0.0;  public double MaxZ { get; set; } = 10.0;

        public string InputCloudName { get; set; } = "";
        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(OutputName), Type="string", DefaultValue="ROI_Box" },
                new ParameterDef { Name=nameof(MinX), Type="double", DefaultValue=-50.0, Min=-10000.0, Max=10000.0, Description="X 下限（mm）" },
                new ParameterDef { Name=nameof(MaxX), Type="double", DefaultValue= 50.0, Min=-10000.0, Max=10000.0, Description="X 上限（mm）" },
                new ParameterDef { Name=nameof(MinY), Type="double", DefaultValue=-50.0, Min=-10000.0, Max=10000.0, Description="Y 下限（mm）── 掃描方向" },
                new ParameterDef { Name=nameof(MaxY), Type="double", DefaultValue= 50.0, Min=-10000.0, Max=10000.0, Description="Y 上限（mm）── 掃描方向" },
                new ParameterDef { Name=nameof(MinZ), Type="double", DefaultValue=  0.0, Min=-10000.0, Max=10000.0, Description="Z 下限（mm）── 高度門檻" },
                new ParameterDef { Name=nameof(MaxZ), Type="double", DefaultValue= 10.0, Min=-10000.0, Max=10000.0, Description="Z 上限（mm）── 高度門檻" },
                new ParameterDef { Name=nameof(InputCloudName), Type="string", DefaultValue="", Description="輸入點雲名稱（留空 = AlignedCloud）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!CloudResolver.TryResolve(ctx, InputCloudName, out var source, out var err))
                    return err;

                if (VirtualMode)
                {
                    ctx.NamedClouds[OutputName] = source;
                    ctx.AddLog($"[VirtualMode] RegionSelectorBox：{OutputName} 輸入驗證通過");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D filtered = null;
                try
                {
                    HOperatorSet.GetObjectModel3dParams(source, "point_coord_x", out HTuple xs);
                    HOperatorSet.GetObjectModel3dParams(source, "point_coord_y", out HTuple ys);
                    HOperatorSet.GetObjectModel3dParams(source, "point_coord_z", out HTuple zs);

                    // ✅ 一次取出成 double[]，避免逐個存取 HTuple 元素
                    double[] xArr = xs.DArr;
                    double[] yArr = ys.DArr;
                    double[] zArr = zs.DArr;

                    int n = xArr.Length;
                    var keepIdx = new List<int>();
                    for (int i = 0; i < n; i++)
                    {
                        if (xArr[i] >= MinX && xArr[i] <= MaxX &&
                            yArr[i] >= MinY && yArr[i] <= MaxY &&
                            zArr[i] >= MinZ && zArr[i] <= MaxZ)
                            keepIdx.Add(i);
                    }

                    if (keepIdx.Count == 0)
                        return ModuleResult.Fail(
                            $"Box 範圍 X[{MinX:F1},{MaxX:F1}] Y[{MinY:F1},{MaxY:F1}] Z[{MinZ:F1},{MaxZ:F1}] mm 內沒有點");

                    var kx = new HTuple(keepIdx.Select(i => xArr[i]).ToArray());
                    var ky = new HTuple(keepIdx.Select(i => yArr[i]).ToArray());
                    var kz = new HTuple(keepIdx.Select(i => zArr[i]).ToArray());

                    HOperatorSet.GenObjectModel3dFromPoints(kx, ky, kz, out HTuple modelHandle);
                    filtered = new HObjectModel3D(modelHandle[0].H.Handle); 

                    ctx.NamedClouds[OutputName] = filtered;
                    ctx.AddLog($"RegionSelectorBox：{OutputName} 取得 {keepIdx.Count} 點");
                    filtered = null;
                    return ModuleResult.Success(OutputName);
                }
                finally
                {
                    filtered?.Dispose();
                }
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Fitting] 3D 直線擬合
    //
    //   結果儲存於 ctx.FittedGeometries[OutputName]：
    //     HTuple[0..2] = (px, py, pz) 通過點（mm）
    //     HTuple[3..5] = (dx, dy, dz) 單位方向向量
    //
    //   擬合方法：
    //     3D 模式（ForceXY=false）：使用 Halcon 原生 fit_primitives_object_model_3d
    //                                 以 cylinder 擬合取軸向，對雜訊較穩健、有 RMS 回報。
    //     2.5D 模式（ForceXY=true） ：將點雲投影到 XY 平面後，用 moments 主軸擬合，
    //                                 適合水平邊緣／輪廓線量測。同時檢查線性度
    //                                 （λ₁ / λ₂ 比值）避免把雜點誤判為直線。
    // =========================================================
    public class LineFitter : IAlgorithmModule
    {
        public string ModuleName => "LineFitter";
        public string ModuleCategory => "Fitting";

        public string InputCloudName { get; set; } = "ROI";
        public string OutputName     { get; set; } = "Line1";

        /// <summary>
        /// 2.5D 邊緣擬合模式：強制在 XY 平面擬合直線。
        /// true  = 將所有點 Z 清零後再做 PCA（用於邊緣偵測/水平線量測）。
        /// false = 標準 3D 空間直線擬合（使用原生 cylinder 擬合，預設）。
        /// </summary>
        public bool ForceXY { get; set; } = false;

        /// <summary>
        /// 線性度門檻（僅 ForceXY 模式使用）：
        /// 主慣量比 λ₁/λ₂ 需大於此值才視為有效直線。
        /// 預設 10 表示最長軸至少是次軸的 10 倍（形狀足夠細長）。
        /// </summary>
        public double MinLinearityRatio { get; set; } = 10.0;

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(InputCloudName),    Type="string", DefaultValue="ROI",   Description="輸入子點雲名稱" },
                new ParameterDef { Name=nameof(OutputName),        Type="string", DefaultValue="Line1", Description="輸出幾何名稱" },
                new ParameterDef { Name=nameof(ForceXY),           Type="bool",   DefaultValue=false,
                    Description="2.5D 邊緣模式：投影到 XY 平面後 PCA 擬合" },
                new ParameterDef { Name=nameof(MinLinearityRatio), Type="double", DefaultValue=10.0, Min=1.0, Max=1000.0,
                    Description="線性度門檻（僅 ForceXY）：主慣量比 λ₁/λ₂ 下限" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!ctx.NamedClouds.TryGetValue(InputCloudName, out var cloud))
                    return ModuleResult.Fail($"找不到點雲：{InputCloudName}");

                if (VirtualMode)
                {
                    ctx.FittedGeometries[OutputName] = new HTuple(new double[] { 0, 0, 0, 1, 0, 0 });
                    ctx.AddLog($"[VirtualMode] LineFitter：{OutputName} 輸入驗證通過，假直線 [0,0,0,1,0,0]");
                    return ModuleResult.Success(OutputName);
                }

                double px, py, pz, dx, dy, dz;

                if (ForceXY)
                {
                    // 2.5D 模式：投影到 XY 後用 PCA，並檢查線性度
                    if (!FitLineXY(cloud, out px, out py, out pz, out dx, out dy, out dz,
                                   out double linearity, out string err))
                        return ModuleResult.Fail(err);

                    ctx.FittedGeometries[OutputName] = new HTuple(new double[] { px, py, pz, dx, dy, dz });
                    ctx.AddLog($"LineFitter：{OutputName}  " +
                               $"點=({px:F4},{py:F4},{pz:F4}) mm  " +
                               $"方向=({dx:F4},{dy:F4},{dz:F4})  [ForceXY, λ₁/λ₂={linearity:F1}]");
                }
                else
                {
                    // 3D 模式：使用原生 fit_primitives_object_model_3d 以 cylinder 擬合
                    // cylinder 的 primitive_pose 的 Z 軸即為圓柱軸向，適合用作直線方向。
                    if (!FitLine3D(cloud, out px, out py, out pz, out dx, out dy, out dz, out string err))
                        return ModuleResult.Fail(err);

                    ctx.FittedGeometries[OutputName] = new HTuple(new double[] { px, py, pz, dx, dy, dz });
                    ctx.AddLog($"LineFitter：{OutputName}  " +
                               $"點=({px:F4},{py:F4},{pz:F4}) mm  " +
                               $"方向=({dx:F4},{dy:F4},{dz:F4})");
                }

                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }

        /// <summary>3D 直線擬合：以 cylinder 擬合取軸向</summary>
        private static bool FitLine3D(HObjectModel3D cloud,
            out double px, out double py, out double pz,
            out double dx, out double dy, out double dz,
            out string err)
        {
            px = py = pz = dx = dy = dz = 0;
            err = null;

            HObjectModel3D fitted = null;
            try
            {
                fitted = cloud.FitPrimitivesObjectModel3d(
                    new HTuple("primitive_type", "fitting_algorithm"),
                    new HTuple("cylinder", "least_squares_huber"));

                HOperatorSet.GetObjectModel3dParams(fitted, "primitive_pose", out HTuple primPose);
                if (primPose.Length < 7)
                {
                    err = "3D 直線擬合失敗：無法取得 primitive_pose（可能點雲形狀不是線狀/圓柱）";
                    return false;
                }

                HOperatorSet.PoseToHomMat3d(primPose, out HTuple hom);

                // cylinder 軸向 = pose 的 Z 軸方向
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 0,
                    out HTuple ox, out HTuple oy, out HTuple oz);
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 1,
                    out HTuple zx, out HTuple zy, out HTuple zz);

                px = ox[0].D; py = oy[0].D; pz = oz[0].D;
                dx = zx[0].D - ox[0].D;
                dy = zy[0].D - oy[0].D;
                dz = zz[0].D - oz[0].D;

                // 正規化方向向量
                double len = Math.Sqrt(dx * dx + dy * dy + dz * dz);
                if (len < 1e-9)
                {
                    err = "3D 直線擬合失敗：擬合軸向長度退化為 0";
                    return false;
                }
                dx /= len; dy /= len; dz /= len;
                return true;
            }
            catch (Exception ex)
            {
                err = $"3D 直線擬合失敗：{ex.Message}";
                return false;
            }
            finally
            {
                fitted?.Dispose();
            }
        }

        /// <summary>2.5D 直線擬合：投影到 XY 平面後用 moments 主軸，並回傳線性度</summary>
        private bool FitLineXY(HObjectModel3D cloud,
            out double px, out double py, out double pz,
            out double dx, out double dy, out double dz,
            out double linearity, out string err)
        {
            px = py = pz = dx = dy = dz = 0;
            linearity = 0;
            err = null;

            HObjectModel3D xyCloud = null;
            try
            {
                HOperatorSet.GetObjectModel3dParams(cloud, "point_coord_x", out HTuple xs);
                HOperatorSet.GetObjectModel3dParams(cloud, "point_coord_y", out HTuple ys);
                int nPts = xs.Length;
                if (nPts < 3)
                {
                    err = $"點數不足（{nPts} < 3），無法擬合直線";
                    return false;
                }

                HTuple zs = new HTuple(new double[nPts]);
                HOperatorSet.GenObjectModel3dFromPoints(xs, ys, zs, out HTuple xyCloudId);
                xyCloud = new HObjectModel3D(xyCloudId[0].H.Handle);  // ✅ 取 IntPtr

                // 使用 principal_axes 取主軸：回傳的 pose 中 X 軸為最大慣量主軸
                HOperatorSet.MomentsObjectModel3d(xyCloud, "principal_axes", out HTuple principalPose);
                HOperatorSet.PoseToHomMat3d(principalPose, out HTuple hom);

                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 0,
                    out HTuple ox, out HTuple oy, out HTuple oz);
                HOperatorSet.AffineTransPoint3d(hom, 1, 0, 0,
                    out HTuple ex, out HTuple ey, out HTuple ez);

                px = ox[0].D; py = oy[0].D; pz = 0;  // ForceXY：Z 清零
                dx = ex[0].D - ox[0].D;
                dy = ey[0].D - oy[0].D;
                dz = 0;

                double len = Math.Sqrt(dx * dx + dy * dy);
                if (len < 1e-9)
                {
                    err = "2.5D 直線擬合失敗：主軸長度退化為 0";
                    return false;
                }
                dx /= len; dy /= len;

                // 線性度檢查：計算 XY 點集的共變異矩陣特徵值比
                linearity = ComputeLinearityXY(xs, ys);
                if (linearity < MinLinearityRatio)
                {
                    err = $"2.5D 直線擬合失敗：線性度 λ₁/λ₂ = {linearity:F2} < {MinLinearityRatio:F2}，" +
                          $"點雲形狀過於圓整，不適合擬合直線";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                err = $"2.5D 直線擬合失敗：{ex.Message}";
                return false;
            }
            finally
            {
                xyCloud?.Dispose();
            }
        }

        /// <summary>計算 2D 點集共變異矩陣的特徵值比 λ₁/λ₂（衡量形狀細長程度）</summary>
        private static double ComputeLinearityXY(HTuple xs, HTuple ys)
        {
            int n = xs.Length;
            if (n < 2) return 0;

            // 計算均值
            double mx = 0, my = 0;
            for (int i = 0; i < n; i++) { mx += xs[i].D; my += ys[i].D; }
            mx /= n; my /= n;

            // 2x2 共變異矩陣 [[a, b], [b, c]]
            double a = 0, b = 0, c = 0;
            for (int i = 0; i < n; i++)
            {
                double dxi = xs[i].D - mx;
                double dyi = ys[i].D - my;
                a += dxi * dxi;
                b += dxi * dyi;
                c += dyi * dyi;
            }
            a /= n; b /= n; c /= n;

            // 特徵值：λ = (a+c)/2 ± sqrt(((a-c)/2)² + b²)
            double mean = (a + c) / 2.0;
            double diff = Math.Sqrt(((a - c) / 2.0) * ((a - c) / 2.0) + b * b);
            double lambda1 = mean + diff;  // 最大
            double lambda2 = mean - diff;  // 最小

            if (lambda2 < 1e-12) return double.PositiveInfinity;  // 完美直線
            return lambda1 / lambda2;
        }
    }

    // =========================================================
    // [Fitting] 3D 平面擬合
    //
    //   結果儲存於 ctx.FittedGeometries[OutputName]：
    //     HTuple[0..2] = (nx, ny, nz) 單位法向量
    //     HTuple[3]    = d            平面到原點距離（mm）
    //
    //   Validate2_5D = true（2.5D 驗證模式）：
    //     若 |nz| < MinNzComponent 則拒絕擬合結果，
    //     確保量測的是水平面而非側面。
    // =========================================================
    public class PlaneFitter : IAlgorithmModule
    {
        public string ModuleName => "PlaneFitter";
        public string ModuleCategory => "Fitting";

        public string InputCloudName { get; set; } = "ROI";
        public string OutputName { get; set; } = "Plane1";

        /// <summary>2.5D 水平面驗證：若 |nz| &lt; MinNzComponent 則拒絕擬合結果</summary>
        public bool Validate2_5D { get; set; } = false;

        /// <summary>法向量 Z 分量最小值（0~1），預設 0.7 ≈ 45° 傾角門檻</summary>
        public double MinNzComponent { get; set; } = 0.7;

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(InputCloudName),  Type="string", DefaultValue="ROI",    Description="輸入子點雲名稱" },
                new ParameterDef { Name=nameof(OutputName),      Type="string", DefaultValue="Plane1", Description="輸出幾何名稱" },
                new ParameterDef { Name=nameof(Validate2_5D),    Type="bool",   DefaultValue=false,
                    Description="2.5D 驗證：|nz| < MinNzComponent 時拒絕（確保水平面）" },
                new ParameterDef { Name=nameof(MinNzComponent),  Type="double", DefaultValue=0.7, Min=0.0, Max=1.0,
                    Description="法向量 Z 分量最小值（0.7 ≈ 45° 傾角門檻）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!ctx.NamedClouds.TryGetValue(InputCloudName, out var cloud))
                    return ModuleResult.Fail($"找不到點雲：{InputCloudName}");

                if (VirtualMode)
                {
                    ctx.FittedGeometries[OutputName] = new HTuple(new double[] { 0, 0, 1, 0 });
                    ctx.AddLog($"[VirtualMode] PlaneFitter：{OutputName} 輸入驗證通過，假平面 [nx=0,ny=0,nz=1,d=0]");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D fitted = cloud.FitPrimitivesObjectModel3d("primitive_type", "plane");
                HOperatorSet.GetObjectModel3dParams(fitted, "primitive_pose", out HTuple primPose);
                fitted.Dispose();

                HOperatorSet.PoseToHomMat3d(primPose, out HTuple hom);
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 0,
                    out HTuple ox, out HTuple oy, out HTuple oz);
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 1,
                    out HTuple zx, out HTuple zy, out HTuple zz);

                double nx  = zx[0].D - ox[0].D;
                double ny  = zy[0].D - oy[0].D;
                double nz  = zz[0].D - oz[0].D;
                double nLen = Math.Sqrt(nx*nx + ny*ny + nz*nz);
                nx /= nLen; ny /= nLen; nz /= nLen;

                double absNz = Math.Abs(nz);
                if (absNz < 0.7)
                    ctx.AddLog($"⚠️ PlaneFitter 警告：{OutputName} |nz|={absNz:F3} < 0.7，" +
                               "擬合面可能為側面而非水平面，建議檢查 ROI 設定");

                if (Validate2_5D && absNz < MinNzComponent)
                    return ModuleResult.Fail(
                        $"PlaneFitter 2.5D 驗證失敗：{OutputName} |nz|={absNz:F3} < {MinNzComponent:F3}，" +
                        "擬合結果為非水平面，請確認 ROI 是否包含到側面或雜點");

                double ptx = ox[0].D, pty = oy[0].D, ptz = oz[0].D;
                double d = nx*ptx + ny*pty + nz*ptz;

                ctx.FittedGeometries[OutputName] = new HTuple(new double[] { nx, ny, nz, d });
                ctx.AddLog($"PlaneFitter：{OutputName}  法向=({nx:F4},{ny:F4},{nz:F4})  d={d:F4} mm");
                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Fitting] 3D 點雲擬合圓
    //
    //   結果儲存於 ctx.FittedGeometries[OutputName]：
    //     HTuple[0..2] = (cx, cy, cz) 圓心座標（mm）
    //     HTuple[3]    = radius        圓半徑（mm）
    //     HTuple[4..6] = (nx, ny, nz) 圓所在平面法向量
    //
    //   Validate2_5D = true：若 |nz| < MinNzComponent 則拒絕
    // =========================================================
    public class CircleFitter : IAlgorithmModule
    {
        public string ModuleName => "CircleFitter";
        public string ModuleCategory => "Fitting";
        public string InputCloudName { get; set; } = "ROI";
        public string OutputName { get; set; } = "Circle1";

        /// <summary>2.5D 驗證：確保擬合的是水平圓（頂面孔）而非側面圓</summary>
        public bool Validate2_5D { get; set; } = false;

        /// <summary>法向量 Z 分量最小值，預設 0.7</summary>
        public double MinNzComponent { get; set; } = 0.7;

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(InputCloudName),  Type="string", DefaultValue="ROI",     Description="輸入子點雲名稱" },
                new ParameterDef { Name=nameof(OutputName),      Type="string", DefaultValue="Circle1", Description="輸出幾何名稱" },
                new ParameterDef { Name=nameof(Validate2_5D),    Type="bool",   DefaultValue=false,
                    Description="2.5D 驗證：|nz| < MinNzComponent 時拒絕（確保水平圓）" },
                new ParameterDef { Name=nameof(MinNzComponent),  Type="double", DefaultValue=0.7, Min=0.0, Max=1.0,
                    Description="法向量 Z 分量最小值（0.7 ≈ 45° 傾角門檻）" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!ctx.NamedClouds.TryGetValue(InputCloudName, out var cloud))
                    return ModuleResult.Fail($"找不到點雲：{InputCloudName}");

                if (VirtualMode)
                {
                    ctx.FittedGeometries[OutputName] = new HTuple(new double[] { 0, 0, 0, 1, 0, 0, 1 });
                    ctx.AddLog($"[VirtualMode] CircleFitter：{OutputName} 輸入驗證通過，假圓 [cx=0,cy=0,cz=0,r=1,nx=0,ny=0,nz=1]");
                    return ModuleResult.Success(OutputName);
                }

                HObjectModel3D fitted = cloud.FitPrimitivesObjectModel3d("primitive_type", "circle");
                HOperatorSet.GetObjectModel3dParams(fitted, "primitive_pose",   out HTuple primPose);
                HOperatorSet.GetObjectModel3dParams(fitted, "primitive_radius", out HTuple primRadius);
                fitted.Dispose();

                HOperatorSet.PoseToHomMat3d(primPose, out HTuple hom);
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 0,
                    out HTuple cx, out HTuple cy, out HTuple cz);
                HOperatorSet.AffineTransPoint3d(hom, 0, 0, 1,
                    out HTuple zx, out HTuple zy, out HTuple zz);

                double nx = zx[0].D - cx[0].D;
                double ny = zy[0].D - cy[0].D;
                double nz = zz[0].D - cz[0].D;
                double nLen = Math.Sqrt(nx * nx + ny * ny + nz * nz);
                nx /= nLen; ny /= nLen; nz /= nLen;

                double absNz = Math.Abs(nz);
                if (absNz < 0.7)
                    ctx.AddLog($"⚠️ CircleFitter 警告：{OutputName} |nz|={absNz:F3} < 0.7，" +
                               "圓所在平面可能不是水平面，建議確認是否為頂面孔");

                if (Validate2_5D && absNz < MinNzComponent)
                    return ModuleResult.Fail(
                        $"CircleFitter 2.5D 驗證失敗：{OutputName} |nz|={absNz:F3} < {MinNzComponent:F3}，" +
                        "擬合圓不在水平面上（可能是側面孔或雜點），請確認 ROI");

                double radius = primRadius[0].D;
                ctx.FittedGeometries[OutputName] = new HTuple(
                    new double[] { cx[0].D, cy[0].D, cz[0].D, radius, nx, ny, nz });

                ctx.AddLog($"CircleFitter：{OutputName}  " +
                           $"圓心=({cx[0].D:F4}, {cy[0].D:F4}, {cz[0].D:F4}) mm  " +
                           $"半徑={radius:F4} mm  法向=({nx:F4}, {ny:F4}, {nz:F4})");
                return ModuleResult.Success(OutputName);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 線到線距離（mm）
    // =========================================================
    public class MeasureLineToLine3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureLineToLine3D";
        public string ModuleCategory => "Measure";

        public string LineAName { get; set; } = "Line1";
        public string LineBName { get; set; } = "Line2";
        public string OutputKey  { get; set; } = "Dist_L2L";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(LineAName),  Type="string", DefaultValue="Line1" },
                new ParameterDef { Name=nameof(LineBName),  Type="string", DefaultValue="Line2" },
                new ParameterDef { Name=nameof(OutputKey),  Type="string", DefaultValue="Dist_L2L" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetLine(ctx, LineAName, out var pA, out var dA))
                    return ModuleResult.Fail($"找不到直線：{LineAName}");
                if (!Vec3.TryGetLine(ctx, LineBName, out var pB, out var dB))
                    return ModuleResult.Fail($"找不到直線：{LineBName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureLineToLine3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double dist = Vec3.SegmentToSegment(pA, dA, pB, dB);
                ctx.MeasureResults[OutputKey] = dist;
                ctx.AddLog($"MeasureLineToLine3D（線段模式）：{OutputKey} = {dist:F4} mm");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 點到線距離（mm）
    // =========================================================
    public class MeasurePointToLine3D : IAlgorithmModule
    {
        public string ModuleName => "MeasurePointToLine3D";
        public string ModuleCategory => "Measure";

        public string PointCloudName { get; set; } = "ROI_Point";
        public string LineName       { get; set; } = "Line1";
        public string OutputKey      { get; set; } = "Dist_P2L";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(PointCloudName), Type="string", DefaultValue="ROI_Point" },
                new ParameterDef { Name=nameof(LineName),       Type="string", DefaultValue="Line1" },
                new ParameterDef { Name=nameof(OutputKey),      Type="string", DefaultValue="Dist_P2L" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!ctx.NamedClouds.TryGetValue(PointCloudName, out var ptCloud))
                    return ModuleResult.Fail($"找不到點雲：{PointCloudName}");
                if (!Vec3.TryGetLine(ctx, LineName, out var lp, out var ld))
                    return ModuleResult.Fail($"找不到直線：{LineName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasurePointToLine3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                HOperatorSet.GetObjectModel3dParams(ptCloud, "center", out HTuple center);
                if (center.Length < 3) return ModuleResult.Fail("無法取得質心");

                double[] pt = { center[0].D, center[1].D, center[2].D };
                double dist = Vec3.PointToLine(pt, lp, ld);
                ctx.MeasureResults[OutputKey] = dist;
                ctx.AddLog($"MeasurePointToLine3D：{OutputKey} = {dist:F4} mm");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 線到平面距離（mm）
    // =========================================================
    public class MeasureLineToPlane3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureLineToPlane3D";
        public string ModuleCategory => "Measure";

        public string LineName   { get; set; } = "Line1";
        public string PlaneName  { get; set; } = "Plane1";
        public string OutputKey  { get; set; } = "Dist_L2Pl";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(LineName),  Type="string", DefaultValue="Line1" },
                new ParameterDef { Name=nameof(PlaneName), Type="string", DefaultValue="Plane1" },
                new ParameterDef { Name=nameof(OutputKey), Type="string", DefaultValue="Dist_L2Pl" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetLine(ctx, LineName, out var lp, out var ld))
                    return ModuleResult.Fail($"找不到直線：{LineName}");
                if (!Vec3.TryGetPlane(ctx, PlaneName, out var normal, out double d))
                    return ModuleResult.Fail($"找不到平面：{PlaneName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureLineToPlane3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double dist = Math.Abs(Vec3.Dot(normal, lp) - d) / Vec3.Norm(normal);
                ctx.MeasureResults[OutputKey] = dist;
                ctx.AddLog($"MeasureLineToPlane3D：{OutputKey} = {dist:F4} mm");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 直線與指定軸夾角（度）
    // =========================================================
    public class MeasureAngleWithAxis3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureAngleWithAxis3D";
        public string ModuleCategory => "Measure";

        public string LineName  { get; set; } = "Line1";
        public string Axis      { get; set; } = "X";
        public string OutputKey { get; set; } = "Angle_LX";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(LineName),  Type="string", DefaultValue="Line1", Description="目標直線名稱" },
                new ParameterDef { Name=nameof(Axis),      Type="string", DefaultValue="X",     Description="參考軸：X/Y/Z" },
                new ParameterDef { Name=nameof(OutputKey), Type="string", DefaultValue="Angle_LX" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetLine(ctx, LineName, out _, out var dir))
                    return ModuleResult.Fail($"找不到直線：{LineName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureAngleWithAxis3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double[] axisVec;
                switch (Axis.ToUpper())
                {
                    case "Y":  axisVec = new double[]{ 0, 1, 0 }; break;
                    case "Z":  axisVec = new double[]{ 0, 0, 1 }; break;
                    default:   axisVec = new double[]{ 1, 0, 0 }; break;
                }

                double angleRad = Vec3.AngleWithAxis(dir, axisVec);
                double angleDeg = angleRad * 180.0 / Math.PI;
                ctx.MeasureResults[OutputKey] = angleDeg;
                ctx.AddLog($"MeasureAngleWithAxis3D：{OutputKey} ({LineName} vs {Axis}) = {angleDeg:F4}°");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 兩直線夾角（度）
    // =========================================================
    public class MeasureAngleBetweenLines3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureAngleBetweenLines3D";
        public string ModuleCategory => "Measure";

        public string LineAName { get; set; } = "Line1";
        public string LineBName { get; set; } = "Line2";
        public string OutputKey { get; set; } = "Angle_LL";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(LineAName), Type="string", DefaultValue="Line1" },
                new ParameterDef { Name=nameof(LineBName), Type="string", DefaultValue="Line2" },
                new ParameterDef { Name=nameof(OutputKey), Type="string", DefaultValue="Angle_LL" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetLine(ctx, LineAName, out _, out var dA))
                    return ModuleResult.Fail($"找不到直線：{LineAName}");
                if (!Vec3.TryGetLine(ctx, LineBName, out _, out var dB))
                    return ModuleResult.Fail($"找不到直線：{LineBName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureAngleBetweenLines3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double angleRad = Vec3.AngleBetweenLines(dA, dB);
                double angleDeg = angleRad * 180.0 / Math.PI;
                ctx.MeasureResults[OutputKey] = angleDeg;
                ctx.AddLog($"MeasureAngleBetweenLines3D：{OutputKey} = {angleDeg:F4}°");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 直線與平面夾角（度）
    // =========================================================
    public class MeasureAngleLinePlane3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureAngleLinePlane3D";
        public string ModuleCategory => "Measure";

        public string LineName  { get; set; } = "Line1";
        public string PlaneName { get; set; } = "Plane1";
        public string OutputKey { get; set; } = "Angle_LPl";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(LineName),  Type="string", DefaultValue="Line1" },
                new ParameterDef { Name=nameof(PlaneName), Type="string", DefaultValue="Plane1" },
                new ParameterDef { Name=nameof(OutputKey), Type="string", DefaultValue="Angle_LPl" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetLine(ctx, LineName, out _, out var dir))
                    return ModuleResult.Fail($"找不到直線：{LineName}");
                if (!Vec3.TryGetPlane(ctx, PlaneName, out var normal, out _))
                    return ModuleResult.Fail($"找不到平面：{PlaneName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureAngleLinePlane3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double angleWithNormal = Vec3.AngleWithAxis(dir, normal);
                double angleWithPlane  = Math.PI / 2.0 - angleWithNormal;
                double angleDeg = Math.Abs(angleWithPlane) * 180.0 / Math.PI;
                ctx.MeasureResults[OutputKey] = angleDeg;
                ctx.AddLog($"MeasureAngleLinePlane3D：{OutputKey} = {angleDeg:F4}°");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    // =========================================================
    // [Measure] 3D 兩平面夾角（度）
    // =========================================================
    public class MeasureAngleBetweenPlanes3D : IAlgorithmModule
    {
        public string ModuleName => "MeasureAngleBetweenPlanes3D";
        public string ModuleCategory => "Measure";

        public string PlaneAName { get; set; } = "Plane1";
        public string PlaneBName { get; set; } = "Plane2";
        public string OutputKey  { get; set; } = "Angle_PlPl";

        public bool VirtualMode { get; set; } = false;

        public ModuleParameterSchema GetSchema() => new ModuleParameterSchema
        {
            Parameters = new List<ParameterDef>
            {
                new ParameterDef { Name=nameof(PlaneAName), Type="string", DefaultValue="Plane1" },
                new ParameterDef { Name=nameof(PlaneBName), Type="string", DefaultValue="Plane2" },
                new ParameterDef { Name=nameof(OutputKey),  Type="string", DefaultValue="Angle_PlPl" },
            }
        };

        public ModuleResult Execute(MeasureContext ctx)
        {
            try
            {
                if (!Vec3.TryGetPlane(ctx, PlaneAName, out var nA, out _))
                    return ModuleResult.Fail($"找不到平面：{PlaneAName}");
                if (!Vec3.TryGetPlane(ctx, PlaneBName, out var nB, out _))
                    return ModuleResult.Fail($"找不到平面：{PlaneBName}");

                if (VirtualMode)
                {
                    ctx.MeasureResults[OutputKey] = 0.0;
                    ctx.AddLog($"[VirtualMode] MeasureAngleBetweenPlanes3D：{OutputKey} 輸入驗證通過，假值 0.0");
                    return ModuleResult.Success(OutputKey);
                }

                double angleRad = Vec3.AngleBetweenLines(nA, nB);
                double angleDeg = angleRad * 180.0 / Math.PI;
                ctx.MeasureResults[OutputKey] = angleDeg;
                ctx.AddLog($"MeasureAngleBetweenPlanes3D：{OutputKey} = {angleDeg:F4}°");
                return ModuleResult.Success(OutputKey);
            }
            catch (Exception ex) { return ModuleResult.Fail(ex.Message); }
        }
    }

    public static class Tool
    {
        /// <summary>
        /// 將 Halcon HImage 轉換為 float[]
        /// </summary>
        /// <param name="image">輸入的 HImage</param>
        /// <returns>float[] 像素數據 (依序為 row-major 排列)</returns>
        public static float[] HImageToFloatArray(out int ow, out int oh, HImage image, double res = 0.002)
        {
            // 取得圖像基本資訊
            image.GetImageSize(out int width, out int height);
            ow = width; oh = height;
            string imageType = image.GetImageType();
            float resolution = (float)res;
            int totalPixels = width * height;
            System.Diagnostics.Debug.WriteLine($"HImageToFloatArray：圖像類型={imageType} 解析度={resolution} mm/px 大小={width}x{height} 總像素={totalPixels}");
            float[] result = new float[totalPixels];

            switch (imageType)
            {
                case "byte":
                    {
                        // 取得原始指標，型別為 byte (0~255)
                        IntPtr ptr = image.GetImagePointer1(out string type, out int w, out int h);
                        unsafe
                        {
                            byte* data = (byte*)ptr.ToPointer();
                            for (int i = 0; i < totalPixels; i++)
                                result[i] = data[i] * resolution;
                        }
                        break;
                    }

                case "uint2":
                    {
                        IntPtr ptr = image.GetImagePointer1(out string type, out int w, out int h);
                        unsafe
                        {
                            ushort* data = (ushort*)ptr.ToPointer();
                            for (int i = 0; i < totalPixels; i++)
                                result[i] = data[i] * resolution;
                        }
                        break;
                    }

                case "int4":
                    {
                        IntPtr ptr = image.GetImagePointer1(out string type, out int w, out int h);
                        unsafe
                        {
                            int* data = (int*)ptr.ToPointer();
                            for (int i = 0; i < totalPixels; i++)
                                result[i] = data[i] * resolution;
                        }
                        break;
                    }

                case "real":
                    {
                        // Halcon "real" 型別本身就是 float
                        IntPtr ptr = image.GetImagePointer1(out string type, out int w, out int h);
                        unsafe
                        {
                            float* data = (float*)ptr.ToPointer();
                            for (int i = 0; i < totalPixels; i++)
                                result[i] = data[i] * resolution;
                        }
                        break;
                    }

                default:
                    throw new NotSupportedException($"不支援的 HImage 型別：{imageType}");
            }

            return result;
        }
    }
}
