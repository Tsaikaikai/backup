-----------------------------------------------------------------------------
File  : 'Readme.txt' - Readme for IrfanView Languages
Author: Irfan Skiljan
E-Mail: irfanview@gmx.net
WWW   : http://www.irfanview.com
-----------------------------------------------------------------------------



- How to install IrfanView languages?

  1) Find your IrfanView directory

  2) Unzip all files from the language ZIP into the "Languages" sub-directory

  3) Start IrfanView, go to menu: "Options->Change Language" and choose your language ;-)

  4) If a help (CHM) file is included, unzip it into IrfanView main folder, not "Languages".

Much fun!
