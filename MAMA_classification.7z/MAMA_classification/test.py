﻿# -*- coding: utf-8 -*-
"""
Created on Fri Aug 20 17:50:00 2021

@author: AOI
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 27 10:41:26 2021

@author: AOI
"""

import torch
import torch.nn as nn
import torch.utils.data as data
from torchvision.datasets import ImageFolder
import torch.optim as optim
from torchvision import transforms
from csp_resnet_18 import csp_resnet_18
from tqdm import tqdm 
import torch.onnx
import argparse
import os

from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from HTMLViewer import HTML

def set_arg():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", help="set name", type=str, default='AVI2')
    parser.add_argument("--dataroot", help="set test data path. Ex:./data/test/", type=str, default='./datasets/AVI2/')
    parser.add_argument("--input_nc", help="number of image channel. gray=1,color=3", type=int, default=1)
    parser.add_argument("--crop_size", help="set_model_img_size", type=int, default=128)


    return parser.parse_args()
        
def check_device():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print('use device: '+ str(device))
    return device

def load_data(TEST_DATA_PATH,CHANNEL):
    if CHANNEL == 1:
        TRANSFORM_IMG = transforms.Compose([
            transforms.Grayscale(num_output_channels=1),
            transforms.Resize([args.crop_size,args.crop_size]),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5],std=[0.5])])
        
    elif CHANNEL == 3:
        TRANSFORM_IMG = transforms.Compose([
            transforms.Resize([args.crop_size,args.crop_size]),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5],std=[0.5, 0.5, 0.5])])
        
    else:
        raise IndexError('Number of channel: ' + str(CHANNEL) + "doesn't suppoor")
        
    print('load data...')
    test_data = ImageFolder(root=TEST_DATA_PATH, transform=TRANSFORM_IMG)
    test_data_loader  = data.DataLoader(test_data, batch_size=1, shuffle=False)
    print("Number of test samples: ", len(test_data))
    return test_data, test_data_loader

def validate(test_loader, model,device):
    y_pred = []  # 保存預測label
    y_true = []  # 保存實際label

    with torch.no_grad():
        model.eval()
        for i, (images, target) in enumerate(test_loader):
            images, target = images.to(device), target.to(device)
            output = model(images)
            _, preds = torch.max(output, 1)  # preds是預測結果

            y_pred.extend(preds.view(-1).detach().cpu().numpy())  # 將preds預測結果detach出來，並轉成numpy格式
            y_true.extend(target.view(-1).detach().cpu().numpy())  # target是ground-truth的label

    return y_pred, y_true
def show_confusion_matrix(confusion_matrix, class_names,filename):
    fig = plt.figure()
    cm = confusion_matrix.copy()
    cell_counts = cm.flatten()
    cm_row_norm = cm / cm.sum(axis=1)[:, np.newaxis]
    row_percentages = ["{0:.2f}".format(value) for value in cm_row_norm.flatten()]
    cell_labels = [f"{cnt}\n{per}" for cnt, per in zip(cell_counts, row_percentages)]
    cell_labels = np.asarray(cell_labels).reshape(cm.shape[0], cm.shape[1])
    df_cm = pd.DataFrame(cm_row_norm, index=class_names, columns=class_names)
    hmap = sns.heatmap(df_cm, annot=cell_labels, fmt="", cmap="Blues")
    hmap.yaxis.set_ticklabels(hmap.yaxis.get_ticklabels(), rotation=0, ha='right')
    hmap.xaxis.set_ticklabels(hmap.xaxis.get_ticklabels(), rotation=30, ha='right')
    plt.ylabel('True Sign')
    plt.xlabel('Predicted Sign')
    fig.savefig(filename, dpi=fig.dpi, bbox_inches='tight')

if __name__ == '__main__':
    args = set_arg()
    device = check_device()
    Test_dataRoot = os.path.join(args.dataroot, 'test')
    test_data, test_data_loader = load_data(Test_dataRoot, args.input_nc)

    resultFolder = ".\\results\\"
    projectpath = os.path.join(resultFolder, args.name)
    if not os.path.exists(resultFolder):
        os.makedirs(resultFolder)
    if not os.path.exists(projectpath):
        os.makedirs(projectpath)

    model = torch.load('./model/' + args.name + '.pt')
    print('\nload model from ./model/ '+args.name +'.pt')
    model.to(device)
    loss_func = nn.CrossEntropyLoss()
    #Testing
    test_correct = 0
    total_test_loss = 0

    y_pred = []  # 保存預測label
    y_true = []  # 保存實際label
    with torch.no_grad():
        model.eval()
        for test_step, (test_x, test_y) in enumerate(tqdm(test_data_loader,ascii=True)):
            test_x,test_y = test_x.to(device),test_y.to(device)
            test_output = model(test_x)
            test_loss = loss_func(test_output, test_y)
            test_pred_y = torch.max(test_output, 1)[1].data
            total_test_loss += test_loss
            test_correct += (test_pred_y == test_y).float().sum()

            _, preds = torch.max(test_output, 1)  # preds是預測結果
            y_pred.extend(preds.view(-1).detach().cpu().numpy())  # 將preds預測結果detach出來，並轉成numpy格式
            y_true.extend(test_y.view(-1).detach().cpu().numpy())  # target是ground-truth的label

    # print(len(test_data))
    test_accuracy = test_correct / len(test_data)
    print('\n\ntest accuracy:  %.4f' % test_accuracy, '| test loss: %.4f' % (total_test_loss/(test_step+1))+'\n')


    classname = test_data.classes
    cf_matrix = confusion_matrix(y_true, y_pred)
    show_confusion_matrix(cf_matrix, classname, projectpath + '\confusion.jpg')
    webpage = HTML(projectpath, 'Experiment name = %s' % "Classifcation")
    webpage.add_header1('Classifcation Result')
    webpage.add_header1('Project Name: %s' % (args.name))
    webpage.add_header1('-----------------------------------------')
    webpage.add_header('Image Size:  %s * %s * %s' % (args.crop_size , args.crop_size, args.input_nc))
    webpage.add_header('Total Images :  %d' % len(test_data))
    webpage.add_header('Test accuracy:  %.4f' % test_accuracy)
    webpage.add_header('Test loss: %.4f' % (total_test_loss / (test_step + 1)))
    webpage.add_header1('-----------------------------------------')

    txts, links = [], []

    txts.append("Confusion Matrix")
    links.append('confusion.jpg')
    webpage.add_images(txts, links)
    webpage.save()