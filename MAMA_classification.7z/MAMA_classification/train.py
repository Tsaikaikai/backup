import torch
import torch.nn as nn
import torch.utils.data as data
from torchvision.datasets import ImageFolder
from torchvision import transforms
from csp_resnet_18 import csp_resnet_18
from tqdm import tqdm
import torch.onnx
import argparse
import os



def set_arg():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataroot", help="set train and test data path. Ex:./datasets/", type=str, default='./datasets/211123/')
    parser.add_argument("--name", help="set name", type=str, default='211113')
    parser.add_argument("--batch_size", help="set batch size of train and test", type=int, default=10)    
    parser.add_argument("--input_nc", help="number of image channel. gray=1,color=3", type=int, default=3)    
    parser.add_argument("--crop_size", help="set_model_img_size", type=int, default=224)
    parser.add_argument("--n_epochs", help="set training epoch", type=int, default=100)
    parser.add_argument("--learning_rate", help="set learning rate", type=float, default=0.0001)
    parser.add_argument("--continue_train", help="true or flase retrain",action='store_true')

    return parser.parse_args()
        
def check_device():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print('use device: '+ str(device))
    return device

def load_data(TRAIN_DATA_PATH,TEST_DATA_PATH,BATCH_SIZE,CHANNEL):
    
    if CHANNEL == 1:
        TRANSFORM_IMG = transforms.Compose([
            transforms.Grayscale(num_output_channels=1),
            transforms.Resize([args.crop_size,args.crop_size]),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5],std=[0.5])])
        
    elif CHANNEL == 3:
        TRANSFORM_IMG = transforms.Compose([
            transforms.Resize([args.crop_size,args.crop_size]),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5],std=[0.5, 0.5, 0.5])])
        
    else:
        raise IndexError('Number of channel ' + str(CHANNEL) + " doesn't support.")
    
    print('load data...')
    train_data = ImageFolder(root=TRAIN_DATA_PATH, transform=TRANSFORM_IMG)
    train_data_loader = data.DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True)
    test_data = ImageFolder(root=TEST_DATA_PATH, transform=TRANSFORM_IMG)
    test_data_loader  = data.DataLoader(test_data, batch_size=1, shuffle=False)
    print("Number of train samples: ", len(train_data))
    print("Number of test samples: ", len(test_data))
    print("Detected Classes are: ", train_data.class_to_idx) # classes are detected by folder structure    
    return train_data, train_data_loader, test_data, test_data_loader, len(train_data.class_to_idx)


if __name__ == '__main__':
    args = set_arg()
    device = check_device()
    Train_data = args.dataroot + 'train/' 
    Test_data = args.dataroot + 'test/' 
    train_data, train_data_loader, test_data, test_data_loader, num_class = load_data(Train_data, Test_data, args.batch_size, args.input_nc)
    
    if os.path.exists('.\\model'):
        print("Model directory already exists: ./model/")
    else :
        os.makedirs('.\\model\\')
        print('make Output directory : ./output/')
    
    if args.continue_train == True:
        model = torch.load('./model/' + args.name + '.pt')
        print('\nload pretrain model from '+args.name + '.pt')

    else:
        model = csp_resnet_18(num_class, args.input_nc)
        print('\nload model...')
        
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    # scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5000, gamma=0.5)
    loss_func = nn.CrossEntropyLoss()    
    best_accuracy = 0
    
    # Training
    for epoch in range(args.n_epochs):
        train_correct = 0
        total_train_loss = 0
        model.train()
        for train_step, (batch_train_x, batch_train_y) in enumerate(tqdm(train_data_loader,ascii=True)):
            batch_train_x,batch_train_y = batch_train_x.to(device),batch_train_y.to(device)
            train_output = model(batch_train_x)
            train_loss = loss_func(train_output, batch_train_y)
            train_pred_y = torch.max(train_output, 1)[1].data
            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()
            # scheduler.step()
            total_train_loss += train_loss
            train_correct += (train_pred_y == batch_train_y).float().sum()
            # print((train_pred_y == batch_train_y).float())
        train_accuracy = train_correct / len(train_data)       
        
        #Testing
        test_correct = 0
        total_test_loss = 0
        totoal_time = 0
        with torch.no_grad():
            model.eval()
            for test_step, (test_x, test_y) in enumerate(tqdm(test_data_loader,ascii=True)):
                test_x,test_y = test_x.to(device),test_y.to(device)
                # t1 = time.time()
                test_output = model(test_x)
                # t2 = time.time()-t1
                # totoal_time+=t2
                test_loss = loss_func(test_output, test_y)
                test_pred_y = torch.max(test_output, 1)[1].data
                total_test_loss += test_loss
                test_correct += (test_pred_y == test_y).float().sum()
        # print(len(test_data))   
        test_accuracy = test_correct / len(test_data)      
        
        print('\nEpoch-{0} lr: {1}'.format(epoch+1, optimizer.param_groups[0]['lr']))
        print('train accuracy: %.4f' % train_accuracy, '| train loss: %.4f' % (total_train_loss/(train_step+1)))
        print('test accuracy:  %.4f' % test_accuracy, '| test loss: %.4f' % (total_test_loss/(test_step+1))+'\n')

        # print('avg_time: %.4f' % (totoal_time/(test_step+1))+'\n')
        
        #save best model
        if test_accuracy > best_accuracy:            
            torch.save(model, './model/' + args.name+'.pt')
            best_accuracy = test_accuracy

    print('Save model : ./model/ ' + args.name+'.pt')
    print('Training complete.')