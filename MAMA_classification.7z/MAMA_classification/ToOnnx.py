# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 17:25:21 2021

@author: AOI
"""

import torch
import argparse
import os
import torch.nn.functional as F
from csp_resnet_18 import csp_resnet_18_softmax

if __name__ == '__main__':
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--name',type=str,help='model name', default='AVI')
    parser.add_argument("--input_nc", help="number of image channel. gray=1,color=3", type=int, default=1)
    parser.add_argument("--crop_size", help="set_model_img_size", type=int, default=128)
    args = parser.parse_args()

    if os.path.exists('.\\onnx'):
        print("Output directory already exists: ./onnx/")
    else :
        os.makedirs('.\\onnx')
        print('make Output directory : ./onnx/')

    device = 'cpu'
    model = torch.load('./model/' + args.name + '.pt')
    model.eval()
    model.to(device)
    onnx = csp_resnet_18_softmax(model)
    dummy_input = torch.randn(1, args.input_nc, args.crop_size, args.crop_size, requires_grad=True).to(device)
     
    torch.onnx.export(onnx, dummy_input, './onnx/'+ args.name +".onnx",
                      input_names = ['CspNet_input'],
                      output_names = ['CspNet_output'])
    print(args.name + ' transfer to onnx complete.')