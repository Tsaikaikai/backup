# -*- coding: utf-8 -*-
"""
Created on Wed May 19 15:14:39 2021

@author: AOI
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
# from torchsummary import summary
#from conv_bn import BN_Conv2d_Leaky
# from ptflops import get_model_complexity_info

class BN_Conv2d_Leaky(nn.Module):
    """
    BN_CONV_LeakyRELU
    """

    def __init__(self, in_channels: object, out_channels: object, kernel_size: object, stride: object, padding: object,
                 dilation=1, bias=False) -> object:
        super(BN_Conv2d_Leaky, self).__init__()
        self.seq = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                      padding=padding, dilation=dilation, bias=bias),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        return F.leaky_relu(self.seq(x))


class ResidualBlock(nn.Module):
    def __init__(self, inchannel, outchannel, stride=1):
        super(ResidualBlock, self).__init__()
        self.left = nn.Sequential(
            nn.Conv2d(inchannel, outchannel, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(outchannel),
            nn.ReLU(inplace=True),
            nn.Conv2d(outchannel, outchannel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(outchannel)
        )
        self.shortcut = nn.Sequential()
        if stride != 1 or inchannel != outchannel:
            self.shortcut = nn.Sequential(
                nn.Conv2d(inchannel, outchannel, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(outchannel)
            )

    def forward(self, x):
        out = self.left(x)
        out += self.shortcut(x)
        out = F.relu(out)
        return out


class Stem(nn.Module):
    def __init__(self, in_channels, num_blocks, stride=2):
        super(Stem, self).__init__()
        self.c0 = in_channels // 2
        self.c1 = in_channels - in_channels // 2
        self.inchannel = self.c1
        self.hidden_channels = in_channels
        self.out_channels = self.hidden_channels * 2
        self.trans_part0 = nn.Sequential(BN_Conv2d_Leaky(self.c0, self.hidden_channels, 1, 1, 0), nn.AvgPool2d(stride))
        self.block = self._make_layer(self.hidden_channels, num_blocks, stride)
        #part1 1*1 conv
        self.trans_part1 = BN_Conv2d_Leaky(self.hidden_channels, self.hidden_channels, 1, 1, 0)
        #concat 1*1conv
        self.trans = BN_Conv2d_Leaky(self.out_channels, self.out_channels, 1, 1, 0)

    def _make_layer(self, channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)   #strides=[1,1]
        layers = []
        for stride in strides:
            layers.append(ResidualBlock(self.inchannel, channels, stride))
            self.inchannel = channels
        return nn.Sequential(*layers)

    def forward(self, x):
        x0 = x[:, :self.c0, :, :]
        x1 = x[:, self.c0:, :, :]
        out0 = self.trans_part0(x0)
        out1 = self.trans_part1(self.block(x1))
        out = torch.cat((out0, out1), 1)
        return self.trans(out)


class CSP_ResNet(nn.Module):
    def __init__(self, num_blocks, cadinality, group_width, num_classes, num_channels):
        super(CSP_ResNet, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(num_channels, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1))
        self.stem0 = Stem(64, num_blocks[0], stride=1)
        self.stem1 = Stem(128, num_blocks[1])
        self.stem2 = Stem(256, num_blocks[2])
        self.stem3 = Stem(512, num_blocks[3])
        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(cadinality * group_width * 16, num_classes)
        self.dropout = nn.Dropout(p=0.1)

    def forward(self, x):
        out = self.conv1(x)
        out = self.stem0(out)
        out = self.stem1(out)
        out = self.stem2(out)
        out = self.stem3(out)
        out = self.global_pool(out)
        out = out.view(out.size(0), -1)
        # out = self.dropout(out)
        out = self.fc(out)
        # out = F.softmax(out,dim=1)
        return out

def csp_resnet_18(num_classes, num_channels):
    return CSP_ResNet([2, 2, 2, 2], 1, 64, num_classes, num_channels)

class csp_resnet_18_softmax(nn.Module):
    '''CNN that uses Fast Dense Feature Extraction to
       efficiently apply a patch-based CNN <base_net> on a whole image
    '''
    def __init__(self, cspnet):
        super(csp_resnet_18_softmax, self).__init__()
        self.cspnet = cspnet

    def forward(self, x):
        out = self.cspnet(x)
        out = F.softmax(out,dim=1)

        return out

if __name__ == '__main__':
    net = csp_resnet_18(num_classes=2, num_channels=1)
    # summary(net, (1, 224, 224))