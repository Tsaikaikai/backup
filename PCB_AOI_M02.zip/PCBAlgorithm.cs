﻿using Brandy;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using PatternMatch;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace PCB_AOI
{
    public class PCBAlgorithm
    {
        #region Initial
        CAlgorithmConfig Config = new CAlgorithmConfig();
        ChangeDetectionModel Core = null;

        public PCBAlgorithm()
        {

        }

        public bool LoadConfig(string ConfigPath)
        {
            try
            {
                Config = Config.ReadXmlConfig(ConfigPath);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class CutImage : IDisposable
        {
            public Mat ImageA;
            public Mat ImageB;
            public float[] floatImageA;
            public float[] floatImageB;
            public int X;
            public int Y;
            public Bitmap Result;
            bool _disposed;

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            ~CutImage()
            {
                Dispose();
            }
            protected virtual void Dispose(bool disposing)
            {
                if (_disposed) return;
                if (disposing)
                {
                    if (ImageA != null)
                        ImageA.Dispose();
                    if (ImageB != null)
                        ImageB.Dispose();
                }
                _disposed = true;
            }
        }
        public class Defect
        {
            public int Area;
            public int PosX;
            public int PosY;
            public int Width;
            public int Height;
            public int NumberPCB;
        }

        public class PointMatch
        {
            public PointF PointTop { get; set; }
            public PointF PointBtm { get; set; }
        }
        #endregion


        #region Main Function
        public bool DoLoadAIModel()
        {
            try
            {
                if (File.Exists(Config.AIModelPath) != true)
                {
                    throw new Exception("AI model file not exist.");
                }

                Core = new ChangeDetectionModel(Config.AIModelPath, Config.UseGPU);

                if (Core.InputShape[2] != Core.InputShape[3])
                {
                    throw new Exception("The width and height should be the same in model.");
                }

                if(Core.InputShape[2] != Config.AIInputSize || Core.InputShape[3] != Config.AIInputSize)
                {
                    throw new Exception("The model input is differnce than setting input size. Model size is " +
                        Core.InputShape[2] + " x " + Core.InputShape[3] + ", but setting is " + Config.AIInputSize + " x "+ Config.AIInputSize);
                }

                //Do first inference to ensure execution time is stable
                Random random = new Random();
                float[] array = new float[Core.InputShape[1] * Core.InputShape[2] * Core.InputShape[3] * Config.BatchSize];

                Parallel.For(0, array.Length, j =>
                {
                    array[j] = (float)random.NextDouble();
                });
                Core.BatchInference(array, array, Config.BatchSize);

                return true;
            }
            catch(Exception ex)
            {
                throw new Exception("Load AI Model Fail : " + ex.Message);
            }
        }

        public bool DoPCBAlignment(Mat SrcImage, Mat GdnImage, ref List<Mat> SrcAlignImageList, ref List<Mat> GdnAlignImageList)
        {
            List<PatternMatchResult> resultList = new List<PatternMatchResult>();
            List<PointF> resultSrcTopList = new List<PointF>();
            List<PointF> resultSrcBtmList = new List<PointF>();
            List<PointF> resultGdnTopList = new List<PointF>();
            List<PointF> resultGdnBtmList = new List<PointF>();
            List<PointMatch> srcPointMatchList = new List<PointMatch>();
            List<PointMatch> gdnPointMatchList = new List<PointMatch>();
            Mat scaleSrcImage = new Mat();
            Mat scaleGdnImage = new Mat();
            Mat scaleTopGolden = new Mat();
            Mat scaleBtmGolden = new Mat();
            Mat[] goldens = new Mat[2];
            Mat TopGolden = new Mat();
            Mat BtmGolden = new Mat();
            Mat srcAlignImage = new Mat();
            Mat gdnAlignImage = new Mat();
            Mat cropPCB = new Mat();
            Mat[] tempSrcAlignImageArr = new Mat[Config.PCBNumber];
            Mat[] tempGdnAlignImageArr = new Mat[Config.PCBNumber];

            try
            {
                if (SrcImage.Empty() == true || GdnImage.Empty() == true)
                {
                    throw new Exception("Input Image is empty !");
                }
                if (SrcImage.Width != Config.ImageWidth || GdnImage.Width != Config.ImageWidth 
                    || SrcImage.Height != Config.ImageHeight || GdnImage.Height != Config.ImageHeight)
                {
                    throw new Exception("Input image size is difference with setting !");
                }
                if (File.Exists(Config.TopAlignGoldenPath))
                {
                    TopGolden = Cv2.ImRead(Config.TopAlignGoldenPath, ImreadModes.Grayscale);
                }
                else throw new Exception("Top Align Golden Path not exist !");

                if (File.Exists(Config.BtmAlignGoldenPath))
                {
                    BtmGolden = Cv2.ImRead(Config.BtmAlignGoldenPath, ImreadModes.Grayscale);
                }
                else throw new Exception("Bottom Align Golden Path not exist !");

                //scale
                if (Config.Scale <= 0 || Config.Scale > 1) throw new Exception("Scale value should 0 > scale > =1");
                if (Config.Scale != 1)
                {
                    scaleSrcImage = ScaleImage(SrcImage, Config.Scale);
                    scaleGdnImage = ScaleImage(GdnImage, Config.Scale);
                    scaleTopGolden = ScaleImage(TopGolden, Config.Scale);
                    scaleBtmGolden = ScaleImage(BtmGolden, Config.Scale);
                }

                //pattern match
                goldens = new Mat[] { scaleTopGolden, scaleBtmGolden };
                for (int i = 0; i < goldens.Length; i++)
                {
                    if (FastPatternMatch(goldens[i], scaleSrcImage, ref resultList))
                    {
                        if (resultList.Count <= 0)
                        {
                            throw new Exception("Match failure : Source image not have any match result.");
                        }
                        else
                        {
                            //Src Top
                            if (i == 0)
                            {
                                foreach (PatternMatchResult result in resultList)
                                {
                                    resultSrcTopList.Add(result.Center);
                                }
                            }

                            //Src Btm
                            if (i == 1)
                            {
                                foreach (PatternMatchResult result in resultList)
                                {
                                    resultSrcBtmList.Add(result.Center);
                                }
                            }
                        }
                    }
                    if (FastPatternMatch(goldens[i], scaleGdnImage, ref resultList))
                    {
                        if (resultList.Count <= 0)
                        {
                            throw new Exception("Match failure : Golden image not have any match result.");
                        }
                        else
                        {
                            //Golden Top
                            if (i == 0)
                            {
                                foreach (PatternMatchResult result in resultList)
                                {
                                    resultGdnTopList.Add(result.Center);
                                }
                            }

                            //Golden Btm
                            if (i == 1)
                            {
                                foreach (PatternMatchResult result in resultList)
                                {
                                    resultGdnBtmList.Add(result.Center);
                                }
                            }
                        }
                    }
                }
                //match each point
                srcPointMatchList = FindMatchingPoints(resultSrcTopList, resultSrcBtmList, Config.PCBHeight, Config.MatchRegionRate, Config.Scale);
                gdnPointMatchList = FindMatchingPoints(resultGdnTopList, resultGdnBtmList, Config.PCBHeight, Config.MatchRegionRate, Config.Scale);

                //check PCB number
                if (srcPointMatchList.Count != gdnPointMatchList.Count)
                {
                    throw new ArgumentException("PCB Number not match. Source has " + srcPointMatchList.Count + 
                                                " PCBs. But Golden has " + gdnPointMatchList.Count + " PCBs.");
                }

                if (srcPointMatchList.Count == 0 || gdnPointMatchList.Count == 0)
                {
                    throw new ArgumentException("PCB Number not match. Please check Each PCB Height (pix) !");
                }

                //sort
                srcPointMatchList = srcPointMatchList.OrderBy(pt => pt.PointTop.Y).ToList();
                gdnPointMatchList = gdnPointMatchList.OrderBy(pt => pt.PointTop.Y).ToList();

                //resume scale
                srcPointMatchList = ScalePointMatches(srcPointMatchList, Config.Scale);
                gdnPointMatchList = ScalePointMatches(gdnPointMatchList, Config.Scale);

                //crop rough region and rotate and crop
                for (int i = 0; i < srcPointMatchList.Count; i++)
                {
                    PointMatch newPm = new PointMatch();
                    (cropPCB, newPm) = CropImageByPointMatch(SrcImage, srcPointMatchList[i], Config.ExpandCropY);

                    srcAlignImage = RotateAndCropImage(cropPCB, newPm, Config.ExpandTop, Config.ExpandBottom, Config.ExpandLeft, Config.ExpandRight);
                    tempSrcAlignImageArr[i] = srcAlignImage;
                }
                for (int i = 0; i < gdnPointMatchList.Count; i++)
                {
                    PointMatch newPm = new PointMatch();
                    (cropPCB, newPm) = CropImageByPointMatch(GdnImage, gdnPointMatchList[i], Config.ExpandCropY);

                    gdnAlignImage = RotateAndCropImage(cropPCB, newPm, Config.ExpandTop, Config.ExpandBottom, Config.ExpandLeft, Config.ExpandRight);
                    tempGdnAlignImageArr[i] = gdnAlignImage;
                }

                //scale image to same size
                if (tempSrcAlignImageArr.Length == tempGdnAlignImageArr.Length)
                {
                    Parallel.For(0, tempSrcAlignImageArr.Length, i =>
                    {
                        if (tempGdnAlignImageArr[i] != null)
                        {
                            OpenCvSharp.Size newSize = tempGdnAlignImageArr[i].Size();
                            Cv2.Resize(tempSrcAlignImageArr[i], tempSrcAlignImageArr[i], newSize, 0, 0, InterpolationFlags.Linear);
                        }

                    });
                }

                SrcAlignImageList = tempSrcAlignImageArr.ToList();
                GdnAlignImageList = tempGdnAlignImageArr.ToList();

                return true;
            }
            catch(Exception ex)
            {
                throw new Exception("Alignment Fail : " + ex.Message);
            }
            finally
            {
                TopGolden?.Dispose();
                BtmGolden?.Dispose();
                scaleSrcImage ?.Dispose();
                scaleGdnImage ?.Dispose();
                scaleTopGolden?.Dispose();
                scaleBtmGolden?.Dispose();
                cropPCB?.Dispose();
                foreach (Mat golden in goldens)
                {
                    golden?.Dispose();
                }
            }
        }

        public bool DoAutoAlignment(Mat SrcImage, Mat CprImage, ref Mat AlignSrcImage, ref Mat AlignCprImage, ref PatternMatchResult AlignResult)
        {
            List<Rect> allPatternRegion = new List<Rect>();
            Rect patternCropRoi = new Rect();
            List<PatternMatchResult> resultList = new List<PatternMatchResult>();
            Mat rotateCprImage = new Mat();
            Mat copySrcImage = new Mat(); 
            Mat copyCprImage = new Mat();
            Mat patternImage = new Mat();
            int patternCenterX = 0;
            int patternCenterY = 0;

            try
            {
                copySrcImage = SrcImage.Clone();
                copyCprImage = CprImage.Clone();

                allPatternRegion = GetAlignRegion(copySrcImage.Width, copySrcImage.Height);

                for (int i = 0; i < allPatternRegion.Count(); i++)
                {
                    Rect alignSrcCropRegion = new Rect(Config.Buffer, 
                                                       Config.Buffer, 
                                                       SrcImage.Width - Config.Buffer * 2,
                                                       SrcImage.Height - Config.Buffer * 2);

                    Rect patternSrcCropRegion = allPatternRegion[i];


                    AlignSrcImage = CropImage(copySrcImage, alignSrcCropRegion);
                    patternImage = CropImage(copySrcImage, patternSrcCropRegion);

                    if (FastPatternMatch(patternImage, copyCprImage, ref resultList))
                    {
                        patternCropRoi = allPatternRegion[i];
                        patternCenterX = Convert.ToInt32(patternCropRoi.X + patternCropRoi.Width / 2);
                        patternCenterY = Convert.ToInt32(patternCropRoi.Y + patternCropRoi.Height / 2);
                    }

                    if (resultList.Count != 1)
                    {
                        if (i == allPatternRegion.Count() - 1)
                        {
                            throw new Exception("Align Fail. No match any region.");
                        }
                        else continue;
                    }

                    AlignResult = resultList[0];
                    int matchCenterX = Convert.ToInt32(resultList[0].ptCenter.X);
                    int matchCenterY = Convert.ToInt32(resultList[0].ptCenter.Y);
                    double matchRotate = Math.Round(resultList[0].Angle, 3);

                    //save aligned cpr image
                    rotateCprImage = RotateImage(copyCprImage, matchCenterX, matchCenterY, -matchRotate);
                    Rect cprCrop = new Rect(Config.Buffer + matchCenterX - patternCenterX,
                                            Config.Buffer + matchCenterY - patternCenterY,
                                            CprImage.Width - Config.Buffer * 2,
                                            CprImage.Height - Config.Buffer * 2);

                    AlignCprImage = CropImage(rotateCprImage, cprCrop);

                    if (AlignCprImage == null)
                    {
                        if (i == allPatternRegion.Count() - 1)
                        {
                            throw new Exception("Align Fail. No match any region.");
                        }
                        else continue;
                    }
                    break;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Alignment Fail : " + ex.Message);
            }
            finally
            {
                rotateCprImage?.Dispose();
                resultList?.Clear();
                copySrcImage.Dispose();
                copyCprImage.Dispose();
                patternImage.Dispose();
            }
        }

        public bool DoInspection(Mat alignSrcImage, Mat alignCprImage, ref Bitmap resultMask)
        {
            Mat copyAlignSrcImage = new Mat();
            Mat copyAlignCprImage = new Mat();
            Bitmap resultStitch = new Bitmap(alignSrcImage.Width, alignSrcImage.Height);
            try
            {
                if (Core == null)
                {
                    throw new Exception("No change detection model.");
                }
                copyAlignSrcImage = alignSrcImage.Clone();
                copyAlignCprImage = alignCprImage.Clone();

                //fit image size to AI detection
                OpenCvSharp.Size newSize = new OpenCvSharp.Size(Config.AIInputSize * Config.CutNumWidth, Config.AIInputSize * Config.CutNumHeight);
                Cv2.Resize(copyAlignSrcImage, copyAlignSrcImage, newSize, 0, 0, InterpolationFlags.Linear);
                Cv2.Resize(copyAlignCprImage, copyAlignCprImage, newSize, 0, 0, InterpolationFlags.Linear);

                CutImage[] cutImages = ImageCutting(copyAlignSrcImage, copyAlignCprImage, Config.AIInputSize, Config.AIInputSize, Config.OverlapRate);
                ChangeDetection(Core, cutImages, Config.BatchSize, Config.CDThreshold);
                resultStitch = ImageStitching(cutImages, copyAlignSrcImage.Width, copyAlignSrcImage.Height);
                //save
                /*for (int i = 0; i < cutImages.Count(); i++)
                {
                    cutImages[i].ImageA.SaveImage(i.ToString() + "_OK.jpg");
                    cutImages[i].ImageB.SaveImage(i.ToString() + "_NG.jpg");
                    cutImages[i].Result.ToMat().SaveImage(i.ToString() + "_Result.jpg");
                }*/
                //resume result to original size
                resultMask = new Bitmap(alignSrcImage.Width, alignSrcImage.Height);
                using (Graphics graphics = Graphics.FromImage(resultMask))
                {
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.DrawImage(resultStitch, 0, 0, alignCprImage.Width, alignCprImage.Height);
                }
                return true;
            }
            catch(Exception ex)
            {
                throw new Exception("Inspection Fail : " + ex.Message);
            }
            finally
            {
                copyAlignSrcImage.Dispose();
                copyAlignCprImage.Dispose();
                resultStitch.Dispose();
            }
        }

        public bool DoOutputResult(Mat srcImage, Bitmap resultMask, int NumberPCB, ref Bitmap resultImage, ref List<Defect> defectList)
        {
            Mat copySrcImage = new Mat();
            Bitmap copyResultMask = null;
            try
            {
                copySrcImage = srcImage.Clone();
                copyResultMask = (Bitmap)resultMask.Clone();
                (resultImage, defectList) = DrawAndShowResult(copyResultMask, NumberPCB, copySrcImage);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Output Result Fail : " + ex.Message);
            }
            finally
            {
                copySrcImage.Dispose();
                copyResultMask.Dispose();
            }
        }
        
        public bool DoDisposeAIModel()
        {
            try
            {
                Core?.Dispose();
                return true;
            }
            catch(Exception ex)
            {
                throw new Exception("Dispose AI Model fail." + ex.Message);
            }
        }
        #endregion


        #region Algorithm
        private Mat RotateAndCropImage(Mat srcImage, PointMatch matchingPoints, int topExpand, int bottomExpand, int leftExpand, int rightExpand)
        {
            // 1. 計算旋轉角度
            double angle = CalculateRotationAngle(matchingPoints);

            // 2. 旋轉圖像
            Mat rotatedImage = RotateImage(srcImage, angle);

            // 3. 計算新的匹配點位置
            Point2f center = new Point2f(srcImage.Cols / 2f, srcImage.Rows / 2f);
            PointF rotatedPointTop = RotatePoint(matchingPoints.PointTop, center, -angle);
            PointF rotatedPointBtm = RotatePoint(matchingPoints.PointBtm, center, -angle);

            // 4. 計算裁剪區域
            int left = (int)Math.Min(rotatedPointTop.X, rotatedPointBtm.X) - leftExpand;
            int top = (int)Math.Min(rotatedPointTop.Y, rotatedPointBtm.Y) - topExpand;
            int right = (int)Math.Max(rotatedPointTop.X, rotatedPointBtm.X) + rightExpand;
            int bottom = (int)Math.Max(rotatedPointTop.Y, rotatedPointBtm.Y) + bottomExpand;

            // 確保裁剪區域在圖像範圍內
            left = Math.Max(0, left);
            top = Math.Max(0, top);
            right = Math.Min(rotatedImage.Cols - 1, right);
            bottom = Math.Min(rotatedImage.Rows - 1, bottom);

            // 5. 裁剪圖像
            Rect cropRect = new Rect(left, top, right - left, bottom - top);
            Mat croppedImage = new Mat(rotatedImage, cropRect);

            return croppedImage;
        }

        private bool FastPatternMatch(Mat patternImage, Mat compareImage,ref List<PatternMatchResult> resultList)
        {
            PatternMatchFinder finder = new PatternMatchFinder();
            Mat grayImageP = new Mat();
            Mat grayImageC = new Mat();

            try
            {
                grayImageP = patternImage.Clone();
                grayImageC = compareImage.Clone();

                if (patternImage.Channels() == 3) Cv2.CvtColor(grayImageP, grayImageP, ColorConversionCodes.BGR2GRAY);
                byte[] data1 = MatToByteArray(grayImageP);

                if (compareImage.Channels() == 3) Cv2.CvtColor(grayImageC, grayImageC, ColorConversionCodes.BGR2GRAY);
                byte[] data2 = MatToByteArray(grayImageC);

                MatchImage ptnImage = new MatchImage(data1, grayImageP.Channels(), grayImageP.Width, grayImageP.Height);
                MatchImage cprImage = new MatchImage(data2, grayImageC.Channels(), grayImageC.Width, grayImageC.Height);

                finder.MaxPos = Config.PCBNumber;
                finder.Score = Config.MatchMinScore;
                finder.ToleranceAngle = Config.ToleranceAngle;
                finder.MinReduceArea = Config.MinReduceArea;
                finder.MaxOverlap = Config.MaxOverlap;
                finder.LearnPattern(ptnImage);
                finder.Match(cprImage);
                resultList = finder.GetResult();

                ptnImage.Dispose();
                cprImage.Dispose();

                if (resultList.Count >= 1)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw new Exception("Fast Pattern Match fail" + ex.Message);
            }
            finally
            {
                finder.Dispose();
                grayImageP.Dispose();
                grayImageC.Dispose();
            }
        }

        private void ChangeDetection(ChangeDetectionModel core, CutImage[] cutimages, int batchSize, float threshold)
        {
            List<BrandyImage> outputs = new List<BrandyImage>();
            try
            {
                //if model is color than clone channel
                if (core.InputChannel == 3)
                {
                    Parallel.For(0, cutimages.Count(), j =>
                    {
                        Cv2.CvtColor(cutimages[j].ImageA, cutimages[j].ImageA, ColorConversionCodes.GRAY2BGR);
                        Cv2.CvtColor(cutimages[j].ImageB, cutimages[j].ImageB, ColorConversionCodes.GRAY2BGR);
                    });
                }

                Parallel.For(0, cutimages.Count(), j =>
                {
                    cutimages[j].floatImageA = MatToFloatArray(cutimages[j].ImageA);
                    cutimages[j].floatImageB = MatToFloatArray(cutimages[j].ImageB);
                });

                //batch inference
                int runBatchSize;
                int runTime = cutimages.Count() / batchSize;
                if (cutimages.Count() % batchSize != 0) runTime++;

                for (int epoch = 0; epoch < runTime; epoch++)
                {
                    if (epoch == runTime - 1)
                    {
                        runBatchSize = cutimages.Count() % batchSize;
                        if (runBatchSize == 0) runBatchSize = batchSize;
                    }
                    else
                    {
                        runBatchSize = batchSize;
                    }

                    float[] batchDataA = new float[cutimages[0].floatImageA.Length * runBatchSize];
                    float[] batchDataB = new float[cutimages[0].floatImageB.Length * runBatchSize];

                    Parallel.For(epoch * batchSize, epoch * batchSize + runBatchSize, i =>
                    {
                        Array.Copy(cutimages[i].floatImageA, 0, batchDataA, cutimages[i].floatImageA.Length * (i % batchSize), cutimages[i].floatImageA.Length);
                        Array.Copy(cutimages[i].floatImageB, 0, batchDataB, cutimages[i].floatImageB.Length * (i % batchSize), cutimages[i].floatImageB.Length);
                    });

                    core.BatchInference(batchDataA, batchDataB, runBatchSize);
                    outputs = core.GetOutputImage(threshold, runBatchSize);

                    Parallel.For(0, outputs.Count(), i =>
                    {
                        cutimages[epoch * batchSize + i].Result = outputs[i].Bitmap;
                    });

                    outputs.ForEach(x => x?.Dispose());
                    outputs.Clear();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Inference error : " + ex);
            }
            finally
            {

            }
        }
        #endregion


        #region Tools
        private (Mat, PointMatch) CropImageByPointMatch(Mat srcImage, PointMatch pointMatch, int expandY)
        {
            if (pointMatch == null)
            {
                throw new ArgumentNullException(nameof(pointMatch));
            }

            // 找出 Y 座標的最小值和最大值
            float minY = Math.Min(pointMatch.PointTop.Y, pointMatch.PointBtm.Y);
            float maxY = Math.Max(pointMatch.PointTop.Y, pointMatch.PointBtm.Y);

            // 向外擴展
            int top = Math.Max(0, (int)(minY - expandY));
            int bottom = Math.Min(srcImage.Height - 1, (int)(maxY + expandY));

            // 計算裁剪區域
            int height = bottom - top + 1;
            if (height > 32767) throw new Exception("Crop height is bigger than opencvshape support max height.");
            Rect cropRect = new Rect(0, top, srcImage.Width, height);

            // 裁剪圖像
            Mat croppedImage = new Mat(srcImage, cropRect);
            PointMatch newPm = new PointMatch();
            newPm.PointTop = new PointF(pointMatch.PointTop.X, pointMatch.PointTop.Y - top);
            newPm.PointBtm = new PointF(pointMatch.PointBtm.X, pointMatch.PointBtm.Y - top);
            return (croppedImage,newPm) ;
        }

        private List<PointMatch> ScalePointMatches(List<PointMatch> pointMatches, double scale)
        {
            List<PointMatch> resultList = new List<PointMatch>();
            foreach (var match in pointMatches)
            {
                PointMatch result = new PointMatch();
                // 縮放 Point1
                result.PointTop = new PointF(match.PointTop.X / (float)scale, match.PointTop.Y / (float)scale);

                // 縮放 Point2
                result.PointBtm = new PointF(match.PointBtm.X / (float)scale, match.PointBtm.Y / (float)scale);

                resultList.Add(result);
            }
            return resultList;
        }

        private double CalculateRotationAngle(PointMatch matchingPoints)
        {
            double angle = (Math.Atan2(matchingPoints.PointBtm.Y - matchingPoints.PointTop.Y,
                              matchingPoints.PointBtm.X - matchingPoints.PointTop.X) * 180 / Math.PI) - 90;
            return angle;
        }

        private Mat RotateImage(Mat src, double angle)
        {
            Point2f center = new Point2f(src.Cols / 2f, src.Rows / 2f);
            Mat rotationMatrix = Cv2.GetRotationMatrix2D(center, angle, 1.0);
            Mat rotated = new Mat();
            Cv2.WarpAffine(src, rotated, rotationMatrix, src.Size());
            return rotated;
        }

        private PointF RotatePoint(PointF point, Point2f center, double angleDegrees)
        {
            double angleRadians = angleDegrees * Math.PI / 180;
            float cosTheta = (float)Math.Cos(angleRadians);
            float sinTheta = (float)Math.Sin(angleRadians);

            PointF centered = new PointF(point.X - center.X, point.Y - center.Y);
            PointF rotated = new PointF(
                centered.X * cosTheta - centered.Y * sinTheta,
                centered.X * sinTheta + centered.Y * cosTheta
            );
            return new PointF(rotated.X + center.X, rotated.Y + center.Y);
        }

        private Mat ScaleImage(Mat image, double scaleRate)
        {
            Mat output = new Mat();
            try
            {
                OpenCvSharp.Size newSize = new OpenCvSharp.Size(image.Width * scaleRate, image.Height * scaleRate);
                Cv2.Resize(image, output, newSize, 0, 0, InterpolationFlags.Area);
                return output;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private List<Rect> GetAlignRegion(int imageWidth, int imageHeight)
        {
            List<Rect> allRegion = new List<Rect>();
            Rect firstRegion = new Rect(Config.Buffer, Config.Buffer, imageWidth - Config.Buffer * 2, imageHeight - Config.Buffer * 2);
            allRegion.Add(firstRegion);
            int interval = Convert.ToInt32(Config.AlignSearchRegionSize * Config.AlignSearchOverlap);

            for (int i = Config.Buffer; i+ Config.AlignSearchRegionSize <= imageWidth - Config.Buffer; i+= interval)
            {
                for (int j = Config.Buffer; j+ Config.AlignSearchRegionSize <= imageHeight - Config.Buffer; j+= interval)
                {
                    Rect region = new Rect(i,j, Config.AlignSearchRegionSize, Config.AlignSearchRegionSize);
                    allRegion.Add(region);
                }
            }
            return allRegion;
        }

        private List<PointMatch> FindMatchingPoints(List<PointF> resultTopList, List<PointF> resultBtmList, int PCBheight, double MatchRegionRate, double Scale)
        {
            List<PointMatch> matchingPoints = new List<PointMatch>();
            double tolerance = PCBheight * MatchRegionRate * Scale;
            double scaleHeight = PCBheight * Scale;
            for (int i = 0; i < resultTopList.Count; i++)
            {
                for (int j = 0; j < resultBtmList.Count; j++)
                {
                    float yDifference = resultBtmList[j].Y - resultTopList[i].Y;
                    if (Math.Abs(yDifference - scaleHeight) <= tolerance)
                    {
                        matchingPoints.Add(new PointMatch
                        {
                            PointTop = resultTopList[i],
                            PointBtm = resultBtmList[j]
                        });
                        break;
                    }
                }
            }
            return matchingPoints;
        }

        public Bitmap DrawResult(Bitmap mask, Mat srcImage)
        {
            Mat mMask = BitmapConverter.ToMat(mask);

            if (srcImage.Channels() == 1)
                Cv2.CvtColor(srcImage, srcImage, ColorConversionCodes.GRAY2BGR);
            if (mMask.Channels() == 4)
                Cv2.CvtColor(mMask, mMask, ColorConversionCodes.BGRA2GRAY); // 轉成灰階便於輪廓偵測

            // 形態學開運算：先侵蝕再膨脹，濾除小雜訊
            if (Config.Kernel % 2 == 0) Config.Kernel++;
            Mat morphKernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(Config.Kernel, Config.Kernel));
            Cv2.MorphologyEx(mMask, mMask, MorphTypes.Open, morphKernel);

            // 填紅色區域
            Mat redFilled = new Mat(srcImage.Size(), MatType.CV_8UC3, new Scalar(0, 0, 255));
            Mat result = srcImage.Clone();
            redFilled.CopyTo(result, mMask);

            // 找出輪廓
            Cv2.FindContours(mMask, out OpenCvSharp.Point[][] contours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);

            // 根據面積篩選並繪製輪廓
            foreach (var contour in contours)
            {
                double area = Cv2.ContourArea(contour);
                if (area >= Config.MinArea)
                {
                    Cv2.DrawContours(result, new[] { contour }, -1, new Scalar(0, 255, 0), Config.Thickness); // 綠色畫輪廓
                }
            }

            mMask.Dispose();
            redFilled.Dispose();
            return BitmapConverter.ToBitmap(result);
        }


        private List<Defect> ShowDefect(Bitmap mask, int NumberPCB)
        {
            List<Defect> defectList = new List<Defect>();
            Mat mMask = BitmapConverter.ToMat(mask);
            Mat binaryImage = new Mat(mMask.Width, mMask.Height, MatType.CV_8UC1);
            Cv2.CvtColor(mMask, binaryImage, ColorConversionCodes.BGR2GRAY);

            Cv2.FindContours(binaryImage,
                             out OpenCvSharp.Point[][] contours, out HierarchyIndex[] hierarchy,
                             RetrievalModes.External, ContourApproximationModes.ApproxSimple);

            for (int i = 0; i < contours.Length; i++)
            {
                Defect defect = new Defect();
                double area = Cv2.ContourArea(contours[i]);
                if (area > 0)
                {
                    Moments moments = Cv2.Moments(contours[i]);
                    double centerX = moments.M10 / moments.M00;
                    double centerY = moments.M01 / moments.M00;

                    Rect boundingRect = Cv2.BoundingRect(contours[i]);

                    defect.PosX = Convert.ToInt32(centerX);
                    defect.PosY = Convert.ToInt32(centerY);
                    defect.Area = Convert.ToInt32(area);
                    defect.Width = Convert.ToInt32(boundingRect.Width);
                    defect.Height = Convert.ToInt32(boundingRect.Height);
                }

                defectList.Add(defect);
            }
            return defectList;
        }
         
        private (Bitmap , List<Defect>) DrawAndShowResult(Bitmap mask, int NumberPCB, Mat srcImage)
        {
            Mat mMask = BitmapConverter.ToMat(mask);

            if (srcImage.Channels() == 1)
                Cv2.CvtColor(srcImage, srcImage, ColorConversionCodes.GRAY2BGR);
            if (mMask.Channels() == 4)
                Cv2.CvtColor(mMask, mMask, ColorConversionCodes.BGRA2GRAY); // 轉成灰階便於輪廓偵測

            // 形態學開運算：先侵蝕再膨脹，濾除小雜訊
            if (Config.Kernel % 2 == 0) Config.Kernel++;
            Mat morphKernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(Config.Kernel, Config.Kernel));
            Cv2.MorphologyEx(mMask, mMask, MorphTypes.Open, morphKernel);

            // 找出輪廓
            Cv2.FindContours(mMask, out OpenCvSharp.Point[][] contours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);
            Mat result = srcImage.Clone();
            List<Defect> defectList = new List<Defect>();

            // 根據面積篩選並繪製輪廓
            foreach (var contour in contours)
            {
                double area = Cv2.ContourArea(contour);

                if (area >= Config.MinArea)
                {
                    //畫圖
                    Cv2.DrawContours(result, new[] { contour }, -1, new Scalar(0, 255, 0), Config.Thickness); // 綠色畫輪廓
                    Cv2.DrawContours(result, new[] { contour }, -1, new Scalar(0, 0, 255), thickness: -1); // 紅色填滿

                    //計算defect
                    Defect defect = new Defect();
                    Moments moments = Cv2.Moments(contour);
                    double centerX = moments.M10 / moments.M00;
                    double centerY = moments.M01 / moments.M00;

                    Rect boundingRect = Cv2.BoundingRect(contour);

                    defect.PosX = Convert.ToInt32(centerX);
                    defect.PosY = Convert.ToInt32(centerY);
                    defect.Area = Convert.ToInt32(area);
                    defect.Width = Convert.ToInt32(boundingRect.Width);
                    defect.Height = Convert.ToInt32(boundingRect.Height);
                    defectList.Add(defect);
                }
            }

            mMask.Dispose();
            return (BitmapConverter.ToBitmap(result), defectList);
        }

        private Mat CropImage(Mat sourceImage, Rect cropArea)
        {
            // Create a Region of Interest (ROI) based on the crop area
            if (cropArea.X < 0 ||
                cropArea.Y < 0 ||
                cropArea.X + cropArea.Width > sourceImage.Width ||
                cropArea.Y + cropArea.Height > sourceImage.Height)
                return null;

            Mat croppedImage = new Mat(sourceImage, cropArea);
            return croppedImage;
        }

        private CutImage[] ImageCutting(Mat imageA, Mat imageB, int cutWidth, int cutHeight, double overlapRate)
        {
            if (imageA.Width != imageB.Width || imageA.Height != imageB.Height)
            {
                throw new Exception("ImageCutting Fail : input image A and B size not match.!");
            }
            
            int strideX = Convert.ToInt32(cutWidth * (1.0 - overlapRate));
            int strideY = Convert.ToInt32(cutHeight * (1.0 - overlapRate));
            int totalCutsWeight = (imageA.Width - cutWidth) / strideX + 1;
            int totalCutsHeight = (imageA.Height - cutHeight) / strideY + 1;
            CutImage[] cutImages = new CutImage[totalCutsWeight * totalCutsHeight];

            Parallel.For(0, totalCutsWeight, i =>
            {
                Parallel.For(0, totalCutsHeight, j =>
                {
                    int x = i * strideX;
                    int y = j * strideY;
                    CutImage cutImage = new CutImage
                    {
                        X = x,
                        Y = y,
                        ImageA = new Mat(imageA, new Rect(x, y, cutWidth, cutHeight)),
                        ImageB = new Mat(imageB, new Rect(x, y, cutWidth, cutHeight))
                    };
                    cutImages[j * totalCutsWeight + i] = cutImage;
                });
            });
            return cutImages;
        }

        private Bitmap ImageStitching(CutImage[] cutImages, int mapWidth, int mapHeight)
        {
            Bitmap stitchedBitmap = new Bitmap(mapWidth, mapHeight, PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(stitchedBitmap))
            {
                foreach (CutImage cutimage in cutImages)
                {
                    g.DrawImage(cutimage.Result, cutimage.X, cutimage.Y);
                }
            }
            return stitchedBitmap;
        }

        private Mat RotateImage(Mat image, int rotateX, int rotateY, double angle) 
        {
            // 設定旋轉中心點
            Point2f center = new Point2f(rotateY, rotateX);

            // 計算旋轉矩陣
            Mat rotationMatrix = Cv2.GetRotationMatrix2D(center, angle, 1.0);

            // 進行圖片旋轉
            Mat rotatedImage = new Mat();
            Cv2.WarpAffine(image, rotatedImage, rotationMatrix, image.Size());
            return rotatedImage;
        }

        private static float[] MatToFloatArray(Mat image)
        {
            Mat[] channels = image.Split();
            float[] input = new float[image.Rows * image.Cols * channels.Count()];
            Parallel.For(0, channels.Count(), i =>
            {
                byte[] byteArray = new byte[channels[i].Width * channels[i].Height];
                Marshal.Copy(channels[i].Data, byteArray, 0, byteArray.Length);
                float[] floatMat = byteArray.Select(x => (float)x).ToArray();
                Array.Copy(floatMat, 0, input, channels[i].Width * channels[i].Height * i, channels[i].Width * channels[i].Height);
            });
            return input;
        }

        private byte[] MatToByteArray(Mat image)
        {
            byte[] data = new byte[image.Rows * image.Cols * image.Channels()];
            Marshal.Copy(image.Data, data, 0, image.Rows * image.Cols * image.Channels());
            return data;
        }
        #endregion
    }
}
