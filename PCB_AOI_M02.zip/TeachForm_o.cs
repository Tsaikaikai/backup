using Brandy;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using PatternMatch;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace PCB_AOI
{
    public partial class TeachForm : Form
    {
        #region Initial
        public bool SaveCrop;
        public Mat SrcImage;
        public Mat CprImage;
        public List<Mat> AlignSrcImageList = new List<Mat>();
        public List<Mat> AlignCprImageList = new List<Mat>();

        public int PatternCenterX;
        public int PatternCenterY;
        public int MatchCenterX;
        public int MatchCenterY;
        public double MatchRotate;
        public double MatchScore;

        public int DetectSize;
        public ChangeDetectionModel core;

        PCBAlgorithm pcbAlgorithm = new PCBAlgorithm();
        string ConfigPath = "./AlgorithmConfig.xml";

        public string SrcImagePath;
        public string CprImagePath;
        public string PatternPath;

        // result 根目錄（子資料夾依時間戳命名）
        public string ResultPath = ".\\result\\";
        public string AlignPath  = ".\\align\\";

        public class CutImage : IDisposable
        {
            public Mat ImageA;
            public Mat ImageB;
            public float[] floatImageA;
            public float[] floatImageB;
            public int X;
            public int Y;
            public Bitmap Result;
            bool _disposed;

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            ~CutImage() { Dispose(); }
            protected virtual void Dispose(bool disposing)
            {
                if (_disposed) return;
                if (disposing)
                {
                    ImageA?.Dispose();
                    ImageB?.Dispose();
                }
                _disposed = true;
            }
        }
        #endregion

        #region Sync Pan/Zoom

        private float  _syncScale  = 1.0f;
        private PointF _syncOffset = PointF.Empty;

        private bool   _isDragging      = false;
        private System.Drawing.Point _dragStartMouse;
        private PointF _dragStartOffset;

        private Image _imgGdn;
        private Image _imgDet;
        private Image _imgRst;
        private PictureBox[] _syncBoxes;

        private void InitSyncViewer()
        {
            _syncBoxes = new PictureBox[]
            {
                pictureBox_alignGdn,
                pictureBox_alignDet,
                pictureBox_alignRst
            };

            foreach (var pb in _syncBoxes)
            {
                pb.SizeMode     = PictureBoxSizeMode.Normal;
                pb.Paint       += SyncPb_Paint;
                pb.MouseDown   += SyncPb_MouseDown;
                pb.MouseMove   += SyncPb_MouseMove;
                pb.MouseUp     += SyncPb_MouseUp;
                pb.MouseWheel  += SyncPb_MouseWheel;
                pb.DoubleClick += SyncPb_DoubleClick;
                pb.MouseEnter  += (s, e) => ((Control)s).Focus();
            }
        }

        private void SyncPb_Paint(object sender, PaintEventArgs e)
        {
            Image img = null;
            if      (sender == pictureBox_alignGdn) img = _imgGdn;
            else if (sender == pictureBox_alignDet) img = _imgDet;
            else if (sender == pictureBox_alignRst) img = _imgRst;
            if (img == null) return;

            e.Graphics.InterpolationMode =
                System.Drawing.Drawing2D.InterpolationMode.Bilinear;
            e.Graphics.DrawImage(img,
                _syncOffset.X, _syncOffset.Y,
                img.Width  * _syncScale,
                img.Height * _syncScale);
        }

        private void SyncPb_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _isDragging      = true;
                _dragStartMouse  = PointToClient(Cursor.Position);
                _dragStartOffset = _syncOffset;
                foreach (var pb in _syncBoxes) pb.Cursor = Cursors.SizeAll;
            }
        }

        private void SyncPb_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isDragging) return;
            var cur = PointToClient(Cursor.Position);
            _syncOffset = new PointF(
                _dragStartOffset.X + (cur.X - _dragStartMouse.X),
                _dragStartOffset.Y + (cur.Y - _dragStartMouse.Y));
            InvalidateSyncBoxes();
        }

        private void SyncPb_MouseUp(object sender, MouseEventArgs e)
        {
            _isDragging = false;
            foreach (var pb in _syncBoxes) pb.Cursor = Cursors.Hand;
        }

        private void SyncPb_MouseWheel(object sender, MouseEventArgs e)
        {
            var pb = (PictureBox)sender;
            var mouseInBox = pb.PointToClient(Cursor.Position);
            float newScale = Math.Max(0.05f, Math.Min(20.0f,
                _syncScale * (e.Delta > 0 ? 1.1f : 0.9f)));
            float ratio = newScale / _syncScale;
            _syncOffset = new PointF(
                mouseInBox.X - (mouseInBox.X - _syncOffset.X) * ratio,
                mouseInBox.Y - (mouseInBox.Y - _syncOffset.Y) * ratio);
            _syncScale = newScale;
            InvalidateSyncBoxes();
        }

        private void SyncPb_DoubleClick(object sender, EventArgs e) => ResetSyncView();

        private void ResetSyncView()
        {
            _syncScale  = 1.0f;
            _syncOffset = PointF.Empty;
            InvalidateSyncBoxes();
        }

        private void InvalidateSyncBoxes()
        {
            foreach (var pb in _syncBoxes) pb.Invalidate();
        }

        /// <summary>設定三張圖並重置視角。傳入的 Image 物件由此方法接管生命週期。</summary>
        private void LoadImagesToViewer(Image gdn, Image det, Image rst)
        {
            _imgGdn?.Dispose(); _imgGdn = gdn;
            _imgDet?.Dispose(); _imgDet = det;
            _imgRst?.Dispose(); _imgRst = rst;
            ResetSyncView();
        }

        #endregion

        #region Result List

        private Timer _refreshTimer;
        private const int RefreshIntervalMs = 2_000; // 每 2 秒自動重整

        private void InitResultList()
        {
            RefreshResultList();

            _refreshTimer = new Timer { Interval = RefreshIntervalMs };
            _refreshTimer.Tick += (s, e) => RefreshResultList();
            _refreshTimer.Start();
        }

        /// <summary>掃描 result 根目錄，將所有子資料夾名稱（最新排最上）填入 ListBox。</summary>
        private void RefreshResultList()
        {
            if (!Directory.Exists(ResultPath)) return;

            var dirs = Directory.GetDirectories(ResultPath)
                                .Select(Path.GetFileName)
                                .OrderByDescending(n => n)
                                .ToArray();

            string selected = listBox_resultList.SelectedItem?.ToString();

            listBox_resultList.BeginUpdate();
            listBox_resultList.Items.Clear();
            foreach (var d in dirs)
                listBox_resultList.Items.Add(d);

            if (selected != null)
            {
                int idx = listBox_resultList.Items.IndexOf(selected);
                if (idx >= 0) listBox_resultList.SelectedIndex = idx;
            }
            listBox_resultList.EndUpdate();
        }

        /// <summary>點選 ListBox 項目 → 從該資料夾讀取圖片並顯示。</summary>
        private void listBox_resultList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_resultList.SelectedItem == null) return;

            string folderName = listBox_resultList.SelectedItem.ToString();
            string folderPath = Path.Combine(ResultPath, folderName);
            if (!Directory.Exists(folderPath)) return;

            string gdnFile = Path.Combine(folderPath, "0_gdn.jpg");
            string detFile = Path.Combine(folderPath, "0_det.jpg");
            string rstFile = Path.Combine(folderPath, "0_rst.jpg");

            try
            {
                Image gdn = File.Exists(gdnFile) ? LoadImageUnlocked(gdnFile) : null;
                Image det = File.Exists(detFile) ? LoadImageUnlocked(detFile) : null;
                Image rst = File.Exists(rstFile) ? LoadImageUnlocked(rstFile) : null;
                LoadImagesToViewer(gdn, det, rst);
            }
            catch (Exception ex)
            {
                MessageBox.Show("讀取結果圖片失敗：" + ex.Message);
            }
        }

        /// <summary>用 MemoryStream 讀取，避免 Image.FromFile 鎖定檔案。</summary>
        private static Image LoadImageUnlocked(string path)
        {
            byte[] bytes = File.ReadAllBytes(path);
            using (var ms = new MemoryStream(bytes))
                return Image.FromStream(ms);
        }

        #endregion

        public TeachForm()
        {
            InitializeComponent();
            buttonDetect.Enabled    = false;
            buttonFreeModel.Enabled = false;
            if (!Directory.Exists(ResultPath)) Directory.CreateDirectory(ResultPath);
            if (!Directory.Exists(AlignPath))  Directory.CreateDirectory(AlignPath);

            InitSyncViewer();
            InitResultList();

            listBox_resultList.SelectedIndexChanged += listBox_resultList_SelectedIndexChanged;
        }

        private void TeachForm_Load(object sender, EventArgs e)
        {
            pcbAlgorithm.LoadConfig(ConfigPath);
            txb_recipePath.Text = ConfigPath;
        }

        #region UI Control
        private bool IsImageFile(string filename)
        {
            string ext = Path.GetExtension(filename);
            return ext.Equals(".jpg",  StringComparison.OrdinalIgnoreCase) ||
                   ext.Equals(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                   ext.Equals(".png",  StringComparison.OrdinalIgnoreCase) ||
                   ext.Equals(".bmp",  StringComparison.OrdinalIgnoreCase) ||
                   ext.Equals(".tiff", StringComparison.OrdinalIgnoreCase) ||
                   ext.Equals(".tif",  StringComparison.OrdinalIgnoreCase);
        }

        private void pictureboxSrc_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
        }
        private void pictureboxSrc_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                SrcImagePath = files[0];
                if (IsImageFile(SrcImagePath))
                {
                    pictureboxSrc.Image = Image.FromFile(SrcImagePath);
                    SrcImage = Cv2.ImRead(SrcImagePath, ImreadModes.Grayscale);
                    pictureboxCpr.Invalidate();
                    labelPCBnum.Text = "---";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        private void pictureboxCpr_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
        }
        private void pictureboxCpr_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                CprImagePath = files[0];
                if (IsImageFile(CprImagePath))
                {
                    pictureboxCpr.Image = Image.FromFile(CprImagePath);
                    CprImage = Cv2.ImRead(CprImagePath, ImreadModes.Grayscale);
                    pictureboxCpr.Invalidate();
                    labelPCBnum.Text = "---";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        #endregion

        #region Tool
        private void ShowMatchFail()
        {
            labelPCBnum.Text = "match fail";
            labelAlignExeTime.Text = "match fail";
            pictureboxCpr.Invalidate();
        }
        #endregion

        private void buttonAutoAlign_Click(object sender, EventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null) return;
            PatternMatchResult alignResult = new PatternMatchResult();
            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                if (pcbAlgorithm.DoPCBAlignment(SrcImage, CprImage, ref AlignSrcImageList, ref AlignCprImageList))
                {
                    stopwatch.Stop();
                    labelAlignExeTime.Text = ((int)stopwatch.Elapsed.TotalMilliseconds).ToString() + " ms";
                    string folderPath = "./Align_Result";
                    Directory.CreateDirectory(folderPath);
                    labelPCBnum.Text = "Find " + AlignSrcImageList.Count.ToString() + " PCB(s)";
                    for (int i = 0; i < AlignSrcImageList.Count; i++)
                    {
                        if (AlignSrcImageList[i] == null) continue;
                        AlignSrcImageList[i].SaveImage(Path.Combine(folderPath, $"Golden_{i + 1}.bmp"));
                    }
                    for (int i = 0; i < AlignCprImageList.Count; i++)
                    {
                        if (AlignCprImageList[i] == null) continue;
                        AlignCprImageList[i].SaveImage(Path.Combine(folderPath, $"Source_{i + 1}.bmp"));
                    }
                }
            }
            catch (Exception ex)
            {
                ShowMatchFail();
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonLoadModel_Click(object sender, EventArgs e)
        {
            try
            {
                if (pcbAlgorithm.DoLoadAIModel())
                {
                    buttonLoadModel.BackColor = Color.LimeGreen;
                    buttonDetect.Enabled      = true;
                    buttonFreeModel.Enabled   = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load Model Fail : " + ex.Message);
            }
        }

        private void buttonDetect_Click(object sender, EventArgs e)
        {
            Bitmap[] masks   = new Bitmap[AlignSrcImageList.Count];
            Bitmap[] results = new Bitmap[AlignSrcImageList.Count];
            List<PCBAlgorithm.Defect> defectList      = new List<PCBAlgorithm.Defect>();
            List<PCBAlgorithm.Defect> totalDefectList = new List<PCBAlgorithm.Defect>();
            Stopwatch sw = new Stopwatch();
            try
            {
                if (AlignSrcImageList == null || AlignCprImageList == null) return;

                sw.Start();
                for (int i = 0; i < AlignSrcImageList.Count; i++)
                    pcbAlgorithm.DoInspection(AlignSrcImageList[i], AlignCprImageList[i], ref masks[i]);
                sw.Stop();

                for (int i = 0; i < AlignCprImageList.Count; i++)
                {
                    if (pcbAlgorithm.DoOutputResult(AlignCprImageList[i], masks[i], i, ref results[i], ref defectList))
                        totalDefectList.AddRange(defectList);
                }

                labelDefectNum.Text = totalDefectList.Count().ToString();
                labelTotalTime.Text = ((int)sw.Elapsed.TotalMilliseconds).ToString() + " ms";

                // ── 以時間戳（精細到秒）建立子資料夾 ──────────────────────────
                // 範例：result\20250519_143027\
                string timestamp  = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string saveFolder = Path.Combine(ResultPath, timestamp);
                Directory.CreateDirectory(saveFolder);

                for (int i = 0; i < AlignSrcImageList.Count; i++)
                {
                    // gdn = Golden (AlignCprImageList)
                    // det = Source/Detect (AlignSrcImageList)
                    // rst = Result with defect overlay
                    AlignCprImageList[i].SaveImage(Path.Combine(saveFolder, $"{i}_gdn.jpg"));
                    AlignSrcImageList[i].SaveImage(Path.Combine(saveFolder, $"{i}_det.jpg"));
                    results[i].Save(          Path.Combine(saveFolder, $"{i}_rst.jpg"));
                }

                // 重整 ListBox，並選取剛存的項目
                RefreshResultList();
                int newIdx = listBox_resultList.Items.IndexOf(timestamp);
                if (newIdx >= 0) listBox_resultList.SelectedIndex = newIdx;

                // 直接用記憶體中的 Bitmap 顯示，不需再從磁碟讀
                LoadImagesToViewer(
                    AlignCprImageList[0].ToBitmap(),
                    AlignSrcImageList[0].ToBitmap(),
                    results[0]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                foreach (Bitmap mask in masks) mask?.Dispose();
                defectList?.Clear();
                totalDefectList?.Clear();
            }
        }

        private void buttonFreeModel_Click(object sender, EventArgs e)
        {
            if (pcbAlgorithm.DoDisposeAIModel())
            {
                buttonDetect.Enabled      = false;
                buttonLoadModel.Enabled   = true;
                buttonLoadModel.BackColor = Color.White;
                buttonFreeModel.Enabled   = false;
            }
        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            FormBootConfig frm = new FormBootConfig();
            frm.SetConfig(ConfigPath);
            frm.ShowDialog(this);
            try { pcbAlgorithm.LoadConfig(ConfigPath); }
            catch (Exception ex) { throw ex; }
        }
    }
}
