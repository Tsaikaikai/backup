﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace PCB_AOI
{
    public class CAlgorithmConfig
    {
        #region Initial
        public CAlgorithmConfig()
        {

        }

        public bool WriteXmlConfig(string configFileName)
        {
            try
            {
                if (!File.Exists(configFileName))
                {
                    configFileName = configFileName.Replace("\\\\", "/").Replace("\\", "/");
                    int index = configFileName.LastIndexOf("/");
                    Directory.CreateDirectory(configFileName.Substring(0, index));
                }
                // Write config value into xml.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Create))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(CAlgorithmConfig));
                    xmlSerializer.Serialize(fileStream, this);
                    fileStream.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"[WriteXmlConfig]{ex.Message}");
            }
        }

        public CAlgorithmConfig ReadXmlConfig(string configFileName)
        {
            CAlgorithmConfig tempConfig;
            try
            {
                // If file does not exists, create default one.
                if (!File.Exists(configFileName))
                    this.WriteXmlConfig(configFileName);

                // Open and read a crypto-xml file.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Open))
                using (XmlTextReader xmlTextReader = new XmlTextReader(fileStream))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(CAlgorithmConfig));
                    tempConfig = (CAlgorithmConfig)xmlSerializer.Deserialize(xmlTextReader);

                    xmlTextReader.Close();
                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"[ReadXmlConfig]{ex.Message}");
            }

            return tempConfig;
        }
        #endregion

        #region Base 
        [Category("0.Base"), DisplayName("Image Width (pix)")]
        public int ImageWidth { get; set; }

        [Category("0.Base"), DisplayName("Image Height (pix)")]
        public int ImageHeight { get; set; }

        [Category("0.Base"), DisplayName("PCB Number (int)")]
        public int PCBNumber { get; set; }

        [Category("0.Base"), DisplayName("Each PCB Height (pix)")]
        public int PCBHeight { get; set; }
        #endregion

        #region 1.Alignment
        [Category("1.Alignment"), DisplayName("Top Align Golden Path")]
        public string TopAlignGoldenPath { get; set; }

        [Category("1.Alignment"), DisplayName("Scale Image (double)")]
        public double Scale { get; set; }

        [Category("1.Alignment"), DisplayName("Bottom Align Golden Path")]
        public string BtmAlignGoldenPath { get; set; }

        [Category("1.Alignment"), DisplayName("Match Region Rate of PCB Height (double)")]
        public double MatchRegionRate { get; set; }

        [Category("1.Alignment"), DisplayName("Search Region Size (pix)")]
        public int AlignSearchRegionSize { get; set; }

        [Category("1.Alignment"), DisplayName("Expand Top (pix)")]
        public int ExpandTop { get; set; }

        [Category("1.Alignment"), DisplayName("Expand Right (pix)")]
        public int ExpandRight { get; set; }

        [Category("1.Alignment"), DisplayName("Expand Bottom (pix)")]
        public int ExpandBottom { get; set; }

        [Category("1.Alignment"), DisplayName("Expand Left (pix)")]
        public int ExpandLeft { get; set; }

        [Category("1.Alignment"), DisplayName("Expand Before Crop Y (pix)")]
        public int ExpandCropY { get; set; }

        [Category("1.Alignment"), DisplayName("Search Overlap (pix)")]
        public double AlignSearchOverlap { get; set; }

        [Category("1.Alignment"), DisplayName("ToleranceAngle (int)")]
        public int ToleranceAngle { get; set; }

        [Category("1.Alignment"), DisplayName("Score (0-1)")]
        public double MatchMinScore { get; set; }

        [Category("1.Alignment"), DisplayName("MinReduceArea (int)")]
        public int MinReduceArea { get; set; }

        [Category("1.Alignment"), DisplayName("Max Overlap (double)")]
        public double MaxOverlap { get; set; }

        [Category("1.Alignment"), DisplayName("Buffer (pix)")]
        public int Buffer { get; set; }
        #endregion

        #region 2.Inspection

        [Category("2.Inspection"), DisplayName("AI Model Path")]
        public string AIModelPath { get; set; }

        [Category("2.Inspection"), DisplayName("UseGPU")]
        public int UseGPU { get; set; }

        [Category("2.Inspection"), DisplayName("Batch Size")]
        public int BatchSize { get; set; }

        [Category("2.Inspection"), DisplayName("AI Input Size")]
        public int AIInputSize { get; set; }

        [Category("2.Inspection"), DisplayName("Overlap Rate")]
        public double OverlapRate { get; set; }

        [Category("2.Inspection"), DisplayName("CD Threshold")]
        public float CDThreshold { get; set; }

        [Category("2.Inspection"), DisplayName("Cut Height Num of a PCB")]
        public int CutNumHeight { get; set; }

        [Category("2.Inspection"), DisplayName("Cut Width Num of a PCB")]
        public int CutNumWidth { get; set; }

        [Category("2.Inspection"), DisplayName("Minumun Area")]
        public int MinArea { get; set; }

        [Category("2.Inspection"), DisplayName("Morphogropy Kernel")]
        public int Kernel { get; set; }

        [Category("2.Inspection"), DisplayName("Draw Edge Thickness")]
        public int Thickness { get; set; }

        #endregion
    }
}
