﻿
namespace PCB_AOI
{
    partial class TeachForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureboxCpr = new System.Windows.Forms.PictureBox();
            this.pictureboxSrc = new System.Windows.Forms.PictureBox();
            this.labelPCBnum = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelAlignExeTime = new System.Windows.Forms.Label();
            this.pictureBox_alignRst = new System.Windows.Forms.PictureBox();
            this.buttonLoadModel = new System.Windows.Forms.Button();
            this.buttonFreeModel = new System.Windows.Forms.Button();
            this.labelTotalTime = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_setFront = new System.Windows.Forms.Button();
            this.txb_recipePathFront = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label_modelname = new System.Windows.Forms.Label();
            this.label_inputsize = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelDefectNum = new System.Windows.Forms.Label();
            this.pictureBox_alignDet = new System.Windows.Forms.PictureBox();
            this.pictureBox_alignGdn = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.listBox_resultList = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_runFront = new System.Windows.Forms.Button();
            this.btn_runBack = new System.Windows.Forms.Button();
            this.txb_recipePathBack = new System.Windows.Forms.TextBox();
            this.btn_setBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxCpr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignRst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignDet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignGdn)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureboxCpr
            // 
            this.pictureboxCpr.AllowDrop = true;
            this.pictureboxCpr.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureboxCpr.Location = new System.Drawing.Point(268, 117);
            this.pictureboxCpr.Name = "pictureboxCpr";
            this.pictureboxCpr.Size = new System.Drawing.Size(213, 562);
            this.pictureboxCpr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureboxCpr.TabIndex = 1;
            this.pictureboxCpr.TabStop = false;
            this.pictureboxCpr.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureboxCpr_DragDrop);
            this.pictureboxCpr.DragEnter += new System.Windows.Forms.DragEventHandler(this.pictureboxCpr_DragEnter);
            // 
            // pictureboxSrc
            // 
            this.pictureboxSrc.AllowDrop = true;
            this.pictureboxSrc.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureboxSrc.Location = new System.Drawing.Point(24, 117);
            this.pictureboxSrc.Name = "pictureboxSrc";
            this.pictureboxSrc.Size = new System.Drawing.Size(213, 562);
            this.pictureboxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureboxSrc.TabIndex = 2;
            this.pictureboxSrc.TabStop = false;
            this.pictureboxSrc.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureboxSrc_DragDrop);
            this.pictureboxSrc.DragEnter += new System.Windows.Forms.DragEventHandler(this.pictureboxSrc_DragEnter);
            // 
            // labelPCBnum
            // 
            this.labelPCBnum.AutoSize = true;
            this.labelPCBnum.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelPCBnum.Location = new System.Drawing.Point(251, 797);
            this.labelPCBnum.Name = "labelPCBnum";
            this.labelPCBnum.Size = new System.Drawing.Size(33, 27);
            this.labelPCBnum.TabIndex = 14;
            this.labelPCBnum.Text = "---";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(246, 844);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 27);
            this.label5.TabIndex = 19;
            this.label5.Text = "Align Time : ";
            // 
            // labelAlignExeTime
            // 
            this.labelAlignExeTime.AutoSize = true;
            this.labelAlignExeTime.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelAlignExeTime.Location = new System.Drawing.Point(371, 844);
            this.labelAlignExeTime.Name = "labelAlignExeTime";
            this.labelAlignExeTime.Size = new System.Drawing.Size(60, 27);
            this.labelAlignExeTime.TabIndex = 20;
            this.labelAlignExeTime.Text = "NULL";
            // 
            // pictureBox_alignRst
            // 
            this.pictureBox_alignRst.AllowDrop = true;
            this.pictureBox_alignRst.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox_alignRst.Location = new System.Drawing.Point(1295, 117);
            this.pictureBox_alignRst.Name = "pictureBox_alignRst";
            this.pictureBox_alignRst.Size = new System.Drawing.Size(359, 867);
            this.pictureBox_alignRst.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_alignRst.TabIndex = 24;
            this.pictureBox_alignRst.TabStop = false;
            // 
            // buttonLoadModel
            // 
            this.buttonLoadModel.BackColor = System.Drawing.Color.White;
            this.buttonLoadModel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonLoadModel.Location = new System.Drawing.Point(24, 699);
            this.buttonLoadModel.Name = "buttonLoadModel";
            this.buttonLoadModel.Size = new System.Drawing.Size(168, 51);
            this.buttonLoadModel.TabIndex = 25;
            this.buttonLoadModel.Text = "Load Model";
            this.buttonLoadModel.UseVisualStyleBackColor = false;
            this.buttonLoadModel.Click += new System.EventHandler(this.buttonLoadModel_Click);
            // 
            // buttonFreeModel
            // 
            this.buttonFreeModel.BackColor = System.Drawing.Color.White;
            this.buttonFreeModel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonFreeModel.Location = new System.Drawing.Point(24, 767);
            this.buttonFreeModel.Name = "buttonFreeModel";
            this.buttonFreeModel.Size = new System.Drawing.Size(168, 51);
            this.buttonFreeModel.TabIndex = 34;
            this.buttonFreeModel.Text = "Free Model";
            this.buttonFreeModel.UseVisualStyleBackColor = false;
            this.buttonFreeModel.Click += new System.EventHandler(this.buttonFreeModel_Click);
            // 
            // labelTotalTime
            // 
            this.labelTotalTime.AutoSize = true;
            this.labelTotalTime.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelTotalTime.Location = new System.Drawing.Point(371, 938);
            this.labelTotalTime.Name = "labelTotalTime";
            this.labelTotalTime.Size = new System.Drawing.Size(60, 27);
            this.labelTotalTime.TabIndex = 38;
            this.labelTotalTime.Text = "NULL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(227, 938);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 27);
            this.label12.TabIndex = 37;
            this.label12.Text = "Inspect Time : ";
            // 
            // btn_setFront
            // 
            this.btn_setFront.BackColor = System.Drawing.Color.White;
            this.btn_setFront.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_setFront.Location = new System.Drawing.Point(24, 12);
            this.btn_setFront.Name = "btn_setFront";
            this.btn_setFront.Size = new System.Drawing.Size(133, 32);
            this.btn_setFront.TabIndex = 45;
            this.btn_setFront.Text = "Set Front";
            this.btn_setFront.UseVisualStyleBackColor = false;
            this.btn_setFront.Click += new System.EventHandler(this.btn_setFront_Click);
            // 
            // txb_recipePathFront
            // 
            this.txb_recipePathFront.Location = new System.Drawing.Point(163, 17);
            this.txb_recipePathFront.Name = "txb_recipePathFront";
            this.txb_recipePathFront.Size = new System.Drawing.Size(888, 22);
            this.txb_recipePathFront.TabIndex = 46;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.Location = new System.Drawing.Point(251, 750);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 27);
            this.label6.TabIndex = 48;
            this.label6.Text = "Input Size : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(227, 703);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 27);
            this.label7.TabIndex = 49;
            this.label7.Text = "Model Name : ";
            // 
            // label_modelname
            // 
            this.label_modelname.AutoSize = true;
            this.label_modelname.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_modelname.Location = new System.Drawing.Point(371, 703);
            this.label_modelname.Name = "label_modelname";
            this.label_modelname.Size = new System.Drawing.Size(60, 27);
            this.label_modelname.TabIndex = 50;
            this.label_modelname.Text = "NULL";
            // 
            // label_inputsize
            // 
            this.label_inputsize.AutoSize = true;
            this.label_inputsize.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_inputsize.Location = new System.Drawing.Point(371, 750);
            this.label_inputsize.Name = "label_inputsize";
            this.label_inputsize.Size = new System.Drawing.Size(60, 27);
            this.label_inputsize.TabIndex = 51;
            this.label_inputsize.Text = "NULL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(55, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 24);
            this.label1.TabIndex = 52;
            this.label1.Text = "Golden Image";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(302, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 24);
            this.label2.TabIndex = 53;
            this.label2.Text = "Detection Image";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(204, 891);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 27);
            this.label3.TabIndex = 54;
            this.label3.Text = "Defect Number : ";
            // 
            // labelDefectNum
            // 
            this.labelDefectNum.AutoSize = true;
            this.labelDefectNum.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelDefectNum.Location = new System.Drawing.Point(371, 891);
            this.labelDefectNum.Name = "labelDefectNum";
            this.labelDefectNum.Size = new System.Drawing.Size(60, 27);
            this.labelDefectNum.TabIndex = 55;
            this.labelDefectNum.Text = "NULL";
            // 
            // pictureBox_alignDet
            // 
            this.pictureBox_alignDet.AllowDrop = true;
            this.pictureBox_alignDet.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox_alignDet.Location = new System.Drawing.Point(913, 117);
            this.pictureBox_alignDet.Name = "pictureBox_alignDet";
            this.pictureBox_alignDet.Size = new System.Drawing.Size(359, 867);
            this.pictureBox_alignDet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_alignDet.TabIndex = 56;
            this.pictureBox_alignDet.TabStop = false;
            // 
            // pictureBox_alignGdn
            // 
            this.pictureBox_alignGdn.AllowDrop = true;
            this.pictureBox_alignGdn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox_alignGdn.Location = new System.Drawing.Point(529, 117);
            this.pictureBox_alignGdn.Name = "pictureBox_alignGdn";
            this.pictureBox_alignGdn.Size = new System.Drawing.Size(359, 867);
            this.pictureBox_alignGdn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_alignGdn.TabIndex = 57;
            this.pictureBox_alignGdn.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(637, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 24);
            this.label4.TabIndex = 58;
            this.label4.Text = "Aligned Golden";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(1010, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(173, 24);
            this.label8.TabIndex = 59;
            this.label8.Text = "Aligned Detection";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(1413, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 24);
            this.label9.TabIndex = 60;
            this.label9.Text = "Aligned Result";
            // 
            // listBox_resultList
            // 
            this.listBox_resultList.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox_resultList.FormattingEnabled = true;
            this.listBox_resultList.ItemHeight = 20;
            this.listBox_resultList.Location = new System.Drawing.Point(1691, 117);
            this.listBox_resultList.Name = "listBox_resultList";
            this.listBox_resultList.Size = new System.Drawing.Size(187, 864);
            this.listBox_resultList.TabIndex = 61;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(1732, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 24);
            this.label10.TabIndex = 62;
            this.label10.Text = "Result List";
            // 
            // btn_runFront
            // 
            this.btn_runFront.BackColor = System.Drawing.Color.White;
            this.btn_runFront.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_runFront.Location = new System.Drawing.Point(24, 844);
            this.btn_runFront.Name = "btn_runFront";
            this.btn_runFront.Size = new System.Drawing.Size(168, 51);
            this.btn_runFront.TabIndex = 63;
            this.btn_runFront.Text = "Run (Front)";
            this.btn_runFront.UseVisualStyleBackColor = false;
            this.btn_runFront.Click += new System.EventHandler(this.btn_run_Click);
            // 
            // btn_runBack
            // 
            this.btn_runBack.BackColor = System.Drawing.Color.White;
            this.btn_runBack.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_runBack.Location = new System.Drawing.Point(24, 914);
            this.btn_runBack.Name = "btn_runBack";
            this.btn_runBack.Size = new System.Drawing.Size(168, 51);
            this.btn_runBack.TabIndex = 64;
            this.btn_runBack.Text = "Run (Back)";
            this.btn_runBack.UseVisualStyleBackColor = false;
            this.btn_runBack.Click += new System.EventHandler(this.btn_runBack_Click);
            // 
            // txb_recipePathBack
            // 
            this.txb_recipePathBack.Location = new System.Drawing.Point(163, 55);
            this.txb_recipePathBack.Name = "txb_recipePathBack";
            this.txb_recipePathBack.Size = new System.Drawing.Size(888, 22);
            this.txb_recipePathBack.TabIndex = 66;
            // 
            // btn_setBack
            // 
            this.btn_setBack.BackColor = System.Drawing.Color.White;
            this.btn_setBack.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_setBack.Location = new System.Drawing.Point(24, 50);
            this.btn_setBack.Name = "btn_setBack";
            this.btn_setBack.Size = new System.Drawing.Size(133, 32);
            this.btn_setBack.TabIndex = 65;
            this.btn_setBack.Text = "Set Back";
            this.btn_setBack.UseVisualStyleBackColor = false;
            this.btn_setBack.Click += new System.EventHandler(this.btn_setBack_Click);
            // 
            // TeachForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 991);
            this.Controls.Add(this.txb_recipePathBack);
            this.Controls.Add(this.btn_setBack);
            this.Controls.Add(this.btn_runBack);
            this.Controls.Add(this.btn_runFront);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.listBox_resultList);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox_alignGdn);
            this.Controls.Add(this.pictureBox_alignDet);
            this.Controls.Add(this.labelDefectNum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_inputsize);
            this.Controls.Add(this.label_modelname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txb_recipePathFront);
            this.Controls.Add(this.btn_setFront);
            this.Controls.Add(this.labelTotalTime);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.buttonFreeModel);
            this.Controls.Add(this.buttonLoadModel);
            this.Controls.Add(this.pictureBox_alignRst);
            this.Controls.Add(this.labelAlignExeTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelPCBnum);
            this.Controls.Add(this.pictureboxSrc);
            this.Controls.Add(this.pictureboxCpr);
            this.Name = "TeachForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PCB AOI Tool";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TeachForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxCpr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignRst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignDet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_alignGdn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureboxCpr;
        private System.Windows.Forms.PictureBox pictureboxSrc;
        private System.Windows.Forms.Label labelPCBnum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelAlignExeTime;
        private System.Windows.Forms.PictureBox pictureBox_alignRst;
        private System.Windows.Forms.Button buttonLoadModel;
        private System.Windows.Forms.Button buttonFreeModel;
        private System.Windows.Forms.Label labelTotalTime;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_setFront;
        private System.Windows.Forms.TextBox txb_recipePathFront;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_modelname;
        private System.Windows.Forms.Label label_inputsize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelDefectNum;
        private System.Windows.Forms.PictureBox pictureBox_alignDet;
        private System.Windows.Forms.PictureBox pictureBox_alignGdn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listBox_resultList;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_runFront;
        private System.Windows.Forms.Button btn_runBack;
        private System.Windows.Forms.TextBox txb_recipePathBack;
        private System.Windows.Forms.Button btn_setBack;
    }
}

