﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Brandy;
using Emgu.CV;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace YOLOv7_Demo
{
    public partial class YoloV7Form : Form
    {
        YoloV7Model core = null;
        int[] inputshape = null;
        Mat inputImage = null;
        Point MsPt = new Point(0, 0);
        public YoloV7Form()
        {
            InitializeComponent();
        }
        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }
            return chwData;
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                op.Filter = "Onnx file |*.onnx";
                try
                {
                    if (op.ShowDialog() == DialogResult.OK)
                    {
                        int gpuid = (int)numericUpDown1.Value;
                        core = new YoloV7Model(op.FileName, gpuid);
                        inputshape = core.InputShape;
                        string shapeinf = "InputShape：";
                        for (int i = 0; i < inputshape.Length; i++)
                        {
                            shapeinf += inputshape[i].ToString();
                            if ((i + 1) != inputshape.Length)
                                shapeinf += "*";
                        }
                        textBox2.Text = shapeinf;
                        btn_loadModel.Enabled = false;
                        btn_freeModel.Enabled = true;
                        btn_Inference.Enabled = true;
                        numericUpDown1.Enabled = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    MessageBox.Show("載入模型錯誤，請確認載入類型");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw;
            }
        }

        private void btn_freemodel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;

                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }
        private void btn_openimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {
                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage.Bitmap;
                dataGridViewResult.DataSource = null;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
              
                Stopwatch sw = new Stopwatch();
                sw.Start();
                Mat img = new Mat();
                inputImage.CopyTo(img);

                if (img.NumberOfChannels == 3)
                {
                    CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                }
                CvInvoke.Resize(img, img, new Size(core.InputShape[2], core.InputShape[3]));
                byte[] inputData = Mat_chw(img);
                Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                if (img.NumberOfChannels == 1)
                    type = Brandy.ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);

                sw.Restart();
                if (core.Inference(input))
                {
                    var outputdata = core.Output;
                    sw.Stop();
                    dataGridViewResult.DataSource = outputdata;
                    dataGridViewResult.Invalidate();
                }
                if(dataGridViewResult.DataSource != null)
                {
                    var items = this.dataGridViewResult.DataSource as List<YoloOutput>;
                    var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as YoloOutput;
                    this.DrawBoundingBoxes(items, selectedItem);
                }

                img.Dispose();
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";           
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void DrawBoundingBoxes(List<YoloOutput> items, YoloOutput selectedItem = null)
        {
            Image image = new Bitmap(pictureBoxSrc.Image);
            float gain_x = inputshape[2] / (float)image.Width;
            float gain_y = inputshape[3] / (float)image.Height;
            using (var canvas = Graphics.FromImage(image))
            {
                foreach (var item in items)
                {
                    var x = item.X / gain_x;
                    var y = item.Y / gain_y;
                    var width = item.Width / gain_x;
                    var height = item.Height / gain_y;

                    var brush = this.GetBrush(item.Confidence);
                    var penSize = (image.Width / 1000.0f) < 10 ? 10 : (image.Width / 1000.0f);
                    var penSizeSelect = (image.Width / 500.0f) < 20 ?  20 : (image.Width / 500.0f);
                    using (var pen = new Pen(brush, penSize))
                    using (var penSelect = new Pen(Brushes.DarkBlue, penSize))
                    {
                        if (item.Equals(selectedItem))
                        {
                            canvas.DrawRectangle(penSelect, x, y, width, height);
                        }
                        else
                        {
                            canvas.DrawRectangle(pen, x, y, width, height);
                        }
                    }
                }
                canvas.Flush();
            }
            var oldImage = this.pictureBoxSrc.Image;
            this.pictureBoxSrc.Image = image;
            oldImage?.Dispose();
        }

        private Brush GetBrush(double confidence)
        {
            if (confidence > 0.5)
            {
                return Brushes.GreenYellow;
            }
            else if (confidence > 0.2 && confidence <= 0.5)
            {
                return Brushes.Orange;
            }
            return Brushes.DarkRed;
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            pictureBoxSrc.Image = inputImage.Bitmap;
            if (!this.dataGridViewResult.Focused)
            {
                return;
            }
            var items = this.dataGridViewResult.DataSource as List<YoloOutput>;
            var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as YoloOutput;
            this.DrawBoundingBoxes(items, selectedItem);
        }

        private void Yolo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void pictureBoxSrc_MouseMove(object sender, MouseEventArgs e)
        {
            this.MsPt = this.unScale(new Point(e.X, e.Y));
            this.Text = String.Format("({0},{1})", this.MsPt.X, this.MsPt.Y);
        }

        private Point unScale(Point scaledP)
        {
            if (pictureBoxSrc.SizeMode != PictureBoxSizeMode.Zoom ) //only zoom mode need to scale
                return scaledP;

            if (pictureBoxSrc.Image == null)
                return scaledP;

            Point unscaled_p = new Point();
            // image and container dimensions
            int w_i = pictureBoxSrc.Image.Width;
            int h_i = pictureBoxSrc.Image.Height;
            int w_c = pictureBoxSrc.Width;
            int h_c = pictureBoxSrc.Height;
            float imageRatio = w_i / (float)h_i; // image W:H ratio
            float containerRatio = w_c / (float)h_c; // container W:H ratio

            if (imageRatio >= containerRatio)
            {
                // horizontal image
                float scaleFactor = w_c / (float)w_i;
                float scaledHeight = h_i * scaleFactor;
                // calculate gap between top of container and top of image
                float filler = Math.Abs(h_c - scaledHeight) / 2;
                unscaled_p.X = (int)(scaledP.X / scaleFactor);
                unscaled_p.Y = (int)((scaledP.Y - filler) / scaleFactor);
            }
            else
            {
                // vertical image
                float scaleFactor = h_c / (float)h_i;
                float scaledWidth = w_i * scaleFactor;
                float filler = Math.Abs(w_c - scaledWidth) / 2;
                unscaled_p.X = (int)((scaledP.X - filler) / scaleFactor);
                unscaled_p.Y = (int)(scaledP.Y / scaleFactor);
            }

            if (unscaled_p.X > pictureBoxSrc.Image.Width )
            {
                unscaled_p.X = pictureBoxSrc.Image.Width;
            }
            else if(unscaled_p.X < 0 )
            {
                unscaled_p.X = 0;
            }

            if (unscaled_p.Y > pictureBoxSrc.Image.Height)
            {
                unscaled_p.Y = pictureBoxSrc.Image.Height;
            }
            else if(unscaled_p.Y < 0)
            {
                unscaled_p.Y = 0;
            }
            return unscaled_p;
        }

        private void pictureBoxSrc_DoubleClick(object sender, EventArgs e)
        {          
            var ds = this.dataGridViewResult.DataSource as List<YoloOutput>;
            String msInfo = String.Empty;
            foreach (YoloOutput tmp_ds in ds)
            {
                if (Math.Abs(this.MsPt.X - tmp_ds.X) < 5 && Math.Abs(this.MsPt.Y - tmp_ds.Y) < 5)
                    msInfo += String.Format("Type=[{0}] , Score[{1}]" + "\r\n", tmp_ds.Type, tmp_ds.Confidence);
            }
            MessageBox.Show(String.Format("{0}", msInfo));
        }
    }
}
