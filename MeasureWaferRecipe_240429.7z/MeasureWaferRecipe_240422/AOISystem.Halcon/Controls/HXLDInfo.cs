﻿using HalconDotNet;

namespace AOISystem.Halcon.Controls
{
    public class HXLDInfo
    {
        public HXLDInfo()
        {
            Name = string.Empty;
            HDispXLD = new HObject();
            HDispColor = HColorMode.red;
        }

        public string Name { get; set; }

        public HObject HDispXLD { get; set; }

        public HColorMode HDispColor { get; set; }
    }
}
