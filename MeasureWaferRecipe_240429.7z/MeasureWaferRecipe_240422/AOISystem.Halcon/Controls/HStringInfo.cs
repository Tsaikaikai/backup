﻿using HalconDotNet;

namespace AOISystem.Halcon.Controls
{
    public class HStringInfo
    {
        public HStringInfo()
        {
            Name = string.Empty;
            Msg = string.Empty;
            FontSize = 15;
            Row = new HTuple();
            Column = new HTuple();
            DispColor = HColorMode.red;
        }

        public string Name { get; set; }

        public HTuple Msg { get; set; }

        public int FontSize { get; set; }

        public HTuple Row { get; set; }

        public HTuple Column { get; set; }

        public HColorMode DispColor { get; set; }
    }
}
