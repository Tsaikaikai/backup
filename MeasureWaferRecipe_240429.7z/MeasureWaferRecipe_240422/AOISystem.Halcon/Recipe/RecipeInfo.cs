﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace AOISystem.Halcon.Recipe
{
    [Serializable]
    public class RecipeInfo
    {
        public RecipeInfo()
        {
            this.ROIInfoCollection = new ROIInfoCollection();
        }

        [Browsable(true), Category("Property"), Description("RecipeNo")]
        public int RecipeNo { get; set; }

        [Browsable(true), Category("Property"), Description("RecipeID")]
        public string RecipeID { get; set; }

        [Browsable(true), Category("Property"), Description("ModifyTime")]
        public DateTime ModifyTime { get; set; }

        [Browsable(true), Category("Property"), Description("Active")]
        public bool Active { get; set; }

        [Browsable(true), Category("Property"), Description("Description")]
        public string Description { get; set; }

        [Browsable(false), Category("Property"), Description("ROIInfoCollection")]
        public ROIInfoCollection ROIInfoCollection { get; set; }

        public string GetRecipePath()
        {
            return string.Format(@"{0}\Recipe\{1:D3}_{2}\", Application.StartupPath, this.RecipeNo, this.RecipeID);
        }
    }

    [Serializable]
    public class RecipeInfoCollection : CollectionBase
    {
        public RecipeInfo this[int index]
        {
            get { return (RecipeInfo)base.List[index]; }
            set { base.List[index] = value; }
        }

        public int Add(RecipeInfo value)
        {
            return base.InnerList.Add(value);
        }

        public void Insert(int index, RecipeInfo value)
        {
            base.InnerList.Insert(index, value);
        }

        public void Remove(RecipeInfo value)
        {
            base.InnerList.Remove(value);
        }

        public int IndexOf(RecipeInfo value)
        {
            return base.InnerList.IndexOf(value);
        }

        public bool Contains(RecipeInfo value)
        {
            return base.InnerList.Contains(value);
        }

        public void Sort(IComparer comparer)
        {
            base.InnerList.Sort(comparer);
        }
    }
}
