﻿using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using AOISystem.Halcon.Recipe;

namespace AOISystem.Halcon.RecipeForm
{
    public partial class RecipeController : UserControl
    {
        #region - Private Properties -
        private RecipeInfo _selectedRecipeInfo;
        #endregion - Private Properties -

        #region - Public Constructor -
        public RecipeController()
        {
            InitializeComponent();

            _selectedRecipeInfo = new RecipeInfo();
            this.RecipeInfoCollection = new RecipeInfoCollection();
            this.ROIInfoCollection = new ROIInfoCollection();
        }
        #endregion - Public Constructor -

        # region - Public Parameters -
        public delegate void RecipeCollectionChangedEventHandler(RecipeInfoCollection recipeCollection);
        public event RecipeCollectionChangedEventHandler RecipeCollectionChangedEvent;

        public delegate void RecipeSelectedIndexChangedEventHandler(RecipeInfo recipeInfo);
        public event RecipeSelectedIndexChangedEventHandler RecipeSelectedIndexChangedEvent;

        public delegate void RecipeCopyChangedEventHandler(RecipeInfo oldRecipeInfo, RecipeInfo newRecipeInfo);
        public event RecipeCopyChangedEventHandler RecipeCopyChangedEvent;
        # endregion - Public Parameters -

        # region - Public Property -
        public RecipeInfoCollection RecipeInfoCollection { get; set; }
        public ROIInfoCollection ROIInfoCollection { get; set; }
        public bool IsExistSameRecipeID { get; set; }
        # endregion - Public Property -

        # region - Private Property -
        # endregion - Private Property -

        #region - Configuration Methods -
        /// <summary>
        /// 初始化並切換Recipe
        /// </summary>
        /// <param name="recipeNo">Recipe No</param>
        public bool InitializeConfiguration(int recipeNo)
        {
            bool flag = false;
            InitializeRecipeInfoCollection();

            if (RecipeInfoCollection.Count != 0)
            {
               flag = SetRecipeNo(recipeNo);
            }

            RefreshRecipeData();

            return flag;
        }

        /// <summary>
        /// 初始化並切換Recipe
        /// </summary>
        /// <param name="recipeID">Recipe ID</param>
        public void InitializeConfiguration(string recipeID)
        {
            InitializeRecipeInfoCollection();

            if (RecipeInfoCollection.Count != 0)
            {
                SetRecipeID(recipeID);
            }

            RefreshRecipeData();
        }
        /// <summary>
        /// 初始化RecipeInfoCollection
        /// </summary>
        private void InitializeRecipeInfoCollection()
        {
            if (LoadRecipeInfoCollectionXML() == false)
            {
                string msg = string.Format("讀取Recipe失敗!\n是否建立Recipe基本資料");
                if (MessageBox.Show(msg, "", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    if (!Directory.Exists(RecipeManager.RecipeRootPath))
                    {
                        Directory.CreateDirectory(RecipeManager.RecipeRootPath);
                    }
                    if (!Directory.Exists(RecipeManager.RecipeRootPath + "StandardRecipe"))
                    {
                        Directory.CreateDirectory(RecipeManager.RecipeRootPath + "StandardRecipe");
                    }
                    RecipeManager.SetRecipeCollection(new RecipeInfoCollection());
                }
                else
                {
                    throw new ArgumentException("讀取Recipe失敗");
                }
            }

            OnRecipeCollectionChangedEvent(this.RecipeInfoCollection);
        }
        /// <summary>
        /// 讀取Recipe Info Collection從XML
        /// </summary>
        private bool LoadRecipeInfoCollectionXML()
        {
            try
            {
                this.RecipeInfoCollection = RecipeManager.GetRecipeCollection();

                foreach (RecipeInfo recipe in this.RecipeInfoCollection)
                {
                    LoadROIInfoCollectionFromRecipeInfo(recipe);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        /// <summary>
        /// 儲存Recipe Info Collection到XML
        /// </summary>
        private void SaveRecipeInfoCollectionXML()
        {
            try
            {
                this.RecipeInfoCollection.Sort(new ComparerByRecipeNo());

                RecipeManager.SetRecipeCollection(this.RecipeInfoCollection);

                OnRecipeCollectionChangedEvent(this.RecipeInfoCollection);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// 讀取ROI Info Collection從Recipe Info
        /// </summary>
        /// <param name="recipeInfo">Recipe Info</param>
        private void LoadROIInfoCollectionFromRecipeInfo(RecipeInfo recipeInfo)
        {
            recipeInfo.ROIInfoCollection = ROIManager.GetROIInfoCollection(recipeInfo);
            this.ROIInfoCollection = recipeInfo.ROIInfoCollection;
        }
        /// <summary>
        /// 儲存ROI Info Collection到當前Recipe Info
        /// </summary> 
        /// <param name="rOIInfoCollection">ROI Info Collection</param>
        public void SaveROICollectionToActiveRecipeInfo(ROIInfoCollection rOIInfoCollection)
        {
            this.ROIInfoCollection = rOIInfoCollection;
            ROIManager.SetROIInfoCollection(rOIInfoCollection);
        }
        #endregion - Configuration Methods -

        #region - Event Methods -
        protected virtual void OnRecipeCollectionChangedEvent(RecipeInfoCollection recipeCollection)
        {
            if (this.RecipeCollectionChangedEvent != null)
            { 
                this.RecipeCollectionChangedEvent(recipeCollection);
            }
        }

        protected virtual void OnRecipeSelectedIndexChangedEvent(RecipeInfo recipeInfo)
        {
            if (RecipeSelectedIndexChangedEvent != null)
                RecipeSelectedIndexChangedEvent(recipeInfo);
        }

        protected virtual void OnRecipeCopyChangedEvent(RecipeInfo oldRecipeInfo, RecipeInfo rewRecipeInfo)
        {
            if (RecipeCopyChangedEvent != null)
                RecipeCopyChangedEvent(oldRecipeInfo, rewRecipeInfo);
        }
        #endregion - Event Methods -

        #region - Callback Event Methods -
        private void btnCreateEditorRecipe_Click(object sender, EventArgs e)
        {
            RecipeInfo recipe = new RecipeInfo();

            EditorRecipeForm editorRecipeForm = new EditorRecipeForm(_selectedRecipeInfo, recipe);
            editorRecipeForm.Text = ((Button)sender).Text == "Create" ? "Recipe Create" : "Recipe Edit";

            if (editorRecipeForm.ShowDialog() == DialogResult.OK)
            {
                switch (((Button)sender).Text)
                {
                    case "Create":
                        for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                        {
                            if (this.RecipeInfoCollection[i].RecipeNo == recipe.RecipeNo)
                            {
                                MessageBox.Show("此RecipeNo名稱已存在, 請重新輸入!");
                                return;
                            }
                            if (this.IsExistSameRecipeID == false && this.RecipeInfoCollection[i].RecipeID == recipe.RecipeID)
                            {
                                MessageBox.Show("此RecipeID名稱已存在, 請重新輸入!");
                                return;
                            }
                        }
                        CreateNewRecipe(recipe);
                        break;
                    case "Edit":
                        for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                        {
                            if (this.RecipeInfoCollection[i].RecipeNo == recipe.RecipeNo && txtDisplayRecipeNo.Text != string.Format("{0:D3}", recipe.RecipeNo))
                            {
                                MessageBox.Show("此RecipeNo名稱已存在, 請重新輸入!");
                                return;
                            }
                            if (this.IsExistSameRecipeID == false && this.RecipeInfoCollection[i].RecipeID == recipe.RecipeID && txtDisplayRecipeID.Text != recipe.RecipeID)
                            {
                                MessageBox.Show("此RecipeID名稱已存在, 請重新輸入!");
                                return;
                            }
                        }
                        for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                        {
                            if (this.RecipeInfoCollection[i].RecipeNo == recipe.RecipeNo)
                            {
                                this.RecipeInfoCollection[i].RecipeID = recipe.RecipeID;
                                this.RecipeInfoCollection[i].ModifyTime = DateTime.Now;
                                this.RecipeInfoCollection[i].Description = recipe.Description;
                            }
                        }

                        string editOldNo = RecipeManager.RecipeRootPath + txtDisplayRecipeNo.Text + "_" + txtDisplayRecipeID.Text + "\\";
                        string editNewNo = RecipeManager.RecipeRootPath + txtDisplayRecipeNo.Text + "_" + recipe.RecipeID + "\\";

                        int compareInt = editOldNo.CompareTo(editNewNo);
                        if (compareInt != 0)
                        {
                            string interpath = Path.GetRandomFileName();
                            Directory.Move(editOldNo, interpath);
                            Directory.Move(interpath, editNewNo);
                            SetRecipeNo(recipe.RecipeNo);
                        }
                        break;
                }

                SaveRecipeInfoCollectionXML();

                txtDisplayRecipeNo.Text = string.Format("{0:D3}", recipe.RecipeNo);
                txtDisplayRecipeID.Text = recipe.RecipeID;
                RefreshRecipeData();
            }
        }

        private void dgvRecipeList_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            txtDisplayRecipeNo.Text = this.dgvRecipeList.Rows[e.RowIndex].Cells["RecipeNo"].Value.ToString();
            txtDisplayRecipeID.Text = this.dgvRecipeList.Rows[e.RowIndex].Cells["RecipeID"].Value.ToString();
            for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
            {
                if (txtDisplayRecipeID.Text == this.RecipeInfoCollection[i].RecipeID)
                {
                    _selectedRecipeInfo = this.RecipeInfoCollection[i];
                }
            }            
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (txtDisplayRecipeNo.Text == "" || txtDisplayRecipeID.Text == "")
            {
                MessageBox.Show("尚未選取來源Recipe參數");
                return;
            }

            RecipeInfo recipe = new RecipeInfo();

            CopyRecipeForm copyRecipeForm = new CopyRecipeForm(_selectedRecipeInfo, recipe);

            if (copyRecipeForm.ShowDialog() == DialogResult.OK)
            {
                if (recipe.RecipeNo == 0 || recipe.RecipeID == "")
                {
                    MessageBox.Show("尚未輸入目標Recipe參數");
                    return;
                }
                for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                {
                    if (this.RecipeInfoCollection[i].RecipeNo == recipe.RecipeNo)
                    {
                        MessageBox.Show("此RecipeNo名稱已存在, 請重新輸入!");
                        return;
                    }
                    if (this.IsExistSameRecipeID == false && this.RecipeInfoCollection[i].RecipeID == recipe.RecipeID)
                    {
                        MessageBox.Show("此RecipeID名稱已存在, 請重新輸入!");
                        return;
                    }
                }
                string sourcePath = RecipeManager.RecipeRootPath + txtDisplayRecipeNo.Text + "_" + txtDisplayRecipeID.Text + "\\";
                string targetPath = RecipeManager.RecipeRootPath + string.Format("{0:D3}", recipe.RecipeNo) + "_" + recipe.RecipeID + "\\";

                RecursiveCopy(sourcePath, targetPath);

                recipe.ModifyTime = DateTime.Now;
                this.RecipeInfoCollection.Add(recipe);
                SaveRecipeInfoCollectionXML();

                RefreshRecipeData();

                OnRecipeCopyChangedEvent(_selectedRecipeInfo, recipe);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtDisplayRecipeNo.Text == "")
            {
                MessageBox.Show("尚未選取Recipe");
                return;
            }
            if (int.Parse(this.txtDisplayRecipeNo.Text) == RecipeManager.ActiveRecipe.RecipeNo)
            {
                MessageBox.Show("不能刪除作用中Recipe");
                return;
            }
            DialogResult result;
            result = MessageBox.Show("是否刪除既有Recipe ?", "Recipe管理工具", MessageBoxButtons.YesNo);
            if (result == DialogResult.No)
            {
                return;
            }
            foreach (RecipeInfo recipe in this.RecipeInfoCollection)
            {
                if (recipe.RecipeNo == int.Parse(txtDisplayRecipeNo.Text))
                {
                    this.RecipeInfoCollection.Remove(recipe);
                    break;
                }
            }

            this.DeleteDirectoryFiles(RecipeManager.RecipeRootPath + txtDisplayRecipeNo.Text + "_" + txtDisplayRecipeID.Text);

            SaveRecipeInfoCollectionXML();
            RefreshRecipeData();
            txtDisplayRecipeNo.Text = "";
            txtDisplayRecipeID.Text = "";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(string.Format("使否將RecipeNo設定為{0:000}", cboCurrentRecipeChange.SelectedItem), "",
                MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (cboCurrentRecipeChange.SelectedItem == null)
                {
                    MessageBox.Show("請重新選擇欲切換工單");
                    return;
                }
                SetRecipeNo(int.Parse(cboCurrentRecipeChange.SelectedItem.ToString()));
            }
            else
            {
                this.cboCurrentRecipeChange.Text = this.txtDisplayRecipeNo.Text;
            }
        }
        #endregion - Callback Event Methods -

        #region - Public Methods -
        public RecipeInfo GetRecipeInfo(int recipeNo)
        {
            RecipeInfo returnRecipe = new RecipeInfo();
            foreach (RecipeInfo recipe in this.RecipeInfoCollection)
            {
                if (recipe.RecipeNo == recipeNo)
                {
                    returnRecipe = recipe;
                    break;
                }
            }
            return returnRecipe;
        }

        public ROIInfoCollection GetROIInfoCollection(int recipeNo)
        {
            foreach (RecipeInfo recipe in this.RecipeInfoCollection)
            {
                if (recipe.RecipeNo == recipeNo)
                {
                    return recipe.ROIInfoCollection;
                }
            }
            return new ROIInfoCollection();
        }

        public bool SetRecipeNo(int recipeNo)
        {
            for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
            {
                if (recipeNo == this.RecipeInfoCollection[i].RecipeNo)
                {
                    SetRecipeInfo(this.RecipeInfoCollection[i]);
                    return true;
                }
            }
            return false;
        }

        public bool SetRecipeID(string recipeID)
        {
            for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
            {
                if (recipeID == this.RecipeInfoCollection[i].RecipeID)
                {
                    SetRecipeInfo(this.RecipeInfoCollection[i]);
                    return true;
                }
            }
            return false;
        }

        public void SetRecipeInfo(RecipeInfo recipeInfo)
        {
            this.cboCurrentRecipeChange.Text = string.Format("{0:D3}", recipeInfo.RecipeNo);
            this.txtDisplayRecipeNo.Text = string.Format("{0:D3}", recipeInfo.RecipeNo);
            this.txtDisplayRecipeID.Text = recipeInfo.RecipeID;
            _selectedRecipeInfo = recipeInfo;
            RecipeManager.ActiveRecipe = recipeInfo;
            this.ROIInfoCollection = recipeInfo.ROIInfoCollection;
            OnRecipeSelectedIndexChangedEvent(recipeInfo);
        }

        public int GetRecipeNoFromID(string recipeID)
        {
            for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
            {
                if (recipeID == this.RecipeInfoCollection[i].RecipeID)
                {
                    return this.RecipeInfoCollection[i].RecipeNo;
                }
            }
            return -1;
        }

        public string GetRecipeIDFromNo(int recipeNo)
        {
            for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
            {
                if (recipeNo == this.RecipeInfoCollection[i].RecipeNo)
                {
                    return this.RecipeInfoCollection[i].RecipeID;
                }
            }
            return string.Empty;
        }

        public void ChangeControlState(bool isProcessing)
        {
            this.cboCurrentRecipeChange.Enabled = !isProcessing;
        }
        #endregion - Public Methods -

        #region - Private Methods -
        private void RefreshRecipeData()
        {
            try
            {
                this.dgvRecipeList.Rows.Clear();
                for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                {
                    this.dgvRecipeList.Rows.Add();
                    this.dgvRecipeList.Rows[i].Cells["RecipeNo"].Value = string.Format("{0:D3}", this.RecipeInfoCollection[i].RecipeNo);
                    this.dgvRecipeList.Rows[i].Cells["RecipeID"].Value = this.RecipeInfoCollection[i].RecipeID;
                    this.dgvRecipeList.Rows[i].Cells["ModifyTime"].Value = this.RecipeInfoCollection[i].ModifyTime.ToString("yyyy年MM月dd日 HH:mm:ss");
                    this.dgvRecipeList.Rows[i].Cells["Description"].Value = this.RecipeInfoCollection[i].Description;
                }

                this.cboCurrentRecipeChange.Items.Clear();
                for (int i = 0; i < this.RecipeInfoCollection.Count; i++)
                {
                    this.cboCurrentRecipeChange.Items.Add(string.Format("{0:D3}", this.RecipeInfoCollection[i].RecipeNo));
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void CreateNewRecipe(RecipeInfo recipe)
        {
            recipe.ModifyTime = DateTime.Now;
            this.RecipeInfoCollection.Add(recipe);

            string sourcePath = RecipeManager.RecipeRootPath + "StandardRecipe\\";
            string targetPath = RecipeManager.RecipeRootPath + string.Format("{0:D3}", recipe.RecipeNo) + "_" + recipe.RecipeID + "\\";

            RecursiveCopy(sourcePath, targetPath);
        }

        /// <summary>
        /// 目錄與目錄下檔案複製(原目錄, 目標目錄)
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="targetPath"></param>
        private void RecursiveCopy(string sourcePath, string targetPath)
        {
            if (Directory.Exists(sourcePath))
            {
                //copy directories
                if (!Directory.Exists(targetPath))
                    Directory.CreateDirectory(targetPath);
                string[] dirs = Directory.GetDirectories(sourcePath);
                foreach (string d in dirs)
                {
                    string nextSource = d + "\\";
                    int index = d.LastIndexOf('\\');
                    int index2 = nextSource.LastIndexOf('\\');
                    string s = nextSource.Substring(index + 1, index2 - index - 1);
                    string nextTarget = targetPath + s + "\\";

                    RecursiveCopy(nextSource, nextTarget);
                }
                //copy files
                string[] files = Directory.GetFiles(sourcePath);
                foreach (string f in files)
                {
                    string fileName = Path.GetFileName(f);
                    string destFile = Path.Combine(targetPath, fileName);
                    File.Copy(f, destFile, true);
                }
            }
            else
            {
                if (!Directory.Exists(sourcePath))
                    Directory.CreateDirectory(sourcePath);
                if (!Directory.Exists(targetPath))
                    Directory.CreateDirectory(targetPath);
            }
        }

        /// <summary>
        /// 刪除資料夾檔案
        /// </summary>
        /// <param name="rOIPath">指定要刪除資料夾檔案的完整路徑</param>
        public void DeleteDirectoryFiles(string path)
        {
            try
            {
                string[] tempDirectorys, tempSubDirectorys;
                // 檢查指定的資料夾是否存在
                if (Directory.Exists(path))
                {
                    // 檢查指定的資料夾內是否有子資料夾
                    tempDirectorys = Directory.GetDirectories(path);
                    // 刪除指定的資料夾內的所有子資料夾
                    for (int i = 0; i < tempDirectorys.Length; i++)
                    {
                        // 檢查指定的子資料夾內是否還有資料夾
                        tempSubDirectorys = Directory.GetDirectories(tempDirectorys[i]);
                        if (tempSubDirectorys.Length > 0)
                        {
                            // 刪除指定的子資料夾內還有的資料夾
                            for (int j = 0; j < tempSubDirectorys.Length; j++)
                                DeleteDirectoryFiles(tempSubDirectorys[j]);
                        }
                        // 刪除指定的子資料夾內的所有檔案
                        DeleteFiles(tempDirectorys[i]);
                        // 刪除指定的子資料夾
                        Directory.Delete(tempDirectorys[i]);
                    }
                    // 刪除指定的資料夾內的所有檔案
                    DeleteFiles(path);
                    // 刪除指定的資料夾
                    Directory.Delete(path);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// 刪除檔案
        /// </summary>
        /// <param name="rOIPath">指定要刪除檔案的完整路徑</param>
        public void DeleteFiles(string path)
        {
            try
            {
                string[] tempFileNames;
                // 檢查指定的資料夾是否存在
                if (Directory.Exists(path))
                {
                    // 檢查指定的資料夾內是否有檔案
                    tempFileNames = Directory.GetFiles(path);
                    // 刪除指定的資料夾內的所有檔案
                    for (int i = 0; i < tempFileNames.Length; i++)
                    {
                        File.Delete(tempFileNames[i]);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public class ComparerByRecipeNo : IComparer
        {
            public int Compare(object recipe1, object recipe2)
            {
                return ((RecipeInfo)recipe1).RecipeNo.CompareTo(((RecipeInfo)recipe2).RecipeNo);
            }
        }
        #endregion - Private Methods -
    }
}
