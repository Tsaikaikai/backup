namespace AgingAOI.Core.Models
{
    /// <summary>PushFrame 的回傳值。</summary>
    public enum PushResult
    {
        /// <summary>已收下；該張影像須保留到序列結束（StopInspect / AbortInspect 返回後）才可釋放。</summary>
        Accepted = 0,

        /// <summary>流程異常，本序列失效。平台應 AbortInspect / StopInspect 收尾並記為 Fault。</summary>
        Fault = 1
    }

    /// <summary>
    /// 缺陷代碼常數。ZoneResult.Type 只能是 Ok 或下列 Tm 代碼，大小寫須一致。
    /// 新增代碼前必須先與平台及上游 MES 確認（會直接進上報欄位）。
    /// 哪些類別會被檢測，由演算法 Config 的檢測參數決定（線缺陷 / 面缺陷各自有啟用設定），
    /// 未啟用類別的代碼不會出現在結果中。
    /// </summary>
    public static class DefectCode
    {
        public const string Ok     = "OK";

        // ── 線缺陷 ────────────────────────────────────────
        public const string Tm1500 = "TM1500";   // 線狀瑕疵（介面保留，尚未實作）

        // ── 面缺陷 ────────────────────────────────────────
        public const string Tm6000 = "TM6000";   // 色偏 / 顏色錯誤
        public const string Tm6100 = "TM6100";   // 畫面雜亂（白畫面不均）
        public const string Tm6200 = "TM6200";   // 彩色畫面雜亂
        public const string Tm6300 = "TM6300";   // 缺少圖樣
        public const string Tm6500 = "TM6500";   // 漸層顆粒異物
        public const string Tm7000 = "TM7000";   // 對位失敗 / 閃爍 / 圖樣序列異常
    }

    /// <summary>
    /// 單一 Zone（工位）的統整結果：每個工位一筆。
    /// 逐張、逐區塊等細項結果不在此輸出，由演算法自行存檔。
    /// </summary>
    public class ZoneResult
    {
        /// <summary>Zone 序號，0 起算，與 Config.Zones 順序一致。</summary>
        public int Index { get; set; }

        /// <summary>
        /// "OK" 或 DefectCode 的 TM 代碼。
        /// 規則：單張內多種瑕疵同時命中，優先序 TM7000(閃爍) > TM6500 > TM6100 > TM6000 > TM6200 > TM1500；
        ///       Zone 一旦判 NG，之後各張的 NG 不覆蓋此值（保留第一個）；
        ///       Empty Zone 一律 "OK"。
        /// </summary>
        public string Type { get; set; } = DefectCode.Ok;

        /// <summary>此 Zone 是否通過。</summary>
        public bool IsOk
        {
            get { return Type == DefectCode.Ok; }
        }
    }

    /// <summary>
    /// 一次序列（一片載具）的最終結果：各 Zone 統整結果 + 整體結果。
    /// 平台上報只需讀這個物件。
    /// </summary>
    public class InspectResult
    {
        /// <summary>整體是否通過：全部 Zone 皆 OK 才為 true。</summary>
        public bool IsOk { get; set; } = true;

        /// <summary>
        /// 整體缺陷碼：全部 OK 為 "OK"；否則為「最後一個 NG Zone 的 Type」（對應上報的 MCMQ 缺陷碼）。
        /// </summary>
        public string Type { get; set; } = DefectCode.Ok;

        /// <summary>逐 Zone 統整結果，長度 = Zone 數，順序 = Config.Zones 順序。</summary>
        public ZoneResult[] Zones { get; set; } = new ZoneResult[0];
    }
}
