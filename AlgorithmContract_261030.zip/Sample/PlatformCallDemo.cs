using AgingAOI.Core.Interfaces;
using AgingAOI.Core.Models;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using LogLevel = AgingAOI.Core.Interfaces.LogLevel;   // OpenCvSharp 也有 LogLevel，需指定

namespace AgingAOI.Sample
{
    /// <summary>
    /// 【給平台人員的呼叫示範】—— 模擬「平台」如何使用 IAlgorithm（串流版）。
    ///
    /// 平台一次檢測（一片載具、最多 ZoneCount 個工位）的完整流程：
    ///   1. 建立演算法、載入參數（開機或換機型時做一次；檢測類別由 Config 決定）
    ///   2. StartInspect：傳入 taskId（本次檢測識別，算法存細項時用）與 emptyZones（哪些工位沒放 panel）
    ///   3. 連拍取像：「取到一張就 PushFrame 一張」
    ///        · Accepted → 繼續下一張（★ 該張不可釋放，演算法可能還在用）
    ///        · Fault    → AbortInspect，記為 Fault
    ///   4. 全部送完 → StopInspect（阻塞到算完），取得 InspectResult
    ///   5. StopInspect 回傳 false → 記為 Fault（設備 / 流程異常，不計良率，不上報）
    ///   6. 回傳 true → 直接使用 result（各 Zone 統整結果 + 整體結果）組上報欄位
    ///   7. ★ StopInspect / AbortInspect 返回後（序列已回到 Idle），才釋放本序列餵入的所有影像
    ///
    /// 細項結果（逐張、逐區塊、影像）由演算法自行存檔，不經由介面回傳，平台不需處理。
    ///
    /// 執行：PlatformCallDemo.Run(@"C:\temp\demo");
    /// 本檔使用 MockAlgorithm 代替真實演算法；換成真實演算法只需改 Step 1 的 new。
    /// </summary>
    public static class PlatformCallDemo
    {
        // 模擬取像用的張數與解析度（實機為 5472x3648、約 50~60 張；示範用小圖）
        private const int FrameCount = 5;
        private const int Width = 640;
        private const int Height = 480;

        public static void Run(string outputDir)
        {
            ILogService log = new ConsoleLogService();
            Directory.CreateDirectory(outputDir);

            // ════ Step 1: 建立演算法、載入參數（開機 / 換機型時做一次）════════
            using (IAlgorithm algorithm = new MockAlgorithm(log))
            {
                string configPath = Path.Combine(outputDir, "AlgorithmConfig.xml");
                if (!File.Exists(configPath))
                    algorithm.Config.Save(configPath);       // 第一次先寫出預設值，供現場調參
                algorithm.Config.Load(configPath);           // 檔案不存在時 Load 直接 return，不拋例外
                // 真實演算法：各 Zone 的 Golden 影像放在 configPath 同一資料夾

                log.Info("演算法：" + algorithm.Name);

                // 工位數由 Config 決定；每個工位各自一組參數（Config 內的 Zones[i]），
                // 演算法檢測第 i 個工位時只套用第 i 組。emptyZones 長度必須等於 ZoneCount。
                // 線 / 面缺陷要檢測哪些，也是 Config 的設定，不在呼叫時指定。
                int zoneCount = algorithm.Config.ZoneCount;
                log.Info("工位數 = " + zoneCount);

                // ── 範例 A：預設 Config（線缺陷 + 面缺陷皆啟用），所有工位都有 panel ──
                InspectOnce(algorithm, log, "A001", EmptyZones(zoneCount));

                // ── 範例 B：Config 只啟用線缺陷，且最後一個工位為空 ─────────
                SwitchRecipe(algorithm, log, outputDir, 2, enableLine: true, enableSurface: false);
                InspectOnce(algorithm, log, "A002", EmptyZones(algorithm.Config.ZoneCount, 1));

                // ── 範例 C：Config 未啟用任何檢測類別 → StartInspect 回傳 false → Fault ──
                SwitchRecipe(algorithm, log, outputDir, 2, enableLine: false, enableSurface: false);
                InspectOnce(algorithm, log, "A003", EmptyZones(algorithm.Config.ZoneCount));

                // ── 範例 D：錯誤輸入（emptyZones 長度與 ZoneCount 不符）→ Fault ──
                SwitchRecipe(algorithm, log, outputDir, 2, enableLine: true, enableSurface: true);
                InspectOnce(algorithm, log, "A004", EmptyZones(algorithm.Config.ZoneCount + 1));

                // ── 範例 E：4 個工位的機型，第 2 個工位（Zone 1）為空 ─────────
                // 換機型 = 重新 Config.Load；載入後 ZoneCount 可能改變，平台要重新讀取。
                SwitchRecipe(algorithm, log, outputDir, 4, enableLine: true, enableSurface: true);
                InspectOnce(algorithm, log, "A005", EmptyZones(algorithm.Config.ZoneCount, 1));

                // ── 範例 F：3 個工位的機型，第 1 個工位（Zone 0）為空 ─────────
                SwitchRecipe(algorithm, log, outputDir, 3, enableLine: true, enableSurface: true);
                InspectOnce(algorithm, log, "A006", EmptyZones(algorithm.Config.ZoneCount, 0));

                // ── 範例 G：4 個工位的機型，第 2、3 個工位（Zone 1、Zone 2）為空 ──
                // EmptyZones 的第二個參數起可一次指定多個空工位：{false, true, true, false}
                SwitchRecipe(algorithm, log, outputDir, 4, enableLine: true, enableSurface: true);
                InspectOnce(algorithm, log, "A007", EmptyZones(algorithm.Config.ZoneCount, 1, 2));

                // ── 範例 H：中途中止（例如 panel 被取走）→ AbortInspect，不取結果 ──
                InspectAborted(algorithm, log, "A008", EmptyZones(algorithm.Config.ZoneCount));
            }
        }

        /// <summary>平台對「一片載具」的一次完整檢測（串流餵圖）。</summary>
        private static void InspectOnce(IAlgorithm algorithm, ILogService log, string taskId, bool[] emptyZones)
        {
            log.Info("──── 檢測開始 id=" + taskId + " ────");

            // 平台自己控制逾時；演算法需定期檢查 token，被取消時回傳 false
            using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30)))
            {
                // ════ Step 2: 開始序列 ═══════════════════════════════════
                if (!algorithm.StartInspect(taskId, emptyZones))
                {
                    // 狀態維持 Idle，沒有序列需要收尾
                    log.Error("[" + taskId + "] 結果：Fault（START_FAILED）");
                    return;
                }

                // ════ Step 3: 連拍取像，取到一張餵一張 ═══════════════════
                //   格式：BGR、8UC3、整張原圖，依拍攝順序。
                //   ★ PushFrame 回傳 Accepted 後，演算法可能仍在使用該張（不一定有複製），
                //     所以平台「不可」立刻 Dispose：先收進 frames，
                //     等 StopInspect / AbortInspect 呼叫結束（序列回到 Idle）後，才在 finally 一次釋放。
                var frames = new List<Mat>();
                try
                {
                    for (int i = 0; i < FrameCount; i++)
                    {
                        Mat frame = GrabFrame(i);
                        frames.Add(frame);                    // 不論 Accepted 與否，統一由 finally 釋放

                        if (algorithm.PushFrame(frame) != PushResult.Accepted)
                        {
                            log.Error("[" + taskId + "] 結果：Fault（PUSH_FAILED，第 " + i + " 張）");
                            algorithm.AbortInspect();         // 放棄本序列，回到 Idle，之後才能釋放影像
                            return;
                        }
                        // 實機：此時相機正在拍下一張，演算法同時處理這一張
                    }

                    // ════ Step 4: 全部送完，取最終結果（阻塞到算完）═════════
                    InspectResult result;
                    bool ok = algorithm.StopInspect(out result, cts.Token);

                    // ════ Step 5: false → Fault ══════════════════════════════
                    if (!ok)
                    {
                        // result 內容無效（Zones 為空陣列），不可使用。
                        // Fault = 設備 / 流程異常：本片沒有有效判定，不計入良率，不上報。
                        // StopInspect 回傳後序列已結束（Idle），不需要再 AbortInspect。
                        log.Error("[" + taskId + "] 結果：Fault（ALGORITHM_FAILED）");
                        return;
                    }

                    // ════ Step 6: 使用最終結果組上報欄位 ═════════════════════
                    //   result.IsOk / result.Type = 整體結果；result.Zones = 各工位一筆統整結果。
                    //   不需再自行推導整體 OK / NG。
                    // 各 Zone 是否通過：true;false;…
                    string isPass = string.Join(";", result.Zones.Select(z => z.IsOk ? "true" : "false"));
                    // 失敗說明：各 Zone 的 Type 以 "-" 串接，例如 "OK-TM1500"
                    string failure = result.IsOk
                        ? ""
                        : "1;" + string.Join("-", result.Zones.Select(z => z.Type)) + " NG";

                    log.Info("[" + taskId + "] 結果：" + (result.IsOk ? "OK" : "NG"));
                    log.Info("  Is_Pass     = " + isPass);
                    log.Info("  Failure_Set = " + failure);
                    log.Info("  DefectCode  = " + result.Type);

                    // 位置鍵：result.Zones[j] 對應工位順序（= Config.Zones 順序）。
                    // 逐張 / 逐區塊 / 影像等細項由演算法自行存檔，平台不處理。
                }
                finally
                {
                    // ════ Step 7: 釋放輸入影像 ═══════════════════════════════
                    // 走到這裡時，序列一定已結束（StopInspect 或 AbortInspect 已返回），
                    // 演算法不再持有任何影像參照，可以安全 Dispose。
                    foreach (var f in frames) f.Dispose();
                }
            }
        }

        /// <summary>示範：序列進行到一半被中止（例如 panel 被取走），平台呼叫 AbortInspect 放棄本次。</summary>
        private static void InspectAborted(IAlgorithm algorithm, ILogService log, string taskId, bool[] emptyZones)
        {
            log.Info("──── 檢測開始 id=" + taskId + "（中途中止示範）────");
            if (!algorithm.StartInspect(taskId, emptyZones)) return;

            var frames = new List<Mat>();
            try
            {
                for (int i = 0; i < 2; i++)
                {
                    Mat frame = GrabFrame(i);
                    frames.Add(frame);
                    algorithm.PushFrame(frame);
                }

                algorithm.AbortInspect();     // 演算法放掉所有影像參照，回到 Idle；不會有結果
                log.Info("[" + taskId + "] 已 AbortInspect，演算法回到 Idle，可再次 StartInspect。");
            }
            finally
            {
                // AbortInspect 返回後才可釋放已餵入的影像
                foreach (var f in frames) f.Dispose();
            }
        }

        // ── 平台端輔助 ────────────────────────────────────────────

        /// <summary>
        /// 【僅示範用】模擬「換成另一個機型」：產生一份 N 個工位的 Config 檔並載入。
        /// 真實平台是把各機型自己的 Config 檔路徑傳給 algorithm.Config.Load(path)，
        /// 不會（也不需要）認識具體的 Config 類別；檢測類別啟用與否也是寫在該 Config 檔裡。
        /// </summary>
        private static void SwitchRecipe(IAlgorithm algorithm, ILogService log, string outputDir, int zoneCount,
                                         bool enableLine, bool enableSurface)
        {
            var cfg = new MockAlgorithmConfig
            {
                EnableLineDefect    = enableLine,
                EnableSurfaceDefect = enableSurface
            };
            for (int i = 0; i < zoneCount; i++)
                cfg.Zones.Add(new MockZoneParameter { Name = "Zone " + i, SimulateLineNg = (i % 2 == 1) });

            string path = Path.Combine(outputDir, "Config_" + zoneCount + "zones.xml");
            cfg.Save(path);
            algorithm.Config.Load(path);
            log.Info("切換機型：" + zoneCount + " 個工位，ZoneCount = " + algorithm.Config.ZoneCount);
        }

        /// <summary>建立 emptyZones：長度 = 工位數，預設全部 false（要檢測），指定的序號設為 true（空工位）。</summary>
        private static bool[] EmptyZones(int zoneCount, params int[] emptyIndexes)
        {
            var empty = new bool[zoneCount];
            foreach (int i in emptyIndexes)
                if (i >= 0 && i < zoneCount) empty[i] = true;
            return empty;
        }

        /// <summary>模擬取像：每張產生不同亮度的 BGR 8UC3 影像。呼叫端負責 Dispose（序列結束後）。</summary>
        private static Mat GrabFrame(int index)
        {
            return new Mat(Height, Width, MatType.CV_8UC3, new Scalar(40 * index, 40 * index, 40 * index));
        }

        /// <summary>示範用的簡易日誌；平台請改用自己的 ILogService 實作。</summary>
        private class ConsoleLogService : ILogService
        {
            public void Log(LogLevel level, string message)
            {
                Console.WriteLine("[" + level + "] " + message);
            }
            public void Debug(string message)   { Log(LogLevel.Debug, message); }
            public void Info(string message)    { Log(LogLevel.Info, message); }
            public void Warning(string message) { Log(LogLevel.Warning, message); }
            public void Error(string message)   { Log(LogLevel.Error, message); }
        }
    }
}
