using AgingAOI.Core.Interfaces;
using AgingAOI.Core.Models;
using OpenCvSharp;
using System;
using System.ComponentModel;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Xml.Serialization;

namespace AgingAOI.Sample
{
    /// <summary>
    /// 單一 Zone（工位）的參數（每個 Zone 各一組，互相獨立）。
    /// 真實演算法請把「該 Zone 的 ROI、Golden 檔名與所有檢測參數」放在這個類別。
    /// 加 ExpandableObjectConverter，PropertyGrid 才能把每個 Zone 展開成一個群組。
    /// </summary>
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class MockZoneParameter
    {
        [Category("1.Zone")]
        [DisplayName("Name")]
        [Description("Zone 名稱，僅供 UI 顯示；上報與結果以序號為準")]
        public string Name { get; set; } = "Zone";

        [Category("1.Zone")]
        [DisplayName("Golden File")]
        [Description("該 Zone 的黃金樣板檔名（黑底白色 panel），放在 Config 檔同一資料夾（Mock 不使用）")]
        public string GoldenFile { get; set; } = "";

        // 注意：Zone 參數只放「該 Zone 的檢測參數」（真實演算法的 ROI、門檻等）。
        //       檢測類別（線 / 面缺陷）的啟用開關放在 Config 最上層，對所有 Zone 一律相同。
        [Category("2.Simulation")]
        [DisplayName("Simulate Line NG")]
        [Description("線缺陷檢測啟用時，讓此 Zone 判為 TM1500（僅 Mock 使用）")]
        public bool SimulateLineNg { get; set; }

        [Category("2.Simulation")]
        [DisplayName("Simulate Surface NG")]
        [Description("面缺陷檢測啟用時，讓此 Zone 判為 TM6000（僅 Mock 使用）")]
        public bool SimulateSurfaceNg { get; set; }

        public MockZoneParameter Clone()
        {
            return new MockZoneParameter
            {
                Name              = Name,
                GoldenFile        = GoldenFile,
                SimulateLineNg    = SimulateLineNg,
                SimulateSurfaceNg = SimulateSurfaceNg
            };
        }
    }

    /// <summary>
    /// 模擬演算法的參數（示範 IAlgorithmConfig 的標準寫法）。
    /// 整體參數（檢測類別啟用、細項存檔設定）放最上層，Zone 參數放 Zones 列表；
    /// 每個參數標 [Category]/[DisplayName]/[Description]，Load 逐欄位複製、不換物件參考。
    /// </summary>
    [XmlRoot("MockAlgorithmConfig")]
    public class MockAlgorithmConfig : IAlgorithmConfig
    {
        // ── 整體參數：對所有 Zone 一律相同 ──────────────────────────

        [Category("1.Inspect")]
        [DisplayName("Enable Surface Defect")]
        [Description("啟用面缺陷檢測")]
        public bool EnableSurfaceDefect { get; set; } = true;

        [Category("1.Inspect")]
        [DisplayName("Enable Line Defect")]
        [Description("啟用線缺陷檢測（介面保留，真實演算法目前尚未實作）")]
        public bool EnableLineDefect { get; set; } = true;

        [Category("2.Output")]
        [DisplayName("Detail Save Folder")]
        [Description("演算法自行存放細項結果（逐張、逐區塊、影像）的資料夾；空白 = 不存（Mock 不使用）")]
        public string DetailSaveFolder { get; set; } = "";

        // ── Zone 參數 ───────────────────────────────────────────────

        /// <summary>各 Zone 的參數；Zones[i] 即第 i 個 Zone。XmlSerializer 不支援 Dictionary，所以用 List。</summary>
        [Category("3.Zone")]
        [DisplayName("Zones")]
        [Description("每個 Zone 各自一組參數；第 i 個 Zone 只套用第 i 組")]
        // ★ 陷阱：XmlSerializer 反序列化時，會把檔案內容「加進」屬性上已存在的 List，
        //   若這裡用集合初始設定式放預設 Zone，讀檔後 Zone 會重複。
        //   所以必須宣告為空列表；預設值改由 CreateDefaultZones() 在需要時填入。
        public List<MockZoneParameter> Zones { get; set; } = new List<MockZoneParameter>();

        /// <summary>預設的 Zone 參數（演算法建構時，若 Zones 為空才填入）。</summary>
        public static List<MockZoneParameter> CreateDefaultZones()
        {
            return new List<MockZoneParameter>
            {
                new MockZoneParameter { Name = "Zone 0" },
                new MockZoneParameter { Name = "Zone 1", SimulateLineNg = true }
            };
        }

        /// <summary>Zone 數量 = Zones.Count（IAlgorithmConfig 要求對外公開）。</summary>
        [XmlIgnore]
        [Browsable(false)]
        public int ZoneCount
        {
            get { return Zones.Count; }
        }

        public void Save(string path)
        {
            var serializer = new XmlSerializer(typeof(MockAlgorithmConfig));
            using (var writer = new StreamWriter(path))
                serializer.Serialize(writer, this);
        }

        public void Load(string path)
        {
            if (!File.Exists(path)) return;

            var serializer = new XmlSerializer(typeof(MockAlgorithmConfig));
            using (var reader = new StreamReader(path))
            {
                var loaded = (MockAlgorithmConfig)serializer.Deserialize(reader);

                // 逐欄位複製，不換 Config 物件參考（UI 已繫結）
                EnableSurfaceDefect = loaded.EnableSurfaceDefect;
                EnableLineDefect    = loaded.EnableLineDefect;
                DetailSaveFolder    = loaded.DetailSaveFolder;

                // 不換 List 物件參考：清空後逐一加入複本
                Zones.Clear();
                foreach (var z in loaded.Zones)
                    Zones.Add(z.Clone());
            }
        }
    }

    /// <summary>
    /// 模擬演算法：不做任何真實影像處理，只依 Config 產生固定結果，
    /// 用來讓平台端在真實演算法完成前先把「呼叫流程」跑通。
    /// 同時示範實作端必須遵守的契約：
    ///   · 不拋例外、out 先給安全值
    ///   · PushFrame 快速返回；可持有平台傳入的 Mat，但 StopInspect / AbortInspect 返回前必須放掉所有參照
    ///   · 序列狀態機：Idle → Collecting → (StopInspect / AbortInspect) → Idle；Fault 使序列失效
    ///   · StopInspect 只輸出「各 Zone 統整結果 + 整體結果」；細項由演算法自行存檔
    ///
    /// 真實演算法的 PushFrame 只需「驗證 + 排入內部佇列」，
    /// 裁切、判穩、對位、檢測都由內部工作執行緒處理；PushFrame 只回傳 Accepted 或 Fault。
    /// Mock 不處理影像內容，只記錄張數。
    /// </summary>
    public class MockAlgorithm : IAlgorithm
    {
        #region ConfigData

        private readonly MockAlgorithmConfig _config = new MockAlgorithmConfig();

        public IAlgorithmConfig Config
        {
            get { return _config; }
        }

        #endregion

        #region Fields

        private enum SessionState { Idle, Collecting, Faulted }

        private readonly object _sync = new object();
        private readonly ILogService _log;
        private bool _disposed;

        // ── 序列狀態（受 _sync 保護）──
        private SessionState _state = SessionState.Idle;
        private string _taskId;
        private bool[] _emptyZones;
        private int _zoneCount;
        private Size _frameSize;       // 第 0 張決定，之後必須一致
        private int _acceptedCount;

        public string Name
        {
            get { return "MockAlgorithm v2.1 (streaming)"; }
        }

        #endregion

        #region Constructor

        public MockAlgorithm(ILogService log)
        {
            _log = log;

            // Config 尚未載入前先放預設 Zone 參數，讓 ZoneCount 與 Save 的預設檔可用
            if (_config.Zones.Count == 0)
                _config.Zones.AddRange(MockAlgorithmConfig.CreateDefaultZones());
        }

        #endregion

        #region MainFunction

        public bool StartInspect(string taskId, bool[] emptyZones)
        {
            try
            {
                lock (_sync)
                {
                    if (_state != SessionState.Idle)
                    {
                        // 上一個序列尚未結束：不動原序列，直接回傳 false
                        _log.Error("[" + Name + "] 上一個序列尚未結束（請先 StopInspect 或 AbortInspect）。");
                        return false;
                    }

                    if (string.IsNullOrEmpty(taskId))
                    {
                        _log.Error("[" + Name + "] taskId 不可為空。");
                        return false;
                    }

                    int zoneCount = _config.ZoneCount;
                    if (emptyZones == null || emptyZones.Length != zoneCount)
                    {
                        _log.Error("[" + Name + "] emptyZones 長度必須等於 Zone 數 " + zoneCount + "。");
                        return false;
                    }
                    if (!_config.EnableSurfaceDefect && !_config.EnableLineDefect)
                    {
                        _log.Error("[" + Name + "] Config 未啟用任何檢測類別。");
                        return false;
                    }
                    // 真實演算法此處還要確認「非空工位」的 Golden 檔存在且可載入；缺失 → return false

                    // 真實演算法：把 taskId 記下，之後自行存檔細項時用作資料夾 / 檔名
                    _taskId        = taskId;
                    _zoneCount     = zoneCount;
                    _emptyZones    = (bool[])emptyZones.Clone();   // 不保留平台的陣列參照
                    _frameSize     = new Size(0, 0);
                    _acceptedCount = 0;
                    _state         = SessionState.Collecting;
                    return true;
                }
            }
            catch (Exception ex)
            {
                _log.Error("[" + Name + "] StartInspect failed: " + ex.Message);
                lock (_sync) { ResetToIdle(); }
                return false;
            }
        }

        public PushResult PushFrame(Mat frame)
        {
            try
            {
                lock (_sync)
                {
                    if (_state != SessionState.Collecting)
                    {
                        // 尚未 Start、或序列已 Fault
                        _log.Error("[" + Name + "] PushFrame：目前沒有進行中的序列。");
                        return PushResult.Fault;
                    }
                    if (frame == null || frame.Empty() || frame.Type() != MatType.CV_8UC3)
                    {
                        _log.Error("[" + Name + "] PushFrame：影像為空或格式不是 BGR 8UC3。");
                        _state = SessionState.Faulted;
                        return PushResult.Fault;
                    }
                    if (_acceptedCount == 0)
                    {
                        _frameSize = frame.Size();
                    }
                    else if (frame.Size() != _frameSize)
                    {
                        _log.Error("[" + Name + "] PushFrame：影像尺寸與第 0 張不一致。");
                        _state = SessionState.Faulted;
                        return PushResult.Fault;
                    }

                    // 真實演算法：此處可直接持有 frame 參照（或自行複製 ROI）排入佇列。
                    //             契約：平台會保留 frame 到 StopInspect / AbortInspect 返回後才 Dispose，
                    //             所以演算法必須在這兩個方法返回前放掉所有參照（含背景執行緒）。
                    _acceptedCount++;
                    return PushResult.Accepted;
                }
            }
            catch (Exception ex)
            {
                _log.Error("[" + Name + "] PushFrame failed: " + ex.Message);
                lock (_sync) { _state = SessionState.Faulted; }
                return PushResult.Fault;
            }
        }

        public bool StopInspect(out InspectResult result, CancellationToken cancellationToken)
        {
            // ── 契約：out 參數必須在第一行就給定安全值（不可為 null）──
            result = new InspectResult { IsOk = false, Type = DefectCode.Ok, Zones = new ZoneResult[0] };

            try
            {
                lock (_sync)
                {
                    // 不論成功失敗，離開時一律回到 Idle（見 finally）
                    if (_state != SessionState.Collecting)
                    {
                        _log.Error("[" + Name + "] StopInspect：序列不存在或已失效。");
                        return false;
                    }
                    if (_acceptedCount == 0)
                    {
                        _log.Error("[" + Name + "] StopInspect：一張影像都沒收到。");
                        return false;
                    }
                    // 真實演算法：此處等待內部佇列處理完，等待期間定期檢查取消
                    if (cancellationToken.IsCancellationRequested)
                    {
                        _log.Debug("[" + Name + "] 被取消。");
                        return false;
                    }

                    // Step 1: 逐 Zone 決定統整結果（Mock：依 Config 固定指定）
                    var zones = new ZoneResult[_zoneCount];
                    for (int z = 0; z < _zoneCount; z++)
                    {
                        // 每個 Zone 只套用「自己那一組」參數：_config.Zones[z]
                        MockZoneParameter p = _config.Zones[z];
                        string type = DefectCode.Ok;
                        if (!_emptyZones[z])
                        {
                            if (_config.EnableLineDefect && p.SimulateLineNg)
                                type = DefectCode.Tm1500;
                            else if (_config.EnableSurfaceDefect && p.SimulateSurfaceNg)
                                type = DefectCode.Tm6000;
                        }
                        zones[z] = new ZoneResult { Index = z, Type = type };
                    }

                    // Step 2: 整體結果；細項（逐張、逐區塊、影像）由演算法依 Config.DetailSaveFolder 自行存檔，
                    //         不經由介面回傳（Mock 不存）
                    string overallType = DefectCode.Ok;
                    foreach (var zr in zones)
                        if (!zr.IsOk) overallType = zr.Type;          // 最後一個 NG Zone 的 Type

                    result = new InspectResult
                    {
                        IsOk  = overallType == DefectCode.Ok,
                        Type  = overallType,
                        Zones = zones
                    };
                    return true;
                }
            }
            catch (Exception ex)
            {
                // ── 契約：攔下所有例外，回傳 false，絕不往上 throw ──
                _log.Error("[" + Name + "] StopInspect failed: " + ex.Message);
                result = new InspectResult { IsOk = false, Type = DefectCode.Ok, Zones = new ZoneResult[0] };
                return false;
            }
            finally
            {
                // 序列一律結束
                lock (_sync) { ResetToIdle(); }
            }
        }

        public void AbortInspect()
        {
            try
            {
                lock (_sync) { ResetToIdle(); }
            }
            catch (Exception ex)
            {
                _log.Error("[" + Name + "] AbortInspect failed: " + ex.Message);
            }
        }

        #endregion

        #region PrivateTools

        // 呼叫時必須已持有 _sync
        private void ResetToIdle()
        {
            _taskId        = null;
            _emptyZones    = null;
            _acceptedCount = 0;
            _state         = SessionState.Idle;
        }

        #endregion

        #region IDisposable

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;
            _disposed = true;
            if (disposing)
            {
                lock (_sync) { ResetToIdle(); }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
