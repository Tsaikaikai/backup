using AgingAOI.Core.Models;
using OpenCvSharp;
using System.Threading;

namespace AgingAOI.Core.Interfaces
{
    /// <summary>
    /// 演算法抽象介面（串流版）。
    /// 所有演算法都必須實作此介面，確保平台端呼叫方式統一，演算法可無縫替換。
    ///
    /// 一次檢測 = 一個「序列（Session）」：同一載具上最多 ZoneCount 個工位（Zone）的 panel，
    /// 連續拍攝 N 張整張原圖。平台「取到一張就餵一張」，演算法收到後自行決定處理順序與平行度，
    /// 全部送完後由平台呼叫 StopInspect 取得最終結果。
    /// 演算法只管「輸入影像 + 參數 → 檢測結果」，不處理機台名稱、檔案路徑、
    /// 網路、報告與流程。
    ///
    /// 【輸出範圍】StopInspect 只輸出「每個 Zone 一筆統整結果 + 整體結果」。
    /// 逐張、逐區塊、影像等細項結果由演算法自行存檔（是否存、存到哪，由演算法自己的 Config 決定），
    /// 不經由介面回傳給平台。
    ///
    /// 【檢測類別】線缺陷 / 面缺陷要檢測哪些，由演算法 Config 的檢測參數決定（對所有 Zone 一律相同），
    /// 不透過介面傳入。
    ///
    /// ════════════════════════════════════════════════════════════
    /// 【呼叫流程】
    ///
    ///   Idle ──StartInspect──► Collecting ──PushFrame × N──► Collecting
    ///                                                           │
    ///                          StopInspect（阻塞到算完）◄────────┘
    ///                               │ 不論 true / false，回到 Idle
    ///                               ▼
    ///                             Idle
    ///
    ///   任何時候可呼叫 AbortInspect() 放棄本次序列並回到 Idle（例如 panel 被取走、流程中斷）。
    ///
    ///   · 一個 IAlgorithm 實例同一時間只處理一個序列；序列未結束（未 StopInspect / AbortInspect）
    ///     就再呼叫 StartInspect 視為流程異常，回傳 false。
    ///   · PushFrame 必須依拍攝順序、由同一條執行緒逐張呼叫（演算法的穩定判斷依賴前後張順序）。
    ///   · StartInspect / StopInspect / AbortInspect 不可與 PushFrame 同時呼叫。
    ///
    /// 【例外契約】—— 本介面採「不拋例外」設計
    ///
    ///   Start / Push / Stop / Abort 內部必須用 try-catch 把所有例外攔下來，
    ///   轉成「回傳 false / PushResult.Fault」交給平台層處理（平台記為 Fault，不計入良率）。
    ///   序列一旦發生 Fault，本序列即失效：之後的 PushFrame 一律回傳 Fault，
    ///   StopInspect 回傳 false（並回到 Idle）。
    ///
    ///   ✕ 錯誤示範： catch (Exception ex) { throw new Exception(...); }
    ///   ○ 正確示範： catch (Exception ex) { /* 記錄、釋放已建立的資源 */ return false; }
    ///
    ///   唯一例外：建構子載入模型 / 樣板失敗時，可丟 AlgorithmException
    ///   （啟動階段問題，應讓系統直接進 Error 狀態）。
    /// ════════════════════════════════════════════════════════════
    ///
    /// 【判定責任】
    ///   本介面由演算法直接判定每個 Zone 的 OK / NG（ZoneResult.Type）以及整體結果
    ///   （InspectResult.IsOk / Type）。不再有單一 score，也不使用 RecipeData.NgThreshold。
    /// </summary>
    public interface IAlgorithm : IDevice
    {
        /// <summary>
        /// 演算法參數（含檢測類別啟用設定）。平台端透過此屬性統一存取 / 儲存參數，
        /// 不需要知道具體是哪一個 Config 類別。
        /// </summary>
        IAlgorithmConfig Config { get; }

        /// <summary>
        /// 開始一個檢測序列。每片載具檢測前呼叫一次。
        /// ──────────────────────────────────────────────
        /// 演算法在此階段完成：驗證參數、載入 / 確認各 Zone 的黃金樣板（Golden）、
        /// 建立各 Zone 狀態、啟動內部處理佇列。
        /// ──────────────────────────────────────────────
        /// </summary>
        /// <param name="taskId">
        /// 本次檢測的識別字串（例如載具 ID / 檢測單號），由平台提供。
        /// 演算法自行存檔細項結果時，以此作為資料夾 / 檔名的一部分，使檔案可對應回平台的檢測單。
        /// 不可為 null 或空字串（否則回傳 false）；演算法存檔時須自行處理檔名不合法字元。
        /// 演算法不修改、不解讀其內容，也不會出現在 InspectResult 中。
        /// </param>
        /// <param name="emptyZones">
        /// 長度 = Config.ZoneCount。true = 該工位沒有放 panel（空工位），不檢測，
        /// 其 ZoneResult.Type 回傳 "OK"。
        /// 任何序號的工位都可以為空，例如 4 個工位的第 2 個為空 = {false, true, false, false}。
        /// 長度與 ZoneCount 不符視為流程異常，回傳 false。
        /// 換機型（重新 Config.Load）後 ZoneCount 可能改變，平台須重新讀取。
        /// 每個 Zone 套用 Config 中「該 Zone 自己」的一組參數（第 i 個 Zone 用第 i 組）。
        /// </param>
        /// <returns>
        /// true  = 序列已開始，可以開始 PushFrame。<br/>
        /// false = 無法開始（參數 / 樣板缺失、taskId 為空、輸入不合法、未啟用任何檢測類別、上一個序列尚未結束等），
        ///         狀態維持 Idle（若是「上一個序列尚未結束」，則維持原序列不受影響）。
        /// </returns>
        bool StartInspect(string taskId, bool[] emptyZones);

        /// <summary>
        /// 餵入一張影像。平台每取到一張就呼叫一次，演算法收到後即可開始處理，
        /// 之後的處理順序、平行度、何時裁切 / 判穩 / 檢測，全由演算法自行決定，平台不需關心。
        /// ──────────────────────────────────────────────
        /// 必須「快速返回」：只做驗證、排入內部佇列，不得在此做完整檢測。
        /// 結果只有 Accepted 或 Fault，沒有「忙碌 / 稍後重送」：演算法內部佇列不設上限阻擋，
        /// 處理速度跟不上時只是累積，由演算法自行負責（序列只有 50~60 張，總量有限）。
        /// ──────────────────────────────────────────────
        /// 【影像生命週期】Accepted 之後，frame 仍可能被演算法內部持續使用（不一定有複製），
        /// 因此平台「不可」在 PushFrame 返回後立刻釋放。
        /// 平台須等到 StopInspect 或 AbortInspect 呼叫結束（序列回到 Idle）後，才可 Dispose 該序列餵入的所有影像。
        /// </summary>
        /// <param name="frame">
        /// 一張整張原圖。格式：BGR、8UC3。所有張的尺寸必須一致（實機 5472x3648）。
        /// 所有權屬呼叫端：演算法不可 Dispose，也不可修改其像素內容。
        /// 演算法可以持有 frame 的參照直到序列結束，但在 StopInspect / AbortInspect 返回前，
        /// 必須放掉所有對 frame 的參照（含內部佇列、背景執行緒仍在使用的部分），
        /// 否則平台 Dispose 後會存取到已釋放的記憶體。
        /// 平台在序列期間也不可修改 frame 的像素。
        /// </param>
        /// <returns>
        /// Accepted  = 已收下。此張的張序 = 目前為止被 Accepted 的張數（0 起算）。
        ///             平台須保留該 Mat（不可 Dispose）到序列結束。<br/>
        /// Fault     = 流程異常（尚未 StartInspect、影像為空 / 格式 / 尺寸不符、序列已失效等）。
        ///             本序列失效，平台應呼叫 AbortInspect() 或 StopInspect() 收尾並記為 Fault，
        ///             再釋放該序列所有影像。
        /// </returns>
        PushResult PushFrame(Mat frame);

        /// <summary>
        /// 通知「影像已全部送完」，並取得最終結果。
        /// 會阻塞到演算法把已收下的所有張處理完為止；回傳後（不論 true / false）序列結束、回到 Idle，
        /// 此時演算法已不再持有任何影像參照，平台才可以 Dispose 該序列餵入的所有影像。
        /// </summary>
        /// <param name="result">
        /// 【結果】逐 Zone 統整結果 + 整體結果。不得為 null。
        /// 平台上報只依 ZoneResult.Type / InspectResult.IsOk / InspectResult.Type。
        /// 回傳 false 時內容無效（Zones 為空陣列），不可使用。
        /// </param>
        /// <param name="cancellationToken">取消信號；長時間等待 / 迴圈請定期檢查，被取消時回傳 false。</param>
        /// <returns>
        /// true  = 演算法流程完整走完，result 有效。<br/>
        /// false = 流程中途異常（序列失效、一張都沒收到、影像 / 參數 / 樣板問題、被取消等），
        ///         result 無效。實作端絕對不可以改成拋例外，請見上方例外契約。
        /// </returns>
        bool StopInspect(out InspectResult result, CancellationToken cancellationToken);

        /// <summary>
        /// 放棄目前序列：停止處理（等背景工作停下）、放掉所有影像參照與中間資料、回到 Idle。
        /// 回傳後平台才可以 Dispose 該序列餵入的所有影像。
        /// 在 Idle 呼叫為空操作。不拋例外。
        /// </summary>
        void AbortInspect();
    }
}
