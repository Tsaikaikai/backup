﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RepairLightCtrl
{
    public partial class MainForm : Form
    {
        private string ConfigPath = @"D:\LightCtrl\";
        private LightConfig Config = new LightConfig();
        private Button[] BtnLen;

        private LitSourceLight RGBW = new LitSourceLight("RGBW");
        private LitSourceLight IR = new LitSourceLight("IR");

        private LenBrightnessParam[] LenPara;

        private Color CheckColor = Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
        private Color UnCheckColor = Color.Silver;
        private int LenIdx = -1;
        private int UploadIdx = -1;


        public MainForm()
        {
            InitializeComponent();
        }


        private void MainForm_Load(object sender, EventArgs e)
        {
            BtnLen = new Button[] { BtnLen1, BtnLen2, BtnLen3, BtnLen4, BtnLen5, BtnLen6, BtnLen7 };

            if (!Directory.Exists(ConfigPath))
            {
                Directory.CreateDirectory(ConfigPath);
            }

            LoadConfig();
            LightInit();
            GetBrightness();
        }

        private void LoadConfig()
        {
            string Path = $@"{ConfigPath}\Config.xml";
            if (!File.Exists(Path))
            {
                Config.Create(Config, Path);
            }
            else
            {
                Config = Config.Read(Path);
            }

            PropertyGrid_Config.SelectedObject = Config;

            LenPara = new LenBrightnessParam[]
            {
                Config.LenSetting_1,
                Config.LenSetting_2,
                Config.LenSetting_3,
                Config.LenSetting_4,
                Config.LenSetting_5,
                Config.LenSetting_6,
                Config.LenSetting_7,
            };
        }

        private void LightInit()
        {
            if (!RGBW.Connect(Config.LightSetting_Color.Comport))
            {
                MessageBox.Show("光源開啟失敗 - R/G/B/W");
            }

            if (!IR.Connect(Config.LightSetting_IR.Comport))
            {
                MessageBox.Show("光源開啟失敗 - IR");
            }
        }

        private void GetBrightness()
        {
            int R = RGBW.GetBrightness(Config.LightSetting_Color.Channel_R);
            int G = RGBW.GetBrightness(Config.LightSetting_Color.Channel_G);
            int B = RGBW.GetBrightness(Config.LightSetting_Color.Channel_B);
            int W = RGBW.GetBrightness(Config.LightSetting_Color.Channel_W);
            int IR = RGBW.GetBrightness(Config.LightSetting_IR.Channel_IR);

            BarR.Value = R;
            BarG.Value = G;
            BarB.Value = B;
            BarW.Value = W;
            BarIR.Value = IR;

            TbxR.Text = $"{R}";
            TbxG.Text = $"{G}";
            TbxB.Text = $"{B}";
            TbxW.Text = $"{W}";
            TbxIR.Text = $"{IR}";
        }

        private void ChangeLen(object sender, EventArgs e)
        {
            Button SourceBtn = (Button)sender;

            foreach (Button Btn in BtnLen)
            {
                Btn.BackColor = (Btn == SourceBtn) ? CheckColor : UnCheckColor;
            }

            LenIdx = Convert.ToInt32(SourceBtn.Tag.ToString());

            RefreshStatus();

            SetBrightness(LightType.R, BarR.Value);
            SetBrightness(LightType.G, BarG.Value);
            SetBrightness(LightType.B, BarB.Value);
            SetBrightness(LightType.W, BarW.Value);
            SetBrightness(LightType.IR, BarIR.Value);
        }

        private void RefreshStatus()
        {
            int Brightness_R = LenPara[LenIdx - 1].Brightness_R;
            if (Brightness_R > 100) Brightness_R = 100;
            if (Brightness_R < 0) Brightness_R = 0;

            int Brightness_G = LenPara[LenIdx - 1].Brightness_G;
            if (Brightness_G > 100) Brightness_G = 100;
            if (Brightness_G < 0) Brightness_G = 0;

            int Brightness_B = LenPara[LenIdx - 1].Brightness_B;
            if (Brightness_B > 100) Brightness_B = 100;
            if (Brightness_B < 0) Brightness_B = 0;

            int Brightness_W = LenPara[LenIdx - 1].Brightness_W;
            if (Brightness_W > 100) Brightness_W = 100;
            if (Brightness_W < 0) Brightness_W = 0;

            int Brightness_IR = LenPara[LenIdx - 1].Brightness_IR;
            if (Brightness_IR > 100) Brightness_IR = 100;
            if (Brightness_IR < 0) Brightness_IR = 0;

            BarR.Value = Brightness_R;
            TbxR.Text = $"{Brightness_R}";

            BarG.Value = Brightness_G;
            TbxG.Text = $"{Brightness_G}";

            BarB.Value = Brightness_B;
            TbxB.Text = $"{Brightness_B}";

            BarW.Value = Brightness_W;
            TbxW.Text = $"{Brightness_W}";

            BarIR.Value = Brightness_IR;
            TbxIR.Text = $"{Brightness_IR}";
        }

        private void SetBrightness(LightType Light, int Brightness)
        {
            bool Result = false;
            int[] Channel = new int[]
            {
                Config.LightSetting_Color.Channel_R,
                Config.LightSetting_Color.Channel_G,
                Config.LightSetting_Color.Channel_B,
                Config.LightSetting_Color.Channel_W,
                Config.LightSetting_IR.Channel_IR
            };

            switch (Light)
            {
                case LightType.R:
                case LightType.G:
                case LightType.B:
                case LightType.W:
                    Result = RGBW.SetBrightness(Channel[(int)Light], Brightness);
                    break;

                case LightType.IR:
                    Result = IR.SetBrightness(Channel[(int)Light], Brightness);
                    break;
            }

            if (Result == false)
            {
                MessageBox.Show($"光源設定失敗({Light}) , Channel={Channel[(int)Light]}, Brightness={Brightness}");
            }
        }


        private void BtnSave_Click(object sender, EventArgs e)
        {
            string Path = $@"{ConfigPath}\Config.xml";
            Config.Create(Config, Path);
            LoadConfig();
            MessageBox.Show("Save & Reload !!");
        }

        private enum LightType
        {
            R,
            G,
            B,
            W,
            IR
        }

        private void BarScroll(object sender, EventArgs e)
        {
            TrackBar SourceCtrl = (TrackBar)sender;

            switch (SourceCtrl.Tag.ToString())
            {
                case "R":
                    SetBrightness(LightType.R, BarR.Value);
                    TbxR.Text = $"{BarR.Value}";
                    break;

                case "G":
                    SetBrightness(LightType.G, BarG.Value);
                    TbxG.Text = $"{BarG.Value}";
                    break;

                case "B":
                    SetBrightness(LightType.B, BarB.Value);
                    TbxB.Text = $"{BarB.Value}";
                    break;

                case "W":
                    SetBrightness(LightType.W, BarW.Value);
                    TbxW.Text = $"{BarW.Value}";
                    break;

                case "IR":
                    SetBrightness(LightType.IR, BarIR.Value);
                    TbxIR.Text = $"{BarIR.Value}";
                    break;
            }
        }

        private void TbxValidated(object sender, EventArgs e)
        {
            try
            {
                TextBox SourceCtrl = (TextBox)sender;

                switch (SourceCtrl.Tag.ToString())
                {
                    case "R":
                        BarR.Value = Convert.ToInt32(TbxR.Text);
                        SetBrightness(LightType.R, BarR.Value);
                        break;

                    case "G":
                        BarG.Value = Convert.ToInt32(TbxG.Text);
                        SetBrightness(LightType.G, BarG.Value);
                        break;

                    case "B":
                        BarB.Value = Convert.ToInt32(TbxB.Text);
                        SetBrightness(LightType.B, BarB.Value);
                        break;

                    case "W":
                        BarW.Value = Convert.ToInt32(TbxW.Text);
                        SetBrightness(LightType.W, BarW.Value);
                        break;

                    case "IR":
                        BarIR.Value = Convert.ToInt32(TbxIR.Text);
                        SetBrightness(LightType.IR, BarIR.Value);
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TbxR_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    TextBox SourceCtrl = (TextBox)sender;

                    switch (SourceCtrl.Tag.ToString())
                    {
                        case "R":
                            BarR.Focus();
                            break;

                        case "G":
                            BarG.Focus();
                            break;

                        case "B":
                            BarB.Focus();
                            break;

                        case "W":
                            BarW.Focus();
                            break;

                        case "IR":
                            BarIR.Focus();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show($"覆寫 Led {UploadIdx + 1} 參數?", "覆寫參數確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                LenPara[UploadIdx].Brightness_R = BarR.Value;
                LenPara[UploadIdx].Brightness_G = BarG.Value;
                LenPara[UploadIdx].Brightness_B = BarB.Value;
                LenPara[UploadIdx].Brightness_W = BarW.Value;
                LenPara[UploadIdx].Brightness_IR = BarIR.Value;

                string Path = $@"{ConfigPath}\Config.xml";
                Config.Create(Config, Path);
                LoadConfig();
                MessageBox.Show("Update & Save !!");
            }
        }

        private void Menu_Len_Opening(object sender, CancelEventArgs e)
        {
            Control Ctrl = (sender as ContextMenuStrip).SourceControl;
            UploadIdx = Convert.ToInt32(Ctrl.Tag.ToString()) - 1;

        }
    }


}
