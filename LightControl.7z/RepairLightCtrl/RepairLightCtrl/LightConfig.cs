﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RepairLightCtrl
{
    public class LightConfig
    {
        public void Create(LightConfig clsRecipe, string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(LightConfig));
            TextWriter writer = new StreamWriter(filename);
            serializer.Serialize(writer, clsRecipe);
            writer.Close();
        }

        public LightConfig Read(string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(LightConfig));
            FileStream fp = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            LightConfig Sfp = (LightConfig)serializer.Deserialize(fp);
            fp.Close();
            return Sfp;
        }

        private ColorLightParam _LightSetting_Color = new ColorLightParam();  
        [Category("0. 基本設定"),DisplayName("0.0. R/G/B/W 光源設定")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public ColorLightParam LightSetting_Color
        {
            get { return _LightSetting_Color; }
            set { _LightSetting_Color = value; }
        }

        private IRLightParam _LightSetting_IR = new IRLightParam();
        [Category("0. 基本設定"), DisplayName("0.1. IR 光源設定")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public IRLightParam LightSetting_IR
        {
            get { return _LightSetting_IR; }
            set { _LightSetting_IR = value; }
        }

        private LenBrightnessParam _LenSetting_1 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.0. 亮度設定 (Len 1)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_1
        {
            get { return _LenSetting_1; }
            set { _LenSetting_1 = value; }
        }

        private LenBrightnessParam _LenSetting_2 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.1. 亮度設定 (Len 2)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_2
        {
            get { return _LenSetting_2; }
            set { _LenSetting_2 = value; }
        }

        private LenBrightnessParam _LenSetting_3 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.2. 亮度設定 (Len 3)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_3
        {
            get { return _LenSetting_3; }
            set { _LenSetting_3 = value; }
        }

        private LenBrightnessParam _LenSetting_4 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.3. 亮度設定 (Len 4)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_4
        {
            get { return _LenSetting_4; }
            set { _LenSetting_4 = value; }
        }

        private LenBrightnessParam _LenSetting_5 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.4. 亮度設定 (Len 5)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_5
        {
            get { return _LenSetting_5; }
            set { _LenSetting_5 = value; }
        }

        private LenBrightnessParam _LenSetting_6 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.5. 亮度設定 (Len 6)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_6
        {
            get { return _LenSetting_6; }
            set { _LenSetting_6 = value; }
        }

        private LenBrightnessParam _LenSetting_7 = new LenBrightnessParam();
        [Category("1. 亮度設定"), DisplayName("1.6. 亮度設定 (Len 7)")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public LenBrightnessParam LenSetting_7
        {
            get { return _LenSetting_7; }
            set { _LenSetting_7 = value; }
        }
    }

    public class ColorLightParam
    {
        private int _Comport;
        [DisplayName("0. Comport設定 (R/G/B/W)")]
        public int Comport
        {
            get { return _Comport; }
            set { _Comport = value; }
        }

        private int _Channel_R;
        [DisplayName("1. Channel設定 (R)")]
        public int Channel_R
        {
            get { return _Channel_R; }
            set { _Channel_R = value; }
        }

        private int _Channel_G;
        [DisplayName("2. Channel設定 (G)")]
        public int Channel_G
        {
            get { return _Channel_G; }
            set { _Channel_G = value; }
        }

        private int _Channel_B;
        [DisplayName("3. Channel設定 (B)")]
        public int Channel_B
        {
            get { return _Channel_B; }
            set { _Channel_B = value; }
        }

        private int _Channel_W;
        [DisplayName("4. Channel設定 (W)")]
        public int Channel_W
        {
            get { return _Channel_W; }
            set { _Channel_W = value; }
        }

        public override string ToString()
        {
            return "";
        }

    }

    public class IRLightParam
    {
        private int _Comport;
        [DisplayName("0. Comport設定 (IR)")]
        public int Comport
        {
            get { return _Comport; }
            set { _Comport = value; }
        }

        private int _Channel_IR;
        [DisplayName("1. Channel設定 (IR)")]
        public int Channel_IR
        {
            get { return _Channel_IR; }
            set { _Channel_IR = value; }
        }
             
        public override string ToString()
        {
            return "";
        }
    }

    public class LenBrightnessParam
    {
        private int _Brightness_R;
        [DisplayName("0. 亮度設定 (R)")]
        public int Brightness_R
        {
            get { return _Brightness_R; }
            set { _Brightness_R = value; }
        }

        private int _Brightness_G;
        [DisplayName("1. 亮度設定 (G)")]
        public int Brightness_G
        {
            get { return _Brightness_G; }
            set { _Brightness_G = value; }
        }

        private int _Brightness_B;
        [DisplayName("2. 亮度設定 (B)")]
        public int Brightness_B
        {
            get { return _Brightness_B; }
            set { _Brightness_B = value; }
        }

        private int _Brightness_W;
        [DisplayName("3. 亮度設定 (W)")]
        public int Brightness_W
        {
            get { return _Brightness_W; }
            set { _Brightness_W = value; }
        }

        private int _Brightness_IR;
        [DisplayName("4. 亮度設定 (IR)")]
        public int Brightness_IR
        {
            get { return _Brightness_IR; }
            set { _Brightness_IR = value; }
        }

        public override string ToString()
        {
            return "";
        }
    }
}
