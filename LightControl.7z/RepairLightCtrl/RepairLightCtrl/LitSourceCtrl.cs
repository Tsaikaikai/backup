﻿using DimmerLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairLightCtrl
{
    class LitSourceLight
    {
        public event Action<string, bool> WriteLog;
        public event Action<bool> IsConnectEvent;
        private string DeviceName;
        private dimlib LightCtrl = null;

        private bool isConnect = false;

        public LitSourceLight(string Name)
        {
            this.DeviceName = Name;
        }

        public bool Connect(int Comport)
        {
            try
            {
                LightCtrl = new dimlib();
                isConnect = LightCtrl.OpenPort($"Com{Comport}", 115200);
                LightCtrl.GetModel();
                LightCtrl.GetBrightness();

                IsConnectEvent?.Invoke(isConnect);

                if (!isConnect)
                {
                    SaveLog($"Connect Fail - Com{Comport}", true);
                }
                return isConnect;
            }
            catch (Exception ex)
            {
                SaveLog((String.Format("[{0}]失敗 , 光源元件載入 - " + ex.Message, DeviceName)), true);
                return false;
            }
        }

        private void SaveLog(string Log, bool isAlm = false)
        {
            WriteLog?.Invoke("[" + DeviceName + "]- " + Log, isAlm);
        }

        public bool SetBrightness(int Channel, int Brightness)
        {
            if (!isConnect)
            {
                SaveLog($"Disconnect , Set Brightness Fail", true);
                return false;
            }

            switch (Channel)
            {
                case 1:
                    LightCtrl.BrightnessCH1 = (byte)(Brightness);
                    break;

                case 2:
                    LightCtrl.BrightnessCH2 = (byte)(Brightness);
                    break;

                case 3:
                    LightCtrl.BrightnessCH3 = (byte)(Brightness);
                    break;

                case 4:
                    LightCtrl.BrightnessCH4 = (byte)(Brightness);
                    break;

                case 5:
                    LightCtrl.BrightnessCH5 = (byte)(Brightness);
                    break;

                case 6:
                    LightCtrl.BrightnessCH6 = (byte)(Brightness);
                    break;

                case 7:
                    LightCtrl.BrightnessCH7 = (byte)(Brightness);
                    break;

                case 8:
                    LightCtrl.BrightnessCH8 = (byte)(Brightness);
                    break;
            }

            bool isOK = LightCtrl.SetBrightness();
            string LogStr = "";
            if (isOK)
            {
                LogStr = string.Format("設定光源亮度 ， Channel={0} ， Brightness={1}", Channel, Brightness);
            }
            else
            {
                LogStr = string.Format("設定光源亮度失敗 ， Channel={0} ， Brightness={1}", Channel, Brightness);
            }

            SaveLog(LogStr, !isOK);

            return isOK;
        }

        public int GetBrightness(int Channel)
        {
            bool isOK = LightCtrl.GetBrightness();

            int Brightness = 0;
            switch (Channel)
            {
                case 1:
                    Brightness = (int)LightCtrl.BrightnessCH1;
                    break;

                case 2:
                    Brightness = (int)LightCtrl.BrightnessCH2;
                    break;

                case 3:
                    Brightness = (int)LightCtrl.BrightnessCH3;
                    break;

                case 4:
                    Brightness = (int)LightCtrl.BrightnessCH4;
                    break;

                case 5:
                    Brightness = (int)LightCtrl.BrightnessCH5;
                    break;

                case 6:
                    Brightness = (int)LightCtrl.BrightnessCH6;
                    break;

                case 7:
                    Brightness = (int)LightCtrl.BrightnessCH7;
                    break;

                case 8:
                    Brightness = (int)LightCtrl.BrightnessCH8;
                    break;
            }

            return Brightness;
        }


        public void Close()
        {
            if (LightCtrl != null)
            {
                LightCtrl.ClosePort();
            }
        }   
    }
}
