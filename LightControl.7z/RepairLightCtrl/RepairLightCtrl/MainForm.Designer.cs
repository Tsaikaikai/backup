﻿
namespace RepairLightCtrl
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TbxIR = new System.Windows.Forms.TextBox();
            this.BarIR = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.TbxW = new System.Windows.Forms.TextBox();
            this.BarW = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.TbxB = new System.Windows.Forms.TextBox();
            this.BarB = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.TbxG = new System.Windows.Forms.TextBox();
            this.BarG = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.TbxR = new System.Windows.Forms.TextBox();
            this.BarR = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnLen1 = new System.Windows.Forms.Button();
            this.Menu_Len = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.BtnUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnLen7 = new System.Windows.Forms.Button();
            this.BtnLen2 = new System.Windows.Forms.Button();
            this.BtnLen6 = new System.Windows.Forms.Button();
            this.BtnLen3 = new System.Windows.Forms.Button();
            this.BtnLen5 = new System.Windows.Forms.Button();
            this.BtnLen4 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.PropertyGrid_Config = new System.Windows.Forms.PropertyGrid();
            this.Menu_Config = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.BtnSave = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarIR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarR)).BeginInit();
            this.Menu_Len.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.Menu_Config.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(728, 432);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.BtnLen1);
            this.tabPage1.Controls.Add(this.BtnLen7);
            this.tabPage1.Controls.Add(this.BtnLen2);
            this.tabPage1.Controls.Add(this.BtnLen6);
            this.tabPage1.Controls.Add(this.BtnLen3);
            this.tabPage1.Controls.Add(this.BtnLen5);
            this.tabPage1.Controls.Add(this.BtnLen4);
            this.tabPage1.Location = new System.Drawing.Point(4, 35);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(720, 393);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Control";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.TbxIR);
            this.panel1.Controls.Add(this.BarIR);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.TbxW);
            this.panel1.Controls.Add(this.BarW);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.TbxB);
            this.panel1.Controls.Add(this.BarB);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.TbxG);
            this.panel1.Controls.Add(this.BarG);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.TbxR);
            this.panel1.Controls.Add(this.BarR);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(708, 264);
            this.panel1.TabIndex = 7;
            // 
            // TbxIR
            // 
            this.TbxIR.BackColor = System.Drawing.Color.LightGray;
            this.TbxIR.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxIR.Location = new System.Drawing.Point(612, 217);
            this.TbxIR.Name = "TbxIR";
            this.TbxIR.Size = new System.Drawing.Size(85, 35);
            this.TbxIR.TabIndex = 15;
            this.TbxIR.Tag = "IR";
            this.TbxIR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TbxIR.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxR_KeyDown);
            this.TbxIR.Validated += new System.EventHandler(this.TbxValidated);
            // 
            // BarIR
            // 
            this.BarIR.LargeChange = 10;
            this.BarIR.Location = new System.Drawing.Point(50, 217);
            this.BarIR.Maximum = 100;
            this.BarIR.Name = "BarIR";
            this.BarIR.Size = new System.Drawing.Size(556, 45);
            this.BarIR.SmallChange = 5;
            this.BarIR.TabIndex = 14;
            this.BarIR.Tag = "IR";
            this.BarIR.Scroll += new System.EventHandler(this.BarScroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 35);
            this.label2.TabIndex = 13;
            this.label2.Text = "IR";
            // 
            // TbxW
            // 
            this.TbxW.BackColor = System.Drawing.Color.LightGray;
            this.TbxW.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxW.Location = new System.Drawing.Point(612, 166);
            this.TbxW.Name = "TbxW";
            this.TbxW.Size = new System.Drawing.Size(85, 35);
            this.TbxW.TabIndex = 12;
            this.TbxW.Tag = "W";
            this.TbxW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TbxW.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxR_KeyDown);
            this.TbxW.Validated += new System.EventHandler(this.TbxValidated);
            // 
            // BarW
            // 
            this.BarW.LargeChange = 10;
            this.BarW.Location = new System.Drawing.Point(50, 166);
            this.BarW.Maximum = 100;
            this.BarW.Name = "BarW";
            this.BarW.Size = new System.Drawing.Size(556, 45);
            this.BarW.SmallChange = 5;
            this.BarW.TabIndex = 11;
            this.BarW.Tag = "W";
            this.BarW.Scroll += new System.EventHandler(this.BarScroll);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(11, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 35);
            this.label5.TabIndex = 10;
            this.label5.Text = "W";
            // 
            // TbxB
            // 
            this.TbxB.BackColor = System.Drawing.Color.LightGray;
            this.TbxB.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxB.Location = new System.Drawing.Point(612, 115);
            this.TbxB.Name = "TbxB";
            this.TbxB.Size = new System.Drawing.Size(85, 35);
            this.TbxB.TabIndex = 9;
            this.TbxB.Tag = "B";
            this.TbxB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TbxB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxR_KeyDown);
            this.TbxB.Validated += new System.EventHandler(this.TbxValidated);
            // 
            // BarB
            // 
            this.BarB.LargeChange = 10;
            this.BarB.Location = new System.Drawing.Point(50, 115);
            this.BarB.Maximum = 100;
            this.BarB.Name = "BarB";
            this.BarB.Size = new System.Drawing.Size(556, 45);
            this.BarB.SmallChange = 5;
            this.BarB.TabIndex = 8;
            this.BarB.Tag = "B";
            this.BarB.Scroll += new System.EventHandler(this.BarScroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(11, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 35);
            this.label4.TabIndex = 7;
            this.label4.Text = "B";
            // 
            // TbxG
            // 
            this.TbxG.BackColor = System.Drawing.Color.LightGray;
            this.TbxG.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxG.Location = new System.Drawing.Point(612, 64);
            this.TbxG.Name = "TbxG";
            this.TbxG.Size = new System.Drawing.Size(85, 35);
            this.TbxG.TabIndex = 6;
            this.TbxG.Tag = "G";
            this.TbxG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TbxG.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxR_KeyDown);
            this.TbxG.Validated += new System.EventHandler(this.TbxValidated);
            // 
            // BarG
            // 
            this.BarG.LargeChange = 10;
            this.BarG.Location = new System.Drawing.Point(50, 64);
            this.BarG.Maximum = 100;
            this.BarG.Name = "BarG";
            this.BarG.Size = new System.Drawing.Size(556, 45);
            this.BarG.SmallChange = 5;
            this.BarG.TabIndex = 5;
            this.BarG.Tag = "G";
            this.BarG.Scroll += new System.EventHandler(this.BarScroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(11, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 35);
            this.label3.TabIndex = 4;
            this.label3.Text = "G";
            // 
            // TbxR
            // 
            this.TbxR.BackColor = System.Drawing.Color.LightGray;
            this.TbxR.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxR.Location = new System.Drawing.Point(612, 13);
            this.TbxR.Name = "TbxR";
            this.TbxR.Size = new System.Drawing.Size(85, 35);
            this.TbxR.TabIndex = 3;
            this.TbxR.Tag = "R";
            this.TbxR.Text = "99";
            this.TbxR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TbxR.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxR_KeyDown);
            this.TbxR.Validated += new System.EventHandler(this.TbxValidated);
            // 
            // BarR
            // 
            this.BarR.LargeChange = 10;
            this.BarR.Location = new System.Drawing.Point(50, 13);
            this.BarR.Maximum = 100;
            this.BarR.Name = "BarR";
            this.BarR.Size = new System.Drawing.Size(556, 45);
            this.BarR.SmallChange = 5;
            this.BarR.TabIndex = 2;
            this.BarR.Tag = "R";
            this.BarR.Scroll += new System.EventHandler(this.BarScroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "R";
            // 
            // BtnLen1
            // 
            this.BtnLen1.BackColor = System.Drawing.Color.Silver;
            this.BtnLen1.ContextMenuStrip = this.Menu_Len;
            this.BtnLen1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen1.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen1.Location = new System.Drawing.Point(6, 6);
            this.BtnLen1.Name = "BtnLen1";
            this.BtnLen1.Size = new System.Drawing.Size(96, 111);
            this.BtnLen1.TabIndex = 0;
            this.BtnLen1.Tag = "1";
            this.BtnLen1.Text = "Len - 1";
            this.BtnLen1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen1.UseVisualStyleBackColor = false;
            this.BtnLen1.Click += new System.EventHandler(this.ChangeLen);
            // 
            // Menu_Len
            // 
            this.Menu_Len.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnUpdate});
            this.Menu_Len.Name = "Menu_Config";
            this.Menu_Len.Size = new System.Drawing.Size(235, 34);
            this.Menu_Len.Opening += new System.ComponentModel.CancelEventHandler(this.Menu_Len_Opening);
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnUpdate.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(234, 30);
            this.BtnUpdate.Text = "Update  Config";
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // BtnLen7
            // 
            this.BtnLen7.BackColor = System.Drawing.Color.Silver;
            this.BtnLen7.ContextMenuStrip = this.Menu_Len;
            this.BtnLen7.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen7.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen7.Location = new System.Drawing.Point(618, 6);
            this.BtnLen7.Name = "BtnLen7";
            this.BtnLen7.Size = new System.Drawing.Size(96, 111);
            this.BtnLen7.TabIndex = 6;
            this.BtnLen7.Tag = "7";
            this.BtnLen7.Text = "Len - 7";
            this.BtnLen7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen7.UseVisualStyleBackColor = false;
            this.BtnLen7.Click += new System.EventHandler(this.ChangeLen);
            // 
            // BtnLen2
            // 
            this.BtnLen2.BackColor = System.Drawing.Color.Silver;
            this.BtnLen2.ContextMenuStrip = this.Menu_Len;
            this.BtnLen2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen2.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen2.Location = new System.Drawing.Point(108, 6);
            this.BtnLen2.Name = "BtnLen2";
            this.BtnLen2.Size = new System.Drawing.Size(96, 111);
            this.BtnLen2.TabIndex = 1;
            this.BtnLen2.Tag = "2";
            this.BtnLen2.Text = "Len - 2";
            this.BtnLen2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen2.UseVisualStyleBackColor = false;
            this.BtnLen2.Click += new System.EventHandler(this.ChangeLen);
            // 
            // BtnLen6
            // 
            this.BtnLen6.BackColor = System.Drawing.Color.Silver;
            this.BtnLen6.ContextMenuStrip = this.Menu_Len;
            this.BtnLen6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen6.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen6.Location = new System.Drawing.Point(516, 6);
            this.BtnLen6.Name = "BtnLen6";
            this.BtnLen6.Size = new System.Drawing.Size(96, 111);
            this.BtnLen6.TabIndex = 5;
            this.BtnLen6.Tag = "6";
            this.BtnLen6.Text = "Len - 6";
            this.BtnLen6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen6.UseVisualStyleBackColor = false;
            this.BtnLen6.Click += new System.EventHandler(this.ChangeLen);
            // 
            // BtnLen3
            // 
            this.BtnLen3.BackColor = System.Drawing.Color.Silver;
            this.BtnLen3.ContextMenuStrip = this.Menu_Len;
            this.BtnLen3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen3.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen3.Location = new System.Drawing.Point(210, 6);
            this.BtnLen3.Name = "BtnLen3";
            this.BtnLen3.Size = new System.Drawing.Size(96, 111);
            this.BtnLen3.TabIndex = 2;
            this.BtnLen3.Tag = "3";
            this.BtnLen3.Text = "Len - 3";
            this.BtnLen3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen3.UseVisualStyleBackColor = false;
            this.BtnLen3.Click += new System.EventHandler(this.ChangeLen);
            // 
            // BtnLen5
            // 
            this.BtnLen5.BackColor = System.Drawing.Color.Silver;
            this.BtnLen5.ContextMenuStrip = this.Menu_Len;
            this.BtnLen5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen5.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen5.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen5.Location = new System.Drawing.Point(414, 6);
            this.BtnLen5.Name = "BtnLen5";
            this.BtnLen5.Size = new System.Drawing.Size(96, 111);
            this.BtnLen5.TabIndex = 4;
            this.BtnLen5.Tag = "5";
            this.BtnLen5.Text = "Len - 5";
            this.BtnLen5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen5.UseVisualStyleBackColor = false;
            this.BtnLen5.Click += new System.EventHandler(this.ChangeLen);
            // 
            // BtnLen4
            // 
            this.BtnLen4.BackColor = System.Drawing.Color.Silver;
            this.BtnLen4.ContextMenuStrip = this.Menu_Len;
            this.BtnLen4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLen4.Image = global::RepairLightCtrl.Properties.Resources.video_camera;
            this.BtnLen4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnLen4.Location = new System.Drawing.Point(312, 6);
            this.BtnLen4.Name = "BtnLen4";
            this.BtnLen4.Size = new System.Drawing.Size(96, 111);
            this.BtnLen4.TabIndex = 3;
            this.BtnLen4.Tag = "4";
            this.BtnLen4.Text = "Len - 4";
            this.BtnLen4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLen4.UseVisualStyleBackColor = false;
            this.BtnLen4.Click += new System.EventHandler(this.ChangeLen);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage2.Controls.Add(this.PropertyGrid_Config);
            this.tabPage2.Location = new System.Drawing.Point(4, 35);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(720, 397);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Setting";
            // 
            // PropertyGrid_Config
            // 
            this.PropertyGrid_Config.ContextMenuStrip = this.Menu_Config;
            this.PropertyGrid_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PropertyGrid_Config.Location = new System.Drawing.Point(3, 3);
            this.PropertyGrid_Config.Name = "PropertyGrid_Config";
            this.PropertyGrid_Config.Size = new System.Drawing.Size(714, 391);
            this.PropertyGrid_Config.TabIndex = 0;
            // 
            // Menu_Config
            // 
            this.Menu_Config.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnSave});
            this.Menu_Config.Name = "Menu_Config";
            this.Menu_Config.Size = new System.Drawing.Size(201, 34);
            // 
            // BtnSave
            // 
            this.BtnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnSave.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(200, 30);
            this.BtnSave.Text = "Save Config";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 432);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Light Control";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarIR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarR)).EndInit();
            this.Menu_Len.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.Menu_Config.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnLen1;
        private System.Windows.Forms.Button BtnLen2;
        private System.Windows.Forms.Button BtnLen3;
        private System.Windows.Forms.Button BtnLen4;
        private System.Windows.Forms.Button BtnLen5;
        private System.Windows.Forms.Button BtnLen6;
        private System.Windows.Forms.Button BtnLen7;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TbxW;
        private System.Windows.Forms.TrackBar BarW;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TbxB;
        private System.Windows.Forms.TrackBar BarB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TbxG;
        private System.Windows.Forms.TrackBar BarG;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TbxR;
        private System.Windows.Forms.TrackBar BarR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TbxIR;
        private System.Windows.Forms.TrackBar BarIR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PropertyGrid PropertyGrid_Config;
        private System.Windows.Forms.ContextMenuStrip Menu_Config;
        private System.Windows.Forms.ToolStripMenuItem BtnSave;
        private System.Windows.Forms.ContextMenuStrip Menu_Len;
        private System.Windows.Forms.ToolStripMenuItem BtnUpdate;
    }
}

