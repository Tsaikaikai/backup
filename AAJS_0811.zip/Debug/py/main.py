from utils import MAMC_model
from utils.CheckData import checkData
from utils.UsingCsv import UsingCsv

import argparse
import os, shutil


###　python main.py --image_folder_path=./gray/0 --model_path=./AoiGrayModel_ver1_3.onnx --unknown_threshold=0.99 --csv_name=20220711194249
parser = argparse.ArgumentParser(description='please enter image_folder_path, model_path, unknown_threshold and csv_name')
parser.add_argument('--image_folder_path', type=str)
parser.add_argument('--model_path', type=str)
parser.add_argument('--unknown_threshold', type=float, default=0.99)
parser.add_argument('--csv_name', type=str, default='00000000000000')


if __name__ == '__main__':
    arg = parser.parse_args()

    fileName = os.path.split(arg.model_path)[-1]
    fileName = f'{fileName.split(".")[0]}.csv'
    csvFile = UsingCsv(fileName,'.')
    csvFile.create_csv()
    csvFile.writing(['NAS_path', arg.image_folder_path],'a')
    csvFile.writing(['AI model', arg.model_path],'a')
    csvFile.writing(['file_name', 'confidence', 'prediction', 'reason'],'a')

    unidentifiedPath = './unidentified'
    if not os.path.isdir(unidentifiedPath):
        os.mkdir(unidentifiedPath)
    
        
    checkData(arg.image_folder_path, arg.model_path, unidentifiedPath, csvFile)
    
        

    finalResult = MAMC_model.inference(arg.image_folder_path, arg.unknown_threshold, arg.model_path, arg.csv_name, csvFile)
    for i in range(len(finalResult['FileName'])):
        print("FileName: {:20s} / Prediction: {:15s} / Prediction Name: {:15s}".format(finalResult['FileName'][i], finalResult['Prediction'][i], finalResult['Prediction_Name'][i]))
        print("Confidence: {}".format(finalResult['Confidence'][i]))

    imageFile = os.listdir(unidentifiedPath)
    for imageName in imageFile:
        shutil.move(os.path.join(unidentifiedPath, imageName), os.path.join(arg.image_folder_path, imageName))

    '''   
    with open('AoiGrayModel_ver1_3.csv', 'r') as csvFile:
        rows = csv.reader(csvFile)
        
        for row in rows:
            print(row)
    '''