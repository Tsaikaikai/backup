﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LumColorMapping
{
    public partial class TestForm : Form
    {
        public MappingMethod method = new MappingMethod();
        public AllConfig config;

        public TestForm()
        {
            InitializeComponent();
        }

        private void btn_Calibration_Click(object sender, EventArgs e)
        {
            config.CalibrationOutput = method.DoCalibration(config.CalibrationInput);
            updateConfig();
        }

        private void btn_Mapping_Click(object sender, EventArgs e)
        {
            config.MappingOutput = method.DoMapping(config.MappingInput,config.CalibrationInput,config.CalibrationOutput);
            updateConfig();
        }

        private void btn_HSLtrans_Click(object sender, EventArgs e)
        {
            config.HslOutput = method.DoHSLTransfer(config.MappingOutput, config.HslInput);
            updateConfig();
        }

        private void btn_LoadConfig_Click(object sender, EventArgs e)
        {
            config = method.LoadConfig();
            updateConfig();
        }

        private void btn_SaveConfig_Click(object sender, EventArgs e)
        {
            method.SaveConfig(config);
            MessageBox.Show("設定已儲存！");
        }

        private void updateConfig()
        {
            pg_CalibrationInput.SelectedObject = config.CalibrationInput;
            pg_CalibrationOutput.SelectedObject = config.CalibrationOutput;
            pg_MappingInput.SelectedObject = config.MappingInput;
            pg_MappingOutput.SelectedObject = config.MappingOutput;
            pg_HSLInput.SelectedObject = config.HslInput;
            pg_HSLOutput.SelectedObject = config.HslOutput;

            textBox_FinalOutput.Text = "Hue = " + config.HslOutput.FinalHue.ToString() + "\r\n\r\n" +
                                       "Saturation = " + config.HslOutput.FinalSaturation.ToString() + "\r\n\r\n" +
                                       "Lightness = " + config.HslOutput.FinalLightness.ToString();
        }
    }
}
