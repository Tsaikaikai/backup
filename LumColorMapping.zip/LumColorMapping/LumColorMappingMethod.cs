﻿using System;
using System.ComponentModel;
using System.IO;
using System.Text.Json;

namespace LumColorMapping
{

    public class MappingMethod
    {
        public CalibrationOutput DoCalibration(CalibrationInput input)
        {
            CalibrationOutput output = new CalibrationOutput();

            output.CalibrationKX = Math.Round((double)input.SR3MeasureX / (double)input.JAIMeasureX, 3);
            output.CalibrationKY = Math.Round((double)input.SR3MeasureY / (double)input.JAIMeasureY, 3);
            output.CalibrationKZ = Math.Round((double)input.SR3MeasureZ / (double)input.JAIMeasureZ, 3);

            return output;
        }

        public MappingOutput DoMapping(MappingInput mInput, CalibrationInput cInput, CalibrationOutput cOutput)
        {
            MappingOutput output = new MappingOutput();
            output.JAIExposureTimeRateX = Math.Round((double)cInput.ExposureTimeX / mInput.JAIExposureTimeX, 3);
            output.JAIExposureTimeRateY = Math.Round((double)cInput.ExposureTimeY / mInput.JAIExposureTimeY, 3);
            output.JAIExposureTimeRateZ = Math.Round((double)cInput.ExposureTimeZ / mInput.JAIExposureTimeZ, 3);

            output.JAIStandardX = mInput.JAIOriginlMeasureX * output.JAIExposureTimeRateX;
            output.JAIStandardY = mInput.JAIOriginlMeasureY * output.JAIExposureTimeRateY;
            output.JAIStandardZ = mInput.JAIOriginlMeasureZ * output.JAIExposureTimeRateZ;

            output.JAIAfterMappingX = output.JAIStandardX * cOutput.CalibrationKX;
            output.JAIAfterMappingY = output.JAIStandardY * cOutput.CalibrationKY;
            output.JAIAfterMappingZ = output.JAIStandardZ * cOutput.CalibrationKZ;

            output.JAIAfterMappingSmallX = output.JAIAfterMappingX / (output.JAIAfterMappingX + output.JAIAfterMappingY + output.JAIAfterMappingZ);
            output.JAIAfterMappingSmallY = output.JAIAfterMappingY / (output.JAIAfterMappingX + output.JAIAfterMappingY + output.JAIAfterMappingZ);
            output.JAIAfterMappingSmallZ = output.JAIAfterMappingZ / (output.JAIAfterMappingX + output.JAIAfterMappingY + output.JAIAfterMappingZ);

            return output;
        }

        public  HslOutput DoHSLTransfer(MappingOutput mOutput, HslInput hslInput)
        {
            HslOutput hslOutput = new HslOutput();

            hslOutput.NormalizeX = mOutput.JAIAfterMappingX / hslInput.NormalizeConstantX;
            hslOutput.NormalizeY = mOutput.JAIAfterMappingY / hslInput.NormalizeConstantY;
            hslOutput.NormalizeZ = mOutput.JAIAfterMappingZ / hslInput.NormalizeConstantZ;

            hslOutput.BradfordLmsRho = hslInput.BradfordLmsRhoConstantA * hslOutput.NormalizeX +
                                       hslInput.BradfordLmsRhoConstantB * hslOutput.NormalizeY +
                                       hslInput.BradfordLmsRhoConstantC * hslOutput.NormalizeZ;

            hslOutput.BradfordLmsGamma = hslInput.BradfordLmsGammaConstantA * hslOutput.NormalizeX +
                                         hslInput.BradfordLmsGammaConstantB * hslOutput.NormalizeY +
                                         hslInput.BradfordLmsGammaConstantC * hslOutput.NormalizeZ;

            hslOutput.BradfordLmsBeta = hslInput.BradfordLmsBetaConstantA * hslOutput.NormalizeX +
                                        hslInput.BradfordLmsBetaConstantB * hslOutput.NormalizeY +
                                        hslInput.BradfordLmsBetaConstantC * hslOutput.NormalizeZ;

            hslOutput.ZoomLmsA = hslOutput.BradfordLmsRho * (hslInput.D65LightWhiteSpotLMSConstantA / hslInput.ALightWhiteSpotLMSConstantA);
            hslOutput.ZoomLmsB = hslOutput.BradfordLmsGamma * (hslInput.D65LightWhiteSpotLMSConstantB / hslInput.ALightWhiteSpotLMSConstantB);
            hslOutput.ZoomLmsC = hslOutput.BradfordLmsBeta * (hslInput.D65LightWhiteSpotLMSConstantC / hslInput.ALightWhiteSpotLMSConstantC);

            hslOutput.D65X = hslInput.D65XConstantA * hslOutput.ZoomLmsA + hslInput.D65XConstantB * hslOutput.ZoomLmsB + hslInput.D65XConstantC * hslOutput.ZoomLmsC;
            hslOutput.D65Y = hslInput.D65YConstantA * hslOutput.ZoomLmsA + hslInput.D65YConstantB * hslOutput.ZoomLmsB + hslInput.D65YConstantC * hslOutput.ZoomLmsC;
            hslOutput.D65Z = hslInput.D65ZConstantA * hslOutput.ZoomLmsA + hslInput.D65ZConstantB * hslOutput.ZoomLmsB + hslInput.D65ZConstantC * hslOutput.ZoomLmsC;

            hslOutput.LinearR = hslInput.LinearRConstantA * hslOutput.D65X + hslInput.LinearRConstantB * hslOutput.D65Y + hslInput.LinearRConstantC * hslOutput.D65Z;
            hslOutput.LinearG = hslInput.LinearGConstantA * hslOutput.D65X + hslInput.LinearGConstantB * hslOutput.D65Y + hslInput.LinearGConstantC * hslOutput.D65Z;
            hslOutput.LinearB = hslInput.LinearBConstantA * hslOutput.D65X + hslInput.LinearBConstantB * hslOutput.D65Y + hslInput.LinearBConstantC * hslOutput.D65Z;


            if (hslOutput.LinearR <= 0.0031308)
            {
                hslOutput.sRGBGammaCorrectionR = 12.92 * hslOutput.LinearR;
            }
            else
            {
                hslOutput.sRGBGammaCorrectionR =  1.055 * Math.Pow(hslOutput.LinearR, 1.0 / 2.4) - 0.055;
            }

            if (hslOutput.LinearG <= 0.0031308)
            {
                hslOutput.sRGBGammaCorrectionG = 12.92 * hslOutput.LinearG;
            }
            else
            {
                hslOutput.sRGBGammaCorrectionG = 1.055 * Math.Pow(hslOutput.LinearG, 1.0 / 2.4) - 0.055;
            }

            if (hslOutput.LinearB <= 0.0031308)
            {
                hslOutput.sRGBGammaCorrectionB = 12.92 * hslOutput.LinearB;
            }
            else
            {
                hslOutput.sRGBGammaCorrectionB = 1.055 * Math.Pow(hslOutput.LinearB, 1.0 / 2.4) - 0.055;
            }

            hslOutput.sRGBGammaCorrectionR = Math.Max(0.0, Math.Min(1.0, hslOutput.sRGBGammaCorrectionR));
            hslOutput.sRGBGammaCorrectionG = Math.Max(0.0, Math.Min(1.0, hslOutput.sRGBGammaCorrectionG));
            hslOutput.sRGBGammaCorrectionB = Math.Max(0.0, Math.Min(1.0, hslOutput.sRGBGammaCorrectionB));

            hslOutput.sRGBGammaCorrectionMax = Math.Max(hslOutput.sRGBGammaCorrectionR, Math.Max(hslOutput.sRGBGammaCorrectionG, hslOutput.sRGBGammaCorrectionB));
            hslOutput.sRGBGammaCorrectionMin = Math.Min(hslOutput.sRGBGammaCorrectionR, Math.Min(hslOutput.sRGBGammaCorrectionG, hslOutput.sRGBGammaCorrectionB));
            hslOutput.sRGBGammaCorrectionMaxMinRange = hslOutput.sRGBGammaCorrectionMax - hslOutput.sRGBGammaCorrectionMin;

            //Hue
            if (hslOutput.sRGBGammaCorrectionMaxMinRange == 0)
            {                 
                hslOutput.FinalHue = 0;
            }
            else
            {
                if (hslOutput.sRGBGammaCorrectionMax == hslOutput.sRGBGammaCorrectionR)
                {
                    double h = 60.0 * ((hslOutput.sRGBGammaCorrectionG - hslOutput.sRGBGammaCorrectionB) / hslOutput.sRGBGammaCorrectionMaxMinRange);
                    hslOutput.FinalHue = (h % 360.0 + 360.0) % 360.0; // 確保 0-360
                }
                else
                {
                    if (hslOutput.sRGBGammaCorrectionMax == hslOutput.sRGBGammaCorrectionG)
                    {
                        hslOutput.FinalHue = 60.0 * (((hslOutput.sRGBGammaCorrectionB - hslOutput.sRGBGammaCorrectionR) / hslOutput.sRGBGammaCorrectionMaxMinRange) + 2.0);
                    }
                    // 否則視為最大值為 B
                    else
                    {
                        hslOutput.FinalHue = 60.0 * (((hslOutput.sRGBGammaCorrectionR - hslOutput.sRGBGammaCorrectionG) / hslOutput.sRGBGammaCorrectionMaxMinRange) + 4.0);
                    }
                }
            }

            //Lightness
            hslOutput.FinalLightness = (hslOutput.sRGBGammaCorrectionMax + hslOutput.sRGBGammaCorrectionMin) / 2;

            //Saturation
            if (hslOutput.sRGBGammaCorrectionMaxMinRange == 0)
            {
                hslOutput.FinalSaturation = 0;
            }
            else
            {
                hslOutput.FinalSaturation = hslOutput.sRGBGammaCorrectionMaxMinRange / (1 - Math.Abs(2 * hslOutput.FinalLightness - 1));
            }

            return hslOutput;
        }

        private const string CONFIG_FILE = "MappingConfig.json";

        // 儲存設定
        public void SaveConfig(AllConfig config)
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string jsonString = JsonSerializer.Serialize(config, options);
                File.WriteAllText(CONFIG_FILE, jsonString);
            }
            catch (Exception ex)
            {
                throw new Exception($"儲存設定失敗: {ex.Message}");
            }
        }

        // 讀取設定
        public AllConfig LoadConfig()
        {
            try
            {
                if (File.Exists(CONFIG_FILE))
                {
                    string jsonString = File.ReadAllText(CONFIG_FILE);
                    var config = JsonSerializer.Deserialize<AllConfig>(jsonString);
                    return config ?? new AllConfig();
                }
                else
                {
                    throw new Exception($"參數檔案不存在");
                }
            }
            catch (Exception ex)
            {
               throw new Exception($"參數檔案讀取失敗: {ex.Message}");
            }
        }
    }
}
