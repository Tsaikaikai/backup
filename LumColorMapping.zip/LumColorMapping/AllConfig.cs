﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LumColorMapping
{
    public class AllConfig
    {
        public CalibrationInput CalibrationInput { get; set; } = new CalibrationInput();
        public CalibrationOutput CalibrationOutput { get; set; } = new CalibrationOutput();
        public MappingInput MappingInput { get; set; } = new MappingInput();
        public MappingOutput MappingOutput { get; set; } = new MappingOutput();
        public HslInput HslInput { get; set; } = new HslInput();
        public HslOutput HslOutput { get; set; } = new HslOutput();
    }

    [DisplayName("校準輸入參數")]
    public class CalibrationInput
    {
        [Category("SR3測量值"), DisplayName("SR3MeasureX")]
        public int SR3MeasureX { get; set; }

        [Category("SR3測量值"), DisplayName("SR3MeasureY")]
        public int SR3MeasureY { get; set; }

        [Category("SR3測量值"), DisplayName("SR3MeasureZ")]
        public int SR3MeasureZ { get; set; }

        [Category("JAI測量值"), DisplayName("JAIMeasureX")]
        public int JAIMeasureX { get; set; }

        [Category("JAI測量值"), DisplayName("JAIMeasureY")]
        public int JAIMeasureY { get; set; }

        [Category("JAI測量值"), DisplayName("JAIMeasureZ")]
        public int JAIMeasureZ { get; set; }

        [Category("曝光時間"), DisplayName("ExposureTimeX")]
        public int ExposureTimeX { get; set; }

        [Category("曝光時間"), DisplayName("ExposureTimeY")]
        public int ExposureTimeY { get; set; }

        [Category("曝光時間"), DisplayName("ExposureTimeZ")]
        public int ExposureTimeZ { get; set; }
    }


    [DisplayName("校準輸出參數")]
    public class CalibrationOutput
    {
        [Category("校準輸出"), DisplayName("CalibrationKX")]
        public double CalibrationKX { get; set; }

        [Category("校準輸出"), DisplayName("CalibrationKY")]
        public double CalibrationKY { get; set; }

        [Category("校準輸出"), DisplayName("CalibrationKZ")]
        public double CalibrationKZ { get; set; }
    }

    [DisplayName("映射輸入參數")]
    public class MappingInput
    {
        [Category("映射輸入"), DisplayName("JAIOriginlMeasureX")]
        public double JAIOriginlMeasureX { get; set; }

        [Category("映射輸入"), DisplayName("JAIOriginlMeasureY")]
        public double JAIOriginlMeasureY { get; set; }

        [Category("映射輸入"), DisplayName("JAIOriginlMeasureZ")]
        public double JAIOriginlMeasureZ { get; set; }

        [Category("映射輸入"), DisplayName("JAIExposureTimeX")]
        public int JAIExposureTimeX { get; set; }

        [Category("映射輸入"), DisplayName("JAIExposureTimeY")]
        public int JAIExposureTimeY { get; set; }

        [Category("映射輸入"), DisplayName("JAIExposureTimeZ")]
        public int JAIExposureTimeZ { get; set; }
    }


    [DisplayName("映射輸出參數")]
    public class MappingOutput
    {
        [Category("映射輸出"), DisplayName("JAIExposureTimeRateX")]
        public double JAIExposureTimeRateX { get; set; }

        [Category("映射輸出"), DisplayName("JAIExposureTimeRateY")]
        public double JAIExposureTimeRateY { get; set; }

        [Category("映射輸出"), DisplayName("JAIExposureTimeRateZ")]
        public double JAIExposureTimeRateZ { get; set; }

        [Category("映射輸出"), DisplayName("JAIStandardX")]
        public double JAIStandardX { get; set; }

        [Category("映射輸出"), DisplayName("JAIStandardY")]
        public double JAIStandardY { get; set; }

        [Category("映射輸出"), DisplayName("JAIStandardZ")]
        public double JAIStandardZ { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingX")]
        public double JAIAfterMappingX { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingY")]
        public double JAIAfterMappingY { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingZ")]
        public double JAIAfterMappingZ { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingSmallX")]
        public double JAIAfterMappingSmallX { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingSmallY")]
        public double JAIAfterMappingSmallY { get; set; }

        [Category("映射輸出"), DisplayName("JAIAfterMappingSmallZ")]
        public double JAIAfterMappingSmallZ { get; set; }
    }

    [DisplayName("HSL轉換輸入參數")]
    public class HslInput
    {
        [Category("HSL轉換輸入"), DisplayName("NormalizeConstantX")]
        public int NormalizeConstantX { get; set; } = 100;

        [Category("HSL轉換輸入"), DisplayName("NormalizeConstantY")]
        public int NormalizeConstantY { get; set; } = 100;

        [Category("HSL轉換輸入"), DisplayName("NormalizeConstantZ")]
        public int NormalizeConstantZ { get; set; } = 100;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsRhoConstantA")]
        public double BradfordLmsRhoConstantA { get; set; } = 0.8951;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsRhoConstantB")]
        public double BradfordLmsRhoConstantB { get; set; } = 0.2664;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsRhoConstantC")]
        public double BradfordLmsRhoConstantC { get; set; } = -0.1314;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsGammaConstantA")]
        public double BradfordLmsGammaConstantA { get; set; } = -0.7502;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsGammaConstantB")]
        public double BradfordLmsGammaConstantB { get; set; } = 1.7135;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsGammaConstantC")]
        public double BradfordLmsGammaConstantC { get; set; } = 0.0367;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsBetaConstantA")]
        public double BradfordLmsBetaConstantA { get; set; } = 0.0389;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsBetaConstantB")]
        public double BradfordLmsBetaConstantB { get; set; } = -0.0685;

        [Category("HSL轉換輸入"), DisplayName("BradfordLmsBetaConstantC")]
        public double BradfordLmsBetaConstantC { get; set; } = 1.0296;

        [Category("HSL轉換輸入"), DisplayName("ALightWhiteSpotLMSConstantA")]
        public double ALightWhiteSpotLMSConstantA { get; set; } = 1.2389;

        [Category("HSL轉換輸入"), DisplayName("ALightWhiteSpotLMSConstantB")]
        public double ALightWhiteSpotLMSConstantB { get; set; } = 0.9026;

        [Category("HSL轉換輸入"), DisplayName("ALightWhiteSpotLMSConstantC")]
        public double ALightWhiteSpotLMSConstantC { get; set; } = 0.341;

        [Category("HSL轉換輸入"), DisplayName("D65LightWhiteSpotLMSConstantA")]
        public double D65LightWhiteSpotLMSConstantA { get; set; } = 0.939;

        [Category("HSL轉換輸入"), DisplayName("D65LightWhiteSpotLMSConstantB")]
        public double D65LightWhiteSpotLMSConstantB { get; set; } = 1.0407;

        [Category("HSL轉換輸入"), DisplayName("D65LightWhiteSpotLMSConstantC")]
        public double D65LightWhiteSpotLMSConstantC { get; set; } = 1.0889;

        [Category("HSL轉換輸入"), DisplayName("D65XConstantA")]
        public double D65XConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65XConstantB")]
        public double D65XConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65XConstantC")]
        public double D65XConstantC { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65YConstantA")]
        public double D65YConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65YConstantB")]
        public double D65YConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65YConstantC")]
        public double D65YConstantC { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65ZConstantA")]
        public double D65ZConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65ZConstantB")]
        public double D65ZConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("D65ZConstantC")]
        public double D65ZConstantC { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearRConstantA")]
        public double LinearRConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearRConstantB")]
        public double LinearRConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearRConstantC")]
        public double LinearRConstantC { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearGConstantA")]
        public double LinearGConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearGConstantB")]
        public double LinearGConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearGConstantC")]
        public double LinearGConstantC { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearBConstantA")]
        public double LinearBConstantA { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearBConstantB")]
        public double LinearBConstantB { get; set; }

        [Category("HSL轉換輸入"), DisplayName("LinearBConstantC")]
        public double LinearBConstantC { get; set; }
    }

    [DisplayName("HSL轉換輸出參數")]
    public class HslOutput
    {
        [Category("HSL轉換輸出"), DisplayName("BradfordLmsRho")]
        public double BradfordLmsRho { get; set; }

        [Category("HSL轉換輸出"), DisplayName("BradfordLmsGamma")]
        public double BradfordLmsGamma { get; set; }

        [Category("HSL轉換輸出"), DisplayName("BradfordLmsBeta")]
        public double BradfordLmsBeta { get; set; }

        [Category("HSL轉換輸出"), DisplayName("NormalizeX")]
        public double NormalizeX { get; set; }

        [Category("HSL轉換輸出"), DisplayName("NormalizeY")]
        public double NormalizeY { get; set; }

        [Category("HSL轉換輸出"), DisplayName("NormalizeZ")]
        public double NormalizeZ { get; set; }

        [Category("HSL轉換輸出"), DisplayName("ZoomLmsA")]
        public double ZoomLmsA { get; set; }

        [Category("HSL轉換輸出"), DisplayName("ZoomLmsB")]
        public double ZoomLmsB { get; set; }

        [Category("HSL轉換輸出"), DisplayName("ZoomLmsC")]
        public double ZoomLmsC { get; set; }

        [Category("HSL轉換輸出"), DisplayName("D65X")]
        public double D65X { get; set; }

        [Category("HSL轉換輸出"), DisplayName("D65Y")]
        public double D65Y { get; set; }

        [Category("HSL轉換輸出"), DisplayName("D65Z")]
        public double D65Z { get; set; }

        [Category("HSL轉換輸出"), DisplayName("LinearR")]
        public double LinearR { get; set; }

        [Category("HSL轉換輸出"), DisplayName("LinearG")]
        public double LinearG { get; set; }

        [Category("HSL轉換輸出"), DisplayName("LinearB")]
        public double LinearB { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionR")]
        public double sRGBGammaCorrectionR { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionG")]
        public double sRGBGammaCorrectionG { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionB")]
        public double sRGBGammaCorrectionB { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionMax")]
        public double sRGBGammaCorrectionMax { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionMin")]
        public double sRGBGammaCorrectionMin { get; set; }

        [Category("HSL轉換輸出"), DisplayName("sRGBGammaCorrectionMaxMinRange")]
        public double sRGBGammaCorrectionMaxMinRange { get; set; }

        [Category("HSL轉換輸出"), DisplayName("FinalHue")]
        public double FinalHue { get; set; }

        [Category("HSL轉換輸出"), DisplayName("FinalSaturation")]
        public double FinalSaturation { get; set; }

        [Category("HSL轉換輸出"), DisplayName("FinalLightness")]
        public double FinalLightness { get; set; }
    }
}
