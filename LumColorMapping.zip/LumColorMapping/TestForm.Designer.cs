﻿
namespace LumColorMapping
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pg_CalibrationInput = new System.Windows.Forms.PropertyGrid();
            this.pg_MappingInput = new System.Windows.Forms.PropertyGrid();
            this.pg_HSLInput = new System.Windows.Forms.PropertyGrid();
            this.pg_HSLOutput = new System.Windows.Forms.PropertyGrid();
            this.pg_MappingOutput = new System.Windows.Forms.PropertyGrid();
            this.pg_CalibrationOutput = new System.Windows.Forms.PropertyGrid();
            this.btn_Calibration = new System.Windows.Forms.Button();
            this.btn_Mapping = new System.Windows.Forms.Button();
            this.btn_HSLtrans = new System.Windows.Forms.Button();
            this.btn_LoadConfig = new System.Windows.Forms.Button();
            this.btn_SaveConfig = new System.Windows.Forms.Button();
            this.textBox_FinalOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pg_CalibrationInput
            // 
            this.pg_CalibrationInput.Location = new System.Drawing.Point(12, 12);
            this.pg_CalibrationInput.Name = "pg_CalibrationInput";
            this.pg_CalibrationInput.Size = new System.Drawing.Size(374, 362);
            this.pg_CalibrationInput.TabIndex = 0;
            // 
            // pg_MappingInput
            // 
            this.pg_MappingInput.Location = new System.Drawing.Point(402, 12);
            this.pg_MappingInput.Name = "pg_MappingInput";
            this.pg_MappingInput.Size = new System.Drawing.Size(374, 362);
            this.pg_MappingInput.TabIndex = 1;
            // 
            // pg_HSLInput
            // 
            this.pg_HSLInput.Location = new System.Drawing.Point(798, 12);
            this.pg_HSLInput.Name = "pg_HSLInput";
            this.pg_HSLInput.Size = new System.Drawing.Size(374, 362);
            this.pg_HSLInput.TabIndex = 2;
            // 
            // pg_HSLOutput
            // 
            this.pg_HSLOutput.Location = new System.Drawing.Point(798, 426);
            this.pg_HSLOutput.Name = "pg_HSLOutput";
            this.pg_HSLOutput.Size = new System.Drawing.Size(374, 362);
            this.pg_HSLOutput.TabIndex = 5;
            // 
            // pg_MappingOutput
            // 
            this.pg_MappingOutput.Location = new System.Drawing.Point(402, 426);
            this.pg_MappingOutput.Name = "pg_MappingOutput";
            this.pg_MappingOutput.Size = new System.Drawing.Size(374, 362);
            this.pg_MappingOutput.TabIndex = 4;
            // 
            // pg_CalibrationOutput
            // 
            this.pg_CalibrationOutput.Location = new System.Drawing.Point(12, 426);
            this.pg_CalibrationOutput.Name = "pg_CalibrationOutput";
            this.pg_CalibrationOutput.Size = new System.Drawing.Size(374, 362);
            this.pg_CalibrationOutput.TabIndex = 3;
            // 
            // btn_Calibration
            // 
            this.btn_Calibration.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_Calibration.Location = new System.Drawing.Point(103, 380);
            this.btn_Calibration.Name = "btn_Calibration";
            this.btn_Calibration.Size = new System.Drawing.Size(198, 39);
            this.btn_Calibration.TabIndex = 6;
            this.btn_Calibration.Text = "Calibration";
            this.btn_Calibration.UseVisualStyleBackColor = true;
            this.btn_Calibration.Click += new System.EventHandler(this.btn_Calibration_Click);
            // 
            // btn_Mapping
            // 
            this.btn_Mapping.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_Mapping.Location = new System.Drawing.Point(490, 380);
            this.btn_Mapping.Name = "btn_Mapping";
            this.btn_Mapping.Size = new System.Drawing.Size(198, 39);
            this.btn_Mapping.TabIndex = 7;
            this.btn_Mapping.Text = "Mapping";
            this.btn_Mapping.UseVisualStyleBackColor = true;
            this.btn_Mapping.Click += new System.EventHandler(this.btn_Mapping_Click);
            // 
            // btn_HSLtrans
            // 
            this.btn_HSLtrans.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_HSLtrans.Location = new System.Drawing.Point(893, 380);
            this.btn_HSLtrans.Name = "btn_HSLtrans";
            this.btn_HSLtrans.Size = new System.Drawing.Size(198, 39);
            this.btn_HSLtrans.TabIndex = 8;
            this.btn_HSLtrans.Text = "HSL Transfer";
            this.btn_HSLtrans.UseVisualStyleBackColor = true;
            this.btn_HSLtrans.Click += new System.EventHandler(this.btn_HSLtrans_Click);
            // 
            // btn_LoadConfig
            // 
            this.btn_LoadConfig.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_LoadConfig.Location = new System.Drawing.Point(1216, 66);
            this.btn_LoadConfig.Name = "btn_LoadConfig";
            this.btn_LoadConfig.Size = new System.Drawing.Size(198, 58);
            this.btn_LoadConfig.TabIndex = 9;
            this.btn_LoadConfig.Text = "Load Config";
            this.btn_LoadConfig.UseVisualStyleBackColor = true;
            this.btn_LoadConfig.Click += new System.EventHandler(this.btn_LoadConfig_Click);
            // 
            // btn_SaveConfig
            // 
            this.btn_SaveConfig.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_SaveConfig.Location = new System.Drawing.Point(1216, 147);
            this.btn_SaveConfig.Name = "btn_SaveConfig";
            this.btn_SaveConfig.Size = new System.Drawing.Size(198, 58);
            this.btn_SaveConfig.TabIndex = 10;
            this.btn_SaveConfig.Text = "Save Config";
            this.btn_SaveConfig.UseVisualStyleBackColor = true;
            this.btn_SaveConfig.Click += new System.EventHandler(this.btn_SaveConfig_Click);
            // 
            // textBox_FinalOutput
            // 
            this.textBox_FinalOutput.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_FinalOutput.Location = new System.Drawing.Point(1193, 543);
            this.textBox_FinalOutput.Multiline = true;
            this.textBox_FinalOutput.Name = "textBox_FinalOutput";
            this.textBox_FinalOutput.Size = new System.Drawing.Size(221, 179);
            this.textBox_FinalOutput.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(1189, 519);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 21);
            this.label1.TabIndex = 12;
            this.label1.Text = "Final Output";
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 823);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_FinalOutput);
            this.Controls.Add(this.btn_SaveConfig);
            this.Controls.Add(this.btn_LoadConfig);
            this.Controls.Add(this.btn_HSLtrans);
            this.Controls.Add(this.btn_Mapping);
            this.Controls.Add(this.btn_Calibration);
            this.Controls.Add(this.pg_HSLOutput);
            this.Controls.Add(this.pg_MappingOutput);
            this.Controls.Add(this.pg_CalibrationOutput);
            this.Controls.Add(this.pg_HSLInput);
            this.Controls.Add(this.pg_MappingInput);
            this.Controls.Add(this.pg_CalibrationInput);
            this.Name = "TestForm";
            this.Text = "JAI 3CCD Mapping Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PropertyGrid pg_CalibrationInput;
        private System.Windows.Forms.PropertyGrid pg_MappingInput;
        private System.Windows.Forms.PropertyGrid pg_HSLInput;
        private System.Windows.Forms.PropertyGrid pg_HSLOutput;
        private System.Windows.Forms.PropertyGrid pg_MappingOutput;
        private System.Windows.Forms.PropertyGrid pg_CalibrationOutput;
        private System.Windows.Forms.Button btn_Calibration;
        private System.Windows.Forms.Button btn_Mapping;
        private System.Windows.Forms.Button btn_HSLtrans;
        private System.Windows.Forms.Button btn_LoadConfig;
        private System.Windows.Forms.Button btn_SaveConfig;
        private System.Windows.Forms.TextBox textBox_FinalOutput;
        private System.Windows.Forms.Label label1;
    }
}