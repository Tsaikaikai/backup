﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Emgu.CV;

namespace Brandy
{
    public class CspResnetModel : IDisposable
    {
        OnnxCore _core = null;
        float[] _result = null;
        int _maxClass = -1;
        float _maxScore = -1;
        int[] _maxClassList = new int[0];
        float[] _maxScoreList = new float[0];
        public float[] Output
        {
            get { return _result; }
        }
        public int OutputClass
        {
            get { return _maxClass; }
        }
        public float OutputScore
        {
            get { return _maxScore; }
        }
        public int[] BatchOutputClass
        {
            get
            {
                return _maxClassList;
            }
        }
        public float[] BatchOutputScore
        {
            get
            {
                return _maxScoreList;
            }
        }

        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public CspResnetModel(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.CSPResNet18);
        }
        ~CspResnetModel()
        {
            if(_core!=null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        bool Inference(float[] data)
        {
            bool state = false;
            _maxClass = -1;
            _maxScore = -1;
            try
            {
                float[] inputData = Util.NormalizeData(data);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    double[] softmax_result = softmax(_result);
                    if (_result != null)
                    {
                        for (int i = 0; i < _result.Length; i++)
                        {
                            if (_result[i] > _maxScore)
                            {
                                _maxScore = (float)Math.Round(softmax_result[i],2);
                                _maxClass = i;
                            }
                        }
                    }
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public bool BatchInference(float[] input,int batchSize)
        {
            try
            {
                float[] inputData = Util.NormalizeData(input);
                if (_core.BatchInference(inputData, batchSize))
                {
                    _result = _core.Output;

                    float[][] groupedArray = _result
                        .Select((value, index) => new { value, index })
                        .GroupBy(x => x.index / _core.OutputShape[1])
                        .Select(g => g.Select(x => x.value).ToArray())
                        .ToArray();

                    _maxClassList = new int[batchSize];
                    _maxScoreList = new float[batchSize];

                    for (int i = 0; i < batchSize; i++)
                    {
                        double[] softmax_result = softmax(groupedArray[i]);
                        if (groupedArray[i] != null)
                        {
                            float maxScore = -1;
                            int maxClass = -1;
                            for (int j = 0; j < softmax_result.Length; j++)
                            {
                                if (softmax_result[j] > maxScore)
                                {
                                    maxScore = (float)Math.Round(softmax_result[j], 2);
                                    maxClass = j;
                                }
                            }
                            _maxClassList[i] = maxClass;
                            _maxScoreList[i] = maxScore;
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Batch Inference fail : " + ex.Message);
            }
            finally
            {

            }
        }

        private double[] softmax(float[] input)
        {
            //var z = new[] { 1.0, 2.0, 3.0, 4.0, 1.0, 2.0, 3.0 };
            double[] array = new double[input.Length];

            for (int i = 0; i < input.GetLength(0); i++)
            {
                array[i] = input[i];
            }

            IEnumerable<double> z_exp = array.Select(Math.Exp);
            // [2.72, 7.39, 20.09, 54.6, 2.72, 7.39, 20.09]

            double sum_z_exp = z_exp.Sum();
            // 114.98

            IEnumerable<double> _result = z_exp.Select(i => i / sum_z_exp);
            // [0.024, 0.064, 0.175, 0.475, 0.024, 0.064, 0.175]

            double[] result = _result.ToArray();
            return result;
        }
        public bool Inference(string filename)
        {
            try
            {
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);
                return Inference(image);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[2], ResizeMode.KeepRatio);
                image.Padding();
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return (Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void ParallelPreprocess(ref List<BrandyImage> inputImages)
        {
            try
            {
                Parallel.ForEach(inputImages, (image, LoopState) => {
                    image.CheckChannel(InputShape[1]);
                    image.Resize(InputShape[2], ResizeMode.KeepRatio);
                    image.Padding();
                    image.ProcessImage = image.GetPlannerDataFloat();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BrandyImage> MatsToBrandyImages(Mat[] InputImages)
        {
            //pre-process mat to brandyimage
            BrandyImage[] inputImagesArr = new BrandyImage[InputImages.Length];
            Parallel.For(0, InputImages.Length, i =>
            {
                Mat img = new Mat();
                InputImages[i].CopyTo(img);
                if (img.NumberOfChannels == 3)
                {
                    CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                }
                byte[] inputData = Mat_chw(img);
                Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                if (img.NumberOfChannels == 1)
                    type = Brandy.ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);
                inputImagesArr[i] = input;
            });
            List<BrandyImage> inputImages = new List<BrandyImage>(inputImagesArr);
            return inputImages;
        }

        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }
    }
}
