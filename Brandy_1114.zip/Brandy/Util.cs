﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Util;

namespace Brandy
{
    public static class Util
    {
        /// <summary>
        /// 正規化數據，Data 為0~255 float
        /// </summary>
        /// <returns></returns>
        public static float[] NormalizeData(float[] data, double mean = 0.5, double std = 0.5)
        {
            int count = data.Length;
            Parallel.For(0, count, i =>
            {
                data[i] = (float)((data[i] / 255 - mean) / std);
            });
            return data;
        }
        public static float[] Normalize3DData(float[] data, double[] mean , double[] std)
        {
            if (data.Length % 3 == 0)
            {
                int each_size = data.Length / 3;
                Parallel.For(0, data.Length, i =>
                {
                    if (i >= 0 && i < each_size) //R channel
                    {
                        data[i] = (float)((data[i] / 255 - mean[0]) / std[0]);
                    }
                    else if (i >= each_size && i < each_size * 2)
                    {
                        data[i] = (float)((data[i] / 255 - mean[1]) / std[1]);
                    }
                    else if (i >= each_size * 2 && i < each_size * 3)
                    {
                        data[i] = (float)((data[i] / 255 - mean[2]) / std[2]);
                    }
                });
            }
            return data;
        }

        /// <summary>
        /// 輸入0~1正規化數據，返回 float 0~255
        /// </summary>
        /// <returns></returns>
        public static float[] DeNormalizeData(float[] data, double mean = 0.5, double std = 0.5)
        {
            int count = data.Length;
            Parallel.For(0, count, i =>
            {
                data[i] = (float)((data[i] * std) + mean) * 255;
            });
            return data;
        }

        public static float[] BitmapToArray(Bitmap image)
        {
            const int R = 2;
            const int G = 1;
            const int B = 0;
            Rectangle oRect = new Rectangle(0, 0, image.Width, image.Height);
            BitmapData BitData = image.LockBits(oRect,
                ImageLockMode.ReadWrite, image.PixelFormat);
            int channel = 3;
            if (image.PixelFormat == PixelFormat.Format8bppIndexed)
                channel = 1;
            int offset = BitData.Stride - BitData.Width * channel;
            float[] data = new float[BitData.Width * BitData.Height * channel];
            int size = BitData.Width * BitData.Height;
            // 啟動不安全模式
            unsafe
            {
                byte* ptr = (byte*)(BitData.Scan0);
                for (int i = 0; i < BitData.Height; i++)
                {
                    for (int j = 0; j < BitData.Width; j++)
                    {
                        if (channel > 1)
                        {
                            int index = i * BitData.Width + j;
                            data[0 + index] = (byte)ptr[R];
                            data[size + index] = (byte)ptr[G];
                            data[2 * size + index] = (byte)ptr[B];
                        }
                        else
                        {
                            data[i * BitData.Width + j] = (byte)ptr[0];
                        }
                        ptr += channel;
                    }
                    ptr += offset;
                }
            }
            image.UnlockBits(BitData);
            return data;
        }

        public static Bitmap ResizeBitmap(Bitmap bmp, int width, int height)
        {
            Bitmap result = new Bitmap(width, height,
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.DrawImage(bmp, 0, 0, width, height);
            }

            if (bmp.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                Bitmap gray = BitmapRGBtoGray(result);
                result.Dispose();
                return gray;
            }
            return result;
        }

        public static Bitmap CreateGrayscaleImage(int width, int height)
        {
            // create new image
            Bitmap image = new Bitmap(width, height,
                PixelFormat.Format8bppIndexed);
            // get palette
            System.Drawing.Imaging.ColorPalette cp = image.Palette;
            // init palette with grayscale colors
            for (int i = 0; i < 256; i++)
            {
                cp.Entries[i] = Color.FromArgb(i, i, i);
            }
            // set palette back
            image.Palette = cp;
            // return new image
            return image;
        }

        public static Bitmap CreateRGBImage(int width, int height)
        {
            // create new image
            Bitmap image = new Bitmap(width, height,
                PixelFormat.Format24bppRgb);
            return image;
        }

        public static Bitmap BitmapRGBtoGray(Bitmap image)
        {
            Bitmap gray = CreateGrayscaleImage(image.Width, image.Height);

            Rectangle oRect = new Rectangle(0, 0, image.Width, image.Height);
            BitmapData grayBitdata = gray.LockBits(oRect,
                ImageLockMode.ReadWrite, gray.PixelFormat);

            BitmapData rgbBitdata = image.LockBits(oRect,
                ImageLockMode.ReadWrite, image.PixelFormat);

            int channel = 3;
            if (image.PixelFormat == PixelFormat.Format32bppArgb)
                channel = 4;

            int grayoffset = grayBitdata.Stride - grayBitdata.Width;
            int rgboffset = rgbBitdata.Stride - grayBitdata.Width * channel;

            byte[] data = new byte[grayBitdata.Width * grayBitdata.Height];
            // 啟動不安全模式
            unsafe
            {
                byte* grayptr = (byte*)(grayBitdata.Scan0);
                byte* rgbptr = (byte*)(rgbBitdata.Scan0);
                for (int i = 0; i < grayBitdata.Height; i++)
                {
                    for (int j = 0; j < grayBitdata.Width; j++)
                    {
                        grayptr[0] = (byte)((double)(rgbptr[0]+ rgbptr[1] + rgbptr[2])/3.0);
                        data[i * grayBitdata.Width + j] = grayptr[0];
                        grayptr++;
                        rgbptr += channel;
                    }
                    grayptr += grayoffset;
                    rgbptr += rgboffset;
                }
            }
            gray.UnlockBits(grayBitdata);
            image.UnlockBits(rgbBitdata);
            return gray;
        }

        public static Bitmap BitmapGraytoRGB(Bitmap image)
        {
            Bitmap rgb = CreateRGBImage(image.Width, image.Height);

            Rectangle oRect = new Rectangle(0, 0, image.Width, image.Height);
            BitmapData rgbBitdata = rgb.LockBits(oRect,
                ImageLockMode.ReadWrite, rgb.PixelFormat);

            BitmapData grayBitdata = image.LockBits(oRect,
                ImageLockMode.ReadWrite, image.PixelFormat);

            int grayoffset = grayBitdata.Stride - grayBitdata.Width;
            int rgboffset = rgbBitdata.Stride - grayBitdata.Width * 3;

            byte[] data = new byte[grayBitdata.Width * grayBitdata.Height];
            // 啟動不安全模式
            unsafe
            {
                byte* grayptr = (byte*)(grayBitdata.Scan0);
                byte* rgbptr = (byte*)(rgbBitdata.Scan0);
                for (int i = 0; i < grayBitdata.Height; i++)
                {
                    for (int j = 0; j < grayBitdata.Width; j++)
                    {
                        rgbptr[0] = grayptr[0];
                        rgbptr[1] = grayptr[0];
                        rgbptr[2] = grayptr[0];
                        data[i * grayBitdata.Width + j] = grayptr[0];
                        grayptr++;
                        rgbptr += 3;
                    }
                    grayptr += grayoffset;
                    rgbptr += rgboffset;
                }
            }
            rgb.UnlockBits(grayBitdata);
            image.UnlockBits(rgbBitdata);
            return rgb;
        }

        public static Bitmap ArrayToBitmap(float[] data,int channel, int width, int height)
        {
            const int R = 2;
            const int G = 1;
            const int B = 0;

            Bitmap result = null;

            if(channel == 1)
            {
                result = CreateGrayscaleImage(width, height);
            }
            else
            {
                result = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            }

            Rectangle oRect = new Rectangle(0, 0, result.Width, result.Height);
            BitmapData BitData = result.LockBits(oRect,
                ImageLockMode.ReadWrite, result.PixelFormat);
            int offset = BitData.Stride - BitData.Width * channel;
            int size = BitData.Width * BitData.Height;
            // 啟動不安全模式
            unsafe
            {
                byte* ptr = (byte*)(BitData.Scan0);
                for (int i = 0; i < BitData.Height; i++)
                {
                    for (int j = 0; j < BitData.Width; j++)
                    {
                        if (channel > 1)
                        {
                            int index = i * BitData.Width + j;
                            ptr[R] = (byte)data[0 + index];
                            ptr[G] = (byte)data[size + index];
                            ptr[B] = (byte)data[2 * size + index];
                        }
                        else
                        {
                            ptr[0] = (byte)data[i * BitData.Width + j];
                        }
                        ptr += channel;
                    }
                    ptr += offset;
                }        
            }
            result.UnlockBits(BitData);
            return result;
        }

        public static Bitmap ChannelConvertBitmap(Bitmap bmp, int channel)
        {
            if(channel < 1)
                return bmp;

            PixelFormat format = bmp.PixelFormat;
            if (format == PixelFormat.Format8bppIndexed)
            {
                if(channel > 1)
                {
                    return BitmapGraytoRGB(bmp);
                }
            }
            else
            {
                if (channel ==1)
                {
                    return BitmapRGBtoGray(bmp);
                }
            }

            return bmp;
        }

        public static byte[] MinMaxToByte(float[] input)
        {
            byte[] result =new byte[input.Length];
            float max = -1;
            float min = 100000;
            Parallel.For(0, input.Length,
            index =>
            {
                if (input[index] >= max)
                    max = input[index];
                else if (input[index] <= min)
                    min = input[index];
            });
            Parallel.For(0, input.Length,
             index =>
             {
                 if (input[index] < 1)
                     result[index] = 0;
                 result[index] = (byte)((input[index]- min)/(max-min) * 255);
             });
            return result;
        }
        public static double StandardDeviation(float[] sequence)
        {
            double result = 0;

            if (sequence.Length>0)
            {
                float average = (float)sequence.AsParallel().Average();
                float[] std = (float[])sequence.Clone();
                Parallel.For(0, sequence.Length,
                index =>
                {
                    std[index] = (sequence[index] - average) * (sequence[index] - average);
                });
                double sum = std.AsParallel().Sum();
                result = Math.Sqrt((sum) / (sequence.Length - 1));
            }
            return result;
        }
    }
}
