﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace Brandy
{
    public class HealthyLogger
    {
        ////////////////////////////////////////////
        // Properties
        //------------------------------------------
        public string logPath { get; set; }
        public string logFilename { get; set; }
        public DateTime logDate { get; set; }

        StreamWriter logFile;

        public HealthyLogger()
        {
            this.logPath = "";
            this.logFilename = "";
        }

        //Destructor
        ~HealthyLogger()
        {
            //   釋放 SteamWriter 空間
            if (this.logFile.BaseStream != null)
            {
                this.logFile.Close();
            }
        }

        public void Open(string path, string filename)
        {
            logDate = DateTime.Today;
            logFilename = filename;
            logPath = path;

            try
            {
                if (File.Exists(String.Format("{0}\\{1}.log",
                     this.logPath, this.logFilename)))
                    File.Delete(String.Format("{0}\\{1}.log",
                     this.logPath, this.logFilename));
                //   開啟檔案
                logFile = File.AppendText(
                     String.Format("{0}\\{1}.log",
                     this.logPath, this.logFilename));

                //   設定自動清除 - 當資料寫入時會自動將除了編碼器狀態外的其他狀態都清除
                logFile.AutoFlush = true;

                //   寫入檔案開啟時間
                logFile.WriteLine(
                     "=============== LOG START - {0:yyyy}.{0:MM}.{0:dd} {0:HH}:{0:mm}:{0:ss}:{0:ffff} ===============",
                     logDate);
            }
            catch (Exception ex)
              {
                throw ex;
            }
        }

        public void Close()
        {
            DateTime logCloseDate = DateTime.Today;
            try
            {
                logFile.WriteLine(
                     "===============   LOG END - {0:yyyy}.{0:MM}.{0:dd} {0:HH}:{0:mm}:{0:ss}:{0:ffff} ===============",
                     logCloseDate);

                logFile.Close();
            }
            catch (Exception )
            {
            }
        }
        public void Write(String message)
        {
            DateTime writeTime = DateTime.Now;
            try
            {
                logFile.WriteLine(
                     "{0:yyyy}/{0:MM}/{0:dd}, {0:HH}:{0:mm}:{0:ss}:{0:ffff} - {1}",
                     writeTime, message);
            }
            catch (Exception)
            {
            }
        }
    }
    public class HealthyConfig
    {
        public double IntervalTime { get; set; }
        public bool isPostHealthy { get; set; }
        public string healthyServerAddress { get; set; }
        public int healthyConnectTimeOut { get; set; }
        public int healthyReadWriteTimeOut { get; set; }
        public string healthyFab { get; set; }
        public string healthyProjectId { get; set; }
        public string healthyStatusExpireTime { get; set; }

        public HealthyConfig()
        {
            IntervalTime = 60;
            // Healthy
            this.isPostHealthy = false;
            this.healthyServerAddress = "testHealthyAddress";
            this.healthyConnectTimeOut = 2000;
            this.healthyReadWriteTimeOut = 2000;
            this.healthyFab = "testHealthyFab";
            this.healthyProjectId = "testHealthyProjectId";
            this.healthyStatusExpireTime = "9527";
        }
        public HealthyConfig ReadXML(string filename)
        {
            try
            {
                if (!File.Exists(filename))
                    WriteXML(filename);
                XmlSerializer serializer = new XmlSerializer(typeof(HealthyConfig));
                StreamReader sr = new StreamReader(filename, System.Text.Encoding.Default);
                HealthyConfig m_Object = (HealthyConfig)serializer.Deserialize(sr);
                sr.Close();
                return m_Object;
            }
            catch (Exception ex) 
            {
                throw new Exception("[Healthy.ReadXML] Read Healthy XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }
        public void WriteXML(string filename)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(HealthyConfig));
                StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Unicode);
                serializer.Serialize(sw, this);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("[Healthy.WriteXML] Write Healthy XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }
    }
    public class HealthyJosn
    {
        public string  fab;
        public string project_id;
        public string ai_status;
        public string status_expire_time;
        public string err_code;

        public HealthyJosn()
        {
            fab = "testFab";
            project_id = "testProjectId";
            ai_status = "RUN";
            status_expire_time = "9527";
            err_code = "TEST";
        }
    };
    public class Healthy
    {
        bool islife = false;
        HealthyConfig healthyConfig;
        HealthyLogger log;
        public string Name { get; }
        public Healthy(string name = "")
        {
            healthyConfig = new HealthyConfig();
            string path = System.IO.Directory.GetCurrentDirectory();
            Name = name;

            if (Name == "")
                healthyConfig = healthyConfig.ReadXML(path + "\\HealthyConfig.xml");
            else
            {
                healthyConfig = healthyConfig.ReadXML(path + "\\HealthyConfig_"+ Name +".xml");
            }

            log = new HealthyLogger();
            if(Name == "")
                log.Open(path, "HealthyMessage");
            else
            {
                log.Open(path, "HealthyMessage_" + Name);
            }
        }
        public void Dispose()
        {
            Stop();
            log.Close();
        }
        ~Healthy()
        {
            Dispose();
        }
        public void ShowDialog()
        {
            HealthyConfigSetting form = new HealthyConfigSetting(Name, healthyConfig);
            form.ShowDialog();
            healthyConfig = form.cfg;
        }

        public void Run()
        {
            islife = true;
            log.Write("Run");
            Task.Run(() => RunCycle());
        }
        public void Stop()
        {
            log.Write("Stop");
            islife = false;
            System.Threading.Thread.Sleep(100);
        }
        void RunCycle()
        {
            try
            {
                DateTime TimeNow = DateTime.Now;
                DateTime TimePrevious = DateTime.Now;
                double intevaltime = healthyConfig.IntervalTime;
                while (islife)
                {
                    TimeNow = DateTime.Now;
                    TimeSpan ts = TimeNow - TimePrevious;
                    if(ts.TotalSeconds > intevaltime)
                    {
                        SendHealty();
                        TimePrevious = DateTime.Now;
                    }
                    System.Threading.Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                log.Write(ex.StackTrace + " : " + ex.Message);
                islife = false;
            }
            try
            {
                log.Write("Run Thread Stop");
            }
            catch (Exception)
            {
            }

        }
        
        void  SendHealty()
        {
            if (!healthyConfig.isPostHealthy)
            {
                return;
            }

            // Convert to json format
            HealthyJosn healthyJosn = new HealthyJosn();
            healthyJosn.fab = healthyConfig.healthyFab;
            healthyJosn.project_id = healthyConfig.healthyProjectId;
            healthyJosn.status_expire_time = healthyConfig.healthyStatusExpireTime;

            string strJson = JsonConvert.SerializeObject(healthyJosn, Newtonsoft.Json.Formatting.Indented);

            // Convert to Byte

            byte[] bs = System.Text.Encoding.ASCII.GetBytes(strJson);

            // HttpWebRequest
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(healthyConfig.healthyServerAddress);
            request.Method = "POST";
            request.Timeout = healthyConfig.healthyConnectTimeOut;
            request.ReadWriteTimeout = healthyConfig.healthyReadWriteTimeOut;
            request.ContentType = "application/json";
            request.ContentLength = bs.Length;

            try
            {
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bs, 0, bs.Length);
                requestStream.Flush();
            }
            catch (Exception ex) {
                log.Write(ex.StackTrace + " : " + ex.Message);
            }

            String responseStr = "";
            try
            {
                WebResponse response = request.GetResponse();

                StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8);

                responseStr = reader.ReadToEnd();

                response.Close();
            }
            catch (Exception ex) {
                log.Write(ex.StackTrace + " : " + ex.Message);
            }
            try
            {
                //輸出Server端回傳字串
                log.Write("SendHealty Response:" + responseStr);
            }
            catch (Exception)
            {
            }


        }
    }
}
