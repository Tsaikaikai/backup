﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;


namespace Brandy
{
    public enum ModelTpye
    {
        CycleGan,
        Ganormaly,
        CSPResNet18,
        STPM,
        Regression,
        YoloV7Model,
        ChangeDetection,
    };

    public class OnnxCore : IDisposable
    {
        InferenceSession _session = null;
        ModelTpye _modelTpye = ModelTpye.ChangeDetection;
        int[] _inputShape = null;
        int[] _outputShape = null;
        float[] _outputData = null;
        string _inputName = null;
        string _inputName2 = null;
        string _outputName = null;

        private bool _disposedValue = false; // 偵測多餘的呼叫
        public float[] Output
        {
            get { return _outputData; }
        }
        public int[] InputShape
        {
            get { return _inputShape; }
        }
        public int[] OutputShape
        {
            get { return _outputShape; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="modelPath">onnx file path</param>
        /// <param name="gpuid"> gpu id,if = -1 ,use cpu</param>
        /// <param name="modeltype"></param>
        public OnnxCore(string modelPath, int gpuid, ModelTpye modeltype)
        {
            try
            {
                _modelTpye = modeltype;
                if (!CheckModelName())
                {
                    throw new Exception("Load Model Error, " + "Model Type Error");
                }
                if (gpuid < 0)
                {
                    SessionOptions options = new SessionOptions();
                    options.GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_EXTENDED;

                    _session = new InferenceSession(modelPath, options);
                }
                else
                {
                    _session = new InferenceSession(modelPath,
                        SessionOptions.MakeSessionOptionWithCudaProvider(gpuid));
                }
                if (_session == null)
                    throw new Exception("Load Model Error, " + modelPath);
                else
                {
                    var inputMeta = _session.InputMetadata;
                    _inputShape = inputMeta[_inputName].Dimensions;
                }
                if (_modelTpye == ModelTpye.ChangeDetection)
                {
                    PreInference_twoinput();
                }
                else    PreInference();          
            }
            catch (Exception ex)
            {
                Dispose();
                throw ex;
            }

        }
        ~OnnxCore()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    if (_session != null)
                    {
                        _session.Dispose();
                        _session = null;
                    }
                    _inputShape = null;
                    _outputData = null;
                    _outputShape = null;
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void PreInference()
        {
            var inputMeta = _session.InputMetadata;
            int[] shape = new int[4];
            if (_inputShape[0] == -1)
                shape[0] = 1;
            else
                shape[0] = _inputShape[0];
            if (_inputShape[1] == -1)
                shape[1] = 3;
            else
                shape[1] = _inputShape[1];
            if (_inputShape[2] == -1)
                shape[2] = 256;
            else
                shape[2] = _inputShape[2];
            if (_inputShape[3] == -1)
                shape[3] = 256;
            else
                shape[3] = _inputShape[3];
            float[] data = new float[shape[1] * shape[2] * shape[3]];
            var container = new List<NamedOnnxValue>();
            var tensor = new DenseTensor<float>(data, shape);
            container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));

            _outputData = null;
            var results = _session.Run(container);
            bool outNameState = false;

            foreach (var r in results)
            {
                if (!outNameState && r.Name == _outputName)
                {
                    var rr = (DenseTensor<float>)r.Value;
                    _outputShape = rr.Dimensions.ToArray();
                    outNameState = true;
                }
            }
            if (outNameState != true)
                throw new Exception("OutputName Error, No find Model output Name. " + _outputName);
            results.Dispose();
        }

        void PreInference_twoinput()
        {
            var inputMeta = _session.InputMetadata;
            int[] shape = new int[4];
            if (_inputShape[0] == -1)
                shape[0] = 1;
            else
                shape[0] = _inputShape[0];
            if (_inputShape[1] == -1)
                shape[1] = 3;
            else
                shape[1] = _inputShape[1];
            if (_inputShape[2] == -1)
                shape[2] = 256;
            else
                shape[2] = _inputShape[2];
            if (_inputShape[3] == -1)
                shape[3] = 256;
            else
                shape[3] = _inputShape[3];
            float[] data = new float[shape[1] * shape[2] * shape[3]];
            var container = new List<NamedOnnxValue>();
            var tensor = new DenseTensor<float>(data, shape);
            container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));
            container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName2, tensor));
            _outputData = null;
            var results = _session.Run(container);
            bool outNameState = false;

            foreach (var r in results)
            {
                if (!outNameState && r.Name == _outputName)
                {
                    var rr = (DenseTensor<float>)r.Value;
                    _outputShape = rr.Dimensions.ToArray();
                    outNameState = true;
                }
            }
            if (outNameState != true)
                throw new Exception("OutputName Error, No find Model output Name. " + _outputName);
            results.Dispose();
        }
        bool CheckModelName()
        {
            bool state = true;
            switch (_modelTpye)
            {
                case ModelTpye.CycleGan:
                    _inputName = "CycleGanInput";
                    _outputName = "CycleGanOutput";
                    break;
                case ModelTpye.Ganormaly:
                    _inputName = "GanormalyInput";
                    _outputName = "GanormalyOutput";
                    break;
                case ModelTpye.CSPResNet18:
                    _inputName = "CspNet_input";
                    _outputName = "CspNet_output";
                    break;
                case ModelTpye.STPM:
                    _inputName = "STPMInput";
                    _outputName = "STPMOutput";
                    break;
                case ModelTpye.Regression:
                    _inputName = "Regression_input";
                    _outputName = "Regression_output";
                    break;
                case ModelTpye.YoloV7Model:
                    _inputName = "images";
                    _outputName = "output";
                    break;
                case ModelTpye.ChangeDetection:
                    _inputName = "ChangeDetection_input1";
                    _inputName2 = "ChangeDetection_input2";
                    _outputName = "ChangeDetection_output";
                    break;
                default:
                    state = false;
                    break;
            }
            return state;
        }
        /// <summary>
        /// Inference Network , the data array order is channel,height,width
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Inference(float[] data)
        {
            try
            {
                bool outNameState = false;
                int batchSize = 1;
                List<NamedOnnxValue> container = new List<NamedOnnxValue>();

                if (data.Length != batchSize * _inputShape[1] * _inputShape[2] * _inputShape[3])
                {
                    throw new Exception("Inference Error, data size should be " + batchSize.ToString() + "," + _inputShape[1].ToString() + "," + _inputShape[2].ToString() + "," + _inputShape[3].ToString());
                }
                else
                {
                    DenseTensor<float> tensor = new DenseTensor<float>(data, new[] { batchSize, _inputShape[1], _inputShape[2], _inputShape[3] });
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));
                }

                _outputData = null;
                var results = _session.Run(container);

                foreach (var r in results)
                {
                    if (r.Name == _outputName)
                    {
                        _outputData = r.AsTensor<float>().ToArray();
                        outNameState = true;
                    }
                }
                results.Dispose();

                if (outNameState == false)
                    throw new Exception("Inference Error, No find Model output Name " + _outputName);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName + "," + ex.ToString());
            }
        }

        public bool BatchInference(float[] data , int batchSize)
        {
            try
            {
                bool outNameState = false;
                List<NamedOnnxValue> container = new List<NamedOnnxValue>();

                if (data.Length != batchSize * _inputShape[1] * _inputShape[2] * _inputShape[3])
                {
                    throw new Exception("Inference Error, data size should be " + batchSize.ToString() + " " + _inputShape[1].ToString() + " " + _inputShape[2].ToString() + " " + _inputShape[3].ToString());
                }
                else
                {
                    DenseTensor<float> tensor = new DenseTensor<float>(data, new[] { batchSize , _inputShape[1], _inputShape[2], _inputShape[3]});
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));
                }


                _outputData = null;
                var results = _session.Run(container);

                foreach (var r in results)
                {
                    if (r.Name == _outputName)
                    {
                        _outputData = r.AsTensor<float>().ToArray();
                    }
                    outNameState = true;
                }
                results.Dispose();

                if (outNameState == false)
                {
                    throw new Exception("Inference Error, No find Model output Name " + _outputName);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName + "," + ex.ToString());
            }
        }

        public bool BatchInference_twoinput(float[] data1, float[] data2, int batchSize)
        {
            try
            {
                bool outNameState = false;
                List<NamedOnnxValue> container = new List<NamedOnnxValue>();

                if (data1.Length != batchSize * _inputShape[1] * _inputShape[2] * _inputShape[3] || 
                    data2.Length != batchSize * _inputShape[1] * _inputShape[2] * _inputShape[3])
                {
                    throw new Exception("Inference Error, data size should be " + batchSize.ToString() + " " + _inputShape[1].ToString() + " " + _inputShape[2].ToString() + " " + _inputShape[3].ToString());
                }
                else
                {
                    DenseTensor<float> tensor1 = new DenseTensor<float>(data1, new[] { batchSize, _inputShape[1], _inputShape[2], _inputShape[3] });
                    DenseTensor<float> tensor2 = new DenseTensor<float>(data2, new[] { batchSize, _inputShape[1], _inputShape[2], _inputShape[3] });
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor1));
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName2, tensor2));
                }

                _outputData = null;
                var results = _session.Run(container);

                foreach (var r in results)
                {
                    if (r.Name == _outputName)
                    {
                        _outputData = r.AsTensor<float>().ToArray();
                    }
                    outNameState = true;
                }
                results.Dispose();

                if (outNameState == false)
                {
                    throw new Exception("Inference Error, No find Model output Name " + _outputName);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName + "," + ex.ToString());
            }
        }

        /// <summary>
        /// Inference Network , the data array order is channel,height,width
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Inference(string filename)
        {
            try
            {
                if (!System.IO.File.Exists(filename))
                    return false;
                Bitmap image = new Bitmap(filename);
                if (_inputShape[2] != image.Height || _inputShape[3] != image.Width)
                {
                    image = Util.ResizeBitmap(image, _inputShape[3], _inputShape[2]);
                }
                float[] data = Util.BitmapToArray(image);
                data = Util.NormalizeData(data);
                return Inference(data);
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName + "," + ex.ToString());
            }
        }
        public bool Inference_twoinput(float[] data1, float[] data2)
        {
            try
            {
                bool outNameState = false;
                if (data1.Length != _inputShape[1] * _inputShape[2] * _inputShape[3])
                    return false;
                else if (data2.Length != _inputShape[1] * _inputShape[2] * _inputShape[3])
                    return false;
                else
                {
                    var container = new List<NamedOnnxValue>();
                    var tensor1 = new DenseTensor<float>(data1, _inputShape);
                    var tensor2 = new DenseTensor<float>(data2, _inputShape);
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor1));
                    container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName2, tensor2));
                    _outputData = null;
                    var results = _session.Run(container);

                    foreach (var r in results)
                    {
                        if (r.Name == _outputName)
                        {
                            _outputData = r.AsTensor<float>().ToArray();
                            outNameState = true;
                        }
                    }
                    results.Dispose();
                }
                if (outNameState == false)
                    throw new Exception("Inference Error, No find Model output Name " + _outputName);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName + "," + ex.ToString());
            }

        }
    }
}
