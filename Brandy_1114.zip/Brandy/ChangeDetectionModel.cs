﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Runtime.InteropServices;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Util;
namespace Brandy
{
    public class ChangeDetectionModel
    {
        int _inputChannel = 3;
        int _outputChannel = 1;
        IDisposableReadOnlyCollection<DisposableNamedOnnxValue> _results;
        OnnxCore _core = null;
        float[] _result = null;

        public float[] Output
        {
            get { return _result; }
        }
        String[] _inputName = { "ChangeDetection_input1", "ChangeDetection_input2" };
        String _outputName = "ChangeDetection_output";

        private bool _disposedValue = false; // 偵測多餘的呼叫

        public List<BrandyImage> GetOutputImage(float threshold, int batchSize)
        {
            try
            {
                List<BrandyImage> outputImages = new List<BrandyImage>();
                int img_size = _core.OutputShape[3]*_core.OutputShape[2];
                
                for (int numBatch = 0; numBatch < batchSize; numBatch ++)
                {
                    float[] sub = new float[img_size];
                    for (int i = 0; i < img_size; i++)
                    {
                        if ((_result[(numBatch * 2 * img_size) + i + img_size] - _result[(numBatch * 2 * img_size) + i]) > threshold) sub[i] = 255;
                        else sub[i] = 0;
                    }
                    BrandyImage outputImage = new BrandyImage(sub, ImageChannel.Gray, _core.OutputShape[3], _core.OutputShape[2]);
                    outputImage.DeNormalize(ConvertMode.None);
                    //outputImage.Save("./" + numBatch.ToString() + ".bmp");
                    outputImages.Add(outputImage);
                }
                return outputImages;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InputChannel
        {
            get { return _inputChannel; }
        }
        public int OutputChannel
        {
            get { return _outputChannel; }
        }
        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public ChangeDetectionModel(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.ChangeDetection);
        }

        ~ChangeDetectionModel()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    if (_core != null)
                    {
                        _core.Dispose();
                        _core = null;
                    }
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Inference Network , the data array order is channel,height,width
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Inference(float[] data1, float[] data2)
        {
            bool state = false;
            try
            {
                double[] mean = new double[] { 0.485, 0.456, 0.406 };
                double[] std = new double[] { 0.229, 0.224, 0.225 };
                float[] inputData1 = Util.Normalize3DData(data1, mean, std);
                float[] inputData2 = Util.Normalize3DData(data2, mean, std);

                if (_core.Inference_twoinput(inputData1, inputData2))
                {
                    _result = _core.Output;
                    state = true;
                }
                else
                {
                    throw new Exception("Inference Error.");
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public bool Inference(string filename1, string filename2)
        {
            try
            {
                if (!System.IO.File.Exists(filename1) || !System.IO.File.Exists(filename2))
                    return false;

                BrandyImage image1 = new BrandyImage(filename1);
                BrandyImage image2 = new BrandyImage(filename2);
                return Inference(image1, image2);
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName[0] + "," + ex.ToString());
            }
        }

        public bool Inference(BrandyImage image1, BrandyImage image2)
        {
            try
            {
                if (_results != null)
                {
                    _results.Dispose();
                    _results = null;
                }
                float[] data1 = image1.GetPlannerDataFloat();
                float[] data2 = image2.GetPlannerDataFloat();
                image1.Dispose();
                image2.Dispose();
                return BatchInference(data1, data2,1);
                //return Inference(data1, data2);
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName[0] + "," + ex.ToString());
            }
        }

        public bool BatchInference(float[] data1, float[] data2, int batchSize)
        {
            bool state = false;
            try
            {
                double[] mean = new double[] { 0.485, 0.456, 0.406 };
                double[] std = new double[] { 0.229, 0.224, 0.225 };
                float[] inputData1 = Util.Normalize3DData(data1, mean, std);
                float[] inputData2 = Util.Normalize3DData(data2, mean, std);
                if (_core.BatchInference_twoinput(inputData1, inputData2, batchSize))
                {
                    _result = _core.Output;
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public float[,,] ArrayReshape3D(float[] input, int channel, int height, int width)
        {
            float[,,] output = new float[channel, height, width];
            for (int i = 0; i < channel; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    for (int k = 0; k < width; k++)
                    {
                        output[i, j, k] = input[i * height * width + j * width + k];
                    }
                }
            }
            return output;
        }
    }
    public class ChangeDetectionResult
    {
        public BrandyImage Compare;
        public ChangeDetectionResult(BrandyImage compare)
        {
            Compare = compare;
        }
    }
}
