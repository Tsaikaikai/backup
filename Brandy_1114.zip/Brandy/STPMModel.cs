﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emgu.CV;
using Emgu.CV.Util;

namespace Brandy
{
    public class StpmModel
    {
        BrandyImage _outputImage = null;
        OnnxCore _core = null;
        float[] _result = null;
        float _outputScale = 0;
        double _abnormalFactor = 0;

        int _imageInputWidth;
        int _imageInputHeight;

        int _imageResizeWidth;
        int _imageResizeHeight;

        bool _isFirstGetOutputImage;

        public float[] Output
        {
            get { return _result; }
        }
        public BrandyImage OutputImage
        {
            get
            {
                if(_isFirstGetOutputImage)
                {
                    if (_outputImage != null)
                    {
                        _outputImage.Dispose();
                        _outputImage = null;
                    }

                    _outputImage = new BrandyImage(_result, ImageChannel.Gray, _core.OutputShape[0], _core.OutputShape[0]);
                    _outputImage.CropCenter(_imageResizeWidth, _imageResizeHeight);
                    _outputImage.DeNormalize();
                    _outputImage.Resize(_imageInputWidth, _imageInputHeight);
                }
                return _outputImage;
            }
        }
        public double AbnormalFactor
        {
            get
            {
                return _abnormalFactor;
            }
        }
        public float OutputScale
        {
            get { return _outputScale; }
            set { _outputScale = value; }
        }

        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public StpmModel(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.STPM);
        }
        ~StpmModel()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }
        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
            if (_outputImage != null)
            {
                _outputImage.Dispose();
                _outputImage = null;
            }
        }
        bool Inference(float[] data)
        {
            bool state = false;
            try
            {
                float[] inputData = Util.NormalizeData(data);
                if (_core.Inference(data))
                {
                    _result = _core.Output;

                    _abnormalFactor = Util.StandardDeviation(_result) * 1000;
                    if(_outputScale > 0)
                        //DataScale(_result, _outputScale);
                        ResultThreshold(_result, _outputScale);
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public bool Inference(string filename)
        {
            try
            {
                _isFirstGetOutputImage = true;
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);
                return Inference(image);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                _isFirstGetOutputImage = true;
                _imageInputWidth = image.Width;
                _imageInputHeight = image.Height;
                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[2], ResizeMode.KeepRatio);
                _imageResizeWidth = image.Width;
                _imageResizeHeight = image.Height;
                image.Padding();
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return(Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        float[] DataScale(float[] input, float scaleFator)
        {
            Parallel.For(0, input.Length,
                         index =>
                         {
                             input[index] = input[index] * scaleFator;
                             if (input[index] < 1)
                                 input[index] = 0;
                         });
            return input;
        }

        float[] ResultThreshold(float[] input, float threshold)
        {
            Parallel.For(0, input.Length,
                         index => {
                             input[index] = input[index] - 1;
                             if (input[index] < Math.Round(threshold / 1000, 4))
                                 input[index] = 0;
                         });
            return input;
        }

    }
}

