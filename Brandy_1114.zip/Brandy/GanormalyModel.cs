﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brandy
{
    public class GanormalyModel
    {
        BrandyImage _outputImage = null;
        BrandyImage _abnormalImage = null;
        bool _isFirstGetOutputImage = false;
        bool _isFirstGetAbnormalImage = false;
        OnnxCore _core = null;
        float[] _result = null;
        float[] _abnormalResult = null;
        float _abnormalFactor = 0;
        bool _isCalculateFator = false;
        public bool IsCalculateFator
        {
            get { return _isCalculateFator; }
            set { _isCalculateFator = value; }
        }
        public float[] Output
        {
            get { return _result; }
        }
        public BrandyImage OutputImage
        {
            get
            {
                if (_isFirstGetOutputImage)
                {
                    if (_outputImage != null)
                    {
                        _outputImage.Dispose();
                        _outputImage = null;
                    }
                    ImageChannel channel = ImageChannel.Gray;
                    if (_core.OutputShape[1] > 1)
                        channel = ImageChannel.RGBPlanner;
                    _outputImage = new BrandyImage(_result, channel, _core.OutputShape[3], _core.OutputShape[2]);
                    _outputImage.DeNormalize(ConvertMode.None);
                    _isFirstGetOutputImage = false;
                }
                return _outputImage;
            }
        }

        public BrandyImage AbnormalImage
        {
            get
            {
                if (!_isCalculateFator)
                    return null;
                if (_isFirstGetAbnormalImage)
                {
                    if (_abnormalImage != null)
                    {
                        _abnormalImage.Dispose();
                        _abnormalImage = null;
                    }
                    ImageChannel channel = ImageChannel.Gray;
                    if (_core.OutputShape[1] > 1)
                        channel = ImageChannel.RGBPlanner;
                    _abnormalImage = new BrandyImage(_abnormalResult, channel, _core.OutputShape[3], _core.OutputShape[2]);
                    _abnormalImage.DeNormalize(ConvertMode.None);
                    _isFirstGetAbnormalImage = false;
                }
                return _abnormalImage;
            }
        }
        public float AbnormalFactor
        {
            get { return _abnormalFactor; }
        }

        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public GanormalyModel(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.Ganormaly);
        }
        ~GanormalyModel()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }
        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
            if (_outputImage != null)
            {
                _outputImage.Dispose();
                _outputImage = null;
            }
        }
        bool Inference(float[] data)
        {
            bool state = false;
            _isFirstGetOutputImage = true;
            _isFirstGetAbnormalImage = true;
            try
            {
                float[] inputData = Util.NormalizeData(data);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    if(_isCalculateFator)
                    {
                        _abnormalResult = CalculateAbnormal(inputData, _result, out _abnormalFactor);
                        _abnormalResult = Util.DeNormalizeData(_abnormalResult);
                    }
                    _result = Util.DeNormalizeData(_result);
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public bool Inference(string filename)
        {
            try
            {
                try
                {
                    if (!System.IO.File.Exists(filename))
                        return false;

                    BrandyImage image = new BrandyImage(filename);
                    return Inference(image);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[2], ResizeMode.Default);
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return (Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        float[] CalculateAbnormal(float[] input, float[] output,out float fator)
        {
            fator = 0;
            float[]diff = null;
            if (input.Length != output.Length)
                return diff;
            else
            {
                diff = new float[input.Length];
                Parallel.For(0, input.Length,
                             index => {
                                 var value = input[index] - output[index];
                                 if (value < 0)
                                     value *= -1;
                                 diff[index] = value;
                             });
                fator = diff.AsParallel().Sum() / diff.Length;
                return diff;
            }
        }
    }
}
