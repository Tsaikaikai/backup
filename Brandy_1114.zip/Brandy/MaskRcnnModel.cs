﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Runtime.InteropServices;

namespace Brandy
{
    public class MaskRcnnModel : IDisposable
    {
        InferenceSession _session = null;
        int _imageInputWidth;
        int _imageInputHeight;

        int _inputChannel = 3;
        int _outputChannel = 1;
        IDisposableReadOnlyCollection<DisposableNamedOnnxValue> _results;

        String _inputName = "MaskRcnn_input";
        String[] _outputName = { "MaskRcnn_masks" };

        private bool _disposedValue = false; // 偵測多餘的呼叫

        public List<MaskRcnnResult> GetResults()
        {
            float[] box_output = null;
            long[] label_output = null;
            float[] score_output = null;
            float[] mask_output = null;
            List <MaskRcnnResult> result =null;

            foreach (var r in _results)
            {
                switch (r.Name)
                {
                    case "MaskRcnn_boxes":
                        box_output = r.AsTensor<float>().ToArray();
                        break;

                    case "MaskRcnn_labels":
                        label_output = r.AsTensor<long>().ToArray();
                        break;

                    case "MaskRcnn_scores":
                        score_output = r.AsTensor<float>().ToArray();
                        break;

                    case "MaskRcnn_masks":
                        mask_output= r.AsTensor<float>().ToArray();
                        break;

                    default:
                        break;
                }

            }
            int number = label_output.Length;
            int boxlengh = 4;
            if (number > 0)
            {
                int masklengh = mask_output.Length / number;

                result = new List<MaskRcnnResult>();
                for (int i = 0; i < number; i++)
                {
                    int p1x = (int)Math.Round(box_output[i * boxlengh]);
                    int p1y = (int)Math.Round(box_output[i * boxlengh + 1]);
                    int p2x = (int)Math.Round(box_output[i * boxlengh + 2]);
                    int p2y = (int)Math.Round(box_output[i * boxlengh + 3]);
                    Rectangle rect = new Rectangle(p1x, p1y, p2x - p1x, p2y - p1y);
                    float[] data = new float[masklengh];
                    Array.Copy(mask_output, i * masklengh, data, 0, masklengh);
                    BrandyImage mask = new BrandyImage(data, ImageChannel.Gray, _imageInputWidth, _imageInputHeight);
                    mask.DeNormalize(ConvertMode.MinMax);
                    result.Add(new MaskRcnnResult(rect, (int)label_output[i],
                        score_output[i], mask));
                }
            }
            return result;
        }

        public int InputChannel
        {
            get { return _inputChannel; }
        }
        public int OutputChannel
        {
            get { return _outputChannel; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="modelPath">onnx file path</param>
        /// <param name="gpuid"> gpu id,if = -1 ,use cpu</param>
        /// <param name="modeltype"></param>
        public MaskRcnnModel(string modelPath, int gpuid)
        {
            try
            {
                if (gpuid < 0)
                {
                    SessionOptions options = new SessionOptions();
                    options.GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_EXTENDED;

                    _session = new InferenceSession(modelPath, options);
                }
                else
                {
                    _session = new InferenceSession(modelPath, SessionOptions.MakeSessionOptionWithCudaProvider(gpuid));
                }
                if (_session == null)
                    throw new Exception("Load Model Error, " + modelPath);
                else
                {
                    var inputMeta = _session.InputMetadata;
                    var Shape = inputMeta[_inputName].Dimensions;
                    _inputChannel = Shape[1];
                }

                PreInference();
            }
            catch (Exception ex)
            {
                Dispose();
                throw ex;
            }

        }
        ~MaskRcnnModel()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    if (_session != null)
                    {
                        _session.Dispose();
                        _session = null;
                    }
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void PreInference()
        {
            int[] testShape = { 1, _inputChannel, 512, 512 };
            float[] data = new float[testShape[1] * testShape[2] * testShape[3]];
            var container = new List<NamedOnnxValue>();
            var tensor = new DenseTensor<float>(data, testShape);
            container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));

            var results = _session.Run(container);
            bool outNameState = false;

            foreach (var r in results)
            {
                if (!outNameState && r.Name == _outputName[0])
                {
                    outNameState = true;
                }
            }
            if (outNameState != true)
                throw new Exception("OutputName Error, No find Model output Name. " + _outputName[0]);
            results.Dispose();
        }
        /// <summary>
        /// Inference Network , the data array order is channel,height,width
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool Inference(float[] data, int h ,int w)
        {
            try
            {
                if(_results!=null)
                {
                    _results.Dispose();
                    _results = null;
                }
                data = Util.NormalizeData(data, 0, 1);
                var container = new List<NamedOnnxValue>();

                var tensor = new DenseTensor<float>(data,new int[] {1,_inputChannel , h ,w });
                container.Add(NamedOnnxValue.CreateFromTensor<float>(_inputName, tensor));

                _results = _session.Run(container);

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName[0] + "," + ex.ToString());
            }

        }
        public bool Inference(string filename)
        {
            try
            {
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);

                return Inference(image);
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName[0] + "," + ex.ToString());
            }

        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                if (_results != null)
                {
                    _results.Dispose();
                    _results = null;
                }
                _imageInputWidth = image.Width;
                _imageInputHeight = image.Height;
                float[] data = image.GetPlannerDataFloat();
                image.Dispose();
                return Inference(data, _imageInputHeight, _imageInputWidth);
            }
            catch (Exception ex)
            {
                throw new Exception("Inference Error" + _outputName[0] + "," + ex.ToString());
            }

        }
    }
    public class MaskRcnnResult
    {
        public Rectangle Box { get; set; }
        public int Label { get; set; }
        public float Score { get; set; }
        public BrandyImage Mask;
        public MaskRcnnResult(Rectangle box, int label , float score , BrandyImage mask)
        {
            Box = box;
            Label = label;
            Score = score;
            Mask = mask;
        }
    }
}
