﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brandy
{
    public partial class HealthyConfigSetting : Form
    {
        string HealthyName;
        public HealthyConfig cfg { get; set; }

        public HealthyConfigSetting(string name, HealthyConfig config)
        {
            InitializeComponent();
            cfg = config;
            propertyGrid1.SelectedObject = cfg;
            HealthyName = name;
            btn_OK.DialogResult = DialogResult.OK;
            btn_Cancel.DialogResult = DialogResult.Cancel;
            if (HealthyName != "")
                label1.Text += " : " + HealthyName;
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            string path = System.IO.Directory.GetCurrentDirectory();
            if (HealthyName == "")
                cfg = cfg.ReadXML(path + "\\HealthyConfig.xml");
            else
            {
                cfg = cfg.ReadXML(path + "\\HealthyConfig_" + HealthyName + ".xml");
            }

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            string path = System.IO.Directory.GetCurrentDirectory();

            if (HealthyName == "")
                cfg.WriteXML(path + "\\HealthyConfig.xml");
            else
            {
                cfg.WriteXML(path + "\\HealthyConfig_" + HealthyName + ".xml");
            }
        }

        Point mousedownpoint = Point.Empty;

        private void Form_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void Form_MouseMove(object sender, MouseEventArgs e)
        {

            if (mousedownpoint.IsEmpty)
                return;
            Form f = this;
            this.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));

        }

        private void Form_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }
    }
}
