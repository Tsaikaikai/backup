﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Brandy
{
    public class YoloV7Model
    {
        int PADDDING_GRAY_LEVEL = 114;
        OnnxCore _core = null;
        float[] _result = null;
        int _imageW = 0;
        int _imageH = 0;
        float _pad_x = 0;
        float _pad_y = 0;
        float _gain = 1;
        object _lockObj = new object();

        public List<YoloOutput> Output
        {
            get
            {
                int count = 0;
                List<YoloOutput> results = new List<YoloOutput>();
                if (_result == null)
                    return results;
                else
                {
                    count = _result.Length / 7;
                }

                Parallel.For(0, count, i => 
                {
                    int index = i * 7;
                    YoloOutput obj = new YoloOutput();
                    obj.BatchId = (int)_result[index];
                    obj.X = (_result[index + 1] - _pad_x) / _gain;
                    obj.Y = (_result[index + 2] - _pad_y) / _gain;

                    obj.Width = (_result[index + 3] - _result[index + 1]) / _gain;
                    obj.Height = (_result[index + 4] - _result[index + 2]) / _gain;
                    obj.Type = _result[index + 5].ToString();
                    obj.Confidence = _result[index + 6];
                    if (obj.X > _imageW - 1 || obj.Y > _imageH - 1)
                        return;
                    obj.X = Math.Max(obj.X, 0);
                    obj.Y = Math.Max(obj.Y, 0);
                    obj.Width = Math.Min(_imageW - obj.X, obj.Width);
                    obj.Height = Math.Min(_imageH - obj.Y, obj.Height);
                    lock (_lockObj)
                    {
                        results.Add(obj);
                    }
                });
                return results;
            }
        }
        public int[] InputShape
        {
            get
            {
                return _core.InputShape;
            }
        }
        public int[] OutputShape
        {
            get
            {
                return _core.OutputShape;
            }
        }
        public YoloV7Model(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.YoloV7Model);
        }
        ~YoloV7Model()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        public bool Inference(float[] data)
        {
            bool state = false;
            try
            {
                float[] inputData = Util.NormalizeData(data, 0, 1);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inference(float[] data, int w, int h)
        {
            _imageW = w;
            _imageH = h;
            int imageW = _imageW > _imageH ? _imageW : _imageH;
            _gain = _core.InputShape[2] / (float)imageW;
            _pad_x = ((float)_core.InputShape[2] - _imageW * _gain) / 2;
            _pad_y = ((float)_core.InputShape[2] - _imageH * _gain) / 2;

            bool state = false;
            try
            {
                float[] inputData = Util.NormalizeData(data, 0, 1);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inference(string filename)
        {
            try
            {
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);
                return Inference(image);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                _imageW = image.Width;
                _imageH = image.Height;
                int imageW = _imageW > _imageH ? _imageW : _imageH;
                _gain = _core.InputShape[2] / (float)imageW;
                _pad_x = ((float)_core.InputShape[2] - _imageW * _gain) / 2;
                _pad_y = ((float)_core.InputShape[2] - _imageH * _gain) / 2;

                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[2], ResizeMode.KeepRatio);
                image.Padding(PADDDING_GRAY_LEVEL);
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return (Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool BatchInference(float[] data, int batchSize)
        {
            bool state = false;
            try
            {
                _imageW = _core.InputShape[2];
                _imageH = _core.InputShape[3];
                float[] inputData = Util.NormalizeData(data, 0, 1);
                if (_core.BatchInference(inputData, batchSize))
                {
                    _result = _core.Output;
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void  ParallelPreprocess(ref List<BrandyImage> inputImages)
        {
            try
            {
                Parallel.ForEach (inputImages , (image, LoopState) =>
                {
                    image.CheckChannel(InputShape[1]);
                    image.Resize(InputShape[2], ResizeMode.KeepRatio);
                    image.Padding(PADDDING_GRAY_LEVEL);
                    image.ProcessImage = image.GetPlannerDataFloat();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
