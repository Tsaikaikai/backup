﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brandy
{
    public class RegressionModel
    {
        OnnxCore _core = null;
        float[] _result = null;
        public float[] Output
        {
            get { return _result; }
        }

        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public RegressionModel(string modelpath, int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.Regression);
        }
        ~RegressionModel()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        bool Inference(float[] data)
        {
            bool state = false;
            try
            {
                float[] inputData = Util.NormalizeData(data);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    state = true;
                }
                return state;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public bool Inference(string filename)
        {
            try
            {
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);
                return Inference(image);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public bool Inference(BrandyImage image)
        {
            try
            {
                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[3], InputShape[2]);
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return (Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
