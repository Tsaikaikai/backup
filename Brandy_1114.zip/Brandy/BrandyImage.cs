﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Util;

namespace Brandy
{
    public enum ImageChannel
    {
        Gray,
        RGBPlanner,
        RGBPackage,
        bichannel
    }
    public enum ResizeMode
    {
        Default,
        KeepRatio
    }
    public enum ConvertMode
    {
        None,
        MinMax
    }
    public class BrandyImage: IDisposable
    {
        public Mat image = null;
        bool _disposed;

        public int Width { get { return image.Width; } }
        public int Height { get { return image.Height; } }

        public float[] ProcessImage = null;

        public Bitmap Bitmap 
        { 
            get 
            {
                return image.Bitmap;
            } 
        }

        public BrandyImage(byte[]data, ImageChannel channel, int width, int height)
        {
            image = Data2Mat(data, channel, width, height);
        }
        public BrandyImage(float[] data, ImageChannel channel, int width, int height)
        {
            image = Data2Mat(data, channel, width, height);
        }

        public BrandyImage(Mat inputimage)
        {
            image = inputimage;
        }

        public BrandyImage(string filename)
        {
            image = new Mat(filename, Emgu.CV.CvEnum.ImreadModes.Unchanged);
            if (image.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
            {
                image.ConvertTo(image, Emgu.CV.CvEnum.DepthType.Cv8U);
            }
            else if (image.NumberOfChannels > 3)
            {
                CvInvoke.CvtColor(image, image, Emgu.CV.CvEnum.ColorConversion.Bgra2Rgb);
                //CvInvoke.CvtColor(image, image, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
            }
            else if (image.NumberOfChannels == 3)
            {
                CvInvoke.CvtColor(image, image, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
            }
        }
        public void CheckChannel(int modelchannel)
        {
            if (modelchannel > 1)
            {
                if (image.NumberOfChannels != 3)
                {
                    CvInvoke.CvtColor(image, image, Emgu.CV.CvEnum.ColorConversion.Gray2Rgb);
                }
            }
            else
            {
                if (image.NumberOfChannels == 3)
                {
                    CvInvoke.CvtColor(image, image, Emgu.CV.CvEnum.ColorConversion.Rgb2Gray);
                }
            }
        }
        public void Save(string filename)
        {
            image.Save(filename);
        }
        public void Resize(int size, ResizeMode mode)
        {
            if (image.Width == size && image.Height == size)
                return;
            switch (mode)
            {
                case ResizeMode.Default:
                    CvInvoke.Resize(image, image, new Size(size, size), 0, 0, Emgu.CV.CvEnum.Inter.Linear);
                    break;
                case ResizeMode.KeepRatio:
                    {
                        int ow = image.Width;
                        int oh = image.Height;
                        int w, h;

                        if (ow >= oh)
                        {
                            w = size;
                            double ratio = (double)size / ow;
                            if (ratio == 1)
                                return;
                            h = (int)(ratio * oh );
                        }

                        else
                        {
                            h = size;
                            double ratio = (double)size / oh;
                            if (ratio == 1)
                                return;
                            w = (int)(ratio * ow);
                        }
                        CvInvoke.Resize(image, image, new Size(w, h), 0, 0, Emgu.CV.CvEnum.Inter.Linear);
                    }
                    break;
                default:
                    break;
            }
        }
        public void Resize(int width,int height)
        {
            CvInvoke.Resize(image, image, new Size(width, height), 0, 0, Emgu.CV.CvEnum.Inter.Linear);
        }
        public void Padding(int gray = 0)
        {
            if (image.Width == image.Height)
                return;
            int w = image.Width;
            int h = image.Height;
            var maxval = Math.Max(w, h);
            int p_top = (maxval - h) / 2;
            int p_left = (maxval - w) / 2;
            int p_bottom = maxval - (h + p_top);
            int p_right = maxval - (w + p_left);
            CvInvoke.CopyMakeBorder(image, image, p_top, p_bottom, p_left, p_right,
                Emgu.CV.CvEnum.BorderType.Constant, new Emgu.CV.Structure.MCvScalar(gray));
        }
        public void Padding(int gray, int stripe)
        {
            if (image.Width == image.Height)
                return;
            int w = image.Width;
            int h = image.Height;
            double maxval = Math.Max(w, h);

            double dw = (maxval-w) % stripe;
            double dh = (maxval-h) % stripe;

            dw /= 2;
            dh /= 2;
            int top = (int)Math.Round(dh - 0.1);
            int bottom = (int)Math.Round(dh + 0.1);
            int left = (int)Math.Round(dw - 0.1);
            int right = (int)Math.Round(dw + 0.1);
            CvInvoke.CopyMakeBorder(image, image, top, bottom, left, right,
    Emgu.CV.CvEnum.BorderType.Constant, new Emgu.CV.Structure.MCvScalar(gray));

            //int p_top = (maxval - h) / 2;
            //int p_left = (maxval - w) / 2;
            //int p_bottom = maxval - (h + p_top);
            //int p_right = maxval - (w + p_left);
            //CvInvoke.CopyMakeBorder(image, image, p_top, p_bottom, p_left, p_right,
            //    Emgu.CV.CvEnum.BorderType.Constant, new Emgu.CV.Structure.MCvScalar(gray));
        }
        public void CropCenter(int width, int height)
        {
            int crop_width = width < image.Width ? width : image.Width;
            int crop_height = height < image.Height ? height : image.Height;
            int mid_x = image.Width / 2;
            int mid_y = image.Height / 2;
            int cw2 = (crop_width / 2);
            int ch2 = (crop_height / 2);
            image = new Mat(image, new Emgu.CV.Structure.Range(mid_y - ch2, mid_y + ch2),
                new Emgu.CV.Structure.Range(mid_x - cw2, mid_x + cw2));
        }
        public void DeNormalize(ConvertMode mode = ConvertMode.MinMax)
        {
            switch (mode)
            {
                case ConvertMode.None:
                    image.ConvertTo(image, DepthType.Cv8U);
                    break;
                case ConvertMode.MinMax:
                    CvInvoke.Normalize(image, image, 255, 0.0, NormType.MinMax, DepthType.Cv8U);
                    break;
                default:
                    break;
            }
        }
        public void RGB2BGR()
        {
            CvInvoke.CvtColor(image, image, ColorConversion.Rgb2Bgr);
        }


        public void Color2Gray()
        {
            switch (image.NumberOfChannels)
            {
                case 3:
                    CvInvoke.CvtColor(image, image, ColorConversion.Rgb2Gray);
                    break;
                case 4:
                    CvInvoke.CvtColor(image, image, ColorConversion.Rgba2Gray);
                    break;
                default:
                    break;
            }
        }
        public void ChannelConvert(ImageChannel type)
        {
            switch (type)
            {
                case ImageChannel.Gray:
                    break;
                case ImageChannel.RGBPlanner:
                    break;
                case ImageChannel.RGBPackage:
                    break;
                default:
                    break;
            }
        }
        public float[] GetPlannerDataFloat()
        {
            image.ConvertTo(image, DepthType.Cv32F);
            int total = image.Rows * image.Cols * image.NumberOfChannels;
            int imgSize = image.Rows * image.Cols;
            Mat[] bgrChannels = image.Split();
            float[] data = new float[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, data, i * imgSize, imgSize);
            }
            return data;
        }
        public float[] GetPackageDataFloat()
        {
            image.ConvertTo(image, DepthType.Cv32F);
            int total = image.Rows * image.Cols * image.NumberOfChannels;
            float[] data = new float[total];
            Marshal.Copy(image.DataPointer, data, 0, total);
            return data;
        }
        public byte[] GetPlannerDataByte()
        {
            image.ConvertTo(image, DepthType.Cv8U);
            int total = image.Rows * image.Cols * image.NumberOfChannels;
            int imgSize = image.Rows * image.Cols;
            Mat[] bgrChannels = image.Split();
            byte[] data = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, data, i * imgSize, imgSize);
            }
            return data;
        }
        public byte[] GetPackageDataByte()
        {
            image.ConvertTo(image, DepthType.Cv8U);
            int total = image.Rows * image.Cols * image.NumberOfChannels;
            byte[] data = new byte[total];
            Marshal.Copy(image.DataPointer, data, 0, total);
            return data;
        }
        Mat Data2Mat(byte[] data, ImageChannel type, int width, int height)
        {
            try
            {
                int channel = 3;
                if (type == ImageChannel.Gray)
                    channel = 1;
                if (type == ImageChannel.bichannel)
                    channel = 2;

                Mat output = new Mat(new Size(width, height), Emgu.CV.CvEnum.DepthType.Cv8U, channel);
                if (channel * width * height != data.Length)
                    throw new Exception("channel * width * height != data.Length");
                if (channel > 1)
                {
                    if(type == ImageChannel.RGBPlanner)
                    {
                        Mat image = output;
                        VectorOfMat matVector = new VectorOfMat();
                        Mat[] channels = image.Split();
                        for (int i = 0; i < channels.Length; i++)
                        {
                            Marshal.Copy(data, i * width * height, channels[i].DataPointer, width * height);
                            matVector.Push(channels[i]);
                        }
                        CvInvoke.Merge(matVector, image);
                    }
                    else
                    {
                        Mat image = output;
                        int total = image.Rows * image.Cols * image.NumberOfChannels;
                        Marshal.Copy(data, 0, image.DataPointer, total);
                    }
                }
                else
                {
                    Mat image = output;
                    Marshal.Copy(data, 0, image.DataPointer, width * height);
                }
                return output;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        Mat Data2Mat(float[] data, ImageChannel type, int width, int height)
        {
            try
            {
                int channel = 3;
                if (type == ImageChannel.Gray)
                    channel = 1;
                if (type == ImageChannel.bichannel)
                    channel = 2;

                Mat output = new Mat(new Size(width, height), Emgu.CV.CvEnum.DepthType.Cv32F, channel);
                if (channel * width * height != data.Length)
                    throw new Exception("channel * width * height != data.Length");
                if (channel > 1)
                {
                    if (type == ImageChannel.RGBPlanner)
                    {
                        Mat image = output;
                        VectorOfMat matVector = new VectorOfMat();
                        Mat[] channels = image.Split();
                        for (int i = 0; i < channels.Length; i++)
                        {
                            Marshal.Copy(data, i * width * height, channels[i].DataPointer, width * height);
                            matVector.Push(channels[i]);
                        }

                        CvInvoke.Merge(matVector, image);
                    }
                    else
                    {
                        Mat image = output;
                        int total = image.Rows * image.Cols * image.NumberOfChannels;
                        Marshal.Copy(image.DataPointer, data, 0, total);
                    }
                }
                else
                {
                    Mat image = output;
                    Marshal.Copy(data, 0, image.DataPointer, width * height);
                }

                return output;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~BrandyImage()
        {
            Dispose();
        }
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return; 
            if (disposing)
            {
                if(image!=null)
                    image.Dispose();
            }
            _disposed = true;
        }
    }
}
