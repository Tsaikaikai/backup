﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Alturos.Yolo.Model;
using System.Drawing;
using System.Runtime.InteropServices;
using Alturos.Yolo;
using System.Drawing.Imaging;

namespace Brandy
{
    public class YoloV4Model
    {
        private YoloWrapper _yoloWrapper;
        private List<YoloItem> _output = null;
        private static int _channel;
        private static PixelFormat _pixelFormat;

        public List<YoloOutput> Output
        {
            get
            {
                List<YoloOutput> result = new List<YoloOutput>();
                for (int i = 0; i < _output.Count; i++)
                {
                    YoloOutput obj = new YoloOutput();
                    obj.X = _output[i].X;
                    obj.Y = _output[i].Y;
                    obj.Width = _output[i].Width;
                    obj.Height = _output[i].Height;
                    obj.Confidence = _output[i].Confidence;
                    obj.Type = _output[i].Type;
                    result.Add(obj);
                }
                return result;
            }
        }

        public int Channel
        {
            get
            {
                return _channel;
            }
        }

        public YoloV4Model(string modelfolder, bool gpu = true)
        {
            Console.WriteLine("......Initial Yolo......");
            try
            {
                var configurationDetector = new YoloConfigurationDetector();
                var config = configurationDetector.Detect(modelfolder);
                if (config == null)
                {
                    return;
                }
                var gpuConfig = new GpuConfig();
                if (gpu != true)
                    gpuConfig = null;

                _yoloWrapper = new YoloWrapper(config.ConfigFile, config.WeightsFile, 
                    config.NamesFile, gpuConfig);
                _channel = _yoloWrapper.Getmodelchannel(gpu);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Dispose()
        {
            Console.WriteLine("......Dispose......");
            this._yoloWrapper?.Dispose();
        }

        public void Inference(string imagepath)
        {
            Console.WriteLine("......Inference Yolo......");
            if (_output != null)
            {
                if (_output.Count > 0)
                {
                    for (int i = 0; i < _output.Count; i++)
                    {
                        _output[i] = null;
                    }
                    _output.Clear();
                    _output = null;
                }
            }
            _output = _yoloWrapper.Detect(imagepath).ToList();
        }

        void Inference(byte[] rawdata, int width, int height)
        {
            if (_channel == 1)
            {
                _pixelFormat = PixelFormat.Format8bppIndexed;
            }
            else if (_channel == 3)
            {
                _pixelFormat = PixelFormat.Format24bppRgb;

            }
            else
                throw new Exception("wrong model channel.");


            if (_output != null)
            {
                if (_output.Count > 0)
                {
                    for (int i = 0; i < _output.Count; i++)
                    {
                        _output[i] = null;
                    }
                    _output.Clear();
                    _output = null;
                }
            }

            Check_rawdata(rawdata, width, height, _channel);
            Bitmap inputBmp = RawdataToBitmap(rawdata, width, height, _pixelFormat);
            byte[] inputBmparray = ToByteArray(inputBmp);
            _output = _yoloWrapper.Detect(inputBmparray).ToList();
        }

        public void Inference(BrandyImage image)
        {
            if (_channel == 1)
            {
                _pixelFormat = PixelFormat.Format8bppIndexed;
            }
            else if (_channel == 3)
            {
                _pixelFormat = PixelFormat.Format24bppRgb;

            }
            else
                throw new Exception("wrong model channel.");


            if (_output != null)
            {
                if (_output.Count > 0)
                {
                    for (int i = 0; i < _output.Count; i++)
                    {
                        _output[i] = null;
                    }
                    _output.Clear();
                    _output = null;
                }
            }
            byte[] data = image.GetPackageDataByte();
            Inference(data, image.Width, image.Height);
        }

        private Bitmap RawdataToBitmap(byte[] rawdata, int width, int height, PixelFormat pixelFormat)
        {
            var bmp = new Bitmap(width, height, pixelFormat);
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), 
                ImageLockMode.WriteOnly, bmp.PixelFormat);
            IntPtr pNative = bmpData.Scan0;
            Marshal.Copy(rawdata, 0, pNative, rawdata.Length);
            bmp.UnlockBits(bmpData);
            return bmp;
        }

        private byte[] ToByteArray(Image image)
        {
            MemoryStream ms = new MemoryStream();
            image.Save(ms, ImageFormat.Bmp);
            return ms.ToArray();
        }

        private void Check_rawdata(byte[] rawdata, int width, int height, int channel)
        {
            if (rawdata.Length != width * height * channel)
            {
                throw new Exception("Invalid image size, wrong image width or height or channel.");
            }
        }
    }
    public class YoloOutput
    {
        public int BatchId { get; set; }
        public string Type { get; set; }
        public double Confidence { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public YoloOutput()
        {

        }

        public PointF Center()
        {
            return new PointF(X + Width / 2, Y + Height / 2);
        }
    }
}
