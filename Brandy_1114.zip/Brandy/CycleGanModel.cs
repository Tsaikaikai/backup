﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brandy
{
    public class CycleGanModel
    {
        BrandyImage _outputImage = null;
        bool _isFirstGetOutputImage= false;

        OnnxCore _core = null;
        float[] _result = null;
        public float[] Output
        {
            get { return _result; }
        }
        public BrandyImage GetOutputImage()
        {
            BrandyImage outputImage = null;
            try
            {
                ImageChannel channel = ImageChannel.Gray;
                if (_core.OutputShape[1] > 1)
                    channel = ImageChannel.RGBPlanner;
                outputImage = new BrandyImage(_result, channel, _core.OutputShape[3], _core.OutputShape[2]);
                outputImage.DeNormalize(ConvertMode.None);
                return outputImage;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public BrandyImage OutputImage
        {
            get
            {
                if (_isFirstGetOutputImage)
                {
                    if (_outputImage != null)
                    {
                        _outputImage.Dispose();
                        _outputImage = null;
                    }
                    ImageChannel channel = ImageChannel.Gray;
                    if (_core.OutputShape[1] > 1)
                        channel = ImageChannel.RGBPlanner;
                    _outputImage = new BrandyImage(_result, channel, _core.OutputShape[3], _core.OutputShape[2]);
                    _outputImage.DeNormalize(ConvertMode.None);
                }
                return _outputImage;
            }
        }

        public int[] InputShape
        {
            get { return _core.InputShape; }
        }
        public int[] OutputShape
        {
            get { return _core.OutputShape; }
        }
        public CycleGanModel(string modelpath,int gpuid)
        {
            _core = new OnnxCore(modelpath, gpuid, ModelTpye.CycleGan);
        }
        ~CycleGanModel()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
        }

        public void Dispose()
        {
            if (_core != null)
            {
                _core.Dispose();
                _core = null;
            }
            if (_outputImage != null)
            {
                _outputImage.Dispose();
                _outputImage = null;
            }
        }

        bool Inference(float[] data)
        {
            bool state = false;
            try
            {
                float[] inputData = Util.NormalizeData(data);
                if (_core.Inference(inputData))
                {
                    _result = _core.Output;
                    _result = Util.DeNormalizeData(_result);
                    state = true;
                }
                return state;
            }
            catch (Exception ex )
            {
                throw ex;
            }

        }

        public bool Inference(string filename)
        {
            try
            {
                _isFirstGetOutputImage = true;
                if (!System.IO.File.Exists(filename))
                    return false;

                BrandyImage image = new BrandyImage(filename);
                return Inference(image);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Inference(BrandyImage image)
        {
            try
            {
                _isFirstGetOutputImage = true;
                image.CheckChannel(InputShape[1]);
                image.Resize(InputShape[2], ResizeMode.Default);
                float[] input = image.GetPlannerDataFloat();
                image.Dispose();
                return (Inference(input));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
