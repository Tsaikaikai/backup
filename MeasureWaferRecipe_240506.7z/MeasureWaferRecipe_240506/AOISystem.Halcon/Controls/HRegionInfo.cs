﻿using HalconDotNet;

namespace AOISystem.Halcon.Controls
{
    public class HRegionInfo
    {
        public HRegionInfo()
        {
            Name = string.Empty;
            HDispRegion = new HObject();
            HDispColor = HColorMode.red;
            HDrawMode = HDrawMode.margin;
        }

        public string Name { get; set; }

        public HObject HDispRegion { get; set; }

        public HColorMode HDispColor { get; set; }

        public HDrawMode HDrawMode { get; set; }
    }

    public enum HDrawMode
    {
        fill,
        margin
    }
}
