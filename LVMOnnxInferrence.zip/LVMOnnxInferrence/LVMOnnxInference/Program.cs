﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using OpenCvSharp;

namespace OnnxSegmentationInference
{
    /// <summary>
    /// ONNX Segmentation Model Inference Tool
    /// 支援批次推論和動態輸入尺寸，支援GPU加速
    /// </summary>
    public class ONNXSegmentationInference : IDisposable
    {
        private InferenceSession _session;
        private readonly string _inputName;
        private readonly string _outputName;
        private readonly int[] _inputShape;
        private readonly int[] _outputShape;
        private readonly int _inputChannels;

        /// <summary>
        /// 初始化推論器
        /// </summary>
        /// <param name="modelPath">ONNX模型路徑</param>
        /// <param name="useGpu">是否使用GPU</param>
        public ONNXSegmentationInference(string modelPath, bool useGpu = true)
        {
            if (!File.Exists(modelPath))
                throw new FileNotFoundException($"模型檔案不存在: {modelPath}");

            // 設定執行選項
            var sessionOptions = new SessionOptions();

            if (useGpu)
            {
                try
                {
                    // 嘗試使用CUDA Provider
                    sessionOptions.AppendExecutionProvider_CUDA(0);
                    Console.WriteLine("已啟用CUDA GPU加速");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"CUDA不可用，回退至CPU: {ex.Message}");
                }
            }

            _session = new InferenceSession(modelPath, sessionOptions);

            // 取得模型輸入輸出資訊
            _inputName = _session.InputMetadata.Keys.First();
            _outputName = _session.OutputMetadata.Keys.First();
            _inputShape = _session.InputMetadata[_inputName].Dimensions;
            _outputShape = _session.OutputMetadata[_outputName].Dimensions;

            Console.WriteLine($"模型載入成功: {modelPath}");
            Console.WriteLine($"輸入名稱: {_inputName}");
            Console.WriteLine($"輸出名稱: {_outputName}");
            Console.WriteLine($"輸入形狀: [{string.Join(", ", _inputShape)}]");
            Console.WriteLine($"輸出形狀: [{string.Join(", ", _outputShape)}]");

            // 取得輸入通道數（通常為3 for RGB或1 for grayscale）
            _inputChannels = _inputShape.Length == 4 ? _inputShape[1] : 3;
        }

        /// <summary>
        /// 預處理單張圖像
        /// </summary>
        /// <param name="imagePath">圖像路徑</param>
        /// <param name="targetSize">目標尺寸 (height, width)</param>
        /// <param name="normalize">是否正規化到[0,1]範圍</param>
        /// <returns>預處理後的圖像數組，形狀為(C, H, W)</returns>
        public float[,,] PreprocessImage(string imagePath, Size? targetSize = null, bool normalize = true)
        {
            if (!File.Exists(imagePath))
                throw new FileNotFoundException($"圖像檔案不存在: {imagePath}");

            using (var img = Cv2.ImRead(imagePath))
            {
                return PreprocessImage(img, targetSize, normalize);
            }
        }

        /// <summary>
        /// 預處理單張圖像
        /// </summary>
        /// <param name="image">OpenCV Mat圖像</param>
        /// <param name="targetSize">目標尺寸 (height, width)</param>
        /// <param name="normalize">是否正規化到[0,1]範圍</param>
        /// <returns>預處理後的圖像數組，形狀為(C, H, W)</returns>
        public float[,,] PreprocessImage(Mat image, Size? targetSize = null, bool normalize = true)
        {
            using (var rgbImg = new Mat())
            {
                Cv2.CvtColor(image, rgbImg, ColorConversionCodes.BGR2RGB);

                // 調整尺寸
                Mat resizedImg = rgbImg;
                if (targetSize.HasValue)
                {
                    resizedImg = new Mat();
                    Cv2.Resize(rgbImg, resizedImg, targetSize.Value, 0, 0, InterpolationFlags.Linear);
                }

                try
                {
                    // 轉換為浮點數
                    using (var floatImg = new Mat())
                    {
                        resizedImg.ConvertTo(floatImg, MatType.CV_32F);
                        Mat floatImg_copy = floatImg.Clone();

                        // 正規化
                        if (normalize)
                        {
                            floatImg_copy = floatImg_copy / 255.0f;
                        }

                        // 轉換維度順序 (H, W, C) -> (C, H, W)
                        int height = floatImg_copy.Height;
                        int width = floatImg_copy.Width;
                        int channels = floatImg_copy.Channels();

                        var result = new float[channels, height, width];

                        unsafe
                        {
                            float* data = (float*)floatImg_copy.DataPointer;
                            for (int y = 0; y < height; y++)
                            {
                                for (int x = 0; x < width; x++)
                                {
                                    for (int c = 0; c < channels; c++)
                                    {
                                        result[c, y, x] = data[y * width * channels + x * channels + c];
                                    }
                                }
                            }
                        }

                        return result;
                    }
                }
                finally
                {
                    if (resizedImg != rgbImg)
                        resizedImg?.Dispose();
                }
            }
        }

        /// <summary>
        /// 批次預處理圖像
        /// </summary>
        /// <param name="imagePaths">圖像路徑清單</param>
        /// <param name="targetSize">目標尺寸</param>
        /// <param name="normalize">是否正規化</param>
        /// <returns>批次圖像數組，形狀為(N, C, H, W)</returns>
        public float[,,,] PreprocessBatch(List<string> imagePaths, Size? targetSize = null, bool normalize = true)
        {
            var processedImages = new List<float[,,]>();

            foreach (var imagePath in imagePaths)
            {
                var processedImg = PreprocessImage(imagePath, targetSize, normalize);
                processedImages.Add(processedImg);
            }

            // 堆疊成批次
            int batchSize = processedImages.Count;
            int channels = processedImages[0].GetLength(0);
            int height = processedImages[0].GetLength(1);
            int width = processedImages[0].GetLength(2);

            var batch = new float[batchSize, channels, height, width];

            for (int i = 0; i < batchSize; i++)
            {
                for (int c = 0; c < channels; c++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        for (int w = 0; w < width; w++)
                        {
                            batch[i, c, h, w] = processedImages[i][c, h, w];
                        }
                    }
                }
            }

            return batch;
        }

        /// <summary>
        /// 後處理模型輸出
        /// </summary>
        /// <param name="output">模型原始輸出，形狀為(N, C, H, W)</param>
        /// <param name="originalSizes">原始圖像尺寸清單</param>
        /// <returns>後處理後的分割遮罩清單</returns>
        public List<Mat> PostprocessOutput(float[,,,] output, List<Size> originalSizes = null)
        {
            var results = new List<Mat>();
            int batchSize = output.GetLength(0);
            int height = output.GetLength(2);
            int width = output.GetLength(3);

            for (int i = 0; i < batchSize; i++)
            {
                // 提取第二個通道（假設為前景類別）
                var mask = new float[height, width];
                for (int h = 0; h < height; h++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        // 應用sigmoid函數
                        float sigmoid = 1.0f / (1.0f + (float)Math.Exp(-output[i, 1, h, w]));
                        mask[h, w] = sigmoid > 0.2f ? 1.0f : 0.0f; // 二值化
                    }
                }

                // 轉換為Mat (安全版本)
                var maskMat = new Mat(height, width, MatType.CV_8UC1);

                // 使用安全的方式設定像素值
                for (int h = 0; h < height; h++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        byte pixelValue = (byte)(mask[h, w] * 255);
                        maskMat.Set<byte>(h, w, pixelValue);
                    }
                }

                // 恢復到原始尺寸
                if (originalSizes != null && i < originalSizes.Count)
                {
                    var originalSize = originalSizes[i];
                    var resizedMask = new Mat();
                    Cv2.Resize(maskMat, resizedMask, originalSize, 0, 0, InterpolationFlags.Nearest);
                    maskMat.Dispose();
                    results.Add(resizedMask);
                }
                else
                {
                    results.Add(maskMat);
                }
            }

            return results;
        }

        public List<Mat> PostprocessOutputParallel(float[,,,] output, Size[] originalSizes = null)
        {
            int batchSize = output.GetLength(0);
            int height = output.GetLength(2);
            int width = output.GetLength(3);

            var results = new Mat[batchSize];

            // 並行處理每個批次項目
            Parallel.For(0, batchSize, i =>
            {
                // 創建像素資料陣列
                var pixelData = new byte[height * width];

                // 並行處理像素計算
                Parallel.For(0, height, h =>
                {
                    for (int w = 0; w < width; w++)
                    {
                        // 應用sigmoid函數
                        float sigmoid = 1.0f / (1.0f + (float)Math.Exp(-output[i, 1, h, w]));
                        pixelData[h * width + w] = (byte)((sigmoid > 0.2f ? 1.0f : 0.0f) * 255);
                    }
                });

                // 使用現代化的API創建Mat
                var maskMat = Mat.FromPixelData(height, width, MatType.CV_8UC1, pixelData);

                // 恢復到原始尺寸
                if (originalSizes != null && i < originalSizes.Length)
                {
                    var originalSize = originalSizes[i];
                    var resizedMask = new Mat();
                    Cv2.Resize(maskMat, resizedMask, originalSize, 0, 0, InterpolationFlags.Nearest);
                    maskMat.Dispose();
                    results[i] = resizedMask;
                }
                else
                {
                    results[i] = maskMat;
                }
            });

            return results.ToList();
        }

        /// <summary>
        /// 單張圖像推論
        /// </summary>
        /// <param name="imagePath">輸入圖像路徑</param>
        /// <param name="targetSize">目標尺寸</param>
        /// <param name="normalize">是否正規化</param>
        /// <returns>分割遮罩</returns>
        public Mat PredictSingle(string imagePath, Size? targetSize = null, bool normalize = true)
        {
            // 記錄原始尺寸
            using (var originalImg = Cv2.ImRead(imagePath))
            {
                var originalSize = new Size(originalImg.Width, originalImg.Height);

                // 預處理
                var processedImg = PreprocessImage(imagePath, targetSize, normalize);

                // 創建輸入張量
                var inputTensor = new DenseTensor<float>(new[] { 1, processedImg.GetLength(0), processedImg.GetLength(1), processedImg.GetLength(2) });

                for (int c = 0; c < processedImg.GetLength(0); c++)
                {
                    for (int h = 0; h < processedImg.GetLength(1); h++)
                    {
                        for (int w = 0; w < processedImg.GetLength(2); w++)
                        {
                            inputTensor[0, c, h, w] = processedImg[c, h, w];
                        }
                    }
                }

                // 推論
                Stopwatch sw = Stopwatch.StartNew();
                var inputs = new List<NamedOnnxValue> { NamedOnnxValue.CreateFromTensor(_inputName, inputTensor) };
                using (var results = _session.Run(inputs))
                {
                    sw.Stop();
                    var output = results.First().AsTensor<float>();
                    Console.WriteLine($"單張圖像單純模型推論時間: {sw.Elapsed.TotalMilliseconds:F1} ms");

                    // 轉換輸出格式
                    var outputArray = new float[1, output.Dimensions[1], output.Dimensions[2], output.Dimensions[3]];
                    for (int c = 0; c < output.Dimensions[1]; c++)
                    {
                        for (int h = 0; h < output.Dimensions[2]; h++)
                        {
                            for (int w = 0; w < output.Dimensions[3]; w++)
                            {
                                outputArray[0, c, h, w] = output[0, c, h, w];
                            }
                        }
                    }

                    // 後處理
                    var maskResults = PostprocessOutput(outputArray, new List<Size> { originalSize });
                    return maskResults[0];
                }
            }
        }

        /// <summary>
        /// 批次圖像推論
        /// </summary>
        /// <param name="imagePaths">圖像路徑清單</param>
        /// <param name="targetSize">目標尺寸</param>
        /// <param name="normalize">是否正規化</param>
        /// <param name="batchSize">批次大小</param>
        /// <returns>分割遮罩清單</returns>
        public List<Mat> PredictBatch(List<string> imagePaths, Size? targetSize = null, bool normalize = true, int? batchSize = null)
        {
            // 並行讀取圖片並記錄原始尺寸
            var originalSizes = new Size[imagePaths.Count];
            Parallel.For(0, imagePaths.Count, i =>
            {
                using (var img = Cv2.ImRead(imagePaths[i]))
                {
                    originalSizes[i] = new Size(img.Width, img.Height);
                }
            });

            var allResults = new List<Mat>();
            if (!batchSize.HasValue)
                batchSize = imagePaths.Count;

            // 分批處理
            for (int i = 0; i < imagePaths.Count; i += batchSize.Value)
            {
                var batchImagePaths = imagePaths.GetRange(i, Math.Min(batchSize.Value, imagePaths.Count - i));
                var batchOriginalSizes = originalSizes.Skip(i).Take(Math.Min(batchSize.Value, originalSizes.Length - i)).ToArray();

                // 預處理
                var batchInput = PreprocessBatch(batchImagePaths, targetSize, normalize);

                // 創建輸入張量（優化版本）
                var dimensions = new int[] { batchInput.GetLength(0), batchInput.GetLength(1), batchInput.GetLength(2), batchInput.GetLength(3) };
                var inputTensor = new DenseTensor<float>(dimensions);

                // 並行化張量複製
                var totalElements = dimensions[0] * dimensions[1] * dimensions[2] * dimensions[3];
                Parallel.For(0, totalElements, idx =>
                {
                    var indices = GetIndicesFromFlat(idx, dimensions);
                    inputTensor[indices[0], indices[1], indices[2], indices[3]] =
                        batchInput[indices[0], indices[1], indices[2], indices[3]];
                });

                // 推論
                Stopwatch sw = Stopwatch.StartNew();
                var inputs = new List<NamedOnnxValue> { NamedOnnxValue.CreateFromTensor(_inputName, inputTensor) };
                using (var results = _session.Run(inputs))
                {
                    sw.Stop();
                    Console.WriteLine($"批次大小 {batchImagePaths.Count} 單純模型一張影像推論時間: {sw.Elapsed.TotalMilliseconds/ batchImagePaths.Count:F1} ms");
                    var output = results.First().AsTensor<float>();

                    // 優化的輸出格式轉換
                    var outputArray = ConvertTensorToArrayParallel(output);

                    // 後處理
                    var batchResults = PostprocessOutputParallel(outputArray, batchOriginalSizes);
                    allResults.AddRange(batchResults);
                }
            }

            return allResults;
        }

        private float[,,,] ConvertTensorToArrayParallel(Tensor<float> output)
        {
            var dims = output.Dimensions.ToArray();
            var outputArray = new float[dims[0], dims[1], dims[2], dims[3]];

            var totalElements = dims[0] * dims[1] * dims[2] * dims[3];

            Parallel.For(0, totalElements, idx =>
            {
                var indices = GetIndicesFromFlat(idx, dims);
                outputArray[indices[0], indices[1], indices[2], indices[3]] =
                    output[indices[0], indices[1], indices[2], indices[3]];
            });

            return outputArray;
        }

        private int[] GetIndicesFromFlat(int flatIndex, int[] dimensions)
        {
            var indices = new int[4];
            indices[3] = flatIndex % dimensions[3];
            flatIndex /= dimensions[3];
            indices[2] = flatIndex % dimensions[2];
            flatIndex /= dimensions[2];
            indices[1] = flatIndex % dimensions[1];
            flatIndex /= dimensions[1];
            indices[0] = flatIndex;
            return indices;
        }

        /// <summary>
        /// 儲存分割結果
        /// </summary>
        /// <param name="masks">分割遮罩清單</param>
        /// <param name="outputDir">輸出目錄</param>
        /// <param name="imageNames">圖像名稱清單</param>
        public void SaveResults(List<Mat> masks, string outputDir, List<string> imageNames = null)
        {
            Directory.CreateDirectory(outputDir);

            for (int i = 0; i < masks.Count; i++)
            {
                string name;
                if (imageNames != null && i < imageNames.Count)
                {
                    name = Path.GetFileNameWithoutExtension(imageNames[i]);
                }
                else
                {
                    name = $"mask_{i:D4}";
                }

                string outputPath = Path.Combine(outputDir, $"{name}_mask.png");
                Cv2.ImWrite(outputPath, masks[i]);
                Console.WriteLine($"已儲存: {outputPath}");
            }
        }

        /// <summary>
        /// 執行模型 warm-up
        /// </summary>
        /// <param name="inference">推論器實例</param>
        /// <param name="targetSize">目標尺寸</param>
        /// <param name="normalize">是否正規化</param>
        /// <param name="batchSize">批次大小</param>
        /// <param name="warmupRuns">warm-up 執行次數</param>
        public void PerformWarmUp(ONNXSegmentationInference inference, Size targetSize, bool normalize, int batchSize, int warmupRuns)
        {
            try
            {
                // 產生假的輸入圖像數據
                var dummyImages = CreateDummyImages(batchSize, targetSize);

                var warmupStopwatch = Stopwatch.StartNew();

                for (int i = 0; i < warmupRuns; i++)
                {
                    Console.Write($"  Warm-up 第 {i + 1}/{warmupRuns} 次... ");

                    var runStopwatch = Stopwatch.StartNew();

                    // 執行推論（不儲存結果）
                    var warmupResults = inference.PredictBatch(dummyImages, targetSize, normalize, batchSize);

                    runStopwatch.Stop();
                    Console.WriteLine($"耗時: {runStopwatch.Elapsed.TotalMilliseconds:F1} ms");

                    // 清理 warm-up 結果
                    foreach (var result in warmupResults)
                    {
                        result?.Dispose();
                    }
                }

                warmupStopwatch.Stop();
                Console.WriteLine($"總 warm-up 時間: {warmupStopwatch.Elapsed.TotalSeconds:F2} 秒");

                // 清理假的輸入圖像
                CleanupDummyImages(dummyImages);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warm-up 過程中發生錯誤: {ex.Message}");
                // 不拋出異常，繼續執行主要推論
            }
        }

        /// <summary>
        /// 建立假的輸入圖像用於 warm-up
        /// </summary>
        /// <param name="batchSize">批次大小</param>
        /// <param name="targetSize">目標尺寸</param>
        /// <returns>假圖像路徑列表</returns>
        private static List<string> CreateDummyImages(int batchSize, Size targetSize)
        {
            var dummyImages = new List<string>();
            var tempDir = Path.GetTempPath();

            int width = targetSize.Width;
            int height = targetSize.Height;
            var random = new Random();

            for (int i = 0; i < batchSize; i++)
            {
                // 使用 OpenCvSharp 建立隨機色彩的假圖像
                using (var mat = new OpenCvSharp.Mat(height, width, OpenCvSharp.MatType.CV_8UC3))
                {
                    // 產生隨機顏色 (BGR格式)
                    var color = new OpenCvSharp.Scalar(
                        random.Next(256), // B
                        random.Next(256), // G
                        random.Next(256)  // R
                    );

                    // 填充整個圖像為隨機顏色
                    mat.SetTo(color);

                    string tempImagePath = Path.Combine(tempDir, $"warmup_dummy_{i}_{Guid.NewGuid()}.png");
                    OpenCvSharp.Cv2.ImWrite(tempImagePath, mat);
                    dummyImages.Add(tempImagePath);
                }
            }

            return dummyImages;
        }

        /// <summary>
        /// 清理建立的假圖像檔案
        /// </summary>
        /// <param name="dummyImages">假圖像路徑列表</param>
        private static void CleanupDummyImages(List<string> dummyImages)
        {
            foreach (var imagePath in dummyImages)
            {
                try
                {
                    if (File.Exists(imagePath))
                    {
                        File.Delete(imagePath);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"清理暫存檔案失敗 {imagePath}: {ex.Message}");
                }
            }
        }

        public void Dispose()
        {
            if (_session != null)
                _session.Dispose();
        }
    }

    class Program
    {
        static int Main(string[] args)
        {
            try
            {
                // 設定預設參數
                string modelPath = @"D:\Johnny\LVM_Onnx_Model_trans\model\reconstructed_model.onnx";
                string inputPath = @"D:\Johnny\LVM_Onnx_Model_trans\image";
                string outputPath = @"D:\Johnny\LVM_Onnx_Model_trans\output";
                int batchSize = 4;
                int targetHeight = 644;
                int targetWidth = 644;
                bool normalize = true;
                bool useGpu = true;
                int warmupRuns = 2;

                // 顯示使用說明
                Console.WriteLine("ONNX Segmentation Inference Tool");
                Console.WriteLine("=================================");
                Console.WriteLine($"模型路徑: {modelPath}");
                Console.WriteLine($"輸入路徑: {inputPath}");
                Console.WriteLine($"輸出路徑: {outputPath}");
                Console.WriteLine($"批次大小: {batchSize}");
                Console.WriteLine($"目標尺寸: {targetWidth}x{targetHeight}");
                Console.WriteLine($"正規化: {normalize}");
                Console.WriteLine($"使用GPU: {useGpu}");
                Console.WriteLine($"Warm-up次數: {warmupRuns}");
                Console.WriteLine();

                // 初始化推論器
                using (var inference = new ONNXSegmentationInference(modelPath, useGpu))
                {
                    // 準備目標尺寸
                    Size targetSize = new Size();
                    if (targetHeight > 0 && targetWidth > 0)
                    {
                        targetSize = new Size(targetWidth, targetHeight);
                    }

                    // ===== 新增：模型 Warm Up =====
                    Console.WriteLine("開始模型 warm-up...");
                    inference.PerformWarmUp(inference, targetSize, normalize, batchSize, warmupRuns);
                    Console.WriteLine("模型 warm-up 完成");
                    Console.WriteLine();

                    // 收集輸入圖像
                    List<string> images;
                    List<string> imageNames;

                    if (File.Exists(inputPath))
                    {
                        // 單個檔案
                        images = new List<string> { inputPath };
                        imageNames = new List<string> { Path.GetFileName(inputPath) };
                    }
                    else if (Directory.Exists(inputPath))
                    {
                        // 目錄
                        var extensions = new[] { ".jpg", ".jpeg", ".png", ".bmp", ".tiff" };
                        images = Directory.GetFiles(inputPath)
                            .Where(f => extensions.Contains(Path.GetExtension(f).ToLower()))
                            .ToList();
                        imageNames = images.Select(Path.GetFileName).ToList();
                    }
                    else
                    {
                        throw new ArgumentException($"輸入路徑無效: {inputPath}");
                    }

                    Console.WriteLine($"找到 {images.Count} 張圖像");

                    if (images.Count == 0)
                    {
                        Console.WriteLine("未找到任何圖像檔案");
                        return 1;
                    }

                    Stopwatch sw = Stopwatch.StartNew();
                    // 執行推論
                    var results = inference.PredictBatch(images, targetSize, normalize, batchSize);
                    sw.Stop();
                    Console.WriteLine($"總推論時間: {sw.Elapsed.TotalSeconds:F2} 秒");
                    Console.WriteLine($"平均每張圖像推論時間: {sw.Elapsed.TotalSeconds / images.Count:F2} 秒");

                    // 儲存結果
                    inference.SaveResults(results, outputPath, imageNames);
                    Console.WriteLine($"推論完成，結果已儲存至: {outputPath}");

                    // 清理資源
                    foreach (var mask in results)
                    {
                        mask.Dispose();
                    }
                }

                Console.WriteLine("按任意鍵結束...");
                Console.ReadKey();
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"錯誤: {ex.Message}");
                Console.WriteLine($"詳細錯誤: {ex.StackTrace}");
                Console.WriteLine("按任意鍵結束...");
                Console.ReadKey();
                return 1;
            }
        }
    }
}