﻿
namespace AOISystem.Halcon.Controls
{
    public enum FontZoomMode
    {
        Constant,
        Positive,
        Reverse
    }
}
