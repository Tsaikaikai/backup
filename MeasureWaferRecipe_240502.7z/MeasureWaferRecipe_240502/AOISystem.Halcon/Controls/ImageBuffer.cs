﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using AOISystem.Halcon.HAlgorithm;
using HalconDotNet;
using System.Windows.Forms;

namespace AOISystem.Halcon.Controls
{
    public class ImageBuffer
    {
        private IntPtr _pointer;

        public ImageBuffer()
        {
            _pointer = IntPtr.Zero;
            this.KeyObj = new object();
            this.Width = 640;
            this.Height = 480;
            this.Columns = 1;
            this.Rows = 1;
            this.Widths = this.Width * this.Columns;
            this.Heights = this.Height * this.Rows;
        }

        public HObject RawImage { get; set; }

        public object KeyObj { get; set; }

        public IntPtr ImagePointer { get { return _pointer; } }

        public int Width { get; set; }

        public int Height { get; set; }

        public int Widths { get; set; }

        public int Heights { get; set; }

        public int Columns { get; set; }

        public int Rows { get; set; }

        private void InitializeImageBuffer(HObject image, int columns, int rows)
        {
            lock (this.KeyObj)
            {
                this.Columns = columns;
                this.Rows = rows;

                HImageInfo hImageInfo = HOperatorSetEx.GetImagePointer1(image, false);

                _pointer = hImageInfo.Pointer;

                this.Widths = hImageInfo.Width;
                this.Width = this.Widths / this.Columns;

                this.Heights = hImageInfo.Height;
                this.Height = this.Heights / this.Rows;

                if (this.RawImage == null)
                {
                    this.RawImage = HOperatorSetEx.GenEmptyObj();
                }
                HObject ho_OldRawImage = this.RawImage.CopyObj(1, -1);
                this.RawImage.Dispose();
                this.RawImage = image;
                ho_OldRawImage.Dispose();
            }
        }

        public void InitializeImageBuffer(int width, int height, int columns, int rows)
        {
            HObject ho_ImageBuffer;

            HOperatorSet.GenEmptyObj(out ho_ImageBuffer);

            columns = columns == 0 ? 1 : columns;
            rows = rows == 0 ? 1 : rows;

            ho_ImageBuffer.Dispose();
            HOperatorSet.GenImageConst(out ho_ImageBuffer, "byte", width * columns, height * rows);
            InitializeImageBuffer(ho_ImageBuffer, columns, rows);
        }

        public void ReadImage(IntPtr pointer, int column, int row)
        {
            lock (this.KeyObj)
            {
                if (this.RawImage == null)
                {
                    throw new ArgumentException(string.Format("Column {0} Row {1} ImageBuffer isn't Initialization. RawImage is Null.", column, row));
                }
                if (!HOperatorSetEx.TestObjDef(this.RawImage))
                {
                    throw new ArgumentException(string.Format("Column {0} Row {1} ImageBuffer isn't Initialization. RawImage is Empty.", column, row));
                }
                for (int i = 0; i < this.Height; i++)
                {
                    byte[] tempData = new byte[this.Width];
                    Marshal.Copy(pointer + i * this.Width, tempData, 0, this.Width);
                    IntPtr destPtr = new IntPtr(this._pointer.ToInt64() + (long)column * this.Width +
                        (long)row * this.Width * this.Height + (long)i * this.Widths);
                    Marshal.Copy(tempData, 0, destPtr, this.Width);
                    //Marshal.Copy(tempData, 0, this._pointer + column * this.Width +
                    //    row * this.Width * this.Height + i * this.Widths, this.Width);
                    tempData = null;
                }
            }
        }

        public void ReadImage(string fileName, int column, int row)
        {
            try
            {
                lock (this.KeyObj)
                {
                    FileStream fileStream = File.OpenRead(fileName);
                    fileStream.Seek(1078, SeekOrigin.Begin);

                    for (int i = 0; i < this.Height; i++)
                    {
                        int ByteOfSkip = (this.Width % 4) != 0 ? (4 - this.Width % 4) : 0;
                        byte[] tempData = new byte[this.Width + ByteOfSkip];
                        fileStream.Read(tempData, 0, this.Width + ByteOfSkip);

                        //Marshal.Copy(tempData, 0, this._pointer + column * this.Width +
                        //  row * this.Width * this.Height * this.Columns + (this.Height - i - 1) * this.Widths, this.Width);

                        ///201411251800課長新增解決影像大小超出記憶體負荷，解決方式提升至更高位元Long取代Int
                        Marshal.Copy(tempData, 0, (IntPtr)(this._pointer.ToInt64() + (long)column * this.Width +
                            (long)row * this.Width * this.Height * this.Columns + (long)(this.Height - i - 1) * this.Widths)
                        , this.Width);
                        tempData = null;
                    }

                    fileStream.Close();
                }
            }
            catch(Exception e)
            {
            }
          
        }

        public void ReadImage(HObject image)
        {
            if (TestEqualObj(image))
            {
                return;
            }
            HObject ho_Image = image.CopyObj(1, -1);
            InitializeImageBuffer(ho_Image, 1, 1);
        }

        public void ReadImage(HObject image, int column, int row)
        {
            HObject ho_Image = image.CopyObj(1, -1);
            HImageInfo hImageInfo = HOperatorSetEx.GetImagePointer1(ho_Image, false);
            ReadImage(hImageInfo.Pointer.IP, column, row);
            ho_Image.Dispose();
        }

        /// <summary>由目前圖像中裁剪複製指定範圍之圖像</summary>
        /// <param name="column">Image Buffer中圖像起始位置</param>
        /// <param name="row"></param>
        /// <returns>裁剪後之指定範圍影像</returns>
        public HObject GetHImage(int column, int row)
        {
            if (this.RawImage == null)
            {
                throw new ArgumentException("ImageBuffer isn't Initialization. RawImage is Null.");
            }

            HObject ho_Image;

            HOperatorSet.GenEmptyObj(out ho_Image);

            HTuple row1 = this.Height * row;
            HTuple col1 = this.Width * column;
            HTuple row2 = row1 + this.Height - 1;
            HTuple col2 = col1 + this.Width - 1;
            HOperatorSet.CropRectangle1(this.RawImage, out ho_Image, row1, col1, row2, col2);

            return ho_Image;
        }

        /// <summary>由目前圖像中裁剪複製指定範圍之圖像</summary>
        /// <param name="startColumn">Image Buffer中圖像起始位置</param>
        /// <param name="startRow"></param>
        /// <param name="endColumn">Image Buffer中圖像結束位置</param>
        /// <param name="endRow"></param>
        /// <returns>裁剪後之指定範圍影像</returns>
        public HObject GetHImage(int startColumn, int startRow, int endColumn, int endRow)
        {
            if (this.RawImage == null)
            {
                throw new ArgumentException("ImageBuffer isn't Initialization. RawImage is Null.");
            }
            
            HObject ho_Image;

            HOperatorSet.GenEmptyObj(out ho_Image);

            HTuple row1 = this.Height * startRow;
            HTuple col1 = this.Width * startColumn;
            HTuple row2 = this.Height * (endRow + 1) - 1;
            HTuple col2 = this.Width * (endColumn + 1) - 1;
            HOperatorSet.CropRectangle1(this.RawImage, out ho_Image, row1, col1, row2, col2);

            return ho_Image;   
        }

        public byte[] GetRawData()
        {
            byte[] rawData = new byte[this.Widths * this.Heights];
            Marshal.Copy(_pointer, rawData, 0, this.Widths * this.Heights);
            return rawData;
        }

        public byte[] GetRawData(int row)
        {
            byte[] rawData = new byte[this.Widths];
            Marshal.Copy(_pointer + row * this.Widths, rawData, 0, this.Widths);
            return rawData;
        }

        public ImageBuffer CopyObj()
        {
            ImageBuffer imageBuffer = new ImageBuffer();
            if (HOperatorSetEx.TestObjDef(this.RawImage))
            {
                imageBuffer.RawImage = this.RawImage.CopyObj(1, -1);
            }
            imageBuffer.Width = this.Width;
            imageBuffer.Height = this.Height;
            imageBuffer.Widths = this.Widths;
            imageBuffer.Heights = this.Heights;
            imageBuffer.Columns = this.Columns;
            imageBuffer.Rows = this.Rows;
            return imageBuffer;
        }

        public bool TestEqualObj(HObject objects)
        {
            HTuple isEqual;
            if (!HOperatorSetEx.TestObjDef(this.RawImage))
            {
                return false;
            }
            HOperatorSet.TestEqualObj(this.RawImage, objects, out isEqual);
            return isEqual == 1;
        }

        public void Dispose()
        {
            if (this.RawImage != null)
            {
                this.RawImage.Dispose();
                _pointer = IntPtr.Zero;
            }
        }
    }
}
