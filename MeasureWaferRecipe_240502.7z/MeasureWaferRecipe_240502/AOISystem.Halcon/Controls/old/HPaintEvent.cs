﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Algorithm.Controls
{
    /// <summary>
    /// HControl Paint Delegate
    /// </summary>
    public delegate object HPaintEventDelegate(params object[] args);

    /// <summary>
    /// HControl Paint Handler
    /// </summary>
    public delegate void HPaintEventHandler(object sender, HPaintEventArgs e);

    /// <summary>
    /// Hcontrol Paint Event Args
    /// </summary>
    public class HPaintEventArgs : EventArgs
    {
        public int X;
        public int Y;
        public Point Location;
        public float Zoom;

        public int Width;
        public int Height;

        public HPaintEventArgs(int x, int y, float zoom)
        {
            this.X = x;
            this.Y = y;
            Location = new Point(x, y);
            this.Zoom = zoom;
        }

        public HPaintEventArgs(Size paintSize)
        {
            this.Width = paintSize.Width;
            this.Height = paintSize.Height;
        }
    }

    public enum ToolsControl
    {
        None,
        CreateRectangle,
        MoveRectangle,
        DeleteRectangle
    }
}
