﻿using System;
using System.Drawing;
using AOISystem.Halcon.Controls;
using AOISystem.Halcon.Recipe;
using HalconDotNet;

namespace AOISystem.Halcon.ROI
{
    public class ROIRotatableRectangle : ROIBase
    {
        //fields
        private double row1, col1;         // upper left
        private double row2, col2;         // lower right 
        private double centerR, centerC;   // midpoint 
        private double midR, midC, phi;         // row and column mid point
        private double length1;
        private double length2;
        public PointF uppoint, downpoint, leftpoint, rightpoint;
        public double mouseRow, mouseCol;

        //[Browsable(true), Category("Property"), Description("Row")]
        //public double Row
        //{
        //    get { return row1; }
        //}

        //[Browsable(true), Category("Property"), Description("Column")]
        //public double Column
        //{
        //    get { return col1; }
        //}

        //[Browsable(true), Category("Property"), Description("設定檔路徑")]
        //public double MidRow
        //{
        //    get { return midR; }
        //}

        /// <summary>
        /// Constructor
        /// </summary>
        public ROIRotatableRectangle()
        {
            NumHandles = 9; // 8 corner points + midpoint
            activeHandleIdx = 4;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_recipe"></param>
        public ROIRotatableRectangle(ROIInfo recipe)
            : this()
        {
            base.ROIInfo = recipe;
            ROIInfo.RegionType = 2;

            phi = recipe.Angle;
            centerC = recipe.X;
            centerR = recipe.Y;
            length1 = recipe.Width;
            length2 = recipe.Height;

        }

        /// <summary>
        /// create ROI 設定初始框大小位置
        /// </summary>
        public override void createROI(double midX, double midY)
        {
            length1 = (int)(40 / this.Scale);
            length2 = (int)(30 / this.Scale);
            //Center
            centerR = (int)midY;
            centerC = (int)midX;

            phi = 0;

        }

        /// <summary>
        /// draw 畫框
        /// </summary>
        public override void draw(HalconDotNet.HWindow window)
        {
            midR = row1 + (row2 - row1) / 2;
            midC = col1 + (col2 - col1) / 2;

            window.DispRectangle2(centerR, centerC, phi, length1, length2);
        }

        public override void drawFont(HalconDotNet.HWindow window)
        {
            int h_fontZoom = 0;
            if (this.ROIFontZoomMode == FontZoomMode.Positive)
            {
                h_fontZoom = (int)(this.FontSize * this.Scale);
            }
            else if (this.ROIFontZoomMode == FontZoomMode.Reverse)
            {
                h_fontZoom = (int)System.Math.Sqrt(this.FontSize / this.Scale);
                if (h_fontZoom < this.FontSizeThreshold)
                {
                    h_fontZoom = this.FontSizeThreshold;
                }
            }
            else
            {
                h_fontZoom = this.FontSize;
            }
            if (h_fontZoom >= this.FontSizeThreshold)
            {
                double x = 0, y = 0;
                calculatePointFont(out x, out y);
                //float[] arroyPX = new float[4] { uppoint.X, downpoint.X, leftpoint.X, rightpoint.X };
                //float[] arroyPY = new float[4] { uppoint.Y, downpoint.Y, leftpoint.Y, rightpoint.Y };
                //Array.Sort(arroyPX);

                //window.SetTposition((int)arroyPY[3], (int)arroyPX[3]);
                string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
                HTuple font = string.Format(fontFormat, h_fontZoom);
                window.SetFont(font);
                window.SetTposition((int)y, (int)x);
                window.WriteString(base.ROIInfo.InspectName);
            }
        }

        public override int ROIdistance(double x, double y)
        {
            calculatePoint();
            //float[] arroyPX = new float[4] { uppoint.X, downpoint.X, leftpoint.X, rightpoint.X };
            //float[] arroyPY = new float[4] { uppoint.Y, downpoint.Y, leftpoint.Y, rightpoint.Y };

            //Array.Sort(arroyPX);
            //Array.Sort(arroyPY);
            HObject R2ri, ans;
            HOperatorSet.GenRectangle2(out R2ri, centerR, centerC, phi, length1 + 15, length2 + 15);
            HOperatorSet.SelectRegionPoint(R2ri, out ans, y, x);
            if (ans.CountObj() != 0)
            {
                return (int)(length1 * length2);
            }

            return -1;
        }

        /// <summary>
        /// 計算最接近的小框
        /// </summary>
        public override bool distToClosestHandle2(double x, double y)
        {
            double Distance = 3, temp = 0;
            calculatePoint();
            mouseRow = y;
            mouseCol = x;

            bool flag;
            double max = double.MaxValue;
            double[] val = new double[NumHandles];
            bool[] valbool = new bool[NumHandles];
            double epsilon = 7 / this.Scale;

            row1 = centerR - length2;
            row2 = centerR + length2;
            col1 = centerC - length1;
            col2 = centerC + length1;

            val[0] = double.MaxValue;       // upper left 
            val[1] = double.MaxValue;        // upper right 
            val[2] = double.MaxValue;         // lower right 
            val[3] = double.MaxValue;         // lower left 
            val[4] = HMisc.DistancePp(y, x, centerR, centerC); // midpoint 
            val[5] = HMisc.DistancePp(y, x, uppoint.Y, uppoint.X);       // upper left  midpoint 
            val[6] = HMisc.DistancePp(y, x, downpoint.Y, downpoint.X);       // upper right  midpoint 
            val[7] = HMisc.DistancePp(y, x, leftpoint.Y, leftpoint.X);       // lower right midpoint 
            val[8] = HMisc.DistancePp(y, x, rightpoint.Y, rightpoint.X);       // lower left midpoint 
            //val[5] = HMisc.DistancePp(y, x, row1, midC);       // upper left  midpoint 
            //val[6] = HMisc.DistancePp(y, x, row2, midC);       // upper right  midpoint 
            //val[7] = HMisc.DistancePp(y, x, midR, col1);       // lower right midpoint 
            //val[8] = HMisc.DistancePp(y, x, midR, col2);       // lower left midpoint 
            HObject R2ri, ans;
            HOperatorSet.GenEllipse(out R2ri, uppoint.Y, uppoint.X, phi, length1, length2 / 4);
            HOperatorSet.SelectRegionPoint(R2ri, out ans, y, x);
            if (ans.CountObj() != 0)
            { valbool[5] = true; }
            HOperatorSet.GenEllipse(out R2ri, downpoint.Y, downpoint.X, phi, length1, length2 / 4);
            HOperatorSet.SelectRegionPoint(R2ri, out ans, y, x);
            if (ans.CountObj() != 0)
            { valbool[6] = true; }
            HOperatorSet.GenEllipse(out R2ri, leftpoint.Y, leftpoint.X, phi, length2, length1 / 4);
            HOperatorSet.SelectRegionPoint(R2ri, out ans, y, x);
            if (ans.CountObj() != 0)
            { valbool[7] = true; }
            HOperatorSet.GenEllipse(out R2ri, rightpoint.Y, rightpoint.X, phi, length2, length1 / 4);
            HOperatorSet.SelectRegionPoint(R2ri, out ans, y, x);
            if (ans.CountObj() != 0)
            { valbool[8] = true; }
            activeHandleIdx = 0;
            for (int i = 5; i < 9; i++)
            {
                if (valbool[i] && max > val[i])
                {
                    max = val[i];
                    activeHandleIdx = i;
                }
            }
            if (activeHandleIdx != 0)
            { return true; }
            if (ROIdistance(x, y) > 0)
            {
                activeHandleIdx = 4;
                return true;
            }

            //if (length2 < 200)
            //{ Distance = 2; }
            //else { Distance = 7 / 3; }
            //if (length2 < 20)
            //{ temp = 0; }
            //else
            //{ temp = 20; }
            //for (int i = 5; i < 7; i++)
            //{
            //    if (val[i] < (length2 + temp) / Distance)
            //    {
            //        max = val[i];
            //        activeHandleIdx = i;
            //        return true;
            //    }
            //}
            //if (length1 < 200)
            //{ Distance = 2; }
            //else { Distance = 7 / 3; }
            //if (length1 < 20)
            //{ temp = 0; }
            //else
            //{ temp = 20; }
            //for (int i = 7; i < 9; i++)
            //{
            //    if (val[i] < (length1 + temp) / Distance)
            //    {
            //        max = val[i];
            //        activeHandleIdx = i;
            //        return true;
            //    }
            //}

            //if (val[4] < length1 || val[4] < length2)
            //{
            //    activeHandleIdx = 4;
            //    return true;
            //}

            activeHandleIdx = 0;
            return false;

        }


        /// <summary> 
        /// Paints the active handle of the ROI object into the supplied window
        /// </summary>
        /// <param name="window">HALCON window</param>
        public override void displayActive(HalconDotNet.HWindow window)
        {
            calculatePoint();
            double dislength1 = 5 / this.Scale;
            double dislength2 = 5 / this.Scale;

            //window.DispLine((double)uppoint.Y, uppoint.X, downpoint.Y, downpoint.X);
            //window.DispLine((double)leftpoint.Y, leftpoint.X, rightpoint.Y, rightpoint.X);
            ////  Angle1 * 180 / Math.PI, Angle2 * 180 / Math.PI
            //window.SetTposition(0, 0);
            //window.WriteString(string.Format("Angle1 = {0}, Angle2 = {1},a_diff = {2} Phi = {3}, x = {4}, y = {5}",
            //   a1, a2, angledifference, phi * 180 / Math.PI, downpoint.X, downpoint.Y));
            //window.SetTposition(80, 0);

            //window.WriteString(string.Format("length1 = {0}, length2 = {1}, DisX = {2}, DisY = {3}",
            //     length1, length2, DisX, DisY));

            //double distance = Math.Sqrt(Math.Pow(length1, 2) + Math.Pow(length2, 2));

            //switch (activeHandleIdx)
            for (int i = 0; i < 9; i++)
            {
                if (i == activeHandleIdx)
                    HOperatorSet.SetColor(window, "red");
                else
                    HOperatorSet.SetColor(window, "blue");
                switch (i)
                {
                    //case 0:
                    //    window.DispRectangle2(row1, col1, phi, dislength1, dislength2);
                    //    break;
                    //case 1:
                    //    window.DispRectangle2(row1, col2, phi, dislength1, dislength2);
                    //    break;
                    //case 2:
                    //    window.DispRectangle2(row2, col2, phi, dislength1, dislength2);
                    //    break;
                    //case 3:
                    //    window.DispRectangle2(row2, col1, phi, dislength1, dislength2);
                    //    break;
                    case 4:
                        window.DispRectangle2(centerR, centerC, phi, dislength1, dislength2);
                        break;
                    case 5:
                        //window.DispRectangle2(row1, centerC, phi, dislength1, dislength2);
                        window.DispRectangle2(uppoint.Y, uppoint.X, phi, dislength1, dislength2);
                        break;
                    case 6:
                        //window.DispRectangle2(row2, centerC, phi, dislength1, dislength2);
                        window.DispRectangle2(downpoint.Y, downpoint.X, phi, dislength1, dislength2);
                        break;
                    case 7:
                        //window.DispRectangle2(centerR, col1, phi, dislength1, dislength2);
                        window.DispRectangle2(leftpoint.Y, leftpoint.X, phi, dislength1, dislength2);
                        break;
                    case 8:
                        //window.DispRectangle2(centerR, col2, phi, dislength1, dislength2);
                        window.DispRectangle2(rightpoint.Y, rightpoint.X, phi, dislength1, dislength2);
                        break;
                }
            }
            arrow(window, rightpoint);
            HOperatorSet.SetColor(window, "red");
        }

        public void drawFont(HalconDotNet.HWindow window, HTuple row, HTuple col)
        {
            window.SetFont("-Arial-18-*-1-*-*-1-ANSI_CHARSET-");
            window.SetTposition(row, col);
            window.WriteString(base.ROIInfo.InspectName);
        }
        /// <summary>
        /// Gets the HALCON region described by the ROI
        /// </summary>
        /// <returns></returns>
        public override HRegion getRegion()
        {
            HRegion region = new HRegion();
            region.GenRectangle2(centerR, centerC, phi, length1, length2);
            return region;
        }

        public override System.Drawing.RectangleF getRectangleF()
        {
            ROIInfo.X = centerC;
            ROIInfo.Y = centerR;
            ROIInfo.Width = length1;
            ROIInfo.Height = length2;
            ROIInfo.Angle = phi;
            return new System.Drawing.RectangleF((float)col1, (float)row1, (float)(col2 - col1), (float)(row2 - row1));
        }
        /// <summary> 
        /// Recalculates the shape of the ROI instance. Translation is 
        /// performed at the active handle of the ROI object 
        /// for the image coordinate (x,y)
        /// </summary>
        /// <param name="newX">x mouse coordinate</param>
        /// <param name="newY">y mouse coordinate</param>

        double Angle1 = 0;
        double Angle2 = 0;
        double DisX = 0;
        double DisY = 0;
        double angledifference = 0;
        double a1 = 0, a2 = 0;
        public override void moveByHandle(double newX, double newY)
        {
            calculatePoint();
            PointF p;
            double temp;
            double length = 0;
            double Distance = 0;
            bool flag = false;
            a1 = 0; a2 = 0; Angle1 = 0; Angle2 = 0;
            DisX = 0; DisY = 0; angledifference = 0;
            switch (activeHandleIdx)
            {
                //case 0: // upper left 
                //    row1 = newY;
                //    col1 = newX;
                //    break;
                //case 1: // upper right 
                //    row1 = newY;
                //    col2 = newX;
                //    break;
                //case 2: // lower right 
                //    row2 = newY;
                //    col2 = newX;
                //    break;
                //case 3: // lower left
                //    row2 = newY;
                //    col1 = newX;
                //    break;
                case 4: // midpoint 
                    centerR = newY;
                    centerC = newX;
                    break;
                case 5:
                    //row1 = newY;
                    //length2 = HMisc.DistancePp(newY, newX, centerR, centerC);

                    p = downpoint;
                    Angle1 = -Math.Atan2(-(downpoint.Y - newY), -(downpoint.X - newX)); ;
                    a1 = Angle1 * 180 / Math.PI;

                    if (phi >= 0)
                    { temp = (phi * 180 / Math.PI); }
                    else
                    { temp = 360 + (phi * 180 / Math.PI); }

                    if (temp >= 0 && temp <= 270)
                    { a2 = temp + 90; }
                    else if (temp > 270)
                    { a2 = temp - 270; }
                    Angle2 = (a2 / 180 * Math.PI);

                    if (Angle1 > 0)
                    { a1 = Angle1 * 180 / Math.PI; }
                    else
                    { a1 = (Angle1 * 180 / Math.PI) + 360; }

                    angledifference = a1 - a2;
                    Distance = HMisc.DistancePp(newY, newX, downpoint.Y, downpoint.X);
                    if ((angledifference < 90 && angledifference > -90))
                    {
                        length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance));
                        flag = true;
                    }
                    else if ((a2 + 90 - 360) > a1 && a2 > 270)
                    {
                        if (a1 < 90)
                        { length = Math.Abs((Math.Cos((Angle2 - (Angle1 + (2 / 180 * Math.PI)))) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }
                    else if ((a1 > 270 + a2) && a2 < 90)
                    {
                        if (a1 > 270 + a2)
                        { length = Math.Abs((Math.Cos(((Angle2 + (2 / 180 * Math.PI)) - Angle1)) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }
                    if (flag)
                    {
                        if (length == 0)
                        { length2 = 1; }
                        else
                        { length2 = length / 2; }

                        calculatePoint();

                        centerR = centerR + p.Y - downpoint.Y;
                        centerC = centerC + p.X - downpoint.X;
                    }

                    break;
                case 6:
                    //row2 = newY;
                    //length2 = HMisc.DistancePp(newY, newX, centerR, centerC);
                    //row1 = newY;
                    //length2 = HMisc.DistancePp(newY, newX, centerR, centerC);
                    p = uppoint;
                    Angle1 = -Math.Atan2(-(uppoint.Y - newY), -(uppoint.X - newX)); ;
                    a1 = Angle1 * 180 / Math.PI;

                    if (phi >= 0)
                    { temp = (phi * 180 / Math.PI); }
                    else
                    { temp = 360 + (phi * 180 / Math.PI); }

                    if (temp >= 0 && temp <= 90)
                    { a2 = temp + 270; }
                    else
                    { a2 = temp - 90; }
                    Angle2 = (a2 / 180 * Math.PI);

                    if (Angle1 > 0)
                    { a1 = Angle1 * 180 / Math.PI; }
                    else
                    { a1 = (Angle1 * 180 / Math.PI) + 360; }

                    angledifference = a1 - a2;
                    Distance = HMisc.DistancePp(newY, newX, uppoint.Y, uppoint.X);
                    if ((angledifference < 90 && angledifference > -90) || (a2 + 90 - 360) > a1)
                    {
                        length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance));
                        flag = true;
                    }
                    else if (a1 < (a2 + 90) - 360 && a2 > 270)
                    {
                        if (a1 < 90)
                        { length = Math.Abs((Math.Cos((Angle2 - (Angle1 + (2 / 180 * Math.PI)))) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }
                    else if ((a1 > 270 + a2) && a2 < 90)
                    {
                        if (a1 > 270 + a2)
                        { length = Math.Abs((Math.Cos(((Angle2 + (2 / 180 * Math.PI)) - Angle1)) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }
                    if (flag)
                    {
                        if (length == 0)
                        { length2 = 1; }
                        else
                        { length2 = length / 2; }

                        calculatePoint();

                        centerR = centerR + p.Y - uppoint.Y;
                        centerC = centerC + p.X - uppoint.X;
                    }
                    break;
                case 7:
                    //col1 = newX;
                    //length1 = HMisc.DistancePp(newY, newX, centerR, centerC);

                    p = rightpoint;
                    Angle1 = -Math.Atan2(-(rightpoint.Y - newY), -(rightpoint.X - newX)); ;
                    a1 = Angle1 * 180 / Math.PI;

                    if (phi >= 0)
                    { temp = (phi * 180 / Math.PI); }
                    else
                    { temp = 360 + (phi * 180 / Math.PI); }

                    if (temp >= 0 && temp <= 180)
                    { a2 = temp + 180; }
                    else if (temp > 180)
                    { a2 = temp - 180; }

                    Angle2 = (a2 / 180 * Math.PI);

                    if (Angle1 > 0)
                    { a1 = Angle1 * 180 / Math.PI; }
                    else
                    { a1 = (Angle1 * 180 / Math.PI) + 360; }

                    angledifference = a1 - a2;
                    Distance = HMisc.DistancePp(newY, newX, rightpoint.Y, rightpoint.X);
                    if ((angledifference < 90 && angledifference > -90))
                    {
                        length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance));
                        flag = true;
                    }
                    else if (a1 < (a2 + 90) - 360 && a2 > 270)
                    {
                        if (a1 < 90)
                        { length = Math.Abs((Math.Cos((Angle2 - (Angle1 + (2 / 180 * Math.PI)))) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }
                    else if ((a1 > 270 + a2) && a2 < 90)
                    {
                        if (a1 > 270 + a2)
                        { length = Math.Abs((Math.Cos(((Angle2 + (2 / 180 * Math.PI)) - Angle1)) * Distance)); }
                        else
                        { length = Math.Abs((Math.Cos((Angle2 - Angle1)) * Distance)); }
                        flag = true;
                    }

                    if (flag)
                    {
                        if (length == 0)
                        { length1 = 1; }
                        else
                        { length1 = length / 2; }

                        calculatePoint();

                        centerR = centerR + p.Y - rightpoint.Y;
                        centerC = centerC + p.X - rightpoint.X;
                    }

                    break;
                case 8:
                    //col2 = newX;
                    length1 = HMisc.DistancePp(newY, newX, centerR, centerC);
                    phi = -Math.Atan2((newY - centerR), (newX - centerC));

                    break;
            }
        }

        private void calculatePoint()
        {
            // uppoint, downpoint, leftpoint, rightpoint;

            double distance = length1;
            double DisX = (Math.Cos((-phi)) * distance);
            double DisY = (Math.Sin((-phi)) * distance);

            double Angle_C = centerC + DisX;
            double Angle_R = centerR + DisY;
            distance = length1;
            DisX = (Math.Cos((-phi)) * distance);
            DisY = (Math.Sin((-phi)) * distance);
            rightpoint.X = (int)(centerC + DisX);
            rightpoint.Y = (int)(centerR + DisY);

            distance = length1;
            DisX = (Math.Cos((-phi + (1 * 3.14159))) * distance);
            DisY = (Math.Sin((-phi + (1 * 3.14159))) * distance);
            leftpoint.X = (int)(centerC + DisX);
            leftpoint.Y = (int)(centerR + DisY);

            distance = length2;
            DisX = (Math.Cos((-phi - (0.5 * 3.14159))) * distance);
            DisY = (Math.Sin((-phi - (0.5 * 3.14159))) * distance);
            uppoint.X = (int)(centerC + DisX);
            uppoint.Y = (int)(centerR + DisY);

            distance = length2;
            DisX = (Math.Cos((-phi + (0.5 * 3.14159))) * distance);
            DisY = (Math.Sin((-phi + (0.5 * 3.14159))) * distance);
            downpoint.X = (int)(centerC + DisX);
            downpoint.Y = (int)(centerR + DisY);

        }
        private void arrow(HalconDotNet.HWindow window, PointF p)
        {
            PointF PtoP = new PointF();
            PointF arrowP = new PointF();
            double length1 = 25 / this.Scale;
            double length2 = 15 / this.Scale;

            double DisX = (Math.Cos((-phi)) * length1);
            double DisY = (Math.Sin((-phi)) * length1);

            PtoP.X = (int)(p.X + DisX);
            PtoP.Y = (int)(p.Y + DisY);

            window.DispLine((double)p.Y, p.X, PtoP.Y, PtoP.X);

            DisX = (Math.Cos((-phi - 0.8 * 3.14159)) * length2);
            DisY = (Math.Sin((-phi - 0.8 * 3.14159)) * length2);

            arrowP.X = (int)(PtoP.X + DisX);
            arrowP.Y = (int)(PtoP.Y + DisY);

            window.DispLine((double)arrowP.Y, arrowP.X, PtoP.Y, PtoP.X);
            DisX = (Math.Cos((-phi + 0.8 * 3.14159)) * length2);
            DisY = (Math.Sin((-phi + 0.8 * 3.14159)) * length2);

            arrowP.X = (int)(PtoP.X + DisX);
            arrowP.Y = (int)(PtoP.Y + DisY);

            window.DispLine((double)arrowP.Y, arrowP.X, PtoP.Y, PtoP.X);

        }
        private void calculatePointFont(out double x, out double y)
        {
            // uppoint, downpoint, leftpoint, rightpoint;

            double distance = Math.Sqrt(Math.Pow(length1, 2) + Math.Pow(length2, 2));
            double DisX = 0;
            double DisY = 0;
            double phinum = phi * 180 / 3.14159;
            double Angle = Math.Atan2((length2), (length1));
            double Anglenum = Angle * 180 / 3.14159;
            phinum = (phi) * 180 / 3.14159;

            if (phinum >= (90 - Anglenum) && phinum <= (90 + Anglenum))
            {
                //右上
                DisX = (Math.Cos((-phi - Angle)) * distance);
                DisY = (Math.Sin((-phi - Angle)) * distance);
            }
            if ((phinum <= 180 && phinum > 90 + Anglenum) || (phinum >= -180 && phinum < -90 - Anglenum))
            {
                //右下
                DisX = (Math.Cos((-phi + Angle)) * distance);
                DisY = (Math.Sin((-phi + Angle)) * distance);
            }
            if (phinum >= (-90 - Anglenum) && phinum <= (-90 + Anglenum))
            {
                //左下
                DisX = (Math.Cos((-phi - (Angle + 3.14159))) * distance);
                DisY = (Math.Sin((-phi - (Angle + 3.14159))) * distance);
            }
            if ((phinum >= 0 && phinum < 90 - Anglenum) || (phinum <= 0 && phinum > -90 + Anglenum))
            {
                //左上
                DisX = (Math.Cos((-phi + (Angle - 3.14159))) * distance);
                DisY = (Math.Sin((-phi + (Angle - 3.14159))) * distance);
            }
            x = (int)(centerC + DisX);
            y = (int)(centerR + DisY);
        }
    }
}
