﻿using System;
using System.ComponentModel;
using System.Reflection;
using HalconDotNet;

namespace AOISystem.Halcon.PropertyType
{
    public class PropertyTypeConverter
    {
        public object Parse(string typeName, string parseString)
        {
            if (typeName == null | string.IsNullOrEmpty(parseString))
            {
                throw new ArgumentException("轉型參數錯誤，請確認轉型物件之命名空間與轉型字串");
            }

            if (typeName == typeof(string).FullName)
            {
                return parseString;
            }

            if (typeName == typeof(HTuple).FullName)
            {

                return Activator.CreateInstance(typeof(HTuple), new object[] { parseString });
            }

            Type type = Type.GetType(typeName);

            if (type == null)
            {
                throw new ArgumentException("轉型失敗，無法取得型別Type");
            }
            MethodInfo typeMeth = type.GetMethod("Parse", new Type[] { typeof(string) });
            if (typeMeth == null)
            {
                throw new ArgumentException("轉型失敗，" + typeName + "不支援Parse(string s)");
            }
            return typeMeth.Invoke(null, new object[] { parseString });

        }

        public object Parse(object sender, PropertyDescriptor property, string parseString)
        {
            string typeName = property.PropertyType.FullName;

            if (typeName == null | string.IsNullOrEmpty(parseString))
            {
                throw new ArgumentException("轉型參數錯誤，請確認轉型物件之命名空間與轉型字串");
            }

            if (typeName == typeof(string).FullName)
            {
                return parseString;
            }

            if (typeName == typeof(HTuple).FullName)
            {
                return Activator.CreateInstance(typeof(HTuple), new object[] { HTupleTypeConverter.HTupleStringTypeConverter(parseString) } );
            }

            Type type = Type.GetType(typeName);

            if (type == null)
            {
                throw new ArgumentException("轉型失敗，無法取得型別Type");
            }
            MethodInfo typeMeth = type.GetMethod("Parse", new Type[] { typeof(string) });
            if (typeMeth == null)
            {
                throw new ArgumentException("轉型失敗，" + typeName + "不支援Parse(string s)");
            }
            return typeMeth.Invoke(null, new object[] { parseString });
        }
    }

    //------------------------------------
    public class MyConverter : ExpandableObjectConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ListAttribute lst = (ListAttribute)context.PropertyDescriptor.Attributes[typeof(ListAttribute)];
            StandardValuesCollection vals = new TypeConverter.StandardValuesCollection(lst.lists);
            return vals;
        }
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            return true;
        }

    }
    public class ListAttribute : Attribute
    {
        public string[] lists;
        public ListAttribute(string S)
        {
            switch (S)
            {
                case "Transition":
                    lists = new string[] { "all", "positive", "negative", "all_strongest", "positive_strongest", "negative_strongest" };
                    break;
                case "Interpolation":
                    lists = new string[] { "nearest_neighbor", "bilinear", "bicubic" };
                    break;
                case "RGB":
                    lists = new string[] { "R", "G", "B", "Gray", "Mono" };
                    break;
                case "YesOrNo":
                    lists = new string[] { "Y", "N" };
                    break;
            }
        }
    }
}
