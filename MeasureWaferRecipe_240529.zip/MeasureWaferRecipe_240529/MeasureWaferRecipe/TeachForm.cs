﻿using AOISystem.Halcon.Controls;
using HalconDotNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeasureWaferRecipe
{
    public partial class TeachForm : Form
    {
        #region Initial
        CAlgorithmConfig config = new CAlgorithmConfig();
        OpenFileDialog openFileDialog = new OpenFileDialog();
        FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
        SalmonAlgorithm salmonAlgorithm = new SalmonAlgorithm();
        string ConfigPath = "./AlgorithmConfig.xml";
        public TeachForm()
        {
            InitializeComponent();
        }

        public void SetConfig(string path)
        {
            ConfigPath = path;
            salmonAlgorithm.LoadConfig(ConfigPath);

        }
        private void TeachForm_Load(object sender, EventArgs e)
        {
            //load recipe
            salmonAlgorithm.LoadConfig(ConfigPath);
            txb_recipePath.Text = ConfigPath;
        }

        #endregion

        #region Hui-Demo
        HObject EdgeImage;
        HObject NotchImage;

        //缺陷1
        HObject ho_NotchImage;
        HObject RawLineScanImage;
        HTuple LineNotchModelID;
        HTuple AreaNotchModelID;
        HTuple hv_EdgePntRows = null, hv_EdgePntCols;
        bool IsDefectFirstTest = false;
        HObject ho_CropImage, ho_CropImage_AI;
        bool IsCropOK = false;
        bool IsDomainFirst = false;
        int[] catchIndexes = new int[0];

        private void nud_bu2Ratio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btn_LoadImage_Edge_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_EdgeImgPath.Text = openFileDialog.FileName;
                if (txb_EdgeImgPath.Text == "")
                    return;
                HOperatorSet.ReadImage(out EdgeImage, txb_EdgeImgPath.Text);
                HOperatorSet.GetImageSize(EdgeImage, out HTuple width, out HTuple height);
                if (height > 1440)
                {
                    txb_EdgeImgPath.Text = "";
                    MessageBox.Show("影像尺寸錯誤非面幅影像");
                    return;
                }


                hctrl_EdgeView.ReadImage(EdgeImage);
                hctrl_EdgeView.ZoomToFit();
            }
        }

        private void btn_MasureTest_Edge_Click(object sender, EventArgs e)
        {
            if (txb_EdgeImgPath.Text == "")
            {
                MessageBox.Show("請先輸入圖片");
                return;
            }
            MeasureEdge(EdgeImage);
        }

        private EdgeMeasureResultData MeasureEdge(HObject edgeImage)
        {
            EdgeMeasureResultData result = new EdgeMeasureResultData();
            HTuple hv_PixelSize = 3.45;  //um
            double hv_rotateAngle = Convert.ToDouble(nud_EdgeRotateAngle.Value);
            double hv_GrayMax = Convert.ToDouble(nud_GrayMax.Value);
            double hv_RoiY1 = 221.418;
            double hv_RoiX1 = 227.161;
            double hv_RoiY2 = 1174;
            double hv_RoiX2 = 1179;

            double hv_A1Ang = Convert.ToDouble(nud_AngleStart1.Value);
            double hv_A2Ang = Convert.ToDouble(nud_AngleStart2.Value);
            double hv_C1Ang = Convert.ToDouble(nud_AngleTop1.Value);
            double hv_C2Ang = Convert.ToDouble(nud_AngleTop2.Value);
            double hv_bu11 = Convert.ToDouble(nud_bu1Ratio.Value);
            double hv_bv11 = Convert.ToDouble(nud_bv1Ratio.Value);
            double hv_bu22 = Convert.ToDouble(nud_bu2Ratio.Value);
            double hv_bv22 = Convert.ToDouble(nud_bv2Ratio.Value);
            double hv_ExAngle = Convert.ToDouble(nud_exAngle.Value);
            double hv_ScaleW = Convert.ToDouble(nud_hvScaleW.Value);
            double hv_ScaleH = Convert.ToDouble(nud_hvScaleH.Value);
            double hv_CMeasureNumber = Convert.ToDouble(nud_CMeasureNumber.Value);

            HalconFunction.MeasureWaferEdgeB(edgeImage, out HObject ho_ImageOut, out HObject ho_rotateImage,
            hv_PixelSize, hv_rotateAngle, hv_GrayMax, hv_RoiY1,
            hv_RoiX1, hv_RoiY2, hv_RoiX2, hv_A1Ang, hv_A2Ang,
            hv_C1Ang, hv_C2Ang, hv_bu11, hv_bv11, hv_bu22,
            hv_bv22, hv_ExAngle, hv_ScaleW, hv_ScaleH, hv_CMeasureNumber,
            out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
            out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
            out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
            out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
            out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
            out HTuple hv_TextsY);

            if (hv_ErrorMsg.Length != 0 || hv_A2.Length == 0)
            {
                MessageBox.Show(hv_ErrorMsg);
                return null;
            }
            hctrl_EdgeView.ReadImage(ho_ImageOut);
            hctrl_EdgeView.ZoomToFit();

            txb_A1.Text = "" + hv_A1;
            txb_A2.Text = "" + hv_A2;
            txb_B1.Text = "" + hv_B1;
            txb_B2.Text = "" + hv_B2;
            txb_BC.Text = "" + hv_BC;
            txb_C1.Text = "" + hv_C1;
            txb_C2.Text = "" + hv_C2;
            txb_R1.Text = "" + hv_R1;
            txb_R2.Text = "" + hv_R2;
            txb_t.Text = "" + hv_t;
            txb_Ang1.Text = "" + hv_Ang1;
            txb_Ang2.Text = "" + hv_Ang2;

            result.A1 = "" + hv_A1;
            result.A2 = "" + hv_A2;
            result.B1 = "" + hv_B1;
            result.B2 = "" + hv_B2;
            result.BC = "" + hv_BC;
            result.C1 = "" + hv_C1;
            result.C2 = "" + hv_C2;
            result.R1 = "" + hv_R1;
            result.R2 = "" + hv_R2;
            result.t = "" + hv_t;
            result.Ang1 = "" + hv_Ang1;
            result.Ang2 = "" + hv_Ang2;

            return result;
        }

        private void btn_LoadImage_Notch_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_NotchImgPath.Text = openFileDialog.FileName;
                if (txb_NotchImgPath.Text == "")
                    return;
                HOperatorSet.ReadImage(out NotchImage, txb_NotchImgPath.Text);
                hctrl_NotchView.ReadImage(NotchImage);
                hctrl_NotchView.ZoomToFit();
            }
        }

        private void btn_MasureTest_Notch_Click(object sender, EventArgs e)
        {
            HObject[] notchImagesArr = new HObject[1];
            if (txb_NotchImgPath.Text == "")
            {
                MessageBox.Show("請輸入圖片再進測試");
                return;
            }
            else
            {
                if (File.Exists(txb_NotchImgPath.Text))
                {

                    HOperatorSet.ReadImage(out notchImagesArr[0], txb_NotchImgPath.Text);
                }
                else
                {
                    MessageBox.Show("圖片不存在");
                    return;
                }
            }

            //load recipe
            salmonAlgorithm.LoadConfig(txb_recipePath.Text);

            HObject resultImage = new HObject();
            NotchMeasureResult result = new NotchMeasureResult();


            bool state = salmonAlgorithm.DoNotchMeasure(notchImagesArr, ref resultImage, ref result);

            txb_Vh.Text = "" + result.Vh;
            txb_Vw.Text = "" + result.Vw;
            txb_Vr.Text = "" + result.Vr;
            txb_AngV.Text = "" + result.AngV;
            txb_P1.Text = "" + result.P1;
            txb_P2.Text = "" + result.P2;
            txb_VR1.Text = "" + result.Vr1;
            txb_VR2.Text = "" + result.Vr2;

            hctrl_NotchView.ReadImage(resultImage);
            hctrl_NotchView.ZoomToFit();
        }

        private void btn_LoadImage_Defect_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_ImageRaw_1.Text = openFileDialog.FileName;
                if (txb_ImageRaw_1.Text == "")
                    return;
                HOperatorSet.ReadImage(out RawLineScanImage, txb_ImageRaw_1.Text);
                hctrl_RawImage_1.ReadImage(RawLineScanImage);
                hctrl_RawImage_1.ZoomToFit();
            }
        }

        /*private void btn_TestCropNotch_Click(object sender, EventArgs e)
        {
            IsCropOK = false;
            IsDomainFirst = false;
            IsDefectFirstTest = false;

            string ModelPath = txb_model_1.Text;
            string[] sArray = ModelPath.Split('.');

            if (txb_model_1.Text == "" || sArray[sArray.Length - 1] != "shm")
            {
                MessageBox.Show("Model檔案錯誤");
                return;
            }

            if (txb_ImageRaw_1.Text == "")
            {
                MessageBox.Show("請輸入影像");
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";
            string[] captureImages = null;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                captureImages = openFileDialog.FileNames;
            }
            if (captureImages.Length == 0) return;
            HObject[] hv_captureImages = new HObject[captureImages.Length];
            foreach (string captureImage in captureImages)
            {
                HOperatorSet.ReadImage(out HObject hv_captureImage, captureImage);
                hv_captureImages.Append(hv_captureImage);
            }

            HalconFunction.MatchNotch2HObject(out HObject LineScanImage_Raw, out HObject LineScanImage_NotchCenter,
                out int notchLocation, hv_captureImages, LineNotchModelID, 0.6, 2048, 120000);

            hctrl_RawImage_1.ReadImage(LineScanImage_NotchCenter);
            hctrl_RawImage_1.ZoomToFit();

            double hv_CropNotchWidth = Convert.ToDouble(nud_CropNotchWidth_1.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_1.Value);
            double hv_PixelSize = Convert.ToDouble(nud_PixelSize_1.Value);
            double hv_CropSize = Convert.ToDouble(nud_CropSize_1.Value);
            double hv_MinScore = Convert.ToDouble(nud_MinScore_1.Value);

            HalconFunction.CalculateEdgePntAndCropNotch(LineScanImage_NotchCenter, out ho_NotchImage,
                        LineNotchModelID, hv_CropNotchWidth, hv_InDistance, hv_PixelSize,
                        hv_CropSize, hv_MinScore, out hv_EdgePntRows, out hv_EdgePntCols,
                        out HTuple hv_ErrMsg, out HTuple hv_NotchLocation);

            if (hv_ErrMsg.Length != 0)
            {
                MessageBox.Show(hv_ErrMsg + "請調整參數");
                return;
            }
            else
            {
                if (nud_catchAreaNum.Value > nud_totalAreaNum.Value)
                {
                    MessageBox.Show("面幅取樣點數量不能大於取像數量");
                    return;
                }
                if (hv_NotchLocation != null)
                {
                    nud_notchPosition.Value = Convert.ToInt32((double)hv_NotchLocation);
                }

                int lineScanResolution = 120000;

                catchIndexes = CatchEdgeImageIndex(lineScanResolution, hv_NotchLocation, nud_totalAreaNum.Value, nud_catchAreaNum.Value, nud_shiftAngle.Value);
                textBox_catchImage.Text = string.Join(", ", catchIndexes);
                hctrl_NotchImg_1.ReadImage(ho_NotchImage);
                hctrl_NotchImg_1.ZoomToFit();
                int number = hv_EdgePntRows.Length;
                lab_dispNumber_1.Text = "全部共有 " + number + " 張";
                nud_SelectCropImg_1.Maximum = number;
                IsCropOK = true;  //裁切成功
            }
        }*/

        private int[] CatchEdgeImageIndex(int linescanResolution, double notchLocation, decimal areaTotalNum, decimal catchNum, decimal notchShiftDegreeAngle)
        {
            int lineGap = Convert.ToInt32(linescanResolution / catchNum);
            int areaGap = Convert.ToInt32(linescanResolution / areaTotalNum);
            int shiftLine = Convert.ToInt32(linescanResolution * (notchShiftDegreeAngle / 360));
            //第一張加上shift
            int index = Convert.ToInt32(notchLocation + shiftLine);

            int[] imgNumber = new int[0];
            while (imgNumber.Count() < catchNum)
            {
                int captureCount = Convert.ToInt32(index / areaGap) + 1; //第一張圖為01

                if (Math.Abs((captureCount) * areaGap - index) < Math.Abs((captureCount - 1) * areaGap - index))//檢查前後張距離
                {
                    captureCount++;
                }
                if (captureCount > areaTotalNum) captureCount = captureCount - Convert.ToInt32(areaTotalNum);
                imgNumber = imgNumber.Append(captureCount).ToArray();

                if (imgNumber.Count() == 1) index = index - shiftLine; //去除第一張shift再計算其他張
                index = index + lineGap;
                if (index > linescanResolution) //超出linescan的話從頭算
                {
                    index = index - linescanResolution;
                }
            }
            Array.Sort(imgNumber);
            return imgNumber;
        }

        private void btn_TestDefect_Click(object sender, EventArgs e)
        {
            if (IsDefectFirstTest != false)
            {
                btn_CropInspectionImg_Click(sender, e);
            }
            else
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            IsDefectFirstTest = true;

            double hv_RoiWidthToBevelCenter = Convert.ToDouble(nud_RoiWidthToBevelCenter_1.Value);
            double hv_BevelWidth = Convert.ToDouble(nud_BevelWidth_1.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_1.Value);
            double hv_AiDefectSize = Convert.ToDouble(nud_AiDefectSize_1.Value);
            double hv_AiMinGray = Convert.ToDouble(nud_AiMinGray_1.Value);
            double hv_InnerDefectAreaSize = Convert.ToDouble(nud_InnerDefectAreaSize_1.Value);
            double hv_InnerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_1.Value);
            double hv_BevelDefectAreaSize = Convert.ToDouble(nud_EdgeDefectAreaSize_1.Value);
            double hv_BevelDefectMaxGray = Convert.ToDouble(nud_GrayMax);

            double hv_ROIColumn = Convert.ToDouble(nud_ROIColumn.Value);//370;     //檢查roi範圍
            double hv_DarkLightThreshold = Convert.ToDouble(nud_DarkLightThreshold.Value);// 150;  //DarkLightThreshold
            double hv_light_DarkThres = Convert.ToDouble(nud_light_DarkThres.Value);// 45;
            double hv_DarkMax = Convert.ToDouble(nud_DarkMax.Value);//50;
            double hv_Dark_DarkThres = Convert.ToDouble(nud_Dark_DarkThres.Value);//35;
            double hv_Dark_LightThres = Convert.ToDouble(nud_Dark_LightThres.Value);// 60;
            double hv_WhiteThres = Convert.ToDouble(nud_WhiteThres.Value);// 20;
            double hv_MinAreaSize = Convert.ToDouble(nud_MinAreaSize.Value);// 20;
            double hv_MinDefectSize = Convert.ToDouble(nud_MinDefectSize.Value);//1;
            double hv_LineBypassWidth = 2;
            bool hv_PaintResult = true;
            bool hv_HaveSecondEdge = true;
            double hv_gamma = 1.5;
            int hv_findLineMask = 5;
            double hv_findLineLow = 3;
            double hv_findLineHigh = 8;
            bool hv_onlyInspectEdge = false;
            double hv_lineScanPixelSize = 7.04;
            double hv_insideInspectWidth = 3;
            int hv_secondEdgeToEdgeDistance = 9;
            int hv_shiftEdge = 1;

            HObject ho_ImageOut;
            if (ckb_DefectV1.Checked == true)
            {
                HalconFunction.InspectWaferEdgeDefectAndDrawAi(ho_CropImage, ho_CropImage_AI,
                       out ho_ImageOut, hv_BevelWidth,
                         hv_DisplayDilation, hv_BevelDefectMaxGray, hv_AiDefectSize,
                         hv_AiMinGray, hv_InnerDefectAreaSize, hv_InnerDefectMaxGray, hv_BevelDefectAreaSize,
                         Convert.ToInt16(hv_PaintResult), Convert.ToInt16(hv_HaveSecondEdge), hv_LineBypassWidth,
                         hv_gamma, hv_findLineMask, hv_findLineLow, hv_findLineHigh, Convert.ToInt16(hv_onlyInspectEdge),
                         hv_lineScanPixelSize, hv_insideInspectWidth, hv_secondEdgeToEdgeDistance, hv_shiftEdge,
                       out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
                       out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber, out HTuple hv_Area);//V1

            }
            else
            {
                HalconFunction.InspectionDefect_V2(ho_CropImage, out HObject ho_DefectOut, out HObject ho_DefectDisplay,
                   out ho_ImageOut, hv_ROIColumn, hv_DarkLightThreshold,
                    hv_light_DarkThres, hv_DarkMax, hv_Dark_DarkThres, hv_Dark_LightThres,
                    hv_WhiteThres, hv_DisplayDilation, hv_MinAreaSize, hv_MinDefectSize,
                   out HTuple hv_DefectHeight, out HTuple hv_DefectWidth, out HTuple hv_DefectNumber,
                   out HTuple hv_DefectRows, out HTuple hv_DefectCols); ///V2
            }

            hctrl_DefectImg_1.ReadImage(ho_ImageOut);
            hctrl_DefectImg_1.ZoomToFit();
        }
        private void btn_CropInspectionImg_Click(object sender, EventArgs e)
        {
            IsDomainFirst = true;
            IsDefectFirstTest = false;
            if (IsCropOK != true)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_PixelSize = 7.04;//um
            double hv_CropSize = Convert.ToDouble(nud_CropSize_1.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_1.Value);
            int N = Convert.ToInt32(nud_SelectCropImg_1.Value);
            double hv_EdgePntRow = hv_EdgePntRows[N - 1];
            double hv_EdgePntCol = hv_EdgePntCols[N - 1];
            double hv_AI_OutDrawStartX = 166; //Ai開始判定的位置，目前沒用到
            HalconFunction.CropDomainImage(RawLineScanImage, out ho_CropImage, out ho_CropImage_AI,
                         hv_PixelSize, hv_CropSize, hv_InDistance, hv_EdgePntRow,
                         hv_EdgePntCol, hv_AI_OutDrawStartX);

            hctrl_DefectImg_1.ReadImage(ho_CropImage);
            hctrl_DefectImg_1.ZoomToFit();
            IsDefectFirstTest = true;
            if (nud_SelectCropImg_1.Value < nud_SelectCropImg_1.Maximum)
            {
                nud_SelectCropImg_1.Value += 1;
            }
        }

        private void hctrl_NotchImg_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Link;
            else e.Effect = DragDropEffects.None;
        }

        private void hctrl_NotchImg_DragDrop(object sender, DragEventArgs e)
        {
            //其中label1.Text顯示的就是拖進檔案的檔名； 
            string Path = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            string[] ImageData = Path.Split('.');
            int N = ImageData.Length;
            string filename = ImageData[N - 1];

            if (filename == "png" || filename == "bmp" || filename == "jpg" || filename == "jpeg" || filename == "gif" || filename == "tiff")
            {
                HOperatorSet.ReadImage(out ho_NotchImage, Path);
                hctrl_NotchImg_1.ReadImage(ho_NotchImage);
                hctrl_NotchImg_1.ResetAllHDispObject();
                hctrl_NotchImg_1.ZoomToFit();
            }
            else
            {
                MessageBox.Show("檔案錯誤，請輸入圖片檔");
                return;
            }
        }

        private void btn_loadModel_1_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "* |*.shm";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_model_1.Text = openFileDialog.FileName;
                if (txb_model_1.Text == "")
                    return;

                HOperatorSet.ReadShapeModel(txb_model_1.Text, out LineNotchModelID);
            }
        }
        //缺陷1
        HObject ho_NotchImage2;
        HObject RawImage2;
        HTuple ModelID2;
        HTuple hv_EdgePntRows2 = null, hv_EdgePntCols2;
        bool IsDefectFirstTest2 = false;
        HObject ho_CropImage2, ho_CropImage_AI2;
        bool IsCropOK2 = false;
        bool IsDomainFirst2 = false;
        private void btn_LoadImage_Defect_2_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_ImageRaw_2.Text = openFileDialog.FileName;
                if (txb_ImageRaw_2.Text == "")
                    return;
                HOperatorSet.ReadImage(out RawImage2, txb_ImageRaw_2.Text);
                hctrl_RawImage_2.ReadImage(RawImage2);
                hctrl_RawImage_2.ZoomToFit();
            }
        }

        private void btn_loadModel_2_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "* |*.shm";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txb_model_2.Text = openFileDialog.FileName;
                if (txb_model_2.Text == "")
                    return;

                HOperatorSet.ReadShapeModel(txb_model_2.Text, out ModelID2);

            }
        }

        /*private void btn_TestCropNotch_2_Click(object sender, EventArgs e)
        {
            IsCropOK2 = false;
            IsDomainFirst2 = false;
            IsDefectFirstTest2 = false;

            string ModelPath = txb_model_2.Text;
            string[] sArray = ModelPath.Split('.');

            if (txb_model_2.Text == "" || sArray[sArray.Length - 1] != "shm")
            {
                MessageBox.Show("Model檔案錯誤");
                return;
            }

            if (txb_ImageRaw_2.Text == "")
            {
                MessageBox.Show("請輸入影像");
                return;
            }

            double hv_CropNotchWidth = Convert.ToDouble(nud_CropNotchWidth_2.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_2.Value);
            double hv_PixelSize = Convert.ToDouble(nud_PixelSize_2.Value);
            double hv_CropSize = Convert.ToDouble(nud_CropSize_2.Value);
            double hv_MinScore = Convert.ToDouble(nud_MinScore_2.Value);
            HalconFunction.CalculateEdgePntAndCropNotch(RawImage2, out ho_NotchImage2,
                         ModelID2, hv_CropNotchWidth, hv_InDistance, hv_PixelSize,
                         hv_CropSize, hv_MinScore, out hv_EdgePntRows2, out hv_EdgePntCols2,
                        out HTuple hv_ErrMsg2, out HTuple hv_notch_location);

            if (hv_ErrMsg2.Length != 0)
            {
                MessageBox.Show(hv_ErrMsg2 + "請調整參數");
                return;
            }
            else
            {
                hctrl_NotchImg_2.ReadImage(ho_NotchImage2);
                hctrl_NotchImg_2.ZoomToFit();
                int number2 = hv_EdgePntRows2.Length;
                lab_dispNumber_2.Text = "全部共有 " + number2 + " 張";
                nud_SelectCropImg_2.Maximum = number2;
                IsCropOK2 = true;  //裁切成功
            }

        }*/

        private void ckb_DefectV2_CheckedChanged(object sender, EventArgs e)
        {
            if (ckb_DefectV2.Checked == true)
            { ckb_DefectV1.Checked = false; }
            else
            { ckb_DefectV1.Checked = true; }
            DefectParameter_Enable();

        }

        private void ckb_DefectV1_CheckedChanged(object sender, EventArgs e)
        {
            if (ckb_DefectV1.Checked == true)
            { ckb_DefectV2.Checked = false; }
            else
            { ckb_DefectV2.Checked = true; }
            DefectParameter_Enable();
        }

        private void ckb_DefectV2_2_CheckedChanged(object sender, EventArgs e)
        {
            if (ckb_DefectV2_2.Checked == true)
            { ckb_DefectV1_2.Checked = false; }
            else
            { ckb_DefectV1_2.Checked = true; }
            DefectParameter_Enable_2();
        }

        private void ckb_DefectV1_2_CheckedChanged(object sender, EventArgs e)
        {
            if (ckb_DefectV1_2.Checked == true)
            { ckb_DefectV2_2.Checked = false; }
            else
            { ckb_DefectV2_2.Checked = true; }
            DefectParameter_Enable_2();
        }

        void DefectParameter_Enable()
        {
            if (ckb_DefectV1.Checked == false)
            {   //V1
                nud_RoiWidthToBevelCenter_1.Enabled = false;
                nud_BevelWidth_1.Enabled = false;
                nud_InnerThresholdMax_1.Enabled = false;
                nud_AiDefectSize_1.Enabled = false;
                nud_AiMinGray_1.Enabled = false;
                nud_InnerDefectAreaSize_1.Enabled = false;
                nud_innerDefectMaxGray_1.Enabled = false;
                //V1 end

                //V2
                nud_ROIColumn.Enabled = true;
                nud_DarkLightThreshold.Enabled = true;
                nud_light_DarkThres.Enabled = true;
                nud_DarkMax.Enabled = true;
                nud_Dark_DarkThres.Enabled = true;
                nud_Dark_LightThres.Enabled = true;
                nud_WhiteThres.Enabled = true;
                nud_MinAreaSize.Enabled = true;
                nud_MinDefectSize.Enabled = true;
                //V2 end
            }
            else
            {   //V1
                nud_RoiWidthToBevelCenter_1.Enabled = true;
                nud_BevelWidth_1.Enabled = true;
                nud_InnerThresholdMax_1.Enabled = true;
                nud_AiDefectSize_1.Enabled = true;
                nud_AiMinGray_1.Enabled = true;
                nud_InnerDefectAreaSize_1.Enabled = true;
                nud_innerDefectMaxGray_1.Enabled = true;
                //V1 end

                //V2
                nud_ROIColumn.Enabled = false;
                nud_DarkLightThreshold.Enabled = false;
                nud_light_DarkThres.Enabled = false;
                nud_DarkMax.Enabled = false;
                nud_Dark_DarkThres.Enabled = false;
                nud_Dark_LightThres.Enabled = false;
                nud_WhiteThres.Enabled = false;
                nud_MinAreaSize.Enabled = false;
                nud_MinDefectSize.Enabled = false;
                //V2 end

            }
        }

        void DefectParameter_Enable_2()
        {
            if (ckb_DefectV1_2.Checked == false)
            {   //V1
                nud_RoiWidthToBevelCenter_2.Enabled = false;
                nud_BevelWidth_2.Enabled = false;
                nud_InnerThresholdMax_2.Enabled = false;
                nud_AiDefectSize_2.Enabled = false;
                nud_AiMinGray_2.Enabled = false;
                nud_InnerDefectAreaSize_2.Enabled = false;
                nud_innerDefectMaxGray_2.Enabled = false;
                //V1 end

                //V2
                nud_ROIColumn_2.Enabled = true;
                nud_DarkLightThreshold_2.Enabled = true;
                nud_light_DarkThres_2.Enabled = true;
                nud_DarkMax_2.Enabled = true;
                nud_Dark_DarkThres_2.Enabled = true;
                nud_Dark_LightThres_2.Enabled = true;
                nud_WhiteThres_2.Enabled = true;
                nud_MinAreaSize_2.Enabled = true;
                nud_MinDefectSize_2.Enabled = true;

                //V2 end
            }
            else
            {   //V1
                nud_RoiWidthToBevelCenter_2.Enabled = true;
                nud_BevelWidth_2.Enabled = true;
                nud_InnerThresholdMax_2.Enabled = true;
                nud_AiDefectSize_2.Enabled = true;
                nud_AiMinGray_2.Enabled = true;
                nud_InnerDefectAreaSize_2.Enabled = true;
                nud_innerDefectMaxGray_2.Enabled = true;
                //V1 end

                //V2
                nud_ROIColumn_2.Enabled = false;
                nud_DarkLightThreshold_2.Enabled = false;
                nud_light_DarkThres_2.Enabled = false;
                nud_DarkMax_2.Enabled = false;
                nud_Dark_DarkThres_2.Enabled = false;
                nud_Dark_LightThres_2.Enabled = false;
                nud_WhiteThres_2.Enabled = false;
                nud_MinAreaSize_2.Enabled = false;
                nud_MinDefectSize_2.Enabled = false;
                //V2 end

            }
        }

        private void btn_TestDefectBatch_1_Click(object sender, EventArgs e)
        {

        }

        private void btn_MasureTest_Edge_Autoselect_Click(object sender, EventArgs e)
        {

            salmonAlgorithm.LoadConfig(txb_recipePath.Text);

            string[] imageFileNames = System.IO.Directory.GetFiles(txb_EdgeImgFolder.Text);
            HObject[] images = new HObject[imageFileNames.Length];

            for (int i = 0; i < imageFileNames.Length; i++)
            {
                HOperatorSet.ReadImage(out images[i], imageFileNames[i]);
            }

            int notchLocY = 87000;
            List<EdgeMeasureResult> resultList = new List<EdgeMeasureResult>();
            EdgeMeasureResultData stdResult = new EdgeMeasureResultData();
            EdgeMeasureResultData avgResult = new EdgeMeasureResultData();
            EdgeMeasureResultData ppResult = new EdgeMeasureResultData();
            bool state = salmonAlgorithm.DoEdgeMeasure(images, notchLocY, ref resultList, ref stdResult, ref avgResult, ref ppResult);

            MessageBox.Show("標準差統計結果 : \n" +
                            "A1 : " + stdResult.A1.ToString() + "\n" +
                            "A2 : " + stdResult.A2.ToString() + "\n" +
                            "B1 : " + stdResult.B1.ToString() + "\n" +
                            "B2 : " + stdResult.B2.ToString() + "\n" +
                            "BC : " + stdResult.BC.ToString() + "\n" +
                            "C1 : " + stdResult.C1.ToString() + "\n" +
                            "C2 : " + stdResult.C2.ToString() + "\n" +
                            "R1 : " + stdResult.R1.ToString() + "\n" +
                            "R2 : " + stdResult.R2.ToString() + "\n" +
                            "t : " + stdResult.t.ToString() + "\n" +
                            "Ang1 : " + stdResult.Ang1.ToString() + "\n" +
                            "Ang2 : " + stdResult.Ang2.ToString() + "\n");

            MessageBox.Show("平均統計結果 : \n" +
                            "A1 : " + avgResult.A1.ToString() + "\n" +
                            "A2 : " + avgResult.A2.ToString() + "\n" +
                            "B1 : " + avgResult.B1.ToString() + "\n" +
                            "B2 : " + avgResult.B2.ToString() + "\n" +
                            "BC : " + avgResult.BC.ToString() + "\n" +
                            "C1 : " + avgResult.C1.ToString() + "\n" +
                            "C2 : " + avgResult.C2.ToString() + "\n" +
                            "R1 : " + avgResult.R1.ToString() + "\n" +
                            "R2 : " + avgResult.R2.ToString() + "\n" +
                            "t : " + avgResult.t.ToString() + "\n" +
                            "Ang1 : " + avgResult.Ang1.ToString() + "\n" +
                            "Ang2 : " + avgResult.Ang2.ToString() + "\n");

            MessageBox.Show("峰對峰值統計結果 : \n" +
                            "A1 : " + ppResult.A1.ToString() + "\n" +
                            "A2 : " + ppResult.A2.ToString() + "\n" +
                            "B1 : " + ppResult.B1.ToString() + "\n" +
                            "B2 : " + ppResult.B2.ToString() + "\n" +
                            "BC : " + ppResult.BC.ToString() + "\n" +
                            "C1 : " + ppResult.C1.ToString() + "\n" +
                            "C2 : " + ppResult.C2.ToString() + "\n" +
                            "R1 : " + ppResult.R1.ToString() + "\n" +
                            "R2 : " + ppResult.R2.ToString() + "\n" +
                            "t : " + ppResult.t.ToString() + "\n" +
                            "Ang1 : " + ppResult.Ang1.ToString() + "\n" +
                            "Ang2 : " + ppResult.Ang2.ToString() + "\n");

            hctrl_EdgeView.ReadImage(resultList[0].ResultImage);
            hctrl_EdgeView.ZoomToFit();
        }

        private void btn_LoadFolder_Edge_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "請選擇資料夾";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filepath = dialog.SelectedPath;
                txb_EdgeImgFolder.Text = filepath;
            }
        }

        private void btn_SaveRecipe_Edge_Click(object sender, EventArgs e)
        {

        }

        private void btn_CropInspectionImg_2_Click(object sender, EventArgs e)
        {
            IsDomainFirst2 = true;
            IsDefectFirstTest2 = false;
            if (IsCropOK2 != true)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_PixelSize = 7.04;//um
            double hv_CropSize = Convert.ToDouble(nud_CropSize_2.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_2.Value);
            int N = Convert.ToInt32(nud_SelectCropImg_2.Value);
            double hv_EdgePntRow = hv_EdgePntRows2[N - 1];
            double hv_EdgePntCol = hv_EdgePntCols2[N - 1];
            double hv_AI_OutDrawStartX = 166; //Ai開始判定的位置，目前沒用到
            HalconFunction.CropDomainImage(RawImage2, out ho_CropImage2, out ho_CropImage_AI2,
                         hv_PixelSize, hv_CropSize, hv_InDistance, hv_EdgePntRow,
                         hv_EdgePntCol, hv_AI_OutDrawStartX);

            hctrl_DefectImg_2.ReadImage(ho_CropImage2);
            hctrl_DefectImg_2.ZoomToFit();
            IsDefectFirstTest2 = true;
            if (nud_SelectCropImg_2.Value + 1 < nud_SelectCropImg_2.Maximum)
                nud_SelectCropImg_2.Value += 1;
        }

        private void btn_TestDefect_2_Click(object sender, EventArgs e)
        {
            if (IsDefectFirstTest2 != false)
            {
                btn_CropInspectionImg_2_Click(sender, e);
            }
            else
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            IsDefectFirstTest2 = true;

            double hv_RoiWidthToBevelCenter = Convert.ToDouble(nud_RoiWidthToBevelCenter_2.Value);
            double hv_BevelWidth = Convert.ToDouble(nud_BevelWidth_2.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_2.Value);
            double hv_AiDefectSize = Convert.ToDouble(nud_AiDefectSize_2.Value);
            double hv_AiMinGray = Convert.ToDouble(nud_AiMinGray_2.Value);
            double hv_InnerDefectAreaSize = Convert.ToDouble(nud_InnerDefectAreaSize_2.Value);
            double hv_InnerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_2.Value);
            double hv_EdgeDefectAreaSize = Convert.ToDouble(nud_edgeDefectMaxGray_2.Value);

            double hv_ROIColumn_2 = Convert.ToDouble(nud_ROIColumn_2.Value);//370;     //檢查roi範圍
            double hv_DarkLightThreshold_2 = Convert.ToDouble(nud_DarkLightThreshold_2.Value);// 150;  //DarkLightThreshold
            double hv_light_DarkThres_2 = Convert.ToDouble(nud_light_DarkThres_2.Value);// 45;
            double hv_DarkMax_2 = Convert.ToDouble(nud_DarkMax_2.Value);//50;
            double hv_Dark_DarkThres_2 = Convert.ToDouble(nud_Dark_DarkThres_2.Value);//35;
            double hv_Dark_LightThres_2 = Convert.ToDouble(nud_Dark_LightThres_2.Value);// 60;
            double hv_WhiteThres_2 = Convert.ToDouble(nud_WhiteThres_2.Value);// 20;
            double hv_MinAreaSize_2 = Convert.ToDouble(nud_MinAreaSize_2.Value);// 20;
            double hv_MinDefectSize_2 = Convert.ToDouble(nud_MinDefectSize_2.Value);//1;
            double hv_LineBypassWidth = 2;
            bool hv_PaintResult = true;
            bool hv_OnlyDetectEdge = true;
            double hv_gamma = 1.5;
            int hv_findLineMask = 5;
            double hv_findLineLow = 3;
            double hv_findLineHigh = 8;
            bool hv_onlyInspectEdge = false;
            double hv_lineScanPixelSize = 7.04;
            double hv_insideInspectWidth = 3;
            int hv_secondEdgeToEdgeDistance = 9;
            int hv_shiftEdge = 1;

            HObject ho_ImageOut2;
            if (ckb_DefectV1.Checked == true)
            {
                HalconFunction.InspectWaferEdgeDefectAndDrawAi(ho_CropImage2, ho_CropImage_AI2,
                        out ho_ImageOut2, hv_BevelWidth,
                          hv_DisplayDilation, hv_DisplayDilation, hv_AiDefectSize,
                          hv_AiMinGray, hv_InnerDefectAreaSize, hv_InnerDefectMaxGray, hv_EdgeDefectAreaSize,
                          Convert.ToInt16(hv_PaintResult), Convert.ToInt16(hv_OnlyDetectEdge), hv_LineBypassWidth,
                          hv_gamma, hv_findLineMask, hv_findLineLow, hv_findLineHigh, Convert.ToInt16(hv_onlyInspectEdge),
                        hv_lineScanPixelSize, hv_insideInspectWidth, hv_secondEdgeToEdgeDistance, hv_shiftEdge,
                        out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
                        out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber, out HTuple hv_Area);
            }
            else
            {
                HalconFunction.InspectionDefect_V2(ho_CropImage2, out HObject ho_DefectOut, out HObject ho_DefectDisplay,
                   out ho_ImageOut2, hv_ROIColumn_2, hv_DarkLightThreshold_2,
                    hv_light_DarkThres_2, hv_DarkMax_2, hv_Dark_DarkThres_2, hv_Dark_LightThres_2,
                    hv_WhiteThres_2, hv_DisplayDilation, hv_MinAreaSize_2, hv_MinDefectSize_2,
                   out HTuple hv_DefectHeight, out HTuple hv_DefectWidth, out HTuple hv_DefectNumber,
                   out HTuple hv_DefectRows, out HTuple hv_DefectCols); ///V2

            }
            hctrl_DefectImg_2.ReadImage(ho_ImageOut2);
            hctrl_DefectImg_2.ZoomToFit();
        }

        private void btn_TestNotchDefect_2_Click(object sender, EventArgs e)
        {
            if (IsCropOK2 == false)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_BackWhiteMinGray = Convert.ToDouble(nud_BackWhiteMinGray_2.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_2.Value);
            double hv_innerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_Notch_2.Value);
            double hv_NotchVwRow1 = Convert.ToDouble(nud_NotchVwRow1_2.Value);
            double hv_NotchVwRow2 = Convert.ToDouble(nud_NotchVwRow2_2.Value);
            double hv_NotchBlackWidth = Convert.ToDouble(nud_NotchBlackWidth_2.Value);
            double hv_InnerDefectMinWidth = Convert.ToDouble(nud_InnerDefectMinWidth_2.Value);
            double hv_OutDefectMinWidth = Convert.ToDouble(nud_OutDefectMinWidth_2.Value);

            HalconFunction.InspectNotchDefect_v2(ho_NotchImage2, out HObject ho_ImageOut2, out HObject ho_ImageOut_Teach2,
          out HObject ho_Teach_Contour2, hv_BackWhiteMinGray, hv_DisplayDilation,
           hv_innerDefectMaxGray, hv_NotchVwRow1, hv_NotchVwRow2,
           hv_NotchBlackWidth, hv_InnerDefectMinWidth, hv_OutDefectMinWidth,
          out HTuple hv_DefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1, out HTuple hv_DefectRow2, out HTuple hv_DefectCol2);
            hctrl_NotchImg_2.ReadImage(ho_ImageOut2);
            hctrl_NotchImg_2.ResetAllHXLDInfo();
            hctrl_NotchImg_2.AddHXLD(HColorMode.green, ho_Teach_Contour2);
            //hCtrl_Model.ZoomToFit();
            hctrl_NotchImg_2.ZoomToFit();
        }

        private void btn_TestNotchDefect_Click(object sender, EventArgs e)
        {
            if (IsCropOK == false)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_BackWhiteMinGray = Convert.ToDouble(nud_BackWhiteMinGray_1.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_1.Value);
            double hv_innerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_Notch_1.Value);
            double hv_NotchVwRow1 = Convert.ToDouble(nud_NotchVwRow1_1.Value);
            double hv_NotchVwRow2 = Convert.ToDouble(nud_NotchVwRow2_1.Value);
            double hv_NotchBlackWidth = Convert.ToDouble(nud_NotchBlackWidth_1.Value);
            double hv_InnerDefectMinWidth = Convert.ToDouble(nud_InnerDefectMinWidth_1.Value);
            double hv_OutDefectMinWidth = Convert.ToDouble(nud_OutDefectMinWidth_1.Value);

            HalconFunction.InspectNotchDefect_v2(ho_NotchImage, out HObject ho_ImageOut, out HObject ho_ImageOut_Teach,
          out HObject ho_Teach_Contour, hv_BackWhiteMinGray, hv_DisplayDilation,
           hv_innerDefectMaxGray, hv_NotchVwRow1, hv_NotchVwRow2,
           hv_NotchBlackWidth, hv_InnerDefectMinWidth, hv_OutDefectMinWidth,
          out HTuple hv_DefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1, out HTuple hv_DefectRow2, out HTuple hv_DefectCol2);
            hctrl_NotchImg_1.ReadImage(ho_ImageOut);
            hctrl_NotchImg_1.ResetAllHXLDInfo();
            hctrl_NotchImg_1.AddHXLD(HColorMode.green, ho_Teach_Contour);
            //hCtrl_Model.ZoomToFit();
            hctrl_NotchImg_1.ZoomToFit();
        }
        #endregion

        #region Initial

        HObject[] LineScanSrcImageTopArr;
        HObject[] LineScanSrcImageBottomArr;
        HObject LineScanAlignImageTop;
        HObject LineScanAlignImageBottom;
        HObject[] NotchAreaImageArr;
        HObject NotchLineScanImage;
        HObject[] EdgeImagesArr = new HObject[0];
        int NotchLocation = 0;
        HTuple EdgePntRows = null;
        HTuple EdgePntCols = null;
        List<EdgeMeasureResult> EdgeMeasureResultList = new List<EdgeMeasureResult>();
        NotchMeasureResult NotchMeasureResult = new NotchMeasureResult();
        List<InspectDefect> TotalDefectListTop = new List<InspectDefect>();
        List<InspectDefect> TotalDefectListBtm = new List<InspectDefect>();

        private void btn_setRecipe_Click(object sender, EventArgs e)
        {

            FormBootConfig frm = new FormBootConfig();
            frm.SetConfig(ConfigPath);
            frm.ShowDialog(this);
            try
            {
                salmonAlgorithm.LoadConfig(ConfigPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region DoAlignment
        private void btn_DefectInspectionTOPLoadImage_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                HObject[] selcetImages = new HObject[openFileDialog.FileNames.Length];
                for (int i = 0; i < openFileDialog.FileNames.Length; i++)
                {
                    HOperatorSet.ReadImage(out HObject tempImage, openFileDialog.FileNames[i]);
                    selcetImages[i] = tempImage;
                }
                LineScanSrcImageTopArr = selcetImages;
            }
        }

        private void btn_DefectInspectionBottomLoadImage_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                HObject[] selcetImages = new HObject[openFileDialog.FileNames.Length];
                for (int i = 0; i < openFileDialog.FileNames.Length; i++)
                {
                    HOperatorSet.ReadImage(out HObject tempImage, openFileDialog.FileNames[i]);
                    selcetImages[i] = tempImage;
                }
                LineScanSrcImageBottomArr = selcetImages;
            }
        }

        private void btn_DefectInspectionTOPAlign_Click(object sender, EventArgs e)
        {
            try
            {
                if (salmonAlgorithm.DoAlignment(LineScanSrcImageTopArr, ref LineScanAlignImageTop, ref NotchLineScanImage, ref NotchLocation, ref EdgePntRows, ref EdgePntCols))
                {
                    hControl_linescanTop.ReadImage(LineScanAlignImageTop);
                    hControl_linescanTop.ZoomToFit();
                    hControl_NotchInspect.ReadImage(NotchLineScanImage);
                    hControl_NotchInspect.ZoomToFit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
        }

        private void btn_DefectInspectionBottomAlign_Click(object sender, EventArgs e)
        {
            try
            {
                if (salmonAlgorithm.DoAlignment(LineScanSrcImageBottomArr, ref LineScanAlignImageBottom, ref NotchLineScanImage, ref NotchLocation, ref EdgePntRows, ref EdgePntCols))
                {
                    hControl_linescanBottom.ReadImage(LineScanAlignImageBottom);
                    hControl_linescanBottom.ZoomToFit();
                    hControl_NotchInspect.ReadImage(NotchLineScanImage);
                    hControl_NotchInspect.ZoomToFit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
        }
        #endregion

        #region DoDefectInspect
        private void btn_DefectInspectionTOPRun_Click(object sender, EventArgs e)
        {
            HObject resultImage = new HObject();
            TotalDefectListTop.Clear();
            try
            {
                if (salmonAlgorithm.DoDefectInspectTop(LineScanAlignImageTop, EdgePntRows, EdgePntCols, ref resultImage, ref TotalDefectListTop))
                {
                    if (resultImage != null)
                    {
                        hControl_linescanTop.ReadImage(resultImage);
                        hControl_linescanTop.ZoomToFit();
                    }
                    nud_topDefectNum.Value = TotalDefectListTop.Count;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
            finally
            {
                resultImage.Dispose();
                TotalDefectListTop.ForEach(x=>x.Dispose());
                TotalDefectListTop.Clear();
            }
        }

        private void btn_DefectInspectionBottomRun_Click(object sender, EventArgs e)
        {
            HObject resultImage = new HObject();
            TotalDefectListBtm.Clear();
            try
            {
                if (salmonAlgorithm.DoDefectInspectBottom(LineScanAlignImageBottom, EdgePntRows, EdgePntCols, ref resultImage, ref TotalDefectListBtm))
                {
                    if (resultImage != null)
                    {
                        hControl_linescanBottom.ReadImage(resultImage);
                        hControl_linescanBottom.ZoomToFit();
                    }
                    nud_btmDefectNum.Value = TotalDefectListBtm.Count;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
            finally
            {
                resultImage.Dispose();
                TotalDefectListBtm.ForEach(x => x.Dispose());
                TotalDefectListBtm.Clear();
            }
        }

        private void btn_defectInspectTopSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "BMP|*.bmp";
            sfd.DefaultExt = ".bmp";
            sfd.AddExtension = true;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;
                hControl_linescanTop.SaveImage(path);
            }
        }

        private void btn_defectInspectBottomSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "BMP|*.bmp";
            sfd.DefaultExt = ".bmp";
            sfd.AddExtension = true;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;
                hControl_linescanBottom.SaveImage(path);
            }
        }
        #endregion

        #region DoNotchInspect
        private void btn_NotchInspectLoadImage_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                HOperatorSet.ReadImage(out NotchLineScanImage, openFileDialog.FileName);
                hControl_NotchInspect.ReadImage(NotchLineScanImage);
                hControl_NotchInspect.ZoomToFit();
            }
        }

        private void btn_NotchInspectRun_Click(object sender, EventArgs e)
        {
            HObject resultImage = new HObject();
            List<Rectangle> defects = new List<Rectangle>();
            try
            {
                if (salmonAlgorithm.DoNotchInspect(NotchLineScanImage, ref resultImage, ref defects))
                {
                    hControl_NotchInspect.ReadImage(resultImage);
                    hControl_NotchInspect.ZoomToFit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
            finally
            {
                resultImage.Dispose();
                defects.Clear();
            }
        }

        private void btn_notchResultSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "BMP|*.bmp";
            sfd.DefaultExt = ".bmp";
            sfd.AddExtension = true;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;
                hControl_NotchInspect.SaveImage(path);
            }
        }
        #endregion

        #region DoDiameter
        private void btn_DiameterMeasurementRun_Click(object sender, EventArgs e)
        {
            try
            {
                double diameterT = -1;
                double diameterB = -1;

                if (salmonAlgorithm.DoDiameterMeasure(LineScanAlignImageTop, ref diameterT))
                {
                    nud_DiameterT.Value = Convert.ToDecimal(diameterT);
                }
                if (salmonAlgorithm.DoDiameterMeasure(LineScanAlignImageBottom, ref diameterB))
                {
                    nud_DiameterB.Value = Convert.ToDecimal(diameterB);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
        }
        #endregion

        #region DoNotchMeasurement
        private void btn_NotchMeasurementLoadImage_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                HObject[] selcetImages = new HObject[openFileDialog.FileNames.Length];
                for (int i = 0; i < openFileDialog.FileNames.Length; i++)
                {
                    HOperatorSet.ReadImage(out HObject tempImage, openFileDialog.FileNames[i]);
                    selcetImages[i] = tempImage;
                }
                NotchAreaImageArr = selcetImages;

                //show first image
                hControl_NotchMeasurement.ReadImage(selcetImages[0]);
                hControl_NotchMeasurement.ZoomToFit();
            }
        }

        private void btn_NotchMeasurementRun_Click(object sender, EventArgs e)
        {
            HObject resultImage = new HObject();
            try
            {
                if (salmonAlgorithm.DoNotchMeasure(NotchAreaImageArr, ref resultImage, ref NotchMeasureResult))
                {
                    hControl_NotchMeasurement.ReadImage(resultImage);
                    hControl_NotchMeasurement.ZoomToFit();

                    //show result
                    nud_Vh.Value = Convert.ToDecimal(NotchMeasureResult.Vh);
                    nud_Vw.Value = Convert.ToDecimal(NotchMeasureResult.Vw);
                    nud_Vr.Value = Convert.ToDecimal(NotchMeasureResult.Vr);
                    nud_AngV.Value = Convert.ToDecimal(NotchMeasureResult.AngV);
                    nud_P1.Value = Convert.ToDecimal(NotchMeasureResult.P1);
                    nud_P2.Value = Convert.ToDecimal(NotchMeasureResult.P2);
                    nud_Vr1.Value = Convert.ToDecimal(NotchMeasureResult.Vr1);
                    nud_Vr2.Value = Convert.ToDecimal(NotchMeasureResult.Vr2);
                }
                else
                {
                    MessageBox.Show("Notch Measurement Fail ! Doesn't have any result !");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
            }
            finally
            {
                resultImage.Dispose();
                NotchMeasureResult.Dispose();
            }
        }

        private void btn_notchMeasureSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "BMP|*.bmp";
            sfd.DefaultExt = ".bmp";
            sfd.AddExtension = true;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = sfd.FileName;
                hControl_NotchMeasurement.SaveImage(path);
            }
        }
        #endregion

        #region DoEdgeMeasurement
        private void btn_EdgeMeasurementLoadImage_Click(object sender, EventArgs e)
        {
            HObject tempImage = new HObject();
            try
            {
                openFileDialog.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";
                openFileDialog.Multiselect = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    EdgeImagesArr = new HObject[openFileDialog.FileNames.Length];
                    for (int i = 0; i < openFileDialog.FileNames.Length; i++)
                    {
                        HOperatorSet.ReadImage(out tempImage, openFileDialog.FileNames[i]);
                        EdgeImagesArr[i] = new HObject(tempImage);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                tempImage.Dispose();
            }
        }

        private void btn_CheckGrinding_Click(object sender, EventArgs e)
        {
            HObject ResultImage = new HObject();
            bool Grinding = false;
            try
            {
                //get current Edge Image
                int index = Convert.ToInt16(nud_edgeIndex.Value);
                EdgeMeasureResult result = EdgeMeasureResultList[index];
                if (salmonAlgorithm.DoCheckGrinding(result.SourceImage, ref ResultImage, ref Grinding))
                {
                    //show image
                    hControl_EdgeMeasurement.ReadImage(ResultImage);
                    hControl_EdgeMeasurement.ZoomToFit();
                    nud_edgeIndex.BackColor = Grinding ? Color.LimeGreen : Color.Red;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                ResultImage.Dispose();
            }


        }

        private void btn_EdgeMeasurementRun_Click(object sender, EventArgs e)
        {
            EdgeMeasureResultData stdResultData = new EdgeMeasureResultData();
            EdgeMeasureResultData avgResultData = new EdgeMeasureResultData();
            EdgeMeasureResultData ppResultData = new EdgeMeasureResultData();
            EdgeMeasureResultList.ForEach(x => x.Dispose());
            EdgeMeasureResultList.Clear();

            try
            {
                if (salmonAlgorithm.DoEdgeMeasure(EdgeImagesArr, NotchLocation, ref EdgeMeasureResultList,
                    ref stdResultData, ref avgResultData, ref ppResultData))
                {
                    nud_edgeIndex.Maximum = EdgeMeasureResultList.Count();

                    //show first result
                    nud_edgeIndex.Value = 1;
                    nud_edgeAngle.Value = Convert.ToDecimal(EdgeMeasureResultList[0].Angle);
                    nud_A1.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.A1);
                    nud_A2.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.A2);
                    nud_B1.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.B1);
                    nud_B2.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.B2);
                    nud_BC.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.BC);
                    nud_C1.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.C1);
                    nud_C2.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.C2);
                    nud_R1.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.R1);
                    nud_R2.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.R2);
                    nud_t.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.t);
                    nud_Ang1.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.Ang1);
                    nud_Ang2.Value = Convert.ToDecimal(EdgeMeasureResultList[0].ResultData.Ang2);

                    //show image
                    hControl_EdgeMeasurement.ReadImage(EdgeMeasureResultList[0].ResultImage);
                    hControl_EdgeMeasurement.ZoomToFit();
                    /*
                    //show STD result
                    MessageBox.Show("標準差統計結果 : \n" +
                        "A1 : " + stdResultData.A1.ToString() + "\n" +
                        "A2 : " + stdResultData.A2.ToString() + "\n" +
                        "B1 : " + stdResultData.B1.ToString() + "\n" +
                        "B2 : " + stdResultData.B2.ToString() + "\n" +
                        "BC : " + stdResultData.BC.ToString() + "\n" +
                        "C1 : " + stdResultData.C1.ToString() + "\n" +
                        "C2 : " + stdResultData.C2.ToString() + "\n" +
                        "R1 : " + stdResultData.R1.ToString() + "\n" +
                        "R2 : " + stdResultData.R2.ToString() + "\n" +
                        "t : " + stdResultData.t.ToString() + "\n" +
                        "Ang1 : " + stdResultData.Ang1.ToString() + "\n" +
                        "Ang2 : " + stdResultData.Ang2.ToString() + "\n");

                    //show AVG result
                    MessageBox.Show("平均統計結果 : \n" +
                        "A1 : " + avgResultData.A1.ToString() + "\n" +
                        "A2 : " + avgResultData.A2.ToString() + "\n" +
                        "B1 : " + avgResultData.B1.ToString() + "\n" +
                        "B2 : " + avgResultData.B2.ToString() + "\n" +
                        "BC : " + avgResultData.BC.ToString() + "\n" +
                        "C1 : " + avgResultData.C1.ToString() + "\n" +
                        "C2 : " + avgResultData.C2.ToString() + "\n" +
                        "R1 : " + avgResultData.R1.ToString() + "\n" +
                        "R2 : " + avgResultData.R2.ToString() + "\n" +
                        "t : " + avgResultData.t.ToString() + "\n" +
                        "Ang1 : " + avgResultData.Ang1.ToString() + "\n" +
                        "Ang2 : " + avgResultData.Ang2.ToString() + "\n");

                    //show PP result
                    MessageBox.Show("峰對峰值統計結果 : \n" +
                        "A1 : " + ppResultData.A1.ToString() + "\n" +
                        "A2 : " + ppResultData.A2.ToString() + "\n" +
                        "B1 : " + ppResultData.B1.ToString() + "\n" +
                        "B2 : " + ppResultData.B2.ToString() + "\n" +
                        "BC : " + ppResultData.BC.ToString() + "\n" +
                        "C1 : " + ppResultData.C1.ToString() + "\n" +
                        "C2 : " + ppResultData.C2.ToString() + "\n" +
                        "R1 : " + ppResultData.R1.ToString() + "\n" +
                        "R2 : " + ppResultData.R2.ToString() + "\n" +
                        "t : " + ppResultData.t.ToString() + "\n" +
                        "Ang1 : " + ppResultData.Ang1.ToString() + "\n" +
                        "Ang2 : " + ppResultData.Ang2.ToString() + "\n");
                    */
                }
            }
            catch (Exception ex)
            {
                if(ex.InnerException!=null)
                MessageBox.Show(ex.Message + " : " + ex.InnerException.Message);
                else
                    MessageBox.Show(ex.Message);

            }
            finally
            {
                //SideMeasureResultList.Clear();
            }
        }

        private void btn_edgeNumberBack_Click(object sender, EventArgs e)
        {
            if (nud_edgeIndex.Value - 1 >= 0)
            {
                nud_edgeIndex.Value--;
                ChangeIndex();
            }
        }

        private void btn_edgeNumberNext_Click(object sender, EventArgs e)
        {
            if (nud_edgeIndex.Value + 1 < nud_edgeIndex.Maximum)
            {
                nud_edgeIndex.Value++;
                ChangeIndex();
            }
        }

        private void ChangeIndex()
        {
            //now
            int index = Convert.ToInt16(nud_edgeIndex.Value);
            //show next
            EdgeMeasureResult result = EdgeMeasureResultList[index];
            nud_edgeIndex.BackColor = result.ProcessStatus ? Color.LimeGreen : Color.Red;
            nud_edgeIndex.TextAlign = HorizontalAlignment.Center;
            if (result.ProcessStatus)
            {
                nud_edgeAngle.Value = Convert.ToDecimal(result.Angle);
                nud_A1.Value = Convert.ToDecimal(result.ResultData.A1);
                nud_A2.Value = Convert.ToDecimal(result.ResultData.A2);
                nud_B1.Value = Convert.ToDecimal(result.ResultData.B1);
                nud_B2.Value = Convert.ToDecimal(result.ResultData.B2);
                nud_BC.Value = Convert.ToDecimal(result.ResultData.BC);
                nud_C1.Value = Convert.ToDecimal(result.ResultData.C1);
                nud_C2.Value = Convert.ToDecimal(result.ResultData.C2);
                nud_R1.Value = Convert.ToDecimal(result.ResultData.R1);
                nud_R2.Value = Convert.ToDecimal(result.ResultData.R2);
                nud_t.Value = Convert.ToDecimal(result.ResultData.t);
                nud_Ang1.Value = Convert.ToDecimal(result.ResultData.Ang1);
                nud_Ang2.Value = Convert.ToDecimal(result.ResultData.Ang2);
            }
            else
            {
                nud_A1.Value = -1;
                nud_A2.Value = -1;
                nud_B1.Value = -1;
                nud_B2.Value = -1;
                nud_BC.Value = -1;
                nud_C1.Value = -1;
                nud_C2.Value = -1;
                nud_R1.Value = -1;
                nud_R2.Value = -1;
                nud_t.Value = -1;
                nud_Ang1.Value = -1;
                nud_Ang2.Value = -1;
            }
            nud_edgeAngle.Value = Convert.ToDecimal(result.Angle);


            //show image
            hControl_EdgeMeasurement.ReadImage(result.ResultImage);
            hControl_EdgeMeasurement.ZoomToFit();
        }
        #endregion

        #region Batch Run
        string Mainpath;
        private void bnt_loadBatchData_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.Description = "Please select folder.";
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                Mainpath = folderBrowserDialog.SelectedPath;
            }
        }

        private void load_image(string path)
        {
            HObject tempImage = new HObject();
            try
            {
                //Initial
                DisposeHObjectArray(LineScanSrcImageTopArr);
                DisposeHObjectArray(LineScanSrcImageBottomArr);
                DisposeHObjectArray(EdgeImagesArr);
                DisposeHObjectArray(NotchAreaImageArr);
                LineScanAlignImageTop?.Dispose();
                LineScanAlignImageBottom?.Dispose();
                NotchLineScanImage?.Dispose();
                EdgePntRows?.Dispose();
                EdgePntCols?.Dispose();
                EdgeMeasureResultList.ForEach(x => { x.Dispose(); });
                EdgeMeasureResultList.Clear();
                TotalDefectListTop?.Clear();
                TotalDefectListBtm?.Clear();
                NotchMeasureResult?.Dispose();


                //load Top
                string topPath = Mainpath + "//Source_CameraDiameterTop//";
                if (Directory.Exists(topPath))
                {
                    string[] files = Directory.GetFiles(topPath);
                    LineScanSrcImageTopArr = new HObject[files.Length];
                    for (int i = 0; i < files.Length; i++)
                    {
                        HOperatorSet.ReadImage(out tempImage, files[i]);
                        LineScanSrcImageTopArr[i] = new HObject(tempImage);
                    }
                }
                else
                {
                    throw new Exception("[Load Batch Data Fail] " + topPath + "  not found !");
                }

                //load Bottom
                string btmPath = Mainpath + "//Source_CameraDiameterBtm//";
                if (Directory.Exists(btmPath))
                {
                    string[] files = Directory.GetFiles(btmPath);
                    LineScanSrcImageBottomArr = new HObject[files.Length];
                    for (int i = 0; i < files.Length; i++)
                    {
                        HOperatorSet.ReadImage(out tempImage, files[i]);
                        LineScanSrcImageBottomArr[i] = new HObject(tempImage);
                    }
                }
                else
                {
                    throw new Exception("[Load Batch Data Fail] " + btmPath + "  not found !");
                }

                //load Edge
                string edgePath = Mainpath + "//Source_CameraEdge//";
                if (Directory.Exists(edgePath))
                {
                    string[] files = Directory.GetFiles(edgePath);
                    EdgeImagesArr = new HObject[files.Length];
                    for (int i = 0; i < files.Length; i++)
                    {
                        HOperatorSet.ReadImage(out tempImage, files[i]);
                        EdgeImagesArr[i] = new HObject(tempImage);
                    }
                }
                else
                {
                    throw new Exception("[Load Batch Data Fail] " + edgePath + "  not found !");
                }

                //load notch
                string notchPath = Mainpath + "//Source_CameraNotch//";
                if (Directory.Exists(notchPath))
                {
                    string[] files = Directory.GetFiles(notchPath);
                    NotchAreaImageArr = new HObject[files.Length];
                    for (int i = 0; i < files.Length; i++)
                    {
                        HOperatorSet.ReadImage(out tempImage, files[i]);
                        NotchAreaImageArr[i] = new HObject(tempImage);
                    }

                    //show first image
                    hControl_NotchMeasurement.ReadImage(NotchAreaImageArr[0]);
                    hControl_NotchMeasurement.ZoomToFit();
                }
                else
                {
                    throw new Exception("[Load Batch Data Fail] " + notchPath + "  not found !");
                }
            }
            catch { }
            finally
            {
                tempImage.Dispose();
            }
        }

        private void btn_batchRun_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();

            try
            {
                stopwatch.Start();
                for (int i = 0; i < nud_batchRunTime.Value; i++)
                {
                    load_image(Mainpath);
                    btn_DefectInspectionTOPAlign.PerformClick();
                    btn_DefectInspectionTOPRun.PerformClick();
                    btn_DefectInspectionBottomAlign.PerformClick();
                    btn_DefectInspectionBottomRun.PerformClick();
                    btn_EdgeMeasurementRun.PerformClick();
                    btn_NotchMeasurementRun.PerformClick();
                    btn_DiameterMeasurementRun.PerformClick();
                }

                stopwatch.Stop();
                double totalTime = stopwatch.Elapsed.TotalMilliseconds;
                double eachTime = (totalTime / (double)nud_batchRunTime.Value);
                MessageBox.Show("Batch Run Finish ! \nTotal : " + totalTime.ToString() + " ms. \nEach : " + eachTime.ToString() + "ms.");
            }
            catch (Exception ex)
            {
                throw new Exception("Batch Run Fail." + ex.Message);
            }
            finally
            {
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                ClsResult result = new ClsResult();

                result.Dia = Convert.ToDouble(nud_DiameterT.Value);
                result.EdgeDataList = EdgeMeasureResultList;

                result.NotchData.Vh = Convert.ToDouble(nud_Vh.Value);
                result.NotchData.Vw = Convert.ToDouble(nud_Vw.Value);
                result.NotchData.Vr = Convert.ToDouble(nud_Vr.Value);
                result.NotchData.AngV = Convert.ToDouble(nud_AngV.Value);
                result.NotchData.P1 = Convert.ToDouble(nud_P1.Value);
                result.NotchData.P2 = Convert.ToDouble(nud_P2.Value);
                result.NotchData.Vr1 = Convert.ToDouble(nud_Vr1.Value);
                result.NotchData.Vr2 = Convert.ToDouble(nud_Vr2.Value);

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "CSV|*.csv";
                sfd.DefaultExt = ".csv";
                sfd.AddExtension = true;
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    string path = sfd.FileName;
                    result.CreatCSV(path);
                }

            }
            catch (Exception)
            {

            }

        }

        public void DisposeHObjectArray(HObject[] array)
        {
            if (array != null)
            {
                foreach (HObject hObject in array)
                {
                    if (hObject != null && hObject.IsInitialized())
                    {
                        hObject.Dispose();
                    }
                }
            }
        }

        #endregion
    }

    public class ClsResult
    {
        public DateTime MeasureDateTime { get; set; }
        public string CassetteNo { get; set; }
        public string LotNo { get; set; }
        public string WaferNo { get; set; }
        public string STG { get; set; }
        public string RecipeName { get; set; }
        public string EQUIP_ID { get; set; }
        public string Memo { get; set; }
        public double Dia { get; set; }
        public NotchMeasureResult NotchData { get; set; }
        public List<EdgeMeasureResult> EdgeDataList { get; set; }
        public List<InspectDefect> DefectList_Top { get; set; }
        public List<InspectDefect> DefectList_Btm { get; set; }

        public ClsResult()
        {
            MeasureDateTime = DateTime.Now;
            CassetteNo = "NA";
            LotNo = "NA";
            WaferNo = "NA";
            STG = "NA";
            RecipeName = "NA";
            EQUIP_ID = "NA";
            Memo = "NA";

            Dia = 0;
            NotchData = new NotchMeasureResult();
            EdgeDataList = new List<EdgeMeasureResult>();
            DefectList_Top = new List<InspectDefect>();
            DefectList_Btm = new List<InspectDefect>();
        }
        public string CreatCSV(string path)
        {
            try
            {
                DataTable dt = new DataTable();
                for (int i = 0; i < 20; i++)
                {
                    dt.Columns.Add("", typeof(string));
                }

                dt.Rows.Add("Measure Date Time :", MeasureDateTime.ToString("d/m/yy"), MeasureDateTime.ToString("HH:mm:ss"));
                dt.Rows.Add("Cassette No : ", CassetteNo);
                dt.Rows.Add("Lot No :", LotNo);
                dt.Rows.Add("Wafer No :", WaferNo);
                dt.Rows.Add("STG :", STG);
                dt.Rows.Add("RecipeName :", RecipeName);
                dt.Rows.Add("EQUIP_ID :", EQUIP_ID);
                dt.Rows.Add("Memo :", Memo);
                dt.Rows.Add("");
                dt.Rows.Add("[Dia]");
                dt.Rows.Add(Dia);
                dt.Rows.Add("");
                dt.Rows.Add("[Notch]");
                dt.Rows.Add("Vh", "Vw", "Vr", "AngV", "P1", "P2", "VR1", "VR2", "EdgeTop", "EdgeDown", "Judgement");
                dt.Rows.Add(NotchData.Vh, NotchData.Vw, NotchData.Vr, NotchData.AngV, NotchData.P1, NotchData.P2, NotchData.Vr1, NotchData.Vr2, "NG", "NG", "NG");
                dt.Rows.Add("");
                dt.Rows.Add("[Edge]");
                dt.Rows.Add("No", "Point", "A1", "A2", "B1", "B2", "BC", "C1", "C2", "R1", "R2", "t", "Ang1", "Ang2", "Judgement");
                int EdgeIndex = 1;
                foreach (var item in EdgeDataList)
                {
                    if (item.ProcessStatus == true)
                    {
                        dt.Rows.Add(EdgeIndex,
                       item.Angle,
                       item.ResultData.A1,
                       item.ResultData.A2,
                       item.ResultData.B1,
                       item.ResultData.B2,
                       item.ResultData.BC,
                       item.ResultData.C1,
                       item.ResultData.C2,
                       item.ResultData.R1,
                       item.ResultData.R2,
                       item.ResultData.t,
                       item.ResultData.Ang1,
                       item.ResultData.Ang2,
                       "NG");
                    }
                    else
                    {
                        dt.Rows.Add(EdgeIndex,
                       item.Angle,
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "",
                       "NG");

                    }

                    EdgeIndex++;
                }

                dt.Rows.Add("");

                if (EdgeDataList.Count > 0)
                {
                    dt.Rows.Add("", "<Max>",
                    EdgeDataList?.Select(x => x.ResultData.A1).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.A2).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.B1).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.B2).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.BC).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.C1).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.C2).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.R1).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.R2).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.t).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.Ang1).ToList().Where(x => x != 9999).Max(),
                    EdgeDataList?.Select(x => x.ResultData.Ang2).ToList().Where(x => x != 9999).Max()
                    );

                    dt.Rows.Add("", "<Min>",
                EdgeDataList?.Select(x => x.ResultData.A1).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.A2).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.B1).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.B2).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.BC).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.C1).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.C2).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.R1).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.R2).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.t).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.Ang1).ToList().Where(x => x != 9999).Min(),
                EdgeDataList?.Select(x => x.ResultData.Ang2).ToList().Where(x => x != 9999).Min()
                );

                    dt.Rows.Add("", "<Ave>",
                     EdgeDataList?.Select(x => x.ResultData.A1).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.A2).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.B1).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.B2).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.BC).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.C1).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.C2).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.R1).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.R2).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.t).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.Ang1).ToList().Where(x => x != 9999).Average(),
                     EdgeDataList?.Select(x => x.ResultData.Ang2).ToList().Where(x => x != 9999).Average()
                     );
                }
                else
                {
                    dt.Rows.Add("", "<Max>");
                    dt.Rows.Add("", "<Min>");
                    dt.Rows.Add("", "<Ave>");
                }


                dt.Rows.Add("");

                dt.Rows.Add("[Defect]", "TOP");
                dt.Rows.Add("Point", "Code", "Area(um2)", "Judgement");
                foreach (var item in DefectList_Top)
                {
                    dt.Rows.Add(item.Angle, "PW0081", item.Area, "NG");
                }

                dt.Rows.Add("[Defect]", "Btm");
                dt.Rows.Add("Point", "Code", "Area(um2)", "Judgement");
                foreach (var item in DefectList_Btm)
                {
                    dt.Rows.Add(item.Angle, "PW0081", item.Area, "NG");
                }

                return ConvertToCsv(dt, path, false);
            }
            catch (Exception)
            {

                throw;
            }

        }
        public string ConvertToCsv(DataTable dt, string path, bool NeedColumnTitle = true)
        {
            try
            {
                List<string> lines = new List<string>();

                string[] columnNames = dt.Columns
                    .Cast<DataColumn>()
                    .Select(column => column.ColumnName)
                    .ToArray();

                if (NeedColumnTitle)
                {
                    string header = string.Join(",", columnNames.Select(name => $"\"{name}\""));
                    lines.Add(header);
                }

                var valueLines = dt.AsEnumerable().Select(row => string.Join(",", row.ItemArray.Select(val => $"\"{val}\"")));

                lines.AddRange(valueLines);
                string AllStr = string.Join("\r\n", lines);
                if (path != null)
                {
                    File.WriteAllLines(path, lines);
                }
                return AllStr;
            }
            catch (Exception)
            {
                throw;
            }
        }



    }
}

