﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace MeasureWaferRecipe
{
    public class CAlgorithmConfig
    {
        #region Initial
        public CAlgorithmConfig()
        {

        }

        public bool WriteXmlConfig(string configFileName)
        {
            try
            {
                if (!File.Exists(configFileName))
                {
                    configFileName = configFileName.Replace("\\\\", "/").Replace("\\", "/");
                    int index = configFileName.LastIndexOf("/");
                    Directory.CreateDirectory(configFileName.Substring(0, index));
                }
                // Write config value into xml.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Create))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(CAlgorithmConfig));
                    xmlSerializer.Serialize(fileStream, this);
                    fileStream.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"[WriteXmlConfig]{ex.Message}");
            }
        }

        public CAlgorithmConfig ReadXmlConfig(string configFileName)
        {
            CAlgorithmConfig tempConfig;
            try
            {
                // If file does not exists, create default one.
                if (!File.Exists(configFileName))
                    this.WriteXmlConfig(configFileName);

                // Open and read a crypto-xml file.
                using (FileStream fileStream = new FileStream(configFileName, FileMode.Open))
                using (XmlTextReader xmlTextReader = new XmlTextReader(fileStream))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(CAlgorithmConfig));
                    tempConfig = (CAlgorithmConfig)xmlSerializer.Deserialize(xmlTextReader);

                    xmlTextReader.Close();
                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"[ReadXmlConfig]{ex.Message}");
            }

            return tempConfig;
        }
        #endregion

        #region Base
        [Category("0.Base"), DisplayName("Line Scan Image Height (pix)")]
        public int LineScanHeight { get; set; }

        [Category("0.Base"), DisplayName("Line Scan Image Width (pix)")]
        public int LineScanWidth { get; set; }

        [Category("0.Base"), DisplayName("Line Scan Pixel Size (um/pix)")]
        public double LineScanPixelSize { get; set; }

        [Category("0.Base"), DisplayName("Side Camera Pixel Size (um/pix)")]
        public double SidePixelSize { get; set; }

        [Category("0.Base"), DisplayName("Notch Camera Pixel Size (um/pix)")]
        public double NotchMeasurePixSize { get; set; }

        #endregion

        #region 1.拼接對位

        //CalculateEdgePntAndCropNotch

        [Category("1.TileAlign"), DisplayName("Notch Model Path")]
        public string NotchModelPath { get; set; }

        [Category("1.TileAlign"), DisplayName("Crop Notch Width (pix)")]
        public int CropNotchWidth { get; set; }

        [Category("1.TileAlign"), DisplayName("Inside Inspect Width (mm)")]
        public double InsideInspectWidth { get; set; }

        [Category("1.TileAlign"), DisplayName("Crop Size (pix)")]
        public int CropSize { get; set; }

        [Category("1.TileAlign"), DisplayName("Align MinScore (0-1)")]
        public double AlignMinScore { get; set; }

        //CatchEdgeImageIndex

        [Category("1.TileAlign"), DisplayName("Area Total Grab Number")]
        public int AreaTotalNum { get; set; }

        [Category("1.TileAlign"), DisplayName("Measurement Catch Number")]
        public int CatchNum { get; set; }

        [Category("1.TileAlign"), DisplayName("Notch Shift Degree Angle (deg)")]
        public double NotchShiftDegreeAngle { get; set; }
        #endregion

        #region 2.直徑檢
        [Category("2.Diameter Inspect"), DisplayName("White to Black Direction (L/R)")]
        public string Direction { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Gaussian Smooth Sigma")]
        public double Sigma { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Black White Amplitude")]
        public double Amplitude { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Measurement Length (pix)")]
        public int MeasurePosLength { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Measurement Width (pix)")]
        public int MeasurePosWidth { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Measurement Gap (pix)")]
        public int MeasureGap { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Notch Width (pix)")]
        public int NotchWidth { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Diameter tranfer alpha")]
        public double Alpha { get; set; }

        [Category("2.Diameter Inspect"), DisplayName("Diameter tranfer beta")]
        public double Beta { get; set; }
        #endregion

        #region 3.瑕疵檢

        //CropDomainImage

        [Category("3.Defect Inspect"), DisplayName("Defect Inspect Width (mm)")]
        public double DefectInspectWidth { get; set; }

        [Category("3.Defect Inspect"), DisplayName("AI Draw Start X (pix)")]
        public int AIDrawStartX  { get; set; }

        //InspectWaferEdgeDefectAndDrawAi

        [Category("3.Defect Inspect"), DisplayName("ROI Width to Bevel Center (pix)")]
        public int ROIWidthtoBevelCenter { get; set; }

        [Category("3.Defect Inspect"), DisplayName("Bevel Width (pix)")]
        public int BevelWidth { get; set; }

        [Category("3.Defect Inspect"), DisplayName("Display Dilation (pix)")]
        public int DisplayDilation { get; set; }

        [Category("3.Defect Inspect"), DisplayName("Inner Threshold Max")]
        public int InnerThresholdMax { get; set; }

        [Category("3.Defect Inspect"), DisplayName("AI Defect Size")]
        public int AIDefectSize { get; set; }

        [Category("3.Defect Inspect"), DisplayName("AI Min Gray")]
        public int AIMinGray { get; set; }

        [Category("3.Defect Inspect"), DisplayName("Inner Defect Area Min Size")]
        public int InnerDefectAreaSize { get; set; }

        [Category("3.Defect Inspect"), DisplayName("Inner Defect Area Max Gray")]
        public int InnerDefectMaxGray { get; set; }

        #endregion

        #region 4.面幅檢

        //MeasureWaferEdgeB

        [Category("4.Side Measurement"), DisplayName("Rotate Angle (deg)")]
        public int SideRotateAngle { get; set; }

        [Category("4.Side Measurement"), DisplayName("Gray Max")]
        public double SideGrayMax { get; set; }

        [Category("4.Side Measurement"), DisplayName("ROI Y1")]
        public double SideRoiY1 { get; set; }

        [Category("4.Side Measurement"), DisplayName("ROI X1")]
        public double SideRoiX1 { get; set; }

        [Category("4.Side Measurement"), DisplayName("ROI Y2")]
        public double SideRoiY2 { get; set; }

        [Category("4.Side Measurement"), DisplayName("ROI X2")]
        public double SideRoiX2 { get; set; }

        [Category("4.Side Measurement"), DisplayName("A1 Angle")]
        public double A1Ang { get; set; }

        [Category("4.Side Measurement"), DisplayName("A2 Angle")]
        public double A2Ang { get; set; }

        [Category("4.Side Measurement"), DisplayName("C1 Angle")]
        public double C1Ang { get; set; }

        [Category("4.Side Measurement"), DisplayName("C2 Angle")]
        public double C2Ang { get; set; }

        [Category("4.Side Measurement"), DisplayName("bu11")]
        public double Bu11 { get; set; }

        [Category("4.Side Measurement"), DisplayName("bv11")]
        public double Bv11 { get; set; }

        [Category("4.Side Measurement"), DisplayName("bu22")]
        public double Bu22 { get; set; }

        [Category("4.Side Measurement"), DisplayName("bv22")]
        public double Bv22 { get; set; }

        [Category("4.Side Measurement"), DisplayName("R Exclude Angle")]
        public double ExAngle{ get; set; }

        [Category("4.Side Measurement"), DisplayName("Scale Width")]
        public double ScaleW { get; set; }

        [Category("4.Side Measurement"), DisplayName("Scale Height")]
        public double ScaleH { get; set; }

        [Category("4.Side Measurement"), DisplayName("Bevel Measure Number")]
        public double BevelMeasureNum { get; set; }

        #endregion

        #region 5.notch量測

        //MeasureNotch

        [Category("5.Notch Measurement"), DisplayName("Notch Measurement Rotate Angle (deg)")]
        public double NotchMeasureRotate { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Notch Area Model Path")]
        public string NotchAreaModelPath { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Notch Measurement Resize Rate (0-1)")]
        public double NotchMeasureResizeRate { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Notch Backlight Region Gray Min")]
        public double NotchGrayMin { get; set; }

        [Category("5.Notch Measurement"), DisplayName("B1 Angle (deg)")]
        public double B1Ang { get; set; }

        [Category("5.Notch Measurement"), DisplayName("B2 Angle (deg)")]
        public double B2Ang { get; set; }

        [Category("5.Notch Measurement"), DisplayName("U1 Start Rate (0-1)")]
        public double U1 { get; set; }

        [Category("5.Notch Measurement"), DisplayName("U2 Start Rate (0-1)")]
        public double U2 { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Radius Width Left (um)")]
        public double RWidthLeft { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Radius Width Right (um)")]
        public double RWidthRight { get; set; }

        [Category("5.Notch Measurement"), DisplayName("Pin Radius (mm)")]
        public double PinR { get; set; }

        [Category("5.Notch Measurement"), DisplayName("VR Angle (deg)")]
        public double VRAng { get; set; }

        #endregion

        #region 6.notch瑕疵檢

        //InspectNotchDefect_v2

        [Category("6.Notch Inspect"), DisplayName("Back White Min Gray")]
        public double BackWhiteMinGray { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Notch Inspect Display Dilation (pix)")]
        public int NotchInspectDisplayDilation { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Notch Inner Defect Max Gray")]
        public double NotchInnerDefectMaxGray { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Notch Vm Y Up (pix)")]
        public int NotchVmRowUp { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Notch Vm Y Down (pix)")]
        public int NotchVmRowDown { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Notch Black Width (pix)")]
        public int NotchBlackWidth { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Inner Defect Min Width (pix)")]
        public int InnerDefectMinWidth { get; set; }

        [Category("6.Notch Inspect"), DisplayName("Out Defect Min Width (pix)")]
        public int OutDefectMinWidth { get; set; }

        #endregion
    }
}
