﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeasureWaferRecipe
{
    public class SalmonAlgorithm
    {
        public CAlgorithmConfig Config = null;

        public SalmonAlgorithm()
        {

        }

        public bool LoadConfig(string ConfigPath)
        {
            try
            {
                Config = Config.ReadXML(ConfigPath);
                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public bool DoAlignment(HObject[] SourceImageArr, ref List<int> SideMeasureImageIndexList, ref HObject AlignResultImage,ref HObject NotchImage)
        {
            try
            {
               
                return true;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public bool DoNotchMeasure(HObject SourceImage, ref HObject ResultImage, ref NotchMeasureResult Result)
        {
            try
            {

                return true;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public bool DoNotchInspect(HObject SourceImage, ref HObject ResultImage)
        {
            try
            {

                return true;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public bool DoDiameterMeasure(HObject SourceImage, out double Diameter)
        {
            try
            {
                //SourceImage 必須將 Notch 置中
                HalconFunction.MeasureEdgePoints(SourceImage, Config.Direction, Config.Sigma,
                    Config.Amplitude, Config.MeasurePosLength, Config.MeasurePosWidth, Config.MeasureGap,
                    out HTuple hv_EdgeY, out HTuple hv_EdgeX);

                //去除 Notch 位置，及圓形對面的點
                double[] TotalX = hv_EdgeX.ToDArr()
                double[] TotalY = hv_EdgeY.ToDArr()



                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool DoDefectInspect(HObject SourceImage, ref HObject ResultImage, ref List<Rectangle> TotalGlobalDefectList)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool DoSideMeasure(HObject[] SourceImageArr, ref List<SideMeasureResult> ResultImageList, ref SideMeasureResultData StatisticResultData)
        {
            try
            {
                List<SideMeasureResult> resultList = new List<SideMeasureResult>();

                Parallel.ForEach(SourceImageArr, SourceImage =>
                {
                    HalconFunction.MeasureWaferEdgeB(SourceImage, out HObject ho_ImageOut, out HObject ho_rotateImage,
                        Config.SidePixelSize, Config.SideRotateAngle, Config.SideGrayMax, 
                        Config.SideRoiY1, Config.SideRoiX1,Config.SideRoiY2,Config.SideRoiX2,Config.A1Ang,Config.A2Ang,
                        Config.C1Ang, Config.C2Ang, Config.Bu11, Config.Bv11, Config.Bu22,
                        Config.Bv22, Config.ExAngle, Config.ScaleW, Config.ScaleH, Config.BevelMeasureNum,
                        out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
                        out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
                        out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
                        out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
                        out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
                        out HTuple hv_TextsY);


                    SideMeasureResultData resultData = new SideMeasureResultData();
                    resultData.A1 = "" + hv_A1;
                    resultData.A1 = "" + hv_A1;
                    resultData.A2 = "" + hv_A2;
                    resultData.B1 = "" + hv_B1;
                    resultData.B2 = "" + hv_B2;
                    resultData.BC = "" + hv_BC;
                    resultData.C1 = "" + hv_C1;
                    resultData.C2 = "" + hv_C2;
                    resultData.R1 = "" + hv_R1;
                    resultData.R2 = "" + hv_R2;
                    resultData.t = "" + hv_t;
                    resultData.Ang1 = "" + hv_Ang1;
                    resultData.Ang2 = "" + hv_Ang2;

                    SideMeasureResult measureResult = new SideMeasureResult();
                    measureResult.ResultData = resultData;
                    resultList.Add(measureResult);
                });

                //輸出總結果
                ResultImageList = resultList;

                //輸出統計結果
                StatisticResultData = HalconFunction.StatisticsMeasureEdgeResult(resultList);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }


    public class SideMeasureResult
    {
        public HObject SourceImage;
        public HObject ResultImage;
        public SideMeasureResultData ResultData;
        public double Angle;
        public SideMeasureResult()
        {
        }

        public void Dispose()
        {
            SourceImage.Dispose();
            ResultImage.Dispose();
        }
    }

    public class SideMeasureResultData
    {
        public string A1;
        public string A2;
        public string B1;
        public string B2;
        public string BC;
        public string C1;
        public string C2;
        public string R1;
        public string R2;
        public string t;
        public string Ang1;
        public string Ang2;
    }

    public class NotchMeasureResult
    {
        public HObject SourceImage;
        public HObject ResultImage;

        //TODO  Modify Notch
        public string hv_A1;
        public string hv_A2;
        public string hv_B1;
        public string hv_B2;
        public string hv_BC;
        public string hv_C1;
        public string hv_C2;
        public string hv_R1;
        public string hv_R2;
        public string hv_t;
        public string hv_Ang1;
        public string hv_Ang2;

        public NotchMeasureResult()
        {

        }
        public void Dispose()
        {
            SourceImage.Dispose();
            ResultImage.Dispose();
        }
    }

    public class DefectInspectCropImage
    {
        public HObject SourceCropImage;

        public int GlobalX;

        public int GlobalY;

        public HObject ResultCropImage;

        public List<Rectangle> DefectList;

        public List<Rectangle> GlobalDefectList
        {
            get
            {
                List<Rectangle> tempList = new List<Rectangle>();

                foreach (var item in DefectList)
                {
                    tempList.Add(new Rectangle
                    {
                        X = item.X + GlobalX,
                        Y = item.Y + GlobalY,
                        Width = item.Width,
                        Height = item.Height
                    });
                }

                return tempList;
            }
        }

        public DefectInspectCropImage()
        {
        }

        public void Dispose()
        {
            SourceCropImage.Dispose();
            ResultCropImage.Dispose();
        }



    }

}
