﻿using AOISystem.Halcon.Controls;
using AOISystem.Halcon.Recipe;
using HalconDotNet;

namespace AOISystem.Halcon.ROI
{
    public class ROICross : ROIBase
    {
        //fields
        private double size;
        private double centerR, centerC;   // midpoint 
        private double midR, midC;         // row and column mid point

        public double mouseRow, mouseCol;

        //[Browsable(true), Category("Property"), Description("Row")]
        //public double Row
        //{
        //    get { return row1; }
        //}

        //[Browsable(true), Category("Property"), Description("Column")]
        //public double Column
        //{
        //    get { return col1; }
        //}

        //[Browsable(true), Category("Property"), Description("設定檔路徑")]
        //public double MidRow
        //{
        //    get { return midR; }
        //}

        /// <summary>
        /// Constructor
        /// </summary>
        public ROICross()
        {
            NumHandles = 9; // 8 corner points + midpoint
            activeHandleIdx = 4;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_recipe"></param>
        public ROICross(ROIInfo recipe)
            : this()
        {
            base.ROIInfo = recipe;
            ROIInfo.RegionType = 0;

            centerC = recipe.X;
            centerR = recipe.Y;
            size = recipe.Radius;
        }

        /// <summary>
        /// create ROI 設定初始框大小位置
        /// </summary>
        public override void createROI(double midX, double midY)
        {
            //Center
            centerR = (int)midY;
            centerC = (int)midX;

            size = (int)(70 / this.Scale);
        }

        /// <summary>
        /// draw 十字
        /// </summary>
        public override void draw(HalconDotNet.HWindow window)
        {
            HOperatorSet.SetDraw(window, "fill");
            double dispsize = 15 / this.Scale;
            if (dispsize > size)
            { window.DispCross(centerR, centerC, dispsize, 0); }
            else
            { window.DispCross(centerR, centerC, size, 0); }
            HOperatorSet.SetDraw(window, "margin");
        }

        public override void drawFont(HalconDotNet.HWindow window)
        {
            int h_fontZoom = 0;
            if (this.ROIFontZoomMode == FontZoomMode.Positive)
            {
                h_fontZoom = (int)(this.FontSize * this.Scale);
            }
            else if (this.ROIFontZoomMode == FontZoomMode.Reverse)
            {
                h_fontZoom = (int)System.Math.Sqrt(this.FontSize / this.Scale);
                if (h_fontZoom < this.FontSizeThreshold)
                {
                    h_fontZoom = this.FontSizeThreshold;
                }
            }
            else
            {
                h_fontZoom = this.FontSize;
            }
            if (h_fontZoom >= this.FontSizeThreshold)
            {
                string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
                HTuple font = string.Format(fontFormat, h_fontZoom);
                window.SetFont(font);
                window.SetTposition((int)centerR, (int)centerC);
                window.WriteString(base.ROIInfo.InspectName);
            }
        }
        /// <summary>
        /// 計算最接近的小框
        /// </summary>
        public override int ROIdistance(double x, double y)
        {
            if ((centerR - 10) < y && (centerR + 10) > y && (centerC - 10) < x && (centerC + 10) > x)
            {
                return 10;
            }
            return -1;
        }

        /// <summary>
        /// 計算最接近的小框
        /// </summary>
        public override bool distToClosestHandle2(double x, double y)
        {
            double Distance;
            double max = double.MaxValue;
            double temp;
            double[] val = new double[NumHandles];

            val[0] = double.MaxValue;   // upper left 
            val[1] = double.MaxValue;   // upper right 
            val[2] = double.MaxValue;   // lower right 
            val[3] = double.MaxValue;   // lower left 
            val[4] = HMisc.DistancePp(y, x, centerR, centerC); // midpoint 
            val[5] = double.MaxValue;   // upper left  midpoint 
            val[6] = double.MaxValue;   // upper right  midpoint 
            val[7] = double.MaxValue;   // lower right midpoint 
            val[8] = HMisc.DistancePp(y, x, centerR, centerC + size / 2);    // lower left midpoint 

            //val[5] = HMisc.DistancePp(y, x, centerR - size / 2, centerC);        // upper left  midpoint 
            //val[6] = HMisc.DistancePp(y, x, centerR, centerC - size / 2);     // upper right  midpoint 
            //val[7] = HMisc.DistancePp(y, x, centerR + size / 2, centerC);      // lower right midpoint 
            //val[8] = HMisc.DistancePp(y, x, centerR, centerC + size / 2);      // lower left midpoint 
            if (size / 2 < 100)
            { temp = size / 2 - 1; }
            else
            { temp = 20; }
            if (size / 2 < 200)
            { Distance = 2; }
            else { Distance = 7 / 3; }
            for (int i = 5; i < 7; i++)
            {
                if (val[i] < (size / 2 + temp) / Distance)
                {
                    max = val[i];
                    activeHandleIdx = i;
                    return true;
                }
            }
            for (int i = 7; i < 9; i++)
            {
                if (val[i] < (size / 2 + temp) / Distance)
                {
                    max = val[i];
                    activeHandleIdx = i;
                    return true;
                }
            }


            if (val[4] < size / 2)
            {
                activeHandleIdx = 4;
                return true;
            }
            if (size == 0)
            {
                activeHandleIdx = 4;
                size = 3;
                return true;
            }
            activeHandleIdx = 0;
            return false;

        }

        public override void displayActive(HalconDotNet.HWindow window)
        {
            double dislength1 = 5 / this.Scale;
            double dislength2 = 5 / this.Scale;
            for (int i = 0; i < 9; i++)
            {
                if (i == activeHandleIdx)
                    HOperatorSet.SetColor(window, "red");
                else
                    HOperatorSet.SetColor(window, "blue");
                switch (i)
                {
                    //case 0:
                    //    window.DispRectangle2(row1, col1, phi, dislength1, dislength2);
                    //    break;
                    //case 1:
                    //    window.DispRectangle2(row1, col2, phi, dislength1, dislength2);
                    //    break;
                    //case 2:
                    //    window.DispRectangle2(row2, col2, phi, dislength1, dislength2);
                    //    break;
                    //case 3:
                    //    window.DispRectangle2(row2, col1, phi, dislength1, dislength2);
                    //    break;
                    case 4:
                        window.DispRectangle2(centerR, centerC, 0, dislength1, dislength2);
                        break;
                    case 5:
                        //window.DispRectangle2(centerR - size / 2, centerC, 0, dislength1, dislength2);
                        break;
                    case 6:
                        //window.DispRectangle2(centerR, centerC - size / 2, 0, dislength1, dislength2);
                        break;
                    case 7:
                        //window.DispRectangle2(centerR + size / 2, centerC, 0, dislength1, dislength2);
                        break;
                    case 8:
                        window.DispRectangle2(centerR, centerC + size / 2, 0, dislength1, dislength2);
                        break;
                }
            }
            /*
        double dislength1 = 5 / this.Scale;
        double dislength2 = 5 / this.Scale;
        if (1 == activeHandleIdx)
            window.DispRectangle2(centerR, centerC, 0, dislength1, dislength2);*/
        }


        public void drawFont(HalconDotNet.HWindow window, HTuple row, HTuple col)
        {
            window.SetFont("-Arial-18-*-1-*-*-1-ANSI_CHARSET-");
            window.SetTposition(row, col);
            window.WriteString(base.ROIInfo.InspectName);
        }
        public override HRegion getRegion()
        {
            HRegion region = new HRegion();
            region.GenCircle(centerR, centerC, 10);
            return region;
        }

        //public override System.Drawing.RectangleF getRectangleF()
        //{
        //    return new System.Drawing.RectangleF((float)centerR, (float)centerC, (float)centerR, (float)centerC);
        //}

        public override System.Drawing.RectangleF getRectangleF()
        {
            ROIInfo.X = centerC;
            ROIInfo.Y = centerR;
            ROIInfo.Radius = size;
            return new System.Drawing.RectangleF((float)centerR, (float)centerC, (float)centerR, (float)centerC);
        }
        /// <summary> 
        /// Recalculates the shape of the ROI instance. Translation is 
        /// performed at the active handle of the ROI object 
        /// for the image coordinate (x,y)
        /// </summary>
        /// <param name="newX">x mouse coordinate</param>
        /// <param name="newY">y mouse coordinate</param>
        public override void moveByHandle(double newX, double newY)
        {
            double val;
            if (1 == activeHandleIdx)
            {
                centerR = newY;
                centerC = newX;
            }
            switch (activeHandleIdx)
            {
                case 4:
                    centerR = newY;
                    centerC = newX;
                    break;
                case 5:
                    val = HMisc.DistancePp(newY, newX, centerR, centerC);
                    size = val * 2;
                    break;
                case 6:
                    val = HMisc.DistancePp(newY, newX, centerR, centerC);
                    size = val * 2;
                    break;
                case 7:
                    val = HMisc.DistancePp(newY, newX, centerR, centerC);
                    size = val * 2;
                    break;
                case 8:
                    //val = HMisc.DistancePp(newY, newX, centerR, centerC);
                    val = newX - centerC;
                    if (val < 1)
                        val = 2;
                    size = val * 2;
                    break;
            }
        }
    }
}
