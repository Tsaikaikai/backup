﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AOISystem.Halcon.Controls;


namespace MeasureWaferRecipe
{
    public class HalconFunction
    {
        #region 拼接對位
        public static void MatchNotch2HObject(out HObject HO_img_raw, out HObject HO_img_notchCenter, out int notch_idx,
            HObject[] hobj_list, HTuple NotchModel, HTuple matchConfidence, int total_w, int total_h)
        {
            //merge原圖
            HObject concatImage = null;
            HOperatorSet.GenEmptyObj(out concatImage);
            foreach (HObject hobj_temp in hobj_list)
                HOperatorSet.ConcatObj(concatImage, hobj_temp, out concatImage);
            HObject concatImage_raw;
            HOperatorSet.TileImages(concatImage, out concatImage_raw, 1, "vertical");

            //輸出拼接原圖(Notch在原始位置)
            //HObject CropImage_raw;
            HOperatorSet.GetImageSize(concatImage_raw, out HTuple w, out HTuple h);
            //HOperatorSet.CropPart(concatImage_raw, out CropImage_raw, 0, 0, total_w, (int)h - total_h);

            HO_img_raw = concatImage_raw;
            HO_img_notchCenter = concatImage_raw;
            notch_idx = -1;

            try
            {
                concatImage = null;
                HOperatorSet.GenEmptyObj(out concatImage);
                for (int j = 0; j < 2; j++)
                {
                    HOperatorSet.ConcatObj(concatImage, concatImage_raw, out concatImage);
                }

                //拼接兩次原圖
                HObject concatImage_all;
                HOperatorSet.TileImages(concatImage, out concatImage_all, 1, "vertical");

                // 讀取模型文件找最靠近中間的notch
                HTuple cent_y, score;

                FindCenterNotch(concatImage_all, NotchModel, matchConfidence, out cent_y, out score);

                int mid_y = Convert.ToInt32((double)cent_y);

                //Console.WriteLine("notch_idx : " + mid_y.ToString());

                notch_idx = mid_y;
                int start = mid_y - total_h / 2;


                if (start < 0)
                {
                    start = 0;
                }

                int x1 = 0;
                int y1 = start;
                int x2 = total_w;
                int y2 = start + total_h;

                // 裁剪notch置中影像區域
                HObject reducedImage, result;
                HOperatorSet.GenRectangle1(out HObject retangle, y1, x1, y2, x2);
                HOperatorSet.ReduceDomain(concatImage_all, retangle, out reducedImage);
                HOperatorSet.CropDomain(reducedImage, out result);
                HO_img_notchCenter = result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void FindCenterNotch(HObject ho_Image, HTuple hv_NotchModel, out HTuple hv_CenterModelY)
        {




            // Local iconic variables 

            // Local control variables 

            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Angle = new HTuple(), hv_Score = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_CenterRow = new HTuple(), hv_CenterCol = new HTuple();
            HTuple hv_Distance = new HTuple(), hv_Indices = new HTuple();
            // Initialize local and output iconic variables 
            hv_CenterModelY = new HTuple();
            try
            {
                //2023/04/18 v1.0 連續五張影像中 (有兩個notch),找尋最靠近中間的notch，並輸出notch Y座標
                //
                hv_Row.Dispose();
                hv_Row = new HTuple();
                hv_Column.Dispose();
                hv_Column = new HTuple();
                hv_CenterModelY.Dispose();
                hv_CenterModelY = new HTuple();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Row.Dispose(); hv_Column.Dispose(); hv_Angle.Dispose(); hv_Score.Dispose();
                    HOperatorSet.FindShapeModel(ho_Image, hv_NotchModel, (new HTuple(0)).TupleRad()
                        , (new HTuple(360)).TupleRad(), 0.5, 2, 0.5, "least_squares", (new HTuple(6)).TupleConcat(
                        1), 0.7, out hv_Row, out hv_Column, out hv_Angle, out hv_Score);
                }
                if ((int)(new HTuple((new HTuple(hv_Row.TupleLength())).TupleNotEqual(2))) != 0)
                {
                    throw new HalconException(new HTuple(new HTuple("找不到兩個notch!!  只有") + (new HTuple(hv_Row.TupleLength()
                        ))) + "個");

                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Angle.Dispose();
                    hv_Score.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_CenterRow.Dispose();
                    hv_CenterCol.Dispose();
                    hv_Distance.Dispose();
                    hv_Indices.Dispose();

                    return;
                }
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                hv_CenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterRow = (hv_Height - 1) / 2;
                }
                hv_CenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterCol = (hv_Width - 1) / 2;
                }
                hv_Distance.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Distance = ((hv_Row - hv_CenterRow)).TupleAbs()
                        ;
                }
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Distance, out hv_Indices);
                hv_CenterModelY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterModelY = hv_Row.TupleSelect(
                        hv_Indices.TupleSelect(0));
                }

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Score.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_CenterRow.Dispose();
                hv_CenterCol.Dispose();
                hv_Distance.Dispose();
                hv_Indices.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Score.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_CenterRow.Dispose();
                hv_CenterCol.Dispose();
                hv_Distance.Dispose();
                hv_Indices.Dispose();

                throw HDevExpDefaultException;
            }
        }
        #endregion

        #region 直徑量測

        public static void MeasureEdgePoints(HObject ho_Image, HTuple hv_Direction, HTuple hv_Sigma,
            HTuple hv_Amp, HTuple hv_MeasurePosLength, HTuple hv_MeasurePosWidth, HTuple hv_Gap,
            out HTuple hv_EdgeY, out HTuple hv_EdgeX)
        {




            // Local iconic variables 

            HObject ho_f1 = null, ho_Cross = null, ho_Arrow;
            HObject ho_Cross2;

            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_X1 = new HTuple(), hv_X2 = new HTuple(), hv_i = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Col = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_f1);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            HOperatorSet.GenEmptyObj(out ho_Arrow);
            HOperatorSet.GenEmptyObj(out ho_Cross2);
            hv_EdgeY = new HTuple();
            hv_EdgeX = new HTuple();
            //2023/03/06 v1.0 for Salmon for直徑量測使用
            //MeasurePosLengthOut := MeasurePosLength
            hv_Width.Dispose(); hv_Height.Dispose();
            HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
            if ((int)(new HTuple(hv_Direction.TupleEqual("L"))) != 0)
            {
                hv_X1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X1 = ((hv_Width - 1) / 2) + hv_MeasurePosLength;
                }
                hv_X2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X2 = ((hv_Width - 1) / 2) - hv_MeasurePosLength;
                }
            }
            else if ((int)(new HTuple(hv_Direction.TupleEqual("R"))) != 0)
            {
                hv_X1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X1 = ((hv_Width - 1) / 2) - hv_MeasurePosLength;
                }
                hv_X2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X2 = ((hv_Width - 1) / 2) + hv_MeasurePosLength;
                }
            }
            hv_EdgeY.Dispose();
            hv_EdgeY = new HTuple();
            hv_EdgeX.Dispose();
            hv_EdgeX = new HTuple();
            //-1D量測--
            HTuple end_val13 = hv_Height - 1;
            HTuple step_val13 = hv_Gap;
            for (hv_i = 0.0; hv_i.Continue(end_val13, step_val13); hv_i = hv_i.TupleAdd(step_val13))
            {

                ho_f1.Dispose(); hv_Row.Dispose(); hv_Col.Dispose();
                MeasurePosNegative(ho_Image, out ho_f1, hv_i, hv_X1, hv_i, hv_X2, hv_MeasurePosWidth,
                    hv_Amp, hv_Sigma, out hv_Row, out hv_Col);
                ho_Cross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross, hv_Row, hv_Col, 500, 0);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_EdgeY = hv_EdgeY.TupleConcat(
                            hv_i);
                        hv_EdgeY.Dispose();
                        hv_EdgeY = ExpTmpLocalVar_EdgeY;
                    }
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_EdgeX = hv_EdgeX.TupleConcat(
                            hv_Col);
                        hv_EdgeX.Dispose();
                        hv_EdgeX = ExpTmpLocalVar_EdgeX;
                    }
                }

            }




            //if (MeasurePosLengthOut>=Width or MeasurePosLengthOut==0)
            //MeasurePosLengthOut := Width
            //endif
            //if (Direction=='L')
            //LineY1 := 0
            //LineY2 := Height-1
            //elseif (Direction=='R')
            //LineY1 := Height-1
            //LineY2 := 0
            //endif

            //LineX1 := Width/2
            //LineX2 := Width/2
            //新建一個2D量測模型
            //create_metrology_model (Metrolog_Line)
            //get_image_size (Image, Width, Height)
            //* set_metrology_model_image_size (Metrolog_Line, Width, Height)
            //* set_metrology_model_param (Metrolog_Line, 'camera_param', [])

            //* add_metrology_object_line_measure (Metrolog_Line, LineY1, LineX1, LineY2, LineX2, MeasurePosLengthOut/2, MeasurePosWidth/2, Sigma, Amp, 'measure_distance', Gap, Index)
            //set_metrology_object_param (Metrolog_Line, Index, 'num_instances', 1)
            //* set_metrology_object_param (Metrolog_Line, Index, 'measure_select', 'first')
            //* set_metrology_object_param (Metrolog_Line, Index, 'measure_transition', 'negative')
            //set_metrology_object_param (Metrolog_Line, Index, 'min_score', 0.85)
            //* apply_metrology_model (Image, Metrolog_Line)
            //* get_metrology_object_measures (Contours1, Metrolog_Line, Index, 'all', EdgeY, EdgeX)
            //*  clear_metrology_model (Metrolog_Line)
            //-顯示-
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_Arrow.Dispose();
                gen_arrow_contour_xld(out ho_Arrow, 0, hv_Width / 2, hv_Height - 1, hv_Width / 2, 5,
                    5);
            }
            ho_Cross2.Dispose();
            HOperatorSet.GenCrossContourXld(out ho_Cross2, hv_EdgeY, hv_EdgeX, 1, 0);

            //--
            ho_f1.Dispose();
            ho_Cross.Dispose();
            ho_Arrow.Dispose();
            ho_Cross2.Dispose();

            hv_Width.Dispose();
            hv_Height.Dispose();
            hv_X1.Dispose();
            hv_X2.Dispose();
            hv_i.Dispose();
            hv_Row.Dispose();
            hv_Col.Dispose();

            return;
        } //v1.0
        #endregion

        #region 量測notch

        /// <summary>
        /// 量測notch 輸出指定8值
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ResultImage">
        /// <para>輸出圖片(繪製量測結果於圖上)</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>光學解析度</para>
        /// <para>型態: </para>
        /// <para>語義: real</para>
        /// <para>預設值: 7.04</para>
        /// </param>
        /// <param name = "hv_Rotate">
        /// <para>預旋轉方向</para>
        /// <para>型態: </para>
        /// <para>語義: real</para>
        /// <para>預設值: 90</para>
        /// </param>
        /// <param name = "hv_Resize">
        /// <para>resize倍率，填入 0 或-1 則不進行resize</para>
        /// <para>型態: </para>
        /// <para>語義: number</para>
        /// <para>預設值: 0</para>
        /// </param>
        /// <param name = "hv_GrayMin">
        /// <para>背光區(白色區域)的最小灰階值</para>
        /// <para>型態: </para>
        /// <para>預設值: -1</para>
        /// </param>
        /// <param name = "hv_b1Ang">
        /// <para>曹口點切線角度(左) 單位:度</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// <para>預設值: 20</para>
        /// </param>
        /// <param name = "hv_b2Ang">
        /// <para>曹口點切線角度(右) 單位:度</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// <para>預設值: -20</para>
        /// </param>
        /// <param name = "hv_u1">
        /// <para>角度起點比率 h1:Vh</para>
        /// <para>型態: </para>
        /// <para>預設值: 0.3</para>
        /// </param>
        /// <param name = "hv_u2">
        /// <para>角度起點比率 h2:Vh</para>
        /// <para>型態: </para>
        /// <para>預設值: 0.7</para>
        /// </param>
        /// <param name = "hv_RWidth1">
        /// <para>曹口底半徑計算寬度(左)(um)</para>
        /// <para>型態: </para>
        /// <para>預設值: 600</para>
        /// </param>
        /// <param name = "hv_RWidth2">
        /// <para>曹口底半徑計算寬度(右)(um)</para>
        /// <para>型態: </para>
        /// <para>預設值: 600</para>
        /// </param>
        /// <param name = "hv_PinR">
        /// <para>鑲嵌Pin半徑(mm)</para>
        /// <para>型態: </para>
        /// <para>預設值: 1.5</para>
        /// </param>
        /// <param name = "hv_VRAng">
        /// <para>曹口肩排除角(度)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Vh">
        /// <para>輸出Vh:曹口深度</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Vw">
        /// <para>輸出Vw:曹口寬度</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Vr">
        /// <para>輸出Vr:曹口半徑</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_P1">
        /// <para>輸出P1:曹口圓至槽底距離</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_P2">
        /// <para>輸出P2:曹口Pin圓至槽底距離</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AngV">
        /// <para>曹口開口角度</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_VR1">
        /// <para>曹口左肩半徑</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_VR2">
        /// <para>曹口右肩半徑</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ErrorMsg">
        /// <para>錯誤訊息</para>
        /// <para>型態: </para>
        /// <para>語義: string</para>
        /// </param>
        public static void MeasureNotch(HObject ho_Image, out HObject ho_ResultImage, out HObject ho_OrgImage,
            HTuple hv_PixelSize, HTuple hv_Rotate, HTuple hv_Resize, HTuple hv_GrayMin,
            HTuple hv_b1Ang, HTuple hv_b2Ang, HTuple hv_u1, HTuple hv_u2, HTuple hv_RWidth1,
            HTuple hv_RWidth2, HTuple hv_PinR, HTuple hv_VRAng, HTuple hv_NotchModelPath,
            HTuple hv_MatchMinScore, out HTuple hv_Vh, out HTuple hv_Vw, out HTuple hv_Vr,
            out HTuple hv_P1, out HTuple hv_P2, out HTuple hv_AngV, out HTuple hv_VR1, out HTuple hv_VR2,
            out HTuple hv_ErrorMsg)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_ImageOut = null, ho_ImageAffineTrans;
            HObject ho_Image3_crop, ho_Region1, ho_SelectedRegions;
            HObject ho_ImageReduced, ho_Image2, ho_ImageResult1, ho_Image1;
            HObject ho_Domain, ho_ImageResult2, ho_ImageOut2, ho_WhiteReg = null;
            HObject ho_ConnectedRegions, ho_f1, ho_C, ho_Rectangle1;
            HObject ho_Rectangle2, ho_RegBlack, ho_RegionTrans, ho_Reg1;
            HObject ho_ConnectedRegions1, ho_Reg2, ho_ConnectedRegions2;
            HObject ho_RegionLines1, ho_b1, ho_RegionLines2, ho_b2;
            HObject ho_Cross, ho_bu11, ho_bu12, ho_bu21, ho_bu22, ho_LAng2;
            HObject ho_LAng1, ho_f2, ho_ContCircle, ho_Rectangle = null;
            HObject ho_RegionIntersection = null, ho_PinCircle, ho_g11Lines;
            HObject ho_g12Lines, ho_g11, ho_g12, ho_CircleVR1, ho_Cross1;
            HObject ho_g21Lines, ho_g21, ho_g22Lines, ho_g22, ho_CircleVR2;
            HObject ho_r, ho_ShowResult, ho_Region, ho_ShowResult2;
            HObject ho_CircleReg, ho_PinCircleReg, ho_R, ho_G, ho_B;
            HObject ho_VhLine;

            // Local control variables 

            HTuple hv_ErrorMsgOut = new HTuple(), hv_ResizeOut = new HTuple();
            HTuple hv_Range = new HTuple(), hv_Sigma = new HTuple();
            HTuple hv_Amp = new HTuple(), hv_MeasureWidth = new HTuple();
            HTuple hv_MeasureGap = new HTuple(), hv_WidthImg = new HTuple();
            HTuple hv_HeightImg = new HTuple(), hv_NotchModelID = new HTuple();
            HTuple hv_Row3 = new HTuple(), hv_Column3 = new HTuple();
            HTuple hv_Angle = new HTuple(), hv_Scale = new HTuple();
            HTuple hv_Score = new HTuple(), hv_Model = new HTuple();
            HTuple hv_HomMat2D = new HTuple(), hv_Width1 = new HTuple();
            HTuple hv_Height1 = new HTuple(), hv_crop_x = new HTuple();
            HTuple hv_crop_y = new HTuple(), hv_Width2 = new HTuple();
            HTuple hv_Height2 = new HTuple(), hv_Area = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Indices3 = new HTuple(), hv_Rows = new HTuple();
            HTuple hv_Columns = new HTuple(), hv_Indices = new HTuple();
            HTuple hv_Indices1 = new HTuple(), hv_Indices2 = new HTuple();
            HTuple hv_CenterIdx = new HTuple(), hv_CenterCol = new HTuple();
            HTuple hv_CenterRow = new HTuple(), hv_CRow = new HTuple();
            HTuple hv_CCol = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Height = new HTuple(), hv_Area1 = new HTuple();
            HTuple hv_Row1 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Indices4 = new HTuple(), hv_Area2 = new HTuple();
            HTuple hv_Row2 = new HTuple(), hv_Column2 = new HTuple();
            HTuple hv_Indices5 = new HTuple(), hv_Reg1Row1 = new HTuple();
            HTuple hv_Reg1Col1 = new HTuple(), hv_Reg1Row2 = new HTuple();
            HTuple hv_Reg1Col2 = new HTuple(), hv_Reg2Row1 = new HTuple();
            HTuple hv_Reg2Col1 = new HTuple(), hv_Reg2Row2 = new HTuple();
            HTuple hv_Reg2Col2 = new HTuple(), hv_MeaLength = new HTuple();
            HTuple hv_Row1_RU = new HTuple(), hv_Col1_RU = new HTuple();
            HTuple hv_MinDistance1 = new HTuple(), hv_Row_CutL = new HTuple();
            HTuple hv_Col_CutL = new HTuple(), hv_b1Row_roughly = new HTuple();
            HTuple hv_b1Col_roughly = new HTuple(), hv_b1Row = new HTuple();
            HTuple hv_b1Col = new HTuple(), hv_Row2_RU = new HTuple();
            HTuple hv_Col2_RU = new HTuple(), hv_MinDistance2 = new HTuple();
            HTuple hv_Row_CutR = new HTuple(), hv_Col_CutR = new HTuple();
            HTuple hv_b2Row_roughly = new HTuple(), hv_b2Col_roughly = new HTuple();
            HTuple hv_b2Row = new HTuple(), hv_b2Col = new HTuple();
            HTuple hv_Row01 = new HTuple(), hv_Column11 = new HTuple();
            HTuple hv_Row21 = new HTuple(), hv_Column21 = new HTuple();
            HTuple hv_bu11Row1 = new HTuple(), hv_bu11Col1 = new HTuple();
            HTuple hv_bu11Row2 = new HTuple(), hv_bu11Col2 = new HTuple();
            HTuple hv_bu11Row = new HTuple(), hv_bu11Col = new HTuple();
            HTuple hv_bu12Row1 = new HTuple(), hv_bu12Row2 = new HTuple();
            HTuple hv_bu12Row = new HTuple(), hv_bu12Col = new HTuple();
            HTuple hv_Row02 = new HTuple(), hv_bu21Row1 = new HTuple();
            HTuple hv_bu21Col1 = new HTuple(), hv_bu21Row2 = new HTuple();
            HTuple hv_bu21Col2 = new HTuple(), hv_bu21Row = new HTuple();
            HTuple hv_bu21Col = new HTuple(), hv_bu22Row1 = new HTuple();
            HTuple hv_bu22Row2 = new HTuple(), hv_bu22Row = new HTuple();
            HTuple hv_bu22Col = new HTuple(), hv_AngV_rad = new HTuple();
            HTuple hv_Angle2 = new HTuple(), hv_Angle1 = new HTuple();
            HTuple hv_Length = new HTuple(), hv_ARow = new HTuple();
            HTuple hv_AColumn = new HTuple(), hv_IsOverlapping = new HTuple();
            HTuple hv_f1Row = new HTuple(), hv_f1Col = new HTuple();
            HTuple hv_f2Row = new HTuple(), hv_f2Col = new HTuple();
            HTuple hv_CircleRow = new HTuple(), hv_CircleCol = new HTuple();
            HTuple hv_CircleR = new HTuple(), hv_Row13 = new HTuple();
            HTuple hv_Column13 = new HTuple(), hv_Row22 = new HTuple();
            HTuple hv_Column22 = new HTuple(), hv_i = new HTuple();
            HTuple hv_PinRow = new HTuple(), hv_PinCol = new HTuple();
            HTuple hv_PinRadius = new HTuple(), hv_A = new HTuple();
            HTuple hv_CutRow_g11 = new HTuple(), hv_CutCol_g11 = new HTuple();
            HTuple hv_g11Row_roughly = new HTuple(), hv_g11Col_roughly = new HTuple();
            HTuple hv_g11Row = new HTuple(), hv_g11Col = new HTuple();
            HTuple hv_CutRow_g12 = new HTuple(), hv_CutCol_g12 = new HTuple();
            HTuple hv_g12Row_roughly = new HTuple(), hv_g12Col_roughly = new HTuple();
            HTuple hv_g12Row = new HTuple(), hv_g12Col = new HTuple();
            HTuple hv_VR1Row = new HTuple(), hv_VR1Col = new HTuple();
            HTuple hv_CutRow_g21 = new HTuple(), hv_CutCol_g21 = new HTuple();
            HTuple hv_g21Row_roughly = new HTuple(), hv_g21Col_roughly = new HTuple();
            HTuple hv_g21Row = new HTuple(), hv_g21Col = new HTuple();
            HTuple hv_CutRow_g22 = new HTuple(), hv_CutCol_g22 = new HTuple();
            HTuple hv_g22Row_roughly = new HTuple(), hv_g22Col_roughly = new HTuple();
            HTuple hv_g22Row = new HTuple(), hv_g22Col = new HTuple();
            HTuple hv_VR2Row = new HTuple(), hv_VR2Col = new HTuple();
            HTuple hv_CrossSize = new HTuple(), hv_Channels = new HTuple();
            HTuple hv_GrayMin_COPY_INP_TMP = new HTuple(hv_GrayMin);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ResultImage);
            HOperatorSet.GenEmptyObj(out ho_OrgImage);
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_ImageAffineTrans);
            HOperatorSet.GenEmptyObj(out ho_Image3_crop);
            HOperatorSet.GenEmptyObj(out ho_Region1);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_Image2);
            HOperatorSet.GenEmptyObj(out ho_ImageResult1);
            HOperatorSet.GenEmptyObj(out ho_Image1);
            HOperatorSet.GenEmptyObj(out ho_Domain);
            HOperatorSet.GenEmptyObj(out ho_ImageResult2);
            HOperatorSet.GenEmptyObj(out ho_ImageOut2);
            HOperatorSet.GenEmptyObj(out ho_WhiteReg);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_f1);
            HOperatorSet.GenEmptyObj(out ho_C);
            HOperatorSet.GenEmptyObj(out ho_Rectangle1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle2);
            HOperatorSet.GenEmptyObj(out ho_RegBlack);
            HOperatorSet.GenEmptyObj(out ho_RegionTrans);
            HOperatorSet.GenEmptyObj(out ho_Reg1);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Reg2);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions2);
            HOperatorSet.GenEmptyObj(out ho_RegionLines1);
            HOperatorSet.GenEmptyObj(out ho_b1);
            HOperatorSet.GenEmptyObj(out ho_RegionLines2);
            HOperatorSet.GenEmptyObj(out ho_b2);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            HOperatorSet.GenEmptyObj(out ho_bu11);
            HOperatorSet.GenEmptyObj(out ho_bu12);
            HOperatorSet.GenEmptyObj(out ho_bu21);
            HOperatorSet.GenEmptyObj(out ho_bu22);
            HOperatorSet.GenEmptyObj(out ho_LAng2);
            HOperatorSet.GenEmptyObj(out ho_LAng1);
            HOperatorSet.GenEmptyObj(out ho_f2);
            HOperatorSet.GenEmptyObj(out ho_ContCircle);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_RegionIntersection);
            HOperatorSet.GenEmptyObj(out ho_PinCircle);
            HOperatorSet.GenEmptyObj(out ho_g11Lines);
            HOperatorSet.GenEmptyObj(out ho_g12Lines);
            HOperatorSet.GenEmptyObj(out ho_g11);
            HOperatorSet.GenEmptyObj(out ho_g12);
            HOperatorSet.GenEmptyObj(out ho_CircleVR1);
            HOperatorSet.GenEmptyObj(out ho_Cross1);
            HOperatorSet.GenEmptyObj(out ho_g21Lines);
            HOperatorSet.GenEmptyObj(out ho_g21);
            HOperatorSet.GenEmptyObj(out ho_g22Lines);
            HOperatorSet.GenEmptyObj(out ho_g22);
            HOperatorSet.GenEmptyObj(out ho_CircleVR2);
            HOperatorSet.GenEmptyObj(out ho_r);
            HOperatorSet.GenEmptyObj(out ho_ShowResult);
            HOperatorSet.GenEmptyObj(out ho_Region);
            HOperatorSet.GenEmptyObj(out ho_ShowResult2);
            HOperatorSet.GenEmptyObj(out ho_CircleReg);
            HOperatorSet.GenEmptyObj(out ho_PinCircleReg);
            HOperatorSet.GenEmptyObj(out ho_R);
            HOperatorSet.GenEmptyObj(out ho_G);
            HOperatorSet.GenEmptyObj(out ho_B);
            HOperatorSet.GenEmptyObj(out ho_VhLine);
            hv_Vh = new HTuple();
            hv_Vw = new HTuple();
            hv_Vr = new HTuple();
            hv_P1 = new HTuple();
            hv_P2 = new HTuple();
            hv_AngV = new HTuple();
            hv_VR1 = new HTuple();
            hv_VR2 = new HTuple();
            hv_ErrorMsg = new HTuple();
            try
            {
                //v1.0 2023/03/07 Notch量測
                //v1.1 2023/03/09 註解CutLineMinDistanceAndPnt
                //v1.2 2023/04/06 輸出圖片畫上量測結果
                //v1.3 2023/05/22 新增notch上方的空白區域
                //v1.4 2023/06/06 修改 Vh 頂部
                ho_ImageOut.Dispose();
                ho_ImageOut = new HObject(ho_Image);
                hv_ErrorMsgOut.Dispose();
                hv_ErrorMsgOut = new HTuple();
                //Area計算時打開
                //ResizeOut := 13.8/7.04
                hv_ResizeOut.Dispose();
                hv_ResizeOut = new HTuple(hv_Resize);
                hv_Range.Dispose();
                hv_Range = 50;
                hv_Sigma.Dispose();
                hv_Sigma = 3;
                hv_Amp.Dispose();
                hv_Amp = 1;
                hv_MeasureWidth.Dispose();
                hv_MeasureWidth = 50;
                hv_MeasureGap.Dispose();
                hv_MeasureGap = 0.5;
                //-內部參數AreaScan
                //Range := 40
                //Sigma := 4
                //Amp := 5
                //MeasureWidth := 30
                //MeasureGap := 0.5
                hv_WidthImg.Dispose(); hv_HeightImg.Dispose();
                HOperatorSet.GetImageSize(ho_ImageOut, out hv_WidthImg, out hv_HeightImg);

                //旋轉角度
                if ((int)((new HTuple(hv_Rotate.TupleNotEqual(0))).TupleAnd(new HTuple(hv_Rotate.TupleNotEqual(
                    -1)))) != 0)
                {
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.RotateImage(ho_ImageOut, out ExpTmpOutVar_0, hv_Rotate, "constant");
                        ho_ImageOut.Dispose();
                        ho_ImageOut = ExpTmpOutVar_0;
                    }
                }

                //對位notch
                hv_NotchModelID.Dispose();
                HOperatorSet.ReadShapeModel(hv_NotchModelPath, out hv_NotchModelID);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Row3.Dispose(); hv_Column3.Dispose(); hv_Angle.Dispose(); hv_Scale.Dispose(); hv_Score.Dispose(); hv_Model.Dispose();
                    HOperatorSet.FindScaledShapeModels(ho_ImageOut, hv_NotchModelID, (new HTuple(0)).TupleRad()
                        , (new HTuple(360)).TupleRad(), 0.75, 1.25, hv_MatchMinScore, 1, 0.1, "none",
                        4, 1, out hv_Row3, out hv_Column3, out hv_Angle, out hv_Scale, out hv_Score,
                        out hv_Model);
                }

                //對位旋轉裁切
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_HomMat2D.Dispose();
                    HOperatorSet.VectorAngleToRigid(hv_HeightImg / 2, hv_WidthImg / 2, 0, hv_HeightImg / 2,
                        hv_WidthImg / 2, -hv_Angle, out hv_HomMat2D);
                }
                ho_ImageAffineTrans.Dispose();
                HOperatorSet.AffineTransImage(ho_ImageOut, out ho_ImageAffineTrans, hv_HomMat2D,
                    "constant", "true");

                //crop imaage
                hv_Width1.Dispose(); hv_Height1.Dispose();
                HOperatorSet.GetImageSize(ho_ImageAffineTrans, out hv_Width1, out hv_Height1);
                hv_crop_x.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_crop_x = hv_Width1 - hv_WidthImg;
                }
                hv_crop_y.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_crop_y = hv_Height1 - hv_HeightImg;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Image3_crop.Dispose();
                    HOperatorSet.CropPart(ho_ImageAffineTrans, out ho_Image3_crop, hv_crop_y * 2,
                        hv_crop_x * 2, hv_Width1 - (hv_crop_x * 4), hv_Height1 - (hv_crop_y * 4));
                }

                //hom_mat2d_identity (HomMat2DIdentity1)
                //hom_mat2d_rotate (HomMat2DIdentity1, -Angle, Column3, Row3, HomMat2DRotate1)
                //hom_mat2d_identity (HomMat2DIdentity2)
                //hom_mat2d_rotate (HomMat2DIdentity2, Angle, Column3, Row3, HomMat2DRotate2)
                //affine_trans_image (ImageOut, ImageOut, HomMat2DRotate1, 'constant', 'false')
                //affine_trans_point_2d (HomMat2DRotate1, 0, 0, Qx1, Qy1)
                //affine_trans_point_2d (HomMat2DRotate1, 0, WidthImg, Qx2, Qy2)
                //affine_trans_point_2d (HomMat2DRotate1, HeightImg, 0, Qx3, Qy3)
                //affine_trans_point_2d (HomMat2DRotate1, HeightImg, WidthImg, Qx4, Qy4)

                //if (Angle > 0)
                //Left_reduce := Qy3
                //Right_reduce := WidthImg - Qy2
                //Top_reduce := Qx1
                //Down_reduce := HeightImg - Qx4
                //else
                //Left_reduce := Qy1
                //Right_reduce := WidthImg - Qy4
                //Top_reduce := Qx2
                //Down_reduce := WidthImg - Left_reduce - Right_reduce - Qx3
                //endif

                //crop_part (ImageOut, ImageOut, Top_reduce, Left_reduce, WidthImg - Left_reduce - Right_reduce, HeightImg - Top_reduce - Down_reduce)

                ho_Region1.Dispose();
                HOperatorSet.Threshold(ho_Image3_crop, out ho_Region1, 0, 100);
                ho_SelectedRegions.Dispose();
                HOperatorSet.SelectShape(ho_Region1, out ho_SelectedRegions, "area", "and",
                    100000, 9000000);
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_Image3_crop, ho_SelectedRegions, out ho_ImageReduced
                    );
                hv_WidthImg.Dispose(); hv_HeightImg.Dispose();
                HOperatorSet.GetImageSize(ho_Image3_crop, out hv_WidthImg, out hv_HeightImg);
                ho_Image2.Dispose();
                HOperatorSet.GenImageConst(out ho_Image2, "byte", hv_WidthImg, hv_HeightImg);
                ho_ImageResult1.Dispose();
                HOperatorSet.PaintRegion(ho_Image2, ho_Image2, out ho_ImageResult1, 255, "fill");
                HOperatorSet.OverpaintRegion(ho_ImageResult1, ho_SelectedRegions, 0, "fill");


                //-增加圖片上方白色區域
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.Rgb1ToGray(ho_ImageResult1, out ExpTmpOutVar_0);
                    ho_ImageResult1.Dispose();
                    ho_ImageResult1 = ExpTmpOutVar_0;
                }
                hv_Width2.Dispose(); hv_Height2.Dispose();
                HOperatorSet.GetImageSize(ho_ImageResult1, out hv_Width2, out hv_Height2);
                ho_Image1.Dispose();
                HOperatorSet.GenImageConst(out ho_Image1, "byte", hv_Width2, hv_Height2);
                ho_Domain.Dispose();
                HOperatorSet.GetDomain(ho_Image1, out ho_Domain);
                ho_ImageResult2.Dispose();
                HOperatorSet.PaintRegion(ho_Domain, ho_Image1, out ho_ImageResult2, 255, "fill");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ImageResult2, ho_ImageResult1, out ExpTmpOutVar_0
                        );
                    ho_ImageResult2.Dispose();
                    ho_ImageResult2 = ExpTmpOutVar_0;
                }
                ho_ImageOut2.Dispose();
                HOperatorSet.TileImages(ho_ImageResult2, out ho_ImageOut2, 1, "vertical");

                //影像長寬比縮小(Area轉換用)
                //if (ResizeOut!=-1 or ResizeOut!=0)
                //get_image_size (ImageOut, Width1, Height1)

                //zoom_image_size (ImageOut, ImageOut, Width1*ResizeOut, Height1*ResizeOut, 'constant')
                //endif

                //影像拉長

                //if (ResizeOut!=-1 and ResizeOut!=0)
                //get_image_size (ImageOut2, Width1, Height1)
                //zoom_image_size (ImageOut2, ImageOut2, Width1*ResizeOut, Height1, 'constant')
                //endif

                ho_OrgImage.Dispose();
                HOperatorSet.CopyImage(ho_ImageOut2, out ho_OrgImage);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ScaleImage(ho_ImageOut2, out ExpTmpOutVar_0, 3.69565, -687);
                    ho_ImageOut2.Dispose();
                    ho_ImageOut2 = ExpTmpOutVar_0;
                }


                //二值化抓區域
                if ((int)(new HTuple(hv_GrayMin_COPY_INP_TMP.TupleLessEqual(-1))) != 0)
                {
                    ho_WhiteReg.Dispose(); hv_GrayMin_COPY_INP_TMP.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageOut2, out ho_WhiteReg, "max_separability",
                        "light", out hv_GrayMin_COPY_INP_TMP);
                }
                else
                {
                    ho_WhiteReg.Dispose();
                    HOperatorSet.Threshold(ho_ImageOut2, out ho_WhiteReg, hv_GrayMin_COPY_INP_TMP,
                        255);
                }
                //找上面那區塊
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_WhiteReg, out ho_ConnectedRegions);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions, out hv_Area, out hv_Row, out hv_Column);
                hv_Indices3.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area, out hv_Indices3);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_WhiteReg.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions, out ho_WhiteReg, (hv_Indices3.TupleSelect(
                        (new HTuple(hv_Indices3.TupleLength())) - 1)) + 1);
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.FillUp(ho_WhiteReg, out ExpTmpOutVar_0);
                    ho_WhiteReg.Dispose();
                    ho_WhiteReg = ExpTmpOutVar_0;
                }
                hv_Rows.Dispose(); hv_Columns.Dispose();
                HOperatorSet.GetRegionContour(ho_WhiteReg, out hv_Rows, out hv_Columns);
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Rows, out hv_Indices);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Indices1.Dispose();
                    HOperatorSet.TupleFind(hv_Rows, hv_Rows.TupleSelect(hv_Indices.TupleSelect(
                        (new HTuple(hv_Indices.TupleLength())) - 1)), out hv_Indices1);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Indices2.Dispose();
                    HOperatorSet.TupleSortIndex(hv_Columns.TupleSelect(hv_Indices1), out hv_Indices2);
                }
                hv_CenterIdx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterIdx = (new HTuple(hv_Indices2.TupleLength()
                        )) / 2;
                }
                hv_CenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterCol = ((hv_Columns.TupleSelect(
                        hv_Indices1))).TupleSelect(hv_CenterIdx);
                }
                hv_CenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterRow = ((hv_Rows.TupleSelect(
                        hv_Indices1))).TupleSelect(hv_CenterIdx);
                }

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_f1.Dispose(); hv_CRow.Dispose(); hv_CCol.Dispose();
                    MeasurePosNegative(ho_ImageOut2, out ho_f1, hv_CenterRow - 10, hv_CenterCol,
                        hv_CenterRow + 10, hv_CenterCol, 1, 30, 1, out hv_CRow, out hv_CCol);
                }
                if ((int)(new HTuple(hv_CRow.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsgOut = hv_ErrorMsgOut.TupleConcat(
                                "找不到原點座標!! 無法計算，請檢查參數GrayMin和影像");
                            hv_ErrorMsgOut.Dispose();
                            hv_ErrorMsgOut = ExpTmpLocalVar_ErrorMsgOut;
                        }
                    }
                    ho_ImageOut.Dispose();
                    ho_ImageAffineTrans.Dispose();
                    ho_Image3_crop.Dispose();
                    ho_Region1.Dispose();
                    ho_SelectedRegions.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Image2.Dispose();
                    ho_ImageResult1.Dispose();
                    ho_Image1.Dispose();
                    ho_Domain.Dispose();
                    ho_ImageResult2.Dispose();
                    ho_ImageOut2.Dispose();
                    ho_WhiteReg.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_f1.Dispose();
                    ho_C.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_RegBlack.Dispose();
                    ho_RegionTrans.Dispose();
                    ho_Reg1.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Reg2.Dispose();
                    ho_ConnectedRegions2.Dispose();
                    ho_RegionLines1.Dispose();
                    ho_b1.Dispose();
                    ho_RegionLines2.Dispose();
                    ho_b2.Dispose();
                    ho_Cross.Dispose();
                    ho_bu11.Dispose();
                    ho_bu12.Dispose();
                    ho_bu21.Dispose();
                    ho_bu22.Dispose();
                    ho_LAng2.Dispose();
                    ho_LAng1.Dispose();
                    ho_f2.Dispose();
                    ho_ContCircle.Dispose();
                    ho_Rectangle.Dispose();
                    ho_RegionIntersection.Dispose();
                    ho_PinCircle.Dispose();
                    ho_g11Lines.Dispose();
                    ho_g12Lines.Dispose();
                    ho_g11.Dispose();
                    ho_g12.Dispose();
                    ho_CircleVR1.Dispose();
                    ho_Cross1.Dispose();
                    ho_g21Lines.Dispose();
                    ho_g21.Dispose();
                    ho_g22Lines.Dispose();
                    ho_g22.Dispose();
                    ho_CircleVR2.Dispose();
                    ho_r.Dispose();
                    ho_ShowResult.Dispose();
                    ho_Region.Dispose();
                    ho_ShowResult2.Dispose();
                    ho_CircleReg.Dispose();
                    ho_PinCircleReg.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();
                    ho_VhLine.Dispose();

                    hv_GrayMin_COPY_INP_TMP.Dispose();
                    hv_ErrorMsgOut.Dispose();
                    hv_ResizeOut.Dispose();
                    hv_Range.Dispose();
                    hv_Sigma.Dispose();
                    hv_Amp.Dispose();
                    hv_MeasureWidth.Dispose();
                    hv_MeasureGap.Dispose();
                    hv_WidthImg.Dispose();
                    hv_HeightImg.Dispose();
                    hv_NotchModelID.Dispose();
                    hv_Row3.Dispose();
                    hv_Column3.Dispose();
                    hv_Angle.Dispose();
                    hv_Scale.Dispose();
                    hv_Score.Dispose();
                    hv_Model.Dispose();
                    hv_HomMat2D.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_crop_x.Dispose();
                    hv_crop_y.Dispose();
                    hv_Width2.Dispose();
                    hv_Height2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Indices3.Dispose();
                    hv_Rows.Dispose();
                    hv_Columns.Dispose();
                    hv_Indices.Dispose();
                    hv_Indices1.Dispose();
                    hv_Indices2.Dispose();
                    hv_CenterIdx.Dispose();
                    hv_CenterCol.Dispose();
                    hv_CenterRow.Dispose();
                    hv_CRow.Dispose();
                    hv_CCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_Area1.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices4.Dispose();
                    hv_Area2.Dispose();
                    hv_Row2.Dispose();
                    hv_Column2.Dispose();
                    hv_Indices5.Dispose();
                    hv_Reg1Row1.Dispose();
                    hv_Reg1Col1.Dispose();
                    hv_Reg1Row2.Dispose();
                    hv_Reg1Col2.Dispose();
                    hv_Reg2Row1.Dispose();
                    hv_Reg2Col1.Dispose();
                    hv_Reg2Row2.Dispose();
                    hv_Reg2Col2.Dispose();
                    hv_MeaLength.Dispose();
                    hv_Row1_RU.Dispose();
                    hv_Col1_RU.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_Row_CutL.Dispose();
                    hv_Col_CutL.Dispose();
                    hv_b1Row_roughly.Dispose();
                    hv_b1Col_roughly.Dispose();
                    hv_b1Row.Dispose();
                    hv_b1Col.Dispose();
                    hv_Row2_RU.Dispose();
                    hv_Col2_RU.Dispose();
                    hv_MinDistance2.Dispose();
                    hv_Row_CutR.Dispose();
                    hv_Col_CutR.Dispose();
                    hv_b2Row_roughly.Dispose();
                    hv_b2Col_roughly.Dispose();
                    hv_b2Row.Dispose();
                    hv_b2Col.Dispose();
                    hv_Row01.Dispose();
                    hv_Column11.Dispose();
                    hv_Row21.Dispose();
                    hv_Column21.Dispose();
                    hv_bu11Row1.Dispose();
                    hv_bu11Col1.Dispose();
                    hv_bu11Row2.Dispose();
                    hv_bu11Col2.Dispose();
                    hv_bu11Row.Dispose();
                    hv_bu11Col.Dispose();
                    hv_bu12Row1.Dispose();
                    hv_bu12Row2.Dispose();
                    hv_bu12Row.Dispose();
                    hv_bu12Col.Dispose();
                    hv_Row02.Dispose();
                    hv_bu21Row1.Dispose();
                    hv_bu21Col1.Dispose();
                    hv_bu21Row2.Dispose();
                    hv_bu21Col2.Dispose();
                    hv_bu21Row.Dispose();
                    hv_bu21Col.Dispose();
                    hv_bu22Row1.Dispose();
                    hv_bu22Row2.Dispose();
                    hv_bu22Row.Dispose();
                    hv_bu22Col.Dispose();
                    hv_AngV_rad.Dispose();
                    hv_Angle2.Dispose();
                    hv_Angle1.Dispose();
                    hv_Length.Dispose();
                    hv_ARow.Dispose();
                    hv_AColumn.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_f1Row.Dispose();
                    hv_f1Col.Dispose();
                    hv_f2Row.Dispose();
                    hv_f2Col.Dispose();
                    hv_CircleRow.Dispose();
                    hv_CircleCol.Dispose();
                    hv_CircleR.Dispose();
                    hv_Row13.Dispose();
                    hv_Column13.Dispose();
                    hv_Row22.Dispose();
                    hv_Column22.Dispose();
                    hv_i.Dispose();
                    hv_PinRow.Dispose();
                    hv_PinCol.Dispose();
                    hv_PinRadius.Dispose();
                    hv_A.Dispose();
                    hv_CutRow_g11.Dispose();
                    hv_CutCol_g11.Dispose();
                    hv_g11Row_roughly.Dispose();
                    hv_g11Col_roughly.Dispose();
                    hv_g11Row.Dispose();
                    hv_g11Col.Dispose();
                    hv_CutRow_g12.Dispose();
                    hv_CutCol_g12.Dispose();
                    hv_g12Row_roughly.Dispose();
                    hv_g12Col_roughly.Dispose();
                    hv_g12Row.Dispose();
                    hv_g12Col.Dispose();
                    hv_VR1Row.Dispose();
                    hv_VR1Col.Dispose();
                    hv_CutRow_g21.Dispose();
                    hv_CutCol_g21.Dispose();
                    hv_g21Row_roughly.Dispose();
                    hv_g21Col_roughly.Dispose();
                    hv_g21Row.Dispose();
                    hv_g21Col.Dispose();
                    hv_CutRow_g22.Dispose();
                    hv_CutCol_g22.Dispose();
                    hv_g22Row_roughly.Dispose();
                    hv_g22Col_roughly.Dispose();
                    hv_g22Row.Dispose();
                    hv_g22Col.Dispose();
                    hv_VR2Row.Dispose();
                    hv_VR2Col.Dispose();
                    hv_CrossSize.Dispose();
                    hv_Channels.Dispose();

                    return;
                }
                //CCol := Columns[Indices1][CenterIdx]
                //CRow := Rows[Indices[|Indices|-1]]
                //CCol := Columns[Indices[|Indices|-1]]
                ho_C.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_C, hv_CRow, hv_CCol, 20, 0);
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_ImageOut2, out hv_Width, out hv_Height);
                ho_Rectangle1.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle1, 0, 0, hv_CRow, hv_CCol);
                ho_Rectangle2.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle2, 0, hv_CCol, hv_CRow, hv_Width);
                //threshold (ImageOut2, RegBlack, 0, GrayMin)
                ho_RegionTrans.Dispose();
                HOperatorSet.ShapeTrans(ho_WhiteReg, out ho_RegionTrans, "convex");
                ho_RegBlack.Dispose();
                HOperatorSet.Difference(ho_RegionTrans, ho_WhiteReg, out ho_RegBlack);
                //--篩選最大塊區域--
                ho_Reg1.Dispose();
                HOperatorSet.Intersection(ho_RegBlack, ho_Rectangle1, out ho_Reg1);
                ho_ConnectedRegions1.Dispose();
                HOperatorSet.Connection(ho_Reg1, out ho_ConnectedRegions1);
                hv_Area1.Dispose(); hv_Row1.Dispose(); hv_Column1.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions1, out hv_Area1, out hv_Row1, out hv_Column1);
                hv_Indices4.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area1, out hv_Indices4);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Reg1.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions1, out ho_Reg1, (hv_Indices4.TupleSelect(
                        (new HTuple(hv_Indices4.TupleLength())) - 1)) + 1);
                }
                //--篩選最大塊區域--
                ho_Reg2.Dispose();
                HOperatorSet.Intersection(ho_RegBlack, ho_Rectangle2, out ho_Reg2);
                ho_ConnectedRegions2.Dispose();
                HOperatorSet.Connection(ho_Reg2, out ho_ConnectedRegions2);
                hv_Area2.Dispose(); hv_Row2.Dispose(); hv_Column2.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions2, out hv_Area2, out hv_Row2, out hv_Column2);
                hv_Indices5.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area2, out hv_Indices5);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Reg2.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions2, out ho_Reg2, (hv_Indices5.TupleSelect(
                        (new HTuple(hv_Indices5.TupleLength())) - 1)) + 1);
                }

                hv_Reg1Row1.Dispose(); hv_Reg1Col1.Dispose(); hv_Reg1Row2.Dispose(); hv_Reg1Col2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Reg1, out hv_Reg1Row1, out hv_Reg1Col1,
                    out hv_Reg1Row2, out hv_Reg1Col2);
                hv_Reg2Row1.Dispose(); hv_Reg2Col1.Dispose(); hv_Reg2Row2.Dispose(); hv_Reg2Col2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Reg2, out hv_Reg2Row1, out hv_Reg2Col1,
                    out hv_Reg2Row2, out hv_Reg2Col2);
                hv_MeaLength.Dispose();
                hv_MeaLength = 400;
                //左開口點b1(左邊的右上角)
                hv_Row1_RU.Dispose();
                hv_Row1_RU = new HTuple(hv_Reg1Row1);
                hv_Col1_RU.Dispose();
                hv_Col1_RU = new HTuple(hv_Reg1Col2);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines1.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines1, hv_Row1_RU + (hv_MeaLength * (((((-hv_b1Ang)).TupleRad()
                        )).TupleSin())), hv_Col1_RU - (hv_MeaLength * (((((-hv_b1Ang)).TupleRad())).TupleCos()
                        )), hv_Row1_RU - (hv_MeaLength * (((((-hv_b1Ang)).TupleRad())).TupleSin())),
                        hv_Col1_RU + (hv_MeaLength * (((((-hv_b1Ang)).TupleRad())).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_Row_CutL.Dispose(); hv_Col_CutL.Dispose(); hv_b1Row_roughly.Dispose(); hv_b1Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines1, ho_Reg1, out hv_MinDistance1, out hv_Row_CutL,
                    out hv_Col_CutL, out hv_b1Row_roughly, out hv_b1Col_roughly);

                hv_b1Row.Dispose(); hv_b1Col.Dispose();
                CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_Row_CutL, hv_Col_CutL,
                    hv_b1Ang, hv_MinDistance1, hv_Sigma, hv_Amp, hv_MeasureWidth, hv_MeasureGap,
                    out hv_b1Row, out hv_b1Col);

                ho_b1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b1, hv_b1Row, hv_b1Col, 30, 0);
                //右開口點b2(右邊的左上角)
                hv_Row2_RU.Dispose();
                hv_Row2_RU = new HTuple(hv_Reg2Row1);
                hv_Col2_RU.Dispose();
                hv_Col2_RU = new HTuple(hv_Reg2Col1);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines2.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines2, hv_Row2_RU + (hv_MeaLength * (((((-hv_b2Ang)).TupleRad()
                        )).TupleSin())), hv_Col2_RU - (hv_MeaLength * (((((-hv_b2Ang)).TupleRad())).TupleCos()
                        )), hv_Row2_RU - (hv_MeaLength * (((((-hv_b2Ang)).TupleRad())).TupleSin())),
                        hv_Col2_RU + (hv_MeaLength * (((((-hv_b2Ang)).TupleRad())).TupleCos())));
                }
                hv_MinDistance2.Dispose(); hv_Row_CutR.Dispose(); hv_Col_CutR.Dispose(); hv_b2Row_roughly.Dispose(); hv_b2Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines2, ho_Reg2, out hv_MinDistance2, out hv_Row_CutR,
                    out hv_Col_CutR, out hv_b2Row_roughly, out hv_b2Col_roughly);
                hv_b2Row.Dispose(); hv_b2Col.Dispose();
                CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_Row_CutR, hv_Col_CutR,
                    hv_b2Ang, hv_MinDistance2, hv_Sigma, hv_Amp, hv_MeasureWidth, hv_MeasureGap,
                    out hv_b2Row, out hv_b2Col);
                ho_b2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b2, hv_b2Row, hv_b2Col, 30, 0);
                ho_Cross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross, hv_b2Row_roughly, hv_b2Col_roughly,
                    6, 0.785398);

                //-----------量測到開口角  做校正------
                //hom_mat2d_identity (HomMat2DIdentity)
                //旋轉中心(Wafer的頂點)
                //rotateRow := (b1Row+b2Row)/2
                //rotateCol := (b1Col+b2Col)/2
                //angle_lx (b1Row, b1Col, b2Row, b2Col, Angle)
                //hom_mat2d_rotate (HomMat2DIdentity, -Angle, rotateCol, rotateRow, HomMat2DRotate)
                //affine_trans_image (ImageOut, ImageOut, HomMat2DRotate, 'constant', 'false')
                //----------------
                //量測斜角左
                //*     bu11Row1:=b1Row+abs(b1Row-CRow)*u1
                //*     bu11Col1:=CCol
                //*     bu11Row2:=b1Row+abs(b1Row-CRow)*u1
                //*     bu11Col2:=b1Col
                hv_Row01.Dispose(); hv_Column11.Dispose(); hv_Row21.Dispose(); hv_Column21.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Reg1, out hv_Row01, out hv_Column11, out hv_Row21,
                    out hv_Column21);
                hv_bu11Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu11Row1 = hv_Row01 + ((((hv_Row01 - hv_CRow)).TupleAbs()
                        ) * hv_u1);
                }
                hv_bu11Col1.Dispose();
                hv_bu11Col1 = new HTuple(hv_CCol);
                hv_bu11Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu11Row2 = hv_Row01 + ((((hv_Row01 - hv_CRow)).TupleAbs()
                        ) * hv_u1);
                }
                hv_bu11Col2.Dispose();
                hv_bu11Col2 = new HTuple(hv_b1Col);
                ho_bu11.Dispose(); hv_bu11Row.Dispose(); hv_bu11Col.Dispose();
                MeasurePosNegative(ho_ImageOut2, out ho_bu11, hv_bu11Row1, hv_bu11Col1, hv_bu11Row2,
                    hv_bu11Col2, 1, 30, 1, out hv_bu11Row, out hv_bu11Col);
                if ((int)(new HTuple(hv_bu11Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsgOut = hv_ErrorMsgOut.TupleConcat(
                                "bu11量測失敗");
                            hv_ErrorMsgOut.Dispose();
                            hv_ErrorMsgOut = ExpTmpLocalVar_ErrorMsgOut;
                        }
                    }
                }
                //*     bu12Row1:=b1Row+abs(b1Row-CRow)*u2
                //*     bu12Row2:=b1Row+abs(b1Row-CRow)*u2
                hv_bu12Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu12Row1 = hv_Row01 + ((((hv_Row01 - hv_CRow)).TupleAbs()
                        ) * hv_u2);
                }
                hv_bu12Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu12Row2 = hv_Row01 + ((((hv_Row01 - hv_CRow)).TupleAbs()
                        ) * hv_u2);
                }
                ho_bu12.Dispose(); hv_bu12Row.Dispose(); hv_bu12Col.Dispose();
                MeasurePosNegative(ho_ImageOut2, out ho_bu12, hv_bu12Row1, hv_bu11Col1, hv_bu12Row2,
                    hv_bu11Col2, 1, 30, 1, out hv_bu12Row, out hv_bu12Col);
                if ((int)(new HTuple(hv_bu12Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsgOut = hv_ErrorMsgOut.TupleConcat(
                                "bu12量測失敗");
                            hv_ErrorMsgOut.Dispose();
                            hv_ErrorMsgOut = ExpTmpLocalVar_ErrorMsgOut;
                        }
                    }
                }

                //量測斜角右
                //*     bu21Row1:=b2Row+abs(b2Row-CRow)*u1
                //*     bu21Col1:=b2Col
                //*     bu21Row2:=b2Row+abs(b2Row-CRow)*u1
                //*     bu21Col2:=CCol
                hv_Row02.Dispose(); hv_Column11.Dispose(); hv_Row21.Dispose(); hv_Column21.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Reg2, out hv_Row02, out hv_Column11, out hv_Row21,
                    out hv_Column21);
                hv_bu21Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu21Row1 = hv_Row02 + ((((hv_Row02 - hv_CRow)).TupleAbs()
                        ) * hv_u1);
                }
                hv_bu21Col1.Dispose();
                hv_bu21Col1 = new HTuple(hv_b2Col);
                hv_bu21Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu21Row2 = hv_Row02 + ((((hv_Row02 - hv_CRow)).TupleAbs()
                        ) * hv_u1);
                }
                hv_bu21Col2.Dispose();
                hv_bu21Col2 = new HTuple(hv_CCol);
                ho_bu21.Dispose(); hv_bu21Row.Dispose(); hv_bu21Col.Dispose();
                MeasurePosNegative(ho_ImageOut2, out ho_bu21, hv_bu21Row2, hv_bu21Col2, hv_bu21Row1,
                    hv_bu21Col1, 1, 30, 1, out hv_bu21Row, out hv_bu21Col);
                if ((int)(new HTuple(hv_bu21Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsgOut = hv_ErrorMsgOut.TupleConcat(
                                "bu21量測失敗");
                            hv_ErrorMsgOut.Dispose();
                            hv_ErrorMsgOut = ExpTmpLocalVar_ErrorMsgOut;
                        }
                    }
                }
                //*     bu22Row1:=b2Row+abs(b2Row-CRow)*u2
                //*     bu22Row2:=b2Row+abs(b2Row-CRow)*u2
                hv_bu22Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu22Row1 = hv_Row02 + ((((hv_Row02 - hv_CRow)).TupleAbs()
                        ) * hv_u2);
                }
                hv_bu22Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu22Row2 = hv_Row02 + ((((hv_Row02 - hv_CRow)).TupleAbs()
                        ) * hv_u2);
                }
                ho_bu22.Dispose(); hv_bu22Row.Dispose(); hv_bu22Col.Dispose();
                MeasurePosNegative(ho_ImageOut2, out ho_bu22, hv_bu22Row2, hv_bu21Col2, hv_bu22Row1,
                    hv_bu21Col1, 1, 30, 1, out hv_bu22Row, out hv_bu22Col);
                if ((int)(new HTuple(hv_bu22Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsgOut = hv_ErrorMsgOut.TupleConcat(
                                "bu22量測失敗");
                            hv_ErrorMsgOut.Dispose();
                            hv_ErrorMsgOut = ExpTmpLocalVar_ErrorMsgOut;
                        }
                    }
                }
                if ((int)(new HTuple(hv_ErrorMsgOut.TupleNotEqual(new HTuple()))) != 0)
                {
                    ho_ImageOut.Dispose();
                    ho_ImageAffineTrans.Dispose();
                    ho_Image3_crop.Dispose();
                    ho_Region1.Dispose();
                    ho_SelectedRegions.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Image2.Dispose();
                    ho_ImageResult1.Dispose();
                    ho_Image1.Dispose();
                    ho_Domain.Dispose();
                    ho_ImageResult2.Dispose();
                    ho_ImageOut2.Dispose();
                    ho_WhiteReg.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_f1.Dispose();
                    ho_C.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_RegBlack.Dispose();
                    ho_RegionTrans.Dispose();
                    ho_Reg1.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Reg2.Dispose();
                    ho_ConnectedRegions2.Dispose();
                    ho_RegionLines1.Dispose();
                    ho_b1.Dispose();
                    ho_RegionLines2.Dispose();
                    ho_b2.Dispose();
                    ho_Cross.Dispose();
                    ho_bu11.Dispose();
                    ho_bu12.Dispose();
                    ho_bu21.Dispose();
                    ho_bu22.Dispose();
                    ho_LAng2.Dispose();
                    ho_LAng1.Dispose();
                    ho_f2.Dispose();
                    ho_ContCircle.Dispose();
                    ho_Rectangle.Dispose();
                    ho_RegionIntersection.Dispose();
                    ho_PinCircle.Dispose();
                    ho_g11Lines.Dispose();
                    ho_g12Lines.Dispose();
                    ho_g11.Dispose();
                    ho_g12.Dispose();
                    ho_CircleVR1.Dispose();
                    ho_Cross1.Dispose();
                    ho_g21Lines.Dispose();
                    ho_g21.Dispose();
                    ho_g22Lines.Dispose();
                    ho_g22.Dispose();
                    ho_CircleVR2.Dispose();
                    ho_r.Dispose();
                    ho_ShowResult.Dispose();
                    ho_Region.Dispose();
                    ho_ShowResult2.Dispose();
                    ho_CircleReg.Dispose();
                    ho_PinCircleReg.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();
                    ho_VhLine.Dispose();

                    hv_GrayMin_COPY_INP_TMP.Dispose();
                    hv_ErrorMsgOut.Dispose();
                    hv_ResizeOut.Dispose();
                    hv_Range.Dispose();
                    hv_Sigma.Dispose();
                    hv_Amp.Dispose();
                    hv_MeasureWidth.Dispose();
                    hv_MeasureGap.Dispose();
                    hv_WidthImg.Dispose();
                    hv_HeightImg.Dispose();
                    hv_NotchModelID.Dispose();
                    hv_Row3.Dispose();
                    hv_Column3.Dispose();
                    hv_Angle.Dispose();
                    hv_Scale.Dispose();
                    hv_Score.Dispose();
                    hv_Model.Dispose();
                    hv_HomMat2D.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_crop_x.Dispose();
                    hv_crop_y.Dispose();
                    hv_Width2.Dispose();
                    hv_Height2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Indices3.Dispose();
                    hv_Rows.Dispose();
                    hv_Columns.Dispose();
                    hv_Indices.Dispose();
                    hv_Indices1.Dispose();
                    hv_Indices2.Dispose();
                    hv_CenterIdx.Dispose();
                    hv_CenterCol.Dispose();
                    hv_CenterRow.Dispose();
                    hv_CRow.Dispose();
                    hv_CCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_Area1.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices4.Dispose();
                    hv_Area2.Dispose();
                    hv_Row2.Dispose();
                    hv_Column2.Dispose();
                    hv_Indices5.Dispose();
                    hv_Reg1Row1.Dispose();
                    hv_Reg1Col1.Dispose();
                    hv_Reg1Row2.Dispose();
                    hv_Reg1Col2.Dispose();
                    hv_Reg2Row1.Dispose();
                    hv_Reg2Col1.Dispose();
                    hv_Reg2Row2.Dispose();
                    hv_Reg2Col2.Dispose();
                    hv_MeaLength.Dispose();
                    hv_Row1_RU.Dispose();
                    hv_Col1_RU.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_Row_CutL.Dispose();
                    hv_Col_CutL.Dispose();
                    hv_b1Row_roughly.Dispose();
                    hv_b1Col_roughly.Dispose();
                    hv_b1Row.Dispose();
                    hv_b1Col.Dispose();
                    hv_Row2_RU.Dispose();
                    hv_Col2_RU.Dispose();
                    hv_MinDistance2.Dispose();
                    hv_Row_CutR.Dispose();
                    hv_Col_CutR.Dispose();
                    hv_b2Row_roughly.Dispose();
                    hv_b2Col_roughly.Dispose();
                    hv_b2Row.Dispose();
                    hv_b2Col.Dispose();
                    hv_Row01.Dispose();
                    hv_Column11.Dispose();
                    hv_Row21.Dispose();
                    hv_Column21.Dispose();
                    hv_bu11Row1.Dispose();
                    hv_bu11Col1.Dispose();
                    hv_bu11Row2.Dispose();
                    hv_bu11Col2.Dispose();
                    hv_bu11Row.Dispose();
                    hv_bu11Col.Dispose();
                    hv_bu12Row1.Dispose();
                    hv_bu12Row2.Dispose();
                    hv_bu12Row.Dispose();
                    hv_bu12Col.Dispose();
                    hv_Row02.Dispose();
                    hv_bu21Row1.Dispose();
                    hv_bu21Col1.Dispose();
                    hv_bu21Row2.Dispose();
                    hv_bu21Col2.Dispose();
                    hv_bu21Row.Dispose();
                    hv_bu21Col.Dispose();
                    hv_bu22Row1.Dispose();
                    hv_bu22Row2.Dispose();
                    hv_bu22Row.Dispose();
                    hv_bu22Col.Dispose();
                    hv_AngV_rad.Dispose();
                    hv_Angle2.Dispose();
                    hv_Angle1.Dispose();
                    hv_Length.Dispose();
                    hv_ARow.Dispose();
                    hv_AColumn.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_f1Row.Dispose();
                    hv_f1Col.Dispose();
                    hv_f2Row.Dispose();
                    hv_f2Col.Dispose();
                    hv_CircleRow.Dispose();
                    hv_CircleCol.Dispose();
                    hv_CircleR.Dispose();
                    hv_Row13.Dispose();
                    hv_Column13.Dispose();
                    hv_Row22.Dispose();
                    hv_Column22.Dispose();
                    hv_i.Dispose();
                    hv_PinRow.Dispose();
                    hv_PinCol.Dispose();
                    hv_PinRadius.Dispose();
                    hv_A.Dispose();
                    hv_CutRow_g11.Dispose();
                    hv_CutCol_g11.Dispose();
                    hv_g11Row_roughly.Dispose();
                    hv_g11Col_roughly.Dispose();
                    hv_g11Row.Dispose();
                    hv_g11Col.Dispose();
                    hv_CutRow_g12.Dispose();
                    hv_CutCol_g12.Dispose();
                    hv_g12Row_roughly.Dispose();
                    hv_g12Col_roughly.Dispose();
                    hv_g12Row.Dispose();
                    hv_g12Col.Dispose();
                    hv_VR1Row.Dispose();
                    hv_VR1Col.Dispose();
                    hv_CutRow_g21.Dispose();
                    hv_CutCol_g21.Dispose();
                    hv_g21Row_roughly.Dispose();
                    hv_g21Col_roughly.Dispose();
                    hv_g21Row.Dispose();
                    hv_g21Col.Dispose();
                    hv_CutRow_g22.Dispose();
                    hv_CutCol_g22.Dispose();
                    hv_g22Row_roughly.Dispose();
                    hv_g22Col_roughly.Dispose();
                    hv_g22Row.Dispose();
                    hv_g22Col.Dispose();
                    hv_VR2Row.Dispose();
                    hv_VR2Col.Dispose();
                    hv_CrossSize.Dispose();
                    hv_Channels.Dispose();

                    return;
                }
                hv_AngV_rad.Dispose();
                HOperatorSet.AngleLl(hv_bu22Row, hv_bu22Col, hv_bu21Row, hv_bu21Col, hv_bu12Row,
                    hv_bu12Col, hv_bu11Row, hv_bu11Col, out hv_AngV_rad);
                hv_Angle2.Dispose();
                HOperatorSet.AngleLx(hv_bu22Row, hv_bu22Col, hv_bu21Row, hv_bu21Col, out hv_Angle2);
                hv_Angle1.Dispose();
                HOperatorSet.AngleLx(hv_bu12Row, hv_bu12Col, hv_bu11Row, hv_bu11Col, out hv_Angle1);
                hv_Length.Dispose();
                hv_Length = 150;
                hv_ARow.Dispose(); hv_AColumn.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_bu22Row, hv_bu22Col, hv_bu21Row, hv_bu21Col,
                    hv_bu12Row, hv_bu12Col, hv_bu11Row, hv_bu11Col, out hv_ARow, out hv_AColumn,
                    out hv_IsOverlapping);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_LAng2.Dispose();
                    gen_arrow_contour_xld(out ho_LAng2, hv_ARow, hv_AColumn, hv_bu21Row - (hv_Length * (hv_Angle2.TupleSin()
                        )), hv_bu21Col + (hv_Length * (hv_Angle2.TupleCos())), 0, 0);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_LAng1.Dispose();
                    gen_arrow_contour_xld(out ho_LAng1, hv_ARow, hv_AColumn, hv_bu11Row - (hv_Length * (hv_Angle1.TupleSin()
                        )), hv_bu11Col + (hv_Length * (hv_Angle1.TupleCos())), 0, 0);
                }


                //量測內切圓
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_f1.Dispose(); hv_f1Row.Dispose(); hv_f1Col.Dispose();
                    MeasurePosNegative(ho_ImageOut2, out ho_f1, hv_b2Row, hv_CCol - (hv_RWidth1 / hv_PixelSize),
                        hv_CRow + 30, hv_CCol - (hv_RWidth1 / hv_PixelSize), 2, 30, 1, out hv_f1Row,
                        out hv_f1Col);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_f2.Dispose(); hv_f2Row.Dispose(); hv_f2Col.Dispose();
                    MeasurePosNegative(ho_ImageOut2, out ho_f2, hv_b2Row, hv_CCol + (hv_RWidth2 / hv_PixelSize),
                        hv_CRow + 30, hv_CCol + (hv_RWidth2 / hv_PixelSize), 2, 30, 1, out hv_f2Row,
                        out hv_f2Col);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_ContCircle.Dispose(); hv_CircleRow.Dispose(); hv_CircleCol.Dispose(); hv_CircleR.Dispose();
                    GetCircleCenterFrom3Point(out ho_ContCircle, ((hv_f1Row.TupleConcat(hv_f2Row))).TupleConcat(
                        hv_CRow), ((hv_f1Col.TupleConcat(hv_f2Col))).TupleConcat(hv_CCol), hv_PixelSize,
                        out hv_CircleRow, out hv_CircleCol, out hv_CircleR);
                }

                //嵌入Pin
                hv_Row13.Dispose(); hv_Column13.Dispose(); hv_Row22.Dispose(); hv_Column22.Dispose();
                HOperatorSet.SmallestRectangle1(ho_WhiteReg, out hv_Row13, out hv_Column13,
                    out hv_Row22, out hv_Column22);
                HTuple end_val244 = ((hv_PinR * 3) * 1000) / hv_PixelSize;
                HTuple step_val244 = 1;
                for (hv_i = ((hv_PinR * 1.99) * 1000) / hv_PixelSize; hv_i.Continue(end_val244, step_val244); hv_i = hv_i.TupleAdd(step_val244))
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle.Dispose();
                        HOperatorSet.GenRectangle1(out ho_Rectangle, hv_Row22 - hv_i, hv_Column13,
                            hv_Row22, hv_Column22);
                    }
                    ho_RegionIntersection.Dispose();
                    HOperatorSet.Intersection(ho_WhiteReg, ho_Rectangle, out ho_RegionIntersection
                        );
                    hv_PinRow.Dispose(); hv_PinCol.Dispose(); hv_PinRadius.Dispose();
                    HOperatorSet.InnerCircle(ho_RegionIntersection, out hv_PinRow, out hv_PinCol,
                        out hv_PinRadius);
                    hv_A.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_A = (hv_PinRadius * hv_PixelSize) * 0.001;
                    }
                    if ((int)(new HTuple((((hv_PinRadius * hv_PixelSize) * 0.001)).TupleGreaterEqual(
                        hv_PinR))) != 0)
                    {
                        break;
                    }
                }
                if ((int)(new HTuple((((hv_PinRadius * hv_PixelSize) * 0.001)).TupleLess(hv_PinR))) != 0)
                {

                    //ErrorMsg := [ErrorMsg,'Pin量測失敗，影像異常']
                }
                ho_PinCircle.Dispose();
                HOperatorSet.GenCircleContourXld(out ho_PinCircle, hv_PinRow, hv_PinCol, hv_PinRadius,
                    0, 6.28318, "positive", 1);



                hv_Vh.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Vh = ((hv_CRow - ((hv_Row01 + hv_Row02) * 0.5)) * hv_PixelSize) * 0.001;
                }
                //*Vh:=(CRow-(b1Row+b2Row)*0.5)*PixelSize*0.001
                hv_Vw.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Vw = ((hv_b2Col - hv_b1Col) * hv_PixelSize) * 0.001;
                }
                hv_Vr.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Vr = hv_CircleR * 0.001;
                }
                hv_P1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_P1 = ((((hv_b1Row + hv_b2Row) * 0.5) - (hv_PinRow - hv_PinRadius)) * hv_PixelSize) * 0.001;
                }
                hv_P2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_P2 = (((hv_CRow - hv_PinRow) + hv_PinRadius) * hv_PixelSize) * 0.001;
                }
                hv_AngV.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_AngV = hv_AngV_rad.TupleDeg()
                        ;
                }

                //-----------------------------------------
                //計算肩圓
                //VR1左開口點g11 g12(左邊的右上角)

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_g11Lines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_g11Lines, hv_Row1_RU + (hv_MeaLength * ((((((-hv_b1Ang) + hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col1_RU - (hv_MeaLength * ((((((-hv_b1Ang) + hv_VRAng)).TupleRad()
                        )).TupleCos())), hv_Row1_RU - (hv_MeaLength * ((((((-hv_b1Ang) + hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col1_RU + (hv_MeaLength * ((((((-hv_b1Ang) + hv_VRAng)).TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CutRow_g11.Dispose(); hv_CutCol_g11.Dispose(); hv_g11Row_roughly.Dispose(); hv_g11Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_g11Lines, ho_Reg1, out hv_MinDistance1, out hv_CutRow_g11,
                    out hv_CutCol_g11, out hv_g11Row_roughly, out hv_g11Col_roughly);


                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_g11Row.Dispose(); hv_g11Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_CutRow_g11, hv_CutCol_g11,
                        hv_b1Ang - hv_VRAng, hv_MinDistance1, hv_Sigma, hv_Amp, hv_MeasureWidth,
                        hv_MeasureGap, out hv_g11Row, out hv_g11Col);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_g12Lines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_g12Lines, hv_Row1_RU + (hv_MeaLength * ((((((-hv_b1Ang) - hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col1_RU - (hv_MeaLength * ((((((-hv_b1Ang) - hv_VRAng)).TupleRad()
                        )).TupleCos())), hv_Row1_RU - (hv_MeaLength * ((((((-hv_b1Ang) - hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col1_RU + (hv_MeaLength * ((((((-hv_b1Ang) - hv_VRAng)).TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CutRow_g12.Dispose(); hv_CutCol_g12.Dispose(); hv_g12Row_roughly.Dispose(); hv_g12Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_g12Lines, ho_Reg1, out hv_MinDistance1, out hv_CutRow_g12,
                    out hv_CutCol_g12, out hv_g12Row_roughly, out hv_g12Col_roughly);
                ho_g11.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_g11, hv_g11Row, hv_g11Col, 30, 0);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_g12Row.Dispose(); hv_g12Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_CutRow_g12, hv_CutCol_g12,
                        hv_b1Ang + hv_VRAng, hv_MinDistance1, hv_Sigma, hv_Amp, hv_MeasureWidth,
                        hv_MeasureGap, out hv_g12Row, out hv_g12Col);
                }
                ho_g12.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_g12, hv_g12Row, hv_g12Col, 30, 0);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_CircleVR1.Dispose(); hv_VR1Row.Dispose(); hv_VR1Col.Dispose(); hv_VR1.Dispose();
                    GetCircleCenterFrom3Point(out ho_CircleVR1, ((hv_g11Row.TupleConcat(hv_g12Row))).TupleConcat(
                        hv_b1Row), ((hv_g11Col.TupleConcat(hv_g12Col))).TupleConcat(hv_b1Col),
                        hv_PixelSize * 0.001, out hv_VR1Row, out hv_VR1Col, out hv_VR1);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Cross1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_Cross1, ((hv_g11Row.TupleConcat(hv_g12Row))).TupleConcat(
                        hv_b1Row), ((hv_g11Col.TupleConcat(hv_g12Col))).TupleConcat(hv_b1Col),
                        6, hv_Angle1);
                }
                //GetCircleCenterFrom3Point (CircleVR1, [g11Row,bu11Row,b1Row], [g11Col,bu11Col,b1Col], PixelSize*0.001, VR1Row, VR1Col, VR1)
                //GetCircleCenterFrom3Point (CircleVR1, [g11Row,g12Row,bu11Row], [g11Col,g12Col,bu11Col], PixelSize*0.001, VR1Row, VR1Col, VR1)

                if ((int)(new HTuple(hv_VR1.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "VR1量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }

                //VR2右開口點g21 g22(右邊的左上角)
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_g21Lines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_g21Lines, hv_Row2_RU + (hv_MeaLength * ((((((-hv_b2Ang) - hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col2_RU - (hv_MeaLength * ((((((-hv_b2Ang) - hv_VRAng)).TupleRad()
                        )).TupleCos())), hv_Row2_RU - (hv_MeaLength * ((((((-hv_b2Ang) - hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col2_RU + (hv_MeaLength * ((((((-hv_b2Ang) - hv_VRAng)).TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CutRow_g21.Dispose(); hv_CutCol_g21.Dispose(); hv_g21Row_roughly.Dispose(); hv_g21Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_g21Lines, ho_Reg2, out hv_MinDistance1, out hv_CutRow_g21,
                    out hv_CutCol_g21, out hv_g21Row_roughly, out hv_g21Col_roughly);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_g21Row.Dispose(); hv_g21Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_CutRow_g21, hv_CutCol_g21,
                        hv_b2Ang + hv_VRAng, hv_MinDistance1, hv_Sigma, hv_Amp, hv_MeasureWidth,
                        hv_MeasureGap, out hv_g21Row, out hv_g21Col);
                }

                ho_g21.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_g21, hv_g21Row, hv_g21Col, 30, 0);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_g22Lines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_g22Lines, hv_Row2_RU + (hv_MeaLength * ((((((-hv_b2Ang) + hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col2_RU - (hv_MeaLength * ((((((-hv_b2Ang) + hv_VRAng)).TupleRad()
                        )).TupleCos())), hv_Row2_RU - (hv_MeaLength * ((((((-hv_b2Ang) + hv_VRAng)).TupleRad()
                        )).TupleSin())), hv_Col2_RU + (hv_MeaLength * ((((((-hv_b2Ang) + hv_VRAng)).TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CutRow_g22.Dispose(); hv_CutCol_g22.Dispose(); hv_g22Row_roughly.Dispose(); hv_g22Col_roughly.Dispose();
                HOperatorSet.DistanceRrMin(ho_g22Lines, ho_Reg2, out hv_MinDistance1, out hv_CutRow_g22,
                    out hv_CutCol_g22, out hv_g22Row_roughly, out hv_g22Col_roughly);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_g22Row.Dispose(); hv_g22Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut2, hv_Range, hv_CutRow_g22, hv_CutCol_g22,
                        hv_b2Ang - hv_VRAng, hv_MinDistance1, hv_Sigma, hv_Amp, hv_MeasureWidth,
                        hv_MeasureGap, out hv_g22Row, out hv_g22Col);
                }

                ho_g22.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_g22, hv_g22Row, hv_g22Col, 30, 0);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_CircleVR2.Dispose(); hv_VR2Row.Dispose(); hv_VR2Col.Dispose(); hv_VR2.Dispose();
                    GetCircleCenterFrom3Point(out ho_CircleVR2, ((hv_g21Row.TupleConcat(hv_g22Row))).TupleConcat(
                        hv_b2Row), ((hv_g21Col.TupleConcat(hv_g22Col))).TupleConcat(hv_b2Col),
                        hv_PixelSize * 0.001, out hv_VR2Row, out hv_VR2Col, out hv_VR2);
                }
                //GetCircleCenterFrom3Point (CircleVR2, [g21Row,bu21Row,b2Row], [g21Col,bu21Col,b2Col], PixelSize*0.001, VR2Row, VR2Col, VR2)
                //GetCircleCenterFrom3Point (CircleVR2, [g21Row,g22Row,bu21Row], [g21Col,g22Col,bu21Col], PixelSize*0.001, VR2Row, VR2Col, VR2)
                if ((int)(new HTuple(hv_VR2.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "VR2量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }


                //-----畫上結果------
                hv_CrossSize.Dispose();
                hv_CrossSize = 10;
                ho_C.Dispose();
                GenCross(out ho_C, hv_CrossSize, hv_CRow, hv_CCol);
                ho_b2.Dispose();
                GenCross(out ho_b2, hv_CrossSize, hv_b2Row, hv_b2Col);
                ho_b1.Dispose();
                GenCross(out ho_b1, hv_CrossSize, hv_b1Row, hv_b1Col);
                ho_g11.Dispose();
                GenCross(out ho_g11, hv_CrossSize, hv_g11Row, hv_g11Col);
                ho_g22.Dispose();
                GenCross(out ho_g22, hv_CrossSize, hv_g22Row, hv_g22Col);
                ho_g12.Dispose();
                GenCross(out ho_g12, hv_CrossSize, hv_g12Row, hv_g12Col);
                ho_g21.Dispose();
                GenCross(out ho_g21, hv_CrossSize, hv_g21Row, hv_g21Col);
                ho_bu11.Dispose();
                GenCross(out ho_bu11, 3, hv_bu11Row, hv_bu11Col);
                ho_bu12.Dispose();
                GenCross(out ho_bu12, 3, hv_bu12Row, hv_bu12Col);
                ho_bu21.Dispose();
                GenCross(out ho_bu21, 3, hv_bu21Row, hv_bu21Col);
                ho_bu22.Dispose();
                GenCross(out ho_bu22, 3, hv_bu22Row, hv_bu22Col);
                ho_r.Dispose();
                GenCross(out ho_r, hv_CrossSize, hv_CircleRow, hv_CircleCol);

                //--十字.線
                ho_ShowResult.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ShowResult);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_C, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_b2, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_b1, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_LAng1, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_LAng2, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_r, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_g11, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_g22, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_g12, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_g21, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_bu11, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_bu12, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_bu21, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult, ho_bu22, out ExpTmpOutVar_0);
                    ho_ShowResult.Dispose();
                    ho_ShowResult = ExpTmpOutVar_0;
                }
                ho_Region.Dispose();
                HOperatorSet.GenRegionContourXld(ho_ShowResult, out ho_Region, "margin");
                //--
                //--圓形
                ho_ShowResult2.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ShowResult2);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult2, ho_ContCircle, out ExpTmpOutVar_0);
                    ho_ShowResult2.Dispose();
                    ho_ShowResult2 = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult2, ho_CircleVR1, out ExpTmpOutVar_0);
                    ho_ShowResult2.Dispose();
                    ho_ShowResult2 = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_ShowResult2, ho_CircleVR2, out ExpTmpOutVar_0);
                    ho_ShowResult2.Dispose();
                    ho_ShowResult2 = ExpTmpOutVar_0;
                }
                ho_CircleReg.Dispose();
                HOperatorSet.GenRegionContourXld(ho_ShowResult2, out ho_CircleReg, "margin");
                ho_PinCircleReg.Dispose();
                HOperatorSet.GenRegionContourXld(ho_PinCircle, out ho_PinCircleReg, "margin");
                //---

                hv_Channels.Dispose();
                HOperatorSet.CountChannels(ho_ImageOut2, out hv_Channels);
                ho_ResultImage.Dispose();
                HOperatorSet.CopyImage(ho_ImageOut2, out ho_ResultImage);
                if ((int)(new HTuple(hv_Channels.TupleNotEqual(1))) != 0)
                {
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.Rgb1ToGray(ho_ResultImage, out ExpTmpOutVar_0);
                        ho_ResultImage.Dispose();
                        ho_ResultImage = ExpTmpOutVar_0;
                    }
                }
                //[200,200,200] Pin
                //[255,0,0]CircleReg
                //[0,255,0]Region
                //paint_region (PinCircleReg, ResultImage, ResultImage, [200,200,200], 'margin')
                //paint_region (CircleReg, MultiChannelImage, MultiChannelImage, [255,0,0], 'margin')
                //paint_region (Region, ResultImage, ResultImage, [0,255,0], 'margin')
                //R
                ho_R.Dispose();
                HOperatorSet.PaintRegion(ho_PinCircleReg, ho_ResultImage, out ho_R, 200, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_CircleReg, ho_R, out ExpTmpOutVar_0, 255, "margin");
                    ho_R.Dispose();
                    ho_R = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_Region, ho_R, out ExpTmpOutVar_0, 0, "margin");
                    ho_R.Dispose();
                    ho_R = ExpTmpOutVar_0;
                }
                //G
                ho_G.Dispose();
                HOperatorSet.PaintRegion(ho_PinCircleReg, ho_ResultImage, out ho_G, 200, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_CircleReg, ho_G, out ExpTmpOutVar_0, 0, "margin");
                    ho_G.Dispose();
                    ho_G = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_Region, ho_G, out ExpTmpOutVar_0, 255, "margin");
                    ho_G.Dispose();
                    ho_G = ExpTmpOutVar_0;
                }
                //B
                ho_B.Dispose();
                HOperatorSet.PaintRegion(ho_PinCircleReg, ho_ResultImage, out ho_B, 200, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_CircleReg, ho_B, out ExpTmpOutVar_0, 0, "margin");
                    ho_B.Dispose();
                    ho_B = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_Region, ho_B, out ExpTmpOutVar_0, 0, "margin");
                    ho_B.Dispose();
                    ho_B = ExpTmpOutVar_0;
                }

                ho_ResultImage.Dispose();
                HOperatorSet.Compose3(ho_R, ho_G, ho_B, out ho_ResultImage);
                //-------------------

                //===顯示=====
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.ClearWindow(HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetLineWidth(HDevWindowStack.GetActive(), 1);
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_OrgImage, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                }

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_VhLine.Dispose();
                    gen_arrow_contour_xld(out ho_VhLine, (hv_Row01 + hv_Row02) * 0.5, 0, (hv_Row01 + hv_Row02) * 0.5,
                        hv_Width, 0, 0);
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_VhLine, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_C, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_b2, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_b1, HDevWindowStack.GetActive());
                }

                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_LAng1, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_LAng2, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_f1, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_f2, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_ContCircle, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_CircleVR1, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_CircleVR2, HDevWindowStack.GetActive());
                }

                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_g11, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_g22, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_g12, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_g21, HDevWindowStack.GetActive());
                }

                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_bu11, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_bu12, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_bu21, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_bu22, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "gray");
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_PinCircle, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        HOperatorSet.DispText(HDevWindowStack.GetActive(), (((((((((((((("Vh = " + hv_Vh)).TupleConcat(
                            "Vw = " + hv_Vw))).TupleConcat("Vr = " + hv_Vr))).TupleConcat("AngV = " + hv_AngV))).TupleConcat(
                            "P1 = " + hv_P1))).TupleConcat("P2 = " + hv_P2))).TupleConcat("VR1 = " + hv_VR1))).TupleConcat(
                            "VR2 = " + hv_VR2), "window", 10, 10, "black", new HTuple(), new HTuple());
                    }
                }
                //-------
                ho_ImageOut.Dispose();
                ho_ImageAffineTrans.Dispose();
                ho_Image3_crop.Dispose();
                ho_Region1.Dispose();
                ho_SelectedRegions.Dispose();
                ho_ImageReduced.Dispose();
                ho_Image2.Dispose();
                ho_ImageResult1.Dispose();
                ho_Image1.Dispose();
                ho_Domain.Dispose();
                ho_ImageResult2.Dispose();
                ho_ImageOut2.Dispose();
                ho_WhiteReg.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_f1.Dispose();
                ho_C.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_RegBlack.Dispose();
                ho_RegionTrans.Dispose();
                ho_Reg1.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Reg2.Dispose();
                ho_ConnectedRegions2.Dispose();
                ho_RegionLines1.Dispose();
                ho_b1.Dispose();
                ho_RegionLines2.Dispose();
                ho_b2.Dispose();
                ho_Cross.Dispose();
                ho_bu11.Dispose();
                ho_bu12.Dispose();
                ho_bu21.Dispose();
                ho_bu22.Dispose();
                ho_LAng2.Dispose();
                ho_LAng1.Dispose();
                ho_f2.Dispose();
                ho_ContCircle.Dispose();
                ho_Rectangle.Dispose();
                ho_RegionIntersection.Dispose();
                ho_PinCircle.Dispose();
                ho_g11Lines.Dispose();
                ho_g12Lines.Dispose();
                ho_g11.Dispose();
                ho_g12.Dispose();
                ho_CircleVR1.Dispose();
                ho_Cross1.Dispose();
                ho_g21Lines.Dispose();
                ho_g21.Dispose();
                ho_g22Lines.Dispose();
                ho_g22.Dispose();
                ho_CircleVR2.Dispose();
                ho_r.Dispose();
                ho_ShowResult.Dispose();
                ho_Region.Dispose();
                ho_ShowResult2.Dispose();
                ho_CircleReg.Dispose();
                ho_PinCircleReg.Dispose();
                ho_R.Dispose();
                ho_G.Dispose();
                ho_B.Dispose();
                ho_VhLine.Dispose();

                hv_GrayMin_COPY_INP_TMP.Dispose();
                hv_ErrorMsgOut.Dispose();
                hv_ResizeOut.Dispose();
                hv_Range.Dispose();
                hv_Sigma.Dispose();
                hv_Amp.Dispose();
                hv_MeasureWidth.Dispose();
                hv_MeasureGap.Dispose();
                hv_WidthImg.Dispose();
                hv_HeightImg.Dispose();
                hv_NotchModelID.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_Angle.Dispose();
                hv_Scale.Dispose();
                hv_Score.Dispose();
                hv_Model.Dispose();
                hv_HomMat2D.Dispose();
                hv_Width1.Dispose();
                hv_Height1.Dispose();
                hv_crop_x.Dispose();
                hv_crop_y.Dispose();
                hv_Width2.Dispose();
                hv_Height2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Indices3.Dispose();
                hv_Rows.Dispose();
                hv_Columns.Dispose();
                hv_Indices.Dispose();
                hv_Indices1.Dispose();
                hv_Indices2.Dispose();
                hv_CenterIdx.Dispose();
                hv_CenterCol.Dispose();
                hv_CenterRow.Dispose();
                hv_CRow.Dispose();
                hv_CCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Area1.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices4.Dispose();
                hv_Area2.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Indices5.Dispose();
                hv_Reg1Row1.Dispose();
                hv_Reg1Col1.Dispose();
                hv_Reg1Row2.Dispose();
                hv_Reg1Col2.Dispose();
                hv_Reg2Row1.Dispose();
                hv_Reg2Col1.Dispose();
                hv_Reg2Row2.Dispose();
                hv_Reg2Col2.Dispose();
                hv_MeaLength.Dispose();
                hv_Row1_RU.Dispose();
                hv_Col1_RU.Dispose();
                hv_MinDistance1.Dispose();
                hv_Row_CutL.Dispose();
                hv_Col_CutL.Dispose();
                hv_b1Row_roughly.Dispose();
                hv_b1Col_roughly.Dispose();
                hv_b1Row.Dispose();
                hv_b1Col.Dispose();
                hv_Row2_RU.Dispose();
                hv_Col2_RU.Dispose();
                hv_MinDistance2.Dispose();
                hv_Row_CutR.Dispose();
                hv_Col_CutR.Dispose();
                hv_b2Row_roughly.Dispose();
                hv_b2Col_roughly.Dispose();
                hv_b2Row.Dispose();
                hv_b2Col.Dispose();
                hv_Row01.Dispose();
                hv_Column11.Dispose();
                hv_Row21.Dispose();
                hv_Column21.Dispose();
                hv_bu11Row1.Dispose();
                hv_bu11Col1.Dispose();
                hv_bu11Row2.Dispose();
                hv_bu11Col2.Dispose();
                hv_bu11Row.Dispose();
                hv_bu11Col.Dispose();
                hv_bu12Row1.Dispose();
                hv_bu12Row2.Dispose();
                hv_bu12Row.Dispose();
                hv_bu12Col.Dispose();
                hv_Row02.Dispose();
                hv_bu21Row1.Dispose();
                hv_bu21Col1.Dispose();
                hv_bu21Row2.Dispose();
                hv_bu21Col2.Dispose();
                hv_bu21Row.Dispose();
                hv_bu21Col.Dispose();
                hv_bu22Row1.Dispose();
                hv_bu22Row2.Dispose();
                hv_bu22Row.Dispose();
                hv_bu22Col.Dispose();
                hv_AngV_rad.Dispose();
                hv_Angle2.Dispose();
                hv_Angle1.Dispose();
                hv_Length.Dispose();
                hv_ARow.Dispose();
                hv_AColumn.Dispose();
                hv_IsOverlapping.Dispose();
                hv_f1Row.Dispose();
                hv_f1Col.Dispose();
                hv_f2Row.Dispose();
                hv_f2Col.Dispose();
                hv_CircleRow.Dispose();
                hv_CircleCol.Dispose();
                hv_CircleR.Dispose();
                hv_Row13.Dispose();
                hv_Column13.Dispose();
                hv_Row22.Dispose();
                hv_Column22.Dispose();
                hv_i.Dispose();
                hv_PinRow.Dispose();
                hv_PinCol.Dispose();
                hv_PinRadius.Dispose();
                hv_A.Dispose();
                hv_CutRow_g11.Dispose();
                hv_CutCol_g11.Dispose();
                hv_g11Row_roughly.Dispose();
                hv_g11Col_roughly.Dispose();
                hv_g11Row.Dispose();
                hv_g11Col.Dispose();
                hv_CutRow_g12.Dispose();
                hv_CutCol_g12.Dispose();
                hv_g12Row_roughly.Dispose();
                hv_g12Col_roughly.Dispose();
                hv_g12Row.Dispose();
                hv_g12Col.Dispose();
                hv_VR1Row.Dispose();
                hv_VR1Col.Dispose();
                hv_CutRow_g21.Dispose();
                hv_CutCol_g21.Dispose();
                hv_g21Row_roughly.Dispose();
                hv_g21Col_roughly.Dispose();
                hv_g21Row.Dispose();
                hv_g21Col.Dispose();
                hv_CutRow_g22.Dispose();
                hv_CutCol_g22.Dispose();
                hv_g22Row_roughly.Dispose();
                hv_g22Col_roughly.Dispose();
                hv_g22Row.Dispose();
                hv_g22Col.Dispose();
                hv_VR2Row.Dispose();
                hv_VR2Col.Dispose();
                hv_CrossSize.Dispose();
                hv_Channels.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_ImageOut.Dispose();
                ho_ImageAffineTrans.Dispose();
                ho_Image3_crop.Dispose();
                ho_Region1.Dispose();
                ho_SelectedRegions.Dispose();
                ho_ImageReduced.Dispose();
                ho_Image2.Dispose();
                ho_ImageResult1.Dispose();
                ho_Image1.Dispose();
                ho_Domain.Dispose();
                ho_ImageResult2.Dispose();
                ho_ImageOut2.Dispose();
                ho_WhiteReg.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_f1.Dispose();
                ho_C.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_RegBlack.Dispose();
                ho_RegionTrans.Dispose();
                ho_Reg1.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Reg2.Dispose();
                ho_ConnectedRegions2.Dispose();
                ho_RegionLines1.Dispose();
                ho_b1.Dispose();
                ho_RegionLines2.Dispose();
                ho_b2.Dispose();
                ho_Cross.Dispose();
                ho_bu11.Dispose();
                ho_bu12.Dispose();
                ho_bu21.Dispose();
                ho_bu22.Dispose();
                ho_LAng2.Dispose();
                ho_LAng1.Dispose();
                ho_f2.Dispose();
                ho_ContCircle.Dispose();
                ho_Rectangle.Dispose();
                ho_RegionIntersection.Dispose();
                ho_PinCircle.Dispose();
                ho_g11Lines.Dispose();
                ho_g12Lines.Dispose();
                ho_g11.Dispose();
                ho_g12.Dispose();
                ho_CircleVR1.Dispose();
                ho_Cross1.Dispose();
                ho_g21Lines.Dispose();
                ho_g21.Dispose();
                ho_g22Lines.Dispose();
                ho_g22.Dispose();
                ho_CircleVR2.Dispose();
                ho_r.Dispose();
                ho_ShowResult.Dispose();
                ho_Region.Dispose();
                ho_ShowResult2.Dispose();
                ho_CircleReg.Dispose();
                ho_PinCircleReg.Dispose();
                ho_R.Dispose();
                ho_G.Dispose();
                ho_B.Dispose();
                ho_VhLine.Dispose();

                hv_GrayMin_COPY_INP_TMP.Dispose();
                hv_ErrorMsgOut.Dispose();
                hv_ResizeOut.Dispose();
                hv_Range.Dispose();
                hv_Sigma.Dispose();
                hv_Amp.Dispose();
                hv_MeasureWidth.Dispose();
                hv_MeasureGap.Dispose();
                hv_WidthImg.Dispose();
                hv_HeightImg.Dispose();
                hv_NotchModelID.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_Angle.Dispose();
                hv_Scale.Dispose();
                hv_Score.Dispose();
                hv_Model.Dispose();
                hv_HomMat2D.Dispose();
                hv_Width1.Dispose();
                hv_Height1.Dispose();
                hv_crop_x.Dispose();
                hv_crop_y.Dispose();
                hv_Width2.Dispose();
                hv_Height2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Indices3.Dispose();
                hv_Rows.Dispose();
                hv_Columns.Dispose();
                hv_Indices.Dispose();
                hv_Indices1.Dispose();
                hv_Indices2.Dispose();
                hv_CenterIdx.Dispose();
                hv_CenterCol.Dispose();
                hv_CenterRow.Dispose();
                hv_CRow.Dispose();
                hv_CCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Area1.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices4.Dispose();
                hv_Area2.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Indices5.Dispose();
                hv_Reg1Row1.Dispose();
                hv_Reg1Col1.Dispose();
                hv_Reg1Row2.Dispose();
                hv_Reg1Col2.Dispose();
                hv_Reg2Row1.Dispose();
                hv_Reg2Col1.Dispose();
                hv_Reg2Row2.Dispose();
                hv_Reg2Col2.Dispose();
                hv_MeaLength.Dispose();
                hv_Row1_RU.Dispose();
                hv_Col1_RU.Dispose();
                hv_MinDistance1.Dispose();
                hv_Row_CutL.Dispose();
                hv_Col_CutL.Dispose();
                hv_b1Row_roughly.Dispose();
                hv_b1Col_roughly.Dispose();
                hv_b1Row.Dispose();
                hv_b1Col.Dispose();
                hv_Row2_RU.Dispose();
                hv_Col2_RU.Dispose();
                hv_MinDistance2.Dispose();
                hv_Row_CutR.Dispose();
                hv_Col_CutR.Dispose();
                hv_b2Row_roughly.Dispose();
                hv_b2Col_roughly.Dispose();
                hv_b2Row.Dispose();
                hv_b2Col.Dispose();
                hv_Row01.Dispose();
                hv_Column11.Dispose();
                hv_Row21.Dispose();
                hv_Column21.Dispose();
                hv_bu11Row1.Dispose();
                hv_bu11Col1.Dispose();
                hv_bu11Row2.Dispose();
                hv_bu11Col2.Dispose();
                hv_bu11Row.Dispose();
                hv_bu11Col.Dispose();
                hv_bu12Row1.Dispose();
                hv_bu12Row2.Dispose();
                hv_bu12Row.Dispose();
                hv_bu12Col.Dispose();
                hv_Row02.Dispose();
                hv_bu21Row1.Dispose();
                hv_bu21Col1.Dispose();
                hv_bu21Row2.Dispose();
                hv_bu21Col2.Dispose();
                hv_bu21Row.Dispose();
                hv_bu21Col.Dispose();
                hv_bu22Row1.Dispose();
                hv_bu22Row2.Dispose();
                hv_bu22Row.Dispose();
                hv_bu22Col.Dispose();
                hv_AngV_rad.Dispose();
                hv_Angle2.Dispose();
                hv_Angle1.Dispose();
                hv_Length.Dispose();
                hv_ARow.Dispose();
                hv_AColumn.Dispose();
                hv_IsOverlapping.Dispose();
                hv_f1Row.Dispose();
                hv_f1Col.Dispose();
                hv_f2Row.Dispose();
                hv_f2Col.Dispose();
                hv_CircleRow.Dispose();
                hv_CircleCol.Dispose();
                hv_CircleR.Dispose();
                hv_Row13.Dispose();
                hv_Column13.Dispose();
                hv_Row22.Dispose();
                hv_Column22.Dispose();
                hv_i.Dispose();
                hv_PinRow.Dispose();
                hv_PinCol.Dispose();
                hv_PinRadius.Dispose();
                hv_A.Dispose();
                hv_CutRow_g11.Dispose();
                hv_CutCol_g11.Dispose();
                hv_g11Row_roughly.Dispose();
                hv_g11Col_roughly.Dispose();
                hv_g11Row.Dispose();
                hv_g11Col.Dispose();
                hv_CutRow_g12.Dispose();
                hv_CutCol_g12.Dispose();
                hv_g12Row_roughly.Dispose();
                hv_g12Col_roughly.Dispose();
                hv_g12Row.Dispose();
                hv_g12Col.Dispose();
                hv_VR1Row.Dispose();
                hv_VR1Col.Dispose();
                hv_CutRow_g21.Dispose();
                hv_CutCol_g21.Dispose();
                hv_g21Row_roughly.Dispose();
                hv_g21Col_roughly.Dispose();
                hv_g21Row.Dispose();
                hv_g21Col.Dispose();
                hv_CutRow_g22.Dispose();
                hv_CutCol_g22.Dispose();
                hv_g22Row_roughly.Dispose();
                hv_g22Col_roughly.Dispose();
                hv_g22Row.Dispose();
                hv_g22Col.Dispose();
                hv_VR2Row.Dispose();
                hv_VR2Col.Dispose();
                hv_CrossSize.Dispose();
                hv_Channels.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.4

        /// <summary>
        /// 量測1D邊緣
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ResultCross">
        /// <para>輸出座標點</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_Y1">
        /// <para>輸入量測線起始點Y1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X1">
        /// <para>輸入量測線起始點X1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Y2">
        /// <para>輸入量測線起始點Y2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X2">
        /// <para>輸入量測線起始點X2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Width">
        /// <para>輸入量測寬度</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Amp">
        /// <para>黑白震幅</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Sigma">
        /// <para>高斯平滑參數</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// <para>範圍: 1.000000 ＜= hv_Sigma ＜= 11.000000</para>
        /// </param>
        /// <param name = "hv_ResultY">
        /// <para>結果輸出座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ResultX">
        /// <para>結果輸出座標X</para>
        /// <para>型態: </para>
        /// </param>
        public static void MeasurePosNegative(HObject ho_Image, out HObject ho_ResultCross, HTuple hv_Y1,
                HTuple hv_X1, HTuple hv_Y2, HTuple hv_X2, HTuple hv_Width, HTuple hv_Amp, HTuple hv_Sigma,
                out HTuple hv_ResultY, out HTuple hv_ResultX)
        {
            // Local iconic variables 

            HObject ho_Rectangle;

            // Local control variables 

            HTuple hv_TmpCtrl_Row = new HTuple(), hv_TmpCtrl_Column = new HTuple();
            HTuple hv_TmpCtrl_Dr = new HTuple(), hv_TmpCtrl_Dc = new HTuple();
            HTuple hv_TmpCtrl_Phi = new HTuple(), hv_TmpCtrl_Len1 = new HTuple();
            HTuple hv_TmpCtrl_Len2 = new HTuple(), hv_Height = new HTuple();
            HTuple hv_MsrHandle_Measure_02_0 = new HTuple(), hv_Amplitude_Measure_02_0 = new HTuple();
            HTuple hv_Distance_Measure_02_0 = new HTuple();
            HTuple hv_Width_COPY_INP_TMP = new HTuple(hv_Width);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ResultCross);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            hv_ResultY = new HTuple();
            hv_ResultX = new HTuple();
            try
            {
                //20230213 v1.0 量測1D邊緣
                //20230214 v1.2 新增參數:量測角度
                //20230221 v1.3 負向量測
                hv_TmpCtrl_Row.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Row = 0.5 * (hv_Y1 + hv_Y2);
                }
                hv_TmpCtrl_Column.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Column = 0.5 * (hv_X1 + hv_X2);
                }
                hv_TmpCtrl_Dr.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dr = hv_Y1 - hv_Y2;
                }
                hv_TmpCtrl_Dc.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dc = hv_X2 - hv_X1;
                }
                hv_TmpCtrl_Phi.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Phi = hv_TmpCtrl_Dr.TupleAtan2(
                        hv_TmpCtrl_Dc);
                }
                hv_TmpCtrl_Len1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Len1 = 0.5 * ((((hv_TmpCtrl_Dr * hv_TmpCtrl_Dr) + (hv_TmpCtrl_Dc * hv_TmpCtrl_Dc))).TupleSqrt()
                        );
                }
                hv_TmpCtrl_Len2.Dispose();
                hv_TmpCtrl_Len2 = new HTuple(hv_Width_COPY_INP_TMP);
                ho_ResultCross.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ResultCross);
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle2(out ho_Rectangle, hv_TmpCtrl_Row, hv_TmpCtrl_Column,
                    hv_TmpCtrl_Phi, hv_TmpCtrl_Len1, hv_TmpCtrl_Len2);
                hv_Width_COPY_INP_TMP.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width_COPY_INP_TMP, out hv_Height);
                hv_MsrHandle_Measure_02_0.Dispose();
                HOperatorSet.GenMeasureRectangle2(hv_TmpCtrl_Row, hv_TmpCtrl_Column, hv_TmpCtrl_Phi,
                    hv_TmpCtrl_Len1, hv_TmpCtrl_Len2, hv_Width_COPY_INP_TMP, hv_Height, "nearest_neighbor",
                    out hv_MsrHandle_Measure_02_0);
                hv_ResultY.Dispose(); hv_ResultX.Dispose(); hv_Amplitude_Measure_02_0.Dispose(); hv_Distance_Measure_02_0.Dispose();
                HOperatorSet.MeasurePos(ho_Image, hv_MsrHandle_Measure_02_0, hv_Sigma, hv_Amp,
                    "negative", "first", out hv_ResultY, out hv_ResultX, out hv_Amplitude_Measure_02_0,
                    out hv_Distance_Measure_02_0);
                ho_ResultCross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_ResultCross, hv_ResultY, hv_ResultX,
                    6, 0.785398);
                HOperatorSet.CloseMeasure(hv_MsrHandle_Measure_02_0);
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                throw HDevExpDefaultException;
            }
        }// v1.3 

        // Chapter: Graphics / Text
        // Short Description: Set font independent of OS 


        // Local procedures 
        /// <summary>
        /// 
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_Range">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CutRow">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CutCol">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Ang">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_MinDistance">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_sigma">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Amp">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_MeasureWidth">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_MeasureGap">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Row">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Col">
        /// <para>型態: </para>
        /// </param>
        public static void CutLineMinDistanceAndPnt(HObject ho_Image, HTuple hv_Range, HTuple hv_CutRow,
            HTuple hv_CutCol, HTuple hv_Ang, HTuple hv_MinDistance, HTuple hv_sigma, HTuple hv_Amp,
            HTuple hv_MeasureWidth, HTuple hv_MeasureGap, out HTuple hv_Row, out HTuple hv_Col)
        {




            // Local iconic variables 

            HObject ho_Rectangle3 = null, ho_ResultCross;
            HObject ho_Cross;

            // Local control variables 

            HTuple hv_ResultB1Cols = new HTuple(), hv_ResultB1Rows = new HTuple();
            HTuple hv_Distances = new HTuple(), hv_ii = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_MsrHandle_Measure_02_0 = new HTuple(), hv_ResultY = new HTuple();
            HTuple hv_ResultX = new HTuple(), hv_Amplitude_Measure_02_0 = new HTuple();
            HTuple hv_Distance_Measure_02_0 = new HTuple(), hv_Distance = new HTuple();
            HTuple hv_Min = new HTuple(), hv_Function = new HTuple();
            HTuple hv_SmoothedFunction = new HTuple(), hv_XValues = new HTuple();
            HTuple hv_DistancesSmooth = new HTuple(), hv_Indices6 = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Rectangle3);
            HOperatorSet.GenEmptyObj(out ho_ResultCross);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            hv_Row = new HTuple();
            hv_Col = new HTuple();
            try
            {
                //2023/03/09 v1.0
                hv_ResultB1Cols.Dispose();
                hv_ResultB1Cols = new HTuple();
                hv_ResultB1Rows.Dispose();
                hv_ResultB1Rows = new HTuple();
                hv_Distances.Dispose();
                hv_Distances = new HTuple();

                HTuple end_val5 = -hv_Range;
                HTuple step_val5 = -hv_MeasureGap;
                for (hv_ii = hv_Range; hv_ii.Continue(end_val5, step_val5); hv_ii = hv_ii.TupleAdd(step_val5))
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle3.Dispose();
                        HOperatorSet.GenRectangle2(out ho_Rectangle3, hv_CutRow + (hv_ii * (((((-hv_Ang)).TupleRad()
                            )).TupleSin())), hv_CutCol - (hv_ii * (((((-hv_Ang)).TupleRad())).TupleCos()
                            )), (((-hv_Ang) - 90)).TupleRad(), hv_MinDistance * 10, 7);
                    }

                    ho_ResultCross.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_ResultCross);
                    hv_Width.Dispose(); hv_Height.Dispose();
                    HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_MsrHandle_Measure_02_0.Dispose();
                        HOperatorSet.GenMeasureRectangle2(hv_CutRow + (hv_ii * (((((-hv_Ang)).TupleRad()
                            )).TupleSin())), hv_CutCol - (hv_ii * (((((-hv_Ang)).TupleRad())).TupleCos()
                            )), (((-hv_Ang) - 90)).TupleRad(), hv_MinDistance * 10, hv_MeasureWidth / 2,
                            hv_Width, hv_Height, "nearest_neighbor", out hv_MsrHandle_Measure_02_0);
                    }
                    hv_ResultY.Dispose(); hv_ResultX.Dispose(); hv_Amplitude_Measure_02_0.Dispose(); hv_Distance_Measure_02_0.Dispose();
                    HOperatorSet.MeasurePos(ho_Image, hv_MsrHandle_Measure_02_0, hv_sigma, hv_Amp,
                        "negative", "first", out hv_ResultY, out hv_ResultX, out hv_Amplitude_Measure_02_0,
                        out hv_Distance_Measure_02_0);
                    if ((int)(new HTuple(hv_ResultY.TupleEqual(new HTuple()))) != 0)
                    {
                        continue;
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Distance.Dispose();
                        HOperatorSet.DistancePp(hv_CutRow + (hv_ii * (((((-hv_Ang)).TupleRad())).TupleSin()
                            )), hv_CutCol - (hv_ii * (((((-hv_Ang)).TupleRad())).TupleCos())), hv_ResultY,
                            hv_ResultX, out hv_Distance);
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Distances = hv_Distances.TupleConcat(
                                hv_Distance);
                            hv_Distances.Dispose();
                            hv_Distances = ExpTmpLocalVar_Distances;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ResultB1Cols = hv_ResultB1Cols.TupleConcat(
                                hv_ResultX);
                            hv_ResultB1Cols.Dispose();
                            hv_ResultB1Cols = ExpTmpLocalVar_ResultB1Cols;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ResultB1Rows = hv_ResultB1Rows.TupleConcat(
                                hv_ResultY);
                            hv_ResultB1Rows.Dispose();
                            hv_ResultB1Rows = ExpTmpLocalVar_ResultB1Rows;
                        }
                    }
                    ho_ResultCross.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_ResultCross, hv_ResultY, hv_ResultX,
                        6, 0.785398);
                    HOperatorSet.CloseMeasure(hv_MsrHandle_Measure_02_0);
                }



                hv_Min.Dispose();
                HOperatorSet.TupleMin(hv_Distances, out hv_Min);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Distances = hv_Distances - hv_Min;
                        hv_Distances.Dispose();
                        hv_Distances = ExpTmpLocalVar_Distances;
                    }
                }
                //Create a function from a sequence of y-valus
                hv_Function.Dispose();
                HOperatorSet.CreateFunct1dArray(hv_Distances, out hv_Function);
                //scale_y_funct_1d (Function, 2, 0, Function)
                //Smooth an equidistant 1D function by averaging its values.
                //目前測試最佳均值尺吋 5 Pixel
                hv_SmoothedFunction.Dispose();
                HOperatorSet.SmoothFunct1dMean(hv_Function, 5, 1, out hv_SmoothedFunction);

                hv_XValues.Dispose(); hv_DistancesSmooth.Dispose();
                HOperatorSet.Funct1dToPairs(hv_SmoothedFunction, out hv_XValues, out hv_DistancesSmooth);
                hv_Indices6.Dispose();
                HOperatorSet.TupleSortIndex(hv_DistancesSmooth, out hv_Indices6);


                hv_Row.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Row = hv_ResultB1Rows.TupleSelect(
                        hv_Indices6.TupleSelect(0));
                }
                hv_Col.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Col = hv_ResultB1Cols.TupleSelect(
                        hv_Indices6.TupleSelect(0));
                }
                ho_ResultCross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_ResultCross, hv_Row, hv_Col, 20, 0);

                ho_Cross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross, hv_ResultB1Rows, hv_ResultB1Cols,
                    1, 0.785398);
                ho_Rectangle3.Dispose();
                ho_ResultCross.Dispose();
                ho_Cross.Dispose();

                hv_ResultB1Cols.Dispose();
                hv_ResultB1Rows.Dispose();
                hv_Distances.Dispose();
                hv_ii.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_ResultY.Dispose();
                hv_ResultX.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();
                hv_Distance.Dispose();
                hv_Min.Dispose();
                hv_Function.Dispose();
                hv_SmoothedFunction.Dispose();
                hv_XValues.Dispose();
                hv_DistancesSmooth.Dispose();
                hv_Indices6.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangle3.Dispose();
                ho_ResultCross.Dispose();
                ho_Cross.Dispose();

                hv_ResultB1Cols.Dispose();
                hv_ResultB1Rows.Dispose();
                hv_Distances.Dispose();
                hv_ii.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_ResultY.Dispose();
                hv_ResultX.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();
                hv_Distance.Dispose();
                hv_Min.Dispose();
                hv_Function.Dispose();
                hv_SmoothedFunction.Dispose();
                hv_XValues.Dispose();
                hv_DistancesSmooth.Dispose();
                hv_Indices6.Dispose();

                throw HDevExpDefaultException;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name = "ho_CircleContour">
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_PntRow">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_PntCol">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CircleRow">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CircleCol">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CircleR">
        /// <para>型態: </para>
        /// </param>
        public static void GetCircleCenterFrom3Point(out HObject ho_CircleContour, HTuple hv_PntRow,
                HTuple hv_PntCol, HTuple hv_PixelSize, out HTuple hv_CircleRow, out HTuple hv_CircleCol,
                out HTuple hv_CircleR)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_LinePhi = new HTuple(), hv_CenterPntRow = new HTuple();
            HTuple hv_CenterPntCol = new HTuple(), hv_verticalPhi = new HTuple();
            HTuple hv_EndPointRow = new HTuple(), hv_EndPointCol = new HTuple();
            HTuple hv_LinePhi2 = new HTuple(), hv_CenterPntRow2 = new HTuple();
            HTuple hv_CenterPntCol2 = new HTuple(), hv_verticalPhi2 = new HTuple();
            HTuple hv_EndPointRow2 = new HTuple(), hv_EndPointCol2 = new HTuple();
            HTuple hv_IsOverlapping = new HTuple(), hv_R = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_CircleContour);
            hv_CircleRow = new HTuple();
            hv_CircleCol = new HTuple();
            hv_CircleR = new HTuple();
            try
            {
                //v1.0 20230221 3點定圓心
                ho_CircleContour.Dispose();
                HOperatorSet.GenEmptyObj(out ho_CircleContour);
                hv_CircleRow.Dispose();
                hv_CircleRow = new HTuple();
                hv_CircleCol.Dispose();
                hv_CircleCol = new HTuple();
                hv_CircleR.Dispose();
                hv_CircleR = new HTuple();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinePhi.Dispose();
                    HOperatorSet.LineOrientation(hv_PntRow.TupleSelect(0), hv_PntCol.TupleSelect(
                        0), hv_PntRow.TupleSelect(1), hv_PntCol.TupleSelect(1), out hv_LinePhi);
                }
                hv_CenterPntRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterPntRow = ((hv_PntRow.TupleSelect(
                        0)) + (hv_PntRow.TupleSelect(1))) / 2;
                }
                hv_CenterPntCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterPntCol = ((hv_PntCol.TupleSelect(
                        0)) + (hv_PntCol.TupleSelect(1))) / 2;
                }
                hv_verticalPhi.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_verticalPhi = hv_LinePhi + ((new HTuple(90)).TupleRad()
                        );
                }
                hv_EndPointRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EndPointRow = hv_CenterPntRow - (20 * (hv_verticalPhi.TupleSin()
                        ));
                }
                hv_EndPointCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EndPointCol = hv_CenterPntCol + (20 * (hv_verticalPhi.TupleCos()
                        ));
                }


                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinePhi2.Dispose();
                    HOperatorSet.LineOrientation(hv_PntRow.TupleSelect(0), hv_PntCol.TupleSelect(
                        0), hv_PntRow.TupleSelect(2), hv_PntCol.TupleSelect(2), out hv_LinePhi2);
                }
                hv_CenterPntRow2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterPntRow2 = ((hv_PntRow.TupleSelect(
                        0)) + (hv_PntRow.TupleSelect(2))) / 2;
                }
                hv_CenterPntCol2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterPntCol2 = ((hv_PntCol.TupleSelect(
                        0)) + (hv_PntCol.TupleSelect(2))) / 2;
                }
                hv_verticalPhi2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_verticalPhi2 = hv_LinePhi2 + ((new HTuple(90)).TupleRad()
                        );
                }
                hv_EndPointRow2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EndPointRow2 = hv_CenterPntRow2 - (20 * (hv_verticalPhi2.TupleSin()
                        ));
                }
                hv_EndPointCol2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EndPointCol2 = hv_CenterPntCol2 + (20 * (hv_verticalPhi2.TupleCos()
                        ));
                }
                hv_CircleRow.Dispose(); hv_CircleCol.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_CenterPntRow, hv_CenterPntCol, hv_EndPointRow,
                    hv_EndPointCol, hv_CenterPntRow2, hv_CenterPntCol2, hv_EndPointRow2, hv_EndPointCol2,
                    out hv_CircleRow, out hv_CircleCol, out hv_IsOverlapping);
                if ((int)(new HTuple(hv_CircleRow.TupleEqual(new HTuple()))) != 0)
                {

                    hv_LinePhi.Dispose();
                    hv_CenterPntRow.Dispose();
                    hv_CenterPntCol.Dispose();
                    hv_verticalPhi.Dispose();
                    hv_EndPointRow.Dispose();
                    hv_EndPointCol.Dispose();
                    hv_LinePhi2.Dispose();
                    hv_CenterPntRow2.Dispose();
                    hv_CenterPntCol2.Dispose();
                    hv_verticalPhi2.Dispose();
                    hv_EndPointRow2.Dispose();
                    hv_EndPointCol2.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_R.Dispose();

                    return;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R.Dispose();
                    HOperatorSet.DistancePp(hv_PntRow.TupleSelect(0), hv_PntCol.TupleSelect(0),
                        hv_CircleRow, hv_CircleCol, out hv_R);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_CircleContour.Dispose();
                    HOperatorSet.GenCircleContourXld(out ho_CircleContour, hv_CircleRow, hv_CircleCol,
                        hv_R, 0, (new HTuple(360)).TupleRad(), "positive", 1);
                }
                hv_CircleR.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CircleR = hv_R * hv_PixelSize;
                }

                hv_LinePhi.Dispose();
                hv_CenterPntRow.Dispose();
                hv_CenterPntCol.Dispose();
                hv_verticalPhi.Dispose();
                hv_EndPointRow.Dispose();
                hv_EndPointCol.Dispose();
                hv_LinePhi2.Dispose();
                hv_CenterPntRow2.Dispose();
                hv_CenterPntCol2.Dispose();
                hv_verticalPhi2.Dispose();
                hv_EndPointRow2.Dispose();
                hv_EndPointCol2.Dispose();
                hv_IsOverlapping.Dispose();
                hv_R.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_LinePhi.Dispose();
                hv_CenterPntRow.Dispose();
                hv_CenterPntCol.Dispose();
                hv_verticalPhi.Dispose();
                hv_EndPointRow.Dispose();
                hv_EndPointCol.Dispose();
                hv_LinePhi2.Dispose();
                hv_CenterPntRow2.Dispose();
                hv_CenterPntCol2.Dispose();
                hv_verticalPhi2.Dispose();
                hv_EndPointRow2.Dispose();
                hv_EndPointCol2.Dispose();
                hv_IsOverlapping.Dispose();
                hv_R.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.0

        public static void CheckNotchExist(HObject ho_Image, HTuple hv_NotchModelPath, HTuple hv_minScore, out HTuple hv_Row3, out HTuple hv_Column3)
        {
            HOperatorSet.ReadShapeModel(hv_NotchModelPath, out HTuple hv_NotchModelID);
            HOperatorSet.FindShapeModels(ho_Image, hv_NotchModelID, 0, 180, hv_minScore, 1,
                0.5, "least_squares", 0, 0.9, out hv_Row3, out hv_Column3, out HTuple hv_Angle,
                out HTuple hv_Score, out HTuple hv_Model);

            hv_NotchModelID.Dispose();
            hv_Angle.Dispose();
            hv_Score.Dispose();
            hv_Model.Dispose();
        }
        #endregion

        #region 量測面幅B

        /// <summary>
        /// 量測面幅 TypeB
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ImageOut">
        /// <para>輸出圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>Pixel Size(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_rotateAngle">
        /// <para>初步轉正(統一轉成 wafer在左側之影像)
        /// 
        /// </para>
        /// <para>型態: int</para>
        /// <para>語義: integer</para>
        /// </param>
        /// <param name = "hv_GrayMax">
        /// <para>wafer區域最大灰階罰直</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiY1">
        /// <para>ROI座標(左上Y</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiX1">
        /// <para>ROI座標(左上X</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiY2">
        /// <para>ROI座標(右下Y</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiX2">
        /// <para>ROI座標(右下X</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A1Ang">
        /// <para>輸入 A1點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_A2Ang">
        /// <para>輸入 A2點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_C1Ang">
        /// <para>輸入 C1點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_C2Ang">
        /// <para>輸入 C2點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_bu11">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bv11">
        /// <para>量測斜角的結束值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bu22">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99
        /// 
        /// </para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bv22">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A1">
        /// <para>輸出量測結果 A1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A2">
        /// <para>輸出量測結果 A2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_B1">
        /// <para>輸出量測結果B1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_B2">
        /// <para>輸出量測結果B2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_BC">
        /// <para>輸出量測結果 BC尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_C1">
        /// <para>輸出量測結果C1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_C2">
        /// <para>輸出量測結果 C1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_R1">
        /// <para>輸出量測結果 R1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_R2">
        /// <para>輸出量測結果R2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_t">
        /// <para>輸出量測結果 t 尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_Ang1">
        /// <para>輸出量測結果 Ang1  (0~90度)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_Ang2">
        /// <para>輸出量測結果 Ang2 (0~90度)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_ErrorMsg">
        /// <para>錯誤訊息</para>
        /// <para>型態: string[]</para>
        /// <para>語義: string</para>
        /// </param>
        /// <param name = "hv_Phi_OrgX_OrgY">
        /// <para>wafer偏轉角度(影像上水平),原點座標X，原點座標Y</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_Cir_c1">
        /// <para>輸出可視化參數 C1:=[CenterX,CenterY,R]</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_Cir_c2">
        /// <para>輸出可視化參數 C1:=[CenterX,CenterY,R]</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesX1">
        /// <para>輸出可視化參數:直線起點X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesY1">
        /// <para>輸出可視化參數:直線起點Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesX2">
        /// <para>輸出可視化參數:直線終點X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesY2">
        /// <para>輸出可視化參數:直線終點Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_TextsText">
        /// <para>輸出可視化參數:文字輸出</para>
        /// <para>型態: []</para>
        /// <para>語義: string</para>
        /// </param>
        /// <param name = "hv_TextsX">
        /// <para>輸出可視化參數:文字輸出座標X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_TextsY">
        /// <para>輸出可視化參數:文字輸出座標Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        public static void MeasureWaferEdgeB(HObject ho_Image, out HObject ho_ImageOut, out HObject ho_rotateImage,
            HTuple hv_PixelSize, HTuple hv_rotateAngle, HTuple hv_GrayMax, HTuple hv_RoiY1,
            HTuple hv_RoiX1, HTuple hv_RoiY2, HTuple hv_RoiX2, HTuple hv_A1Ang, HTuple hv_A2Ang,
            HTuple hv_C1Ang, HTuple hv_C2Ang, HTuple hv_bu11, HTuple hv_bv11, HTuple hv_bu22,
            HTuple hv_bv22, HTuple hv_ExAngle, HTuple hv_ScaleW, HTuple hv_ScaleH, HTuple hv_CMeasureNumber,
            out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
            out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
            out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
            out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
            out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
            out HTuple hv_TextsY)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_Regions = null, ho_ConnectedRegions;
            HObject ho_ObjectSelected1, ho_Rectangle1 = null, ho_Rectangle2 = null;
            HObject ho_Position1Region = null, ho_Position2Region = null;
            HObject ho_Rectangle, ho_ImageReduced, ho_Region = null, ho_ConnectedRegions1;
            HObject ho_Cross, ho_bu1, ho_RegionLines, ho_a1, ho_c1;
            HObject ho_a2, ho_c2, ho_Arrow2, ho_bv1, ho_Bu2, ho_bu2;
            HObject ho_Bv2, ho_bv2, ho_b1, ho_b2, ho_MeasureLineBu1 = null;
            HObject ho_MeasureLineBv1 = null, ho_MeasureLineBu2 = null;
            HObject ho_MeasureLineBv2 = null, ho_t1, ho_t2, ho_cc1, ho_cc12;
            HObject ho_cc13, ho_Circle1, ho_Arrow3 = null, ho_ChanferPnt = null;
            HObject ho_Circles = null, ho_Cross1, ho_cc2, ho_cc22, ho_cc23;
            HObject ho_Circle2, ho_Surface1 = null, ho_Surface2 = null;
            HObject ho_line = null, ho_line1 = null, ho_Orig = null, ho_Arrow1 = null;
            HObject ho_OrgLine = null, ho_DrawLines, ho_Arrow = null, ho_CrossH = null;
            HObject ho_CrossV = null, ho_DrawCircles, ho_DupImage, ho_R;
            HObject ho_G, ho_B;

            // Local control variables 

            HTuple hv_show = new HTuple(), hv_ExrPnt_Range = new HTuple();
            HTuple hv_ExrPnt_Sigma = new HTuple(), hv_ExrPnt_Amp = new HTuple();
            HTuple hv_ExrPnt_MeasureWidth = new HTuple(), hv_ExrPnt_MeasureGap = new HTuple();
            HTuple hv_OnePnt_Amp = new HTuple(), hv_OnePnt_MeasureWidth = new HTuple();
            HTuple hv_OnePnt_sigma = new HTuple(), hv_Width1 = new HTuple();
            HTuple hv_Height1 = new HTuple(), hv_UsedThreshold = new HTuple();
            HTuple hv_Area4 = new HTuple(), hv_Row1 = new HTuple();
            HTuple hv_Column1 = new HTuple(), hv_Indices = new HTuple();
            HTuple hv_IsAutoRotate = new HTuple(), hv_RectRow1 = new HTuple();
            HTuple hv_RectColumn1 = new HTuple(), hv_RectRow2 = new HTuple();
            HTuple hv_RectColumn2 = new HTuple(), hv_RectW = new HTuple();
            HTuple hv_RectH = new HTuple(), hv_Area1 = new HTuple();
            HTuple hv_CenterLRow = new HTuple(), hv_CenterLCol = new HTuple();
            HTuple hv_Area3 = new HTuple(), hv_CenterRRow = new HTuple();
            HTuple hv_CenterRCol = new HTuple(), hv_Phi = new HTuple();
            HTuple hv_HomMat2DIdentity = new HTuple(), hv_rotateRow = new HTuple();
            HTuple hv_rotateCol = new HTuple(), hv_HomMat2DRotate = new HTuple();
            HTuple hv_rotateAng = new HTuple(), hv_Area2 = new HTuple();
            HTuple hv_Row4 = new HTuple(), hv_Column4 = new HTuple();
            HTuple hv_Indices3 = new HTuple(), hv_WaferRow1 = new HTuple();
            HTuple hv_WaferCol1 = new HTuple(), hv_WaferRow2 = new HTuple();
            HTuple hv_WaferRCol2 = new HTuple(), hv_Area = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_OriginRow = new HTuple(), hv_OriginCol = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_WaferOriginRow = new HTuple(), hv_WaferOriginCol = new HTuple();
            HTuple hv_RU_row = new HTuple(), hv_RU_col = new HTuple();
            HTuple hv_A1AngOut = new HTuple(), hv_MinDistance1 = new HTuple();
            HTuple hv_A1Row_Cut = new HTuple(), hv_A1Col_Cut = new HTuple();
            HTuple hv_A1Row = new HTuple(), hv_A1Col = new HTuple();
            HTuple hv_C1AngOut = new HTuple(), hv_C1Row_Cut = new HTuple();
            HTuple hv_C1Col_Cut = new HTuple(), hv_C1Row = new HTuple();
            HTuple hv_C1Col = new HTuple(), hv_RD_Row = new HTuple();
            HTuple hv_RD_Col = new HTuple(), hv_A2AngOut = new HTuple();
            HTuple hv_A2Row_Cut = new HTuple(), hv_A2Col_Cut = new HTuple();
            HTuple hv_A2Row = new HTuple(), hv_A2Col = new HTuple();
            HTuple hv_C2AngOut = new HTuple(), hv_C2Row_Cut = new HTuple();
            HTuple hv_C2Col_Cut = new HTuple(), hv_C2Row = new HTuple();
            HTuple hv_C2Col = new HTuple(), hv_bu1Row2 = new HTuple();
            HTuple hv_bu1Col2 = new HTuple(), hv_bu1Row1 = new HTuple();
            HTuple hv_bu1Col1 = new HTuple(), hv_bu1Row = new HTuple();
            HTuple hv_bu1Col = new HTuple(), hv_bv1Row2 = new HTuple();
            HTuple hv_bv1Col2 = new HTuple(), hv_bv1Row1 = new HTuple();
            HTuple hv_bv1Col1 = new HTuple(), hv_bv1Row = new HTuple();
            HTuple hv_bv1Col = new HTuple(), hv_bu2Row2 = new HTuple();
            HTuple hv_bu2Col2 = new HTuple(), hv_bu2Row1 = new HTuple();
            HTuple hv_bu2Col1 = new HTuple(), hv_bu2Row = new HTuple();
            HTuple hv_bu2Col = new HTuple(), hv_bv2Row1 = new HTuple();
            HTuple hv_bv2Col1 = new HTuple(), hv_bv2Row2 = new HTuple();
            HTuple hv_bv2Col2 = new HTuple(), hv_bv2Row = new HTuple();
            HTuple hv_bv2Col = new HTuple(), hv_B1Row = new HTuple();
            HTuple hv_B1Col = new HTuple(), hv_IsOverlapping = new HTuple();
            HTuple hv_B2Row = new HTuple(), hv_B2Col = new HTuple();
            HTuple hv_Angle1 = new HTuple(), hv_Angle2 = new HTuple();
            HTuple hv_Ang12MeasureType = new HTuple(), hv_DistanceA_T = new HTuple();
            HTuple hv_AB1Angle = new HTuple(), hv_Distance = new HTuple();
            HTuple hv_Bu1Row1 = new HTuple(), hv_Bu1Col1 = new HTuple();
            HTuple hv_Bu1Row2 = new HTuple(), hv_Bu1Col2 = new HTuple();
            HTuple hv_Bv1Row1 = new HTuple(), hv_Bv1Col1 = new HTuple();
            HTuple hv_Bv1Row2 = new HTuple(), hv_Bv1Col2 = new HTuple();
            HTuple hv_AB2Angle = new HTuple(), hv_Bu2Row2 = new HTuple();
            HTuple hv_Bu2Col2 = new HTuple(), hv_Bu2Row1 = new HTuple();
            HTuple hv_Bu2Col1 = new HTuple(), hv_Bv2Row2 = new HTuple();
            HTuple hv_Bv2Col2 = new HTuple(), hv_Bv2Row1 = new HTuple();
            HTuple hv_Bv2Col1 = new HTuple(), hv_t1Row = new HTuple();
            HTuple hv_t1Col = new HTuple(), hv_t2Row = new HTuple();
            HTuple hv_t2Col = new HTuple(), hv_CC1AngOut = new HTuple();
            HTuple hv_CC1Row_Cut = new HTuple(), hv_CC1Col_Cut = new HTuple();
            HTuple hv_CC1Row = new HTuple(), hv_CC1Col = new HTuple();
            HTuple hv_CC12AngOut = new HTuple(), hv_CC12Row_Cut = new HTuple();
            HTuple hv_CC12Col_Cut = new HTuple(), hv_CC12Row = new HTuple();
            HTuple hv_CC12Col = new HTuple(), hv_CC13AngOut = new HTuple();
            HTuple hv_CC13Row_Cut = new HTuple(), hv_CC13Col_Cut = new HTuple();
            HTuple hv_CC13Row = new HTuple(), hv_CC13Col = new HTuple();
            HTuple hv_R_1CenterRow = new HTuple(), hv_R_1CenterCol = new HTuple();
            HTuple hv_CircleR1 = new HTuple(), hv_chamfer1_Rows = new HTuple();
            HTuple hv_chamfer1_Cols = new HTuple(), hv_n = new HTuple();
            HTuple hv_Y1 = new HTuple(), hv_Y2 = new HTuple(), hv_X1 = new HTuple();
            HTuple hv_X2 = new HTuple(), hv_ChamferRow = new HTuple();
            HTuple hv_ChamferCol = new HTuple(), hv_R1_Rows = new HTuple();
            HTuple hv_R1_Cols = new HTuple(), hv_R1_Rs = new HTuple();
            HTuple hv_i = new HTuple(), hv_Row_1 = new HTuple(), hv_Col_1 = new HTuple();
            HTuple hv_j = new HTuple(), hv_Row_2 = new HTuple(), hv_Col_2 = new HTuple();
            HTuple hv_k = new HTuple(), hv_Indices1 = new HTuple();
            HTuple hv_R_1 = new HTuple(), hv_CC2AngOut = new HTuple();
            HTuple hv_CC2Row_Cut = new HTuple(), hv_CC2Col_Cut = new HTuple();
            HTuple hv_CC2Row = new HTuple(), hv_CC2Col = new HTuple();
            HTuple hv_CC22AngOut = new HTuple(), hv_CC22Row_Cut = new HTuple();
            HTuple hv_CC22Col_Cut = new HTuple(), hv_CC22Row = new HTuple();
            HTuple hv_CC22Col = new HTuple(), hv_CC23AngOut = new HTuple();
            HTuple hv_CC23Row_Cut = new HTuple(), hv_CC23Col_Cut = new HTuple();
            HTuple hv_CC23Row = new HTuple(), hv_CC23Col = new HTuple();
            HTuple hv_R_2CenterRow = new HTuple(), hv_R_2CenterCol = new HTuple();
            HTuple hv_CircleR2 = new HTuple(), hv_chamfer2_Rows = new HTuple();
            HTuple hv_chamfer2_Cols = new HTuple(), hv_R2_Rows = new HTuple();
            HTuple hv_R2_Cols = new HTuple(), hv_R2_Rs = new HTuple();
            HTuple hv_Indices2 = new HTuple(), hv_R_2 = new HTuple();
            HTuple hv_Length = new HTuple(), hv_Line_Org = new HTuple();
            HTuple hv_Line_Surface1 = new HTuple(), hv_Line_Surface2 = new HTuple();
            HTuple hv_Line_Ang1 = new HTuple(), hv_Line_Ang2 = new HTuple();
            HTuple hv_Line_A1 = new HTuple(), hv_Line_A2 = new HTuple();
            HTuple hv_Line_B1 = new HTuple(), hv_Line_B2 = new HTuple();
            HTuple hv_Line_R1 = new HTuple(), hv_Line_R2 = new HTuple();
            HTuple hv_Line_C1 = new HTuple(), hv_Line_C2 = new HTuple();
            HTuple hv_Lines = new HTuple(), hv_Number = new HTuple();
            HTuple hv_X1_idx = new HTuple(), hv_Y1_idx = new HTuple();
            HTuple hv_X2_idx = new HTuple(), hv_Y2_idx = new HTuple();
            HTuple hv_textA1 = new HTuple(), hv_textA2 = new HTuple();
            HTuple hv_textB1 = new HTuple(), hv_textB2 = new HTuple();
            HTuple hv_textBC = new HTuple(), hv_textC1 = new HTuple();
            HTuple hv_textC2 = new HTuple(), hv_textR1 = new HTuple();
            HTuple hv_textR2 = new HTuple(), hv_textt = new HTuple();
            HTuple hv_textAng1 = new HTuple(), hv_textAng2 = new HTuple();
            HTuple hv_texts = new HTuple(), hv_text_idx = new HTuple();
            HTuple hv_textX_idx = new HTuple(), hv_textY_idx = new HTuple();
            HTuple hv_S4 = new HTuple(), hv_WindowHandle = new HTuple();
            HTuple hv_CrossSize = new HTuple(), hv_CrossX = new HTuple();
            HTuple hv_CrossY = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_rotateImage);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle2);
            HOperatorSet.GenEmptyObj(out ho_Position1Region);
            HOperatorSet.GenEmptyObj(out ho_Position2Region);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_Region);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            HOperatorSet.GenEmptyObj(out ho_bu1);
            HOperatorSet.GenEmptyObj(out ho_RegionLines);
            HOperatorSet.GenEmptyObj(out ho_a1);
            HOperatorSet.GenEmptyObj(out ho_c1);
            HOperatorSet.GenEmptyObj(out ho_a2);
            HOperatorSet.GenEmptyObj(out ho_c2);
            HOperatorSet.GenEmptyObj(out ho_Arrow2);
            HOperatorSet.GenEmptyObj(out ho_bv1);
            HOperatorSet.GenEmptyObj(out ho_Bu2);
            HOperatorSet.GenEmptyObj(out ho_bu2);
            HOperatorSet.GenEmptyObj(out ho_Bv2);
            HOperatorSet.GenEmptyObj(out ho_bv2);
            HOperatorSet.GenEmptyObj(out ho_b1);
            HOperatorSet.GenEmptyObj(out ho_b2);
            HOperatorSet.GenEmptyObj(out ho_MeasureLineBu1);
            HOperatorSet.GenEmptyObj(out ho_MeasureLineBv1);
            HOperatorSet.GenEmptyObj(out ho_MeasureLineBu2);
            HOperatorSet.GenEmptyObj(out ho_MeasureLineBv2);
            HOperatorSet.GenEmptyObj(out ho_t1);
            HOperatorSet.GenEmptyObj(out ho_t2);
            HOperatorSet.GenEmptyObj(out ho_cc1);
            HOperatorSet.GenEmptyObj(out ho_cc12);
            HOperatorSet.GenEmptyObj(out ho_cc13);
            HOperatorSet.GenEmptyObj(out ho_Circle1);
            HOperatorSet.GenEmptyObj(out ho_Arrow3);
            HOperatorSet.GenEmptyObj(out ho_ChanferPnt);
            HOperatorSet.GenEmptyObj(out ho_Circles);
            HOperatorSet.GenEmptyObj(out ho_Cross1);
            HOperatorSet.GenEmptyObj(out ho_cc2);
            HOperatorSet.GenEmptyObj(out ho_cc22);
            HOperatorSet.GenEmptyObj(out ho_cc23);
            HOperatorSet.GenEmptyObj(out ho_Circle2);
            HOperatorSet.GenEmptyObj(out ho_Surface1);
            HOperatorSet.GenEmptyObj(out ho_Surface2);
            HOperatorSet.GenEmptyObj(out ho_line);
            HOperatorSet.GenEmptyObj(out ho_line1);
            HOperatorSet.GenEmptyObj(out ho_Orig);
            HOperatorSet.GenEmptyObj(out ho_Arrow1);
            HOperatorSet.GenEmptyObj(out ho_OrgLine);
            HOperatorSet.GenEmptyObj(out ho_DrawLines);
            HOperatorSet.GenEmptyObj(out ho_Arrow);
            HOperatorSet.GenEmptyObj(out ho_CrossH);
            HOperatorSet.GenEmptyObj(out ho_CrossV);
            HOperatorSet.GenEmptyObj(out ho_DrawCircles);
            HOperatorSet.GenEmptyObj(out ho_DupImage);
            HOperatorSet.GenEmptyObj(out ho_R);
            HOperatorSet.GenEmptyObj(out ho_G);
            HOperatorSet.GenEmptyObj(out ho_B);
            hv_A1 = new HTuple();
            hv_A2 = new HTuple();
            hv_B1 = new HTuple();
            hv_B2 = new HTuple();
            hv_BC = new HTuple();
            hv_C1 = new HTuple();
            hv_C2 = new HTuple();
            hv_R1 = new HTuple();
            hv_R2 = new HTuple();
            hv_t = new HTuple();
            hv_Ang1 = new HTuple();
            hv_Ang2 = new HTuple();
            hv_ErrorMsg = new HTuple();
            hv_Phi_OrgX_OrgY = new HTuple();
            hv_Cir_c1 = new HTuple();
            hv_Cir_c2 = new HTuple();
            hv_LinesX1 = new HTuple();
            hv_LinesY1 = new HTuple();
            hv_LinesX2 = new HTuple();
            hv_LinesY2 = new HTuple();
            hv_TextsText = new HTuple();
            hv_TextsX = new HTuple();
            hv_TextsY = new HTuple();
            try
            {
                //20230213 v1.0
                //20230214 v1.1 修正MeasurePos指令
                //20230406 v1.2 將結果畫在圖上
                //20230601 v1.2.1 修改導角方式
                //20230605 v1.3 R角 排除角計算
                //20230614 v1.5 t 改為 量測 a點旁邊的頂部
                //             R1、R2 計算方式修正， 導角起始點到終點 取N個量測點，N個量測點取2個+C點  構成圓，算出最小的圓為答案
                //             修改B1、B2 從a1~b1 Y距離 改為 t1~b1距離
                //             修改內部參數命名
                //             新增調整影像比例參數
                //20230705 v1.6 修正bu1/2、bv1/2量測線的量測方向
                //20230705 v1.7 t值 原計算兩點距離 改成計算Y的差值
                ho_ImageOut.Dispose();
                HOperatorSet.CopyImage(ho_Image, out ho_ImageOut);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.Rgb1ToGray(ho_ImageOut, out ExpTmpOutVar_0);
                    ho_ImageOut.Dispose();
                    ho_ImageOut = ExpTmpOutVar_0;
                }

                hv_show.Dispose();
                hv_show = 1;
                hv_A1.Dispose();
                hv_A1 = new HTuple();
                hv_A2.Dispose();
                hv_A2 = new HTuple();
                hv_B1.Dispose();
                hv_B1 = new HTuple();
                hv_B2.Dispose();
                hv_B2 = new HTuple();
                hv_BC.Dispose();
                hv_BC = new HTuple();
                hv_C1.Dispose();
                hv_C1 = new HTuple();
                hv_C2.Dispose();
                hv_C2 = new HTuple();
                hv_R1.Dispose();
                hv_R1 = new HTuple();
                hv_R2.Dispose();
                hv_R2 = new HTuple();
                hv_t.Dispose();
                hv_t = new HTuple();
                hv_Ang1.Dispose();
                hv_Ang1 = new HTuple();
                hv_Ang2.Dispose();
                hv_Ang2 = new HTuple();
                hv_ErrorMsg.Dispose();
                hv_ErrorMsg = new HTuple();
                //====新版定義 A,C點==
                //-內部參數 量測切線極值參數
                hv_ExrPnt_Range.Dispose();
                hv_ExrPnt_Range = 40;
                hv_ExrPnt_Sigma.Dispose();
                hv_ExrPnt_Sigma = 2;
                hv_ExrPnt_Amp.Dispose();
                hv_ExrPnt_Amp = 10;
                hv_ExrPnt_MeasureWidth.Dispose();
                hv_ExrPnt_MeasureWidth = 20;
                hv_ExrPnt_MeasureGap.Dispose();
                hv_ExrPnt_MeasureGap = 1;
                //-內部參數  量測單點(MeasurePos)
                hv_OnePnt_Amp.Dispose();
                hv_OnePnt_Amp = 30;
                hv_OnePnt_MeasureWidth.Dispose();
                hv_OnePnt_MeasureWidth = 1;
                hv_OnePnt_sigma.Dispose();
                hv_OnePnt_sigma = 1;


                //轉正
                if ((int)(new HTuple(hv_rotateAngle.TupleNotEqual(0))) != 0)
                {
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.RotateImage(ho_ImageOut, out ExpTmpOutVar_0, hv_rotateAngle,
                            "constant");
                        ho_ImageOut.Dispose();
                        ho_ImageOut = ExpTmpOutVar_0;
                    }
                    ho_rotateImage.Dispose();
                    HOperatorSet.CopyImage(ho_ImageOut, out ho_rotateImage);
                }

                //Resize校正
                hv_Width1.Dispose(); hv_Height1.Dispose();
                HOperatorSet.GetImageSize(ho_ImageOut, out hv_Width1, out hv_Height1);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ZoomImageSize(ho_ImageOut, out ExpTmpOutVar_0, hv_Width1 * hv_ScaleW,
                        hv_Height1 * hv_ScaleH, "constant");
                    ho_ImageOut.Dispose();
                    ho_ImageOut = ExpTmpOutVar_0;
                }

                if ((int)(new HTuple(hv_GrayMax.TupleLessEqual(0))) != 0)
                {
                    ho_Regions.Dispose(); hv_UsedThreshold.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageOut, out ho_Regions, "max_separability",
                        "dark", out hv_UsedThreshold);
                }
                else
                {
                    ho_Regions.Dispose();
                    HOperatorSet.Threshold(ho_ImageOut, out ho_Regions, 0, hv_GrayMax);
                }
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
                hv_Area4.Dispose(); hv_Row1.Dispose(); hv_Column1.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions, out hv_Area4, out hv_Row1, out hv_Column1);
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area4, out hv_Indices);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_ObjectSelected1.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions, out ho_ObjectSelected1, (hv_Indices.TupleSelect(
                        (new HTuple(hv_Indices.TupleLength())) - 1)) + 1);
                }
                hv_IsAutoRotate.Dispose();
                hv_IsAutoRotate = 1;
                if ((int)(new HTuple(hv_IsAutoRotate.TupleEqual(1))) != 0)
                {
                    //抓左右兩小區的region 的中心 計算傾斜角度
                    hv_RectRow1.Dispose(); hv_RectColumn1.Dispose(); hv_RectRow2.Dispose(); hv_RectColumn2.Dispose();
                    HOperatorSet.SmallestRectangle1(ho_ObjectSelected1, out hv_RectRow1, out hv_RectColumn1,
                        out hv_RectRow2, out hv_RectColumn2);
                    hv_RectW.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_RectW = (hv_RectColumn2 - hv_RectColumn1) - 150;
                    }
                    hv_RectH.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_RectH = hv_RectRow2 - hv_RectRow1;
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle1.Dispose();
                        HOperatorSet.GenRectangle1(out ho_Rectangle1, hv_RectRow1 - 30, hv_RectColumn1 + (0.1 * hv_RectW),
                            hv_RectRow2 + 30, hv_RectColumn1 + (0.3 * hv_RectW));
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle2.Dispose();
                        HOperatorSet.GenRectangle1(out ho_Rectangle2, hv_RectRow1 - 30, hv_RectColumn1 + (0.7 * hv_RectW),
                            hv_RectRow2 + 30, hv_RectColumn1 + (0.9 * hv_RectW));
                    }
                    ho_Position1Region.Dispose();
                    HOperatorSet.Intersection(ho_Rectangle1, ho_Regions, out ho_Position1Region
                        );
                    ho_Position2Region.Dispose();
                    HOperatorSet.Intersection(ho_Rectangle2, ho_Regions, out ho_Position2Region
                        );
                    hv_Area1.Dispose(); hv_CenterLRow.Dispose(); hv_CenterLCol.Dispose();
                    HOperatorSet.AreaCenter(ho_Position1Region, out hv_Area1, out hv_CenterLRow,
                        out hv_CenterLCol);
                    hv_Area3.Dispose(); hv_CenterRRow.Dispose(); hv_CenterRCol.Dispose();
                    HOperatorSet.AreaCenter(ho_Position2Region, out hv_Area3, out hv_CenterRRow,
                        out hv_CenterRCol);
                    hv_Phi.Dispose();
                    HOperatorSet.AngleLx(hv_CenterLRow, hv_CenterLCol, hv_CenterRRow, hv_CenterRCol,
                        out hv_Phi);
                    hv_Phi_OrgX_OrgY.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Phi_OrgX_OrgY = hv_Phi.TupleDeg()
                            ;
                    }
                    hv_HomMat2DIdentity.Dispose();
                    HOperatorSet.HomMat2dIdentity(out hv_HomMat2DIdentity);
                    //旋轉中心(Wafer的頂點)
                    hv_rotateRow.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_rotateRow = (hv_RectRow1 + hv_RectRow2) / 2;
                    }
                    hv_rotateCol.Dispose();
                    hv_rotateCol = new HTuple(hv_RectColumn2);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_HomMat2DRotate.Dispose();
                        HOperatorSet.HomMat2dRotate(hv_HomMat2DIdentity, -hv_Phi, hv_rotateCol, hv_rotateRow,
                            out hv_HomMat2DRotate);
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.AffineTransImage(ho_ImageOut, out ExpTmpOutVar_0, hv_HomMat2DRotate,
                            "constant", "false");
                        ho_ImageOut.Dispose();
                        ho_ImageOut = ExpTmpOutVar_0;
                    }
                    hv_rotateAng.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_rotateAng = hv_Phi.TupleDeg()
                            ;
                    }
                }
                else
                {
                    hv_Phi_OrgX_OrgY.Dispose();
                    hv_Phi_OrgX_OrgY = -1;
                    ho_rotateImage.Dispose();
                    HOperatorSet.CopyImage(ho_ImageOut, out ho_rotateImage);
                }
                //抓取ROI區域
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle, hv_RoiY1, hv_RoiX1, hv_RoiY2,
                    hv_RoiX2);
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_ImageOut, ho_Rectangle, out ho_ImageReduced);
                if ((int)(new HTuple(hv_GrayMax.TupleLessEqual(0))) != 0)
                {
                    ho_Region.Dispose(); hv_UsedThreshold.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageReduced, out ho_Region, "max_separability",
                        "dark", out hv_UsedThreshold);
                }
                else
                {
                    ho_Region.Dispose();
                    HOperatorSet.Threshold(ho_ImageReduced, out ho_Region, 0, hv_GrayMax);
                }
                //threshold (ImageReduced, Region, 0, UsedThreshold)

                //選擇最大區域的為目標
                ho_ConnectedRegions1.Dispose();
                HOperatorSet.Connection(ho_Region, out ho_ConnectedRegions1);
                hv_Area2.Dispose(); hv_Row4.Dispose(); hv_Column4.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions1, out hv_Area2, out hv_Row4, out hv_Column4);
                hv_Indices3.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area2, out hv_Indices3);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Region.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions1, out ho_Region, (hv_Indices3.TupleSelect(
                        (new HTuple(hv_Indices3.TupleLength())) - 1)) + 1);
                }
                hv_WaferRow1.Dispose(); hv_WaferCol1.Dispose(); hv_WaferRow2.Dispose(); hv_WaferRCol2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Region, out hv_WaferRow1, out hv_WaferCol1,
                    out hv_WaferRow2, out hv_WaferRCol2);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_Region, out hv_Area, out hv_Row, out hv_Column);
                hv_OriginRow.Dispose();
                hv_OriginRow = new HTuple(hv_Row);
                hv_OriginCol.Dispose();
                hv_OriginCol = new HTuple(hv_WaferRCol2);
                ho_Cross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross, hv_OriginRow, hv_OriginCol, 6,
                    0.785398);
                //儲存原點座標
                //OrgRowsOut := [OrgRowsOut,OriginRow*PixelSize]
                //OrgColsOut := [OrgColsOut,OriginCol*PixelSize]
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Phi_OrgX_OrgY = ((hv_Phi_OrgX_OrgY.TupleConcat(
                            hv_OriginRow))).TupleConcat(hv_OriginCol);
                        hv_Phi_OrgX_OrgY.Dispose();
                        hv_Phi_OrgX_OrgY = ExpTmpLocalVar_Phi_OrgX_OrgY;
                    }
                }
                //量測振幅，量測寬度

                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_ImageReduced, out hv_Width, out hv_Height);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_bu1.Dispose(); hv_WaferOriginRow.Dispose(); hv_WaferOriginCol.Dispose();
                    MeasurePos(ho_ImageReduced, out ho_bu1, hv_Row, hv_Column, hv_Row, hv_OriginCol + 30,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, 1, out hv_WaferOriginRow, out hv_WaferOriginCol);
                }

                if ((int)(new HTuple(hv_WaferOriginCol.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "找不到原點座標!! 無法計算，請檢查參數和影像");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_Bv2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_MeasureLineBu1.Dispose();
                    ho_MeasureLineBv1.Dispose();
                    ho_MeasureLineBu2.Dispose();
                    ho_MeasureLineBv2.Dispose();
                    ho_t1.Dispose();
                    ho_t2.Dispose();
                    ho_cc1.Dispose();
                    ho_cc12.Dispose();
                    ho_cc13.Dispose();
                    ho_Circle1.Dispose();
                    ho_Arrow3.Dispose();
                    ho_ChanferPnt.Dispose();
                    ho_Circles.Dispose();
                    ho_Cross1.Dispose();
                    ho_cc2.Dispose();
                    ho_cc22.Dispose();
                    ho_cc23.Dispose();
                    ho_Circle2.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_Arrow1.Dispose();
                    ho_OrgLine.Dispose();
                    ho_DrawLines.Dispose();
                    ho_Arrow.Dispose();
                    ho_CrossH.Dispose();
                    ho_CrossV.Dispose();
                    ho_DrawCircles.Dispose();
                    ho_DupImage.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();

                    hv_show.Dispose();
                    hv_ExrPnt_Range.Dispose();
                    hv_ExrPnt_Sigma.Dispose();
                    hv_ExrPnt_Amp.Dispose();
                    hv_ExrPnt_MeasureWidth.Dispose();
                    hv_ExrPnt_MeasureGap.Dispose();
                    hv_OnePnt_Amp.Dispose();
                    hv_OnePnt_MeasureWidth.Dispose();
                    hv_OnePnt_sigma.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_IsAutoRotate.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_Phi.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_A1Row_Cut.Dispose();
                    hv_A1Col_Cut.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row_Cut.Dispose();
                    hv_C1Col_Cut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row_Cut.Dispose();
                    hv_A2Col_Cut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row_Cut.Dispose();
                    hv_C2Col_Cut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Ang12MeasureType.Dispose();
                    hv_DistanceA_T.Dispose();
                    hv_AB1Angle.Dispose();
                    hv_Distance.Dispose();
                    hv_Bu1Row1.Dispose();
                    hv_Bu1Col1.Dispose();
                    hv_Bu1Row2.Dispose();
                    hv_Bu1Col2.Dispose();
                    hv_Bv1Row1.Dispose();
                    hv_Bv1Col1.Dispose();
                    hv_Bv1Row2.Dispose();
                    hv_Bv1Col2.Dispose();
                    hv_AB2Angle.Dispose();
                    hv_Bu2Row2.Dispose();
                    hv_Bu2Col2.Dispose();
                    hv_Bu2Row1.Dispose();
                    hv_Bu2Col1.Dispose();
                    hv_Bv2Row2.Dispose();
                    hv_Bv2Col2.Dispose();
                    hv_Bv2Row1.Dispose();
                    hv_Bv2Col1.Dispose();
                    hv_t1Row.Dispose();
                    hv_t1Col.Dispose();
                    hv_t2Row.Dispose();
                    hv_t2Col.Dispose();
                    hv_CC1AngOut.Dispose();
                    hv_CC1Row_Cut.Dispose();
                    hv_CC1Col_Cut.Dispose();
                    hv_CC1Row.Dispose();
                    hv_CC1Col.Dispose();
                    hv_CC12AngOut.Dispose();
                    hv_CC12Row_Cut.Dispose();
                    hv_CC12Col_Cut.Dispose();
                    hv_CC12Row.Dispose();
                    hv_CC12Col.Dispose();
                    hv_CC13AngOut.Dispose();
                    hv_CC13Row_Cut.Dispose();
                    hv_CC13Col_Cut.Dispose();
                    hv_CC13Row.Dispose();
                    hv_CC13Col.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_CircleR1.Dispose();
                    hv_chamfer1_Rows.Dispose();
                    hv_chamfer1_Cols.Dispose();
                    hv_n.Dispose();
                    hv_Y1.Dispose();
                    hv_Y2.Dispose();
                    hv_X1.Dispose();
                    hv_X2.Dispose();
                    hv_ChamferRow.Dispose();
                    hv_ChamferCol.Dispose();
                    hv_R1_Rows.Dispose();
                    hv_R1_Cols.Dispose();
                    hv_R1_Rs.Dispose();
                    hv_i.Dispose();
                    hv_Row_1.Dispose();
                    hv_Col_1.Dispose();
                    hv_j.Dispose();
                    hv_Row_2.Dispose();
                    hv_Col_2.Dispose();
                    hv_k.Dispose();
                    hv_Indices1.Dispose();
                    hv_R_1.Dispose();
                    hv_CC2AngOut.Dispose();
                    hv_CC2Row_Cut.Dispose();
                    hv_CC2Col_Cut.Dispose();
                    hv_CC2Row.Dispose();
                    hv_CC2Col.Dispose();
                    hv_CC22AngOut.Dispose();
                    hv_CC22Row_Cut.Dispose();
                    hv_CC22Col_Cut.Dispose();
                    hv_CC22Row.Dispose();
                    hv_CC22Col.Dispose();
                    hv_CC23AngOut.Dispose();
                    hv_CC23Row_Cut.Dispose();
                    hv_CC23Col_Cut.Dispose();
                    hv_CC23Row.Dispose();
                    hv_CC23Col.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_CircleR2.Dispose();
                    hv_chamfer2_Rows.Dispose();
                    hv_chamfer2_Cols.Dispose();
                    hv_R2_Rows.Dispose();
                    hv_R2_Cols.Dispose();
                    hv_R2_Rs.Dispose();
                    hv_Indices2.Dispose();
                    hv_R_2.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_Number.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();
                    hv_CrossSize.Dispose();
                    hv_CrossX.Dispose();
                    hv_CrossY.Dispose();

                    return;
                }


                //轉換座
                hv_RU_row.Dispose();
                hv_RU_row = new HTuple(hv_WaferRow1);
                hv_RU_col.Dispose();
                hv_RU_col = new HTuple(hv_WaferRCol2);
                hv_A1AngOut.Dispose();
                AngleTrans(hv_A1Ang, out hv_A1AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_A1AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_A1AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_A1AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_A1AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_A1Row_Cut.Dispose(); hv_A1Col_Cut.Dispose(); hv_A1Row.Dispose(); hv_A1Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_A1Row_Cut, out hv_A1Col_Cut, out hv_A1Row, out hv_A1Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A1Row.Dispose(); hv_A1Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_A1Row_Cut, hv_A1Col_Cut,
                        -hv_A1AngOut, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_A1Row, out hv_A1Col);
                }


                ho_a1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_a1, hv_A1Row, hv_A1Col, 6, 0);
                hv_C1AngOut.Dispose();
                AngleTrans(hv_C1Ang, out hv_C1AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_C1AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_C1AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_C1AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_C1AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_C1Row_Cut.Dispose(); hv_C1Col_Cut.Dispose(); hv_C1Row.Dispose(); hv_C1Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_C1Row_Cut, out hv_C1Col_Cut, out hv_C1Row, out hv_C1Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_C1Row.Dispose(); hv_C1Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_C1Row_Cut, hv_C1Col_Cut,
                        -hv_C1AngOut, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_C1Row, out hv_C1Col);
                }
                ho_c1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_c1, hv_C1Row, hv_C1Col, 6, 0);
                hv_RD_Row.Dispose();
                hv_RD_Row = new HTuple(hv_WaferRow2);
                hv_RD_Col.Dispose();
                hv_RD_Col = new HTuple(hv_WaferRCol2);
                hv_A2AngOut.Dispose();
                AngleTrans(hv_A2Ang, out hv_A2AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_A2AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_A2AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_A2AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_A2AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_A2Row_Cut.Dispose(); hv_A2Col_Cut.Dispose(); hv_A2Row.Dispose(); hv_A2Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_A2Row_Cut, out hv_A2Col_Cut, out hv_A2Row, out hv_A2Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A2Row.Dispose(); hv_A2Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_A2Row_Cut, hv_A2Col_Cut,
                        (-hv_A2AngOut) + 180, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_A2Row, out hv_A2Col);
                }

                ho_a2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_a2, hv_A2Row, hv_A2Col, 6, 0);
                hv_C2AngOut.Dispose();
                AngleTrans(hv_C2Ang, out hv_C2AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_C2AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_C2AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_C2AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_C2AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_C2Row_Cut.Dispose(); hv_C2Col_Cut.Dispose(); hv_C2Row.Dispose(); hv_C2Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_C2Row_Cut, out hv_C2Col_Cut, out hv_C2Row, out hv_C2Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_C2Row.Dispose(); hv_C2Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_C2Row_Cut, hv_C2Col_Cut,
                        (-hv_C2AngOut) + 180, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_C2Row, out hv_C2Col);
                }

                ho_c2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_c2, hv_C2Row, hv_C2Col, 6, 0);
                //====新版定義 A,C點==結束


                //====量測Bu Bv 計算Angle===開始==============

                //Sigma := 1
                HOperatorSet.SetSystem("int_zooming", "true");
                hv_bu1Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu1Row2 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bu11);
                }
                hv_bu1Col2.Dispose();
                hv_bu1Col2 = new HTuple(hv_A1Col);
                hv_bu1Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu1Row1 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bu11);
                }
                hv_bu1Col1.Dispose();
                hv_bu1Col1 = new HTuple(hv_WaferOriginCol);
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "blue");
                }
                ho_Arrow2.Dispose();
                gen_arrow_contour_xld(out ho_Arrow2, hv_bu1Row2, hv_bu1Col2, hv_bu1Row1, hv_bu1Col1,
                    5, 5);
                ho_bu1.Dispose(); hv_bu1Row.Dispose(); hv_bu1Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bu1, hv_bu1Row2, hv_bu1Col2, hv_bu1Row1, hv_bu1Col1,
                    hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bu1Row,
                    out hv_bu1Col);
                if ((int)(new HTuple(hv_bu1Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bu1量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bv1Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv1Row2 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bv11);
                }
                hv_bv1Col2.Dispose();
                hv_bv1Col2 = new HTuple(hv_A1Col);
                hv_bv1Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv1Row1 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bv11);
                }
                hv_bv1Col1.Dispose();
                hv_bv1Col1 = new HTuple(hv_WaferOriginCol);
                ho_Arrow2.Dispose();
                gen_arrow_contour_xld(out ho_Arrow2, hv_bv1Row2, hv_bv1Col2, hv_bv1Row1, hv_bv1Col1,
                    5, 5);
                ho_bv1.Dispose(); hv_bv1Row.Dispose(); hv_bv1Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bv1, hv_bv1Row2, hv_bv1Col2, hv_bv1Row1, hv_bv1Col1,
                    hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bv1Row,
                    out hv_bv1Col);
                if ((int)(new HTuple(hv_bv1Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bv1量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bu2Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu2Row2 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bu22);
                }
                hv_bu2Col2.Dispose();
                hv_bu2Col2 = new HTuple(hv_A2Col);
                hv_bu2Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu2Row1 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bu22);
                }
                hv_bu2Col1.Dispose();
                hv_bu2Col1 = new HTuple(hv_WaferOriginCol);
                ho_Bu2.Dispose();
                gen_arrow_contour_xld(out ho_Bu2, hv_bu2Row2, hv_bu2Col2, hv_bu2Row1, hv_bu2Col1,
                    5, 5);
                ho_bu2.Dispose(); hv_bu2Row.Dispose(); hv_bu2Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bu2, hv_bu2Row2, hv_bu2Col2, hv_bu2Row1, hv_bu2Col1,
                    hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bu2Row,
                    out hv_bu2Col);
                if ((int)(new HTuple(hv_bu2Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bu2量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bv2Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv2Row1 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bv22);
                }
                hv_bv2Col1.Dispose();
                hv_bv2Col1 = new HTuple(hv_A2Col);
                hv_bv2Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv2Row2 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bv22);
                }
                hv_bv2Col2.Dispose();
                hv_bv2Col2 = new HTuple(hv_WaferOriginCol);
                ho_Bv2.Dispose();
                gen_arrow_contour_xld(out ho_Bv2, hv_bv2Row1, hv_bv2Col1, hv_bv2Row2, hv_bv2Col2,
                    5, 5);
                ho_bv2.Dispose(); hv_bv2Row.Dispose(); hv_bv2Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bv2, hv_bv2Row1, hv_bv2Col1, hv_bv2Row2, hv_bv2Col2,
                    hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bv2Row,
                    out hv_bv2Col);
                if ((int)(new HTuple(hv_bv2Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bv2量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                if ((int)(new HTuple(hv_ErrorMsg.TupleNotEqual(new HTuple()))) != 0)
                {
                    //throw (ErrorMsg)
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_Bv2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_MeasureLineBu1.Dispose();
                    ho_MeasureLineBv1.Dispose();
                    ho_MeasureLineBu2.Dispose();
                    ho_MeasureLineBv2.Dispose();
                    ho_t1.Dispose();
                    ho_t2.Dispose();
                    ho_cc1.Dispose();
                    ho_cc12.Dispose();
                    ho_cc13.Dispose();
                    ho_Circle1.Dispose();
                    ho_Arrow3.Dispose();
                    ho_ChanferPnt.Dispose();
                    ho_Circles.Dispose();
                    ho_Cross1.Dispose();
                    ho_cc2.Dispose();
                    ho_cc22.Dispose();
                    ho_cc23.Dispose();
                    ho_Circle2.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_Arrow1.Dispose();
                    ho_OrgLine.Dispose();
                    ho_DrawLines.Dispose();
                    ho_Arrow.Dispose();
                    ho_CrossH.Dispose();
                    ho_CrossV.Dispose();
                    ho_DrawCircles.Dispose();
                    ho_DupImage.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();

                    hv_show.Dispose();
                    hv_ExrPnt_Range.Dispose();
                    hv_ExrPnt_Sigma.Dispose();
                    hv_ExrPnt_Amp.Dispose();
                    hv_ExrPnt_MeasureWidth.Dispose();
                    hv_ExrPnt_MeasureGap.Dispose();
                    hv_OnePnt_Amp.Dispose();
                    hv_OnePnt_MeasureWidth.Dispose();
                    hv_OnePnt_sigma.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_IsAutoRotate.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_Phi.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_A1Row_Cut.Dispose();
                    hv_A1Col_Cut.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row_Cut.Dispose();
                    hv_C1Col_Cut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row_Cut.Dispose();
                    hv_A2Col_Cut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row_Cut.Dispose();
                    hv_C2Col_Cut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Ang12MeasureType.Dispose();
                    hv_DistanceA_T.Dispose();
                    hv_AB1Angle.Dispose();
                    hv_Distance.Dispose();
                    hv_Bu1Row1.Dispose();
                    hv_Bu1Col1.Dispose();
                    hv_Bu1Row2.Dispose();
                    hv_Bu1Col2.Dispose();
                    hv_Bv1Row1.Dispose();
                    hv_Bv1Col1.Dispose();
                    hv_Bv1Row2.Dispose();
                    hv_Bv1Col2.Dispose();
                    hv_AB2Angle.Dispose();
                    hv_Bu2Row2.Dispose();
                    hv_Bu2Col2.Dispose();
                    hv_Bu2Row1.Dispose();
                    hv_Bu2Col1.Dispose();
                    hv_Bv2Row2.Dispose();
                    hv_Bv2Col2.Dispose();
                    hv_Bv2Row1.Dispose();
                    hv_Bv2Col1.Dispose();
                    hv_t1Row.Dispose();
                    hv_t1Col.Dispose();
                    hv_t2Row.Dispose();
                    hv_t2Col.Dispose();
                    hv_CC1AngOut.Dispose();
                    hv_CC1Row_Cut.Dispose();
                    hv_CC1Col_Cut.Dispose();
                    hv_CC1Row.Dispose();
                    hv_CC1Col.Dispose();
                    hv_CC12AngOut.Dispose();
                    hv_CC12Row_Cut.Dispose();
                    hv_CC12Col_Cut.Dispose();
                    hv_CC12Row.Dispose();
                    hv_CC12Col.Dispose();
                    hv_CC13AngOut.Dispose();
                    hv_CC13Row_Cut.Dispose();
                    hv_CC13Col_Cut.Dispose();
                    hv_CC13Row.Dispose();
                    hv_CC13Col.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_CircleR1.Dispose();
                    hv_chamfer1_Rows.Dispose();
                    hv_chamfer1_Cols.Dispose();
                    hv_n.Dispose();
                    hv_Y1.Dispose();
                    hv_Y2.Dispose();
                    hv_X1.Dispose();
                    hv_X2.Dispose();
                    hv_ChamferRow.Dispose();
                    hv_ChamferCol.Dispose();
                    hv_R1_Rows.Dispose();
                    hv_R1_Cols.Dispose();
                    hv_R1_Rs.Dispose();
                    hv_i.Dispose();
                    hv_Row_1.Dispose();
                    hv_Col_1.Dispose();
                    hv_j.Dispose();
                    hv_Row_2.Dispose();
                    hv_Col_2.Dispose();
                    hv_k.Dispose();
                    hv_Indices1.Dispose();
                    hv_R_1.Dispose();
                    hv_CC2AngOut.Dispose();
                    hv_CC2Row_Cut.Dispose();
                    hv_CC2Col_Cut.Dispose();
                    hv_CC2Row.Dispose();
                    hv_CC2Col.Dispose();
                    hv_CC22AngOut.Dispose();
                    hv_CC22Row_Cut.Dispose();
                    hv_CC22Col_Cut.Dispose();
                    hv_CC22Row.Dispose();
                    hv_CC22Col.Dispose();
                    hv_CC23AngOut.Dispose();
                    hv_CC23Row_Cut.Dispose();
                    hv_CC23Col_Cut.Dispose();
                    hv_CC23Row.Dispose();
                    hv_CC23Col.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_CircleR2.Dispose();
                    hv_chamfer2_Rows.Dispose();
                    hv_chamfer2_Cols.Dispose();
                    hv_R2_Rows.Dispose();
                    hv_R2_Cols.Dispose();
                    hv_R2_Rs.Dispose();
                    hv_Indices2.Dispose();
                    hv_R_2.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_Number.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();
                    hv_CrossSize.Dispose();
                    hv_CrossX.Dispose();
                    hv_CrossY.Dispose();

                    return;
                }
                //計算B1
                hv_B1Row.Dispose(); hv_B1Col.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_bu1Row, hv_bu1Col, hv_bv1Row, hv_bv1Col,
                    0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol, out hv_B1Row, out hv_B1Col,
                    out hv_IsOverlapping);
                //計算B2
                hv_B2Row.Dispose(); hv_B2Col.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_bu2Row, hv_bu2Col, hv_bv2Row, hv_bv2Col,
                    0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol, out hv_B2Row, out hv_B2Col,
                    out hv_IsOverlapping);
                ho_b1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b1, hv_B1Row, hv_B1Col, 20, 0);
                ho_b2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b2, hv_B2Row, hv_B2Col, 20, 0);
                //計算 B1 & B2 座標
                hv_Angle1.Dispose();
                HOperatorSet.AngleLx(hv_bu1Row, hv_bu1Col, hv_bv1Row, hv_bv1Col, out hv_Angle1);
                hv_Angle2.Dispose();
                HOperatorSet.AngleLx(hv_bu2Row, hv_bu2Col, hv_bv2Row, hv_bv2Col, out hv_Angle2);
                hv_Ang1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Ang1 = ((hv_Angle1.TupleDeg()
                        )).TupleAbs();
                }
                hv_Ang2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Ang2 = ((hv_Angle2.TupleDeg()
                        )).TupleAbs();
                }
                //====量測Bu Bv 計算Angle===結束===========
                hv_Ang12MeasureType.Dispose();
                hv_Ang12MeasureType = 2;
                if ((int)(new HTuple(hv_Ang12MeasureType.TupleEqual(2))) != 0)
                {
                    //--20230703 新版!!--垂直量測 Bu Bv 計算======
                    hv_DistanceA_T.Dispose();
                    hv_DistanceA_T = 50;
                    hv_AB1Angle.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_AB1Angle = -hv_Angle1;
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                    }
                    hv_Distance.Dispose();
                    HOperatorSet.DistancePp(hv_C1Row, hv_C1Col, hv_A1Row, hv_A1Col, out hv_Distance);
                    hv_Bu1Row1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu1Row1 = hv_bu1Row + ((hv_AB1Angle.TupleCos()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bu1Col1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu1Col1 = hv_bu1Col - ((hv_AB1Angle.TupleSin()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bu1Row2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu1Row2 = hv_bu1Row - ((hv_AB1Angle.TupleCos()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bu1Col2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu1Col2 = hv_bu1Col + ((hv_AB1Angle.TupleSin()
                            ) * hv_DistanceA_T);
                    }
                    ho_MeasureLineBu1.Dispose();
                    gen_arrow_contour_xld(out ho_MeasureLineBu1, hv_Bu1Row1, hv_Bu1Col1, hv_Bu1Row2,
                        hv_Bu1Col2, 5, 5);
                    ho_bu1.Dispose(); hv_bu1Row.Dispose(); hv_bu1Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_bu1, hv_Bu1Row1, hv_Bu1Col1, hv_Bu1Row2, hv_Bu1Col2,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bu1Row,
                        out hv_bu1Col);
                    if ((int)(new HTuple(hv_bu1Row.TupleEqual(new HTuple()))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                    "Bu1量測失敗");
                                hv_ErrorMsg.Dispose();
                                hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                            }
                        }
                    }
                    hv_Bv1Row1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv1Row1 = hv_bv1Row + ((hv_AB1Angle.TupleCos()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bv1Col1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv1Col1 = hv_bv1Col - ((hv_AB1Angle.TupleSin()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bv1Row2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv1Row2 = hv_bv1Row - ((hv_AB1Angle.TupleCos()
                            ) * hv_DistanceA_T);
                    }
                    hv_Bv1Col2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv1Col2 = hv_bv1Col + ((hv_AB1Angle.TupleSin()
                            ) * hv_DistanceA_T);
                    }
                    ho_MeasureLineBv1.Dispose();
                    gen_arrow_contour_xld(out ho_MeasureLineBv1, hv_Bv1Row1, hv_Bv1Col1, hv_Bv1Row2,
                        hv_Bv1Col2, 5, 5);
                    ho_bv1.Dispose(); hv_bv1Row.Dispose(); hv_bv1Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_bv1, hv_Bv1Row1, hv_Bv1Col1, hv_Bv1Row2, hv_Bv1Col2,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bv1Row,
                        out hv_bv1Col);
                    if ((int)(new HTuple(hv_bv1Row.TupleEqual(new HTuple()))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                    "Bv1量測失敗");
                                hv_ErrorMsg.Dispose();
                                hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                            }
                        }
                    }
                    hv_AB2Angle.Dispose();
                    HOperatorSet.AngleLx(hv_A2Row, hv_A2Col, hv_C2Row, hv_C2Col, out hv_AB2Angle);
                    hv_AB2Angle.Dispose();
                    hv_AB2Angle = new HTuple(hv_Angle2);
                    hv_Distance.Dispose();
                    HOperatorSet.DistancePp(hv_C2Row, hv_C2Col, hv_A2Row, hv_A2Col, out hv_Distance);
                    hv_Bu2Row2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu2Row2 = hv_bu2Row + ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleSin()) * hv_DistanceA_T);
                    }
                    hv_Bu2Col2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu2Col2 = hv_bu2Col - ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleCos()) * hv_DistanceA_T);
                    }
                    hv_Bu2Row1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu2Row1 = hv_bu2Row - ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleSin()) * hv_DistanceA_T);
                    }
                    hv_Bu2Col1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bu2Col1 = hv_bu2Col + ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleCos()) * hv_DistanceA_T);
                    }
                    ho_MeasureLineBu2.Dispose();
                    gen_arrow_contour_xld(out ho_MeasureLineBu2, hv_Bu2Row1, hv_Bu2Col1, hv_Bu2Row2,
                        hv_Bu2Col2, 5, 5);
                    ho_bu2.Dispose(); hv_bu2Row.Dispose(); hv_bu2Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_bu2, hv_Bu2Row1, hv_Bu2Col1, hv_Bu2Row2, hv_Bu2Col2,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bu2Row,
                        out hv_bu2Col);
                    if ((int)(new HTuple(hv_bu2Row.TupleEqual(new HTuple()))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                    "Bu2量測失敗");
                                hv_ErrorMsg.Dispose();
                                hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                            }
                        }
                    }
                    hv_Bv2Row2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv2Row2 = hv_bv2Row + ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleSin()) * hv_DistanceA_T);
                    }
                    hv_Bv2Col2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv2Col2 = hv_bv2Col - ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleCos()) * hv_DistanceA_T);
                    }
                    hv_Bv2Row1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv2Row1 = hv_bv2Row - ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleSin()) * hv_DistanceA_T);
                    }
                    hv_Bv2Col1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Bv2Col1 = hv_bv2Col + ((((hv_AB2Angle + ((new HTuple(90)).TupleRad()
                            ))).TupleCos()) * hv_DistanceA_T);
                    }
                    ho_MeasureLineBv2.Dispose();
                    gen_arrow_contour_xld(out ho_MeasureLineBv2, hv_Bv2Row1, hv_Bv2Col1, hv_Bv2Row2,
                        hv_Bv2Col2, 5, 5);
                    ho_bv2.Dispose(); hv_bv2Row.Dispose(); hv_bv2Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_bv2, hv_Bv2Row1, hv_Bv2Col1, hv_Bv2Row2, hv_Bv2Col2,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_bv2Row,
                        out hv_bv2Col);
                    if ((int)(new HTuple(hv_bv2Row.TupleEqual(new HTuple()))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                    "Bv2量測失敗");
                                hv_ErrorMsg.Dispose();
                                hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                            }
                        }
                    }
                    if ((int)(new HTuple(hv_ErrorMsg.TupleNotEqual(new HTuple()))) != 0)
                    {
                        //throw (ErrorMsg)
                        ho_Regions.Dispose();
                        ho_ConnectedRegions.Dispose();
                        ho_ObjectSelected1.Dispose();
                        ho_Rectangle1.Dispose();
                        ho_Rectangle2.Dispose();
                        ho_Position1Region.Dispose();
                        ho_Position2Region.Dispose();
                        ho_Rectangle.Dispose();
                        ho_ImageReduced.Dispose();
                        ho_Region.Dispose();
                        ho_ConnectedRegions1.Dispose();
                        ho_Cross.Dispose();
                        ho_bu1.Dispose();
                        ho_RegionLines.Dispose();
                        ho_a1.Dispose();
                        ho_c1.Dispose();
                        ho_a2.Dispose();
                        ho_c2.Dispose();
                        ho_Arrow2.Dispose();
                        ho_bv1.Dispose();
                        ho_Bu2.Dispose();
                        ho_bu2.Dispose();
                        ho_Bv2.Dispose();
                        ho_bv2.Dispose();
                        ho_b1.Dispose();
                        ho_b2.Dispose();
                        ho_MeasureLineBu1.Dispose();
                        ho_MeasureLineBv1.Dispose();
                        ho_MeasureLineBu2.Dispose();
                        ho_MeasureLineBv2.Dispose();
                        ho_t1.Dispose();
                        ho_t2.Dispose();
                        ho_cc1.Dispose();
                        ho_cc12.Dispose();
                        ho_cc13.Dispose();
                        ho_Circle1.Dispose();
                        ho_Arrow3.Dispose();
                        ho_ChanferPnt.Dispose();
                        ho_Circles.Dispose();
                        ho_Cross1.Dispose();
                        ho_cc2.Dispose();
                        ho_cc22.Dispose();
                        ho_cc23.Dispose();
                        ho_Circle2.Dispose();
                        ho_Surface1.Dispose();
                        ho_Surface2.Dispose();
                        ho_line.Dispose();
                        ho_line1.Dispose();
                        ho_Orig.Dispose();
                        ho_Arrow1.Dispose();
                        ho_OrgLine.Dispose();
                        ho_DrawLines.Dispose();
                        ho_Arrow.Dispose();
                        ho_CrossH.Dispose();
                        ho_CrossV.Dispose();
                        ho_DrawCircles.Dispose();
                        ho_DupImage.Dispose();
                        ho_R.Dispose();
                        ho_G.Dispose();
                        ho_B.Dispose();

                        hv_show.Dispose();
                        hv_ExrPnt_Range.Dispose();
                        hv_ExrPnt_Sigma.Dispose();
                        hv_ExrPnt_Amp.Dispose();
                        hv_ExrPnt_MeasureWidth.Dispose();
                        hv_ExrPnt_MeasureGap.Dispose();
                        hv_OnePnt_Amp.Dispose();
                        hv_OnePnt_MeasureWidth.Dispose();
                        hv_OnePnt_sigma.Dispose();
                        hv_Width1.Dispose();
                        hv_Height1.Dispose();
                        hv_UsedThreshold.Dispose();
                        hv_Area4.Dispose();
                        hv_Row1.Dispose();
                        hv_Column1.Dispose();
                        hv_Indices.Dispose();
                        hv_IsAutoRotate.Dispose();
                        hv_RectRow1.Dispose();
                        hv_RectColumn1.Dispose();
                        hv_RectRow2.Dispose();
                        hv_RectColumn2.Dispose();
                        hv_RectW.Dispose();
                        hv_RectH.Dispose();
                        hv_Area1.Dispose();
                        hv_CenterLRow.Dispose();
                        hv_CenterLCol.Dispose();
                        hv_Area3.Dispose();
                        hv_CenterRRow.Dispose();
                        hv_CenterRCol.Dispose();
                        hv_Phi.Dispose();
                        hv_HomMat2DIdentity.Dispose();
                        hv_rotateRow.Dispose();
                        hv_rotateCol.Dispose();
                        hv_HomMat2DRotate.Dispose();
                        hv_rotateAng.Dispose();
                        hv_Area2.Dispose();
                        hv_Row4.Dispose();
                        hv_Column4.Dispose();
                        hv_Indices3.Dispose();
                        hv_WaferRow1.Dispose();
                        hv_WaferCol1.Dispose();
                        hv_WaferRow2.Dispose();
                        hv_WaferRCol2.Dispose();
                        hv_Area.Dispose();
                        hv_Row.Dispose();
                        hv_Column.Dispose();
                        hv_OriginRow.Dispose();
                        hv_OriginCol.Dispose();
                        hv_Width.Dispose();
                        hv_Height.Dispose();
                        hv_WaferOriginRow.Dispose();
                        hv_WaferOriginCol.Dispose();
                        hv_RU_row.Dispose();
                        hv_RU_col.Dispose();
                        hv_A1AngOut.Dispose();
                        hv_MinDistance1.Dispose();
                        hv_A1Row_Cut.Dispose();
                        hv_A1Col_Cut.Dispose();
                        hv_A1Row.Dispose();
                        hv_A1Col.Dispose();
                        hv_C1AngOut.Dispose();
                        hv_C1Row_Cut.Dispose();
                        hv_C1Col_Cut.Dispose();
                        hv_C1Row.Dispose();
                        hv_C1Col.Dispose();
                        hv_RD_Row.Dispose();
                        hv_RD_Col.Dispose();
                        hv_A2AngOut.Dispose();
                        hv_A2Row_Cut.Dispose();
                        hv_A2Col_Cut.Dispose();
                        hv_A2Row.Dispose();
                        hv_A2Col.Dispose();
                        hv_C2AngOut.Dispose();
                        hv_C2Row_Cut.Dispose();
                        hv_C2Col_Cut.Dispose();
                        hv_C2Row.Dispose();
                        hv_C2Col.Dispose();
                        hv_bu1Row2.Dispose();
                        hv_bu1Col2.Dispose();
                        hv_bu1Row1.Dispose();
                        hv_bu1Col1.Dispose();
                        hv_bu1Row.Dispose();
                        hv_bu1Col.Dispose();
                        hv_bv1Row2.Dispose();
                        hv_bv1Col2.Dispose();
                        hv_bv1Row1.Dispose();
                        hv_bv1Col1.Dispose();
                        hv_bv1Row.Dispose();
                        hv_bv1Col.Dispose();
                        hv_bu2Row2.Dispose();
                        hv_bu2Col2.Dispose();
                        hv_bu2Row1.Dispose();
                        hv_bu2Col1.Dispose();
                        hv_bu2Row.Dispose();
                        hv_bu2Col.Dispose();
                        hv_bv2Row1.Dispose();
                        hv_bv2Col1.Dispose();
                        hv_bv2Row2.Dispose();
                        hv_bv2Col2.Dispose();
                        hv_bv2Row.Dispose();
                        hv_bv2Col.Dispose();
                        hv_B1Row.Dispose();
                        hv_B1Col.Dispose();
                        hv_IsOverlapping.Dispose();
                        hv_B2Row.Dispose();
                        hv_B2Col.Dispose();
                        hv_Angle1.Dispose();
                        hv_Angle2.Dispose();
                        hv_Ang12MeasureType.Dispose();
                        hv_DistanceA_T.Dispose();
                        hv_AB1Angle.Dispose();
                        hv_Distance.Dispose();
                        hv_Bu1Row1.Dispose();
                        hv_Bu1Col1.Dispose();
                        hv_Bu1Row2.Dispose();
                        hv_Bu1Col2.Dispose();
                        hv_Bv1Row1.Dispose();
                        hv_Bv1Col1.Dispose();
                        hv_Bv1Row2.Dispose();
                        hv_Bv1Col2.Dispose();
                        hv_AB2Angle.Dispose();
                        hv_Bu2Row2.Dispose();
                        hv_Bu2Col2.Dispose();
                        hv_Bu2Row1.Dispose();
                        hv_Bu2Col1.Dispose();
                        hv_Bv2Row2.Dispose();
                        hv_Bv2Col2.Dispose();
                        hv_Bv2Row1.Dispose();
                        hv_Bv2Col1.Dispose();
                        hv_t1Row.Dispose();
                        hv_t1Col.Dispose();
                        hv_t2Row.Dispose();
                        hv_t2Col.Dispose();
                        hv_CC1AngOut.Dispose();
                        hv_CC1Row_Cut.Dispose();
                        hv_CC1Col_Cut.Dispose();
                        hv_CC1Row.Dispose();
                        hv_CC1Col.Dispose();
                        hv_CC12AngOut.Dispose();
                        hv_CC12Row_Cut.Dispose();
                        hv_CC12Col_Cut.Dispose();
                        hv_CC12Row.Dispose();
                        hv_CC12Col.Dispose();
                        hv_CC13AngOut.Dispose();
                        hv_CC13Row_Cut.Dispose();
                        hv_CC13Col_Cut.Dispose();
                        hv_CC13Row.Dispose();
                        hv_CC13Col.Dispose();
                        hv_R_1CenterRow.Dispose();
                        hv_R_1CenterCol.Dispose();
                        hv_CircleR1.Dispose();
                        hv_chamfer1_Rows.Dispose();
                        hv_chamfer1_Cols.Dispose();
                        hv_n.Dispose();
                        hv_Y1.Dispose();
                        hv_Y2.Dispose();
                        hv_X1.Dispose();
                        hv_X2.Dispose();
                        hv_ChamferRow.Dispose();
                        hv_ChamferCol.Dispose();
                        hv_R1_Rows.Dispose();
                        hv_R1_Cols.Dispose();
                        hv_R1_Rs.Dispose();
                        hv_i.Dispose();
                        hv_Row_1.Dispose();
                        hv_Col_1.Dispose();
                        hv_j.Dispose();
                        hv_Row_2.Dispose();
                        hv_Col_2.Dispose();
                        hv_k.Dispose();
                        hv_Indices1.Dispose();
                        hv_R_1.Dispose();
                        hv_CC2AngOut.Dispose();
                        hv_CC2Row_Cut.Dispose();
                        hv_CC2Col_Cut.Dispose();
                        hv_CC2Row.Dispose();
                        hv_CC2Col.Dispose();
                        hv_CC22AngOut.Dispose();
                        hv_CC22Row_Cut.Dispose();
                        hv_CC22Col_Cut.Dispose();
                        hv_CC22Row.Dispose();
                        hv_CC22Col.Dispose();
                        hv_CC23AngOut.Dispose();
                        hv_CC23Row_Cut.Dispose();
                        hv_CC23Col_Cut.Dispose();
                        hv_CC23Row.Dispose();
                        hv_CC23Col.Dispose();
                        hv_R_2CenterRow.Dispose();
                        hv_R_2CenterCol.Dispose();
                        hv_CircleR2.Dispose();
                        hv_chamfer2_Rows.Dispose();
                        hv_chamfer2_Cols.Dispose();
                        hv_R2_Rows.Dispose();
                        hv_R2_Cols.Dispose();
                        hv_R2_Rs.Dispose();
                        hv_Indices2.Dispose();
                        hv_R_2.Dispose();
                        hv_Length.Dispose();
                        hv_Line_Org.Dispose();
                        hv_Line_Surface1.Dispose();
                        hv_Line_Surface2.Dispose();
                        hv_Line_Ang1.Dispose();
                        hv_Line_Ang2.Dispose();
                        hv_Line_A1.Dispose();
                        hv_Line_A2.Dispose();
                        hv_Line_B1.Dispose();
                        hv_Line_B2.Dispose();
                        hv_Line_R1.Dispose();
                        hv_Line_R2.Dispose();
                        hv_Line_C1.Dispose();
                        hv_Line_C2.Dispose();
                        hv_Lines.Dispose();
                        hv_Number.Dispose();
                        hv_X1_idx.Dispose();
                        hv_Y1_idx.Dispose();
                        hv_X2_idx.Dispose();
                        hv_Y2_idx.Dispose();
                        hv_textA1.Dispose();
                        hv_textA2.Dispose();
                        hv_textB1.Dispose();
                        hv_textB2.Dispose();
                        hv_textBC.Dispose();
                        hv_textC1.Dispose();
                        hv_textC2.Dispose();
                        hv_textR1.Dispose();
                        hv_textR2.Dispose();
                        hv_textt.Dispose();
                        hv_textAng1.Dispose();
                        hv_textAng2.Dispose();
                        hv_texts.Dispose();
                        hv_text_idx.Dispose();
                        hv_textX_idx.Dispose();
                        hv_textY_idx.Dispose();
                        hv_S4.Dispose();
                        hv_WindowHandle.Dispose();
                        hv_CrossSize.Dispose();
                        hv_CrossX.Dispose();
                        hv_CrossY.Dispose();

                        return;
                    }

                    ho_b1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_b1, hv_B1Row, hv_B1Col, 20, 0);
                    ho_b2.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_b2, hv_B2Row, hv_B2Col, 20, 0);
                    //計算 B1 & B2 座標
                    hv_Angle1.Dispose();
                    HOperatorSet.AngleLx(hv_bu1Row, hv_bu1Col, hv_bv1Row, hv_bv1Col, out hv_Angle1);
                    hv_Angle2.Dispose();
                    HOperatorSet.AngleLx(hv_bu2Row, hv_bu2Col, hv_bv2Row, hv_bv2Col, out hv_Angle2);
                    hv_Ang1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Ang1 = ((hv_Angle1.TupleDeg()
                            )).TupleAbs();
                    }
                    hv_Ang2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Ang2 = ((hv_Angle2.TupleDeg()
                            )).TupleAbs();
                    }
                    //--20230703 新版!!--垂直量測 Bu Bv 計算======結束

                }

                //計算t


                hv_DistanceA_T.Dispose();
                hv_DistanceA_T = 50;
                HOperatorSet.SetSystem("int_zooming", "true");
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_t1.Dispose(); hv_t1Row.Dispose(); hv_t1Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_t1, hv_A1Row + 100, hv_A1Col - hv_DistanceA_T, hv_A1Row - 100,
                        hv_A1Col - hv_DistanceA_T, hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma,
                        out hv_t1Row, out hv_t1Col);
                }
                if ((int)(new HTuple(hv_t1Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "t量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_t2.Dispose(); hv_t2Row.Dispose(); hv_t2Col.Dispose();
                    MeasurePos(ho_ImageOut, out ho_t2, hv_A2Row - 100, hv_A2Col - hv_DistanceA_T, hv_A2Row + 100,
                        hv_A2Col - hv_DistanceA_T, hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma,
                        out hv_t2Row, out hv_t2Col);
                }
                if ((int)(new HTuple(hv_t2Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "t量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_t.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_t = ((hv_t1Row - hv_t2Row)).TupleAbs()
                        ;
                }
                //t := abs(A1Row-A2Row)
                //t := abs(t1Row-B1Row)+abs(t2Row-B2Row)


                //量測導角上-----開始----

                hv_CC1AngOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC1AngOut = (-hv_Ang1) - hv_ExAngle;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_CC1AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_CC1AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_CC1AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_CC1AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC1Row_Cut.Dispose(); hv_CC1Col_Cut.Dispose(); hv_CC1Row.Dispose(); hv_CC1Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC1Row_Cut, out hv_CC1Col_Cut, out hv_CC1Row, out hv_CC1Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC1Row.Dispose(); hv_CC1Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC1Row_Cut, hv_CC1Col_Cut,
                        -hv_CC1AngOut, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_CC1Row, out hv_CC1Col);
                }
                ho_cc1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc1, hv_CC1Row, hv_CC1Col, 6, 0);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC12AngOut.Dispose();
                    AngleTrans(-hv_ExAngle, out hv_CC12AngOut);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_CC12AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_CC12AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_CC12AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_CC12AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC12Row_Cut.Dispose(); hv_CC12Col_Cut.Dispose(); hv_CC12Row.Dispose(); hv_CC12Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC12Row_Cut, out hv_CC12Col_Cut, out hv_CC12Row, out hv_CC12Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC12Row.Dispose(); hv_CC12Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC12Row_Cut, hv_CC12Col_Cut,
                        -hv_CC12AngOut, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_CC12Row, out hv_CC12Col);
                }
                ho_cc12.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc12, hv_CC12Row, hv_CC12Col, 6, 0);

                hv_CC13AngOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC13AngOut = (hv_CC1AngOut + hv_CC12AngOut) / 2.0;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_CC13AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_CC13AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_CC13AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_CC13AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC13Row_Cut.Dispose(); hv_CC13Col_Cut.Dispose(); hv_CC13Row.Dispose(); hv_CC13Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC13Row_Cut, out hv_CC13Col_Cut, out hv_CC13Row, out hv_CC13Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC13Row.Dispose(); hv_CC13Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC13Row_Cut, hv_CC13Col_Cut,
                        -hv_CC13AngOut, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_CC13Row, out hv_CC13Col);
                }
                ho_cc13.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc13, hv_CC13Row, hv_CC13Col, 6, 0);

                //GetCircleCenterFrom3Point (Circle1, [CC1Row,CC12Row,CC13Row], [CC1Col,CC12Col,CC13Col], PixelSize, R_1CenterRow, R_1CenterCol, CircleR1)

                hv_chamfer1_Rows.Dispose();
                hv_chamfer1_Rows = new HTuple();
                hv_chamfer1_Cols.Dispose();
                hv_chamfer1_Cols = new HTuple();
                HTuple end_val315 = hv_CMeasureNumber - 1;
                HTuple step_val315 = 1;
                for (hv_n = 0; hv_n.Continue(end_val315, step_val315); hv_n = hv_n.TupleAdd(step_val315))
                {
                    hv_Y1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Y1 = hv_CC1Row + ((hv_n * (hv_CC12Row - hv_CC1Row)) / (hv_CMeasureNumber - 1));
                    }
                    hv_Y2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Y2 = hv_CC1Row + ((hv_n * (hv_CC12Row - hv_CC1Row)) / (hv_CMeasureNumber - 1));
                    }
                    hv_X1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_X1 = hv_CC1Col - 20;
                    }
                    hv_X2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_X2 = hv_CC12Col + 20;
                    }
                    ho_Arrow3.Dispose();
                    gen_arrow_contour_xld(out ho_Arrow3, hv_Y1, hv_X1, hv_Y2, hv_X2, 5, 5);
                    ho_ChanferPnt.Dispose(); hv_ChamferRow.Dispose(); hv_ChamferCol.Dispose();
                    MeasurePos(ho_ImageReduced, out ho_ChanferPnt, hv_Y1, hv_X1, hv_Y2, hv_X2,
                        hv_OnePnt_MeasureWidth, 20, 1, out hv_ChamferRow, out hv_ChamferCol);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_chamfer1_Rows = hv_chamfer1_Rows.TupleConcat(
                                hv_ChamferRow);
                            hv_chamfer1_Rows.Dispose();
                            hv_chamfer1_Rows = ExpTmpLocalVar_chamfer1_Rows;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_chamfer1_Cols = hv_chamfer1_Cols.TupleConcat(
                                hv_ChamferCol);
                            hv_chamfer1_Cols.Dispose();
                            hv_chamfer1_Cols = ExpTmpLocalVar_chamfer1_Cols;
                        }
                    }
                }
                if ((int)(new HTuple(hv_chamfer1_Cols.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "導角量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_Bv2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_MeasureLineBu1.Dispose();
                    ho_MeasureLineBv1.Dispose();
                    ho_MeasureLineBu2.Dispose();
                    ho_MeasureLineBv2.Dispose();
                    ho_t1.Dispose();
                    ho_t2.Dispose();
                    ho_cc1.Dispose();
                    ho_cc12.Dispose();
                    ho_cc13.Dispose();
                    ho_Circle1.Dispose();
                    ho_Arrow3.Dispose();
                    ho_ChanferPnt.Dispose();
                    ho_Circles.Dispose();
                    ho_Cross1.Dispose();
                    ho_cc2.Dispose();
                    ho_cc22.Dispose();
                    ho_cc23.Dispose();
                    ho_Circle2.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_Arrow1.Dispose();
                    ho_OrgLine.Dispose();
                    ho_DrawLines.Dispose();
                    ho_Arrow.Dispose();
                    ho_CrossH.Dispose();
                    ho_CrossV.Dispose();
                    ho_DrawCircles.Dispose();
                    ho_DupImage.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();

                    hv_show.Dispose();
                    hv_ExrPnt_Range.Dispose();
                    hv_ExrPnt_Sigma.Dispose();
                    hv_ExrPnt_Amp.Dispose();
                    hv_ExrPnt_MeasureWidth.Dispose();
                    hv_ExrPnt_MeasureGap.Dispose();
                    hv_OnePnt_Amp.Dispose();
                    hv_OnePnt_MeasureWidth.Dispose();
                    hv_OnePnt_sigma.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_IsAutoRotate.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_Phi.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_A1Row_Cut.Dispose();
                    hv_A1Col_Cut.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row_Cut.Dispose();
                    hv_C1Col_Cut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row_Cut.Dispose();
                    hv_A2Col_Cut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row_Cut.Dispose();
                    hv_C2Col_Cut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Ang12MeasureType.Dispose();
                    hv_DistanceA_T.Dispose();
                    hv_AB1Angle.Dispose();
                    hv_Distance.Dispose();
                    hv_Bu1Row1.Dispose();
                    hv_Bu1Col1.Dispose();
                    hv_Bu1Row2.Dispose();
                    hv_Bu1Col2.Dispose();
                    hv_Bv1Row1.Dispose();
                    hv_Bv1Col1.Dispose();
                    hv_Bv1Row2.Dispose();
                    hv_Bv1Col2.Dispose();
                    hv_AB2Angle.Dispose();
                    hv_Bu2Row2.Dispose();
                    hv_Bu2Col2.Dispose();
                    hv_Bu2Row1.Dispose();
                    hv_Bu2Col1.Dispose();
                    hv_Bv2Row2.Dispose();
                    hv_Bv2Col2.Dispose();
                    hv_Bv2Row1.Dispose();
                    hv_Bv2Col1.Dispose();
                    hv_t1Row.Dispose();
                    hv_t1Col.Dispose();
                    hv_t2Row.Dispose();
                    hv_t2Col.Dispose();
                    hv_CC1AngOut.Dispose();
                    hv_CC1Row_Cut.Dispose();
                    hv_CC1Col_Cut.Dispose();
                    hv_CC1Row.Dispose();
                    hv_CC1Col.Dispose();
                    hv_CC12AngOut.Dispose();
                    hv_CC12Row_Cut.Dispose();
                    hv_CC12Col_Cut.Dispose();
                    hv_CC12Row.Dispose();
                    hv_CC12Col.Dispose();
                    hv_CC13AngOut.Dispose();
                    hv_CC13Row_Cut.Dispose();
                    hv_CC13Col_Cut.Dispose();
                    hv_CC13Row.Dispose();
                    hv_CC13Col.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_CircleR1.Dispose();
                    hv_chamfer1_Rows.Dispose();
                    hv_chamfer1_Cols.Dispose();
                    hv_n.Dispose();
                    hv_Y1.Dispose();
                    hv_Y2.Dispose();
                    hv_X1.Dispose();
                    hv_X2.Dispose();
                    hv_ChamferRow.Dispose();
                    hv_ChamferCol.Dispose();
                    hv_R1_Rows.Dispose();
                    hv_R1_Cols.Dispose();
                    hv_R1_Rs.Dispose();
                    hv_i.Dispose();
                    hv_Row_1.Dispose();
                    hv_Col_1.Dispose();
                    hv_j.Dispose();
                    hv_Row_2.Dispose();
                    hv_Col_2.Dispose();
                    hv_k.Dispose();
                    hv_Indices1.Dispose();
                    hv_R_1.Dispose();
                    hv_CC2AngOut.Dispose();
                    hv_CC2Row_Cut.Dispose();
                    hv_CC2Col_Cut.Dispose();
                    hv_CC2Row.Dispose();
                    hv_CC2Col.Dispose();
                    hv_CC22AngOut.Dispose();
                    hv_CC22Row_Cut.Dispose();
                    hv_CC22Col_Cut.Dispose();
                    hv_CC22Row.Dispose();
                    hv_CC22Col.Dispose();
                    hv_CC23AngOut.Dispose();
                    hv_CC23Row_Cut.Dispose();
                    hv_CC23Col_Cut.Dispose();
                    hv_CC23Row.Dispose();
                    hv_CC23Col.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_CircleR2.Dispose();
                    hv_chamfer2_Rows.Dispose();
                    hv_chamfer2_Cols.Dispose();
                    hv_R2_Rows.Dispose();
                    hv_R2_Cols.Dispose();
                    hv_R2_Rs.Dispose();
                    hv_Indices2.Dispose();
                    hv_R_2.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_Number.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();
                    hv_CrossSize.Dispose();
                    hv_CrossX.Dispose();
                    hv_CrossY.Dispose();

                    return;
                }
                hv_R1_Rows.Dispose();
                hv_R1_Rows = new HTuple();
                hv_R1_Cols.Dispose();
                hv_R1_Cols = new HTuple();
                hv_R1_Rs.Dispose();
                hv_R1_Rs = new HTuple();
                //將量測點做三點圓計算，算出所有的半徑、圓心，再選擇最小的那個圓當作結果
                for (hv_i = 0; (int)hv_i <= (int)((new HTuple(hv_chamfer1_Rows.TupleLength())) - 2); hv_i = (int)hv_i + 1)
                {
                    hv_Row_1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Row_1 = hv_chamfer1_Rows.TupleSelect(
                            hv_i);
                    }
                    hv_Col_1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Col_1 = hv_chamfer1_Cols.TupleSelect(
                            hv_i);
                    }
                    HTuple end_val336 = (new HTuple(hv_chamfer1_Rows.TupleLength()
                        )) - 2;
                    HTuple step_val336 = 1;
                    for (hv_j = hv_i + 1; hv_j.Continue(end_val336, step_val336); hv_j = hv_j.TupleAdd(step_val336))
                    {
                        hv_Row_2.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Row_2 = hv_chamfer1_Rows.TupleSelect(
                                hv_j);
                        }
                        hv_Col_2.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Col_2 = hv_chamfer1_Cols.TupleSelect(
                                hv_j);
                        }
                        //for k := j+1 to |chamfer1_Rows|-2 by 1
                        //Row_3 := chamfer1_Rows[k]
                        //Col_3 := chamfer1_Cols[k]
                        //GetCircleCenterFrom3Point (Circles, [Row_1,Row_2,Row_3], [Col_1,Col_2,Col_3], PixelSize, R_1CenterRow, R_1CenterCol, CircleR1)

                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_Circles.Dispose(); hv_R_1CenterRow.Dispose(); hv_R_1CenterCol.Dispose(); hv_CircleR1.Dispose();
                            GetCircleCenterFrom3Point(out ho_Circles, ((hv_Row_1.TupleConcat(hv_Row_2))).TupleConcat(
                                hv_chamfer1_Rows.TupleSelect((new HTuple(hv_chamfer1_Rows.TupleLength()
                                )) - 1)), ((hv_Col_1.TupleConcat(hv_Col_2))).TupleConcat(hv_chamfer1_Cols.TupleSelect(
                                (new HTuple(hv_chamfer1_Cols.TupleLength())) - 1)), hv_PixelSize, out hv_R_1CenterRow,
                                out hv_R_1CenterCol, out hv_CircleR1);
                        }

                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R1_Rows = hv_R1_Rows.TupleConcat(
                                    hv_R_1CenterRow);
                                hv_R1_Rows.Dispose();
                                hv_R1_Rows = ExpTmpLocalVar_R1_Rows;
                            }
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R1_Cols = hv_R1_Cols.TupleConcat(
                                    hv_R_1CenterCol);
                                hv_R1_Cols.Dispose();
                                hv_R1_Cols = ExpTmpLocalVar_R1_Cols;
                            }
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R1_Rs = hv_R1_Rs.TupleConcat(
                                    hv_CircleR1);
                                hv_R1_Rs.Dispose();
                                hv_R1_Rs = ExpTmpLocalVar_R1_Rs;
                            }
                        }

                        //endfor
                    }
                }

                hv_Indices1.Dispose();
                HOperatorSet.TupleSortIndex(hv_R1_Rs, out hv_Indices1);
                hv_R_1CenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_1CenterRow = hv_R1_Rows.TupleSelect(
                        hv_Indices1.TupleSelect(0));
                }
                hv_R_1CenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_1CenterCol = hv_R1_Cols.TupleSelect(
                        hv_Indices1.TupleSelect(0));
                }
                hv_CircleR1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CircleR1 = hv_R1_Rs.TupleSelect(
                        hv_Indices1.TupleSelect(0));
                }
                hv_R_1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_1 = hv_CircleR1 / hv_PixelSize;
                }
                //顯示
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Circle1.Dispose();
                    HOperatorSet.GenCircleContourXld(out ho_Circle1, hv_R1_Rows.TupleSelect(hv_Indices1.TupleSelect(
                        0)), hv_R1_Cols.TupleSelect(hv_Indices1.TupleSelect(0)), (hv_R1_Rs.TupleSelect(
                        hv_Indices1.TupleSelect(0))) / hv_PixelSize, 0, 6.28318, "positive", 1);
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_Circle1, HDevWindowStack.GetActive());
                }
                ho_Cross1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross1, hv_chamfer1_Rows, hv_chamfer1_Cols,
                    6, 0);
                if (HDevWindowStack.IsOpen())
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        HOperatorSet.DispText(HDevWindowStack.GetActive(), hv_CircleR1, "image",
                            hv_R1_Rows.TupleSelect(hv_Indices1.TupleSelect(0)), hv_R1_Cols.TupleSelect(
                            hv_Indices1.TupleSelect(0)), "black", new HTuple(), new HTuple());
                    }
                }


                //導角上-----結束----

                //導角下-----開始----
                hv_CC2AngOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC2AngOut = hv_Ang2 + hv_ExAngle;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_CC2AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_CC2AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_CC2AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_CC2AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC2Row_Cut.Dispose(); hv_CC2Col_Cut.Dispose(); hv_CC2Row.Dispose(); hv_CC2Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC2Row_Cut, out hv_CC2Col_Cut, out hv_CC2Row, out hv_CC2Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC2Row.Dispose(); hv_CC2Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC2Row_Cut, hv_CC2Col_Cut,
                        (-hv_CC2AngOut) + 180, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp, hv_ExrPnt_MeasureWidth,
                        hv_ExrPnt_MeasureGap, out hv_CC2Row, out hv_CC2Col);
                }
                ho_cc2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc2, hv_CC2Row, hv_CC2Col, 6, 0);

                hv_CC22AngOut.Dispose();
                AngleTrans(hv_ExAngle, out hv_CC22AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_CC22AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_CC22AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_CC22AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_CC22AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC22Row_Cut.Dispose(); hv_CC22Col_Cut.Dispose(); hv_CC22Row.Dispose(); hv_CC22Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC22Row_Cut, out hv_CC22Col_Cut, out hv_CC22Row, out hv_CC22Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC22Row.Dispose(); hv_CC22Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC22Row_Cut, hv_CC22Col_Cut,
                        (-hv_CC22AngOut) + 180, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp,
                        hv_ExrPnt_MeasureWidth, hv_ExrPnt_MeasureGap, out hv_CC22Row, out hv_CC22Col);
                }
                ho_cc22.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc22, hv_CC22Row, hv_CC22Col, 6, 0);

                hv_CC23AngOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC23AngOut = (hv_CC2AngOut + hv_CC22AngOut) / 2.0;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_CC23AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_CC23AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_CC23AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_CC23AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_CC23Row_Cut.Dispose(); hv_CC23Col_Cut.Dispose(); hv_CC23Row.Dispose(); hv_CC23Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_CC23Row_Cut, out hv_CC23Col_Cut, out hv_CC23Row, out hv_CC23Col);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CC23Row.Dispose(); hv_CC23Col.Dispose();
                    CutLineMinDistanceAndPnt(ho_ImageOut, hv_ExrPnt_Range, hv_CC23Row_Cut, hv_CC23Col_Cut,
                        (-hv_CC23AngOut) + 180, hv_MinDistance1, hv_ExrPnt_Sigma, hv_ExrPnt_Amp,
                        hv_ExrPnt_MeasureWidth, hv_ExrPnt_MeasureGap, out hv_CC23Row, out hv_CC23Col);
                }
                ho_cc23.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_cc23, hv_CC23Row, hv_CC23Col, 6, 0);

                //GetCircleCenterFrom3Point (Circle2, [CC23Row,CC22Row,CC2Row], [CC23Col,CC22Col,CC2Col], PixelSize, R_2CenterRow, R_2CenterCol, CircleR2)


                hv_chamfer2_Rows.Dispose();
                hv_chamfer2_Rows = new HTuple();
                hv_chamfer2_Cols.Dispose();
                hv_chamfer2_Cols = new HTuple();
                HTuple end_val393 = hv_CMeasureNumber - 1;
                HTuple step_val393 = 1;
                for (hv_n = 0; hv_n.Continue(end_val393, step_val393); hv_n = hv_n.TupleAdd(step_val393))
                {
                    hv_Y1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Y1 = hv_CC2Row + ((hv_n * (hv_CC22Row - hv_CC2Row)) / (hv_CMeasureNumber - 1));
                    }
                    hv_Y2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Y2 = hv_CC2Row + ((hv_n * (hv_CC22Row - hv_CC2Row)) / (hv_CMeasureNumber - 1));
                    }
                    hv_X1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_X1 = hv_CC2Col - 20;
                    }
                    hv_X2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_X2 = hv_CC22Col + 20;
                    }
                    ho_Arrow3.Dispose();
                    gen_arrow_contour_xld(out ho_Arrow3, hv_Y1, hv_X1, hv_Y2, hv_X2, 5, 5);
                    ho_ChanferPnt.Dispose(); hv_ChamferRow.Dispose(); hv_ChamferCol.Dispose();
                    MeasurePos(ho_ImageReduced, out ho_ChanferPnt, hv_Y1, hv_X1, hv_Y2, hv_X2,
                        hv_OnePnt_MeasureWidth, hv_OnePnt_Amp, hv_OnePnt_sigma, out hv_ChamferRow,
                        out hv_ChamferCol);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_chamfer2_Rows = hv_chamfer2_Rows.TupleConcat(
                                hv_ChamferRow);
                            hv_chamfer2_Rows.Dispose();
                            hv_chamfer2_Rows = ExpTmpLocalVar_chamfer2_Rows;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_chamfer2_Cols = hv_chamfer2_Cols.TupleConcat(
                                hv_ChamferCol);
                            hv_chamfer2_Cols.Dispose();
                            hv_chamfer2_Cols = ExpTmpLocalVar_chamfer2_Cols;
                        }
                    }
                }
                if ((int)(new HTuple(hv_chamfer2_Rows.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "導角量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_Bv2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_MeasureLineBu1.Dispose();
                    ho_MeasureLineBv1.Dispose();
                    ho_MeasureLineBu2.Dispose();
                    ho_MeasureLineBv2.Dispose();
                    ho_t1.Dispose();
                    ho_t2.Dispose();
                    ho_cc1.Dispose();
                    ho_cc12.Dispose();
                    ho_cc13.Dispose();
                    ho_Circle1.Dispose();
                    ho_Arrow3.Dispose();
                    ho_ChanferPnt.Dispose();
                    ho_Circles.Dispose();
                    ho_Cross1.Dispose();
                    ho_cc2.Dispose();
                    ho_cc22.Dispose();
                    ho_cc23.Dispose();
                    ho_Circle2.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_Arrow1.Dispose();
                    ho_OrgLine.Dispose();
                    ho_DrawLines.Dispose();
                    ho_Arrow.Dispose();
                    ho_CrossH.Dispose();
                    ho_CrossV.Dispose();
                    ho_DrawCircles.Dispose();
                    ho_DupImage.Dispose();
                    ho_R.Dispose();
                    ho_G.Dispose();
                    ho_B.Dispose();

                    hv_show.Dispose();
                    hv_ExrPnt_Range.Dispose();
                    hv_ExrPnt_Sigma.Dispose();
                    hv_ExrPnt_Amp.Dispose();
                    hv_ExrPnt_MeasureWidth.Dispose();
                    hv_ExrPnt_MeasureGap.Dispose();
                    hv_OnePnt_Amp.Dispose();
                    hv_OnePnt_MeasureWidth.Dispose();
                    hv_OnePnt_sigma.Dispose();
                    hv_Width1.Dispose();
                    hv_Height1.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_IsAutoRotate.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_Phi.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_A1Row_Cut.Dispose();
                    hv_A1Col_Cut.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row_Cut.Dispose();
                    hv_C1Col_Cut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row_Cut.Dispose();
                    hv_A2Col_Cut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row_Cut.Dispose();
                    hv_C2Col_Cut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Ang12MeasureType.Dispose();
                    hv_DistanceA_T.Dispose();
                    hv_AB1Angle.Dispose();
                    hv_Distance.Dispose();
                    hv_Bu1Row1.Dispose();
                    hv_Bu1Col1.Dispose();
                    hv_Bu1Row2.Dispose();
                    hv_Bu1Col2.Dispose();
                    hv_Bv1Row1.Dispose();
                    hv_Bv1Col1.Dispose();
                    hv_Bv1Row2.Dispose();
                    hv_Bv1Col2.Dispose();
                    hv_AB2Angle.Dispose();
                    hv_Bu2Row2.Dispose();
                    hv_Bu2Col2.Dispose();
                    hv_Bu2Row1.Dispose();
                    hv_Bu2Col1.Dispose();
                    hv_Bv2Row2.Dispose();
                    hv_Bv2Col2.Dispose();
                    hv_Bv2Row1.Dispose();
                    hv_Bv2Col1.Dispose();
                    hv_t1Row.Dispose();
                    hv_t1Col.Dispose();
                    hv_t2Row.Dispose();
                    hv_t2Col.Dispose();
                    hv_CC1AngOut.Dispose();
                    hv_CC1Row_Cut.Dispose();
                    hv_CC1Col_Cut.Dispose();
                    hv_CC1Row.Dispose();
                    hv_CC1Col.Dispose();
                    hv_CC12AngOut.Dispose();
                    hv_CC12Row_Cut.Dispose();
                    hv_CC12Col_Cut.Dispose();
                    hv_CC12Row.Dispose();
                    hv_CC12Col.Dispose();
                    hv_CC13AngOut.Dispose();
                    hv_CC13Row_Cut.Dispose();
                    hv_CC13Col_Cut.Dispose();
                    hv_CC13Row.Dispose();
                    hv_CC13Col.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_CircleR1.Dispose();
                    hv_chamfer1_Rows.Dispose();
                    hv_chamfer1_Cols.Dispose();
                    hv_n.Dispose();
                    hv_Y1.Dispose();
                    hv_Y2.Dispose();
                    hv_X1.Dispose();
                    hv_X2.Dispose();
                    hv_ChamferRow.Dispose();
                    hv_ChamferCol.Dispose();
                    hv_R1_Rows.Dispose();
                    hv_R1_Cols.Dispose();
                    hv_R1_Rs.Dispose();
                    hv_i.Dispose();
                    hv_Row_1.Dispose();
                    hv_Col_1.Dispose();
                    hv_j.Dispose();
                    hv_Row_2.Dispose();
                    hv_Col_2.Dispose();
                    hv_k.Dispose();
                    hv_Indices1.Dispose();
                    hv_R_1.Dispose();
                    hv_CC2AngOut.Dispose();
                    hv_CC2Row_Cut.Dispose();
                    hv_CC2Col_Cut.Dispose();
                    hv_CC2Row.Dispose();
                    hv_CC2Col.Dispose();
                    hv_CC22AngOut.Dispose();
                    hv_CC22Row_Cut.Dispose();
                    hv_CC22Col_Cut.Dispose();
                    hv_CC22Row.Dispose();
                    hv_CC22Col.Dispose();
                    hv_CC23AngOut.Dispose();
                    hv_CC23Row_Cut.Dispose();
                    hv_CC23Col_Cut.Dispose();
                    hv_CC23Row.Dispose();
                    hv_CC23Col.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_CircleR2.Dispose();
                    hv_chamfer2_Rows.Dispose();
                    hv_chamfer2_Cols.Dispose();
                    hv_R2_Rows.Dispose();
                    hv_R2_Cols.Dispose();
                    hv_R2_Rs.Dispose();
                    hv_Indices2.Dispose();
                    hv_R_2.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_Number.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();
                    hv_CrossSize.Dispose();
                    hv_CrossX.Dispose();
                    hv_CrossY.Dispose();

                    return;
                }
                hv_R2_Rows.Dispose();
                hv_R2_Rows = new HTuple();
                hv_R2_Cols.Dispose();
                hv_R2_Cols = new HTuple();
                hv_R2_Rs.Dispose();
                hv_R2_Rs = new HTuple();
                //將量測點做三點圓計算，算出所有的半徑、圓心，再選擇最小的那個圓當作結果
                for (hv_i = 0; (int)hv_i <= (int)((new HTuple(hv_chamfer2_Rows.TupleLength())) - 2); hv_i = (int)hv_i + 1)
                {
                    hv_Row_1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Row_1 = hv_chamfer2_Rows.TupleSelect(
                            hv_i);
                    }
                    hv_Col_1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Col_1 = hv_chamfer2_Cols.TupleSelect(
                            hv_i);
                    }
                    HTuple end_val414 = (new HTuple(hv_chamfer2_Rows.TupleLength()
                        )) - 2;
                    HTuple step_val414 = 1;
                    for (hv_j = hv_i + 1; hv_j.Continue(end_val414, step_val414); hv_j = hv_j.TupleAdd(step_val414))
                    {
                        hv_Row_2.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Row_2 = hv_chamfer2_Rows.TupleSelect(
                                hv_j);
                        }
                        hv_Col_2.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Col_2 = hv_chamfer2_Cols.TupleSelect(
                                hv_j);
                        }
                        //for k := j+1 to |chamfer2_Rows|-2 by 1
                        //Row_3 := chamfer2_Rows[k]
                        //Col_3 := chamfer2_Cols[k]
                        //GetCircleCenterFrom3Point (Circles, [Row_1,Row_2,Row_3], [Col_1,Col_2,Row_3], PixelSize, R_2CenterRow, R_2CenterCol, CircleR2)

                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_Circles.Dispose(); hv_R_2CenterRow.Dispose(); hv_R_2CenterCol.Dispose(); hv_CircleR2.Dispose();
                            GetCircleCenterFrom3Point(out ho_Circles, ((hv_Row_1.TupleConcat(hv_Row_2))).TupleConcat(
                                hv_chamfer2_Rows.TupleSelect((new HTuple(hv_chamfer2_Rows.TupleLength()
                                )) - 1)), ((hv_Col_1.TupleConcat(hv_Col_2))).TupleConcat(hv_chamfer2_Cols.TupleSelect(
                                (new HTuple(hv_chamfer2_Cols.TupleLength())) - 1)), hv_PixelSize, out hv_R_2CenterRow,
                                out hv_R_2CenterCol, out hv_CircleR2);
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R2_Rows = hv_R2_Rows.TupleConcat(
                                    hv_R_2CenterRow);
                                hv_R2_Rows.Dispose();
                                hv_R2_Rows = ExpTmpLocalVar_R2_Rows;
                            }
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R2_Cols = hv_R2_Cols.TupleConcat(
                                    hv_R_2CenterCol);
                                hv_R2_Cols.Dispose();
                                hv_R2_Cols = ExpTmpLocalVar_R2_Cols;
                            }
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_R2_Rs = hv_R2_Rs.TupleConcat(
                                    hv_CircleR2);
                                hv_R2_Rs.Dispose();
                                hv_R2_Rs = ExpTmpLocalVar_R2_Rs;
                            }
                        }

                        //endfor
                    }
                }

                hv_Indices2.Dispose();
                HOperatorSet.TupleSortIndex(hv_R2_Rs, out hv_Indices2);
                hv_R_2CenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_2CenterRow = hv_R2_Rows.TupleSelect(
                        hv_Indices2.TupleSelect(0));
                }
                hv_R_2CenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_2CenterCol = hv_R2_Cols.TupleSelect(
                        hv_Indices2.TupleSelect(0));
                }
                hv_CircleR2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CircleR2 = hv_R2_Rs.TupleSelect(
                        hv_Indices2.TupleSelect(0));
                }
                hv_R_2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_R_2 = hv_CircleR2 / hv_PixelSize;
                }

                //顯示
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Circle2.Dispose();
                    HOperatorSet.GenCircleContourXld(out ho_Circle2, hv_R2_Rows.TupleSelect(hv_Indices2.TupleSelect(
                        0)), hv_R2_Cols.TupleSelect(hv_Indices2.TupleSelect(0)), (hv_R2_Rs.TupleSelect(
                        hv_Indices2.TupleSelect(0))) / hv_PixelSize, 0, 6.28318, "positive", 1);
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_Circle2, HDevWindowStack.GetActive());
                }
                ho_Cross1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross1, hv_chamfer2_Rows, hv_chamfer2_Cols,
                    6, 0);
                if (HDevWindowStack.IsOpen())
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        HOperatorSet.DispText(HDevWindowStack.GetActive(), hv_CircleR2, "image",
                            hv_R2_Rows.TupleSelect(hv_Indices2.TupleSelect(0)), hv_R2_Cols.TupleSelect(
                            hv_Indices2.TupleSelect(0)), "black", new HTuple(), new HTuple());
                    }
                }

                //導角下-----結束----




                hv_A1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A1 = (hv_B1Col - hv_A1Col) * hv_PixelSize;
                }
                hv_A2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A2 = (hv_B2Col - hv_A2Col) * hv_PixelSize;
                }
                hv_B1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_B1 = (((hv_t1Row - hv_B1Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                hv_B2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_B2 = (((hv_t2Row - hv_B2Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                hv_BC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_BC = (((hv_B1Row - hv_B2Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                if ((int)(new HTuple(hv_R_1CenterRow.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_C1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_C1 = (((hv_B1Row - (hv_R_1CenterRow.TupleSelect(
                            0)))).TupleAbs()) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_C1.Dispose();
                    hv_C1 = -1;
                }
                if ((int)(new HTuple(hv_R_2CenterRow.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_C2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_C2 = (((hv_B2Row - (hv_R_2CenterRow.TupleSelect(
                            0)))).TupleAbs()) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_C2.Dispose();
                    hv_C2 = -1;
                }


                if ((int)(new HTuple(hv_R_1.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_R1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_R1 = (hv_R_1.TupleSelect(
                            0)) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_R1.Dispose();
                    hv_R1 = -1;
                }
                if ((int)(new HTuple(hv_R_2.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_R2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_R2 = (hv_R_2.TupleSelect(
                            0)) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_R2.Dispose();
                    hv_R2 = -1;
                }

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_t = hv_t * hv_PixelSize;
                        hv_t.Dispose();
                        hv_t = ExpTmpLocalVar_t;
                    }
                }
                //可視化參數輸出
                hv_Length.Dispose();
                hv_Length = 100;
                if ((int)(new HTuple(hv_R_1CenterCol.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_Cir_c1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Cir_c1 = new HTuple();
                        hv_Cir_c1 = hv_Cir_c1.TupleConcat(hv_R_1CenterCol.TupleSelect(
                            0));
                        hv_Cir_c1 = hv_Cir_c1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                            0));
                        hv_Cir_c1 = hv_Cir_c1.TupleConcat((hv_R_1.TupleSelect(0)) / hv_PixelSize);
                    }
                }
                if ((int)(new HTuple(hv_R_2CenterCol.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_Cir_c2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Cir_c2 = new HTuple();
                        hv_Cir_c2 = hv_Cir_c2.TupleConcat(hv_R_2CenterCol.TupleSelect(
                            0));
                        hv_Cir_c2 = hv_Cir_c2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                            0));
                        hv_Cir_c2 = hv_Cir_c2.TupleConcat((hv_R_2.TupleSelect(0)) / hv_PixelSize);
                    }
                }

                hv_Line_Org.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Org = new HTuple();
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_OriginCol);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_A1Row - hv_Length);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_OriginCol);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_A2Row + hv_Length);
                }
                hv_Line_Surface1.Dispose();
                hv_Line_Surface1 = new HTuple();
                hv_Line_Surface2.Dispose();
                hv_Line_Surface2 = new HTuple();
                //Line_Surface1 := [ 0,A1Row, B1Col + Length, A1Row]
                //Line_Surface2 := [ 0,A2Row, B2Col + Length, A2Row]
                hv_Line_Ang1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Ang1 = new HTuple();
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_bu1Col - ((hv_Length * 2) * (((((-hv_Ang1)).TupleRad()
                        )).TupleCos())));
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_bu1Row + ((hv_Length * 2) * (((((-hv_Ang1)).TupleRad()
                        )).TupleSin())));
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_B1Col, hv_B1Row);
                }
                hv_Line_Ang2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Ang2 = new HTuple();
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_bu2Col - ((hv_Length * 2) * (((hv_Ang2.TupleRad()
                        )).TupleCos())));
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_bu2Row + ((hv_Length * 2) * (((hv_Ang2.TupleRad()
                        )).TupleSin())));
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_B2Col, hv_B2Row);
                }
                hv_Line_A1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_A1 = new HTuple();
                    hv_Line_A1 = hv_Line_A1.TupleConcat(hv_A1Col, hv_A1Row, hv_A1Col);
                    hv_Line_A1 = hv_Line_A1.TupleConcat(hv_A1Row - hv_Length);
                }
                hv_Line_A2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_A2 = new HTuple();
                    hv_Line_A2 = hv_Line_A2.TupleConcat(hv_A2Col, hv_A2Row, hv_A2Col);
                    hv_Line_A2 = hv_Line_A2.TupleConcat(hv_A2Row + hv_Length);
                }
                hv_Line_B1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_B1 = new HTuple();
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Col, hv_B1Row);
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Col + hv_Length);
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Row);
                }
                hv_Line_B2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_B2 = new HTuple();
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Col, hv_B2Row);
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Col + hv_Length);
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Row);
                }
                hv_Line_R1.Dispose();
                hv_Line_R1 = new HTuple();
                hv_Line_R2.Dispose();
                hv_Line_R2 = new HTuple();
                //Line_R1 := [R_1CenterCol[0],R_1CenterRow[0],R_1CenterCol[0]+R_1[0]*cos(rad(180+Ang1)),R_1CenterRow[0]+R_1[0]*sin(rad(180+Ang1))]
                //Line_R2 := [R_2CenterCol[0],R_2CenterRow[0],R_2CenterCol[0]+R_2[0]*cos(rad(180-Ang2)),R_2CenterRow[0]+R_2[0]*sin(rad(180-Ang1))]

                hv_Line_C1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_C1 = new HTuple();
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_OriginCol + (hv_Length * 0.1));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_OriginCol + (hv_Length * 0.5));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                }
                hv_Line_C2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_C2 = new HTuple();
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_OriginCol + (hv_Length * 0.1));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_OriginCol + (hv_Length * 0.5));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                }

                hv_Lines.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Lines = new HTuple();
                    hv_Lines = hv_Lines.TupleConcat(hv_Line_Org, hv_Line_Surface1, hv_Line_Surface2, hv_Line_Ang1, hv_Line_Ang2, hv_Line_A1, hv_Line_A2, hv_Line_B1, hv_Line_B2, hv_Line_R1, hv_Line_R2, hv_Line_C1, hv_Line_C2);
                }
                hv_Number.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Number = new HTuple(hv_Lines.TupleLength()
                        );
                }
                hv_X1_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X1_idx = HTuple.TupleGenSequence(
                        0, hv_Number - 1, 4);
                }
                hv_Y1_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Y1_idx = HTuple.TupleGenSequence(
                        1, hv_Number - 1, 4);
                }
                hv_X2_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X2_idx = HTuple.TupleGenSequence(
                        2, hv_Number - 1, 4);
                }
                hv_Y2_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Y2_idx = HTuple.TupleGenSequence(
                        3, hv_Number - 1, 4);
                }

                hv_LinesX1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesX1 = hv_Lines.TupleSelect(
                        hv_X1_idx);
                }
                hv_LinesY1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesY1 = hv_Lines.TupleSelect(
                        hv_Y1_idx);
                }
                hv_LinesX2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesX2 = hv_Lines.TupleSelect(
                        hv_X2_idx);
                }
                hv_LinesY2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesY2 = hv_Lines.TupleSelect(
                        hv_Y2_idx);
                }
                //建立每個輸出的文字及座標
                hv_textA1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textA1 = new HTuple();
                    hv_textA1[0] = "A1";
                    hv_textA1 = hv_textA1.TupleConcat((((hv_A1Col + hv_OriginCol)).TupleAbs()
                        ) / 2);
                    hv_textA1 = hv_textA1.TupleConcat(hv_A1Row);
                }
                hv_textA2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textA2 = new HTuple();
                    hv_textA2[0] = "A2";
                    hv_textA2 = hv_textA2.TupleConcat((((hv_A2Col + hv_OriginCol)).TupleAbs()
                        ) / 2);
                    hv_textA2 = hv_textA2.TupleConcat(hv_A2Row);
                }
                hv_textB1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textB1 = new HTuple();
                    hv_textB1[0] = "B1";
                    hv_textB1 = hv_textB1.TupleConcat(hv_B1Col);
                    hv_textB1 = hv_textB1.TupleConcat((((hv_B1Row + hv_A1Row)).TupleAbs()
                        ) / 2);
                }
                hv_textB2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textB2 = new HTuple();
                    hv_textB2[0] = "B1";
                    hv_textB2 = hv_textB2.TupleConcat(hv_B1Col);
                    hv_textB2 = hv_textB2.TupleConcat((((hv_B2Row + hv_A2Row)).TupleAbs()
                        ) / 2);
                }
                hv_textBC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textBC = new HTuple();
                    hv_textBC[0] = "BC";
                    hv_textBC = hv_textBC.TupleConcat(hv_OriginCol + (0.8 * hv_Length));
                    hv_textBC = hv_textBC.TupleConcat(hv_OriginRow);
                }
                hv_textC1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textC1 = new HTuple();
                    hv_textC1[0] = "C1";
                    hv_textC1 = hv_textC1.TupleConcat(hv_OriginCol + (0.55 * hv_Length));
                    hv_textC1 = hv_textC1.TupleConcat(hv_B1Row + (hv_Cir_c1.TupleSelect(
                        2)));
                }
                hv_textC2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textC2 = new HTuple();
                    hv_textC2[0] = "C2";
                    hv_textC2 = hv_textC2.TupleConcat(hv_OriginCol + (0.55 * hv_Length));
                    hv_textC2 = hv_textC2.TupleConcat(hv_B2Row - (hv_Cir_c2.TupleSelect(
                        2)));
                }
                hv_textR1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textR1 = new HTuple();
                    hv_textR1[0] = "R1";
                    hv_textR1 = hv_textR1.TupleConcat((hv_R_1CenterCol.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleCos()
                        )));
                    hv_textR1 = hv_textR1.TupleConcat((hv_R_1CenterRow.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_textR2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textR2 = new HTuple();
                    hv_textR2[0] = "R2";
                    hv_textR2 = hv_textR2.TupleConcat((hv_R_2CenterCol.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang2)).TupleRad())).TupleCos()
                        )));
                    hv_textR2 = hv_textR2.TupleConcat((hv_R_2CenterRow.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_textt.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textt = new HTuple();
                    hv_textt[0] = "t";
                    hv_textt = hv_textt.TupleConcat(hv_A1Col - hv_Length);
                    hv_textt = hv_textt.TupleConcat(hv_OriginRow);
                }
                hv_textAng1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textAng1 = new HTuple();
                    hv_textAng1[0] = "Ang1";
                    hv_textAng1 = hv_textAng1.TupleConcat(hv_bu1Col - ((hv_Length * 2) * ((((((-hv_Ang1) / 2)).TupleRad()
                        )).TupleCos())));
                    hv_textAng1 = hv_textAng1.TupleConcat(hv_bu1Row + ((hv_Length * 2) * ((((((-hv_Ang1) / 2)).TupleRad()
                        )).TupleSin())));
                }
                hv_textAng2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textAng2 = new HTuple();
                    hv_textAng2[0] = "Ang2";
                    hv_textAng2 = hv_textAng2.TupleConcat(hv_bu2Col - ((hv_Length * 2) * (((((hv_Ang2 / 2)).TupleRad()
                        )).TupleCos())));
                    hv_textAng2 = hv_textAng2.TupleConcat(hv_bu2Row + ((hv_Length * 2) * (((((hv_Ang2 / 2)).TupleRad()
                        )).TupleSin())));
                }
                //建立全部文字
                hv_texts.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_texts = new HTuple();
                    hv_texts = hv_texts.TupleConcat(hv_textA1, hv_textA2, hv_textB1, hv_textB2, hv_textBC, hv_textC1, hv_textC2, hv_textR1, hv_textR2, hv_textt, hv_textAng1, hv_textAng2);
                }
                hv_text_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_text_idx = HTuple.TupleGenSequence(
                        0, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_textX_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textX_idx = HTuple.TupleGenSequence(
                        1, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_textY_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textY_idx = HTuple.TupleGenSequence(
                        2, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_TextsText.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsText = hv_texts.TupleSelect(
                        hv_text_idx);
                }
                hv_TextsX.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsX = hv_texts.TupleSelect(
                        hv_textX_idx);
                }
                hv_TextsY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsY = hv_texts.TupleSelect(
                        hv_textY_idx);
                }

                //===顯示開始====
                if ((int)(new HTuple(hv_show.TupleEqual(1))) != 0)
                {
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.ClearWindow(HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                    }
                    //====新版

                    ho_Surface1.Dispose();
                    gen_arrow_contour_xld(out ho_Surface1, hv_t1Row, 0, hv_t1Row, hv_Width, 0,
                        0);
                    ho_Surface2.Dispose();
                    gen_arrow_contour_xld(out ho_Surface2, hv_t2Row, 0, hv_t2Row, hv_Width, 0,
                        0);
                    ho_line.Dispose();
                    gen_arrow_contour_xld(out ho_line, hv_bu1Row, hv_bu1Col, hv_B1Row, hv_B1Col,
                        0, 0);
                    ho_line1.Dispose();
                    gen_arrow_contour_xld(out ho_line1, hv_bu2Row, hv_bu2Col, hv_B2Row, hv_B2Col,
                        0, 0);
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_line, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_line1, HDevWindowStack.GetActive());
                    }
                    ho_a1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_a1, hv_A1Row, hv_A1Col, 20, 0);
                    ho_c1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_c1, hv_C1Row, hv_C1Col, 20, 0);
                    ho_a2.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_a2, hv_A2Row, hv_A2Col, 20, 0);
                    ho_c2.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_c2, hv_C2Row, hv_C2Col, 20, 0);
                    ho_Orig.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_Orig, hv_WaferOriginRow, hv_WaferOriginCol,
                        20, 0);
                    ho_Arrow1.Dispose();
                    gen_arrow_contour_xld(out ho_Arrow1, 0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol,
                        0, 0);
                    ho_OrgLine.Dispose();
                    gen_arrow_contour_xld(out ho_OrgLine, hv_WaferOriginRow, 0, hv_WaferOriginRow,
                        hv_Width, 5, 5);
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_OrgLine, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Orig, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Arrow1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Surface1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Surface2, HDevWindowStack.GetActive());
                    }

                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Circle1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Circle2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "t= " + hv_t, "image",
                                hv_WaferOriginRow, 1080, "red", "box", "false");
                        }
                    }

                    hv_S4.Dispose();
                    HOperatorSet.CountSeconds(out hv_S4);
                    if (HDevWindowStack.IsOpen())
                    {
                        hv_WindowHandle = HDevWindowStack.GetActive();
                    }
                    //set_display_font(hv_WindowHandle, 16, "mono", "true", "false");
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetDraw(HDevWindowStack.GetActive(), "margin");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Rectangle, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "blue");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_a1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_c1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_a2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_c2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_b1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_b2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispText(HDevWindowStack.GetActive(), "a2", "image", hv_A2Row,
                            hv_A2Col, "blue", "box", "false");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "a1", "image", hv_A1Row - 25,
                                hv_A1Col, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "b1", "image", hv_B1Row - 25,
                                hv_B1Col - 25, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "b2", "image", hv_B2Row,
                                hv_B2Col - 25, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bv1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bv2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bu1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bu2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_cc1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_cc12, HDevWindowStack.GetActive());
                    }

                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_cc2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_cc22, HDevWindowStack.GetActive());
                    }

                    //這一行可以加到function外面顯示結果   ((可加圖片編號'No.'+[]
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), (((((((((((((((((((((((((("No." + new HTuple()) + "   Phi ") + hv_Phi_OrgX_OrgY)).TupleConcat(
                                "A1 =" + (hv_A1.TupleString(".2f"))))).TupleConcat("A2 =" + (hv_A2.TupleString(
                                ".2f"))))).TupleConcat("B1 =" + (hv_B1.TupleString(".2f"))))).TupleConcat(
                                "B2 =" + (hv_B2.TupleString(".2f"))))).TupleConcat("BC =" + (hv_BC.TupleString(
                                ".2f"))))).TupleConcat("C1 =" + hv_C1))).TupleConcat("C2 =" + hv_C2))).TupleConcat(
                                "R1 =" + hv_R1))).TupleConcat("R2 =" + hv_R2))).TupleConcat("t =" + hv_t))).TupleConcat(
                                "Ang1 =" + hv_Ang1))).TupleConcat("Ang2 =" + hv_Ang2), "window", 80, 50,
                                "black", new HTuple(), new HTuple());
                        }
                    }
                }
                //===顯示結束====
                //-------畫線----
                if (HDevWindowStack.IsOpen())
                {
                    //dev_clear_window ()
                }
                ho_DrawLines.Dispose();
                HOperatorSet.GenEmptyObj(out ho_DrawLines);
                for (hv_j = 0; (int)hv_j <= (int)((new HTuple(hv_LinesX2.TupleLength())) - 1); hv_j = (int)hv_j + 1)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Arrow.Dispose();
                        HOperatorSet.GenRegionLine(out ho_Arrow, hv_LinesY1.TupleSelect(hv_j), hv_LinesX1.TupleSelect(
                            hv_j), hv_LinesY2.TupleSelect(hv_j), hv_LinesX2.TupleSelect(hv_j));
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.ConcatObj(ho_DrawLines, ho_Arrow, out ExpTmpOutVar_0);
                        ho_DrawLines.Dispose();
                        ho_DrawLines = ExpTmpOutVar_0;
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        //dev_display (Arrow)
                    }
                }
                hv_CrossSize.Dispose();
                hv_CrossSize = 5;
                hv_CrossX.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CrossX = new HTuple();
                    hv_CrossX = hv_CrossX.TupleConcat(hv_A1Col, hv_C1Col, hv_A2Col, hv_C2Col);
                }
                hv_CrossY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CrossY = new HTuple();
                    hv_CrossY = hv_CrossY.TupleConcat(hv_A1Row, hv_C1Row, hv_A2Row, hv_C2Row);
                }
                for (hv_k = 0; (int)hv_k <= (int)((new HTuple(hv_CrossX.TupleLength())) - 1); hv_k = (int)hv_k + 1)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_CrossH.Dispose();
                        HOperatorSet.GenRegionLine(out ho_CrossH, hv_CrossY.TupleSelect(hv_k), (hv_CrossX.TupleSelect(
                            hv_k)) - hv_CrossSize, hv_CrossY.TupleSelect(hv_k), (hv_CrossX.TupleSelect(
                            hv_k)) + hv_CrossSize);
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_CrossV.Dispose();
                        HOperatorSet.GenRegionLine(out ho_CrossV, (hv_CrossY.TupleSelect(hv_k)) - hv_CrossSize,
                            hv_CrossX.TupleSelect(hv_k), (hv_CrossY.TupleSelect(hv_k)) + hv_CrossSize,
                            hv_CrossX.TupleSelect(hv_k));
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.ConcatObj(ho_DrawLines, ho_CrossH, out ExpTmpOutVar_0);
                        ho_DrawLines.Dispose();
                        ho_DrawLines = ExpTmpOutVar_0;
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.ConcatObj(ho_DrawLines, ho_CrossV, out ExpTmpOutVar_0);
                        ho_DrawLines.Dispose();
                        ho_DrawLines = ExpTmpOutVar_0;
                    }
                }
                ho_DrawCircles.Dispose();
                HOperatorSet.GenEmptyObj(out ho_DrawCircles);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_DrawCircles, ho_Circle2, out ExpTmpOutVar_0);
                    ho_DrawCircles.Dispose();
                    ho_DrawCircles = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_DrawCircles, ho_Circle1, out ExpTmpOutVar_0);
                    ho_DrawCircles.Dispose();
                    ho_DrawCircles = ExpTmpOutVar_0;
                }

                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.GenRegionContourXld(ho_DrawCircles, out ExpTmpOutVar_0, "filled");
                    ho_DrawCircles.Dispose();
                    ho_DrawCircles = ExpTmpOutVar_0;
                }
                //    TextsText, TextsX, TextsY
                for (hv_k = 0; (int)hv_k <= (int)((new HTuple(hv_TextsText.TupleLength())) - 1); hv_k = (int)hv_k + 1)
                {
                    if (HDevWindowStack.IsOpen())
                    {
                        //dev_disp_text (TextsText[k], 'image', TextsY[k], TextsX[k], 'black', [], [])
                    }
                }
                //=======

                //[255,0,0] Circle
                //[0,255,0]Line
                //paint_region (PinCircleReg, ResultImage, ResultImage, [200,200,200], 'margin')
                //paint_region (CircleReg, MultiChannelImage, MultiChannelImage, [255,0,0], 'margin')
                //paint_region (Region, ResultImage, ResultImage, [0,255,0], 'margin')
                ho_DupImage.Dispose();
                HOperatorSet.CopyImage(ho_ImageOut, out ho_DupImage);
                //R
                ho_R.Dispose();
                HOperatorSet.PaintRegion(ho_DrawCircles, ho_ImageOut, out ho_R, 255, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_DrawLines, ho_R, out ExpTmpOutVar_0, 0, "margin");
                    ho_R.Dispose();
                    ho_R = ExpTmpOutVar_0;
                }
                //G
                ho_G.Dispose();
                HOperatorSet.PaintRegion(ho_DrawCircles, ho_ImageOut, out ho_G, 0, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_DrawLines, ho_G, out ExpTmpOutVar_0, 255, "margin");
                    ho_G.Dispose();
                    ho_G = ExpTmpOutVar_0;
                }
                //B
                ho_B.Dispose();
                HOperatorSet.PaintRegion(ho_DrawCircles, ho_ImageOut, out ho_B, 0, "margin");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.PaintRegion(ho_DrawLines, ho_B, out ExpTmpOutVar_0, 0, "margin");
                    ho_B.Dispose();
                    ho_B = ExpTmpOutVar_0;
                }

                ho_ImageOut.Dispose();
                HOperatorSet.Compose3(ho_R, ho_G, ho_B, out ho_ImageOut);


                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_Position1Region.Dispose();
                ho_Position2Region.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Region.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Cross.Dispose();
                ho_bu1.Dispose();
                ho_RegionLines.Dispose();
                ho_a1.Dispose();
                ho_c1.Dispose();
                ho_a2.Dispose();
                ho_c2.Dispose();
                ho_Arrow2.Dispose();
                ho_bv1.Dispose();
                ho_Bu2.Dispose();
                ho_bu2.Dispose();
                ho_Bv2.Dispose();
                ho_bv2.Dispose();
                ho_b1.Dispose();
                ho_b2.Dispose();
                ho_MeasureLineBu1.Dispose();
                ho_MeasureLineBv1.Dispose();
                ho_MeasureLineBu2.Dispose();
                ho_MeasureLineBv2.Dispose();
                ho_t1.Dispose();
                ho_t2.Dispose();
                ho_cc1.Dispose();
                ho_cc12.Dispose();
                ho_cc13.Dispose();
                ho_Circle1.Dispose();
                ho_Arrow3.Dispose();
                ho_ChanferPnt.Dispose();
                ho_Circles.Dispose();
                ho_Cross1.Dispose();
                ho_cc2.Dispose();
                ho_cc22.Dispose();
                ho_cc23.Dispose();
                ho_Circle2.Dispose();
                ho_Surface1.Dispose();
                ho_Surface2.Dispose();
                ho_line.Dispose();
                ho_line1.Dispose();
                ho_Orig.Dispose();
                ho_Arrow1.Dispose();
                ho_OrgLine.Dispose();
                ho_DrawLines.Dispose();
                ho_Arrow.Dispose();
                ho_CrossH.Dispose();
                ho_CrossV.Dispose();
                ho_DrawCircles.Dispose();
                ho_DupImage.Dispose();
                ho_R.Dispose();
                ho_G.Dispose();
                ho_B.Dispose();

                hv_show.Dispose();
                hv_ExrPnt_Range.Dispose();
                hv_ExrPnt_Sigma.Dispose();
                hv_ExrPnt_Amp.Dispose();
                hv_ExrPnt_MeasureWidth.Dispose();
                hv_ExrPnt_MeasureGap.Dispose();
                hv_OnePnt_Amp.Dispose();
                hv_OnePnt_MeasureWidth.Dispose();
                hv_OnePnt_sigma.Dispose();
                hv_Width1.Dispose();
                hv_Height1.Dispose();
                hv_UsedThreshold.Dispose();
                hv_Area4.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices.Dispose();
                hv_IsAutoRotate.Dispose();
                hv_RectRow1.Dispose();
                hv_RectColumn1.Dispose();
                hv_RectRow2.Dispose();
                hv_RectColumn2.Dispose();
                hv_RectW.Dispose();
                hv_RectH.Dispose();
                hv_Area1.Dispose();
                hv_CenterLRow.Dispose();
                hv_CenterLCol.Dispose();
                hv_Area3.Dispose();
                hv_CenterRRow.Dispose();
                hv_CenterRCol.Dispose();
                hv_Phi.Dispose();
                hv_HomMat2DIdentity.Dispose();
                hv_rotateRow.Dispose();
                hv_rotateCol.Dispose();
                hv_HomMat2DRotate.Dispose();
                hv_rotateAng.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Indices3.Dispose();
                hv_WaferRow1.Dispose();
                hv_WaferCol1.Dispose();
                hv_WaferRow2.Dispose();
                hv_WaferRCol2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_OriginRow.Dispose();
                hv_OriginCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_WaferOriginRow.Dispose();
                hv_WaferOriginCol.Dispose();
                hv_RU_row.Dispose();
                hv_RU_col.Dispose();
                hv_A1AngOut.Dispose();
                hv_MinDistance1.Dispose();
                hv_A1Row_Cut.Dispose();
                hv_A1Col_Cut.Dispose();
                hv_A1Row.Dispose();
                hv_A1Col.Dispose();
                hv_C1AngOut.Dispose();
                hv_C1Row_Cut.Dispose();
                hv_C1Col_Cut.Dispose();
                hv_C1Row.Dispose();
                hv_C1Col.Dispose();
                hv_RD_Row.Dispose();
                hv_RD_Col.Dispose();
                hv_A2AngOut.Dispose();
                hv_A2Row_Cut.Dispose();
                hv_A2Col_Cut.Dispose();
                hv_A2Row.Dispose();
                hv_A2Col.Dispose();
                hv_C2AngOut.Dispose();
                hv_C2Row_Cut.Dispose();
                hv_C2Col_Cut.Dispose();
                hv_C2Row.Dispose();
                hv_C2Col.Dispose();
                hv_bu1Row2.Dispose();
                hv_bu1Col2.Dispose();
                hv_bu1Row1.Dispose();
                hv_bu1Col1.Dispose();
                hv_bu1Row.Dispose();
                hv_bu1Col.Dispose();
                hv_bv1Row2.Dispose();
                hv_bv1Col2.Dispose();
                hv_bv1Row1.Dispose();
                hv_bv1Col1.Dispose();
                hv_bv1Row.Dispose();
                hv_bv1Col.Dispose();
                hv_bu2Row2.Dispose();
                hv_bu2Col2.Dispose();
                hv_bu2Row1.Dispose();
                hv_bu2Col1.Dispose();
                hv_bu2Row.Dispose();
                hv_bu2Col.Dispose();
                hv_bv2Row1.Dispose();
                hv_bv2Col1.Dispose();
                hv_bv2Row2.Dispose();
                hv_bv2Col2.Dispose();
                hv_bv2Row.Dispose();
                hv_bv2Col.Dispose();
                hv_B1Row.Dispose();
                hv_B1Col.Dispose();
                hv_IsOverlapping.Dispose();
                hv_B2Row.Dispose();
                hv_B2Col.Dispose();
                hv_Angle1.Dispose();
                hv_Angle2.Dispose();
                hv_Ang12MeasureType.Dispose();
                hv_DistanceA_T.Dispose();
                hv_AB1Angle.Dispose();
                hv_Distance.Dispose();
                hv_Bu1Row1.Dispose();
                hv_Bu1Col1.Dispose();
                hv_Bu1Row2.Dispose();
                hv_Bu1Col2.Dispose();
                hv_Bv1Row1.Dispose();
                hv_Bv1Col1.Dispose();
                hv_Bv1Row2.Dispose();
                hv_Bv1Col2.Dispose();
                hv_AB2Angle.Dispose();
                hv_Bu2Row2.Dispose();
                hv_Bu2Col2.Dispose();
                hv_Bu2Row1.Dispose();
                hv_Bu2Col1.Dispose();
                hv_Bv2Row2.Dispose();
                hv_Bv2Col2.Dispose();
                hv_Bv2Row1.Dispose();
                hv_Bv2Col1.Dispose();
                hv_t1Row.Dispose();
                hv_t1Col.Dispose();
                hv_t2Row.Dispose();
                hv_t2Col.Dispose();
                hv_CC1AngOut.Dispose();
                hv_CC1Row_Cut.Dispose();
                hv_CC1Col_Cut.Dispose();
                hv_CC1Row.Dispose();
                hv_CC1Col.Dispose();
                hv_CC12AngOut.Dispose();
                hv_CC12Row_Cut.Dispose();
                hv_CC12Col_Cut.Dispose();
                hv_CC12Row.Dispose();
                hv_CC12Col.Dispose();
                hv_CC13AngOut.Dispose();
                hv_CC13Row_Cut.Dispose();
                hv_CC13Col_Cut.Dispose();
                hv_CC13Row.Dispose();
                hv_CC13Col.Dispose();
                hv_R_1CenterRow.Dispose();
                hv_R_1CenterCol.Dispose();
                hv_CircleR1.Dispose();
                hv_chamfer1_Rows.Dispose();
                hv_chamfer1_Cols.Dispose();
                hv_n.Dispose();
                hv_Y1.Dispose();
                hv_Y2.Dispose();
                hv_X1.Dispose();
                hv_X2.Dispose();
                hv_ChamferRow.Dispose();
                hv_ChamferCol.Dispose();
                hv_R1_Rows.Dispose();
                hv_R1_Cols.Dispose();
                hv_R1_Rs.Dispose();
                hv_i.Dispose();
                hv_Row_1.Dispose();
                hv_Col_1.Dispose();
                hv_j.Dispose();
                hv_Row_2.Dispose();
                hv_Col_2.Dispose();
                hv_k.Dispose();
                hv_Indices1.Dispose();
                hv_R_1.Dispose();
                hv_CC2AngOut.Dispose();
                hv_CC2Row_Cut.Dispose();
                hv_CC2Col_Cut.Dispose();
                hv_CC2Row.Dispose();
                hv_CC2Col.Dispose();
                hv_CC22AngOut.Dispose();
                hv_CC22Row_Cut.Dispose();
                hv_CC22Col_Cut.Dispose();
                hv_CC22Row.Dispose();
                hv_CC22Col.Dispose();
                hv_CC23AngOut.Dispose();
                hv_CC23Row_Cut.Dispose();
                hv_CC23Col_Cut.Dispose();
                hv_CC23Row.Dispose();
                hv_CC23Col.Dispose();
                hv_R_2CenterRow.Dispose();
                hv_R_2CenterCol.Dispose();
                hv_CircleR2.Dispose();
                hv_chamfer2_Rows.Dispose();
                hv_chamfer2_Cols.Dispose();
                hv_R2_Rows.Dispose();
                hv_R2_Cols.Dispose();
                hv_R2_Rs.Dispose();
                hv_Indices2.Dispose();
                hv_R_2.Dispose();
                hv_Length.Dispose();
                hv_Line_Org.Dispose();
                hv_Line_Surface1.Dispose();
                hv_Line_Surface2.Dispose();
                hv_Line_Ang1.Dispose();
                hv_Line_Ang2.Dispose();
                hv_Line_A1.Dispose();
                hv_Line_A2.Dispose();
                hv_Line_B1.Dispose();
                hv_Line_B2.Dispose();
                hv_Line_R1.Dispose();
                hv_Line_R2.Dispose();
                hv_Line_C1.Dispose();
                hv_Line_C2.Dispose();
                hv_Lines.Dispose();
                hv_Number.Dispose();
                hv_X1_idx.Dispose();
                hv_Y1_idx.Dispose();
                hv_X2_idx.Dispose();
                hv_Y2_idx.Dispose();
                hv_textA1.Dispose();
                hv_textA2.Dispose();
                hv_textB1.Dispose();
                hv_textB2.Dispose();
                hv_textBC.Dispose();
                hv_textC1.Dispose();
                hv_textC2.Dispose();
                hv_textR1.Dispose();
                hv_textR2.Dispose();
                hv_textt.Dispose();
                hv_textAng1.Dispose();
                hv_textAng2.Dispose();
                hv_texts.Dispose();
                hv_text_idx.Dispose();
                hv_textX_idx.Dispose();
                hv_textY_idx.Dispose();
                hv_S4.Dispose();
                hv_WindowHandle.Dispose();
                hv_CrossSize.Dispose();
                hv_CrossX.Dispose();
                hv_CrossY.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_Position1Region.Dispose();
                ho_Position2Region.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Region.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Cross.Dispose();
                ho_bu1.Dispose();
                ho_RegionLines.Dispose();
                ho_a1.Dispose();
                ho_c1.Dispose();
                ho_a2.Dispose();
                ho_c2.Dispose();
                ho_Arrow2.Dispose();
                ho_bv1.Dispose();
                ho_Bu2.Dispose();
                ho_bu2.Dispose();
                ho_Bv2.Dispose();
                ho_bv2.Dispose();
                ho_b1.Dispose();
                ho_b2.Dispose();
                ho_MeasureLineBu1.Dispose();
                ho_MeasureLineBv1.Dispose();
                ho_MeasureLineBu2.Dispose();
                ho_MeasureLineBv2.Dispose();
                ho_t1.Dispose();
                ho_t2.Dispose();
                ho_cc1.Dispose();
                ho_cc12.Dispose();
                ho_cc13.Dispose();
                ho_Circle1.Dispose();
                ho_Arrow3.Dispose();
                ho_ChanferPnt.Dispose();
                ho_Circles.Dispose();
                ho_Cross1.Dispose();
                ho_cc2.Dispose();
                ho_cc22.Dispose();
                ho_cc23.Dispose();
                ho_Circle2.Dispose();
                ho_Surface1.Dispose();
                ho_Surface2.Dispose();
                ho_line.Dispose();
                ho_line1.Dispose();
                ho_Orig.Dispose();
                ho_Arrow1.Dispose();
                ho_OrgLine.Dispose();
                ho_DrawLines.Dispose();
                ho_Arrow.Dispose();
                ho_CrossH.Dispose();
                ho_CrossV.Dispose();
                ho_DrawCircles.Dispose();
                ho_DupImage.Dispose();
                ho_R.Dispose();
                ho_G.Dispose();
                ho_B.Dispose();

                hv_show.Dispose();
                hv_ExrPnt_Range.Dispose();
                hv_ExrPnt_Sigma.Dispose();
                hv_ExrPnt_Amp.Dispose();
                hv_ExrPnt_MeasureWidth.Dispose();
                hv_ExrPnt_MeasureGap.Dispose();
                hv_OnePnt_Amp.Dispose();
                hv_OnePnt_MeasureWidth.Dispose();
                hv_OnePnt_sigma.Dispose();
                hv_Width1.Dispose();
                hv_Height1.Dispose();
                hv_UsedThreshold.Dispose();
                hv_Area4.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices.Dispose();
                hv_IsAutoRotate.Dispose();
                hv_RectRow1.Dispose();
                hv_RectColumn1.Dispose();
                hv_RectRow2.Dispose();
                hv_RectColumn2.Dispose();
                hv_RectW.Dispose();
                hv_RectH.Dispose();
                hv_Area1.Dispose();
                hv_CenterLRow.Dispose();
                hv_CenterLCol.Dispose();
                hv_Area3.Dispose();
                hv_CenterRRow.Dispose();
                hv_CenterRCol.Dispose();
                hv_Phi.Dispose();
                hv_HomMat2DIdentity.Dispose();
                hv_rotateRow.Dispose();
                hv_rotateCol.Dispose();
                hv_HomMat2DRotate.Dispose();
                hv_rotateAng.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Indices3.Dispose();
                hv_WaferRow1.Dispose();
                hv_WaferCol1.Dispose();
                hv_WaferRow2.Dispose();
                hv_WaferRCol2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_OriginRow.Dispose();
                hv_OriginCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_WaferOriginRow.Dispose();
                hv_WaferOriginCol.Dispose();
                hv_RU_row.Dispose();
                hv_RU_col.Dispose();
                hv_A1AngOut.Dispose();
                hv_MinDistance1.Dispose();
                hv_A1Row_Cut.Dispose();
                hv_A1Col_Cut.Dispose();
                hv_A1Row.Dispose();
                hv_A1Col.Dispose();
                hv_C1AngOut.Dispose();
                hv_C1Row_Cut.Dispose();
                hv_C1Col_Cut.Dispose();
                hv_C1Row.Dispose();
                hv_C1Col.Dispose();
                hv_RD_Row.Dispose();
                hv_RD_Col.Dispose();
                hv_A2AngOut.Dispose();
                hv_A2Row_Cut.Dispose();
                hv_A2Col_Cut.Dispose();
                hv_A2Row.Dispose();
                hv_A2Col.Dispose();
                hv_C2AngOut.Dispose();
                hv_C2Row_Cut.Dispose();
                hv_C2Col_Cut.Dispose();
                hv_C2Row.Dispose();
                hv_C2Col.Dispose();
                hv_bu1Row2.Dispose();
                hv_bu1Col2.Dispose();
                hv_bu1Row1.Dispose();
                hv_bu1Col1.Dispose();
                hv_bu1Row.Dispose();
                hv_bu1Col.Dispose();
                hv_bv1Row2.Dispose();
                hv_bv1Col2.Dispose();
                hv_bv1Row1.Dispose();
                hv_bv1Col1.Dispose();
                hv_bv1Row.Dispose();
                hv_bv1Col.Dispose();
                hv_bu2Row2.Dispose();
                hv_bu2Col2.Dispose();
                hv_bu2Row1.Dispose();
                hv_bu2Col1.Dispose();
                hv_bu2Row.Dispose();
                hv_bu2Col.Dispose();
                hv_bv2Row1.Dispose();
                hv_bv2Col1.Dispose();
                hv_bv2Row2.Dispose();
                hv_bv2Col2.Dispose();
                hv_bv2Row.Dispose();
                hv_bv2Col.Dispose();
                hv_B1Row.Dispose();
                hv_B1Col.Dispose();
                hv_IsOverlapping.Dispose();
                hv_B2Row.Dispose();
                hv_B2Col.Dispose();
                hv_Angle1.Dispose();
                hv_Angle2.Dispose();
                hv_Ang12MeasureType.Dispose();
                hv_DistanceA_T.Dispose();
                hv_AB1Angle.Dispose();
                hv_Distance.Dispose();
                hv_Bu1Row1.Dispose();
                hv_Bu1Col1.Dispose();
                hv_Bu1Row2.Dispose();
                hv_Bu1Col2.Dispose();
                hv_Bv1Row1.Dispose();
                hv_Bv1Col1.Dispose();
                hv_Bv1Row2.Dispose();
                hv_Bv1Col2.Dispose();
                hv_AB2Angle.Dispose();
                hv_Bu2Row2.Dispose();
                hv_Bu2Col2.Dispose();
                hv_Bu2Row1.Dispose();
                hv_Bu2Col1.Dispose();
                hv_Bv2Row2.Dispose();
                hv_Bv2Col2.Dispose();
                hv_Bv2Row1.Dispose();
                hv_Bv2Col1.Dispose();
                hv_t1Row.Dispose();
                hv_t1Col.Dispose();
                hv_t2Row.Dispose();
                hv_t2Col.Dispose();
                hv_CC1AngOut.Dispose();
                hv_CC1Row_Cut.Dispose();
                hv_CC1Col_Cut.Dispose();
                hv_CC1Row.Dispose();
                hv_CC1Col.Dispose();
                hv_CC12AngOut.Dispose();
                hv_CC12Row_Cut.Dispose();
                hv_CC12Col_Cut.Dispose();
                hv_CC12Row.Dispose();
                hv_CC12Col.Dispose();
                hv_CC13AngOut.Dispose();
                hv_CC13Row_Cut.Dispose();
                hv_CC13Col_Cut.Dispose();
                hv_CC13Row.Dispose();
                hv_CC13Col.Dispose();
                hv_R_1CenterRow.Dispose();
                hv_R_1CenterCol.Dispose();
                hv_CircleR1.Dispose();
                hv_chamfer1_Rows.Dispose();
                hv_chamfer1_Cols.Dispose();
                hv_n.Dispose();
                hv_Y1.Dispose();
                hv_Y2.Dispose();
                hv_X1.Dispose();
                hv_X2.Dispose();
                hv_ChamferRow.Dispose();
                hv_ChamferCol.Dispose();
                hv_R1_Rows.Dispose();
                hv_R1_Cols.Dispose();
                hv_R1_Rs.Dispose();
                hv_i.Dispose();
                hv_Row_1.Dispose();
                hv_Col_1.Dispose();
                hv_j.Dispose();
                hv_Row_2.Dispose();
                hv_Col_2.Dispose();
                hv_k.Dispose();
                hv_Indices1.Dispose();
                hv_R_1.Dispose();
                hv_CC2AngOut.Dispose();
                hv_CC2Row_Cut.Dispose();
                hv_CC2Col_Cut.Dispose();
                hv_CC2Row.Dispose();
                hv_CC2Col.Dispose();
                hv_CC22AngOut.Dispose();
                hv_CC22Row_Cut.Dispose();
                hv_CC22Col_Cut.Dispose();
                hv_CC22Row.Dispose();
                hv_CC22Col.Dispose();
                hv_CC23AngOut.Dispose();
                hv_CC23Row_Cut.Dispose();
                hv_CC23Col_Cut.Dispose();
                hv_CC23Row.Dispose();
                hv_CC23Col.Dispose();
                hv_R_2CenterRow.Dispose();
                hv_R_2CenterCol.Dispose();
                hv_CircleR2.Dispose();
                hv_chamfer2_Rows.Dispose();
                hv_chamfer2_Cols.Dispose();
                hv_R2_Rows.Dispose();
                hv_R2_Cols.Dispose();
                hv_R2_Rs.Dispose();
                hv_Indices2.Dispose();
                hv_R_2.Dispose();
                hv_Length.Dispose();
                hv_Line_Org.Dispose();
                hv_Line_Surface1.Dispose();
                hv_Line_Surface2.Dispose();
                hv_Line_Ang1.Dispose();
                hv_Line_Ang2.Dispose();
                hv_Line_A1.Dispose();
                hv_Line_A2.Dispose();
                hv_Line_B1.Dispose();
                hv_Line_B2.Dispose();
                hv_Line_R1.Dispose();
                hv_Line_R2.Dispose();
                hv_Line_C1.Dispose();
                hv_Line_C2.Dispose();
                hv_Lines.Dispose();
                hv_Number.Dispose();
                hv_X1_idx.Dispose();
                hv_Y1_idx.Dispose();
                hv_X2_idx.Dispose();
                hv_Y2_idx.Dispose();
                hv_textA1.Dispose();
                hv_textA2.Dispose();
                hv_textB1.Dispose();
                hv_textB2.Dispose();
                hv_textBC.Dispose();
                hv_textC1.Dispose();
                hv_textC2.Dispose();
                hv_textR1.Dispose();
                hv_textR2.Dispose();
                hv_textt.Dispose();
                hv_textAng1.Dispose();
                hv_textAng2.Dispose();
                hv_texts.Dispose();
                hv_text_idx.Dispose();
                hv_textX_idx.Dispose();
                hv_textY_idx.Dispose();
                hv_S4.Dispose();
                hv_WindowHandle.Dispose();
                hv_CrossSize.Dispose();
                hv_CrossX.Dispose();
                hv_CrossY.Dispose();

                throw HDevExpDefaultException;
            }
        }

        // Local procedures 
        // Short Description: 將輸入參數角度 轉換為實際內部演算角度 
        /// <summary>
        /// 
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)
        /// ------------------------
        /// 輸入參數座標
        /// 
        ///     ▼轉換如下▼
        /// 
        /// 內部實際演算角度
        /// ------------------------
        /// ↗+
        /// →  0度   
        /// ↘-
        /// range(-90~90)
        /// </summary>
        /// <param name = "hv_Angle">
        /// <para>輸入座標
        /// 向上為零度
        /// 
        /// 順時針為正
        /// 逆時針為負
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_AngleOut">
        /// <para>輸出座標,
        /// 向右為零度
        /// 
        /// 逆時針 為正
        /// 順時針 為負
        /// ↗+
        /// →  0度   
        /// ↘-
        /// range(-90~90)</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// </param>
        public static void AngleTrans(HTuple hv_Angle, out HTuple hv_AngleOut)
        {



            // Local iconic variables 
            // Initialize local and output iconic variables 
            hv_AngleOut = new HTuple();
            //20230213 v1.0 將座標轉換將輸入參數角度 轉換為實際內部演算角度
            hv_AngleOut.Dispose();
            hv_AngleOut = new HTuple();
            if ((int)((new HTuple(hv_Angle.TupleGreater(90))).TupleOr(new HTuple(hv_Angle.TupleLess(
                -90)))) != 0)
            {
                throw new HalconException("輸入角度範圍只能為-90~90度");


                return;
            }
            if ((int)(new HTuple(hv_Angle.TupleGreaterEqual(0))) != 0)
            {
                hv_AngleOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_AngleOut = -(hv_Angle - 90);
                }
            }
            else
            {
                hv_AngleOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_AngleOut = -(hv_Angle + 90);
                }
            }


            return;
        }//v1.0


        /// <summary>
        /// 量測1D邊緣
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ResultCross">
        /// <para>輸出座標點</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_Y1">
        /// <para>輸入量測線起始點Y1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X1">
        /// <para>輸入量測線起始點X1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Y2">
        /// <para>輸入量測線起始點Y2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X2">
        /// <para>輸入量測線起始點X2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Width">
        /// <para>輸入量測寬度</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Amp">
        /// <para>黑白震幅</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Sigma">
        /// <para>高斯平滑參數</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// <para>範圍: 1.000000 ＜= hv_Sigma ＜= 11.000000</para>
        /// </param>
        /// <param name = "hv_ResultY">
        /// <para>結果輸出座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ResultX">
        /// <para>結果輸出座標X</para>
        /// <para>型態: </para>
        /// </param>
        public static void MeasurePos(HObject ho_Image, out HObject ho_ResultCross, HTuple hv_Y1,
                        HTuple hv_X1, HTuple hv_Y2, HTuple hv_X2, HTuple hv_Width, HTuple hv_Amp, HTuple hv_Sigma,
                        out HTuple hv_ResultY, out HTuple hv_ResultX)
        {




            // Local iconic variables 

            HObject ho_Rectangle;

            // Local control variables 

            HTuple hv_TmpCtrl_Row = new HTuple(), hv_TmpCtrl_Column = new HTuple();
            HTuple hv_TmpCtrl_Dr = new HTuple(), hv_TmpCtrl_Dc = new HTuple();
            HTuple hv_TmpCtrl_Phi = new HTuple(), hv_TmpCtrl_Len1 = new HTuple();
            HTuple hv_TmpCtrl_Len2 = new HTuple(), hv_Height = new HTuple();
            HTuple hv_MsrHandle_Measure_02_0 = new HTuple(), hv_Amplitude_Measure_02_0 = new HTuple();
            HTuple hv_Distance_Measure_02_0 = new HTuple();
            HTuple hv_Width_COPY_INP_TMP = new HTuple(hv_Width);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ResultCross);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            hv_ResultY = new HTuple();
            hv_ResultX = new HTuple();
            try
            {
                //20230213 v1.0 量測1D邊緣  ///for面幅檢查
                //20230214 v1.2 新增參數:量測角度
                hv_TmpCtrl_Row.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Row = 0.5 * (hv_Y1 + hv_Y2);
                }
                hv_TmpCtrl_Column.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Column = 0.5 * (hv_X1 + hv_X2);
                }
                hv_TmpCtrl_Dr.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dr = hv_Y1 - hv_Y2;
                }
                hv_TmpCtrl_Dc.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dc = hv_X2 - hv_X1;
                }
                hv_TmpCtrl_Phi.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Phi = hv_TmpCtrl_Dr.TupleAtan2(
                        hv_TmpCtrl_Dc);
                }
                hv_TmpCtrl_Len1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Len1 = 0.5 * ((((hv_TmpCtrl_Dr * hv_TmpCtrl_Dr) + (hv_TmpCtrl_Dc * hv_TmpCtrl_Dc))).TupleSqrt()
                        );
                }
                hv_TmpCtrl_Len2.Dispose();
                hv_TmpCtrl_Len2 = new HTuple(hv_Width_COPY_INP_TMP);
                ho_ResultCross.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ResultCross);
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle2(out ho_Rectangle, hv_TmpCtrl_Row, hv_TmpCtrl_Column,
                    hv_TmpCtrl_Phi, hv_TmpCtrl_Len1, hv_TmpCtrl_Len2);
                hv_Width_COPY_INP_TMP.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width_COPY_INP_TMP, out hv_Height);
                hv_MsrHandle_Measure_02_0.Dispose();
                HOperatorSet.GenMeasureRectangle2(hv_TmpCtrl_Row, hv_TmpCtrl_Column, hv_TmpCtrl_Phi,
                    hv_TmpCtrl_Len1, hv_TmpCtrl_Len2, hv_Width_COPY_INP_TMP, hv_Height, "nearest_neighbor",
                    out hv_MsrHandle_Measure_02_0);
                hv_ResultY.Dispose(); hv_ResultX.Dispose(); hv_Amplitude_Measure_02_0.Dispose(); hv_Distance_Measure_02_0.Dispose();
                HOperatorSet.MeasurePos(ho_Image, hv_MsrHandle_Measure_02_0, hv_Sigma, hv_Amp,
                    "positive", "first", out hv_ResultY, out hv_ResultX, out hv_Amplitude_Measure_02_0,
                    out hv_Distance_Measure_02_0);
                ho_ResultCross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_ResultCross, hv_ResultY, hv_ResultX,
                    6, 0.785398);
                HOperatorSet.CloseMeasure(hv_MsrHandle_Measure_02_0);
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.2

        public static EdgeMeasureResultData StatisticsMeasureEdgeResult(List<EdgeMeasureResult> listResult)
        {
            EdgeMeasureResultData statisticResult = new EdgeMeasureResultData();
            List<double> arrHv_A1 = new List<double>();
            List<double> arrHv_A2 = new List<double>();
            List<double> arrHv_B1 = new List<double>();
            List<double> arrHv_B2 = new List<double>();
            List<double> arrHv_BC = new List<double>();
            List<double> arrHv_C1 = new List<double>();
            List<double> arrHv_C2 = new List<double>();
            List<double> arrHv_R1 = new List<double>();
            List<double> arrHv_R2 = new List<double>();
            List<double> arrHv_t = new List<double>();
            List<double> arrHv_Ang1 = new List<double>();
            List<double> arrHv_Ang2 = new List<double>();

            foreach (EdgeMeasureResult result in listResult)
            {
                //濾除measurement失敗
                if (result.ProcessStatus)
                {
                    arrHv_A1.Add(result.ResultData.A1);
                    arrHv_A2.Add(result.ResultData.A2);
                    arrHv_B1.Add(result.ResultData.B1);
                    arrHv_B2.Add(result.ResultData.B2);
                    arrHv_BC.Add(result.ResultData.BC);
                    arrHv_C1.Add(result.ResultData.C1);
                    arrHv_C2.Add(result.ResultData.C2);
                    arrHv_R1.Add(result.ResultData.R1);
                    arrHv_R2.Add(result.ResultData.R2);
                    arrHv_t.Add(result.ResultData.t);
                    arrHv_Ang1.Add(result.ResultData.Ang1);
                    arrHv_Ang2.Add(result.ResultData.Ang2);
                }
                else
                {
                    continue;
                }
            }

            statisticResult.A1 = CalculateSTD(arrHv_A1);
            statisticResult.A2 = CalculateSTD(arrHv_A2);
            statisticResult.B1 = CalculateSTD(arrHv_B1);
            statisticResult.B2 = CalculateSTD(arrHv_B2);
            statisticResult.BC = CalculateSTD(arrHv_BC);
            statisticResult.C1 = CalculateSTD(arrHv_C1);
            statisticResult.C2 = CalculateSTD(arrHv_C2);
            statisticResult.R1 = CalculateSTD(arrHv_R1);
            statisticResult.R2 = CalculateSTD(arrHv_R2);
            statisticResult.t = CalculateSTD(arrHv_t);
            statisticResult.Ang1 = CalculateSTD(arrHv_Ang1);
            statisticResult.Ang2 = CalculateSTD(arrHv_Ang2);

            return statisticResult;
        }

        private static double CalculateSTD(List<double> input)
        {
            double sTD = 9999;
            if (input.Count > 0)
            {
                double mean = input.Average();
                double sumOfSquare = input.Sum(data => Math.Pow(data - mean, 2));
                sTD = Math.Sqrt(sumOfSquare / (input.Count));
            }
            return sTD;
        }

        #endregion

        #region 裁小圖&缺陷檢查
        /// <summary>
        /// 計算邊緣for裁切小圖使用，計算需要量測的座標點，將圖片依照裁切尺寸均分在整個高度範圍   新增 將notch區域排除＆將notch裁圖
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_NotchImage">
        /// <para>輸出notch圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_NotchModel">
        /// <para>輸入notch的shape model</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CropNotchWidth">
        /// <para>Notch裁切圖片的寬度(曹口方向)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_InDistance">
        /// <para>往內檢查範圍</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>光學解析度 (um/Pixel)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CropSize">
        /// <para>檢查圖片裁切大小</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_MinScore">
        /// <para>Notch 找尋最低分數 預設值0.6</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntRows">
        /// <para>計算出的邊緣座標值(每張一個座標)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntCols">
        /// <para>計算出的邊緣座標值(每張一個座標)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ErrMsg">
        /// <para>型態: </para>
        /// </param>
        public static void CalculateEdgePntAndCropNotch(HObject ho_Image, out HObject ho_NotchImage,
            HTuple hv_NotchModel, HTuple hv_CropNotchWidth, HTuple hv_InDistance, HTuple hv_PixelSize,
            HTuple hv_CropSize, HTuple hv_MinScore, out HTuple hv_EdgePntRows, out HTuple hv_EdgePntCols,
            out HTuple hv_ErrMsg, out HTuple hv_notch_location)
        {

            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_ModelContours, ho_TransContours;
            HObject ho_Region1, ho_NotchRegion, ho_Rectangle, ho_ImageReduced1;
            HObject ho_Rectangle0 = null, ho_ImageReduced = null, ho_ImagePartUp = null;
            HObject ho_Rectangle1 = null, ho_ImagePartDown = null;

            // Local control variables 

            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Angle = new HTuple(), hv_Score = new HTuple();
            HTuple hv_notch_column = new HTuple(), hv_HomMat2D = new HTuple();
            HTuple hv_Offset = new HTuple(), hv_NotchRow1 = new HTuple();
            HTuple hv_NotchColumn1 = new HTuple(), hv_NotchRow2 = new HTuple();
            HTuple hv_NotchColumn2 = new HTuple(), hv_NotchCenterRow = new HTuple();
            HTuple hv_NotchCenterCol = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Height = new HTuple(), hv_EdgePntRowsUp = new HTuple();
            HTuple hv_EdgePntColsUp = new HTuple(), hv_EdgePntRowsDown = new HTuple();
            HTuple hv_EdgePntColsDown = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_NotchImage);
            HOperatorSet.GenEmptyObj(out ho_ModelContours);
            HOperatorSet.GenEmptyObj(out ho_TransContours);
            HOperatorSet.GenEmptyObj(out ho_Region1);
            HOperatorSet.GenEmptyObj(out ho_NotchRegion);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle0);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_ImagePartUp);
            HOperatorSet.GenEmptyObj(out ho_Rectangle1);
            HOperatorSet.GenEmptyObj(out ho_ImagePartDown);
            hv_EdgePntRows = new HTuple();
            hv_EdgePntCols = new HTuple();
            hv_ErrMsg = new HTuple();
            hv_notch_location = new HTuple();
            try
            {
                //20230417 v1.0 新曾notch裁切，裁小圖部分排除notch部分
                //20230523 v1.1 新增參數 find Notch最小分數，輸出參數:ErrMsg 提示Notch錯誤
                //20230524 v1.2 ErrorMsg輸出異常修正
                //20240313 v1.3 output 新增notch 位置供面幅挑圖使用
                hv_ErrMsg.Dispose();
                hv_ErrMsg = "";
                //--先找notch----

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Row.Dispose(); hv_Column.Dispose(); hv_Angle.Dispose(); hv_Score.Dispose();
                    HOperatorSet.FindShapeModel(ho_Image, hv_NotchModel, (new HTuple(0)).TupleRad()
                        , (new HTuple(360)).TupleRad(), 0.45, 1, 0.5, "least_squares", (new HTuple(6)).TupleConcat(
                        1), 0.7, out hv_Row, out hv_Column, out hv_Angle, out hv_Score);
                }

                if ((int)(new HTuple((new HTuple(hv_Score.TupleLength())).TupleEqual(0))) != 0)
                {
                    hv_ErrMsg.Dispose();
                    hv_ErrMsg = new HTuple("Notch分數低於MinScore,找不到");
                    ho_ModelContours.Dispose();
                    ho_TransContours.Dispose();
                    ho_Region1.Dispose();
                    ho_NotchRegion.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced1.Dispose();
                    ho_Rectangle0.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_ImagePartUp.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_ImagePartDown.Dispose();

                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Angle.Dispose();
                    hv_Score.Dispose();
                    hv_notch_column.Dispose();
                    hv_HomMat2D.Dispose();
                    hv_Offset.Dispose();
                    hv_NotchRow1.Dispose();
                    hv_NotchColumn1.Dispose();
                    hv_NotchRow2.Dispose();
                    hv_NotchColumn2.Dispose();
                    hv_NotchCenterRow.Dispose();
                    hv_NotchCenterCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_EdgePntRowsUp.Dispose();
                    hv_EdgePntColsUp.Dispose();
                    hv_EdgePntRowsDown.Dispose();
                    hv_EdgePntColsDown.Dispose();

                    return;
                }
                if ((int)(new HTuple(hv_Score.TupleLess(hv_MinScore))) != 0)
                {
                    hv_ErrMsg.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_ErrMsg = ((("Notch分數低於MinScore" + hv_MinScore) + "  /  ") + hv_Score) + "分";
                    }
                    ho_ModelContours.Dispose();
                    ho_TransContours.Dispose();
                    ho_Region1.Dispose();
                    ho_NotchRegion.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced1.Dispose();
                    ho_Rectangle0.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_ImagePartUp.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_ImagePartDown.Dispose();

                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Angle.Dispose();
                    hv_Score.Dispose();
                    hv_notch_column.Dispose();
                    hv_HomMat2D.Dispose();
                    hv_Offset.Dispose();
                    hv_NotchRow1.Dispose();
                    hv_NotchColumn1.Dispose();
                    hv_NotchRow2.Dispose();
                    hv_NotchColumn2.Dispose();
                    hv_NotchCenterRow.Dispose();
                    hv_NotchCenterCol.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_EdgePntRowsUp.Dispose();
                    hv_EdgePntColsUp.Dispose();
                    hv_EdgePntRowsDown.Dispose();
                    hv_EdgePntColsDown.Dispose();

                    return;
                }

                //--- 值抓取notch中心
                hv_notch_location.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_notch_location = hv_Row.TupleSelect(
                        0);
                }
                hv_notch_column.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_notch_column = hv_Column.TupleSelect(
                        0);
                }
                ho_ModelContours.Dispose();
                HOperatorSet.GetShapeModelContours(out ho_ModelContours, hv_NotchModel, 1);
                hv_HomMat2D.Dispose();
                HOperatorSet.HomMat2dIdentity(out hv_HomMat2D);
                {
                    HTuple ExpTmpOutVar_0;
                    HOperatorSet.HomMat2dRotate(hv_HomMat2D, 0, hv_notch_location, hv_notch_column,
                        out ExpTmpOutVar_0);
                    hv_HomMat2D.Dispose();
                    hv_HomMat2D = ExpTmpOutVar_0;
                }
                {
                    HTuple ExpTmpOutVar_0;
                    HOperatorSet.HomMat2dTranslate(hv_HomMat2D, hv_notch_location, hv_notch_column,
                        out ExpTmpOutVar_0);
                    hv_HomMat2D.Dispose();
                    hv_HomMat2D = ExpTmpOutVar_0;
                }
                ho_TransContours.Dispose();
                HOperatorSet.AffineTransContourXld(ho_ModelContours, out ho_TransContours,
                    hv_HomMat2D);
                ho_Region1.Dispose();
                HOperatorSet.GenRegionContourXld(ho_TransContours, out ho_Region1, "filled");
                ho_NotchRegion.Dispose();
                HOperatorSet.Union1(ho_Region1, out ho_NotchRegion);
                //-----
                hv_Offset.Dispose();
                hv_Offset = 20;
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.DilationRectangle1(ho_NotchRegion, out ExpTmpOutVar_0, hv_Offset * 2,
                        hv_Offset * 2);
                    ho_NotchRegion.Dispose();
                    ho_NotchRegion = ExpTmpOutVar_0;
                }
                hv_NotchRow1.Dispose(); hv_NotchColumn1.Dispose(); hv_NotchRow2.Dispose(); hv_NotchColumn2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_NotchRegion, out hv_NotchRow1, out hv_NotchColumn1,
                    out hv_NotchRow2, out hv_NotchColumn2);
                hv_NotchCenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_NotchCenterRow = (hv_NotchRow1 + hv_NotchRow2) / 2.0;
                }
                hv_NotchCenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_NotchCenterCol = (hv_NotchColumn1 + hv_NotchColumn2) / 2.0;
                }
                //--裁切notch影像

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangle.Dispose();
                    HOperatorSet.GenRectangle1(out ho_Rectangle, (hv_NotchCenterRow.TupleInt()) - (hv_CropNotchWidth / 2.0),
                        (hv_NotchCenterCol.TupleInt()) - (((hv_InDistance / hv_PixelSize) * 1000) * 1.5),
                        (hv_NotchCenterRow.TupleInt()) + (hv_CropNotchWidth / 2.0), (hv_NotchCenterCol.TupleInt()
                        ) + 250);
                }
                ho_ImageReduced1.Dispose();
                HOperatorSet.ReduceDomain(ho_Image, ho_Rectangle, out ho_ImageReduced1);
                ho_NotchImage.Dispose();
                HOperatorSet.CropDomain(ho_ImageReduced1, out ho_NotchImage);

                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                //-notch上面
                if ((int)(new HTuple(hv_NotchRow1.TupleGreaterEqual(hv_CropSize))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle0.Dispose();
                        HOperatorSet.GenRectangle1(out ho_Rectangle0, 0, 0, hv_NotchRow1, hv_Width - 1);
                    }
                    ho_ImageReduced.Dispose();
                    HOperatorSet.ReduceDomain(ho_Image, ho_Rectangle0, out ho_ImageReduced);
                    ho_ImagePartUp.Dispose();
                    HOperatorSet.CropDomain(ho_ImageReduced, out ho_ImagePartUp);
                    hv_ErrMsg.Dispose(); hv_EdgePntRowsUp.Dispose(); hv_EdgePntColsUp.Dispose();
                    CalculateEdgePntForCropSize(ho_ImagePartUp, hv_CropSize, out hv_ErrMsg, out hv_EdgePntRowsUp,
                        out hv_EdgePntColsUp);
                }
                else
                {
                    hv_EdgePntRowsUp.Dispose();
                    hv_EdgePntRowsUp = new HTuple();
                    hv_EdgePntColsUp.Dispose();
                    hv_EdgePntColsUp = new HTuple();
                }

                //-notch下面
                if ((int)(new HTuple((((hv_Height - 1) - hv_NotchRow2)).TupleGreaterEqual(hv_CropSize))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_Rectangle1.Dispose();
                        HOperatorSet.GenRectangle1(out ho_Rectangle1, hv_NotchRow2, 0, hv_Height - 1,
                            hv_Width - 1);
                    }
                    ho_ImageReduced.Dispose();
                    HOperatorSet.ReduceDomain(ho_Image, ho_Rectangle1, out ho_ImageReduced);
                    ho_ImagePartDown.Dispose();
                    HOperatorSet.CropDomain(ho_ImageReduced, out ho_ImagePartDown);
                    hv_ErrMsg.Dispose(); hv_EdgePntRowsDown.Dispose(); hv_EdgePntColsDown.Dispose();
                    CalculateEdgePntForCropSize(ho_ImagePartDown, hv_CropSize, out hv_ErrMsg,
                        out hv_EdgePntRowsDown, out hv_EdgePntColsDown);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_EdgePntRowsDown = hv_EdgePntRowsDown + hv_NotchRow2;
                            hv_EdgePntRowsDown.Dispose();
                            hv_EdgePntRowsDown = ExpTmpLocalVar_EdgePntRowsDown;
                        }
                    }
                }
                else
                {
                    hv_EdgePntRowsDown.Dispose();
                    hv_EdgePntRowsDown = new HTuple();
                    hv_EdgePntColsDown.Dispose();
                    hv_EdgePntColsDown = new HTuple();
                }


                //-座標
                hv_EdgePntRows.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EdgePntRows = new HTuple();
                    hv_EdgePntRows = hv_EdgePntRows.TupleConcat(hv_EdgePntRowsUp, hv_EdgePntRowsDown);
                }
                hv_EdgePntCols.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_EdgePntCols = new HTuple();
                    hv_EdgePntCols = hv_EdgePntCols.TupleConcat(hv_EdgePntColsUp, hv_EdgePntColsDown);
                }
                ho_ModelContours.Dispose();
                ho_TransContours.Dispose();
                ho_Region1.Dispose();
                ho_NotchRegion.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced1.Dispose();
                ho_Rectangle0.Dispose();
                ho_ImageReduced.Dispose();
                ho_ImagePartUp.Dispose();
                ho_Rectangle1.Dispose();
                ho_ImagePartDown.Dispose();

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Score.Dispose();
                hv_notch_column.Dispose();
                hv_HomMat2D.Dispose();
                hv_Offset.Dispose();
                hv_NotchRow1.Dispose();
                hv_NotchColumn1.Dispose();
                hv_NotchRow2.Dispose();
                hv_NotchColumn2.Dispose();
                hv_NotchCenterRow.Dispose();
                hv_NotchCenterCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_EdgePntRowsUp.Dispose();
                hv_EdgePntColsUp.Dispose();
                hv_EdgePntRowsDown.Dispose();
                hv_EdgePntColsDown.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_ModelContours.Dispose();
                ho_TransContours.Dispose();
                ho_Region1.Dispose();
                ho_NotchRegion.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced1.Dispose();
                ho_Rectangle0.Dispose();
                ho_ImageReduced.Dispose();
                ho_ImagePartUp.Dispose();
                ho_Rectangle1.Dispose();
                ho_ImagePartDown.Dispose();

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Score.Dispose();
                hv_notch_column.Dispose();
                hv_HomMat2D.Dispose();
                hv_Offset.Dispose();
                hv_NotchRow1.Dispose();
                hv_NotchColumn1.Dispose();
                hv_NotchRow2.Dispose();
                hv_NotchColumn2.Dispose();
                hv_NotchCenterRow.Dispose();
                hv_NotchCenterCol.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_EdgePntRowsUp.Dispose();
                hv_EdgePntColsUp.Dispose();
                hv_EdgePntRowsDown.Dispose();
                hv_EdgePntColsDown.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.3


        /// <summary>
        /// 計算邊緣for裁切小圖使用，計算需要量測的座標點，將圖片依照裁切尺寸均分在整個高度範圍
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_CropSize">
        /// <para>裁切尺寸(長寬相同) Pixel Size
        /// 
        /// 預設256</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ErrMsg">
        /// <para>錯誤訊息</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntRows">
        /// <para>計算出的邊緣座標值(每張一個座標)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntCols">
        /// <para>計算出的邊緣座標值(每張一個座標)</para>
        /// <para>型態: </para>
        /// </param>
        public static void CalculateEdgePntForCropSize(HObject ho_Image, HTuple hv_CropSize,
                out HTuple hv_ErrMsg, out HTuple hv_EdgePntRows, out HTuple hv_EdgePntCols)
        {




            // Local iconic variables 

            HObject ho_Rectangles, ho_f1 = null, ho_Cross = null;

            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_N = new HTuple(), hv_last = new HTuple(), hv_Col = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Gap = new HTuple(), hv_Rows = new HTuple();
            HTuple hv_Cols = new HTuple(), hv_Cols2 = new HTuple();
            HTuple hv_j = new HTuple();
            HTuple hv_CropSize_COPY_INP_TMP = new HTuple(hv_CropSize);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Rectangles);
            HOperatorSet.GenEmptyObj(out ho_f1);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            hv_ErrMsg = new HTuple();
            hv_EdgePntRows = new HTuple();
            hv_EdgePntCols = new HTuple();
            try
            {
                //20230324 v1.0 根據裁切的圖片中心進行單點位的量測 最後輸出每張圖的量測輪廓座標值
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_CropSize = hv_CropSize_COPY_INP_TMP - 1;
                        hv_CropSize_COPY_INP_TMP.Dispose();
                        hv_CropSize_COPY_INP_TMP = ExpTmpLocalVar_CropSize;
                    }
                }
                hv_N.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_N = (hv_Height - 1) / (hv_CropSize_COPY_INP_TMP.TupleInt()
                        );
                }
                hv_last.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_last = (hv_Height - 1) % (hv_CropSize_COPY_INP_TMP.TupleInt()
                        );
                }
                hv_Col.Dispose();
                hv_Col = new HTuple();
                hv_Row.Dispose();
                hv_Row = new HTuple();
                if ((int)(new HTuple(hv_last.TupleNotEqual(0))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_N = hv_N + 1;
                            hv_N.Dispose();
                            hv_N = ExpTmpLocalVar_N;
                        }
                    }
                }
                hv_Gap.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Gap = ((hv_Height - hv_CropSize_COPY_INP_TMP) - 1) / (hv_N - 1.0);
                }

                hv_Rows.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Rows = HTuple.TupleGenSequence(
                        hv_CropSize_COPY_INP_TMP / 2.0, hv_Height - (hv_CropSize_COPY_INP_TMP / 2.0), hv_Gap);
                }
                hv_Cols.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Cols = (hv_Rows * 0) + (hv_Width / 2.0);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangles.Dispose();
                    HOperatorSet.GenRectangle2(out ho_Rectangles, hv_Rows, hv_Cols, hv_Cols * 0,
                        (hv_Cols * 0) + (hv_Width / 2.0), (hv_Cols * 0) + (hv_CropSize_COPY_INP_TMP / 2.0));
                }
                hv_Cols2.Dispose();
                hv_Cols2 = new HTuple();
                for (hv_j = 0; (int)hv_j <= (int)((new HTuple(hv_Rows.TupleLength())) - 1); hv_j = (int)hv_j + 1)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_f1.Dispose(); hv_Row.Dispose(); hv_Col.Dispose();
                        MeasurePosNegative(ho_Image, out ho_f1, hv_Rows.TupleSelect(hv_j), (hv_Cols.TupleSelect(
                            hv_j)) + (hv_Width / 2), hv_Rows.TupleSelect(hv_j), (hv_Cols.TupleSelect(
                            hv_j)) - (hv_Width / 2), 1, 30, 1, out hv_Row, out hv_Col);
                    }
                    if ((int)(new HTuple(hv_Col.TupleEqual(new HTuple()))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_f1.Dispose(); hv_Row.Dispose(); hv_Col.Dispose();
                            MeasurePosNegative(ho_Image, out ho_f1, hv_Rows.TupleSelect(hv_j), (hv_Cols.TupleSelect(
                                hv_j)) + (hv_Width / 2), hv_Rows.TupleSelect(hv_j), (hv_Cols.TupleSelect(
                                hv_j)) - (hv_Width / 2), 1, 10, 1, out hv_Row, out hv_Col);
                        }
                        if ((int)((new HTuple(hv_Col.TupleEqual(new HTuple()))).TupleAnd(new HTuple(hv_Cols2.TupleEqual(
                            new HTuple())))) != 0)
                        {
                            throw new HalconException("邊緣抓取失敗");
                            hv_ErrMsg.Dispose();
                            hv_ErrMsg = "錯誤!";
                            ho_Rectangles.Dispose();
                            ho_f1.Dispose();
                            ho_Cross.Dispose();

                            hv_CropSize_COPY_INP_TMP.Dispose();
                            hv_Width.Dispose();
                            hv_Height.Dispose();
                            hv_N.Dispose();
                            hv_last.Dispose();
                            hv_Col.Dispose();
                            hv_Row.Dispose();
                            hv_Gap.Dispose();
                            hv_Rows.Dispose();
                            hv_Cols.Dispose();
                            hv_Cols2.Dispose();
                            hv_j.Dispose();

                            return;
                        }
                        else if ((int)(new HTuple(hv_Col.TupleEqual(new HTuple()))) != 0)
                        {
                            hv_Col.Dispose();
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                hv_Col = hv_Cols2.TupleSelect(
                                    (new HTuple(hv_Cols2.TupleLength())) - 1);
                            }
                        }
                    }
                    ho_Cross.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_Cross, hv_Row, hv_Col, 6, 0);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Cols2 = hv_Cols2.TupleConcat(
                                hv_Col);
                            hv_Cols2.Dispose();
                            hv_Cols2 = ExpTmpLocalVar_Cols2;
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        //dev_display (Cross)
                    }
                }

                //邊緣點位
                hv_EdgePntRows.Dispose();
                hv_EdgePntRows = new HTuple(hv_Rows);
                hv_EdgePntCols.Dispose();
                hv_EdgePntCols = new HTuple(hv_Cols2);
                ho_Rectangles.Dispose();
                ho_f1.Dispose();
                ho_Cross.Dispose();

                hv_CropSize_COPY_INP_TMP.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_N.Dispose();
                hv_last.Dispose();
                hv_Col.Dispose();
                hv_Row.Dispose();
                hv_Gap.Dispose();
                hv_Rows.Dispose();
                hv_Cols.Dispose();
                hv_Cols2.Dispose();
                hv_j.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangles.Dispose();
                ho_f1.Dispose();
                ho_Cross.Dispose();

                hv_CropSize_COPY_INP_TMP.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_N.Dispose();
                hv_last.Dispose();
                hv_Col.Dispose();
                hv_Row.Dispose();
                hv_Gap.Dispose();
                hv_Rows.Dispose();
                hv_Cols.Dispose();
                hv_Cols2.Dispose();
                hv_j.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.0



        /// <summary>
        /// 單張裁切尺寸
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_CropImage">
        /// <para>輸出裁切影像</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_CropImage_AI">
        /// <para>輸出AI影像((面外塗白))</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>光學解析(um/Pixel) </para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CropSize">
        /// <para>單張裁切尺吋  預設256</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_InDistance">
        /// <para>從wafer內縮的距離(mm)   預設1.5</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntRow">
        /// <para>輸入邊緣座標值</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_EdgePntCol">
        /// <para>輸入邊緣座標值</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AI_OutDrawStartX">
        /// <para>AI要著色的起始點(X座標值)</para>
        /// <para>型態: </para>
        /// </param>
        public static void CropDomainImage(HObject ho_Image, out HObject ho_CropImage, out HObject ho_CropImage_AI,
            HTuple hv_PixelSize, HTuple hv_CropSize, HTuple hv_InDistance, HTuple hv_EdgePntRow,
            HTuple hv_EdgePntCol, HTuple hv_AI_OutDrawStartX)
        {




            // Local iconic variables 

            HObject ho_Rectangle, ho_ImageReduced1, ho_ROI_0;
            HTuple hv_CropSize_COPY_INP_TMP = new HTuple(hv_CropSize);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_CropImage);
            HOperatorSet.GenEmptyObj(out ho_CropImage_AI);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced1);
            HOperatorSet.GenEmptyObj(out ho_ROI_0);
            try
            {
                //20230324 v1.0 單張裁切圖片
                //20230417 v1.1 新增輸出AI圖((面外塗白))
                //PixelSize
                //InDistance  從wafer邊緣內縮的距離
                //EdgePntRow 邊緣座標
                //EdgePntCol 邊緣座標
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_CropSize = hv_CropSize_COPY_INP_TMP - 1;
                        hv_CropSize_COPY_INP_TMP.Dispose();
                        hv_CropSize_COPY_INP_TMP = ExpTmpLocalVar_CropSize;
                    }
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangle.Dispose();
                    HOperatorSet.GenRectangle1(out ho_Rectangle, hv_EdgePntRow - (hv_CropSize_COPY_INP_TMP / 2.0),
                        hv_EdgePntCol - ((hv_InDistance * 1000) / (hv_PixelSize.TupleInt())), hv_EdgePntRow + (hv_CropSize_COPY_INP_TMP / 2.0),
                        (hv_EdgePntCol - ((hv_InDistance * 1000) / (hv_PixelSize.TupleInt()))) + hv_CropSize_COPY_INP_TMP);
                }
                ho_ImageReduced1.Dispose();
                HOperatorSet.ReduceDomain(ho_Image, ho_Rectangle, out ho_ImageReduced1);
                ho_CropImage.Dispose();
                HOperatorSet.CropDomain(ho_ImageReduced1, out ho_CropImage);

                ho_ROI_0.Dispose();
                HOperatorSet.GenRectangle1(out ho_ROI_0, 0, hv_AI_OutDrawStartX, hv_CropSize_COPY_INP_TMP,
                    hv_CropSize_COPY_INP_TMP);
                ho_CropImage_AI.Dispose();
                HOperatorSet.PaintRegion(ho_ROI_0, ho_CropImage, out ho_CropImage_AI, 255,
                    "fill");

                ho_Rectangle.Dispose();
                ho_ImageReduced1.Dispose();
                ho_ROI_0.Dispose();

                hv_CropSize_COPY_INP_TMP.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangle.Dispose();
                ho_ImageReduced1.Dispose();
                ho_ROI_0.Dispose();

                hv_CropSize_COPY_INP_TMP.Dispose();

                throw HDevExpDefaultException;
            }
        } //v1.1

        /// <summary>
        /// 連續五張影像中 (有兩個notch),找尋最靠近中間的notch，並輸出notch Y座標  
        /// 
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片( 超過一圈 含有兩個notch的影像)</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "hv_NotchModel">
        /// <para>Notch 的 shape Model</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_MinScore">
        /// <para>Find Notch最小分數 (預設值0.6)
        /// (數值範圍 0.01~0.99)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_CenterModelY">
        /// <para>輸出最靠影像中心的nnotch座標Y值</para>
        /// <para>型態: </para>
        /// <para>語義: point.y</para>
        /// </param>
        /// <param name = "hv_Score">
        /// <para>輸出找尋到的notch分數</para>
        /// <para>型態: </para>
        /// </param>
        public static void FindCenterNotch(HObject ho_Image, HTuple hv_NotchModel, HTuple hv_MinScore,
            out HTuple hv_CenterModelY, out HTuple hv_Score)
        {




            // Local iconic variables 

            // Local control variables 

            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Angle = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Height = new HTuple(), hv_CenterRow = new HTuple();
            HTuple hv_CenterCol = new HTuple(), hv_Distance = new HTuple();
            HTuple hv_Indices = new HTuple();
            // Initialize local and output iconic variables 
            hv_CenterModelY = new HTuple();
            hv_Score = new HTuple();
            try
            {
                //2023/04/18 v1.0 連續五張影像中 (有兩個notch),找尋最靠近中間的notch，並輸出notch Y座標
                //2023/04/27 v1.1 找不到notch時 回傳CenterModelY=-1， model分數降為0.7
                //2023/05/23 v1.2 開放參數 Model最小分數設定 輸出參數 Score
                hv_Row.Dispose();
                hv_Row = new HTuple();
                hv_Column.Dispose();
                hv_Column = new HTuple();
                hv_CenterModelY.Dispose();
                hv_CenterModelY = new HTuple();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Row.Dispose(); hv_Column.Dispose(); hv_Angle.Dispose(); hv_Score.Dispose();
                    HOperatorSet.FindShapeModel(ho_Image, hv_NotchModel, (new HTuple(0)).TupleRad()
                        , (new HTuple(360)).TupleRad(), hv_MinScore, 2, 0.5, "least_squares", (new HTuple(6)).TupleConcat(
                        1), 0.7, out hv_Row, out hv_Column, out hv_Angle, out hv_Score);
                }
                if ((int)(new HTuple((new HTuple(hv_Row.TupleLength())).TupleEqual(0))) != 0)
                {
                    hv_CenterModelY.Dispose();
                    hv_CenterModelY = -1;

                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Angle.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_CenterRow.Dispose();
                    hv_CenterCol.Dispose();
                    hv_Distance.Dispose();
                    hv_Indices.Dispose();

                    return;
                }
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                hv_CenterRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterRow = (hv_Height - 1) / 2;
                }
                hv_CenterCol.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterCol = (hv_Width - 1) / 2;
                }
                hv_Distance.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Distance = ((hv_Row - hv_CenterRow)).TupleAbs()
                        ;
                }
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Distance, out hv_Indices);
                hv_CenterModelY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_CenterModelY = hv_Row.TupleSelect(
                        hv_Indices.TupleSelect(0));
                }

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_CenterRow.Dispose();
                hv_CenterCol.Dispose();
                hv_Distance.Dispose();
                hv_Indices.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Angle.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_CenterRow.Dispose();
                hv_CenterCol.Dispose();
                hv_Distance.Dispose();
                hv_Indices.Dispose();

                throw HDevExpDefaultException;
            }
        }  //v1.2
        #endregion

        #region 缺陷檢測第一版
        /// <summary>
        /// 檢查是否有缺陷
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_OutDefectAll">
        /// <para>輸出缺陷Region</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_ResultImage">
        /// <para>輸出結果圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_RoiWidthToBevelCenter">
        /// <para>Roi寬度(最左至斜切面中心點距離) 單位:Pixel  預設:90</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_BevelWidth">
        /// <para>斜切面寬度 單位pixel 預設:27</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DisplayDilation">
        /// <para>顯示使用 框選defect 預設:5</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_InnerThresholdMax">
        /// <para>面內區域最大灰接值(輸入-1為自動)  預設:230</para>
        /// <para>型態: int</para>
        /// </param>
        /// <param name = "hv_InnerDefectAreaSize">
        /// <para>面內缺陷尺寸卡控(面積) pixel^2  預設值7</para>
        /// <para>型態: int</para>
        /// <para>建議值: 7</para>
        /// </param>
        /// <param name = "hv_InnerDefectMaxGray">
        /// <para>面內缺陷的最大灰階值</para>
        /// <para>型態: int</para>
        /// <para>預設值: 150</para>
        /// </param>
        /// <param name = "hv_DefectNumber">
        /// <para>輸出抓到的缺陷總數量  </para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectRow1">
        /// <para>缺陷的左上座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectCol1">
        /// <para>缺陷的左上座標X</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectRow2">
        /// <para>缺陷的右下座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectCol2">
        /// <para>缺陷的右下座標X</para>
        /// <para>型態: </para>
        /// </param>
        public static void InspectWaferEdgeDefect(HObject ho_Image, out HObject ho_OutDefectAll,
            out HObject ho_ResultImage, HTuple hv_RoiWidthToBevelCenter, HTuple hv_BevelWidth,
            HTuple hv_DisplayDilation, HTuple hv_InnerThresholdMax, HTuple hv_InnerDefectAreaSize,
            HTuple hv_InnerDefectMaxGray, HTuple hv_EdgeDefectAreaSize, HTuple hv_PaintResult,
            HTuple hv_OnlyDetectEdge, out HTuple hv_DefectNumber, out HTuple hv_DefectRow1,
            out HTuple hv_DefectCol1, out HTuple hv_DefectRow2, out HTuple hv_DefectCol2,
            out HTuple hv_Area)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_DefectAll, ho_ConnectedRegions3;
            HObject ho_ImageMedian, ho_ImageScaled, ho_Rectangle, ho_ImageReduced;
            HObject ho_Lines1, ho_SortedContours, ho_ObjectSelected1;
            HObject ho_ObjectSelected2, ho_RectangleBevel, ho_ImageReduced_inner;
            HObject ho_RectangleBypass, ho_ImageReduced_bypass, ho_innerRegionReal = null;
            HObject ho_BevelDefect, ho_AllInnerRoi = null, ho_ImageZoom = null;
            HObject ho_ResizeImg = null, ho_ImageReduced3 = null, ho_innerDefectResult = null;
            HObject ho_ConnectedinnerDefectResult = null, ho_selectRegion = null;
            HObject ho_selectDefect = null, ho_ConnectedDefectAll, ho_ConnectedDefectAllOpen;
            HObject ho_ConnectedDefectAllOpenClose, ho_selectDefectAll;
            HObject ho_ImageResult = null, ho_ImageResult1 = null;

            // Local control variables 

            HTuple hv_ErrorOut = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Height = new HTuple(), hv_Number = new HTuple();
            HTuple hv_row = new HTuple(), hv_col1 = new HTuple(), hv_waferEdge = new HTuple();
            HTuple hv_waferEdgeMin = new HTuple(), hv_waferEdgeMax = new HTuple();
            HTuple hv_col2 = new HTuple(), hv_secondEdge = new HTuple();
            HTuple hv_secondEdgeMin = new HTuple(), hv_secondEdgeMax = new HTuple();
            HTuple hv_innerEdge = new HTuple(), hv_UsedThreshold1 = new HTuple();
            HTuple hv_Row11 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Row21 = new HTuple(), hv_realRightCol = new HTuple();
            HTuple hv_Area1 = new HTuple(), hv_Row3 = new HTuple();
            HTuple hv_Column3 = new HTuple(), hv_ResizeScale = new HTuple();
            HTuple hv_Index = new HTuple(), hv_DistanceMin = new HTuple();
            HTuple hv_DistanceMax = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_OutDefectAll);
            HOperatorSet.GenEmptyObj(out ho_ResultImage);
            HOperatorSet.GenEmptyObj(out ho_DefectAll);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions3);
            HOperatorSet.GenEmptyObj(out ho_ImageMedian);
            HOperatorSet.GenEmptyObj(out ho_ImageScaled);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_Lines1);
            HOperatorSet.GenEmptyObj(out ho_SortedContours);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected1);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected2);
            HOperatorSet.GenEmptyObj(out ho_RectangleBevel);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced_inner);
            HOperatorSet.GenEmptyObj(out ho_RectangleBypass);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced_bypass);
            HOperatorSet.GenEmptyObj(out ho_innerRegionReal);
            HOperatorSet.GenEmptyObj(out ho_BevelDefect);
            HOperatorSet.GenEmptyObj(out ho_AllInnerRoi);
            HOperatorSet.GenEmptyObj(out ho_ImageZoom);
            HOperatorSet.GenEmptyObj(out ho_ResizeImg);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced3);
            HOperatorSet.GenEmptyObj(out ho_innerDefectResult);
            HOperatorSet.GenEmptyObj(out ho_ConnectedinnerDefectResult);
            HOperatorSet.GenEmptyObj(out ho_selectRegion);
            HOperatorSet.GenEmptyObj(out ho_selectDefect);
            HOperatorSet.GenEmptyObj(out ho_ConnectedDefectAll);
            HOperatorSet.GenEmptyObj(out ho_ConnectedDefectAllOpen);
            HOperatorSet.GenEmptyObj(out ho_ConnectedDefectAllOpenClose);
            HOperatorSet.GenEmptyObj(out ho_selectDefectAll);
            HOperatorSet.GenEmptyObj(out ho_ImageResult);
            HOperatorSet.GenEmptyObj(out ho_ImageResult1);
            hv_DefectNumber = new HTuple();
            hv_DefectRow1 = new HTuple();
            hv_DefectCol1 = new HTuple();
            hv_DefectRow2 = new HTuple();
            hv_DefectCol2 = new HTuple();
            hv_Area = new HTuple();
            try
            {
                //20230324 v1.0 動態二值化計算邊緣(影像大小251)
                //20230424 v1.1 新增面內瑕疵檢，抓取較黑較大的缺陷!  新增面內缺陷檢查 新增兩個參數InnerDefectAreaSize, InnerDefectMaxGray ，若輸入0 或 -1則不進行面內檢測
                //20230426 v1.2 輸出圖片初始化
                //20240320 v1.3 新增濾除邊緣overkill
                //20240412 v1.4 新增輸出area
                //20240417 v1.7 新增畫defect區域開關/只檢連邊機制

                ho_ResultImage.Dispose();
                ho_ResultImage = new HObject(ho_Image);
                hv_ErrorOut.Dispose();
                hv_ErrorOut = new HTuple();
                //gen_empty_obj (DefectAll)
                ho_DefectAll.Dispose();
                HOperatorSet.GenEmptyObj(out ho_DefectAll);
                ho_ConnectedRegions3.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ConnectedRegions3);
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_ImageMedian.Dispose();
                    HOperatorSet.MedianRect(ho_Image, out ho_ImageMedian, 1, hv_Height - 5);
                }
                //找黑色邊緣線有三條
                ho_ImageScaled.Dispose();
                HOperatorSet.ScaleImage(ho_ImageMedian, out ho_ImageScaled, 1, 0);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangle.Dispose();
                    HOperatorSet.GenRectangle1(out ho_Rectangle, 0, ((hv_Width - 1) - hv_RoiWidthToBevelCenter) - 50,
                        hv_Height - 1, hv_Width - 1);
                }
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_ImageScaled, ho_Rectangle, out ho_ImageReduced
                    );
                ho_Lines1.Dispose();
                HOperatorSet.LinesFacet(ho_ImageReduced, out ho_Lines1, 5, 3, 8, "dark");
                //按X軸排序
                ho_SortedContours.Dispose();
                HOperatorSet.SortContoursXld(ho_Lines1, out ho_SortedContours, "upper_left",
                    "true", "column");
                //select_obj (SortedContours, ObjectSelected1, 1)
                //get_contour_attrib_xld (SortedContours, 'angle', Attrib)
                //select_contours_xld (Lines1, SelectedContours, 'contour_length', 10, 99999, -0.5, 0.5)
                hv_Number.Dispose();
                HOperatorSet.CountObj(ho_SortedContours, out hv_Number);

                if ((int)(new HTuple(hv_Number.TupleLess(2))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorOut = hv_ErrorOut.TupleConcat(
                                "找不到邊緣!");
                            hv_ErrorOut.Dispose();
                            hv_ErrorOut = ExpTmpLocalVar_ErrorOut;
                        }
                    }
                    ho_DefectAll.Dispose();
                    ho_ConnectedRegions3.Dispose();
                    ho_ImageMedian.Dispose();
                    ho_ImageScaled.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Lines1.Dispose();
                    ho_SortedContours.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_ObjectSelected2.Dispose();
                    ho_RectangleBevel.Dispose();
                    ho_ImageReduced_inner.Dispose();
                    ho_RectangleBypass.Dispose();
                    ho_ImageReduced_bypass.Dispose();
                    ho_innerRegionReal.Dispose();
                    ho_BevelDefect.Dispose();
                    ho_AllInnerRoi.Dispose();
                    ho_ImageZoom.Dispose();
                    ho_ResizeImg.Dispose();
                    ho_ImageReduced3.Dispose();
                    ho_innerDefectResult.Dispose();
                    ho_ConnectedinnerDefectResult.Dispose();
                    ho_selectRegion.Dispose();
                    ho_selectDefect.Dispose();
                    ho_ConnectedDefectAll.Dispose();
                    ho_ConnectedDefectAllOpen.Dispose();
                    ho_ConnectedDefectAllOpenClose.Dispose();
                    ho_selectDefectAll.Dispose();
                    ho_ImageResult.Dispose();
                    ho_ImageResult1.Dispose();

                    hv_ErrorOut.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_Number.Dispose();
                    hv_row.Dispose();
                    hv_col1.Dispose();
                    hv_waferEdge.Dispose();
                    hv_waferEdgeMin.Dispose();
                    hv_waferEdgeMax.Dispose();
                    hv_col2.Dispose();
                    hv_secondEdge.Dispose();
                    hv_secondEdgeMin.Dispose();
                    hv_secondEdgeMax.Dispose();
                    hv_innerEdge.Dispose();
                    hv_UsedThreshold1.Dispose();
                    hv_Row11.Dispose();
                    hv_Column1.Dispose();
                    hv_Row21.Dispose();
                    hv_realRightCol.Dispose();
                    hv_Area1.Dispose();
                    hv_Row3.Dispose();
                    hv_Column3.Dispose();
                    hv_ResizeScale.Dispose();
                    hv_Index.Dispose();
                    hv_DistanceMin.Dispose();
                    hv_DistanceMax.Dispose();

                    return;
                }

                //取最右邊的為wafer邊緣
                ho_ObjectSelected1.Dispose();
                HOperatorSet.SelectObj(ho_SortedContours, out ho_ObjectSelected1, hv_Number);
                //计算xld的面积以及中心位置
                hv_row.Dispose(); hv_col1.Dispose();
                HOperatorSet.GetContourXld(ho_ObjectSelected1, out hv_row, out hv_col1);
                hv_waferEdge.Dispose();
                HOperatorSet.TupleMean(hv_col1, out hv_waferEdge);
                hv_waferEdgeMin.Dispose();
                HOperatorSet.TupleMin(hv_col1, out hv_waferEdgeMin);
                hv_waferEdgeMax.Dispose();
                HOperatorSet.TupleMax(hv_col1, out hv_waferEdgeMax);
                //取右邊第二條的為研磨邊緣
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_ObjectSelected2.Dispose();
                    HOperatorSet.SelectObj(ho_SortedContours, out ho_ObjectSelected2, hv_Number - 1);
                }
                //计算xld的面积以及中心位置
                hv_row.Dispose(); hv_col2.Dispose();
                HOperatorSet.GetContourXld(ho_ObjectSelected2, out hv_row, out hv_col2);
                hv_secondEdge.Dispose();
                HOperatorSet.TupleMean(hv_col2, out hv_secondEdge);
                hv_secondEdgeMin.Dispose();
                HOperatorSet.TupleMin(hv_col2, out hv_secondEdgeMin);
                hv_secondEdgeMax.Dispose();
                HOperatorSet.TupleMax(hv_col2, out hv_secondEdgeMax);

                //取第三條inner邊緣
                hv_innerEdge.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_innerEdge = hv_waferEdge - hv_BevelWidth;
                }

                //抓取斜切面(內白)區域
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RectangleBevel.Dispose();
                    HOperatorSet.GenRectangle1(out ho_RectangleBevel, 0, (hv_waferEdge - hv_BevelWidth) + 2,
                        hv_Height - 1, hv_waferEdgeMax - 3);
                }
                ho_ImageReduced_inner.Dispose();
                HOperatorSet.ReduceDomain(ho_Image, ho_RectangleBevel, out ho_ImageReduced_inner
                    );
                //抓取bypass區域(研磨邊緣黑線)
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RectangleBypass.Dispose();
                    HOperatorSet.GenRectangle1(out ho_RectangleBypass, 0, hv_secondEdgeMin - 2, hv_Height - 1,
                        hv_secondEdgeMax + 2);
                }
                ho_ImageReduced_bypass.Dispose();
                HOperatorSet.ReduceDomain(ho_Image, ho_RectangleBypass, out ho_ImageReduced_bypass
                    );


                if ((int)(new HTuple(hv_InnerThresholdMax.TupleEqual(-1))) != 0)
                {
                    ho_innerRegionReal.Dispose(); hv_UsedThreshold1.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageReduced_inner, out ho_innerRegionReal,
                        "max_separability", "dark", out hv_UsedThreshold1);
                }
                else
                {
                    ho_innerRegionReal.Dispose();
                    HOperatorSet.Threshold(ho_ImageReduced_inner, out ho_innerRegionReal, 0,
                        hv_InnerThresholdMax);
                }
                hv_Row11.Dispose(); hv_Column1.Dispose(); hv_Row21.Dispose(); hv_realRightCol.Dispose();
                HOperatorSet.SmallestRectangle1(ho_innerRegionReal, out hv_Row11, out hv_Column1,
                    out hv_Row21, out hv_realRightCol);

                //reduce_domain (ImageScaled, RectangleBevel, ImageReduced_innerMean)
                //binary_threshold (ImageReduced_innerMean, innerROI, 'max_separability', 'dark', UsedThreshold2)
                //connection (innerROI, ConnectedRegions2)
                //area_center (ConnectedRegions2, Area4, Row6, Column6)
                //if (|Area4|>1)
                //*     tuple_sort_index (Area4, Indices2)
                //*     select_obj (ConnectedRegions2, innerROI, Indices2[|Indices2|-1]+1)
                //endif
                //dilation_rectangle1 (innerROI, innerROI, 46, 4)
                //shape_trans (innerROI, innerROI, 'rectangle1')
                //smallest_rectangle1 (innerROI, innerROIRow1, innerROICol1, innerROIRow2, RoiRightCol)

                //找斜切面(內白) 缺陷
                ho_BevelDefect.Dispose();
                HOperatorSet.Difference(ho_innerRegionReal, ho_ImageReduced_bypass, out ho_BevelDefect
                    );
                hv_Area1.Dispose(); hv_Row3.Dispose(); hv_Column3.Dispose();
                HOperatorSet.AreaCenter(ho_BevelDefect, out hv_Area1, out hv_Row3, out hv_Column3);

                //connection (BevelDefect, innerEdgeDefects)
                //area_center (innerEdgeDefects, Area2, Row4, Column4)
                //smallest_rectangle1 (innerEdgeDefects, Row13, Column12, Row23, Column21)

                //intensity (innerEdgeDefects, ImageReduced_inner, Mean, Deviation)
                //height_width_ratio (innerEdgeDefects, Height1, Width1, Ratio)



                //threshold (ImageScaled, Region, 0, 107)
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_ImageReduced, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_BevelDefect, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                }

                //gen_arrow_contour_xld (Arrow, 0, RoiRightCol, Height, RoiRightCol, 0, 0)
                if (HDevWindowStack.IsOpen())
                {
                    //dev_display (Arrow)
                }
                //if (|Area|>=3)
                //disp_message (WindowHandle, '有三個區域 這張圖異常!', 'image', 50, 50, 'black', 'true')
                if (HDevWindowStack.IsOpen())
                {
                    //dev_display (innerEdgeDefects)
                }
                //ErrorOut := [ErrorOut,'有三個區域 這張圖異常!']
                //endif
                //gen_empty_obj (RegionDilation)
                //判斷是否有斜切面(內白) 缺陷
                //if (Area1!=0)
                if (HDevWindowStack.IsOpen())
                {
                    //dev_set_color ('cyan')
                }
                //dilation_rectangle1 (BevelDefect, RegionDilation, DisplayDilation, DisplayDilation)
                //smallest_rectangle1 (RegionDilation, Row12, Column11, Row22, Column23)
                //*     if (Column23 > waferEdge)
                //ErrorOut := [ErrorOut,'斜切面缺陷超過導角區域 這張圖異常!']
                //*     endif
                //*     if (RoiRightCol-5 > Column11)
                //ErrorOut := [ErrorOut,'斜切面缺陷位於面內黑區域 這張圖異常!']
                //*     endif

                //endif
                //黑區域
                //erosion_rectangle1 (Region, RegionErosion, 4, 1)
                //reduce_domain (ImageScaled, RegionErosion, ImageReduced1)
                //reduce_domain (Image, RegionErosion, ImageReduced2)
                //dyn_threshold (ImageReduced2, ImageReduced1, RegionDynThresh, 30, 'light')

                //白區域
                //DilaWidth := 6
                //smallest_rectangle1 (innerROI, Row14, Column13, Row24, Column22)
                //gen_rectangle1 (Rectangle2, 0, Column22+DilaWidth/2, Height-1, Width-1)
                //difference (Rectangle2, Region, RegionDifference)
                //dilation_rectangle1 (RegionDifference, RegionDilation1, DilaWidth, 1)
                //reduce_domain (ImageScaled, RegionDilation1, ImageReduced1)
                //reduce_domain (Image, RegionDilation1, ImageReduced2)
                //dyn_threshold (ImageReduced2, ImageReduced1, RegionDynThresh1, 25, 'dark')
                //opening_rectangle1 (RegionDynThresh1, RegionDynThresh2, 3, 3)

                //結合黑白區
                //union2 (RegionDynThresh, RegionDynThresh2, Defect)
                //opening_rectangle1 (Defect, Defect, 1.5, 1.5)
                //connection (Defect, ConnectedRegions1)
                //area_center (ConnectedRegions1, Area3, Row5, Column5)
                //height_width_ratio (ConnectedRegions1, Height2, Width2, Ratio1)
                //tuple_find (Width2[>]1 and Area3[>=]3, true, Indices1)
                //if (Indices1!=-1)
                //select_obj (ConnectedRegions1, DefectAll, Indices1+1)
                if (HDevWindowStack.IsOpen())
                {
                    //dev_set_color ('magenta')
                }

                //dilation_rectangle1 (DefectAll, DefectAll, DisplayDilation, DisplayDilation)

                if (HDevWindowStack.IsOpen())
                {
                    //dev_display (DefectAll)
                }
                //disp_message (WindowHandle, '這張圖異常!', 'image', 50, 50, 'black', 'true')
                //ErrorOut := [ErrorOut,'這張圖異常!']
                //RegionDilation := Region
                //RegionDilation := ConnectedRegions1
                //return ()
                //endif


                //--Resize尺寸
                hv_ResizeScale.Dispose();
                hv_ResizeScale = 0.8;

                //-----檢查面內 AOI-----------------------------------------------------------------
                if ((int)((new HTuple(hv_InnerDefectAreaSize.TupleGreater(0))).TupleOr(new HTuple(hv_InnerDefectMaxGray.TupleGreater(
                    0)))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_AllInnerRoi.Dispose();
                        HOperatorSet.GenRectangle1(out ho_AllInnerRoi, 0, 0, hv_Height - 1, hv_innerEdge - 2);
                    }
                    //前處理

                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_ImageZoom.Dispose();
                        HOperatorSet.ZoomImageSize(ho_Image, out ho_ImageZoom, hv_Width * hv_ResizeScale,
                            hv_Height * hv_ResizeScale, "constant");
                    }
                    ho_ResizeImg.Dispose();
                    HOperatorSet.ZoomImageSize(ho_ImageZoom, out ho_ResizeImg, hv_Width, hv_Height,
                        "constant");
                    ho_ImageReduced3.Dispose();
                    HOperatorSet.ReduceDomain(ho_ResizeImg, ho_AllInnerRoi, out ho_ImageReduced3
                        );
                    ho_innerDefectResult.Dispose();
                    HOperatorSet.Threshold(ho_ImageReduced3, out ho_innerDefectResult, 0, hv_InnerDefectMaxGray);
                    //connection (Region1, ConnectedRegions4)
                    //select_shape (ConnectedRegions4, InnerDefect, 'area', 'and', InnerDefectAreaSize, 9999999999)
                    //dilation_rectangle1 (InnerDefect, InnerDefectDilation, DisplayDilation, DisplayDilation)
                }

                //----------------------------------------------------------------------------------
                //if (InnerDefectAreaSize>0 or InnerDefectMaxGray>0)
                //union2 (DefectAll, InnerDefectDilation, DefectAll)
                //endif

                //面內只檢連邊
                if ((int)(new HTuple(hv_OnlyDetectEdge.TupleEqual(1))) != 0)
                {
                    ho_ConnectedinnerDefectResult.Dispose();
                    HOperatorSet.Connection(ho_innerDefectResult, out ho_ConnectedinnerDefectResult
                        );
                    hv_Number.Dispose();
                    HOperatorSet.CountObj(ho_ConnectedinnerDefectResult, out hv_Number);
                    ho_selectRegion.Dispose();
                    HOperatorSet.GenEmptyRegion(out ho_selectRegion);
                    HTuple end_val184 = hv_Number;
                    HTuple step_val184 = 1;
                    for (hv_Index = 1; hv_Index.Continue(end_val184, step_val184); hv_Index = hv_Index.TupleAdd(step_val184))
                    {
                        ho_selectDefect.Dispose();
                        HOperatorSet.SelectObj(ho_ConnectedinnerDefectResult, out ho_selectDefect,
                            hv_Index);
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_DistanceMin.Dispose(); hv_DistanceMax.Dispose();
                            HOperatorSet.DistanceLr(ho_selectDefect, 0, hv_innerEdge, hv_Height - 1,
                                hv_innerEdge, out hv_DistanceMin, out hv_DistanceMax);
                        }
                        if ((int)(new HTuple(hv_DistanceMin.TupleLess(3))) != 0)
                        {
                            {
                                HObject ExpTmpOutVar_0;
                                HOperatorSet.Union2(ho_selectDefect, ho_selectRegion, out ExpTmpOutVar_0
                                    );
                                ho_selectRegion.Dispose();
                                ho_selectRegion = ExpTmpOutVar_0;
                            }
                        }
                    }
                    //整合缺陷
                    ho_DefectAll.Dispose();
                    HOperatorSet.Union2(ho_BevelDefect, ho_selectRegion, out ho_DefectAll);
                }
                else
                {
                    //整合缺陷
                    ho_DefectAll.Dispose();
                    HOperatorSet.Union2(ho_BevelDefect, ho_innerDefectResult, out ho_DefectAll
                        );
                }

                ho_ConnectedDefectAll.Dispose();
                HOperatorSet.Connection(ho_DefectAll, out ho_ConnectedDefectAll);
                ho_ConnectedDefectAllOpen.Dispose();
                HOperatorSet.OpeningRectangle1(ho_ConnectedDefectAll, out ho_ConnectedDefectAllOpen,
                    2, 2);
                ho_ConnectedDefectAllOpenClose.Dispose();
                HOperatorSet.ClosingRectangle1(ho_ConnectedDefectAllOpen, out ho_ConnectedDefectAllOpenClose,
                    10, 10);
                ho_selectDefectAll.Dispose();
                HOperatorSet.SelectShape(ho_ConnectedDefectAllOpenClose, out ho_selectDefectAll,
                    "area", "and", hv_InnerDefectAreaSize, 9999999999);

                //dilation_rectangle1 (selectDefectAll, selectDefectAllDilate, 4, 4)
                //erosion_rectangle1 (selectDefectAllDilate, selectDefectAllOpen, 4, 4)

                hv_Area.Dispose();
                HOperatorSet.RegionFeatures(ho_selectDefectAll, "area", out hv_Area);
                hv_DefectRow1.Dispose();
                HOperatorSet.RegionFeatures(ho_selectDefectAll, "row1", out hv_DefectRow1);
                hv_DefectCol1.Dispose();
                HOperatorSet.RegionFeatures(ho_selectDefectAll, "column1", out hv_DefectCol1);
                hv_DefectRow2.Dispose();
                HOperatorSet.RegionFeatures(ho_selectDefectAll, "row2", out hv_DefectRow2);
                hv_DefectCol2.Dispose();
                HOperatorSet.RegionFeatures(ho_selectDefectAll, "column2", out hv_DefectCol2);
                hv_DefectNumber.Dispose();
                HOperatorSet.CountObj(ho_selectDefectAll, out hv_DefectNumber);


                if ((int)(new HTuple(hv_PaintResult.TupleEqual(1))) != 0)
                {

                    if ((int)(new HTuple(hv_DefectNumber.TupleEqual(0))) != 0)
                    {
                        ho_ResultImage.Dispose();
                        ho_ResultImage = new HObject(ho_Image);
                    }
                    else
                    {
                        ho_ImageResult.Dispose();
                        HOperatorSet.PaintRegion(ho_selectDefectAll, ho_Image, out ho_ImageResult,
                            255, "margin");
                        ho_ImageResult1.Dispose();
                        HOperatorSet.PaintRegion(ho_selectDefectAll, ho_Image, out ho_ImageResult1,
                            0, "margin");
                        ho_ResultImage.Dispose();
                        HOperatorSet.Compose3(ho_ImageResult, ho_ImageResult1, ho_ImageResult1,
                            out ho_ResultImage);
                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispObj(ho_ResultImage, HDevWindowStack.GetActive());
                        }
                    }
                }
                ho_DefectAll.Dispose();
                ho_ConnectedRegions3.Dispose();
                ho_ImageMedian.Dispose();
                ho_ImageScaled.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Lines1.Dispose();
                ho_SortedContours.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_ObjectSelected2.Dispose();
                ho_RectangleBevel.Dispose();
                ho_ImageReduced_inner.Dispose();
                ho_RectangleBypass.Dispose();
                ho_ImageReduced_bypass.Dispose();
                ho_innerRegionReal.Dispose();
                ho_BevelDefect.Dispose();
                ho_AllInnerRoi.Dispose();
                ho_ImageZoom.Dispose();
                ho_ResizeImg.Dispose();
                ho_ImageReduced3.Dispose();
                ho_innerDefectResult.Dispose();
                ho_ConnectedinnerDefectResult.Dispose();
                ho_selectRegion.Dispose();
                ho_selectDefect.Dispose();
                ho_ConnectedDefectAll.Dispose();
                ho_ConnectedDefectAllOpen.Dispose();
                ho_ConnectedDefectAllOpenClose.Dispose();
                ho_selectDefectAll.Dispose();
                ho_ImageResult.Dispose();
                ho_ImageResult1.Dispose();

                hv_ErrorOut.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Number.Dispose();
                hv_row.Dispose();
                hv_col1.Dispose();
                hv_waferEdge.Dispose();
                hv_waferEdgeMin.Dispose();
                hv_waferEdgeMax.Dispose();
                hv_col2.Dispose();
                hv_secondEdge.Dispose();
                hv_secondEdgeMin.Dispose();
                hv_secondEdgeMax.Dispose();
                hv_innerEdge.Dispose();
                hv_UsedThreshold1.Dispose();
                hv_Row11.Dispose();
                hv_Column1.Dispose();
                hv_Row21.Dispose();
                hv_realRightCol.Dispose();
                hv_Area1.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_ResizeScale.Dispose();
                hv_Index.Dispose();
                hv_DistanceMin.Dispose();
                hv_DistanceMax.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_DefectAll.Dispose();
                ho_ConnectedRegions3.Dispose();
                ho_ImageMedian.Dispose();
                ho_ImageScaled.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Lines1.Dispose();
                ho_SortedContours.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_ObjectSelected2.Dispose();
                ho_RectangleBevel.Dispose();
                ho_ImageReduced_inner.Dispose();
                ho_RectangleBypass.Dispose();
                ho_ImageReduced_bypass.Dispose();
                ho_innerRegionReal.Dispose();
                ho_BevelDefect.Dispose();
                ho_AllInnerRoi.Dispose();
                ho_ImageZoom.Dispose();
                ho_ResizeImg.Dispose();
                ho_ImageReduced3.Dispose();
                ho_innerDefectResult.Dispose();
                ho_ConnectedinnerDefectResult.Dispose();
                ho_selectRegion.Dispose();
                ho_selectDefect.Dispose();
                ho_ConnectedDefectAll.Dispose();
                ho_ConnectedDefectAllOpen.Dispose();
                ho_ConnectedDefectAllOpenClose.Dispose();
                ho_selectDefectAll.Dispose();
                ho_ImageResult.Dispose();
                ho_ImageResult1.Dispose();

                hv_ErrorOut.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Number.Dispose();
                hv_row.Dispose();
                hv_col1.Dispose();
                hv_waferEdge.Dispose();
                hv_waferEdgeMin.Dispose();
                hv_waferEdgeMax.Dispose();
                hv_col2.Dispose();
                hv_secondEdge.Dispose();
                hv_secondEdgeMin.Dispose();
                hv_secondEdgeMax.Dispose();
                hv_innerEdge.Dispose();
                hv_UsedThreshold1.Dispose();
                hv_Row11.Dispose();
                hv_Column1.Dispose();
                hv_Row21.Dispose();
                hv_realRightCol.Dispose();
                hv_Area1.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_ResizeScale.Dispose();
                hv_Index.Dispose();
                hv_DistanceMin.Dispose();
                hv_DistanceMax.Dispose();

                throw HDevExpDefaultException;
            }
        }

        /// <summary>
        /// 缺陷檢查 包含面內缺陷檢查 包含AI的結果抓取
        /// </summary>
        /// <param name = "ho_CropImage">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_ImageAi">
        /// <para>輸入STPM輸出的影像</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_ImageOut">
        /// <para>輸出繪製缺陷的圖</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_RoiWidthToBevelCenter">
        /// <para>Roi寬度(最左至斜切面中心點距離) 單位:Pixel  預設:90</para>
        /// <para>型態: </para>
        /// <para>建議值: 90</para>
        /// </param>
        /// <param name = "hv_BevelWidth">
        /// <para>斜切面寬度 單位pixel 預設:27</para>
        /// <para>型態: </para>
        /// <para>建議值: 27</para>
        /// </param>
        /// <param name = "hv_DisplayDilation">
        /// <para>顯示使用 框選defect 預設:5</para>
        /// <para>型態: </para>
        /// <para>預設值: 5</para>
        /// </param>
        /// <param name = "hv_InnerThresholdMax">
        /// <para>面內區域最大灰接值(輸入-1為自動)  預設:230</para>
        /// <para>型態: </para>
        /// <para>預設值: 230</para>
        /// </param>
        /// <param name = "hv_AiDefectSize">
        /// <para>Ai缺陷尺寸下限值(寬高皆大於此值檢出)</para>
        /// <para>型態: </para>
        /// <para>預設值: 7</para>
        /// </param>
        /// <param name = "hv_AiMinGray">
        /// <para>AI輸出圖片白色區域最小灰階值
        /// ****AiMinGray*****設定-1  直接跳過AI繪製步驟</para>
        /// <para>型態: </para>
        /// <para>預設值: -1</para>
        /// </param>
        /// <param name = "hv_InnerDefectAreaSize">
        /// <para>面內缺陷卡控尺寸(面積大於此值檢出) 單位pixel</para>
        /// <para>型態: </para>
        /// <para>預設值: 7</para>
        /// </param>
        /// <param name = "hv_InnerDefectMaxGray">
        /// <para>面內缺陷的最大灰階值</para>
        /// <para>型態: </para>
        /// <para>預設值: 105</para>
        /// </param>
        /// <param name = "hv_AoiDefectNumber">
        /// <para>輸出抓到的缺陷總數量  (AOI面外)</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectRow1">
        /// <para>缺陷的左上座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectCol1">
        /// <para>缺陷的左上座標X</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectRow2">
        /// <para>缺陷的右下座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectCol2">
        /// <para>缺陷的右下座標X</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AiDefectNumber">
        /// <para>Ai缺陷數量</para>
        /// <para>型態: </para>
        /// </param>
        public static void InspectWaferEdgeDefectAndDrawAi(HObject ho_CropImage, HObject ho_ImageAi,
            out HObject ho_ImageOut, HTuple hv_RoiWidthToBevelCenter, HTuple hv_BevelWidth,
            HTuple hv_DisplayDilation, HTuple hv_InnerThresholdMax, HTuple hv_AiDefectSize,
            HTuple hv_AiMinGray, HTuple hv_InnerDefectAreaSize, HTuple hv_InnerDefectMaxGray,
            HTuple hv_EdgeDefectAreaSize, HTuple hv_PaintResult, HTuple hv_OnlyDetectEdge,
            out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
            out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber,
            out HTuple hv_Area)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_DefectAll, ho_AiDefectRegion;

            // Local control variables 

            HTuple hv_InnerDistance = new HTuple(), hv_R = new HTuple();
            HTuple hv_G = new HTuple(), hv_B = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_DefectAll);
            HOperatorSet.GenEmptyObj(out ho_AiDefectRegion);
            hv_AoiDefectNumber = new HTuple();
            hv_DefectRow1 = new HTuple();
            hv_DefectCol1 = new HTuple();
            hv_DefectRow2 = new HTuple();
            hv_DefectCol2 = new HTuple();
            hv_AiDefectNumber = new HTuple();
            hv_Area = new HTuple();
            try
            {
                //v1.0  2023/04/17 wafer面外AOI檢察，將AI(面內結果也畫再上面
                //v1.1  2023/04/24 新增面內缺陷檢查 新增兩個參數InnerDefectAreaSize, InnerDefectMaxGray ，若輸入0 或 -1則不進行面內檢測
                //v1.2  2024/03/20 新增邊緣瑕疵檢測參數 EdgeDefectAreaSize

                ho_DefectAll.Dispose(); ho_ImageOut.Dispose(); hv_AoiDefectNumber.Dispose(); hv_DefectRow1.Dispose(); hv_DefectCol1.Dispose(); hv_DefectRow2.Dispose(); hv_DefectCol2.Dispose(); hv_Area.Dispose();
                InspectWaferEdgeDefect(ho_CropImage, out ho_DefectAll, out ho_ImageOut, hv_RoiWidthToBevelCenter,
                    hv_BevelWidth, hv_DisplayDilation, hv_InnerThresholdMax, hv_InnerDefectAreaSize,
                    hv_InnerDefectMaxGray, hv_EdgeDefectAreaSize, hv_PaintResult, hv_OnlyDetectEdge,
                    out hv_AoiDefectNumber, out hv_DefectRow1, out hv_DefectCol1, out hv_DefectRow2,
                    out hv_DefectCol2, out hv_Area);

                hv_InnerDistance.Dispose();
                hv_InnerDistance = 0;

                ho_AiDefectRegion.Dispose(); hv_AiDefectNumber.Dispose();
                AiSelectDefect(ho_ImageAi, out ho_AiDefectRegion, hv_InnerDistance, hv_AiDefectSize,
                    hv_AiMinGray, out hv_AiDefectNumber);
                //[255,0,0]
                hv_R.Dispose();
                hv_R = 0;
                hv_G.Dispose();
                hv_G = 255;
                hv_B.Dispose();
                hv_B = 0;
                {
                    HObject ExpTmpOutVar_0;
                    DrawRegion(ho_ImageOut, ho_AiDefectRegion, out ExpTmpOutVar_0, hv_DisplayDilation,
                        hv_R, hv_G, hv_B);
                    ho_ImageOut.Dispose();
                    ho_ImageOut = ExpTmpOutVar_0;
                }
                ho_DefectAll.Dispose();
                ho_AiDefectRegion.Dispose();

                hv_InnerDistance.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_DefectAll.Dispose();
                ho_AiDefectRegion.Dispose();

                hv_InnerDistance.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                throw HDevExpDefaultException;
            }
        } //v1.7
        #endregion

        #region 瑕疵檢測第二版
        public static void InspectionDefect_V2(HObject ho_Image, out HObject ho_DefectOut, out HObject ho_DefectDisplay,
                out HObject ho_ImageOut, HTuple hv_ROIColumn, HTuple hv_DarkLightThreshold,
                HTuple hv_light_DarkThres, HTuple hv_DarkMax, HTuple hv_Dark_DarkThres, HTuple hv_Dark_LightThres,
                HTuple hv_WhiteThres, HTuple hv_DisplayDilation, HTuple hv_MinAreaSize, HTuple hv_MinDefectSize,
                out HTuple hv_DefectHeight, out HTuple hv_DefectWidth, out HTuple hv_DefectNumber,
                out HTuple hv_DefectRows, out HTuple hv_DefectCols)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_OutDefectAll, ho_DefectAll, ho_Rectangle;
            HObject ho_CropImage, ho_CropImageMedian, ho_LightRegion;
            HObject ho_MeanLight, ho_Light, ho_Light_DarkDefect, ho_DarkRegion;
            HObject ho_MeanDark, ho_Dark, ho_Dark_DarkDefect, ho_Dark_lightDefect;
            HObject ho_MinDarkRegion, ho_ImageReduced, ho_ImageReduced1;
            HObject ho_WhiteDefect, ho_Defect, ho_Defects, ho_RegionLines;

            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_Area = new HTuple(), hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Ratio = new HTuple(), hv_Row1 = new HTuple();
            HTuple hv_Column1 = new HTuple(), hv_Phi = new HTuple();
            HTuple hv_Length1 = new HTuple(), hv_Length2 = new HTuple();
            HTuple hv_Indices = new HTuple(), hv_R = new HTuple();
            HTuple hv_G = new HTuple(), hv_B = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_DefectOut);
            HOperatorSet.GenEmptyObj(out ho_DefectDisplay);
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_OutDefectAll);
            HOperatorSet.GenEmptyObj(out ho_DefectAll);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_CropImage);
            HOperatorSet.GenEmptyObj(out ho_CropImageMedian);
            HOperatorSet.GenEmptyObj(out ho_LightRegion);
            HOperatorSet.GenEmptyObj(out ho_MeanLight);
            HOperatorSet.GenEmptyObj(out ho_Light);
            HOperatorSet.GenEmptyObj(out ho_Light_DarkDefect);
            HOperatorSet.GenEmptyObj(out ho_DarkRegion);
            HOperatorSet.GenEmptyObj(out ho_MeanDark);
            HOperatorSet.GenEmptyObj(out ho_Dark);
            HOperatorSet.GenEmptyObj(out ho_Dark_DarkDefect);
            HOperatorSet.GenEmptyObj(out ho_Dark_lightDefect);
            HOperatorSet.GenEmptyObj(out ho_MinDarkRegion);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced1);
            HOperatorSet.GenEmptyObj(out ho_WhiteDefect);
            HOperatorSet.GenEmptyObj(out ho_Defect);
            HOperatorSet.GenEmptyObj(out ho_Defects);
            HOperatorSet.GenEmptyObj(out ho_RegionLines);
            hv_DefectHeight = new HTuple();
            hv_DefectWidth = new HTuple();
            hv_DefectNumber = new HTuple();
            hv_DefectRows = new HTuple();
            hv_DefectCols = new HTuple();
            try
            {
                //20230609 缺陷檢查 透過自己的影像進行均值模糊後，在進行灰階差比較，分為亮、暗、深色區域
                //亮區 檢查 暗缺陷
                //暗區 檢查 亮缺陷、暗缺陷
                //深色 檢查 亮缺陷
                ho_OutDefectAll.Dispose();
                HOperatorSet.GenEmptyObj(out ho_OutDefectAll);
                ho_DefectAll.Dispose();
                HOperatorSet.GenEmptyObj(out ho_DefectAll);
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle, 0, hv_ROIColumn, 500, 500);
                ho_CropImage.Dispose();
                HOperatorSet.ReduceDomain(ho_Image, ho_Rectangle, out ho_CropImage);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_CropImageMedian.Dispose();
                    HOperatorSet.MedianRect(ho_CropImage, out ho_CropImageMedian, 1, hv_Height - 5);
                }

                //mirror_image (CropImageMedian, ImageMirror, 'row')
                //add_image (CropImageMedian, ImageMirror, ImageResult, 0.5, 0)
                //median_rect (ImageResult, CropImageMedian, 1, Height-5)
                ho_LightRegion.Dispose();
                HOperatorSet.Threshold(ho_CropImageMedian, out ho_LightRegion, hv_DarkLightThreshold,
                    255);
                ho_MeanLight.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImageMedian, ho_LightRegion, out ho_MeanLight
                    );
                ho_Light.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImage, ho_LightRegion, out ho_Light);
                ho_Light_DarkDefect.Dispose();
                HOperatorSet.DynThreshold(ho_Light, ho_MeanLight, out ho_Light_DarkDefect,
                    hv_light_DarkThres, "dark");
                ho_DarkRegion.Dispose();
                HOperatorSet.Threshold(ho_CropImageMedian, out ho_DarkRegion, hv_DarkMax, hv_DarkLightThreshold);
                ho_MeanDark.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImageMedian, ho_DarkRegion, out ho_MeanDark
                    );
                ho_Dark.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImage, ho_DarkRegion, out ho_Dark);
                ho_Dark_DarkDefect.Dispose();
                HOperatorSet.DynThreshold(ho_Dark, ho_MeanDark, out ho_Dark_DarkDefect, hv_Dark_DarkThres,
                    "dark");
                ho_Dark_lightDefect.Dispose();
                HOperatorSet.DynThreshold(ho_Dark, ho_MeanDark, out ho_Dark_lightDefect, hv_Dark_LightThres,
                    "light");

                ho_MinDarkRegion.Dispose();
                HOperatorSet.Threshold(ho_CropImageMedian, out ho_MinDarkRegion, 0, hv_DarkMax);
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImage, ho_MinDarkRegion, out ho_ImageReduced
                    );
                ho_ImageReduced1.Dispose();
                HOperatorSet.ReduceDomain(ho_CropImageMedian, ho_MinDarkRegion, out ho_ImageReduced1
                    );

                ho_WhiteDefect.Dispose();
                HOperatorSet.DynThreshold(ho_ImageReduced, ho_ImageReduced1, out ho_WhiteDefect,
                    hv_WhiteThres, "light");


                ho_Defect.Dispose();
                HOperatorSet.Union2(ho_Light_DarkDefect, ho_Dark_DarkDefect, out ho_Defect);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.Union2(ho_Defect, ho_Dark_lightDefect, out ExpTmpOutVar_0);
                    ho_Defect.Dispose();
                    ho_Defect = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.Union2(ho_Defect, ho_WhiteDefect, out ExpTmpOutVar_0);
                    ho_Defect.Dispose();
                    ho_Defect = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.OpeningCircle(ho_Defect, out ExpTmpOutVar_0, 2);
                    ho_Defect.Dispose();
                    ho_Defect = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ClosingCircle(ho_Defect, out ExpTmpOutVar_0, hv_DisplayDilation);
                    ho_Defect.Dispose();
                    ho_Defect = ExpTmpOutVar_0;
                }
                ho_Defects.Dispose();
                HOperatorSet.Connection(ho_Defect, out ho_Defects);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_Defects, out hv_Area, out hv_Row, out hv_Column);
                hv_DefectHeight.Dispose(); hv_DefectWidth.Dispose(); hv_Ratio.Dispose();
                HOperatorSet.HeightWidthRatio(ho_Defects, out hv_DefectHeight, out hv_DefectWidth,
                    out hv_Ratio);
                hv_Row1.Dispose(); hv_Column1.Dispose(); hv_Phi.Dispose(); hv_Length1.Dispose(); hv_Length2.Dispose();
                HOperatorSet.SmallestRectangle2(ho_Defects, out hv_Row1, out hv_Column1, out hv_Phi,
                    out hv_Length1, out hv_Length2);

                //-瑕疵大小卡控
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Indices.Dispose();
                    HOperatorSet.TupleFind(((hv_Area.TupleGreaterEqualElem(hv_MinAreaSize))).TupleAnd(
                        ((hv_Length1 * 2)).TupleGreaterEqualElem(hv_MinDefectSize)), 1, out hv_Indices);
                }
                if ((int)(new HTuple(hv_Indices.TupleNotEqual(-1))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_DefectOut.Dispose();
                        HOperatorSet.SelectObj(ho_Defects, out ho_DefectOut, hv_Indices + 1);
                    }
                    hv_DefectNumber.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_DefectNumber = new HTuple(hv_Indices.TupleLength()
                            );
                    }
                    hv_DefectRows.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_DefectRows = hv_Row.TupleSelect(
                            hv_Indices);
                    }
                    hv_DefectCols.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_DefectCols = hv_Column.TupleSelect(
                            hv_Indices);
                    }
                    ho_DefectDisplay.Dispose();
                    HOperatorSet.DilationCircle(ho_DefectOut, out ho_DefectDisplay, hv_DisplayDilation);

                }
                else
                {
                    hv_DefectNumber.Dispose();
                    hv_DefectNumber = 0;
                    hv_DefectRows.Dispose();
                    hv_DefectRows = new HTuple();
                    hv_DefectCols.Dispose();
                    hv_DefectCols = new HTuple();
                    ho_DefectOut.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_DefectOut);
                    ho_DefectDisplay.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_DefectDisplay);

                }
                //[255,0,0]
                hv_R.Dispose();
                hv_R = 255;
                hv_G.Dispose();
                hv_G = 0;
                hv_B.Dispose();
                hv_B = 0;
                ho_ImageOut.Dispose();
                DrawRegion(ho_Image, ho_DefectOut, out ho_ImageOut, hv_DisplayDilation, hv_R,
                    hv_G, hv_B);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, 0, hv_ROIColumn, hv_Height - 1,
                        hv_ROIColumn);
                }
                {
                    HObject ExpTmpOutVar_0;
                    DrawRegion(ho_ImageOut, ho_RegionLines, out ExpTmpOutVar_0, 0, 0, 255, 0);
                    ho_ImageOut.Dispose();
                    ho_ImageOut = ExpTmpOutVar_0;
                }

                ho_OutDefectAll.Dispose();
                ho_DefectAll.Dispose();
                ho_Rectangle.Dispose();
                ho_CropImage.Dispose();
                ho_CropImageMedian.Dispose();
                ho_LightRegion.Dispose();
                ho_MeanLight.Dispose();
                ho_Light.Dispose();
                ho_Light_DarkDefect.Dispose();
                ho_DarkRegion.Dispose();
                ho_MeanDark.Dispose();
                ho_Dark.Dispose();
                ho_Dark_DarkDefect.Dispose();
                ho_Dark_lightDefect.Dispose();
                ho_MinDarkRegion.Dispose();
                ho_ImageReduced.Dispose();
                ho_ImageReduced1.Dispose();
                ho_WhiteDefect.Dispose();
                ho_Defect.Dispose();
                ho_Defects.Dispose();
                ho_RegionLines.Dispose();

                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Ratio.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Phi.Dispose();
                hv_Length1.Dispose();
                hv_Length2.Dispose();
                hv_Indices.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_OutDefectAll.Dispose();
                ho_DefectAll.Dispose();
                ho_Rectangle.Dispose();
                ho_CropImage.Dispose();
                ho_CropImageMedian.Dispose();
                ho_LightRegion.Dispose();
                ho_MeanLight.Dispose();
                ho_Light.Dispose();
                ho_Light_DarkDefect.Dispose();
                ho_DarkRegion.Dispose();
                ho_MeanDark.Dispose();
                ho_Dark.Dispose();
                ho_Dark_DarkDefect.Dispose();
                ho_Dark_lightDefect.Dispose();
                ho_MinDarkRegion.Dispose();
                ho_ImageReduced.Dispose();
                ho_ImageReduced1.Dispose();
                ho_WhiteDefect.Dispose();
                ho_Defect.Dispose();
                ho_Defects.Dispose();
                ho_RegionLines.Dispose();

                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Ratio.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Phi.Dispose();
                hv_Length1.Dispose();
                hv_Length2.Dispose();
                hv_Indices.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.2
        #endregion

        #region AI缺陷 & 畫缺陷
        // Local procedures 
        /// <summary>
        /// 檢查AI輸出圖片有沒有缺陷(限灰階圖) 注意 此function輸出的是Region!
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_DefectRegion">
        /// <para>缺陷region</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_InnerDistance">
        /// <para>圖片最左至要檢查的距離，範圍內的缺陷才算缺陷</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AiDefectSize">
        /// <para>缺陷尺寸</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AiMinGray">
        /// <para>最小灰階值</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_AiDefectNumber">
        /// <para>缺陷數量</para>
        /// <para>型態: </para>
        /// </param>
        public static void AiSelectDefect(HObject ho_Image, out HObject ho_DefectRegion, HTuple hv_InnerDistance,
            HTuple hv_AiDefectSize, HTuple hv_AiMinGray, out HTuple hv_AiDefectNumber)
        {




            // Local iconic variables 

            HObject ho_Regions, ho_ConnectedRegions;

            // Local control variables 

            HTuple hv_InnerDistanceOut = new HTuple();
            HTuple hv_Row1 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Row2 = new HTuple(), hv_Column2 = new HTuple();
            HTuple hv_Height = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Ratio = new HTuple(), hv_Area = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_Height1 = new HTuple(), hv_idx = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_DefectRegion);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            hv_AiDefectNumber = new HTuple();
            try
            {
                //2023/04/12 檢查AI結果使否有缺陷，並卡控位置與尺寸，注意 此function輸出的是Region!
                //2023/04/17 v1.1  AiDefectNumber:=0 初始化
                hv_InnerDistanceOut.Dispose();
                hv_InnerDistanceOut = new HTuple(hv_InnerDistance);
                hv_AiDefectNumber.Dispose();
                hv_AiDefectNumber = 0;
                ho_DefectRegion.Dispose();
                HOperatorSet.GenEmptyObj(out ho_DefectRegion);

                ho_Regions.Dispose();
                HOperatorSet.Threshold(ho_Image, out ho_Regions, hv_AiMinGray, 255);
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
                hv_Row1.Dispose(); hv_Column1.Dispose(); hv_Row2.Dispose(); hv_Column2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_ConnectedRegions, out hv_Row1, out hv_Column1,
                    out hv_Row2, out hv_Column2);
                if ((int)(new HTuple(hv_Column1.TupleEqual(new HTuple()))) != 0)
                {
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();

                    hv_InnerDistanceOut.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Row2.Dispose();
                    hv_Column2.Dispose();
                    hv_Height.Dispose();
                    hv_Width.Dispose();
                    hv_Ratio.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Height1.Dispose();
                    hv_idx.Dispose();

                    return;
                }
                hv_Height.Dispose(); hv_Width.Dispose(); hv_Ratio.Dispose();
                HOperatorSet.HeightWidthRatio(ho_ConnectedRegions, out hv_Height, out hv_Width,
                    out hv_Ratio);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions, out hv_Area, out hv_Row, out hv_Column);
                if ((int)(new HTuple(hv_InnerDistanceOut.TupleLessEqual(0))) != 0)
                {
                    hv_InnerDistanceOut.Dispose(); hv_Height1.Dispose();
                    HOperatorSet.GetImageSize(ho_Image, out hv_InnerDistanceOut, out hv_Height1);
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_idx.Dispose();
                    HOperatorSet.TupleFind((new HTuple(((hv_Column1.TupleLessElem(hv_InnerDistanceOut))).TupleAnd(
                        hv_Height.TupleGreaterEqualElem(hv_AiDefectSize)))).TupleAnd(hv_Width.TupleGreaterEqualElem(
                        hv_AiDefectSize)), 1, out hv_idx);
                }

                if ((int)(new HTuple(hv_idx.TupleNotEqual(-1))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_DefectRegion.Dispose();
                        HOperatorSet.SelectObj(ho_ConnectedRegions, out ho_DefectRegion, hv_idx + 1);
                    }
                    hv_AiDefectNumber.Dispose();
                    HOperatorSet.CountObj(ho_DefectRegion, out hv_AiDefectNumber);
                }
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();

                hv_InnerDistanceOut.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Height.Dispose();
                hv_Width.Dispose();
                hv_Ratio.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Height1.Dispose();
                hv_idx.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();

                hv_InnerDistanceOut.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Height.Dispose();
                hv_Width.Dispose();
                hv_Ratio.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Height1.Dispose();
                hv_idx.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.1
        /// <summary>
        /// 將Region繪製於圖片上
        /// </summary>
        /// <param name = "ho_ImageIn">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject[]</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_Region">
        /// <para>輸入要繪製的Region</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_ImageOut">
        /// <para>輸出繪製Region圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_DilationSize">
        /// <para>繪製region膨漲邊緣尺寸，若填入0 以下數值則不膨漲</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_R">
        /// <para>繪製顏色 R</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_G">
        /// <para>繪製顏色G</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_B">
        /// <para>繪製顏色 B</para>
        /// <para>型態: </para>
        /// </param>
        public static void DrawRegion(HObject ho_ImageIn, HObject ho_Region, out HObject ho_ImageOut,
            HTuple hv_DilationSize, HTuple hv_R, HTuple hv_G, HTuple hv_B)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_RegionOut = null, ho_Image1 = null;
            HObject ho_Image2 = null, ho_Image3 = null, ho_ImageR = null;
            HObject ho_ImagG = null, ho_ImageB = null;

            // Local control variables 

            HTuple hv_Area = new HTuple(), hv_Row = new HTuple();
            HTuple hv_Column = new HTuple(), hv_Channels = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_RegionOut);
            HOperatorSet.GenEmptyObj(out ho_Image1);
            HOperatorSet.GenEmptyObj(out ho_Image2);
            HOperatorSet.GenEmptyObj(out ho_Image3);
            HOperatorSet.GenEmptyObj(out ho_ImageR);
            HOperatorSet.GenEmptyObj(out ho_ImagG);
            HOperatorSet.GenEmptyObj(out ho_ImageB);
            try
            {
                //2023/04/12 v1.0 將Region繪至於圖片上 ,可讀取三通到或單通道圖
                //2023/05/23  v1.0 三通道圖片 bug修正
                ho_RegionOut.Dispose();
                ho_RegionOut = new HObject(ho_Region);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_RegionOut, out hv_Area, out hv_Row, out hv_Column);
                if ((int)((new HTuple(hv_Area.TupleEqual(0))).TupleOr(new HTuple(hv_Area.TupleEqual(
                    new HTuple())))) != 0)
                {
                    ho_ImageOut.Dispose();
                    HOperatorSet.CopyImage(ho_ImageIn, out ho_ImageOut);
                    ho_RegionOut.Dispose();
                    ho_Image1.Dispose();
                    ho_Image2.Dispose();
                    ho_Image3.Dispose();
                    ho_ImageR.Dispose();
                    ho_ImagG.Dispose();
                    ho_ImageB.Dispose();

                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Channels.Dispose();

                    return;
                }
                if ((int)((new HTuple((new HTuple((new HTuple((new HTuple((new HTuple(hv_R.TupleGreater(
                    255))).TupleOr(new HTuple(hv_G.TupleGreater(255))))).TupleOr(new HTuple(hv_B.TupleGreater(
                    255))))).TupleOr(new HTuple(hv_R.TupleLess(0))))).TupleOr(new HTuple(hv_G.TupleLess(
                    0))))).TupleOr(new HTuple(hv_B.TupleLess(0)))) != 0)
                {
                    throw new HalconException("R G B請設定於 0~2555 之間");
                    ho_RegionOut.Dispose();
                    ho_Image1.Dispose();
                    ho_Image2.Dispose();
                    ho_Image3.Dispose();
                    ho_ImageR.Dispose();
                    ho_ImagG.Dispose();
                    ho_ImageB.Dispose();

                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Channels.Dispose();

                    return;
                }

                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.Union1(ho_RegionOut, out ExpTmpOutVar_0);
                    ho_RegionOut.Dispose();
                    ho_RegionOut = ExpTmpOutVar_0;
                }
                if ((int)(new HTuple(hv_DilationSize.TupleGreater(0))) != 0)
                {
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.DilationCircle(ho_RegionOut, out ExpTmpOutVar_0, hv_DilationSize);
                        ho_RegionOut.Dispose();
                        ho_RegionOut = ExpTmpOutVar_0;
                    }
                }

                hv_Channels.Dispose();
                HOperatorSet.CountChannels(ho_ImageIn, out hv_Channels);
                if ((int)(new HTuple(hv_Channels.TupleEqual(3))) != 0)
                {
                    ho_Image1.Dispose(); ho_Image2.Dispose(); ho_Image3.Dispose();
                    HOperatorSet.Decompose3(ho_ImageIn, out ho_Image1, out ho_Image2, out ho_Image3
                        );
                    ho_ImageOut.Dispose();
                    HOperatorSet.CopyImage(ho_ImageIn, out ho_ImageOut);
                    //R
                    ho_ImageR.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_Image1, out ho_ImageR, hv_R, "margin");
                    //G
                    ho_ImagG.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_Image2, out ho_ImagG, hv_G, "margin");
                    //B
                    ho_ImageB.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_Image3, out ho_ImageB, hv_B, "margin");

                }
                else if ((int)(new HTuple(hv_Channels.TupleEqual(1))) != 0)
                {
                    ho_ImageOut.Dispose();
                    HOperatorSet.CopyImage(ho_ImageIn, out ho_ImageOut);
                    //R
                    ho_ImageR.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_ImageOut, out ho_ImageR, hv_R,
                        "margin");
                    //G
                    ho_ImagG.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_ImageOut, out ho_ImagG, hv_G, "margin");
                    //B
                    ho_ImageB.Dispose();
                    HOperatorSet.PaintRegion(ho_RegionOut, ho_ImageOut, out ho_ImageB, hv_B,
                        "margin");
                }
                else
                {
                    throw new HalconException("影像通道異常");
                    ho_RegionOut.Dispose();
                    ho_Image1.Dispose();
                    ho_Image2.Dispose();
                    ho_Image3.Dispose();
                    ho_ImageR.Dispose();
                    ho_ImagG.Dispose();
                    ho_ImageB.Dispose();

                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Channels.Dispose();

                    return;
                }

                ho_ImageOut.Dispose();
                HOperatorSet.Compose3(ho_ImageR, ho_ImagG, ho_ImageB, out ho_ImageOut);
                ho_RegionOut.Dispose();
                ho_Image1.Dispose();
                ho_Image2.Dispose();
                ho_Image3.Dispose();
                ho_ImageR.Dispose();
                ho_ImagG.Dispose();
                ho_ImageB.Dispose();

                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Channels.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_RegionOut.Dispose();
                ho_Image1.Dispose();
                ho_Image2.Dispose();
                ho_Image3.Dispose();
                ho_ImageR.Dispose();
                ho_ImagG.Dispose();
                ho_ImageB.Dispose();

                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Channels.Dispose();

                throw HDevExpDefaultException;
            }
        }//v1.1

        //TileAllofResultImages
        public static void TileAllImages(HObject[] resultImages, out HObject tileImage)
        {
            HObject concatImage = null;
            HOperatorSet.GenEmptyObj(out concatImage);

            foreach (HObject hobj_temp in resultImages)
                HOperatorSet.ConcatObj(concatImage, hobj_temp, out concatImage);

            HOperatorSet.TileImages(concatImage, out tileImage, 1, "vertical");
        }
        #endregion

        #region Notch檢查 & 畫缺陷
        // Local procedures 

        /// <summary>
        /// 
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入檢查圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "ho_ImageOut">
        /// <para>輸出結果圖片</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_BackWhiteMinGray">
        /// <para>背光區 最小灰階值</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DisplayDilation">
        /// <para>顯示缺陷時的眶框距離</para>
        /// <para>型態: </para>
        /// <para>預設值: 5</para>
        /// </param>
        /// <param name = "hv_innerDefectMaxGray">
        /// <para>面內部瑕疵最大灰階值</para>
        /// <para>型態: </para>
        /// <para>預設值: 79</para>
        /// </param>
        /// <param name = "hv_NotchVwRow1">
        /// <para>Notch開口最上Y座標</para>
        /// <para>型態: </para>
        /// <para>預設值: 148</para>
        /// </param>
        /// <param name = "hv_NotchVwRow2">
        /// <para>Notch開口最下Y座標((面內破邊 檢查範圍))</para>
        /// <para>型態: </para>
        /// <para>預設值: 546</para>
        /// </param>
        /// <param name = "hv_NotchBlackWidth">
        /// <para>Notch黑邊寬度</para>
        /// <para>型態: </para>
        /// <para>預設值: 71</para>
        /// </param>
        /// <param name = "hv_InnerDefectMinWidth">
        /// <para>面內邊緣檢出缺陷最大寬度(最小值1) 預設值5</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_OutDefectMinWidth">
        /// <para>面外邊緣檢出缺陷最大寬度(最小值1) 預設值6</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_DefectNumber">
        /// <para>輸出Defect數量</para>
        /// <para>型態: </para>
        /// </param>
        public static void InspectNotchDefect_v2(HObject ho_Image, out HObject ho_ImageOut, out HObject ho_ImageOut_Teach,
            out HObject ho_Teach_Contour, HTuple hv_BackWhiteMinGray, HTuple hv_DisplayDilation,
            HTuple hv_innerDefectMaxGray, HTuple hv_NotchVwRow1, HTuple hv_NotchVwRow2,
            HTuple hv_NotchBlackWidth, HTuple hv_InnerDefectMinWidth, HTuple hv_OutDefectMinWidth,
            out HTuple hv_DefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
            out HTuple hv_DefectRow2, out HTuple hv_DefectCol2)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_GrayImage, ho_Regions, ho_ConnectedRegions;
            HObject ho_OutReg, ho_RegionDilation, ho_RealconcaveDefect;
            HObject ho_RealconvexeDefect, ho_Rectangle, ho_RegionOpening;
            HObject ho_RegionClosing, ho_RegionDifference, ho_convexeDefectReg;
            HObject ho_concaveDefectReg, ho_RegionUnion, ho_ConnectedRegions1;
            HObject ho_OutDefect = null, ho_concaveDefect = null, ho_convexeDefect = null;
            HObject ho_CenterRegion = null, ho_concaveIntersection = null;
            HObject ho_convexeIntersection = null, ho_BigconcaveDefect = null;
            HObject ho_BigconvexeDefect = null, ho_OutContour = null, ho_OutBlackReg = null;
            HObject ho_InnerReg, ho_ImageReduced, ho_Regions2, ho_innerDefect;
            HObject ho_innerDefects, ho_ObjectSelected2 = null, ho_DefectInner = null;
            HObject ho_DefectInners = null, ho_outDefects, ho_outDefect;
            HObject ho_AllDefects, ho_AllDefectsRegions, ho_OutBlackReg_xld;
            HObject ho_Rectangle_xld;

            // Local control variables 

            HTuple hv_Area = new HTuple(), hv_Row = new HTuple();
            HTuple hv_Column = new HTuple(), hv_Indices = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_Row1 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Phi = new HTuple(), hv_Length1 = new HTuple();
            HTuple hv_Length2 = new HTuple(), hv_Row2 = new HTuple();
            HTuple hv_Column2 = new HTuple(), hv_Radius = new HTuple();
            HTuple hv_Ra = new HTuple(), hv_Rb = new HTuple(), hv_Phi1 = new HTuple();
            HTuple hv_idx = new HTuple(), hv_Area1 = new HTuple();
            HTuple hv_OutDefectCenterRow = new HTuple(), hv_OutDefectCenterCol = new HTuple();
            HTuple hv_Isconcave = new HTuple(), hv_Row3 = new HTuple();
            HTuple hv_Column3 = new HTuple(), hv_Isconvexe = new HTuple();
            HTuple hv_Indices1 = new HTuple(), hv_Indices2 = new HTuple();
            HTuple hv_Area2 = new HTuple(), hv_Row4 = new HTuple();
            HTuple hv_Column4 = new HTuple(), hv_Number = new HTuple();
            HTuple hv_j = new HTuple(), hv_MinDistance = new HTuple();
            HTuple hv_Row11 = new HTuple(), hv_Column11 = new HTuple();
            HTuple hv_DefectHeigh = new HTuple(), hv_DefectWidth = new HTuple();
            HTuple hv_Ratio = new HTuple(), hv_R = new HTuple(), hv_G = new HTuple();
            HTuple hv_B = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_ImageOut_Teach);
            HOperatorSet.GenEmptyObj(out ho_Teach_Contour);
            HOperatorSet.GenEmptyObj(out ho_GrayImage);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_OutReg);
            HOperatorSet.GenEmptyObj(out ho_RegionDilation);
            HOperatorSet.GenEmptyObj(out ho_RealconcaveDefect);
            HOperatorSet.GenEmptyObj(out ho_RealconvexeDefect);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_RegionOpening);
            HOperatorSet.GenEmptyObj(out ho_RegionClosing);
            HOperatorSet.GenEmptyObj(out ho_RegionDifference);
            HOperatorSet.GenEmptyObj(out ho_convexeDefectReg);
            HOperatorSet.GenEmptyObj(out ho_concaveDefectReg);
            HOperatorSet.GenEmptyObj(out ho_RegionUnion);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_OutDefect);
            HOperatorSet.GenEmptyObj(out ho_concaveDefect);
            HOperatorSet.GenEmptyObj(out ho_convexeDefect);
            HOperatorSet.GenEmptyObj(out ho_CenterRegion);
            HOperatorSet.GenEmptyObj(out ho_concaveIntersection);
            HOperatorSet.GenEmptyObj(out ho_convexeIntersection);
            HOperatorSet.GenEmptyObj(out ho_BigconcaveDefect);
            HOperatorSet.GenEmptyObj(out ho_BigconvexeDefect);
            HOperatorSet.GenEmptyObj(out ho_OutContour);
            HOperatorSet.GenEmptyObj(out ho_OutBlackReg);
            HOperatorSet.GenEmptyObj(out ho_InnerReg);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_Regions2);
            HOperatorSet.GenEmptyObj(out ho_innerDefect);
            HOperatorSet.GenEmptyObj(out ho_innerDefects);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected2);
            HOperatorSet.GenEmptyObj(out ho_DefectInner);
            HOperatorSet.GenEmptyObj(out ho_DefectInners);
            HOperatorSet.GenEmptyObj(out ho_outDefects);
            HOperatorSet.GenEmptyObj(out ho_outDefect);
            HOperatorSet.GenEmptyObj(out ho_AllDefects);
            HOperatorSet.GenEmptyObj(out ho_AllDefectsRegions);
            HOperatorSet.GenEmptyObj(out ho_OutBlackReg_xld);
            HOperatorSet.GenEmptyObj(out ho_Rectangle_xld);
            hv_DefectNumber = new HTuple();
            hv_DefectRow1 = new HTuple();
            hv_DefectCol1 = new HTuple();
            hv_DefectRow2 = new HTuple();
            hv_DefectCol2 = new HTuple();
            try
            {
                //20230526  v2.0 計算U曹口內外缺陷，透過最外圍輪廓當作內、外基準線，抓取差異缺陷
                //2023/05/30 v2.1 輸出teach用的影像 (顯示ROI框線
                ho_GrayImage.Dispose();
                HOperatorSet.Rgb1ToGray(ho_Image, out ho_GrayImage);

                ho_Regions.Dispose();
                HOperatorSet.Threshold(ho_GrayImage, out ho_Regions, hv_BackWhiteMinGray, 255);
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions, out hv_Area, out hv_Row, out hv_Column);
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area, out hv_Indices);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_OutReg.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions, out ho_OutReg, (hv_Indices.TupleSelect(
                        (new HTuple(hv_Indices.TupleLength())) - 1)) + 1);
                }
                ho_RegionDilation.Dispose();
                HOperatorSet.DilationCircle(ho_OutReg, out ho_RegionDilation, 37);
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_GrayImage, out hv_Width, out hv_Height);
                ho_RealconcaveDefect.Dispose();
                HOperatorSet.GenEmptyObj(out ho_RealconcaveDefect);
                ho_RealconvexeDefect.Dispose();
                HOperatorSet.GenEmptyObj(out ho_RealconvexeDefect);



                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle, hv_NotchVwRow1, 0, hv_NotchVwRow2,
                    hv_Width);



                //--平滑外面的輪廓
                ho_RegionOpening.Dispose();
                HOperatorSet.OpeningCircle(ho_OutReg, out ho_RegionOpening, 40);
                ho_RegionClosing.Dispose();
                HOperatorSet.ClosingCircle(ho_OutReg, out ho_RegionClosing, 40);
                ho_RegionDifference.Dispose();
                HOperatorSet.Difference(ho_RegionClosing, ho_RegionOpening, out ho_RegionDifference
                    );
                ho_convexeDefectReg.Dispose();
                HOperatorSet.Difference(ho_RegionDifference, ho_OutReg, out ho_convexeDefectReg
                    );
                //---凹缺
                ho_concaveDefectReg.Dispose();
                HOperatorSet.Difference(ho_OutReg, ho_RegionOpening, out ho_concaveDefectReg
                    );


                ho_RegionUnion.Dispose();
                HOperatorSet.Union2(ho_convexeDefectReg, ho_concaveDefectReg, out ho_RegionUnion
                    );
                ho_ConnectedRegions1.Dispose();
                HOperatorSet.Connection(ho_RegionUnion, out ho_ConnectedRegions1);
                hv_Row1.Dispose(); hv_Column1.Dispose(); hv_Phi.Dispose(); hv_Length1.Dispose(); hv_Length2.Dispose();
                HOperatorSet.SmallestRectangle2(ho_ConnectedRegions1, out hv_Row1, out hv_Column1,
                    out hv_Phi, out hv_Length1, out hv_Length2);
                hv_Row2.Dispose(); hv_Column2.Dispose(); hv_Radius.Dispose();
                HOperatorSet.InnerCircle(ho_ConnectedRegions1, out hv_Row2, out hv_Column2,
                    out hv_Radius);

                hv_Ra.Dispose(); hv_Rb.Dispose(); hv_Phi1.Dispose();
                HOperatorSet.EllipticAxis(ho_ConnectedRegions1, out hv_Ra, out hv_Rb, out hv_Phi1);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_idx.Dispose();
                    HOperatorSet.TupleFind((new HTuple(((hv_Length2.TupleGreaterEqualElem(hv_OutDefectMinWidth / 2.0))).TupleAnd(
                        hv_Row1.TupleGreaterEqualElem(hv_NotchVwRow1)))).TupleAnd(hv_Row1.TupleLessEqualElem(
                        hv_NotchVwRow2)), 1, out hv_idx);
                }
                if ((int)(new HTuple(hv_idx.TupleNotEqual(-1))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_OutDefect.Dispose();
                        HOperatorSet.SelectObj(ho_ConnectedRegions1, out ho_OutDefect, hv_idx + 1);
                    }
                    hv_Area1.Dispose(); hv_OutDefectCenterRow.Dispose(); hv_OutDefectCenterCol.Dispose();
                    HOperatorSet.AreaCenter(ho_OutDefect, out hv_Area1, out hv_OutDefectCenterRow,
                        out hv_OutDefectCenterCol);
                    //-外部輪廓有缺陷找-正常輪廓線---
                    ho_concaveDefect.Dispose();
                    HOperatorSet.Intersection(ho_OutDefect, ho_concaveDefectReg, out ho_concaveDefect
                        );
                    ho_convexeDefect.Dispose();
                    HOperatorSet.Intersection(ho_OutDefect, ho_convexeDefectReg, out ho_convexeDefect
                        );

                    ho_CenterRegion.Dispose();
                    HOperatorSet.GenRegionPoints(out ho_CenterRegion, hv_OutDefectCenterRow,
                        hv_OutDefectCenterCol);

                    ho_concaveIntersection.Dispose();
                    HOperatorSet.Intersection(ho_concaveDefect, ho_CenterRegion, out ho_concaveIntersection
                        );
                    ho_convexeIntersection.Dispose();
                    HOperatorSet.Intersection(ho_convexeDefect, ho_CenterRegion, out ho_convexeIntersection
                        );

                    hv_Isconcave.Dispose(); hv_Row3.Dispose(); hv_Column3.Dispose();
                    HOperatorSet.AreaCenter(ho_concaveIntersection, out hv_Isconcave, out hv_Row3,
                        out hv_Column3);
                    hv_Isconvexe.Dispose(); hv_Row3.Dispose(); hv_Column3.Dispose();
                    HOperatorSet.AreaCenter(ho_convexeIntersection, out hv_Isconvexe, out hv_Row3,
                        out hv_Column3);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Indices1.Dispose();
                        HOperatorSet.TupleFind(hv_Isconcave.TupleEqualElem(1), 1, out hv_Indices1);
                    }
                    ho_RealconcaveDefect.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_RealconcaveDefect);
                    ho_BigconcaveDefect.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_BigconcaveDefect);
                    if ((int)(new HTuple(hv_Indices1.TupleNotEqual(-1))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_RealconcaveDefect.Dispose();
                            HOperatorSet.SelectObj(ho_concaveDefect, out ho_RealconcaveDefect, hv_Indices1 + 1);
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_BigconcaveDefect.Dispose();
                            HOperatorSet.SelectObj(ho_OutDefect, out ho_BigconcaveDefect, hv_Indices1 + 1);
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Indices2.Dispose();
                        HOperatorSet.TupleFind(hv_Isconvexe.TupleEqualElem(1), 1, out hv_Indices2);
                    }
                    ho_RealconvexeDefect.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_RealconvexeDefect);
                    ho_BigconvexeDefect.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_BigconvexeDefect);

                    if ((int)(new HTuple(hv_Indices2.TupleNotEqual(-1))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_RealconvexeDefect.Dispose();
                            HOperatorSet.SelectObj(ho_convexeDefect, out ho_RealconvexeDefect, hv_Indices2 + 1);
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_BigconvexeDefect.Dispose();
                            HOperatorSet.SelectObj(ho_OutDefect, out ho_BigconvexeDefect, hv_Indices2 + 1);
                        }
                    }

                    //--抓取輪廓
                    ho_OutContour.Dispose();
                    HOperatorSet.Difference(ho_OutReg, ho_BigconcaveDefect, out ho_OutContour
                        );
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.Union2(ho_OutContour, ho_BigconvexeDefect, out ExpTmpOutVar_0
                            );
                        ho_OutContour.Dispose();
                        ho_OutContour = ExpTmpOutVar_0;
                    }
                    //--內輪廓

                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_OutBlackReg.Dispose();
                        HOperatorSet.DilationCircle(ho_OutContour, out ho_OutBlackReg, hv_NotchBlackWidth / 2.0);
                    }
                }
                else
                {
                    //外部輪廓沒有缺陷
                    ho_OutContour.Dispose();
                    ho_OutContour = new HObject(ho_OutReg);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_OutBlackReg.Dispose();
                        HOperatorSet.DilationCircle(ho_OutContour, out ho_OutBlackReg, hv_NotchBlackWidth / 2.0);
                    }

                }



                //--計算內部黑缺
                ho_InnerReg.Dispose();
                HOperatorSet.Difference(ho_Rectangle, ho_OutBlackReg, out ho_InnerReg);
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_GrayImage, ho_InnerReg, out ho_ImageReduced);
                //--面內黑缺陷
                ho_Regions2.Dispose();
                HOperatorSet.Threshold(ho_ImageReduced, out ho_Regions2, 0, hv_innerDefectMaxGray);
                hv_Area2.Dispose(); hv_Row4.Dispose(); hv_Column4.Dispose();
                HOperatorSet.AreaCenter(ho_Regions2, out hv_Area2, out hv_Row4, out hv_Column4);
                ho_innerDefect.Dispose();
                HOperatorSet.GenEmptyObj(out ho_innerDefect);
                ho_innerDefects.Dispose();
                HOperatorSet.GenEmptyObj(out ho_innerDefects);

                if ((int)(new HTuple(hv_Area2.TupleNotEqual(0))) != 0)
                {
                    ho_ConnectedRegions1.Dispose();
                    HOperatorSet.Connection(ho_Regions2, out ho_ConnectedRegions1);
                    hv_Number.Dispose();
                    HOperatorSet.CountObj(ho_ConnectedRegions1, out hv_Number);
                    //InnerInspectRegion := InnerReg
                    HTuple end_val94 = hv_Number - 1;
                    HTuple step_val94 = 1;
                    for (hv_j = 0; hv_j.Continue(end_val94, step_val94); hv_j = hv_j.TupleAdd(step_val94))
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_ObjectSelected2.Dispose();
                            HOperatorSet.SelectObj(ho_ConnectedRegions1, out ho_ObjectSelected2, hv_j + 1);
                        }
                        hv_MinDistance.Dispose(); hv_Row11.Dispose(); hv_Column11.Dispose(); hv_Row2.Dispose(); hv_Column2.Dispose();
                        HOperatorSet.DistanceRrMin(ho_ObjectSelected2, ho_OutBlackReg, out hv_MinDistance,
                            out hv_Row11, out hv_Column11, out hv_Row2, out hv_Column2);
                        if ((int)(new HTuple(hv_MinDistance.TupleLessEqual(1))) != 0)
                        {
                            {
                                HObject ExpTmpOutVar_0;
                                HOperatorSet.ConcatObj(ho_innerDefect, ho_ObjectSelected2, out ExpTmpOutVar_0
                                    );
                                ho_innerDefect.Dispose();
                                ho_innerDefect = ExpTmpOutVar_0;
                            }
                        }
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.Union1(ho_innerDefect, out ExpTmpOutVar_0);
                        ho_innerDefect.Dispose();
                        ho_innerDefect = ExpTmpOutVar_0;
                    }
                    ho_DefectInner.Dispose();
                    HOperatorSet.OpeningCircle(ho_innerDefect, out ho_DefectInner, 1);
                    ho_DefectInners.Dispose();
                    HOperatorSet.Connection(ho_DefectInner, out ho_DefectInners);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        ho_innerDefects.Dispose();
                        HOperatorSet.SelectShape(ho_DefectInners, out ho_innerDefects, "rect2_len2",
                            "and", hv_InnerDefectMinWidth / 2.0, hv_Height);
                    }
                }

                //--靠近面內白缺陷
                //dilation_circle (OutContour, OutContour2, 3.5)
                //difference (OutBlackReg, OutContour2, RegionDifference1)
                //intersection (RegionDifference1, Rectangle, BlackBevel)
                //reduce_domain (GrayImage, BlackBevel, ImageReduced1)
                //binary_threshold (ImageReduced1, Region, 'max_separability', 'light', UsedThreshold)
                //opening_circle (Region, innerDefectWhite, 2.5)
                //connection (innerDefectWhite, innerDefectWhites)
                //select_shape (innerDefectWhites, innerDefectWhites, [ 'rect2_len2'], 'and', [OutDefectMinWidth/2], [Height])




                //--整合所有缺陷
                ho_outDefects.Dispose();
                HOperatorSet.Union2(ho_RealconcaveDefect, ho_RealconvexeDefect, out ho_outDefects
                    );
                ho_outDefect.Dispose();
                HOperatorSet.Union1(ho_outDefects, out ho_outDefect);
                ho_outDefects.Dispose();
                HOperatorSet.Connection(ho_outDefect, out ho_outDefects);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.SelectShape(ho_outDefects, out ExpTmpOutVar_0, "rect2_len2", "and",
                        hv_OutDefectMinWidth / 2, hv_Height);
                    ho_outDefects.Dispose();
                    ho_outDefects = ExpTmpOutVar_0;
                }

                ho_AllDefects.Dispose();
                HOperatorSet.Union2(ho_outDefects, ho_innerDefects, out ho_AllDefects);
                ho_AllDefectsRegions.Dispose();
                HOperatorSet.Connection(ho_AllDefects, out ho_AllDefectsRegions);
                hv_DefectNumber.Dispose();
                HOperatorSet.CountObj(ho_AllDefectsRegions, out hv_DefectNumber);

                hv_DefectHeigh.Dispose(); hv_DefectWidth.Dispose(); hv_Ratio.Dispose();
                HOperatorSet.HeightWidthRatio(ho_AllDefectsRegions, out hv_DefectHeigh, out hv_DefectWidth,
                    out hv_Ratio);
                //area_center (AllDefectsRegions, Area3, DefectRows, DefectCols)
                //輸出all defect 框選座標
                hv_DefectRow1.Dispose(); hv_DefectCol1.Dispose(); hv_DefectRow2.Dispose(); hv_DefectCol2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_AllDefectsRegions, out hv_DefectRow1, out hv_DefectCol1,
                    out hv_DefectRow2, out hv_DefectCol2);

                //***畫上結果
                hv_R.Dispose();
                hv_R = 255;
                hv_G.Dispose();
                hv_G = 0;
                hv_B.Dispose();
                hv_B = 0;
                ho_ImageOut.Dispose();
                DrawRegion(ho_Image, ho_AllDefects, out ho_ImageOut, hv_DisplayDilation, hv_R,
                    hv_G, hv_B);



                //畫上ROI框 這是teach用的
                hv_R.Dispose();
                hv_R = 0;
                hv_G.Dispose();
                hv_G = 255;
                hv_B.Dispose();
                hv_B = 0;

                ho_ImageOut_Teach.Dispose();
                DrawRegion(ho_ImageOut, ho_OutContour, out ho_ImageOut_Teach, hv_DisplayDilation,
                    hv_R, hv_G, hv_B);
                {
                    HObject ExpTmpOutVar_0;
                    DrawRegion(ho_ImageOut_Teach, ho_OutBlackReg, out ExpTmpOutVar_0, hv_DisplayDilation,
                        hv_R, hv_G, hv_B);
                    ho_ImageOut_Teach.Dispose();
                    ho_ImageOut_Teach = ExpTmpOutVar_0;
                }
                hv_R.Dispose();
                hv_R = 255;
                hv_G.Dispose();
                hv_G = 255;
                hv_B.Dispose();
                hv_B = 0;
                {
                    HObject ExpTmpOutVar_0;
                    DrawRegion(ho_ImageOut_Teach, ho_Rectangle, out ExpTmpOutVar_0, hv_DisplayDilation,
                        hv_R, hv_G, hv_B);
                    ho_ImageOut_Teach.Dispose();
                    ho_ImageOut_Teach = ExpTmpOutVar_0;
                }
                ////輸出contour
                ho_Teach_Contour.Dispose();
                HOperatorSet.GenContourRegionXld(ho_OutContour, out ho_Teach_Contour, "border");
                ho_OutBlackReg_xld.Dispose();
                HOperatorSet.GenContourRegionXld(ho_OutBlackReg, out ho_OutBlackReg_xld, "border");
                ho_Rectangle_xld.Dispose();
                HOperatorSet.GenContourRegionXld(ho_Rectangle, out ho_Rectangle_xld, "border");
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_Teach_Contour, ho_OutBlackReg_xld, out ExpTmpOutVar_0
                        );
                    ho_Teach_Contour.Dispose();
                    ho_Teach_Contour = ExpTmpOutVar_0;
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_Teach_Contour, ho_Rectangle_xld, out ExpTmpOutVar_0
                        );
                    ho_Teach_Contour.Dispose();
                    ho_Teach_Contour = ExpTmpOutVar_0;
                }


                //    concaveDefectReg
                //    convexeDefectReg
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "yellow");
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_Rectangle, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_OutContour, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.DispObj(ho_OutBlackReg, HDevWindowStack.GetActive());
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                }
                ho_GrayImage.Dispose();
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_OutReg.Dispose();
                ho_RegionDilation.Dispose();
                ho_RealconcaveDefect.Dispose();
                ho_RealconvexeDefect.Dispose();
                ho_Rectangle.Dispose();
                ho_RegionOpening.Dispose();
                ho_RegionClosing.Dispose();
                ho_RegionDifference.Dispose();
                ho_convexeDefectReg.Dispose();
                ho_concaveDefectReg.Dispose();
                ho_RegionUnion.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_OutDefect.Dispose();
                ho_concaveDefect.Dispose();
                ho_convexeDefect.Dispose();
                ho_CenterRegion.Dispose();
                ho_concaveIntersection.Dispose();
                ho_convexeIntersection.Dispose();
                ho_BigconcaveDefect.Dispose();
                ho_BigconvexeDefect.Dispose();
                ho_OutContour.Dispose();
                ho_OutBlackReg.Dispose();
                ho_InnerReg.Dispose();
                ho_ImageReduced.Dispose();
                ho_Regions2.Dispose();
                ho_innerDefect.Dispose();
                ho_innerDefects.Dispose();
                ho_ObjectSelected2.Dispose();
                ho_DefectInner.Dispose();
                ho_DefectInners.Dispose();
                ho_outDefects.Dispose();
                ho_outDefect.Dispose();
                ho_AllDefects.Dispose();
                ho_AllDefectsRegions.Dispose();
                ho_OutBlackReg_xld.Dispose();
                ho_Rectangle_xld.Dispose();

                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Indices.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Phi.Dispose();
                hv_Length1.Dispose();
                hv_Length2.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Radius.Dispose();
                hv_Ra.Dispose();
                hv_Rb.Dispose();
                hv_Phi1.Dispose();
                hv_idx.Dispose();
                hv_Area1.Dispose();
                hv_OutDefectCenterRow.Dispose();
                hv_OutDefectCenterCol.Dispose();
                hv_Isconcave.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_Isconvexe.Dispose();
                hv_Indices1.Dispose();
                hv_Indices2.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Number.Dispose();
                hv_j.Dispose();
                hv_MinDistance.Dispose();
                hv_Row11.Dispose();
                hv_Column11.Dispose();
                hv_DefectHeigh.Dispose();
                hv_DefectWidth.Dispose();
                hv_Ratio.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_GrayImage.Dispose();
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_OutReg.Dispose();
                ho_RegionDilation.Dispose();
                ho_RealconcaveDefect.Dispose();
                ho_RealconvexeDefect.Dispose();
                ho_Rectangle.Dispose();
                ho_RegionOpening.Dispose();
                ho_RegionClosing.Dispose();
                ho_RegionDifference.Dispose();
                ho_convexeDefectReg.Dispose();
                ho_concaveDefectReg.Dispose();
                ho_RegionUnion.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_OutDefect.Dispose();
                ho_concaveDefect.Dispose();
                ho_convexeDefect.Dispose();
                ho_CenterRegion.Dispose();
                ho_concaveIntersection.Dispose();
                ho_convexeIntersection.Dispose();
                ho_BigconcaveDefect.Dispose();
                ho_BigconvexeDefect.Dispose();
                ho_OutContour.Dispose();
                ho_OutBlackReg.Dispose();
                ho_InnerReg.Dispose();
                ho_ImageReduced.Dispose();
                ho_Regions2.Dispose();
                ho_innerDefect.Dispose();
                ho_innerDefects.Dispose();
                ho_ObjectSelected2.Dispose();
                ho_DefectInner.Dispose();
                ho_DefectInners.Dispose();
                ho_outDefects.Dispose();
                ho_outDefect.Dispose();
                ho_AllDefects.Dispose();
                ho_AllDefectsRegions.Dispose();
                ho_OutBlackReg_xld.Dispose();
                ho_Rectangle_xld.Dispose();

                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Indices.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Phi.Dispose();
                hv_Length1.Dispose();
                hv_Length2.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Radius.Dispose();
                hv_Ra.Dispose();
                hv_Rb.Dispose();
                hv_Phi1.Dispose();
                hv_idx.Dispose();
                hv_Area1.Dispose();
                hv_OutDefectCenterRow.Dispose();
                hv_OutDefectCenterCol.Dispose();
                hv_Isconcave.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_Isconvexe.Dispose();
                hv_Indices1.Dispose();
                hv_Indices2.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Number.Dispose();
                hv_j.Dispose();
                hv_MinDistance.Dispose();
                hv_Row11.Dispose();
                hv_Column11.Dispose();
                hv_DefectHeigh.Dispose();
                hv_DefectWidth.Dispose();
                hv_Ratio.Dispose();
                hv_R.Dispose();
                hv_G.Dispose();
                hv_B.Dispose();

                throw HDevExpDefaultException;
            }
        } //2.1

        #endregion


        #region 檢查圖片
        public static void CheckWaferAndNotchGray(HObject ho_Image, HTuple hv_RoiPercent, out HTuple hv_Mean_L,
            out HTuple hv_Mean_R, out HTuple hv_Mean_T, out HTuple hv_Mean_B, out HTuple hv_RectangleL,
            out HTuple hv_RectangleR, out HTuple hv_RectangleT, out HTuple hv_RectangleB,
            out HTuple hv_Deviation_L, out HTuple hv_Deviation_R, out HTuple hv_Deviation_T,
            out HTuple hv_Deviation_B, out HTuple hv_Min_L, out HTuple hv_Min_R, out HTuple hv_Min_T,
            out HTuple hv_Min_B, out HTuple hv_Max_L, out HTuple hv_Max_R, out HTuple hv_Max_T,
            out HTuple hv_Max_B, out HTuple hv_Contrast_L, out HTuple hv_Contrast_R, out HTuple hv_Contrast_T,
            out HTuple hv_Contrast_B)
        {




            // Local iconic variables 

            HObject ho_Rectangle_Left, ho_Rectangle_Right;
            HObject ho_Rectangle_Top, ho_Rectangle_Bottom;

            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_Range_L = new HTuple(), hv_Range_R = new HTuple();
            HTuple hv_Range_T = new HTuple(), hv_Range_B = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Rectangle_Left);
            HOperatorSet.GenEmptyObj(out ho_Rectangle_Right);
            HOperatorSet.GenEmptyObj(out ho_Rectangle_Top);
            HOperatorSet.GenEmptyObj(out ho_Rectangle_Bottom);
            hv_Mean_L = new HTuple();
            hv_Mean_R = new HTuple();
            hv_Mean_T = new HTuple();
            hv_Mean_B = new HTuple();
            hv_RectangleL = new HTuple();
            hv_RectangleR = new HTuple();
            hv_RectangleT = new HTuple();
            hv_RectangleB = new HTuple();
            hv_Deviation_L = new HTuple();
            hv_Deviation_R = new HTuple();
            hv_Deviation_T = new HTuple();
            hv_Deviation_B = new HTuple();
            hv_Min_L = new HTuple();
            hv_Min_R = new HTuple();
            hv_Min_T = new HTuple();
            hv_Min_B = new HTuple();
            hv_Max_L = new HTuple();
            hv_Max_R = new HTuple();
            hv_Max_T = new HTuple();
            hv_Max_B = new HTuple();
            hv_Contrast_L = new HTuple();
            hv_Contrast_R = new HTuple();
            hv_Contrast_T = new HTuple();
            hv_Contrast_B = new HTuple();
            //v1.0 2023/04/26 檢查notch影像中 做右兩側的灰階平均值 以及Notch中心邊界的灰階對比度

            hv_Width.Dispose(); hv_Height.Dispose();
            HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);

            //畫檢測ROI
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_Rectangle_Left.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle_Left, 0, 0, hv_Height - 1, (hv_Width * hv_RoiPercent) - 1);
            }
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_Rectangle_Right.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle_Right, 0, hv_Width - ((hv_Width * hv_RoiPercent) - 1),
                    hv_Height - 1, hv_Width - 1);
            }
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_Rectangle_Top.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle_Top, 0, 0, (hv_Height * hv_RoiPercent) - 1,
                    hv_Width - 1);
            }
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_Rectangle_Bottom.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle_Bottom, hv_Height - ((hv_Height * hv_RoiPercent) - 1),
                    0, hv_Height - 1, hv_Width - 1);
            }

            //計算區域平均及標準差
            hv_Mean_L.Dispose(); hv_Deviation_L.Dispose();
            HOperatorSet.Intensity(ho_Rectangle_Left, ho_Image, out hv_Mean_L, out hv_Deviation_L);
            hv_Mean_R.Dispose(); hv_Deviation_R.Dispose();
            HOperatorSet.Intensity(ho_Rectangle_Right, ho_Image, out hv_Mean_R, out hv_Deviation_R);
            hv_Mean_T.Dispose(); hv_Deviation_T.Dispose();
            HOperatorSet.Intensity(ho_Rectangle_Top, ho_Image, out hv_Mean_T, out hv_Deviation_T);
            hv_Mean_B.Dispose(); hv_Deviation_B.Dispose();
            HOperatorSet.Intensity(ho_Rectangle_Bottom, ho_Image, out hv_Mean_B, out hv_Deviation_B);

            //mean_image (Image, ImageMean, 10, 10)
            //計算灰階上下限
            hv_Min_L.Dispose(); hv_Max_L.Dispose(); hv_Range_L.Dispose();
            HOperatorSet.MinMaxGray(ho_Rectangle_Left, ho_Image, 0, out hv_Min_L, out hv_Max_L,
                out hv_Range_L);
            hv_Min_R.Dispose(); hv_Max_R.Dispose(); hv_Range_R.Dispose();
            HOperatorSet.MinMaxGray(ho_Rectangle_Right, ho_Image, 0, out hv_Min_R, out hv_Max_R,
                out hv_Range_R);
            hv_Min_T.Dispose(); hv_Max_T.Dispose(); hv_Range_T.Dispose();
            HOperatorSet.MinMaxGray(ho_Rectangle_Top, ho_Image, 0, out hv_Min_T, out hv_Max_T,
                out hv_Range_T);
            hv_Min_B.Dispose(); hv_Max_B.Dispose(); hv_Range_B.Dispose();
            HOperatorSet.MinMaxGray(ho_Rectangle_Bottom, ho_Image, 0, out hv_Min_B, out hv_Max_B,
                out hv_Range_B);

            //計算對比
            hv_Contrast_L.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Contrast_L = (hv_Max_L - hv_Min_L) / (hv_Min_L + hv_Max_L);
            }
            hv_Contrast_R.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Contrast_R = (hv_Max_R - hv_Min_R) / (hv_Min_R + hv_Max_R);
            }
            hv_Contrast_T.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Contrast_T = (hv_Max_T - hv_Min_T) / (hv_Min_T + hv_Max_T);
            }
            hv_Contrast_B.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Contrast_B = (hv_Max_B - hv_Min_B) / (hv_Min_B + hv_Max_B);
            }

            //ROI框資訊
            hv_RectangleL.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_RectangleL = new HTuple();
                hv_RectangleL[0] = 0;
                hv_RectangleL[1] = 0;
                hv_RectangleL = hv_RectangleL.TupleConcat(hv_Height - 1);
                hv_RectangleL = hv_RectangleL.TupleConcat((hv_Width * hv_RoiPercent) - 1);
            }
            hv_RectangleR.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_RectangleR = new HTuple();
                hv_RectangleR[0] = 0;
                hv_RectangleR = hv_RectangleR.TupleConcat(hv_Width - ((hv_Width * hv_RoiPercent) - 1));
                hv_RectangleR = hv_RectangleR.TupleConcat(hv_Height - 1);
                hv_RectangleR = hv_RectangleR.TupleConcat(hv_Width - 1);
            }
            hv_RectangleT.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_RectangleT = new HTuple();
                hv_RectangleT[0] = 0;
                hv_RectangleT[1] = 0;
                hv_RectangleT = hv_RectangleT.TupleConcat((hv_Height * hv_RoiPercent) - 1);
                hv_RectangleT = hv_RectangleT.TupleConcat(hv_Width - 1);
            }
            hv_RectangleB.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_RectangleB = new HTuple();
                hv_RectangleB = hv_RectangleB.TupleConcat(hv_Height - ((hv_Height * hv_RoiPercent) - 1));
                hv_RectangleB = hv_RectangleB.TupleConcat(0);
                hv_RectangleB = hv_RectangleB.TupleConcat(hv_Height - 1);
                hv_RectangleB = hv_RectangleB.TupleConcat(hv_Width - 1);
            }

            ho_Rectangle_Left.Dispose();
            ho_Rectangle_Right.Dispose();
            ho_Rectangle_Top.Dispose();
            ho_Rectangle_Bottom.Dispose();

            hv_Width.Dispose();
            hv_Height.Dispose();
            hv_Range_L.Dispose();
            hv_Range_R.Dispose();
            hv_Range_T.Dispose();
            hv_Range_B.Dispose();

            return;
        }


        // Main procedure 


        #endregion

        #region 其他 halcon function
        /// <summary>
        /// 
        /// </summary>
        /// <param name = "ho_Cross">
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_CrossSize">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Row">
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Col">
        /// <para>型態: </para>
        /// </param>
        public static void GenCross(out HObject ho_Cross, HTuple hv_CrossSize, HTuple hv_Row,
            HTuple hv_Col)
        {



            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_Contour2;
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Cross);
            HOperatorSet.GenEmptyObj(out ho_Contour2);
            try
            {
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Cross.Dispose();
                    HOperatorSet.GenContourPolygonXld(out ho_Cross, ((hv_Row - hv_CrossSize)).TupleConcat(
                        hv_Row + hv_CrossSize), hv_Col.TupleConcat(hv_Col));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Contour2.Dispose();
                    HOperatorSet.GenContourPolygonXld(out ho_Contour2, hv_Row.TupleConcat(hv_Row),
                        ((hv_Col - hv_CrossSize)).TupleConcat(hv_Col + hv_CrossSize));
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.ConcatObj(ho_Cross, ho_Contour2, out ExpTmpOutVar_0);
                    ho_Cross.Dispose();
                    ho_Cross = ExpTmpOutVar_0;
                }
                ho_Contour2.Dispose();


                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Contour2.Dispose();


                throw HDevExpDefaultException;
            }
        }
        public static void set_display_font(HTuple hv_WindowHandle, HTuple hv_Size, HTuple hv_Font,
            HTuple hv_Bold, HTuple hv_Slant)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_OS = new HTuple(), hv_Fonts = new HTuple();
            HTuple hv_Style = new HTuple(), hv_Exception = new HTuple();
            HTuple hv_AvailableFonts = new HTuple(), hv_Fdx = new HTuple();
            HTuple hv_Indices = new HTuple();
            HTuple hv_Font_COPY_INP_TMP = new HTuple(hv_Font);
            HTuple hv_Size_COPY_INP_TMP = new HTuple(hv_Size);

            // Initialize local and output iconic variables 
            try
            {
                //This procedure sets the text font of the current window with
                //the specified attributes.
                //
                //Input parameters:
                //WindowHandle: The graphics window for which the font will be set
                //Size: The font size. If Size=-1, the default of 16 is used.
                //Bold: If set to 'true', a bold font is used
                //Slant: If set to 'true', a slanted font is used
                //
                hv_OS.Dispose();
                HOperatorSet.GetSystem("operating_system", out hv_OS);
                if ((int)((new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(new HTuple()))).TupleOr(
                    new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(-1)))) != 0)
                {
                    hv_Size_COPY_INP_TMP.Dispose();
                    hv_Size_COPY_INP_TMP = 16;
                }
                if ((int)(new HTuple(((hv_OS.TupleSubstr(0, 2))).TupleEqual("Win"))) != 0)
                {
                    //Restore previous behaviour
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = ((1.13677 * hv_Size_COPY_INP_TMP)).TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                else
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = hv_Size_COPY_INP_TMP.TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("Courier"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Courier";
                    hv_Fonts[1] = "Courier 10 Pitch";
                    hv_Fonts[2] = "Courier New";
                    hv_Fonts[3] = "CourierNew";
                    hv_Fonts[4] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("mono"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Consolas";
                    hv_Fonts[1] = "Menlo";
                    hv_Fonts[2] = "Courier";
                    hv_Fonts[3] = "Courier 10 Pitch";
                    hv_Fonts[4] = "FreeMono";
                    hv_Fonts[5] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("sans"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Luxi Sans";
                    hv_Fonts[1] = "DejaVu Sans";
                    hv_Fonts[2] = "FreeSans";
                    hv_Fonts[3] = "Arial";
                    hv_Fonts[4] = "Liberation Sans";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("serif"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Times New Roman";
                    hv_Fonts[1] = "Luxi Serif";
                    hv_Fonts[2] = "DejaVu Serif";
                    hv_Fonts[3] = "FreeSerif";
                    hv_Fonts[4] = "Utopia";
                    hv_Fonts[5] = "Liberation Serif";
                }
                else
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple(hv_Font_COPY_INP_TMP);
                }
                hv_Style.Dispose();
                hv_Style = "";
                if ((int)(new HTuple(hv_Bold.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Bold";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Bold.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Bold";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Slant.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Italic";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Slant.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Slant";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Style.TupleEqual(""))) != 0)
                {
                    hv_Style.Dispose();
                    hv_Style = "Normal";
                }
                hv_AvailableFonts.Dispose();
                HOperatorSet.QueryFont(hv_WindowHandle, out hv_AvailableFonts);
                hv_Font_COPY_INP_TMP.Dispose();
                hv_Font_COPY_INP_TMP = "";
                for (hv_Fdx = 0; (int)hv_Fdx <= (int)((new HTuple(hv_Fonts.TupleLength())) - 1); hv_Fdx = (int)hv_Fdx + 1)
                {
                    hv_Indices.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Indices = hv_AvailableFonts.TupleFind(
                            hv_Fonts.TupleSelect(hv_Fdx));
                    }
                    if ((int)(new HTuple((new HTuple(hv_Indices.TupleLength())).TupleGreater(
                        0))) != 0)
                    {
                        if ((int)(new HTuple(((hv_Indices.TupleSelect(0))).TupleGreaterEqual(0))) != 0)
                        {
                            hv_Font_COPY_INP_TMP.Dispose();
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                hv_Font_COPY_INP_TMP = hv_Fonts.TupleSelect(
                                    hv_Fdx);
                            }
                            break;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual(""))) != 0)
                {
                    throw new HalconException("Wrong value of control parameter Font");
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Font = (((hv_Font_COPY_INP_TMP + "-") + hv_Style) + "-") + hv_Size_COPY_INP_TMP;
                        hv_Font_COPY_INP_TMP.Dispose();
                        hv_Font_COPY_INP_TMP = ExpTmpLocalVar_Font;
                    }
                }
                HOperatorSet.SetFont(hv_WindowHandle, hv_Font_COPY_INP_TMP);

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                throw HDevExpDefaultException;
            }
        }

        // Chapter: XLD / Creation
        // Short Description: Creates an arrow shaped XLD contour. 
        public static void gen_arrow_contour_xld(out HObject ho_Arrow, HTuple hv_Row1, HTuple hv_Column1,
            HTuple hv_Row2, HTuple hv_Column2, HTuple hv_HeadLength, HTuple hv_HeadWidth)
        {



            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_TempArrow = null;

            // Local control variables 

            HTuple hv_Length = new HTuple(), hv_ZeroLengthIndices = new HTuple();
            HTuple hv_DR = new HTuple(), hv_DC = new HTuple(), hv_HalfHeadWidth = new HTuple();
            HTuple hv_RowP1 = new HTuple(), hv_ColP1 = new HTuple();
            HTuple hv_RowP2 = new HTuple(), hv_ColP2 = new HTuple();
            HTuple hv_Index = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Arrow);
            HOperatorSet.GenEmptyObj(out ho_TempArrow);
            try
            {
                //This procedure generates arrow shaped XLD contours,
                //pointing from (Row1, Column1) to (Row2, Column2).
                //If starting and end point are identical, a contour consisting
                //of a single point is returned.
                //
                //input parameteres:
                //Row1, Column1: Coordinates of the arrows' starting points
                //Row2, Column2: Coordinates of the arrows' end points
                //HeadLength, HeadWidth: Size of the arrow heads in pixels
                //
                //output parameter:
                //Arrow: The resulting XLD contour
                //
                //The input tuples Row1, Column1, Row2, and Column2 have to be of
                //the same length.
                //HeadLength and HeadWidth either have to be of the same length as
                //Row1, Column1, Row2, and Column2 or have to be a single element.
                //If one of the above restrictions is violated, an error will occur.
                //
                //
                //Init
                ho_Arrow.Dispose();
                HOperatorSet.GenEmptyObj(out ho_Arrow);
                //
                //Calculate the arrow length
                hv_Length.Dispose();
                HOperatorSet.DistancePp(hv_Row1, hv_Column1, hv_Row2, hv_Column2, out hv_Length);
                //
                //Mark arrows with identical start and end point
                //(set Length to -1 to avoid division-by-zero exception)
                hv_ZeroLengthIndices.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ZeroLengthIndices = hv_Length.TupleFind(
                        0);
                }
                if ((int)(new HTuple(hv_ZeroLengthIndices.TupleNotEqual(-1))) != 0)
                {
                    if (hv_Length == null)
                        hv_Length = new HTuple();
                    hv_Length[hv_ZeroLengthIndices] = -1;
                }
                //
                //Calculate auxiliary variables.
                hv_DR.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_DR = (1.0 * (hv_Row2 - hv_Row1)) / hv_Length;
                }
                hv_DC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_DC = (1.0 * (hv_Column2 - hv_Column1)) / hv_Length;
                }
                hv_HalfHeadWidth.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_HalfHeadWidth = hv_HeadWidth / 2.0;
                }
                //
                //Calculate end points of the arrow head.
                hv_RowP1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RowP1 = (hv_Row1 + ((hv_Length - hv_HeadLength) * hv_DR)) + (hv_HalfHeadWidth * hv_DC);
                }
                hv_ColP1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ColP1 = (hv_Column1 + ((hv_Length - hv_HeadLength) * hv_DC)) - (hv_HalfHeadWidth * hv_DR);
                }
                hv_RowP2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RowP2 = (hv_Row1 + ((hv_Length - hv_HeadLength) * hv_DR)) - (hv_HalfHeadWidth * hv_DC);
                }
                hv_ColP2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ColP2 = (hv_Column1 + ((hv_Length - hv_HeadLength) * hv_DC)) + (hv_HalfHeadWidth * hv_DR);
                }
                //
                //Finally create output XLD contour for each input point pair
                for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_Length.TupleLength())) - 1); hv_Index = (int)hv_Index + 1)
                {
                    if ((int)(new HTuple(((hv_Length.TupleSelect(hv_Index))).TupleEqual(-1))) != 0)
                    {
                        //Create_ single points for arrows with identical start and end point
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_TempArrow.Dispose();
                            HOperatorSet.GenContourPolygonXld(out ho_TempArrow, hv_Row1.TupleSelect(
                                hv_Index), hv_Column1.TupleSelect(hv_Index));
                        }
                    }
                    else
                    {
                        //Create arrow contour
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_TempArrow.Dispose();
                            HOperatorSet.GenContourPolygonXld(out ho_TempArrow, ((((((((((hv_Row1.TupleSelect(
                                hv_Index))).TupleConcat(hv_Row2.TupleSelect(hv_Index)))).TupleConcat(
                                hv_RowP1.TupleSelect(hv_Index)))).TupleConcat(hv_Row2.TupleSelect(hv_Index)))).TupleConcat(
                                hv_RowP2.TupleSelect(hv_Index)))).TupleConcat(hv_Row2.TupleSelect(hv_Index)),
                                ((((((((((hv_Column1.TupleSelect(hv_Index))).TupleConcat(hv_Column2.TupleSelect(
                                hv_Index)))).TupleConcat(hv_ColP1.TupleSelect(hv_Index)))).TupleConcat(
                                hv_Column2.TupleSelect(hv_Index)))).TupleConcat(hv_ColP2.TupleSelect(
                                hv_Index)))).TupleConcat(hv_Column2.TupleSelect(hv_Index)));
                        }
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.ConcatObj(ho_Arrow, ho_TempArrow, out ExpTmpOutVar_0);
                        ho_Arrow.Dispose();
                        ho_Arrow = ExpTmpOutVar_0;
                    }
                }
                ho_TempArrow.Dispose();

                hv_Length.Dispose();
                hv_ZeroLengthIndices.Dispose();
                hv_DR.Dispose();
                hv_DC.Dispose();
                hv_HalfHeadWidth.Dispose();
                hv_RowP1.Dispose();
                hv_ColP1.Dispose();
                hv_RowP2.Dispose();
                hv_ColP2.Dispose();
                hv_Index.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_TempArrow.Dispose();

                hv_Length.Dispose();
                hv_ZeroLengthIndices.Dispose();
                hv_DR.Dispose();
                hv_DC.Dispose();
                hv_HalfHeadWidth.Dispose();
                hv_RowP1.Dispose();
                hv_ColP1.Dispose();
                hv_RowP2.Dispose();
                hv_ColP2.Dispose();
                hv_Index.Dispose();

                throw HDevExpDefaultException;
            }
        }
        #endregion

    }

}
