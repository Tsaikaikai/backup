from recorder import DiskClean
from time import sleep

dc = DiskClean.DiskClean('Beta_3_1')
dc.start()

sleep(1)

dc.stop()
