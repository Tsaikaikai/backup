#!/usr/bin/env python3

from time import sleep
from math import sin, cos, degrees, radians, atan2, exp, pi, copysign
from os.path import join, isfile, isdir
from threading import Thread, Event
from yaml import load, FullLoader
from navigation.StopWatch import StopWatch
import sys
from utility.RobotConfig import RobotData, RobotState, CleanMode


class ZigzagShapedClean(Thread):
    def __init__(self, _robotType=""):
        Thread.__init__(self)
        self.finished = Event()
        self.navMessage = None
        self.print_message(3, 'Initial new navigation')

        # -----Sensors----- #
        self.sensor = None
        self.sensorForward = False
        self.sensorBackward = False
        self.imu = None  # [roll, pitch, yaw]
        self.SOC = -2
        self.mileage = 0

        # -----Command velocity----- #
        self.linear = 0.0
        self.angular = 0.0
        self.smoothLinear = 0.0
        self.smoothAngular = 0.0

        # -----Flags and params----- #
        self.loadConfigStatus = False
        self.configPath = join('../config', _robotType)
        self.statusFlag = 'INITIAL'
        self.robotState = 0
        self.navState = 0
        self.robotFront = 'RIGHT'
        self.detectEdge = 0
        self.initialYaw = 0.0
        self.rightLimitYaw = -90.0
        self.leftLimitYaw = 90.0
        self.reverseLimitYaw = 180.0
        self.errFlag = False
        self.finishFlag = False
        self.edgeClean = 1
        self.detectCliffMileage = 0.0
        self.detectCliffLinear = 0.0
        self.detectCliffAngular = 0.0
        self.detectCliffFlag = False
        self.cleanArea = 0
        self.stopTuneCount = 0
        self.cleanAreaMileage = 0.0
        self.slipIMUCorrectionMileage = 0.0
        self.slipCameraCorrectionMileage = 0.0
        self.tuneInitialPoseCAND = [0, 0, 0]
        self.currentYaw = 0
        self.currentYawBias = 0
        self.detectPoseCount = 0
        self.slipCameraCorrectionCount = 0
        self.slipIMUCorrectionCount = 0
        self.lockCameraCount = 0
        self.detectSideMode = 0
        self.maxSlope = 0
        self.currentRow = 0
        self.brushOverlap = 1
        self.cameraFrameNumber = 0
        self.cameraStatus = 0
        self.cameraAngle = 0
        self.cameraLocation = 0
        self.prevCameraLocation = 0
        self.cameraLocationList = []
        self.cameraFrameNumberList = []
        self.missFrameNumberList = []
        self.slipLocationList = []
        self.slipFrameNumberList = []
        self.initialLocation = 270
        self.cameraDirection = 0
        self.navigation = RobotData().data['navigation']
        self.cameraAbnormalCount = 0
        self.cameraAbnormalFlag = False

        # -----navigation settings---- #
        self.cleanMode = 0  # 0: Up side to down side from left-top 1:  Up side to down side from right-top
        self.prevCleanMode = 0
        self.navFlag = False
        self.connectFlag = False
        self.cancelFlag = False
        self.loopFlag = False
        self.cleanCount = 1
        self.cleanCountNow = 0
        self.errorCode = 0
        self.errorCount = 0
        self.cleanSpeed = 0.4
        self.speedTestLinear = 0.0
        self.speedTestAngular = 0.0
        self.speedTestDistance = 0.0
        self.speedTestTimer = 0.0
        self.StopWatchThread = None

        # -----moving parameter---- #
        self.rotationSpeed = 0.5  # turn right/left angular
        self.forwardSpeed = 0.4  # forward and backward linear
        self.tuneRotationSpeed = 0.1
        self.tuneForwardSpeed = 0.1
        self.zigzagRotationSpeed = 0.5
        self.zigzagForwardSpeed = 0.05
        self.rturnRotationSpeed = 0.36
        self.rturnForwardSpeed = 0.06
        self.tuneDistance = 0.15  # tune pose forward distance
        self.lowPowerThreshold = 20
        self.cameraAbnormalThreshold = 15
        self.brushLength = 0.89
        self.carHeight = 1.22
        self.accDistanceRange = 0.1
        self.accAngleRange = 12
        self.accDecreaseRatio = 2.5
        self.accFlexible = 4
        self.tuneInitialPoseTolerance = 10
        self.weelRadius = 0.064
        self.weelBase = 0.614
        self.gearRatio = 30
        self.maxRow = -1
        self.minRow = -1
        self.slipCorrectionInterval = 3.25
        self.slipCorrectionAngle = 3
        self.slipMode = 2
        self.cameraLocationThreshold = 80
        self.tuneMode = 0
        self.corrugatedMode = 0
        self.zigzagAngle = 35
        self.zigzagOddDistanceRatio = 1.25
        self.zigzagEvenDistanceRatio = 1.25

    def init_params(self):
        self.statusFlag = 'INITIAL'
        self.robotState = 0
        self.robotFront = 'RIGHT'
        self.detectEdge = 0
        self.reset_detect_cliff_params(False)
        self.cleanArea = 0
        self.brushOverlap = 1
        self.cameraAbnormalCount = 0
        self.cameraAbnormalFlag = False

    def run(self):
        self.load_config()
        if self.loadConfigStatus:
            while not self.finished.is_set():
                if self.navFlag and not self.finishFlag:
                    self.init_params()
                    if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                        self.print_message(3, 'Start left-top navigation')
                        self.robotState = RobotState.LEFT_TOP_NAVIGATION.value
                        self.prevCleanMode = 0
                        self.up_side_to_down_side_mode()
                    elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                        self.print_message(3, 'Start right-top navigation')
                        self.robotState = RobotState.RIGHT_TOP_NAVIGATION.value
                        self.prevCleanMode = 1
                        self.up_side_to_down_side_mode()
                    elif self.cleanMode == CleanMode.RETURN.value:
                        self.print_message(3, 'Start return')
                        self.robotState = RobotState.RETURN.value
                        self.return_mode()
                    elif self.cleanMode == CleanMode.SPEED_TEST.value:
                        self.print_message(3, 'Start speed test')
                        self.robotState = RobotState.SPEED_TEST.value
                        self.speed_test_mode()
                    elif self.cleanMode == CleanMode.RA_TEST.value:
                        self.print_message(3, 'Start RA test')
                        self.robotState = RobotState.RA_TEST.value
                        self.ra_test_mode()
                    elif self.cleanMode == CleanMode.MOTOR_TEST.value:
                        self.print_message(3, 'Start motor test')
                        self.robotState = RobotState.MOTOR_TEST.value
                        self.motor_test_mode()
                else:
                    self.errFlag = False
                    self.statusFlag = 'REMOTE'
                    if not self.connectFlag:
                        self.robotState = RobotState.ABNORMAL.value
                    elif self.SOC <= self.lowPowerThreshold and self.SOC >= 0:
                        self.robotState = RobotState.LOW_BATTERY_ABNORMAL.value
                    elif self.cameraAbnormalFlag:
                        self.robotState = RobotState.CAMERA_ABNORMAL.value
                    else:
                        self.robotState = RobotState.REMOTE.value
                    if not self.navFlag:
                        self.finishFlag = False
                        self.cleanArea = 0
                        self.cleanCountNow = 0
                    if self.errorCode != 0:
                        self.errorCount += 1
                        if self.errorCount > 500:
                            self.errorCode = 0
                            self.errorCount = 0
                sleep(0.01)

    def stop(self):
        self.finished.set()
        self.print_message(3, 'Shutdown navigation')

    def up_side_to_down_side_mode(self):
        while not self.finished.is_set() and self.navFlag and not self.finishFlag:
            if self.statusFlag == 'INITIAL':  # initial pose
                self.print_message(4, 'Go standby point')
                self.initial_pose()
                if self.corrugatedMode == 0:
                    self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                    self.tune_initial_pose('FORWARD', 'UP', False)
                elif self.corrugatedMode == 1:
                    self.move_robot_until_cliff('FORWARD_FIRST', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                    self.tune_initial_pose('FORWARD_FIRST', 'UP', False)
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.turn_robot_fix_angle(5, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw-65)
                    self.turn_robot_fix_angle(5, self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw)
                    self.robotFront = 'RIGHT'
                if self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.turn_robot_fix_angle(5, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw+65)
                    self.turn_robot_fix_angle(5, self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw)
                    self.robotFront = 'LEFT'
                self.statusFlag = 'INITIAL_LINE'
                self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                self.statusFlag = 'INITIAL'
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'LEFT', True)
                    self.move_robot_close_cliff(self.cleanMode)
                    self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.leftLimitYaw)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'RIGHT', True)
                    self.move_robot_close_cliff(self.cleanMode)
                    self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.rightLimitYaw)

                self.statusFlag = 'FORWARD'

            elif self.statusFlag == 'FORWARD':  # go forward
                self.print_message(4, 'Forward')
                if self.detectEdge <= self.edgeClean and self.currentRow != self.maxRow:
                    self.statusFlag = 'FORWARD_LINE'
                    self.currentRow += 1
                    self.cleanAreaMileage = self.mileage
                    if self.currentRow == 1:
                        self.brushOverlap = 1
                    else:
                        self.brushOverlap = 0.5
                    if (self.robotFront == 'RIGHT' and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or (self.robotFront == 'LEFT' and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value):
                        self.move_robot_until_cliff('BACKWARD', -self.forwardSpeed, -self.tuneForwardSpeed)
                    elif (self.robotFront == 'LEFT' and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or (self.robotFront == 'RIGHT' and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value):
                        self.move_robot_until_cliff('FORWARD', self.forwardSpeed, self.tuneForwardSpeed)
                    self.cleanArea += (self.mileage-self.cleanAreaMileage+self.carHeight-self.tuneDistance*2) * self.brushLength * self.brushOverlap
                    self.statusFlag = 'FORWARD'
                if (self.detectEdge >= self.edgeClean or self.currentRow == self.maxRow):
                    if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.robotFront == 'RIGHT') or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.robotFront == 'LEFT'):
                        if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.robotFront == 'RIGHT'):
                            self.robotFront = 'LEFT'
                            self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.leftLimitYaw)
                        elif (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.robotFront == 'LEFT'):
                            self.robotFront = 'RIGHT'
                            self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.rightLimitYaw)
                        self.statusFlag = 'FINISH_LINE'
                        self.move_robot_until_cliff('FORWARD', self.forwardSpeed, self.tuneForwardSpeed)
                    self.statusFlag = 'FINISH'
                    if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                        self.tune_initial_pose('FORWARD', 'LEFT', False)
                    elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                        self.tune_initial_pose('FORWARD', 'RIGHT', False)
                    self.move_robot_avoid_cliff(self.cleanMode)
                    if self.corrugatedMode == 0:
                        self.move_robot_until_cliff('BACKWARD', -self.tuneForwardSpeed, -self.tuneForwardSpeed)
                        self.tune_initial_pose('BACKWARD', 'UP', True)
                    elif self.corrugatedMode == 1:
                        self.move_robot_until_cliff('BACKWARD_FIRST', -self.tuneForwardSpeed, -self.tuneForwardSpeed)
                        self.tune_initial_pose('BACKWARD_FIRST', 'UP', True)
                    self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance)
                    break
                else:
                    if self.robotFront == 'RIGHT':
                        self.statusFlag = 'TURN_RIGHT'
                    elif self.robotFront == 'LEFT':
                        self.statusFlag = 'TURN_LEFT'

            elif self.statusFlag == 'TURN_RIGHT':  # turn right
                self.print_message(4, 'Turn right')
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('BACKWARD', 'LEFT', False)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'RIGHT', False)

                tuneAngle = self.zigzagAngle
                if self.currentRow % 2 == 0:
                    tuneDistance = max(0.4 - 0.01*abs(self.maxSlope), 0)*self.zigzagEvenDistanceRatio
                else:
                    tuneDistance = max(0.4 - 0.01*abs(self.maxSlope), 0)*self.zigzagOddDistanceRatio

                _detectEdge = self.detectEdge
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance*2)
                    if self.sensor[0] and self.sensor[7] and self.currentRow > self.minRow:
                        self.detectEdge += 1
                    else:
                        self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw + tuneAngle)
                        if _detectEdge == self.detectEdge:
                            self.angular = 0
                            self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0.0, tuneDistance)
                            self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                        if _detectEdge != self.detectEdge:
                            self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                            while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[0] and self.sensor[1]:
                                self.linear = -self.tuneForwardSpeed
                                self.angular = 0
                                sleep(0.01)
                            self.stop_robot()
                            self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                        if self.detectEdge < self.edgeClean:
                            _detectEdge = self.detectEdge
                            # self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0, self.tuneDistance)
                            if self.sensor[0] and self.sensor[7] and self.currentRow > self.minRow:
                                self.detectEdge += 1
                            else:
                                self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw - tuneAngle)
                                if _detectEdge == self.detectEdge:
                                    self.angular = 0
                                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0.0, tuneDistance)
                                    self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                                if _detectEdge != self.detectEdge:
                                    self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[6] and self.sensor[7]:
                                        self.linear = self.tuneForwardSpeed
                                        self.angular = 0
                                        sleep(0.01)
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(5, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                    self.move_robot_until_cliff('BACKWARD', -self.forwardSpeed*0.5, -self.tuneForwardSpeed)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance*2)
                    if self.sensor[3] and self.sensor[4] and self.currentRow > self.minRow:
                        self.detectEdge += 1
                    else:
                        self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw + tuneAngle)
                        if _detectEdge == self.detectEdge:
                            self.angular = 0
                            self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0.0, tuneDistance)
                            self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                        if _detectEdge != self.detectEdge:
                            self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                            while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[4] and self.sensor[5]:
                                self.linear = self.tuneForwardSpeed
                                self.angular = 0
                                sleep(0.01)
                            self.stop_robot()
                            self.turn_robot_fix_angle(5, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                        if self.detectEdge < self.edgeClean:
                            _detectEdge = self.detectEdge
                            # self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance)
                            if self.sensor[3] and self.sensor[4] and self.currentRow > self.minRow:
                                self.detectEdge += 1
                            else:
                                self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw - tuneAngle)
                                if _detectEdge == self.detectEdge:
                                    self.angular = 0
                                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0.0, tuneDistance)
                                    self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                                if _detectEdge != self.detectEdge:
                                    self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[2] and self.sensor[3]:
                                        self.linear = -self.tuneForwardSpeed
                                        self.angular = 0
                                        sleep(0.01)
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                    self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)

                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('BACKWARD', 'LEFT', True)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'RIGHT', True)

                self.statusFlag = 'FORWARD'
                self.robotFront = 'LEFT'

            elif self.statusFlag == 'TURN_LEFT':  # turn left
                self.print_message(4, 'Turn left')
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'LEFT', False)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('BACKWARD', 'RIGHT', False)

                tuneAngle = self.zigzagAngle
                if self.currentRow % 2 == 0:
                    tuneDistance = max(0.4 - 0.01*abs(self.maxSlope), 0)*self.zigzagEvenDistanceRatio
                else:
                    tuneDistance = max(0.4 - 0.01*abs(self.maxSlope), 0)*self.zigzagOddDistanceRatio

                _detectEdge = self.detectEdge
                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance*2)
                    if self.sensor[0] and self.sensor[7] and self.currentRow > self.minRow:
                        self.detectEdge += 1
                    else:
                        self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw - tuneAngle)
                        if _detectEdge == self.detectEdge:
                            self.angular = 0
                            self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0.0, tuneDistance)
                            self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                        if _detectEdge != self.detectEdge:
                            self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                            while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[6] and self.sensor[7]:
                                self.linear = self.tuneForwardSpeed
                                self.angular = 0
                                sleep(0.01)
                            self.stop_robot()
                            self.turn_robot_fix_angle(5, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                        if self.detectEdge < self.edgeClean:
                            _detectEdge = self.detectEdge
                            # self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance)
                            if self.sensor[0] and self.sensor[7] and self.currentRow > self.minRow:
                                self.detectEdge += 1
                            else:
                                self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw + tuneAngle)
                                if _detectEdge == self.detectEdge:
                                    self.angular = 0
                                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0.0, tuneDistance)
                                    self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                                if _detectEdge != self.detectEdge:
                                    self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[0] and self.sensor[1]:
                                        self.linear = -self.tuneForwardSpeed
                                        self.angular = 0
                                        sleep(0.01)
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
                    self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance*2)
                    if self.sensor[3] and self.sensor[4] and self.currentRow > self.minRow:
                        self.detectEdge += 1
                    else:
                        self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw - tuneAngle)
                        if _detectEdge == self.detectEdge:
                            self.angular = 0
                            self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0.0, tuneDistance)
                            self.turn_robot_fix_angle(4, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                        if _detectEdge != self.detectEdge:
                            self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                            while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[2] and self.sensor[3]:
                                self.linear = -self.tuneForwardSpeed
                                self.angular = 0
                                sleep(0.01)
                            self.stop_robot()
                            self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                        if self.detectEdge < self.edgeClean:
                            _detectEdge = self.detectEdge
                            # self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance)
                            if self.sensor[3] and self.sensor[4] and self.currentRow > self.minRow:
                                self.detectEdge += 1
                            else:
                                self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw + tuneAngle)
                                if _detectEdge == self.detectEdge:
                                    self.angular = 0
                                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0.0, tuneDistance)
                                    self.turn_robot_fix_angle(3, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                                if _detectEdge != self.detectEdge:
                                    self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0, 0.01*abs(self.maxSlope), False)
                                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensor[4] and self.sensor[5]:
                                        self.linear = self.tuneForwardSpeed
                                        self.angular = 0
                                        sleep(0.01)
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(5, self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
                    self.move_robot_until_cliff('BACKWARD', -self.forwardSpeed*0.5, -self.tuneForwardSpeed)

                if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('FORWARD', 'LEFT', True)
                elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
                    self.tune_initial_pose('BACKWARD', 'RIGHT', True)

                self.statusFlag = 'FORWARD'
                self.robotFront = 'RIGHT'

            if self.SOC <= self.lowPowerThreshold and self.SOC >= 0:
                self.robotState = 3
                self.print_message(2, 'Low power, return')
                self.return_mode()
                break
            elif self.cameraAbnormalCount >= self.cameraAbnormalThreshold*100:
                self.cameraAbnormalFlag = True
                self.robotState = 3
                self.print_message(2, 'Camera abnormal, return')
                self.return_mode()
                break

            self.stop_robot()
            sleep(0.01)

        self.cleanCountNow += 1
        if (self.loopFlag or self.cleanCountNow < self.cleanCount) and self.SOC > self.lowPowerThreshold and self.cameraAbnormalCount < self.cameraAbnormalThreshold*100 and self.connectFlag and not self.cancelFlag:
            self.finishFlag = False
        else:
            self.finishFlag = True
        self.print_message(3, 'Stop navigation')

    def speed_test_mode(self):
        self.StopWatchThread = StopWatch()
        self.StopWatchThread.start()
        self.reset_detect_cliff_params(False)
        self.reset_detect_pose_params()
        self.currentYaw = self.get_average_yaw()
        self.statusFlag = 'FORWARD_LINE'

        if self.speedTestDistance == 0:
            if self.speedTestAngular > 0:
                tuneRotationSpeed = self.tuneRotationSpeed
            elif self.speedTestAngular < 0:
                tuneRotationSpeed = -self.tuneRotationSpeed
            else:
                tuneRotationSpeed = 0
            if self.speedTestLinear > 0:
                while not self.finished.is_set() and self.navFlag and not self.finishFlag and sum(self.sensor[0:4]) < 3:
                    self.detect_cliff('FORWARD', self.speedTestLinear, self.tuneForwardSpeed, self.speedTestAngular, tuneRotationSpeed)
                    if self.tuneMode == 0:
                        self.detect_camera_pose('FORWARD')
                    elif self.tuneMode == 1:
                        self.detect_imu_pose('FORWARD')
                    if self.StopWatchThread:
                        if self.StopWatchThread.is_alive():
                            self.speedTestTimer = self.StopWatchThread.duringTime
                    sleep(0.01)
            elif self.speedTestLinear < 0:
                while not self.finished.is_set() and self.navFlag and not self.finishFlag and sum(self.sensor[4:8]) < 3:
                    self.detect_cliff('BACKWARD', self.speedTestLinear, -self.tuneForwardSpeed, self.speedTestAngular, tuneRotationSpeed)
                    if self.tuneMode == 0:
                        self.detect_camera_pose('BACKWARD')
                    elif self.tuneMode == 1:
                        self.detect_imu_pose('BACKWARD')
                    if self.StopWatchThread:
                        if self.StopWatchThread.is_alive():
                            self.speedTestTimer = self.StopWatchThread.duringTime
                    sleep(0.01)
        else:
            if self.speedTestLinear > 0:
                self.move_robot_fix_distance('FORWARD', self.speedTestLinear, self.speedTestAngular, self.speedTestDistance)
            elif self.speedTestLinear < 0:
                self.move_robot_fix_distance('BACKWARD', self.speedTestLinear, self.speedTestAngular, self.speedTestDistance)

        self.speedTestTimer = self.StopWatchThread.stop()
        self.stop_robot()
        self.finishFlag = True
        self.print_message(3, 'Stop speed test')

    def motor_test_mode(self):
        counter = 0
        while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.speedTestLinear != 0 and self.speedTestDistance != 0 and counter < 20:
            self.move_robot_fix_distance('FORWARD', abs(self.speedTestLinear), 0, self.speedTestDistance)
            self.move_robot_fix_distance('BACKWARD', -abs(self.speedTestLinear), 0, self.speedTestDistance)
            counter += 1
        self.stop_robot()
        self.finishFlag = True
        self.print_message(3, 'Stop motor test')

    def return_mode(self):
        self.statusFlag = 'RETURN'
        self.check_initial_pose()
        if self.prevCleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
            self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.leftLimitYaw)
        elif self.prevCleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
            self.turn_robot_fix_angle(5, -self.zigzagForwardSpeed, self.zigzagRotationSpeed, self.rightLimitYaw)
        self.statusFlag = 'FINISH_LINE'
        self.move_robot_until_cliff('FORWARD', self.forwardSpeed*0.5, self.tuneForwardSpeed)
        self.statusFlag = 'RETURN'
        if self.prevCleanMode == CleanMode.LEFT_TOP_NAVIGATION.value:
            self.tune_initial_pose('FORWARD', 'LEFT', False)
        elif self.prevCleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value:
            self.tune_initial_pose('FORWARD', 'RIGHT', False)
        self.move_robot_avoid_cliff(self.prevCleanMode)
        if self.corrugatedMode == 0:
            self.move_robot_until_cliff('BACKWARD', -self.tuneForwardSpeed, -self.tuneForwardSpeed)
            self.tune_initial_pose('BACKWARD', 'UP', True)
        elif self.corrugatedMode == 1:
            self.move_robot_until_cliff('BACKWARD_FIRST', -self.tuneForwardSpeed, -self.tuneForwardSpeed)
            self.tune_initial_pose('BACKWARD_FIRST', 'UP', True)
        self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance)
        self.stop_robot()
        self.finishFlag = True
        self.print_message(3, 'Stop return')

    def ra_test_mode(self):
        while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.speedTestLinear != 0:
            self.move_robot_until_cliff('FORWARD', abs(self.speedTestLinear), self.tuneForwardSpeed, False)
            self.move_robot_until_cliff('BACKWARD', -abs(self.speedTestLinear), -self.tuneForwardSpeed, False)
        self.stop_robot()
        self.finishFlag = True
        self.print_message(3, 'Stop RA Test')

    def load_config(self):
        self.print_message(4, 'Load nav & motor config from yaml')
        navYamlPath = join(self.configPath, 'NavigationSetting.yaml')
        motorYamlPath = join(self.configPath, 'MotorSetting.yaml')
        if not isfile(navYamlPath):
            self.print_message(1, 'Load config error: NavigationSetting.yaml is not exists')
        elif not isfile(motorYamlPath):
            self.print_message(1, 'Load config error: MotorSetting.yaml is not exists')
        else:
            try:
                with open(navYamlPath, "r") as f:
                    navYamlDict = load(f, Loader=FullLoader)
                self.rotationSpeed = navYamlDict['ROTATION_SPEED']
                self.forwardSpeed = navYamlDict['FORWARD_SPEED']
                self.tuneRotationSpeed = navYamlDict['FINE_TUNE_ROTATION_SPEED']
                self.tuneForwardSpeed = navYamlDict['FINE_TUNE_FORWARD_SPEED']
                self.zigzagRotationSpeed = navYamlDict['ZIGZAG_ROTATION_SPEED']
                self.zigzagForwardSpeed = navYamlDict['ZIGZAG_FORWARD_SPEED']
                self.rturnRotationSpeed = navYamlDict['RTURN_ROTATION_SPEED']
                self.rturnForwardSpeed = navYamlDict['RTURN_FORWARD_SPEED']
                self.tuneDistance = navYamlDict['TUNE_DISTANCE']
                self.brushLength = navYamlDict['BRUSH_LENGTH']
                self.carHeight = navYamlDict['CAR_HEIGHT']
                self.accDistanceRange = navYamlDict['ACC_DISTANCE_RANGE']
                self.accAngleRange = navYamlDict['ACC_ANGLE_RANGE']
                self.accDecreaseRatio = navYamlDict['ACC_DECREASE_RATIO']
                self.accFlexible = navYamlDict['ACC_FLEXIBLE']
                self.tuneInitialPoseTolerance = navYamlDict['TUNE_INITIAL_POSE_TOLERANCE']
                self.maxRow = navYamlDict['MAX_ROW']
                self.minRow = navYamlDict['MIN_ROW']
                self.slipCorrectionInterval = navYamlDict['SLIP_CORRECTION_INTERVAL']
                self.slipCorrectionAngle = navYamlDict['SLIP_CORRECTION_ANGLE']
                self.slipMode = navYamlDict['SLIP_MODE']
                self.cameraLocationThreshold = navYamlDict['CAMERA_LOCATION_THRESHOLD']
                self.tuneMode = navYamlDict['TUNE_MODE']
                self.corrugatedMode = navYamlDict['CORRUGATED_MODE']
                self.zigzagAngle = navYamlDict['ZIGZAG_ANGLE']
                self.zigzagOddDistanceRatio = navYamlDict['ZIGZAG_ODD_DISTANCE_RATIO']
                self.zigzagEvenDistanceRatio = navYamlDict['ZIGZAG_EVEN_DISTANCE_RATIO']
                self.lowPowerThreshold = navYamlDict['LOW_POWER_THRESHOLD']
                self.cameraAbnormalThreshold = navYamlDict['CAMERA_ABNORMAL_THRESHOLD']
                with open(motorYamlPath, "r") as f:
                    motorYamlDict = load(f, Loader=FullLoader)
                self.weelRadius = motorYamlDict['WEEL_RADIUS']
                self.weelBase = motorYamlDict['WEEL_BASE']
                self.gearRatio = motorYamlDict['GEAR_RATIO']
                self.loadConfigStatus = True
            except Exception as e:
                self.print_message(1, 'Load config error: ' + str(e))

    def set_robot_status(self, _robotData):
        # set_nav_setting
        self.navFlag = _robotData['main']['navFlag']
        self.connectFlag = _robotData['main']['connectFlag']
        self.cancelFlag = _robotData['main']['cancelFlag']
        self.cleanMode = _robotData['uiCommand']['navSetting']['cleanMode']
        self.forwardSpeed = _robotData['uiCommand']['navSetting']['cleanSpeed']
        self.cleanCount = _robotData['uiCommand']['navSetting']['cleanCount']
        self.speedTestLinear = _robotData['uiCommand']['speedTestSetting']['testLinear']
        self.speedTestAngular = _robotData['uiCommand']['speedTestSetting']['testAngular']
        self.speedTestDistance = _robotData['uiCommand']['speedTestSetting']['testDistance']
        if self.cleanCount == 999:
            self.loopFlag = True
        else:
            self.loopFlag = False
        if (not self.connectFlag or self.cancelFlag) and self.navFlag:
            self.finishFlag = True

        # set_odometry
        self.x, self.y, self.th = _robotData['driveMotor']['odometry']
        self.mileage = _robotData['driveMotor']['mileage']

        # set_sensors
        self.sensor = _robotData['sonar']['cliffState']
        self.sensorForward = _robotData['sonar']['cliffState'][1] or _robotData['sonar']['cliffState'][2]
        self.sensorBackward = _robotData['sonar']['cliffState'][5] or _robotData['sonar']['cliffState'][6]
        self.imu = _robotData['imu']['euler']
        self.SOC = _robotData['battery']['SOC']

        # set_camera
        self.cameraStatus = _robotData['camera']['status']
        self.cameraFrameNumber = _robotData['camera']['frameNumber']
        if self.cameraStatus == 1:
            self.cameraLocation = _robotData['camera']['location']
            self.cameraAngle = _robotData['camera']['angle']
        if self.cameraStatus != 1 and self.tuneMode == 0 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            self.cameraAbnormalCount += 1
        else:
            self.cameraAbnormalCount = 0

    def get_navigation(self):
        self.check_robot_error()
        self.trans_nav_state()
        self.navigation['errorCode'] = self.errorCode
        self.navigation['robotState'] = self.robotState
        self.navigation['navState'] = self.navState
        self.navigation['finishFlag'] = self.finishFlag
        self.navigation['controlVelocity'] = [self.linear, self.angular]
        self.navigation['motorSpeed'] = [self.velocity_to_rpm(self.linear, self.angular)]
        self.navigation['errorCode'] = self.errorCode
        self.navigation['cameraDirection'] = self.cameraDirection
        self.navigation['detectSideMode'] = self.detectSideMode
        self.navigation['slipCameraCorrectionCount'] = self.slipCameraCorrectionCount
        self.navigation['cleanArea'] = self.calc_clean_area()
        self.navigation['cleanCountNow'] = self.cleanCountNow
        self.navigation['initialYaw'] = self.initialYaw
        return self.navigation

    def check_robot_error(self):
        if self.navFlag and ((self.sensor[0] and self.sensor[1] and self.sensor[6] and self.sensor[7]) or (self.sensor[2] and self.sensor[3] and self.sensor[4] and self.sensor[5])) and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            if self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.robotFront == 'LEFT' and sum(self.sensor[0:4]) < 3:
                self.errorCode = 8001
            elif self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.robotFront == 'RIGHT' and sum(self.sensor[4:8]) < 3:
                self.errorCode = 8001
            elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.robotFront == 'LEFT' and sum(self.sensor[4:8]) < 3:
                self.errorCode = 8001
            elif self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.robotFront == 'RIGHT' and sum(self.sensor[0:4]) < 3:
                self.errorCode = 8001
        elif self.errFlag:
            self.errorCode = 8002
        else:
            self.errorCode = 0

    def trans_nav_state(self):
        if self.statusFlag == 'REMOTE':
            self.navState = 0
        elif self.statusFlag == 'INITIAL' or self.statusFlag == 'INITIAL_LINE':
            self.navState = 1
        elif self.statusFlag == 'FORWARD' or self.statusFlag == 'FORWARD_LINE':
            self.navState = 2
        elif self.statusFlag == 'TURN_RIGHT':
            self.navState = 3
        elif self.statusFlag == 'TURN_LEFT':
            self.navState = 4
        elif self.statusFlag == 'FINISH' or self.statusFlag == 'FINISH_LINE':
            self.navState = 5

    def calc_clean_area(self):
        if self.statusFlag == 'FORWARD_LINE':
            cleanArea = self.cleanArea + (self.mileage-self.cleanAreaMileage+self.carHeight-self.tuneDistance*2) * self.brushLength * self.brushOverlap
        else:
            cleanArea = self.cleanArea
        return round(cleanArea, 2)

    def move_robot_until_cliff(self, _movement, _targetLinear, _tuneTargetLinear, _tuneFlag=True):
        while not self.finished.is_set() and self.navFlag and not self.finishFlag and ((_movement == 'FORWARD' and sum(self.sensor[0:4]) < 3) or (_movement == 'BACKWARD' and sum(self.sensor[4:8]) < 3) or (_movement == 'FORWARD_FIRST' and sum(self.sensor[0:4]) < 2) or (_movement == 'BACKWARD_FIRST' and sum(self.sensor[4:8]) < 2)):
            if ((self.SOC <= self.lowPowerThreshold and self.SOC >= 0) or (self.cameraAbnormalCount >= self.cameraAbnormalThreshold*100)) and self.statusFlag == 'FORWARD_LINE':
                break
            self.print_message(4, 'Move robot until cliff')
            self.currentYaw = self.get_average_yaw()
            self.slipIMUCorrectionMileage = self.mileage
            self.currentYawBias = 0
            self.reset_detect_cliff_params(False)
            self.reset_detect_pose_params()
            if _movement == 'FORWARD' or _movement == 'FORWARD_FIRST':
                while not self.finished.is_set() and self.navFlag and not self.finishFlag:
                    if sum(self.sensor[0:4]) > 2 or (_movement == 'FORWARD_FIRST' and sum(self.sensor[0:4]) > 1) or (((self.SOC <= self.lowPowerThreshold and self.SOC >= 0) or (self.cameraAbnormalCount >= self.cameraAbnormalThreshold*100)) and self.statusFlag == 'FORWARD_LINE'):
                        break
                    else:
                        self.detect_cliff(_movement, _targetLinear, _tuneTargetLinear)
                        if _tuneFlag and self.tuneMode == 0:
                            if self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE':
                                self.detect_camera_pose(_movement)
                            else:
                                self.detect_imu_pose(_movement)
                        elif _tuneFlag and self.tuneMode == 1:
                            if self.mileage - self.slipIMUCorrectionMileage > self.slipCorrectionInterval and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE') and self.detectSideMode == 0 and (self.slipMode == 0 or self.slipMode == 2) and self.detectEdge < self.edgeClean and self.currentRow != self.maxRow:
                                if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.sensor[2] and self.sensor[3]) or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.sensor[0] and self.sensor[1]):
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(7, -self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                                    self.slipIMUCorrectionMileage = self.mileage
                                    self.reset_detect_cliff_params(False)
                                    self.reset_detect_pose_params()
                                else:
                                    self.slip_imu_correction(_movement)
                            else:
                                self.detect_imu_pose(_movement)
                    sleep(0.01)
            elif _movement == 'BACKWARD' or _movement == 'BACKWARD_FIRST':
                while not self.finished.is_set() and self.navFlag and not self.finishFlag:
                    if sum(self.sensor[4:8]) > 2 or (_movement == 'BACKWARD_FIRST' and sum(self.sensor[4:8]) > 1) or (((self.SOC <= self.lowPowerThreshold and self.SOC >= 0) or (self.cameraAbnormalCount >= self.cameraAbnormalThreshold*100)) and self.statusFlag == 'FORWARD_LINE'):
                        break
                    else:
                        self.detect_cliff(_movement, _targetLinear, _tuneTargetLinear)
                        if _tuneFlag and self.tuneMode == 0:
                            if self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE':
                                self.detect_camera_pose(_movement)
                            else:
                                self.detect_imu_pose(_movement)
                        elif _tuneFlag and self.tuneMode == 1:
                            if self.mileage - self.slipIMUCorrectionMileage > self.slipCorrectionInterval and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE') and self.detectSideMode == 0 and (self.slipMode == 0 or self.slipMode == 2) and self.detectEdge < self.edgeClean and self.currentRow != self.maxRow:
                                if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and self.sensor[4] and self.sensor[5]) or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and self.sensor[6] and self.sensor[7]):
                                    self.stop_robot()
                                    self.turn_robot_fix_angle(7, self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                                    self.slipIMUCorrectionMileage = self.mileage
                                    self.reset_detect_cliff_params(False)
                                    self.reset_detect_pose_params()
                                else:
                                    self.slip_imu_correction(_movement)
                            else:
                                self.detect_imu_pose(_movement)
                    sleep(0.01)
            self.currentYawBias = 0
            self.cameraDirection = 0
            self.slipCameraCorrectionCount = 0
            self.detectPoseCount = 0
            self.detectSideMode = 0
            self.stop_robot()
            if _tuneFlag:
                self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.currentYaw)

    def move_robot_fix_distance(self, _movement, _targetLinear, _targetAngular, _targetDistance, _stopFlag=True):
        # ----- Move robot specified distance with specified speed ----- #
        if self.navFlag and not self.finishFlag:
            self.print_message(4, 'Move robot fix distance: ' + str(_movement) + ', ' + str(round(_targetDistance, 2)))
            maxLinear = 0
            maxAngular = 0
            smoothLinear = 0
            findDistanceRange = min(abs(_targetDistance)/(self.accDecreaseRatio+1), self.accDistanceRange)
            startMileage = self.mileage
            self.reset_detect_cliff_params(False)
            if _movement == 'FORWARD' or _movement == 'FORWARD_SIDE' or _movement == 'FORWARD_SIDE_SINGLE' or _movement == 'FORWARD_SIDE_IGNORE':
                while not self.finished.is_set() and self.navFlag and not self.finishFlag:
                    if self.mileage < startMileage:
                        startMileage = 0
                    distance = self.mileage - startMileage
                    if distance - _targetDistance > -0.02:
                        break
                    elif sum(self.sensor[0:4]) > 2 or ((_movement == 'FORWARD_SIDE' or _movement == 'FORWARD_SIDE_IGNORE') and ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3]))) or (_movement == 'FORWARD_SIDE_SINGLE' and (self.sensor[0] or self.sensor[3]) and (distance > _targetDistance * 0.3)):
                        self.stop_robot()
                        if sum(self.sensor[0:4]) > 2 or ((_movement == 'FORWARD_SIDE' or _movement == 'FORWARD_SIDE_IGNORE') and ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3]))) or (_movement == 'FORWARD_SIDE_SINGLE' and (self.sensor[0] or self.sensor[3]) and (distance > _targetDistance * 0.3)):
                            break

                    if _movement == 'FORWARD_SIDE_SINGLE' or _movement == 'FORWARD_SIDE_IGNORE':
                        smoothLinear = _targetLinear
                        self.angular = _targetAngular
                    elif abs(distance-_targetDistance) < findDistanceRange*self.accDecreaseRatio:
                        smoothLinear = self.smoothCurve(maxLinear, self.tuneForwardSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        if _targetAngular < 0:
                            self.angular = self.smoothCurve(maxAngular, -self.tuneRotationSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        elif _targetAngular > 0:
                            self.angular = self.smoothCurve(maxAngular, self.tuneRotationSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        else:
                            self.angular = 0
                    else:
                        smoothLinear = self.smoothCurve(self.tuneForwardSpeed, _targetLinear, self.accFlexible, distance, self.accDistanceRange)
                        maxLinear = smoothLinear
                        if _targetAngular < 0:
                            self.angular = self.smoothCurve(-self.tuneRotationSpeed, _targetAngular, self.accFlexible, distance, self.accDistanceRange)
                        elif _targetAngular > 0:
                            self.angular = self.smoothCurve(self.tuneRotationSpeed, _targetAngular, self.accFlexible, distance, self.accDistanceRange)
                        else:
                            self.angular = 0
                        maxAngular = self.angular
                    self.detect_cliff('FORWARD', smoothLinear, self.tuneForwardSpeed)
                    if self.StopWatchThread:
                        if self.StopWatchThread.is_alive():
                            self.speedTestTimer = self.StopWatchThread.duringTime
                    sleep(0.01)
            elif _movement == 'BACKWARD' or _movement == 'BACKWARD_SIDE' or _movement == 'BACKWARD_SIDE_SINGLE' or _movement == 'BACKWARD_SIDE_IGNORE':
                while not self.finished.is_set() and self.navFlag and not self.finishFlag:
                    if self.mileage < startMileage:
                        startMileage = 0
                    distance = self.mileage - startMileage
                    if distance - _targetDistance > -0.02:
                        break
                    elif sum(self.sensor[4:8]) > 2 or ((_movement == 'BACKWARD_SIDE' or _movement == 'BACKWARD_SIDE_IGNORE') and ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7]))) or (_movement == 'BACKWARD_SIDE_SINGLE' and (self.sensor[4] or self.sensor[7]) and (distance > _targetDistance * 0.3)):
                        self.stop_robot()
                        if sum(self.sensor[4:8]) > 2 or ((_movement == 'BACKWARD_SIDE' or _movement == 'BACKWARD_SIDE_IGNORE') and ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7]))) or (_movement == 'BACKWARD_SIDE_SINGLE' and (self.sensor[4] or self.sensor[7]) and (distance > _targetDistance * 0.3)):
                            break

                    if _movement == 'BACKWARD_SIDE_SINGLE' or _movement == 'BACKWARD_SIDE_IGNORE':
                        smoothLinear = _targetLinear
                        self.angular = _targetAngular
                    elif abs(distance-_targetDistance) < findDistanceRange*2:
                        smoothLinear = self.smoothCurve(maxLinear, -self.tuneForwardSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        if _targetAngular < 0:
                            self.angular = self.smoothCurve(maxAngular, -self.tuneRotationSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        elif _targetAngular > 0:
                            self.angular = self.smoothCurve(maxAngular, self.tuneRotationSpeed, self.accFlexible, findDistanceRange * self.accDecreaseRatio-abs(distance-_targetDistance), findDistanceRange*self.accDecreaseRatio)
                        else:
                            self.angular = 0
                    else:
                        smoothLinear = self.smoothCurve(-self.tuneForwardSpeed, _targetLinear, self.accFlexible, distance, self.accDistanceRange)
                        maxLinear = smoothLinear
                        if _targetAngular < 0:
                            self.angular = self.smoothCurve(-self.tuneRotationSpeed, _targetAngular, self.accFlexible, distance, self.accDistanceRange)
                        elif _targetAngular > 0:
                            self.angular = self.smoothCurve(self.tuneRotationSpeed, _targetAngular, self.accFlexible, distance, self.accDistanceRange)
                        else:
                            self.angular = 0
                        maxAngular = self.angular
                    self.detect_cliff('BACKWARD', smoothLinear, -self.tuneForwardSpeed)
                    if self.StopWatchThread:
                        if self.StopWatchThread.is_alive():
                            self.speedTestTimer = self.StopWatchThread.duringTime
                    sleep(0.01)
            if _stopFlag:
                self.stop_robot()

    def turn_robot_fix_angle(self, _turnMode, _targetLinear, _targetAngular, _targetAngle, _stopFlag=True):
        # ----- Turn robot to target angle (stopFlag: 0:non-stop 1:forward 2:backward)----- #
        if self.navFlag and not self.finishFlag:
            self.print_message(4, 'Turn robot fix angle: ' + str(_turnMode) + ', ' + str(round(_targetAngle, 2)))
            maxAngular = 0
            smoothAngular = 0
            smoothLinear = 0
            maxAngle = self.calc_yaw_diff(self.imu[2], _targetAngle, False)
            findAngleRange = min(abs(maxAngle)/(self.accDecreaseRatio+1), self.accAngleRange)
            retryCount = 0
            while not self.finished.is_set() and self.navFlag and not self.finishFlag:
                angle = self.calc_yaw_diff(self.imu[2], _targetAngle, False)
                if retryCount > 20:
                    self.errFlag = True
                    break
                if maxAngle > 0:
                    if angle < 1:
                        if _turnMode == 3 or _turnMode == 4:
                            self.detectEdge = 0
                        break
                    if abs(angle) < findAngleRange*self.accDecreaseRatio:
                        smoothAngular = self.smoothCurve(maxAngular, -self.tuneRotationSpeed, self.accFlexible, findAngleRange * self.accDecreaseRatio-abs(angle), findAngleRange*self.accDecreaseRatio)
                        smoothLinear = _targetLinear * abs(smoothAngular/_targetAngular)
                    else:
                        smoothAngular = -_targetAngular
                        maxAngular = smoothAngular
                        smoothLinear = _targetLinear * abs(smoothAngular/_targetAngular)
                else:
                    if angle > -1:
                        if _turnMode == 3 or _turnMode == 4:
                            self.detectEdge = 0
                        break
                    if abs(angle) < findAngleRange*self.accDecreaseRatio:
                        smoothAngular = self.smoothCurve(maxAngular, self.tuneRotationSpeed, self.accFlexible, findAngleRange * self.accDecreaseRatio-abs(angle), findAngleRange*self.accDecreaseRatio)
                        smoothLinear = _targetLinear * abs(self.angular/_targetAngular)
                    else:
                        smoothAngular = _targetAngular
                        maxAngular = smoothAngular
                        smoothLinear = _targetLinear * abs(smoothAngular/_targetAngular)
                if _turnMode == 1:
                    smoothLinear = _targetLinear
                    if self.sensor[4] and self.sensor[5] or sum(self.sensor[4:8]) > 2:
                        break
                elif _turnMode == 2:
                    smoothLinear = _targetLinear
                    if self.sensor[6] and self.sensor[7] or sum(self.sensor[4:8]) > 2:
                        break
                elif _turnMode == 3:
                    smoothLinear = _targetLinear
                    if ((self.sensor[4] and self.sensor[5] and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value) or (self.sensor[6] and self.sensor[7] and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or sum(self.sensor[4:8]) > 2) and self.currentRow > self.minRow:
                        self.stop_robot()
                        if ((self.sensor[4] and self.sensor[5] and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value) or (self.sensor[6] and self.sensor[7] and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or sum(self.sensor[4:8]) > 2) and self.currentRow > self.minRow:
                            self.detectEdge += 1
                            break
                elif _turnMode == 4:
                    smoothLinear = _targetLinear
                    if ((self.sensor[2] and self.sensor[3] and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value) or (self.sensor[0] and self.sensor[1] and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or sum(self.sensor[0:4]) > 2) and self.currentRow > self.minRow:
                        self.stop_robot()
                        if ((self.sensor[2] and self.sensor[3] and self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value) or (self.sensor[0] and self.sensor[1] and self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value) or sum(self.sensor[0:4]) > 2) and self.currentRow > self.minRow:
                            self.detectEdge += 1
                            break
                elif _turnMode == 5:
                    if (sum(self.sensor[0:4]) > 1 and smoothLinear > 0):
                        self.stop_robot()
                        self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*1.5)
                        retryCount += 1
                    elif (sum(self.sensor[4:8]) > 1 and smoothLinear < 0):
                        self.stop_robot()
                        self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*1.5)
                        retryCount += 1
                    else:
                        smoothLinear = _targetLinear
                elif _turnMode == 6:
                    if (sum(self.sensor[0:4]) > 1 and smoothLinear > 0):
                        self.stop_robot()
                        self.move_robot_fix_distance('BACKWARD_SIDE_SINGLE', -self.forwardSpeed*0.5, 0, self.tuneDistance*1.5)
                        retryCount += 1
                    elif (sum(self.sensor[4:8]) > 1 and smoothLinear < 0):
                        self.stop_robot()
                        self.move_robot_fix_distance('FORWARD_SIDE_SINGLE', self.forwardSpeed*0.5, 0, self.tuneDistance*1.5)
                        retryCount += 1
                    else:
                        smoothLinear = _targetLinear
                elif _turnMode == 7:
                    smoothLinear = _targetLinear
                    smoothAngular = copysign(_targetAngular, smoothAngular)

                if (sum(self.sensor[0:4]) > 2 and smoothLinear > 0) or (sum(self.sensor[4:8]) > 2 and smoothLinear < 0):
                    smoothLinear = 0
                self.linear = smoothLinear
                self.angular = smoothAngular
                sleep(0.01)
            if _stopFlag:
                self.stop_robot()

    def stop_robot(self):
        # ----- Stop robot then deley 0.1 sec----- #
        if self.linear != 0 or self.angular != 0:
            self.angular = 0.0
            self.linear = 0.0
            sleep(0.75)

    def reset_detect_cliff_params(self, _flag):
        # ----- Reset detect_cliff params before move robot----- #
        self.detectCliffMileage = self.mileage
        self.detectCliffLinear = self.linear
        self.detectCliffAngular = self.angular
        self.detectCliffFlag = _flag

    def reset_detect_pose_params(self):
        self.slipCameraCorrectionCount = 0
        self.slipIMUCorrectionCount = 0
        self.detectSideMode = 0
        self.currentYawBias = 0
        self.initialLocation = 270

    def detect_cliff(self, _movement, _forwardSpeed, _tuneForwardSpeed, _rotationSpeed=0, _tuneRotationSpeed=0):
        # ----- Reduce velocity if detect cliff----- #
        if self.navFlag and not self.finishFlag:
            if ((self.sensorForward and _movement == 'FORWARD') or (self.sensorBackward and _movement == 'BACKWARD')) and not self.detectCliffFlag:
                self.reset_detect_cliff_params(True)
            elif ((not self.sensorForward and _movement == 'FORWARD') or (not self.sensorBackward and _movement == 'BACKWARD')) and self.detectCliffFlag:
                self.reset_detect_cliff_params(False)
            else:
                if self.mileage < self.detectCliffMileage:
                    self.detectCliffMileage = 0
                distance = self.mileage - self.detectCliffMileage
                if _forwardSpeed > 0:
                    self.linear = self.smoothCurve(max(self.detectCliffLinear, _tuneForwardSpeed), _forwardSpeed, self.accFlexible, distance, self.accDistanceRange)
                elif _forwardSpeed < 0:
                    self.linear = self.smoothCurve(min(self.detectCliffLinear, _tuneForwardSpeed), _forwardSpeed, self.accFlexible, distance, self.accDistanceRange)
                if _rotationSpeed > 0:
                    self.angular = self.smoothCurve(max(self.detectCliffAngular, _tuneRotationSpeed), _rotationSpeed, self.accFlexible, distance, self.accDistanceRange)
                elif _rotationSpeed < 0:
                    self.angular = self.smoothCurve(min(self.detectCliffAngular, _tuneRotationSpeed), _rotationSpeed, self.accFlexible, distance, self.accDistanceRange)

    def detect_camera_pose(self, _movement):
        self.lockCameraCount += 1
        if self.cameraStatus == 1 and abs(self.initialLocation - self.cameraLocation) >= self.cameraLocationThreshold and self.slipCameraCorrectionCount == 0:
            if self.cameraFrameNumber not in self.cameraFrameNumberList and len(self.cameraFrameNumberList) < 3:
                self.cameraLocationList.append(self.cameraLocation)
                self.cameraFrameNumberList.append(self.cameraFrameNumber)
        elif self.cameraStatus == 1 and abs(self.initialLocation - self.cameraLocation) < self.cameraLocationThreshold and self.slipCameraCorrectionCount == 0:
            self.cameraLocationList = []
            self.cameraFrameNumberList = []

        if ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3])) and _movement == 'FORWARD' and sum(self.sensor[0:4]) == 2 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            self.stop_robot()
            if ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3])) and sum(self.sensor[0:4]) == 2:
                self.print_message(2, 'Start tune forward corner pose')
                self.detectSideMode = 3
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 3:
                    if self.sensor[0] and self.sensor[1]:
                        self.currentYaw -= 3
                        self.initialYaw -= 3
                        self.rightLimitYaw -= 3
                        self.leftLimitYaw -= 3
                        self.reverseLimitYaw -= 3
                    elif self.sensor[2] and self.sensor[3]:
                        self.currentYaw += 3
                        self.initialYaw += 3
                        self.rightLimitYaw += 3
                        self.leftLimitYaw += 3
                        self.reverseLimitYaw += 3
                self.move_robot_fix_distance('BACKWARD_SIDE', -self.tuneForwardSpeed, 0, self.tuneDistance)
                self.turn_robot_fix_angle(7, -self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                self.cameraDirection = 0
                self.detectSideMode = 0
                self.slipCameraCorrectionCount = 0
                self.currentYawBias = 0
        elif ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7])) and _movement == 'BACKWARD' and sum(self.sensor[4:8]) == 2 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            self.stop_robot()
            if ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7])) and sum(self.sensor[4:8]) == 2:
                self.print_message(2, 'Start tune backward corner pose')
                self.detectSideMode = 4
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 3:
                    if self.sensor[4] and self.sensor[5]:
                        self.currentYaw -= 3
                        self.initialYaw -= 3
                        self.rightLimitYaw -= 3
                        self.leftLimitYaw -= 3
                        self.reverseLimitYaw -= 3
                    elif self.sensor[6] and self.sensor[7]:
                        self.currentYaw += 3
                        self.initialYaw += 3
                        self.rightLimitYaw += 3
                        self.leftLimitYaw += 3
                        self.reverseLimitYaw += 3
                self.move_robot_fix_distance('FORWARD_SIDE', self.tuneForwardSpeed, 0, self.tuneDistance)
                self.turn_robot_fix_angle(7, self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                self.cameraDirection = 0
                self.detectSideMode = 0
                self.slipCameraCorrectionCount = 0
                self.currentYawBias = 0
        elif self.sensor[0] and self.sensor[7]:
            if self.detectSideMode == 0:
                self.print_message(2, 'Start tune left side pose')
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 1.5:
                    if _movement == 'FORWARD':
                        self.currentYaw -= 1.5
                        self.initialYaw -= 1.5
                        self.rightLimitYaw -= 1.5
                        self.leftLimitYaw -= 1.5
                        self.reverseLimitYaw -= 1.5
                    elif _movement == 'BACKWARD':
                        self.currentYaw += 1.5
                        self.initialYaw += 1.5
                        self.rightLimitYaw += 1.5
                        self.leftLimitYaw += 1.5
                        self.reverseLimitYaw += 1.5
            if _movement == 'FORWARD':
                self.angular = -self.tuneRotationSpeed
            else:
                self.angular = self.tuneRotationSpeed
            self.cameraDirection = 0
            self.detectSideMode = 1
            self.slipCameraCorrectionCount = 0
            self.currentYawBias = 0
        elif self.sensor[3] and self.sensor[4]:
            if self.detectSideMode == 0:
                self.print_message(2, 'Start tune right side pose')
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 1.5:
                    if _movement == 'FORWARD':
                        self.currentYaw += 1.5
                        self.initialYaw += 1.5
                        self.rightLimitYaw += 1.5
                        self.leftLimitYaw += 1.5
                        self.reverseLimitYaw += 1.5
                    elif _movement == 'BACKWARD':
                        self.currentYaw -= 1.5
                        self.initialYaw -= 1.5
                        self.rightLimitYaw -= 1.5
                        self.leftLimitYaw -= 1.5
                        self.reverseLimitYaw -= 1.5
            if _movement == 'FORWARD':
                self.angular = self.tuneRotationSpeed
            else:
                self.angular = -self.tuneRotationSpeed
            self.cameraDirection = 0
            self.detectSideMode = 2
            self.slipCameraCorrectionCount = 0
            self.currentYawBias = 0
        elif (self.detectSideMode == 1 and not self.sensor[0] and _movement == 'FORWARD') or (self.detectSideMode == 1 and not self.sensor[7] and _movement == 'BACKWARD') or (self.detectSideMode == 2 and not self.sensor[3] and _movement == 'FORWARD') or (self.detectSideMode == 2 and not self.sensor[4] and _movement == 'BACKWARD'):
            self.print_message(4, 'Start turn back')
            self.detectSideMode = -1
            if _movement == 'FORWARD':
                self.move_robot_fix_distance('FORWARD_SIDE_IGNORE', max(self.linear, self.tuneForwardSpeed), self.angular*0.5, self.tuneDistance*3.25, False)
                self.turn_robot_fix_angle(7, max(self.linear, self.tuneForwardSpeed), self.tuneRotationSpeed, self.currentYaw)
            else:
                self.move_robot_fix_distance('BACKWARD_SIDE_IGNORE', min(self.linear, -self.tuneForwardSpeed), self.angular*0.5, self.tuneDistance*3.25, False)
                self.turn_robot_fix_angle(7, min(self.linear, -self.tuneForwardSpeed), self.tuneRotationSpeed, self.currentYaw)
            self.stop_robot()
            self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.currentYaw)
            if self.cameraStatus == 1:
                self.initialLocation = self.cameraLocation
            self.detectSideMode = 0
        elif self.cameraStatus == 1 and self.initialLocation != -1 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE') and self.lockCameraCount > 50 and len(self.cameraLocationList) > 2 and self.detectSideMode == 0:
            self.slipIMUCorrectionMileage = self.mileage
            if self.slipCameraCorrectionCount == 0 and abs(self.initialLocation - self.cameraLocation) >= self.cameraLocationThreshold:
                if (_movement == 'FORWARD' and self.initialLocation - self.cameraLocation <= -self.cameraLocationThreshold) or (_movement == 'BACKWARD' and self.initialLocation - self.cameraLocation >= self.cameraLocationThreshold):
                    self.cameraDirection = 1
                    self.slip_camera_correction(self.cameraDirection)
                elif (_movement == 'FORWARD' and self.initialLocation - self.cameraLocation >= self.cameraLocationThreshold) or (_movement == 'BACKWARD' and self.initialLocation - self.cameraLocation <= -self.cameraLocationThreshold):
                    self.cameraDirection = 2
                    self.slip_camera_correction(self.cameraDirection)
            elif self.slipCameraCorrectionCount != 0:
                self.slip_camera_correction(self.cameraDirection)
            else:
                self.cameraDirection = 0
                maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
                if maxAngle > 1:
                    self.angular = -self.tuneRotationSpeed
                elif maxAngle > 0.5:
                    self.angular = -self.tuneRotationSpeed * 0.5
                elif maxAngle < -1:
                    self.angular = self.tuneRotationSpeed
                elif maxAngle < -0.5:
                    self.angular = self.tuneRotationSpeed * 0.5
                else:
                    self.angular = 0
        elif self.slipCameraCorrectionCount != 0 and self.detectSideMode == 0:
            self.slipIMUCorrectionMileage = self.mileage
            self.slip_camera_correction(self.cameraDirection)
        elif self.detectSideMode == 0:
            self.cameraDirection = 0
            maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
            if maxAngle > 1:
                self.angular = -self.tuneRotationSpeed
            elif maxAngle > 0.5:
                self.angular = -self.tuneRotationSpeed * 0.5
            elif maxAngle < -1:
                self.angular = self.tuneRotationSpeed
            elif maxAngle < -0.5:
                self.angular = self.tuneRotationSpeed * 0.5
            else:
                self.angular = 0
        # print(self.cameraStatus, self.cameraLocation, self.currentYaw, self.currentYawBias, self.imu[2], self.cameraDirection, self.slipCameraCorrectionCount)

    def slip_camera_correction(self, _movement):
        if self.currentYawBias == 0:
            if _movement == 1:
                self.currentYawBias = -self.slipCorrectionAngle
            elif _movement == 2:
                self.currentYawBias = self.slipCorrectionAngle
            self.slipCameraCorrectionCount += 1
            if self.slipCameraCorrectionCount == 1:
                self.prevCameraLocation = self.cameraLocation
                self.slipCameraCorrectionMileage = self.mileage
            self.missFrameNumberList = []

        tuneFlag = False
        if self.cameraDirection == 1 and self.linear > 0 and self.initialLocation - self.cameraLocation <= -self.cameraLocationThreshold:
            tuneFlag = True
        elif self.cameraDirection == 1 and self.linear > 0 and self.initialLocation - self.cameraLocation > -self.cameraLocationThreshold:
            tuneFlag = False
        elif self.cameraDirection == 2 and self.linear > 0 and self.initialLocation - self.cameraLocation >= self.cameraLocationThreshold:
            tuneFlag = True
        elif self.cameraDirection == 2 and self.linear > 0 and self.initialLocation - self.cameraLocation < self.cameraLocationThreshold:
            tuneFlag = False
        elif self.cameraDirection == 1 and self.linear < 0 and self.initialLocation - self.cameraLocation >= self.cameraLocationThreshold:
            tuneFlag = True
        elif self.cameraDirection == 1 and self.linear < 0 and self.initialLocation - self.cameraLocation < self.cameraLocationThreshold:
            tuneFlag = False
        elif self.cameraDirection == 2 and self.linear < 0 and self.initialLocation - self.cameraLocation <= -self.cameraLocationThreshold:
            tuneFlag = True
        elif self.cameraDirection == 2 and self.linear < 0 and self.initialLocation - self.cameraLocation > -self.cameraLocationThreshold:
            tuneFlag = False

        if self.slipCameraCorrectionCount == 2:
            maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
        else:
            maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw - self.currentYawBias, False)

        if abs(self.initialLocation - self.cameraLocation) < self.cameraLocationThreshold and abs(self.currentYawBias) > abs(self.slipCorrectionAngle) and self.slipCameraCorrectionCount == 1:
            maxAngle = 0

        if maxAngle > 1:
            self.angular = -self.tuneRotationSpeed * 0.5
        elif maxAngle > 0.5:
            self.angular = -self.tuneRotationSpeed * 0.25
        elif maxAngle < -1:
            self.angular = self.tuneRotationSpeed * 0.5
        elif maxAngle < -0.5:
            self.angular = self.tuneRotationSpeed * 0.25
        elif tuneFlag and self.slipCameraCorrectionCount == 1 and self.cameraStatus == 1:
            self.angular = 0
            self.missFrameNumberList = []
            if self.cameraFrameNumber not in self.slipFrameNumberList:
                self.slipLocationList.append(self.cameraLocation)
                self.slipFrameNumberList.append(self.cameraFrameNumber)
            if self.mileage - self.slipCameraCorrectionMileage > 2:
                # if abs(self.currentYawBias) < 15 and not ((self.slipLocationList[0] > 270 and max(self.slipLocationList) - self.slipLocationList[-1] > 20) or (self.slipLocationList[0] < 270 and self.slipLocationList[-1] - min(self.slipLocationList) > 20)):
                if not ((self.slipLocationList[0] > 270 and max(self.slipLocationList) - self.slipLocationList[-1] > 20) or (self.slipLocationList[0] < 270 and self.slipLocationList[-1] - min(self.slipLocationList) > 20)):
                    if self.currentYawBias > 0:
                        self.currentYaw -= (self.slipCorrectionAngle * 0.5)
                        self.initialYaw -= (self.slipCorrectionAngle * 0.5)
                        self.rightLimitYaw -= (self.slipCorrectionAngle * 0.5)
                        self.leftLimitYaw -= (self.slipCorrectionAngle * 0.5)
                        self.reverseLimitYaw -= (self.slipCorrectionAngle * 0.5)
                    else:
                        self.currentYaw += (self.slipCorrectionAngle * 0.5)
                        self.initialYaw += (self.slipCorrectionAngle * 0.5)
                        self.rightLimitYaw += (self.slipCorrectionAngle * 0.5)
                        self.leftLimitYaw += (self.slipCorrectionAngle * 0.5)
                        self.reverseLimitYaw += (self.slipCorrectionAngle * 0.5)
                self.slipCameraCorrectionMileage = self.mileage
                self.slipLocationList = []
                self.slipFrameNumberList = []
        elif tuneFlag and self.slipCameraCorrectionCount == 1 and self.cameraStatus != 1 and self.cameraStatus != -1:
            self.angular = 0
            if self.cameraFrameNumber not in self.missFrameNumberList and self.cameraStatus != 1:
                self.missFrameNumberList.append(self.cameraFrameNumber)
            if len(self.missFrameNumberList) > 5:
                self.currentYawBias = 0
                self.slipIMUCorrectionMileage = self.mileage
        else:
            self.angular = 0
            self.currentYawBias = 0
            self.slipIMUCorrectionMileage = self.mileage
            if self.slipCameraCorrectionCount == 2:
                self.slipCameraCorrectionCount = 0
                self.lockCameraCount = 0
                self.cameraLocationList = []
                self.cameraFrameNumberList = []
                self.slipLocationList = []
                self.slipFrameNumberList = []
                self.print_message(4, 'Finish slip_camera_correction, start: ' + str(self.prevCameraLocation) + ', end: ' + str(self.cameraLocation))

    def detect_imu_pose(self, _movement):
        # ----- Auto tune robot pose to keep same angle ----- #
        self.slipIMUCorrectionCount = 0
        if ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3])) and _movement == 'FORWARD' and sum(self.sensor[0:4]) == 2 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            self.stop_robot()
            if ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3])) and sum(self.sensor[0:4]) == 2:
                self.print_message(2, 'Start tune forward corner pose')
                self.detectSideMode = 3
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 3:
                    if self.sensor[0] and self.sensor[1]:
                        self.currentYaw -= 3
                        self.initialYaw -= 3
                        self.rightLimitYaw -= 3
                        self.leftLimitYaw -= 3
                        self.reverseLimitYaw -= 3
                    elif self.sensor[2] and self.sensor[3]:
                        self.currentYaw += 3
                        self.initialYaw += 3
                        self.rightLimitYaw += 3
                        self.leftLimitYaw += 3
                        self.reverseLimitYaw += 3
                self.turn_robot_fix_angle(7, -self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                self.cameraDirection = 0
                self.detectSideMode = 0
                self.slipCameraCorrectionCount = 0
                self.currentYawBias = 0
        elif ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7])) and _movement == 'BACKWARD' and sum(self.sensor[4:8]) == 2 and (self.statusFlag == 'FORWARD_LINE' or self.statusFlag == 'INITIAL_LINE' or self.statusFlag == 'FINISH_LINE'):
            self.stop_robot()
            if ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7])) and sum(self.sensor[4:8]) == 2:
                self.print_message(2, 'Start tune backward corner pose')
                self.detectSideMode = 4
                if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 3:
                    if self.sensor[4] and self.sensor[5]:
                        self.currentYaw -= 3
                        self.initialYaw -= 3
                        self.rightLimitYaw -= 3
                        self.leftLimitYaw -= 3
                        self.reverseLimitYaw -= 3
                    elif self.sensor[6] and self.sensor[7]:
                        self.currentYaw += 3
                        self.initialYaw += 3
                        self.rightLimitYaw += 3
                        self.leftLimitYaw += 3
                        self.reverseLimitYaw += 3
                self.turn_robot_fix_angle(7, self.tuneForwardSpeed, self.tuneRotationSpeed, self.currentYaw)
                self.cameraDirection = 0
                self.detectSideMode = 0
                self.slipCameraCorrectionCount = 0
                self.currentYawBias = 0
        elif self.sensor[0] and self.sensor[7] and self.detectSideMode == 0:
            self.print_message(2, 'Start tune left side pose')
            if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 1.5:
                if _movement == 'FORWARD':
                    self.currentYaw -= 1.5
                    self.initialYaw -= 1.5
                    self.rightLimitYaw -= 1.5
                    self.leftLimitYaw -= 1.5
                    self.reverseLimitYaw -= 1.5
                elif _movement == 'BACKWARD':
                    self.currentYaw += 1.5
                    self.initialYaw += 1.5
                    self.rightLimitYaw += 1.5
                    self.leftLimitYaw += 1.5
                    self.reverseLimitYaw += 1.5
            if _movement == 'FORWARD':
                self.angular = -self.tuneRotationSpeed
            else:
                self.angular = self.tuneRotationSpeed
            self.detectSideMode = 1
        elif self.sensor[3] and self.sensor[4] and self.detectSideMode == 0:
            self.print_message(2, 'Start tune right side pose')
            if self.calc_yaw_diff(self.imu[2], self.currentYaw, True) < 1.5:
                if _movement == 'FORWARD':
                    self.currentYaw += 1.5
                    self.initialYaw += 1.5
                    self.rightLimitYaw += 1.5
                    self.leftLimitYaw += 1.5
                    self.reverseLimitYaw += 1.5
                elif _movement == 'BACKWARD':
                    self.currentYaw -= 1.5
                    self.initialYaw -= 1.5
                    self.rightLimitYaw -= 1.5
                    self.leftLimitYaw -= 1.5
                    self.reverseLimitYaw -= 1.5
            if _movement == 'FORWARD':
                self.angular = self.tuneRotationSpeed
            else:
                self.angular = -self.tuneRotationSpeed
            self.detectSideMode = 2
        elif (self.detectSideMode == 1 and not self.sensor[0] and _movement == 'FORWARD') or (self.detectSideMode == 1 and not self.sensor[7] and _movement == 'BACKWARD') or (self.detectSideMode == 2 and not self.sensor[3] and _movement == 'FORWARD') or (self.detectSideMode == 2 and not self.sensor[4] and _movement == 'BACKWARD'):
            self.print_message(4, 'Start turn back')
            self.detectSideMode = -1
            self.detectPoseCount = 1
            self.currentYawBias = 0
            self.slipIMUCorrectionMileage = self.mileage
            if _movement == 'FORWARD':
                self.move_robot_fix_distance('FORWARD_SIDE_IGNORE', max(self.linear, self.tuneForwardSpeed), self.angular*0.5, self.tuneDistance*3.25, False)
            else:
                self.move_robot_fix_distance('BACKWARD_SIDE_IGNORE', min(self.linear, -self.tuneForwardSpeed), self.angular*0.5, self.tuneDistance*3.25, False)
            self.detectSideMode = 0
        elif self.detectSideMode == 0:
            if self.slipMode == 2 or self.slipMode == 3:
                maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
                if maxAngle > 1:
                    self.angular = -self.tuneRotationSpeed
                elif maxAngle > 0.5:
                    self.angular = -self.tuneRotationSpeed * 0.5
                elif maxAngle < -1:
                    self.angular = self.tuneRotationSpeed
                elif maxAngle < -0.5:
                    self.angular = self.tuneRotationSpeed * 0.5
                else:
                    self.angular = 0
            elif self.slipMode == 0 or self.slipMode == 1:
                if self.detectPoseCount == 2:
                    maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
                else:
                    maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw - self.currentYawBias, False)
                if maxAngle > 1:
                    self.angular = -self.tuneRotationSpeed
                    if self.currentYawBias == 0:
                        self.detectPoseCount += 1
                    if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and _movement == 'FORWARD') or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and _movement == 'BACKWARD'):
                        if self.currentYawBias < self.calc_yaw_diff(self.imu[2], self.currentYaw, False):
                            self.currentYawBias = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
                    else:
                        if self.currentYawBias < self.calc_yaw_diff(self.imu[2], self.currentYaw, False) * 0.5:
                            self.currentYawBias = self.calc_yaw_diff(self.imu[2], self.currentYaw, False) * 0.5
                elif maxAngle > 0.5:
                    self.angular = -self.tuneRotationSpeed * 0.5
                elif maxAngle < -1:
                    self.angular = self.tuneRotationSpeed
                    if self.currentYawBias == 0:
                        self.detectPoseCount += 1
                    if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and _movement == 'BACKWARD') or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and _movement == 'FORWARD'):
                        if self.currentYawBias > self.calc_yaw_diff(self.imu[2], self.currentYaw, False):
                            self.currentYawBias = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
                    else:
                        if self.currentYawBias > self.calc_yaw_diff(self.imu[2], self.currentYaw, False) * 0.5:
                            self.currentYawBias = self.calc_yaw_diff(self.imu[2], self.currentYaw, False) * 0.5
                elif maxAngle < -0.5:
                    self.angular = self.tuneRotationSpeed * 0.5
                else:
                    self.angular = 0
                    self.currentYawBias = 0
                    if self.detectPoseCount == 2:
                        self.detectPoseCount = 0
                        self.slipIMUCorrectionMileage = self.mileage

    def slip_imu_correction(self, _movement):
        if self.currentYawBias == 0:
            if (self.cleanMode == CleanMode.LEFT_TOP_NAVIGATION.value and _movement == 'FORWARD') or (self.cleanMode == CleanMode.RIGHT_TOP_NAVIGATION.value and _movement == 'BACKWARD'):
                self.currentYawBias = max(abs(self.maxSlope) * 0.6, 1)
            else:
                self.currentYawBias = min(-abs(self.maxSlope) * 0.6, -1)
            self.slipIMUCorrectionCount += 1
            if self.slipIMUCorrectionCount == 2 and self.currentRow == 1:
                self.move_robot_fix_distance('BACKWARD_SIDE_SINGLE', min(self.linear, -self.tuneForwardSpeed), 0, self.tuneDistance*2, False)

        if self.slipIMUCorrectionCount == 2:
            maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw, False)
        else:
            maxAngle = self.calc_yaw_diff(self.imu[2], self.currentYaw - self.currentYawBias, False)

        if maxAngle > 0.5:
            self.angular = -self.tuneRotationSpeed
        elif maxAngle > 0.25:
            self.angular = -self.tuneRotationSpeed * 0.5
        elif maxAngle < -0.5:
            self.angular = self.tuneRotationSpeed
        elif maxAngle < -0.25:
            self.angular = self.tuneRotationSpeed * 0.5
        else:
            self.angular = 0
            self.currentYawBias = 0
            if self.slipIMUCorrectionCount == 2:
                self.slipIMUCorrectionCount = 0
                self.slipIMUCorrectionMileage = self.mileage

    def move_robot_close_cliff(self, _mode):
        if self.navFlag and not self.finishFlag:
            self.print_message(4, 'Move robot close cliff')
            if _mode == 0:
                self.turn_robot_fix_angle(1, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw+25)
                while not self.finished.is_set() and self.navFlag and not self.finishFlag and not (self.sensor[4] or self.sensor[5]):
                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and not (self.sensor[4] or self.sensor[5]):
                        self.linear = -self.forwardSpeed*0.5
                        self.angular = 0
                        sleep(0.01)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.tuneForwardSpeed, 0.0, self.tuneDistance*1.5)
                    sleep(0.01)
                # self.turn_robot_fix_angle(5, self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw)
                self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.leftLimitYaw)
            elif _mode == 1:
                self.turn_robot_fix_angle(2, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw-25)
                while not self.finished.is_set() and self.navFlag and not self.finishFlag and not (self.sensor[6] or self.sensor[7]):
                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and not (self.sensor[6] or self.sensor[7]):
                        self.linear = -self.forwardSpeed*0.5
                        self.angular = 0
                        sleep(0.01)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.tuneForwardSpeed, 0.0, self.tuneDistance*1.5)
                    sleep(0.01)
                # self.turn_robot_fix_angle(5, self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw)
                self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.rightLimitYaw)

    def move_robot_avoid_cliff(self, _mode):
        if self.navFlag and not self.finishFlag:
            self.print_message(4, 'Move robot avoid cliff')
            if _mode == 0:
                self.turn_robot_fix_angle(1, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw+35)
            elif _mode == 1:
                self.turn_robot_fix_angle(2, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw-35)
            self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0.0, self.tuneDistance*2)
            if _mode == 0:
                self.turn_robot_fix_angle(2, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.leftLimitYaw)
                self.turn_robot_fix_angle(2, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.initialYaw+65)
            elif _mode == 1:
                self.turn_robot_fix_angle(1, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.rightLimitYaw)
                self.turn_robot_fix_angle(1, -self.rturnForwardSpeed, self.rturnRotationSpeed, self.initialYaw-65)
            self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0.0, self.tuneDistance*2.5)
            self.turn_robot_fix_angle(5, self.rturnForwardSpeed, self.rturnRotationSpeed, self.initialYaw)
            self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.initialYaw)

    def initial_pose(self):
        # ----- Initialize robot pose to face up ----- #
        if self.navFlag and not self.finishFlag:
            self.print_message(4, 'Initial pose')
            if self.cleanCountNow == 0:
                self.initialYaw = self.get_average_yaw()
            self.currentRow = 0
            self.rightLimitYaw = (self.initialYaw-90) % 360
            self.leftLimitYaw = (self.initialYaw+90) % 360
            self.reverseLimitYaw = (self.initialYaw-180) % 360
            self.tuneInitialPoseCAND[0] = self.initialYaw
            self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.initialYaw)
            self.maxSlope = self.imu[1]

    def tune_initial_pose(self, _movement, _direction, _updateFlag):
        # ----- Calibration robot initial pose ----- #
        if self.navFlag and not self.finishFlag:
            beforeYaw = self.get_average_yaw()
            if self.sensor[0] and self.sensor[7]:
                if _movement == 'FORWARD':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.imu[2]+30)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif _movement == 'BACKWARD':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.imu[2]-30)
                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*2)
            elif self.sensor[3] and self.sensor[4]:
                if _movement == 'FORWARD':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.imu[2]-30)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif _movement == 'BACKWARD':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.imu[2]+30)
                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*2)
            self.turn_robot_fix_angle(5, 0, self.tuneRotationSpeed, beforeYaw)
            if _movement == 'FORWARD':
                self.move_robot_until_cliff('FORWARD', self.tuneForwardSpeed, self.tuneForwardSpeed)
            elif _movement == 'BACKWARD':
                self.move_robot_until_cliff('BACKWARD', -self.tuneForwardSpeed, -self.tuneForwardSpeed)

            if not (self.sensor[0] and self.sensor[7]) and not (self.sensor[3] and self.sensor[4]):
                stopTuneFlag = False
                if _movement == 'FORWARD' or _movement == 'FORWARD_FIRST':
                    self.print_message(4, 'Tune initial pose forward: ' + str(_updateFlag))
                    beforeYaw = self.imu[2]
                    tuneCount = 0
                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and tuneCount < 2:
                        if tuneCount == 1:
                            self.stop_robot()
                            if _movement == 'FORWARD':
                                self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance*1.5)
                            elif _movement == 'FORWARD_FIRST':
                                self.move_robot_fix_distance('FORWARD', self.tuneForwardSpeed, 0.0, self.tuneDistance*0.5)
                        while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensorForward:
                            if self.calc_yaw_diff(self.imu[2], beforeYaw, True) > self.tuneInitialPoseTolerance:
                                self.stop_robot()
                                self.stopTuneCount += 1
                                stopTuneFlag = True
                                break
                            if self.sensor[1] and not self.sensor[2]:
                                self.angular = self.tuneRotationSpeed
                                self.linear = -self.tuneForwardSpeed*0.5
                                sleep(0.05)
                            elif not self.sensor[1] and self.sensor[2]:
                                self.angular = -self.tuneRotationSpeed
                                self.linear = -self.tuneForwardSpeed*0.5
                                sleep(0.05)
                            else:
                                self.angular = 0
                                self.linear = -self.tuneForwardSpeed*0.5
                            sleep(0.01)
                        if not stopTuneFlag:
                            tuneCount += 1
                        else:
                            break
                        sleep(0.01)

                elif _movement == 'BACKWARD' or _movement == 'BACKWARD_FIRST':
                    self.print_message(4, 'Tune initial pose backward: ' + str(_updateFlag))
                    beforeYaw = self.imu[2]
                    tuneCount = 0
                    while not self.finished.is_set() and self.navFlag and not self.finishFlag and tuneCount < 2:
                        if tuneCount == 1:
                            self.stop_robot()
                            if _movement == 'BACKWARD':
                                self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance*1.5)
                            elif _movement == 'BACKWARD_FIRST':
                                self.move_robot_fix_distance('BACKWARD', -self.tuneForwardSpeed, 0.0, self.tuneDistance*0.5)
                        while not self.finished.is_set() and self.navFlag and not self.finishFlag and self.sensorBackward:
                            if self.calc_yaw_diff(self.imu[2], beforeYaw, True) > self.tuneInitialPoseTolerance:
                                self.stop_robot()
                                self.stopTuneCount += 1
                                stopTuneFlag = True
                                break
                            if self.sensor[5] and not self.sensor[6]:
                                self.angular = self.tuneRotationSpeed
                                self.linear = self.tuneForwardSpeed*0.5
                                sleep(0.05)
                            elif not self.sensor[5] and self.sensor[6]:
                                self.angular = -self.tuneRotationSpeed
                                self.linear = self.tuneForwardSpeed*0.5
                                sleep(0.05)
                            else:
                                self.angular = 0
                                self.linear = self.tuneForwardSpeed*0.5
                            sleep(0.01)
                        if not stopTuneFlag:
                            tuneCount += 1
                        else:
                            break
                        sleep(0.01)

                newCAND = 0
                if _direction == 'UP':
                    newCAND = self.imu[2]
                elif _direction == 'LEFT':
                    newCAND = (self.imu[2]-90) % 360
                elif _direction == 'RIGHT':
                    newCAND = (self.imu[2]+90) % 360
                elif _direction == 'DOWN':
                    newCAND = (self.imu[2]+180) % 360

                if stopTuneFlag:
                    if self.stopTuneCount > 2:
                        self.tuneInitialPoseCAND[1] = newCAND
                        self.tuneInitialPoseCAND[2] = newCAND
                        self.stopTuneCount = 0
                    else:
                        self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, beforeYaw)
                elif self.tuneInitialPoseCAND[1] == 0:
                    self.tuneInitialPoseCAND[1] = newCAND
                    self.stopTuneCount = 0
                elif self.tuneInitialPoseCAND[2] == 0:
                    self.tuneInitialPoseCAND[2] = newCAND
                    self.stopTuneCount = 0
                else:
                    self.tuneInitialPoseCAND[1] = newCAND
                    self.stopTuneCount = 0

                if _updateFlag and self.tuneInitialPoseCAND[1] != 0 and self.tuneInitialPoseCAND[2] != 0:
                    if self.calc_yaw_diff(self.tuneInitialPoseCAND[0], self.tuneInitialPoseCAND[1], True) < self.calc_yaw_diff(self.tuneInitialPoseCAND[0], self.tuneInitialPoseCAND[2], True):
                        self.initialYaw = self.tuneInitialPoseCAND[1]
                        self.rightLimitYaw = (self.initialYaw-90) % 360
                        self.leftLimitYaw = (self.initialYaw+90) % 360
                        self.reverseLimitYaw = (self.initialYaw-180) % 360
                    else:
                        self.initialYaw = self.tuneInitialPoseCAND[2]
                        self.rightLimitYaw = (self.initialYaw-90) % 360
                        self.leftLimitYaw = (self.initialYaw+90) % 360
                        self.reverseLimitYaw = (self.initialYaw-180) % 360
                    self.tuneInitialPoseCAND[0] = self.initialYaw
                    self.tuneInitialPoseCAND[1] = 0
                    self.tuneInitialPoseCAND[2] = 0

                self.stop_robot()

                if _direction == 'UP':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.initialYaw)
                elif _direction == 'LEFT':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.leftLimitYaw)
                elif _direction == 'RIGHT':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.rightLimitYaw)
                elif _direction == 'DOWN':
                    self.turn_robot_fix_angle(0, 0, self.tuneRotationSpeed, self.reverseLimitYaw)
            else:
                if _movement == 'FORWARD':
                    self.move_robot_fix_distance('BACKWARD', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif _movement == 'BACKWARD':
                    self.move_robot_fix_distance('FORWARD', self.forwardSpeed*0.5, 0, self.tuneDistance*2)

    def check_initial_pose(self):
        # ----- Move robot if robot is next to a cliff ----- #
        if self.navFlag and not self.finishFlag:
            self.errFlag = False
            cornerTuneFlag = False
            self.print_message(4, 'Check initial pose')
            if self.sensorForward:
                self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                if self.sensorForward and ((self.sensor[4] and self.sensor[5]) or (self.sensor[6] and self.sensor[7])):
                    cornerTuneFlag = True
            elif self.sensorBackward:
                self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                if self.sensorBackward and ((self.sensor[0] and self.sensor[1]) or (self.sensor[2] and self.sensor[3])):
                    cornerTuneFlag = True

            if sum(self.sensor[0:4]) > 2 and sum(self.sensor[4:8]) > 2:
                self.errFlag = True
            elif cornerTuneFlag:
                if not self.sensor[0] and not self.sensor[1]:
                    self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.imu[2]+35)
                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif not self.sensor[2] and not self.sensor[3]:
                    self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.imu[2]-35)
                    self.move_robot_fix_distance('FORWARD_SIDE', self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif not self.sensor[4] and not self.sensor[5]:
                    self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.imu[2]+35)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                elif not self.sensor[6] and not self.sensor[7]:
                    self.turn_robot_fix_angle(0, 0, self.rotationSpeed*0.5, self.imu[2]-35)
                    self.move_robot_fix_distance('BACKWARD_SIDE', -self.forwardSpeed*0.5, 0, self.tuneDistance*2)
                else:
                    self.errFlag = True

    def calc_yaw_diff(self, _a, _b, _absFlag):
        # ----- Calculate the difference between two angles ----- #
        angle = 0
        if _absFlag:
            if abs(_a-_b) > 180:
                angle = abs(abs(_a-_b)-360)
            else:
                angle = abs(_a-_b)
        else:
            if abs(_a-_b) > 180:
                if _a > _b:
                    angle = abs(_a-_b)-360
                else:
                    angle = 360 - abs(_a-_b)
            else:
                angle = _a - _b
        return angle

    def get_average_yaw(self):
        # ----- Get robot's current yaw angle ----- #
        average = 10
        x = 0
        y = 0
        for i in range(average):
            x += cos(radians(self.imu[2]))
            y += sin(radians(self.imu[2]))
            sleep(0.01)
        return degrees(atan2(y/average, x/average)) % 360

    def smoothCurve(self, _start, _target, _flex, _t, _during):
        # ----- Get current velocity after s-curve ----- #
        return _start+(_target-_start)/(1+exp(-_flex*((_t*2-_during)/_during)))

    def rpm_to_velocity(self, _motorLSpeed, _motorRSpeed, _factor=1):
        return ((_motorLSpeed+_motorRSpeed)*(2*self.weelRadius*pi/(60*self.gearRatio))/2)*_factor, ((_motorRSpeed-_motorLSpeed)*(2*self.weelRadius*pi/(60*self.gearRatio))/self.weelBase)*_factor

    def velocity_to_rpm(self, _linear, _angular):
        return ((_linear-_angular*0.5*self.weelBase)*60*self.gearRatio)/(pi*self.weelRadius*2), ((_linear+_angular*0.5*self.weelBase)*60*self.gearRatio)/(pi*self.weelRadius*2)

    def print_message(self, _level, _msg):
        if _level == 1:
            print('\033[1;31m%s\033[0m\r' % ('[Nav ERROR] ' + str(_msg)))
        elif _level == 2:
            print('\033[1;33m%s\033[0m\r' % ('[Nav WARN] ' + str(_msg)))
        elif _level == 3:
            print('\033[1;32m%s\033[0m\r' % ('[Nav INFO] ' + str(_msg)))
        elif _level == 4:
            print('[Nav INFO] ' + str(_msg) + '\r')
        self.navMessage = _msg
