#!/usr/bin/env python3

from time import sleep, time
from threading import Thread, Event


class StopWatch(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.finished = Event()
        self.duringTime = 0.0

    def run(self):
        startTime = time()
        while not self.finished.is_set():
            self.duringTime = time() - startTime
            sleep(0.01)

    def stop(self):
        self.finished.set()
        return self.duringTime

    def set_time_counter_format(self, _duringTime):
        minute = max(0, _duringTime//60)
        sec = max(0, int(_duringTime - (minute * 60)))
        ms = int((_duringTime - sec)*1000)
        return f"{minute:0>2}:{sec:0>2}.{ms:0>3}"
