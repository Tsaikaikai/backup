from io_control import CameraCommunication
from time import sleep

cam = CameraCommunication.CameraCommunication('Beta_3_1')
cam.start()

sleep(5)

if not cam.loadConfigStatus:
    print('camera load config failed')
    exit()

while True:
    result = cam.get_camera()

    if result['frameNumber'] == 987:
        cam.set_robot_status(1, False)

    print(result['status'], result['frameNumber'], result['angle'])
    sleep(0.1)

cam.stop()
