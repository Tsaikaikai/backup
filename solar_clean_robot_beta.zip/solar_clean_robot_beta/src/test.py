#!/usr/bin/env python3

from os.path import join, isfile
from time import sleep, time
import sys
from traceback import extract_tb
from sw_test.ManualTest import ManualTest
import yaml
from consolemenu import *
from consolemenu.items import *
from consolemenu.prompt_utils import PromptUtils
from colors import color
from utility.RobotConfig import TestData
from subprocess import Popen, PIPE
import csv


class Test_SolarCleanRobot(object):
    def __init__(self):
        super(Test_SolarCleanRobot, self).__init__()
        print('[Test INFO] Initial solar clean robot test\r')

        # ---------Initial params and flags--------- #
        self.configPath = '../config'
        self.loadConfigStatus = False
        self.robotInfoJson = None
        self.threadList = []

        # ---------Initial config--------- #
        self.robotType = ''
        self.controlMode = 0  # 0: Web UI 1: New Web UI
        self.simulate = True  # True: Simulate False: Online
        self.navTestMode = 0

        # ---------Initial color--------- #
        self.text_MoT = TestData().data

    def run(self):
        self.load_config()
        self.setup()
        sleep(5)
        if self.loadConfigStatus:
            print('[Main INFO] Run solar clean robot test\r')
            try:
                # Create the menu
                menu = ConsoleMenu("Solar clean robot test", "Please select test scenario:")

                submenu_1 = ConsoleMenu("Sonar test", "MoT_001~MoT_003")
                item_1_1 = FunctionItem(self.update_mot_001, self.action, args=['MoT_001'])
                item_1_2 = FunctionItem(self.update_mot_002, self.action, args=['MoT_002'])
                item_1_3 = FunctionItem(self.update_mot_003, self.action, args=['MoT_003'])
                submenu_1.append_item(item_1_1)
                submenu_1.append_item(item_1_2)
                submenu_1.append_item(item_1_3)

                submenu_2 = ConsoleMenu("Clean motor test", "MoT_004~MoT_005")
                item_2_1 = FunctionItem(self.update_mot_004, self.action, args=['MoT_004'])
                item_2_2 = FunctionItem(self.update_mot_005, self.action, args=['MoT_005'])
                submenu_2.append_item(item_2_1)
                submenu_2.append_item(item_2_2)

                submenu_3 = ConsoleMenu("BZ test", "MoT_006~MoT_007")
                item_3_1 = FunctionItem(self.update_mot_006, self.action, args=['MoT_006'])
                item_3_2 = FunctionItem(self.update_mot_007, self.action, args=['MoT_007'])
                submenu_3.append_item(item_3_1)
                submenu_3.append_item(item_3_2)

                submenu_4 = ConsoleMenu("Drive motor test", "MoT_008~MoT_010")
                item_4_1 = FunctionItem(self.update_mot_008, self.action, args=['MoT_008'])
                item_4_2 = FunctionItem(self.update_mot_009, self.action, args=['MoT_009'])
                item_4_3 = FunctionItem(self.update_mot_010, self.action, args=['MoT_010'])
                submenu_4.append_item(item_4_1)
                submenu_4.append_item(item_4_2)
                submenu_4.append_item(item_4_3)

                submenu_5 = ConsoleMenu("Battery test", "MoT_011~MoT_013")
                item_5_1 = FunctionItem(self.update_mot_011, self.action, args=['MoT_011'])
                item_5_2 = FunctionItem(self.update_mot_012, self.action, args=['MoT_012'])
                item_5_3 = FunctionItem(self.update_mot_013, self.action, args=['MoT_013'])
                submenu_5.append_item(item_5_1)
                submenu_5.append_item(item_5_2)
                submenu_5.append_item(item_5_3)

                submenu_6 = ConsoleMenu("IMU test", "MoT_014~MoT_015")
                item_6_1 = FunctionItem(self.update_mot_014, self.action, args=['MoT_014'])
                item_6_2 = FunctionItem(self.update_mot_015, self.action, args=['MoT_015'])
                submenu_6.append_item(item_6_1)
                submenu_6.append_item(item_6_2)

                submenu_7 = ConsoleMenu("Camera test", "MoT_016~MoT_017")
                item_7_1 = FunctionItem(self.update_mot_016, self.action, args=['MoT_016'])
                item_7_2 = FunctionItem(self.update_mot_017, self.action, args=['MoT_017'])
                submenu_7.append_item(item_7_1)
                submenu_7.append_item(item_7_2)

                item_1 = SubmenuItem(self.update_submenu_1, submenu=submenu_1)
                item_1.set_menu(menu)
                item_2 = SubmenuItem(self.update_submenu_2, submenu=submenu_2)
                item_2.set_menu(menu)
                item_3 = SubmenuItem(self.update_submenu_3, submenu=submenu_3)
                item_3.set_menu(menu)
                item_4 = SubmenuItem(self.update_submenu_4, submenu=submenu_4)
                item_4.set_menu(menu)
                item_5 = SubmenuItem(self.update_submenu_5, submenu=submenu_5)
                item_5.set_menu(menu)
                item_6 = SubmenuItem(self.update_submenu_6, submenu=submenu_6)
                item_6.set_menu(menu)
                item_7 = SubmenuItem(self.update_submenu_7, submenu=submenu_7)
                item_7.set_menu(menu)

                menu.append_item(item_1)
                menu.append_item(item_2)
                menu.append_item(item_3)
                menu.append_item(item_4)
                menu.append_item(item_5)
                menu.append_item(item_6)
                menu.append_item(item_7)

                menu.start()
                menu.join()

                self.save_result()

            except Exception as e:
                error_class = e.__class__.__name__
                detail = e.args[0]
                cl, exc, tb = sys.exc_info()
                lastCallStack = extract_tb(tb)[-1]
                fileName = lastCallStack[0]
                lineNum = lastCallStack[1]
                funcName = lastCallStack[2]
                errMsg = "File \"{}\", line {}, in {}: [{}] {}".format(fileName, lineNum, funcName, error_class, detail)
                print('\033[1;31m%s\033[0m\r' % ('[Test ERROR] ' + str(errMsg)))

    def setup(self):
        print('[Test INFO] Setup solar clean robot test\r')

        # ---------Trigger--------- #
        try:
            echo = Popen(['echo', 'robot'], stdout=PIPE)
            p = Popen(['sudo', '-S', 'udevadm', 'trigger'], stdin=echo.stdout, stdout=PIPE)
            sleep(1)
        except:
            pass

        # ---------Bringup io control--------- #
        self.TestIOControlThread = None
        self.TestIOControlThread = ManualTest(self.robotType)
        self.threadList.append(self.TestIOControlThread)

        for i in self.threadList:
            i.setDaemon(True)
            i.start()
            sleep(0.01)

    def stop(self):
        for i in self.threadList:
            i.stop()
            sleep(0.01)
        print('[Test INFO] Shutdown solar clean robot test\r')

    def load_config(self):
        print('[Test INFO] Load config from yaml\r')
        mainYamlPath = join(self.configPath, 'MainSetting.yaml')
        if not isfile(mainYamlPath):
            print('\033[1;31m%s\033[0m\r' % ('[Test ERROR] Load config error: MainSetting.yaml is not exists'))
        else:
            try:
                with open(mainYamlPath, "r") as f:
                    mainYamlDict = yaml.load(f, Loader=yaml.FullLoader)
                self.robotType = mainYamlDict['ROBOT_TYPE']
                self.loadConfigStatus = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Test ERROR] Load config error: ' + str(e)))

    def save_result(self):
        output = []
        for key in self.text_MoT:
            row = dict()
            row['test_id'] = key
            row['result'] = self.text_MoT[key]['result']
            output.append(row)

        with open("testResult.csv", "w", newline="") as fp:
            writer = csv.DictWriter(fp, fieldnames=['test_id', 'result'])
            writer.writeheader()
            writer.writerows(output)

    def action(self, _testID):
        self.text_MoT[_testID]['result'] = self.TestIOControlThread.test_selector(_testID)
        if self.text_MoT[_testID]['result'] == 'OK':
            self.text_MoT[_testID]['display'] = "{}".format(color(self.text_MoT[_testID]['text'], fg='green'))
        elif self.text_MoT[_testID]['result'] == 'NG':
            self.text_MoT[_testID]['display'] = "{}".format(color(self.text_MoT[_testID]['text'], fg='red'))
        else:
            self.text_MoT[_testID]['display'] = "{}".format(color(self.text_MoT[_testID]['text'], fg='white'))
        PromptUtils(Screen()).enter_to_continue()

    def update_submenu_1(self):
        if self.text_MoT['MoT_001']['result'] == 'None' or self.text_MoT['MoT_002']['result'] == 'None' or self.text_MoT['MoT_003']['result'] == 'None':
            return "{}".format(color('Sonar test', fg='white'))
        elif self.text_MoT['MoT_001']['result'] == 'NG' or self.text_MoT['MoT_002']['result'] == 'NG' or self.text_MoT['MoT_003']['result'] == 'NG':
            return "{}".format(color('Sonar test', fg='red'))
        else:
            return "{}".format(color('Sonar test', fg='green'))

    def update_submenu_2(self):
        if self.text_MoT['MoT_004']['result'] == 'None' or self.text_MoT['MoT_005']['result'] == 'None':
            return "{}".format(color('Clean motor test', fg='white'))
        elif self.text_MoT['MoT_004']['result'] == 'NG' or self.text_MoT['MoT_005']['result'] == 'NG':
            return "{}".format(color('Clean motor test', fg='red'))
        else:
            return "{}".format(color('Clean motor test', fg='green'))

    def update_submenu_3(self):
        if self.text_MoT['MoT_006']['result'] == 'None' or self.text_MoT['MoT_007']['result'] == 'None':
            return "{}".format(color('BZ test', fg='white'))
        elif self.text_MoT['MoT_006']['result'] == 'NG' or self.text_MoT['MoT_007']['result'] == 'NG':
            return "{}".format(color('BZ test', fg='red'))
        else:
            return "{}".format(color('BZ test', fg='green'))

    def update_submenu_4(self):
        if self.text_MoT['MoT_008']['result'] == 'None' or self.text_MoT['MoT_009']['result'] == 'None' or self.text_MoT['MoT_010']['result'] == 'None':
            return "{}".format(color('Drive motor test', fg='white'))
        elif self.text_MoT['MoT_008']['result'] == 'NG' or self.text_MoT['MoT_009']['result'] == 'NG' or self.text_MoT['MoT_010']['result'] == 'NG':
            return "{}".format(color('Drive motor test', fg='red'))
        else:
            return "{}".format(color('Drive motor test', fg='green'))

    def update_submenu_5(self):
        if self.text_MoT['MoT_011']['result'] == 'None' or self.text_MoT['MoT_012']['result'] == 'None' or self.text_MoT['MoT_013']['result'] == 'None':
            return "{}".format(color('Battery test', fg='white'))
        elif self.text_MoT['MoT_011']['result'] == 'NG' or self.text_MoT['MoT_012']['result'] == 'NG' or self.text_MoT['MoT_013']['result'] == 'NG':
            return "{}".format(color('Battery test', fg='red'))
        else:
            return "{}".format(color('Battery test', fg='green'))

    def update_submenu_6(self):
        if self.text_MoT['MoT_014']['result'] == 'None' or self.text_MoT['MoT_015']['result'] == 'None':
            return "{}".format(color('IMU test', fg='white'))
        elif self.text_MoT['MoT_014']['result'] == 'NG' or self.text_MoT['MoT_015']['result'] == 'NG':
            return "{}".format(color('IMU test', fg='red'))
        else:
            return "{}".format(color('IMU test', fg='green'))

    def update_submenu_7(self):
        if self.text_MoT['MoT_016']['result'] == 'None' or self.text_MoT['MoT_017']['result'] == 'None':
            return "{}".format(color('Camera test', fg='white'))
        elif self.text_MoT['MoT_016']['result'] == 'NG' or self.text_MoT['MoT_017']['result'] == 'NG':
            return "{}".format(color('Camera test', fg='red'))
        else:
            return "{}".format(color('Camera test', fg='green'))

    def update_mot_001(self):
        return self.text_MoT['MoT_001']['display']

    def update_mot_002(self):
        return self.text_MoT['MoT_002']['display']

    def update_mot_003(self):
        return self.text_MoT['MoT_003']['display']

    def update_mot_004(self):
        return self.text_MoT['MoT_004']['display']

    def update_mot_005(self):
        return self.text_MoT['MoT_005']['display']

    def update_mot_006(self):
        return self.text_MoT['MoT_006']['display']

    def update_mot_007(self):
        return self.text_MoT['MoT_007']['display']

    def update_mot_008(self):
        return self.text_MoT['MoT_008']['display']

    def update_mot_009(self):
        return self.text_MoT['MoT_009']['display']

    def update_mot_010(self):
        return self.text_MoT['MoT_010']['display']

    def update_mot_011(self):
        return self.text_MoT['MoT_011']['display']

    def update_mot_012(self):
        return self.text_MoT['MoT_012']['display']

    def update_mot_013(self):
        return self.text_MoT['MoT_013']['display']

    def update_mot_014(self):
        return self.text_MoT['MoT_014']['display']

    def update_mot_015(self):
        return self.text_MoT['MoT_015']['display']

    def update_mot_016(self):
        return self.text_MoT['MoT_016']['display']

    def update_mot_017(self):
        return self.text_MoT['MoT_017']['display']


def main():
    Worker = Test_SolarCleanRobot()
    try:
        Worker.run()
    except KeyboardInterrupt:
        pass
    Worker.stop()


if __name__ == "__main__":
    main()
