#!/usr/bin/env python3

from time import sleep, strftime, localtime
from yaml import load, FullLoader
from os.path import join, isfile, isdir
from os import makedirs
import sys
import cv2
import numpy as np
from math import sin, cos, degrees
from threading import Thread, Event
from random import uniform
from utility.RobotConfig import RobotData


class PanelSim(Thread):
    def __init__(self, _robotType=""):
        Thread.__init__(self)
        print('[Simulator INFO] Initial panel simulator\r')
        self.finished = Event()

        # ---------Initial params and flags--------- #
        self.loadConfigStatus = False
        self.logPath = '../log'
        self.configPath = join('../config', _robotType)
        self.sensor = None
        self.sensorRange = None
        # self.imu = None  # [roll, yaw, pitch]
        self.odom = [0, 0, 0]
        self.x = 0
        self.y = 0
        self.th = 0
        self.thRaw = 0
        self.imageX = 0
        self.imageY = 0
        self.map = np.full((600, 1400, 3), 0).astype(np.uint8)
        self.cleanAreaMap = self.map.copy()
        self.threshMap = None
        self.cropMinX = self.map.shape[1]
        self.cropMinY = self.map.shape[0]
        self.cropMaxX = 0
        self.cropMaxY = 0
        self.getInitialPoseFlag = True
        self.initialX = 0
        self.initialY = 0
        self.initialImageX = 0
        self.initialImageY = 0
        self.drawBrush1 = [0, 0, 0, 0]
        self.drawBrush2 = [0, 0, 0, 0]
        self.drawCleanArea = [0, 0, 0, 0]
        self.drawCliffArea = []
        self.overRange = False
        self.SOCSim = 100
        self.paddingX = False
        self.paddingY = False
        self.updateFlag = False  # For LoRa Param in Sim
        self.cleanMode = 0

        # ---------Initial config--------- #
        self.carWidth = 0.59
        self.carHeight = 1.14
        self.gridSize = 0.5
        self.brushDist = 0.08
        self.sensorPosition = [[-0.355, 0.32], [0.0, 0.42],
                               [0.355, 0.32], [0.355, -0.32], [-0.355, -0.32]]
        self.cleanArea = [0.5, 1.2, -2.3, -0.5]
        self.cliffArea = [[0.8, 1.5, 1.2, 1.3], [1.44, 0.35, 1.64, 0.05]]
        self.trackLength = 0.15
        self.weelBase = 0.54
        self.slope = 10
        self.addNoise = False
        self.testCount = 0

        # ---------Initial sensors--------- #
        self.board = RobotData().data['boardMaster']
        self.sonar = RobotData().data['sonar']
        self.battery = RobotData().data['battery']
        self.imu = RobotData().data['imu']
        self.camera = RobotData().data['camera']

    def run(self):
        self.load_config()
        if self.loadConfigStatus:
            print('[Simulator INFO] Run panel simulator\r')
            try:
                while not self.finished.is_set():
                    if self.sensor:
                        self.transform_coordinate()
                        self.draw_path(self.map)
                        self.mapWithCar = self.map.copy()
                        self.draw_endpoint(self.mapWithCar)
                        self.draw_car(self.mapWithCar)
                        self.mapFindRect = self.mapWithCar.copy()
                        self.find_min_rect(self.mapFindRect)
                        self.draw_area(self.cleanAreaMap)
                        self.draw_brush(self.cleanAreaMap)
                        self.mapWithCar = self.fusion_area(
                            self.cleanAreaMap, self.mapWithCar)
                        # self.draw_grid(self.mapWithCar)
                        # self.mapWithCar = self.crop_img(self.mapWithCar)
                        cv2.imshow('map', self.mapWithCar)
                        cv2.waitKey(30)
                    sleep(0.01)
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' %
                      ('[Simulator ERROR] Run error: ' + str(e)))

    def stop(self):
        self.finished.set()
        # cv2.destroyAllWindows()
        print('[Simulator INFO] Shutdown panel simulator\r')

    def load_config(self):
        print('[Simulator INFO] Load main config from yaml\r')
        simYamlPath = join(self.configPath, 'SimulatorSetting.yaml')
        if not isfile(simYamlPath):
            print('\033[1;31m%s\033[0m\r' % (
                '[Simulator ERROR] Load config error: SimulatorSetting.yaml is not exists'))
        else:
            try:
                with open(simYamlPath, "r") as f:
                    simYamlDict = load(f, Loader=FullLoader)
                self.carWidth = simYamlDict['CAR_WIDTH']
                self.carHeight = simYamlDict['CAR_HEIGHT']
                self.gridSize = simYamlDict['GRID_SIZE']
                self.brushDist = simYamlDict['BRUSH_DIST']
                self.sensorPosition = simYamlDict['SENSOR_POSITION']
                self.cleanArea = simYamlDict['CLEAN_AREA']
                self.cliffArea = simYamlDict['CLIFF_AREA']
                self.slope = simYamlDict['SLOPE']
                self.trackLength = simYamlDict['TRACK_LENGTH']
                self.weelBase = simYamlDict['WEEL_BASE']
                self.addNoise = simYamlDict['ADD_NOISE']
                self.loadConfigStatus = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' %
                      ('[Simulator ERROR] Load config error: ' + str(e)))

    def save_map(self):
        try:
            if self.map.any():
                self.mapWithCar = self.map.copy()
                self.draw_car(self.mapWithCar)
                self.draw_endpoint(self.mapWithCar)
                self.find_min_rect(self.mapWithCar)
                self.draw_endpoint(self.map)
                self.draw_grid(self.map)
                self.map = self.crop_img(self.map)
                endTime = strftime("%Y-%m-%d_%H:%M:%S", localtime())
                if not isdir(self.logPath):
                    makedirs(self.logPath)
                cv2.imwrite(join(self.logPath, (endTime + '.jpg')), self.map)
        except Exception as e:
            print('\033[1;31m%s\033[0m\r' %
                  ('[Simulator ERROR] Save map error: ' + str(e)))

    def set_position(self):
        self.x, self.y, self.thRaw = self.odom
        # self.sensor = _sensor
        self.th = -np.rad2deg(self.thRaw)
        if self.getInitialPoseFlag:
            self.initialX = self.x
            self.initialY = self.y
            self.getInitialPoseFlag = False

    def transform_coordinate(self):
        if abs(self.y * 100) + self.carHeight * 100 * 0.75 > self.map.shape[1] * 0.5:
            paddingLength = int(self.gridSize*100*2)
            self.map = cv2.copyMakeBorder(
                self.map, 0, 0, paddingLength, paddingLength, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            self.cleanAreaMap = cv2.copyMakeBorder(
                self.cleanAreaMap, 0, 0, paddingLength, paddingLength, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            self.paddingX = True
        if abs(self.x * 100) + self.carHeight * 100 * 0.75 > self.map.shape[0] * 0.5:
            paddingLength = int(self.gridSize*100*2)
            self.map = cv2.copyMakeBorder(
                self.map, paddingLength, paddingLength, 0, 0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            self.cleanAreaMap = cv2.copyMakeBorder(
                self.cleanAreaMap, paddingLength, paddingLength, 0, 0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            self.paddingY = True
        self.imageX = int(-self.y * 100 + self.map.shape[1] * 0.5)
        self.imageY = int(-self.x * 100 + self.map.shape[0] * 0.5)

    def draw_grid(self, _img):
        for x in range(0, _img.shape[1]-1, int(self.gridSize*100)):
            cv2.line(_img, (x, 0), (x, _img.shape[0]-1), (128, 128, 128), 1, 1)
        for y in range(0, _img.shape[0]-1, int(self.gridSize*100)):
            cv2.line(_img, (0, y), (_img.shape[1]-1, y), (128, 128, 128), 1, 1)
        cv2.line(_img, (_img.shape[1]-1, 0), (_img.shape[1] -
                                              1, _img.shape[0]-1), (128, 128, 128), 1, 1)
        cv2.line(_img, (0, _img.shape[0]-1), (_img.shape[1] -
                                              1, _img.shape[0]-1), (128, 128, 128), 1, 1)

    def draw_area(self, _img):
        mask1 = cv2.inRange(_img, (0, 0, 0), (1, 1, 1))
        area = np.full(
            (self.map.shape[0], self.map.shape[1], 3), 0).astype(np.uint8)
        cv2.rectangle(area, (self.drawCleanArea[0], self.drawCleanArea[1]), (
            self.drawCleanArea[2], self.drawCleanArea[3]), (255, 255, 255), thickness=-1)
        mask2 = cv2.inRange(area, (254, 254, 254), (255, 255, 255))
        mask = cv2.bitwise_and(mask1, mask2)
        _img[mask != 0] = [150, 150, 150]
        for i, val in enumerate(self.drawCliffArea):
            cv2.rectangle(_img, (val[0], val[1]),
                          (val[2], val[3]), (0, 0, 10), thickness=-1)
        # cv2.rectangle(img, (min_x, min_y), (max_x, max_y), (255, 255, 255), thickness=5)

    def draw_car(self, _img):
        # Calc brush
        self.drawBrush1[0] = int((cos(self.thRaw) * (-self.carWidth/2) - sin(
            self.thRaw) * (self.carHeight/2-self.brushDist)) * 100 + self.imageX)
        self.drawBrush1[1] = int(-(sin(self.thRaw) * (-self.carWidth/2) + cos(
            self.thRaw) * (self.carHeight/2-self.brushDist)) * 100 + self.imageY)
        self.drawBrush1[2] = int((cos(self.thRaw) * (self.carWidth/2) - sin(
            self.thRaw) * (self.carHeight/2-self.brushDist)) * 100 + self.imageX)
        self.drawBrush1[3] = int(-(sin(self.thRaw) * (self.carWidth/2) + cos(
            self.thRaw) * (self.carHeight/2-self.brushDist)) * 100 + self.imageY)
        self.drawBrush2[0] = int((cos(self.thRaw) * (-self.carWidth/2) - sin(
            self.thRaw) * (-self.carHeight/2+self.brushDist)) * 100 + self.imageX)
        self.drawBrush2[1] = int(-(sin(self.thRaw) * (-self.carWidth/2) + cos(
            self.thRaw) * (-self.carHeight/2+self.brushDist)) * 100 + self.imageY)
        self.drawBrush2[2] = int((cos(self.thRaw) * (self.carWidth/2) - sin(
            self.thRaw) * (-self.carHeight/2+self.brushDist)) * 100 + self.imageX)
        self.drawBrush2[3] = int(-(sin(self.thRaw) * (self.carWidth/2) + cos(
            self.thRaw) * (-self.carHeight/2+self.brushDist)) * 100 + self.imageY)

        # Calc weel
        drawWeel = [0, 0, 0, 0, 0, 0, 0, 0]
        drawWeel[0] = int((cos(self.thRaw) * (-self.weelBase/2) -
                           sin(self.thRaw) * self.trackLength/2) * 100 + self.imageX)
        drawWeel[1] = int(-(sin(self.thRaw) * (-self.weelBase/2) +
                            cos(self.thRaw) * self.trackLength/2) * 100 + self.imageY)
        drawWeel[2] = int((cos(self.thRaw) * (-self.weelBase/2) -
                           sin(self.thRaw) * (-self.trackLength/2)) * 100 + self.imageX)
        drawWeel[3] = int(-(sin(self.thRaw) * (-self.weelBase/2) +
                            cos(self.thRaw) * (-self.trackLength/2)) * 100 + self.imageY)
        drawWeel[4] = int((cos(self.thRaw) * (self.weelBase/2) -
                           sin(self.thRaw) * self.trackLength/2) * 100 + self.imageX)
        drawWeel[5] = int(-(sin(self.thRaw) * (self.weelBase/2) +
                            cos(self.thRaw) * self.trackLength/2) * 100 + self.imageY)
        drawWeel[6] = int((cos(self.thRaw) * (self.weelBase/2) -
                           sin(self.thRaw) * (-self.trackLength/2)) * 100 + self.imageX)
        drawWeel[7] = int(-(sin(self.thRaw) * (self.weelBase/2) +
                            cos(self.thRaw) * (-self.trackLength/2)) * 100 + self.imageY)

        # Calc clean area
        self.drawCleanArea[0] = int(
            self.cleanArea[0] * 100 + self.map.shape[1] * 0.5)
        self.drawCleanArea[1] = int(-self.cleanArea[1]
                                    * 100 + self.map.shape[0] * 0.5)
        self.drawCleanArea[2] = int(
            self.cleanArea[2] * 100 + self.map.shape[1] * 0.5)
        self.drawCleanArea[3] = int(-self.cleanArea[3]
                                    * 100 + self.map.shape[0] * 0.5)
        for i in range(0, 8, 2):
            self.overRange = False
            if drawWeel[i] <= self.drawCleanArea[0] or drawWeel[i] >= self.drawCleanArea[2] or drawWeel[i+1] <= self.drawCleanArea[1] or drawWeel[i+1] >= self.drawCleanArea[3]:
                self.overRange = True
                break

        # Calc cliff area
        if self.cliffArea:
            self.drawCliffArea = []
            for i, val in enumerate(self.cliffArea):
                x1 = int(val[0] * 100 + self.map.shape[1] * 0.5)
                y1 = int(-val[1] * 100 + self.map.shape[0] * 0.5)
                x2 = int(val[2] * 100 + self.map.shape[1] * 0.5)
                y2 = int(-val[3] * 100 + self.map.shape[0] * 0.5)
                self.drawCliffArea.append([x1, y1, x2, y2])
                for i in range(0, 8, 2):
                    if drawWeel[i] >= x1 and drawWeel[i] <= x2 and drawWeel[i+1] >= y1 and drawWeel[i+1] <= y2:
                        self.overRange = True
                        break
        # Draw car
        rect = ((self.imageX, self.imageY),
                (int(self.carWidth*100), int(self.carHeight*100)), self.th)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        if self.overRange:
            cv2.drawContours(_img, [box], 0, (0, 0, 255), 3)
        else:
            cv2.drawContours(_img, [box], 0, (0, 255, 0), 3)
        cv2.circle(_img, (self.imageX, self.imageY), 3, (0, 255, 0), 10)

        # Draw brush
        if self.overRange:
            cv2.line(_img, (self.drawBrush1[0], self.drawBrush1[1]),
                     (self.drawBrush1[2], self.drawBrush1[3]), (0, 0, 255), 3)
            cv2.line(_img, (self.drawBrush2[0], self.drawBrush2[1]),
                     (self.drawBrush2[2], self.drawBrush2[3]), (0, 255, 0), 3)
        else:
            cv2.line(_img, (self.drawBrush1[0], self.drawBrush1[1]),
                     (self.drawBrush1[2], self.drawBrush1[3]), (0, 0, 255), 3)
            cv2.line(_img, (self.drawBrush2[0], self.drawBrush2[1]),
                     (self.drawBrush2[2], self.drawBrush2[3]), (0, 255, 0), 3)

        # Draw sensor
        for i, val in enumerate(self.sensorPosition):
            x_transform = int(
                (cos(self.thRaw) * val[0] - sin(self.thRaw) * val[1]) * 100 + self.imageX)
            y_transform = int(-(sin(self.thRaw) *
                                val[0] + cos(self.thRaw) * val[1]) * 100 + self.imageY)
            if self.sensor[i]:
                cv2.circle(_img, (x_transform, y_transform),
                           8, (0, 165, 255), -1)
                if self.overRange:
                    cv2.circle(_img, (x_transform, y_transform),
                               7, (0, 0, 255), 2)
                else:
                    cv2.circle(_img, (x_transform, y_transform),
                               7, (0, 255, 0), 2)
            else:
                cv2.circle(_img, (x_transform, y_transform),
                           8, (255, 0, 0), -1)
                if self.overRange:
                    cv2.circle(_img, (x_transform, y_transform),
                               7, (0, 0, 255), 2)
                else:
                    cv2.circle(_img, (x_transform, y_transform),
                               7, (0, 255, 0), 2)

        # Draw weel
        if self.overRange:
            cv2.line(_img, (drawWeel[0], drawWeel[1]),
                     (drawWeel[2], drawWeel[3]), (0, 0, 255), 3)
            cv2.line(_img, (drawWeel[4], drawWeel[5]),
                     (drawWeel[6], drawWeel[7]), (0, 0, 255), 3)
        else:
            cv2.line(_img, (drawWeel[0], drawWeel[1]),
                     (drawWeel[2], drawWeel[3]), (0, 255, 0), 3)
            cv2.line(_img, (drawWeel[4], drawWeel[5]),
                     (drawWeel[6], drawWeel[7]), (0, 255, 0), 3)

    def draw_endpoint(self, _img):
        cv2.circle(_img, (self.initialImageX, self.initialImageY),
                   4, (255, 0, 0), 10)
        cv2.circle(
            _img, (int(_img.shape[1]*0.5), int(_img.shape[0]*0.5)), 5, (0, 128, 255), 10)

    def draw_path(self, _img):
        self.initialImageX = int(-self.initialY * 100 +
                                 self.map.shape[1] * 0.5)
        self.initialImageY = int(-self.initialX * 100 +
                                 self.map.shape[0] * 0.5)
        cv2.circle(_img, (self.imageX, self.imageY), 1, (255, 0, 0), 7)
        '''
        if self.overRange:
            cv2.circle(_img, (self.imageX, self.imageY), 1, (0, 0, 255), 7)
        elif sum(self.sensor) == 0:
            cv2.circle(_img, (self.imageX, self.imageY), 1, (255, 0, 0), 7)
        else:
            cv2.circle(_img, (self.imageX, self.imageY), 1, (0, 165, 255), 7)
        '''

    def draw_brush(self, _img):
        mask1 = cv2.inRange(_img, (149, 149, 149), (150, 150, 150))
        brushImg = _img.copy()
        cv2.line(brushImg, (self.drawBrush1[0], self.drawBrush1[1]), (
            self.drawBrush1[2], self.drawBrush1[3]), (0, 128, 255), 3)
        cv2.line(brushImg, (self.drawBrush2[0], self.drawBrush2[1]), (
            self.drawBrush2[2], self.drawBrush2[3]), (0, 128, 255), 3)
        mask2 = cv2.inRange(brushImg, (0, 127, 254), (0, 129, 255))
        mask = cv2.bitwise_and(mask1, mask2)
        _img[mask != 0] = [255, 255, 255]

    def fusion_area(self, _img1, _img2):
        mask1 = cv2.inRange(_img1, (1, 1, 1), (255, 255, 255))
        mask = cv2.bitwise_and(mask1, self.threshMap)
        img = _img1.copy()
        img[mask != 0] = [0, 0, 0]
        img = cv2.add(img, _img2)
        return img

    def find_min_rect(self, _img):
        cv2.line(_img, (int(_img.shape[1]*0.5), int(_img.shape[0]*0.5)),
                 (self.initialImageX, self.initialImageY), (10, 10, 10), 5)
        imgray = cv2.cvtColor(_img, cv2.COLOR_BGR2GRAY)
        ret, self.threshMap = cv2.threshold(imgray, 1, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(
            self.threshMap, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        rect = cv2.minAreaRect(contours[0])
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(_img, [box], 0, (0, 0, 255), 2)
        xs = [x[0] for x in box]
        ys = [x[1] for x in box]
        if self.paddingY:
            self.cropMinY += int(self.gridSize*100*2)
            self.cropMaxY += int(self.gridSize*100*2)
            self.paddingY = False
        if self.paddingX:
            self.cropMinX += int(self.gridSize*100*2)
            self.cropMaxX += int(self.gridSize*100*2)
            self.paddingX = False
        if self.cropMinX > min(xs):
            self.cropMinX = min(xs)
        if self.cropMinY > min(ys):
            self.cropMinY = min(ys)
        if self.cropMaxX < max(xs):
            self.cropMaxX = max(xs)
        if self.cropMaxY < max(ys):
            self.cropMaxY = max(ys)

    def crop_img(self, _img):
        if self.cropMinX < 0:
            self.cropMinX = 0
        if self.cropMinY < 0:
            self.cropMinY = 0
        if self.cropMaxX > _img.shape[1]:
            self.cropMaxX = _img.shape[1]
        if self.cropMaxY > _img.shape[0]:
            self.cropMaxY = _img.shape[0]
        cropImg = _img[self.cropMinY:self.cropMaxY,
                       self.cropMinX:self.cropMaxX]
        return cropImg

    def get_sensor_status(self):
        self.sensor = [False for i in range(len(self.sensorPosition))]
        for i, val in enumerate(self.sensorPosition):
            transY = -(cos(self.thRaw) * val[0] - sin(self.thRaw) * val[1]) + self.y
            transX = sin(self.thRaw) * val[0] + cos(self.thRaw) * val[1] + self.x
            if transX > self.cleanArea[1] or transX < self.cleanArea[3] or transY > -self.cleanArea[0] or transY < -self.cleanArea[2]:
                self.sensor[i] = True
            if self.cliffArea:
                for j, val in enumerate(self.cliffArea):
                    if transX >= val[3] and transX <= val[1] and transY <= -val[0] and transY >= -val[2]:
                        self.sensor[i] = True

    def get_sensor_range(self):
        self.sensorRange = [0 for i in range(len(self.sensor))]
        for i, val in enumerate(self.sensor):
            if self.sensor[i]:
                self.sensorRange[i] = -1
            else:
                self.sensorRange[i] = 10

    def get_imu(self):
        degRoll, degPitch, degYaw = 0, 0, 0
        if self.addNoise:
            degYaw = (degrees(self.thRaw) + uniform(-1.0, 1.0)) % 360
        else:
            degYaw = degrees(self.thRaw) % 360
        if degYaw >= 0 and degYaw < 180:
            degPitch = self.slope - 2 * self.slope * degYaw / 180
        else:
            degPitch = 2 * self.slope * (degYaw-180) / 180 - self.slope
        if self.addNoise:
            degPitch += uniform(-0.5, 0.5)
            degRoll = uniform(-0.5, 0.5)
        euler = [degRoll, degPitch, degYaw]

        Connect = True
        Code = 0
        # self.testCount += 1
        # print(self.testCount)
        # if self.testCount > 1000 and self.testCount < 2000:
        #     Connect = False
        #     Code = 1001
        # else:
        #     Connect = True
        #     Code = 0

        self.imu['connect'] = Connect
        self.imu['errorCode'] = Code
        self.imu['euler'] = euler
        return self.imu

    def get_camera(self):
        if self.addNoise:
            degYaw = (degrees(self.thRaw) + uniform(-1.0, 1.0)) % 360
        else:
            degYaw = degrees(self.thRaw) % 360

        if degYaw >= 180:
            self.camera['angle'] = round(270 - degYaw)
        else:
            self.camera['angle'] = round(90 - degYaw)

        if self.cleanMode == 0:
            self.camera['location'] = int(640 - ((-self.x * 100 + self.map.shape[0] * 0.5) % 20) * 640 / 20)
        else:
            self.camera['location'] = int(((-self.x * 100 + self.map.shape[0] * 0.5) % 20) * 640 / 20)

        self.camera['frameNumber'] += 1
        if self.camera['frameNumber'] > 999:
            self.camera['frameNumber'] = 0
        self.camera['status'] = 1
        return self.camera

    def set_clean_mode(self, _cleanMode):
        self.cleanMode = _cleanMode

    def get_battery(self):
        self.battery['connect'] = True
        self.battery['voltage'] = 24.0
        self.battery['current'] = 5.0
        self.battery['temperature'] = 40.0
        self.battery['SOC'] = 100
        self.battery['SOH'] = 100
        self.battery['cycle'] = 5
        return self.battery

    def get_board(self):
        self.board['connect'] = True
        self.board['firmwareVersion'] = 0x320
        return self.board

    def get_sonar(self, _odom):
        self.odom = _odom
        self.set_position()
        self.get_sensor_status()
        self.get_sensor_range()
        Connect = True
        Code = 0
        # self.testCount += 1
        # print(self.testCount)
        # if self.testCount > 3000 and self.testCount < 4000:
        #     Connect = False
        #     Code = 5001
        # else:
        #     Connect = True
        #     Code = 0
        self.sonar['connect'] = Connect
        self.sonar['cliffState'] = self.sensor
        self.sonar['range'] = self.sensorRange
        self.sonar['errorCode'] = Code
        return self.sonar

    def get_battery_test(self):
        # print(self.testCount)
        VB, IB, SOC, Temp, Cycle, SOH, Connect, Code = 24, 4, 100, 40, 1, 100, True, 0
        self.SOCSim -= 0.02
        self.testCount += 1
        # if self.testCount > 6000:
        #     self.SOCSim = 100
        if self.SOCSim < 10:
            self.SOCSim = 10

        # self.testCount += 1
        # if self.testCount > 1000 and self.testCount < 2000:
        #     Connect = False
        #     Code = 4001
        # else:
        #     Connect = True
        #     Code = 0

        self.battery['connect'] = Connect
        self.battery['errorCode'] = Code
        self.battery['voltage'] = VB
        self.battery['current'] = IB
        self.battery['temperature'] = Temp
        self.battery['SOC'] = round(self.SOCSim)
        self.battery['SOH'] = SOH
        self.battery['cycle'] = Cycle
        return self.battery
