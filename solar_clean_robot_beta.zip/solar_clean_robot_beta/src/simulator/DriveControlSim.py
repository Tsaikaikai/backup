#!/usr/bin/env python3

import time
from math import sin, cos, pi, sqrt
from threading import Thread, Event
from os.path import join, isfile, isdir
from yaml import load, FullLoader
import numpy as np
import sys
from utility.RobotConfig import RobotData


class DriveControlSim(Thread):
    def __init__(self, _robotType=""):
        Thread.__init__(self)
        print('[Motor INFO] Initial drive motor simulation\r')
        self.finished = Event()

        # -----Initial params and flags----- #
        self.configPath = join('../config', _robotType)
        self.emoFlag = False
        self.loadConfigStatus = False
        self.errFlag = False
        self.driveMotor = RobotData().data['driveMotor']

        # -----Hardware----- #
        self.weelRadius = 0.075
        self.weelBase = 0.54
        self.gearRatio = 15.38
        self.PPR = 10000
        self.motorMaxSpeed = 4500
        self.frequency = 30
        self.initial_pose = [0, 0, 0]
        self.sonar = [True, True, True, True, True, True, True, True]

        # -----Kinematic----- #
        self.currentLinear = 0.0
        self.currentAngular = 0.0
        self.speedL = 0
        self.speedR = 0
        self.linearMaxSpeed = (self.motorMaxSpeed * 2 * self.weelRadius * pi) / (60 * self.gearRatio)
        self.angularMaxSpeed = (self.motorMaxSpeed * 2 * self.weelRadius * pi) / (60 * self.gearRatio * self.weelBase * 0.5)

        # -----Encoder----- #
        self.motorLEncoder = 0
        self.motorREncoder = 0
        self.prevMotorLEncoder = 0
        self.prevMotorREncoder = 0
        self.currentEncoderTimer = 0
        self.prevEncoderTimer = 0

        # -----Odometry----- #
        self.x = 0
        self.y = 0
        self.th = 0
        self.vx = 0
        self.vy = 0
        self.vth = 0
        self.dt = 0
        self.dx = 0
        self.dy = 0
        self.dth = 0
        self.dc = 0
        self.deltaL = 0
        self.deltaR = 0
        self.prevX = 0
        self.prevY = 0
        self.mileage = 0

    def run(self):
        self.load_config()
        if self.loadConfigStatus:
            print('[Motor INFO] Run drive motor simulation\r')
            while not self.finished.is_set():
                self.control_motor()
                self.finished.wait(1/self.frequency)

    def stop(self):
        self.finished.set()
        print('[Motor INFO] Shutdown drive motor simulation\r')

    def control_motor(self):
        try:
            self.calc_kinematic()
            self.calc_odometry()
            self.calc_mileage()
        except Exception as e:
            print('\033[1;31m%s\033[0m\r' % ('[Motor ERROR] Control motor error: ' + str(e)))

    def load_config(self):
        print('[Motor INFO] Load config from yaml\r')
        motorYamlPath = join(self.configPath, 'MotorSetting.yaml')
        if not isfile(motorYamlPath):
            print('\033[1;31m%s\033[0m\r' % ('[Motor ERROR] Load config error: MotorSetting.yaml is not exists'))
        else:
            try:
                with open(motorYamlPath, "r") as f:
                    motorYamlDict = load(f, Loader=FullLoader)
                self.weelRadius = motorYamlDict['WEEL_RADIUS']
                self.weelBase = motorYamlDict['WEEL_BASE']
                self.gearRatio = motorYamlDict['GEAR_RATIO']
                self.PPR = motorYamlDict['PPR']
                self.initial_pose = motorYamlDict['INITIAL_POSE']
                self.x += self.initial_pose[1]
                self.y -= self.initial_pose[0]
                self.th += np.deg2rad(self.initial_pose[2])
                self.loadConfigStatus = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Motor ERROR] Load config error: ' + str(e)))

    def set_velocity(self, _velocity):
        self.currentLinear, self.currentAngular = _velocity

    def set_sonar(self, _sonar):
        self.sonar = _sonar

    def get_drive_motor(self):
        self.driveMotor['connect'] = True
        self.driveMotor['velocity'] = [self.currentLinear, self.currentAngular]
        self.driveMotor['odometry'] = [self.x, self.y, self.th]
        self.driveMotor['mileage'] = self.mileage
        return self.driveMotor

    def calc_kinematic(self):
        linear = self.currentLinear
        angular = self.currentAngular
        if self.emoFlag:
            linear = 0.0
            angular = 0.0
        if (sum(self.sonar[0:4]) > 2 and linear > 0) or (sum(self.sonar[4:8]) > 2 and linear < 0):
            linear = 0.0
            angular = 0.0
            # print('\033[1;33m%s\033[0m\r' % ('[Motor WARN] Detect cliff, stop'))
        self.speedL = int(round(((linear - self.weelBase / 2.0 * angular) / (2 * self.weelRadius * pi / (60 * self.gearRatio)))))
        self.speedR = int(round(((linear + self.weelBase / 2.0 * angular) / (2 * self.weelRadius * pi / (60 * self.gearRatio)))))
        if self.speedL > self.motorMaxSpeed:
            self.speedL = self.motorMaxSpeed
        elif self.speedL < -self.motorMaxSpeed:
            self.speedL = -self.motorMaxSpeed
        if self.speedR > self.motorMaxSpeed:
            self.speedR = self.motorMaxSpeed
        elif self.speedR < -self.motorMaxSpeed:
            self.speedR = -self.motorMaxSpeed

    def calc_mileage(self):
        self.mileage += sqrt(((self.x-self.prevX)**2)+((self.y-self.prevY)**2))
        self.prevX = self.x
        self.prevY = self.y

    def calc_odometry(self):
        self.currentEncoderTimer = time.time()
        self.motorLEncoder += self.speedL / 60 * self.PPR * (self.currentEncoderTimer - self.prevEncoderTimer)
        self.motorREncoder += self.speedR / 60 * self.PPR * (self.currentEncoderTimer - self.prevEncoderTimer)
        self.motorLEncoder = float(self.motorLEncoder)
        self.motorREncoder = float(self.motorREncoder)

        try:
            self.deltaL = self.motorLEncoder - self.prevMotorLEncoder
            self.deltaR = self.motorREncoder - self.prevMotorREncoder
            dl = 2 * pi * self.weelRadius * self.deltaL / (self.PPR * self.gearRatio)
            dr = 2 * pi * self.weelRadius * self.deltaR / (self.PPR * self.gearRatio)
            self.dc = (dl + dr) / 2
            self.dt = self.currentEncoderTimer - self.prevEncoderTimer
            self.dth = (dr - dl) / self.weelBase
            self.dx = (cos(self.th) * cos(self.dth) * self.dc + sin(self.th) * sin(self.dth) * self.dc)
            self.dy = (sin(self.th) * cos(self.dth) * self.dc - cos(self.th) * sin(self.dth) * self.dc)
            if self.emoFlag:
                self.dc = 0
                self.deltaL = 0
                self.deltaR = 0
                self.dx = 0
                self.dy = 0
                self.dth = 0
            if self.dt != 0:
                if abs(self.dc / self.dt) <= self.linearMaxSpeed and abs(self.dth / self.dt) <= self.angularMaxSpeed:
                    self.x += self.dx
                    self.y += self.dy
                    self.th += self.dth
                    self.vx = self.dc / self.dt
                    self.vy = 0
                    self.vth = self.dth / self.dt
                else:
                    print('\033[1;33m%s\033[0m\r' % ('[Motor WARN] Over speed, l: %.3f a: %.3f, ignore once' % (self.dc / self.dt, self.dth / self.dt)))
            else:
                print('\033[1;33m%s\033[0m\r' % ('[Motor WARN] dt is zero, ignore once'))
            self.prevEncoderTimer = self.currentEncoderTimer
            self.prevMotorLEncoder = self.motorLEncoder
            self.prevMotorREncoder = self.motorREncoder
        except Exception as e:
            print('\033[1;31m%s\033[0m\r' % ('[Motor ERROR] Calculate odometry error: ' + str(e)))
