import os
import time
from datetime import datetime


def save_to_txt(filename, data):
    with open(filename, 'a') as file:
        file.write(data + '\n')
        file.flush()  # 確保將資料寫入緩衝區
        os.fsync(file.fileno())  # 強制將緩衝區的資料寫入硬碟


def main():
    start_time = time.time()

    while True:
        current_time = time.time()
        elapsed_time = current_time - start_time

        # 轉換為時間格式 (hh:mm:ss)
        formatted_time = str(datetime.utcfromtimestamp(elapsed_time).strftime('%H:%M:%S'))

        # 處理時間進位為1天
        days = int(elapsed_time // (24 * 3600))
        elapsed_time -= days * 24 * 3600

        # 顯示累積運行時間（加上天數）
        print(f"累積運行時間: {days} 天 {formatted_time}")

        # 儲存累積運行時間至txt檔
        save_to_txt('/home/rpdzkj/Desktop/ra_log.txt', f"{days} 天 {formatted_time}")

        time.sleep(1)  # 暫停1秒


if __name__ == "__main__":
    main()
