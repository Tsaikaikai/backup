from os.path import isfile, join
from yaml import load, FullLoader
from os import fsync
import yaml
from datetime import datetime
from utility.RobotConfig import LogType


def save_config(_configPath, _configSetting):
    if not isfile(_configPath):
        return False
    else:
        try:
            with open(_configPath, "w") as f:
                yaml.dump(_configSetting, f)
            return True
        except Exception as _exception:
            print(_exception)
            return False


def load_config(_configPath):
    if not isfile(_configPath):
        return dict()
    else:
        try:
            with open(_configPath, "r") as f:
                _configYamlDict = load(f, Loader=FullLoader)
            return _configYamlDict
        except Exception as _exception:
            return dict()


def save_log_list(_logfileName, _logDataList):
    try:
        with open(_logfileName, "a") as f:
            while len(_logDataList) > 0:
                f.write("["+_logDataList[0][0]+"]")
                f.write(_logDataList[0][1])
                _logDataList.pop(0)
            f.flush()
            fsync(f)
        return True
    except Exception as _exception:
        print(_exception)
        return False


def save_log(_logPath, _logfileName, _timeStamp, _logData):
    try:
        _logfileName = join(_logPath, _logfileName)
        with open(_logfileName, "a") as f:
            f.write("["+_timeStamp+"]")
            f.write(_logData)
            f.flush()
            fsync(f)
        return True
    except Exception as _exception:
        print(_exception)
        return False


def print_log(_logData, _logInfo) -> list:
    _outputLog = [str(datetime.now().strftime("%H:%M:%S")), _logData]
    if _logInfo == LogType.ERROR.value:
        print("\033[1;31m%s\033[0m\r" % (_logData))
    else:
        print(_logData)
    return _outputLog
