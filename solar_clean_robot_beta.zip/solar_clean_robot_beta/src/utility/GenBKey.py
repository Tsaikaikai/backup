#!/usr/bin/env python3

import hashlib
import os

def get_cpu_id():
    cpuID = None
    with open('/proc/cpuinfo') as f:
        for line in f:
            if line.split(':')[0].strip() == 'Serial':
                cpuID = line.split(':')[1].strip()
    return cpuID

def delete_self():
    self_path = os.path.realpath(__file__)
    os.remove(self_path)
 
if __name__ == '__main__':
    cpuID = get_cpu_id()
    hl1 = hashlib.md5(cpuID.encode(encoding='UTF-8')).hexdigest()
    hl2 = hashlib.sha256(hl1.encode(encoding='UTF-8')).hexdigest()
    if os.path.isdir('/usr/src/'):
        with open('/usr/src/.key', 'w') as f:
            f.write(hl2[16:32])
    delete_self()
