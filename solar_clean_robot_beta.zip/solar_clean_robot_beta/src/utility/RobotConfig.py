from enum import Enum


class RobotData():
    def __init__(self) -> None:
        self.data = dict()
        self.data["main"] = dict()
        self.data["main"] = {"connectFlag": False, "cancelFlag": False, "navFlag": False, "controlVelocity": [0, 0], "errorCode": [0], "softwareVersion": ""}
        self.data["boardMaster"] = dict()
        self.data["boardMaster"] = {"timeStamp": 0, "connect": False, "retryCounter": 0, "errorCode": 0, "firmwareVersion": ""}
        self.data["boardSlave"] = dict()
        self.data["boardSlave"] = {"timeStamp": 0, "connect": False, "errorCode": 0}
        self.data["sonar"] = dict()
        self.data["sonar"] = {"connect": False, "errorCode": 0, "cliffState": [True, True, True, True, True, True, True, True], "range": [-2, -2, -2, -2, -2, -2, -2, -2]}
        self.data["battery"] = dict()
        self.data["battery"] = {"connect": False, "errorCode": 0, "voltage": 0.0, "current": 0.0, "temperature": 0.0, "SOC": 0, "SOH": 0, "cycle": 0}
        self.data["driveMotor"] = dict()
        self.data["driveMotor"] = {"connect": False, "errorCode": 0, "state": 0, "velocity": [0.0, 0.0], "odometry": [0.0, 0.0, 0.0], "mileage": 0.0}
        self.data["imu"] = dict()
        self.data["imu"] = {"connect": False, "retryCounter": 0, "errorCode": 0, "euler": [0.0, 0.0, 0.0], "acceleration": [0.0, 0.0, 0.0]}
        self.data["recorder"] = dict()
        self.data["recorder"] = {"errorCode": 0, "brushRemainTime": 0, "pedrailRemainTime": 0, "cleanAreaNow": 0.0, "cleanAreaTotal": 0.0, "cleanDistanceNow": 0.0, "cleanDistanceTotal": 0.0, "cleanTimeNow": 0, "cleanTimeTotal": 0, "mileageNow": 0.0, "mileageTotal": 0.0, "robotID": ""}
        self.data["sensor"] = dict()
        self.data["sensor"] = {"temperature": [0.0, 0.0], "humidity": 0.0, "current": [0.0, 0.0, 0.0, 0.0], "errorCode": 0}
        self.data["controller"] = dict()
        self.data["controller"] = {"connect": False, "remoteFlag": False, "navFlag": False}
        self.data["camera"] = dict()
        self.data["camera"] = {"connect": False, "frameNumber": 0, "status": -1, "location": -1, "angle": 0, "cameraDebugData": {"data0": "0", "data1": "0", "data2": "0", "data3": "0", "data4": "0", "data5": "0"}}
        self.data["navigation"] = dict()
        self.data["navigation"] = {'errorCode': 0, 'robotState': 0, 'navState': 0, 'finishFlag': False, 'controlVelocity': [0.0, 0.0], 'motorSpeed': [0, 0], 'cameraDirection': 0, 'detectSideMode': 0, 'slipCameraCorrectionCount': 0,
                                   'cleanArea': 0, 'cleanCountNow': 0, 'initialYaw': 0}
        self.data["uiCommand"] = dict()
        self.data["uiCommand"] = {"errorCode": 0, "controlVelocity": [0.0, 0.0], "cleanMotorFlag": False, "beeperFlag": False, "navFlag": False, "navSetting": {
            "cleanMode": 0, "cleanSpeed": 0.4, "cleanCount": 1}, "speedTestSetting": {"testLinear": 0.0, "testAngular": 0.0, "testDistance": 0.0}, "errorCode": 0}


class TestData():
    def __init__(self) -> None:
        self.data = dict()
        self.data["MoT_001"] = dict()
        self.data["MoT_001"] = {'text': '[MoT_001]', 'result': 'None', 'display': '[MoT_001]'}
        self.data["MoT_002"] = dict()
        self.data["MoT_002"] = {'text': '[MoT_002]', 'result': 'None', 'display': '[MoT_002]'}
        self.data["MoT_003"] = dict()
        self.data["MoT_003"] = {'text': '[MoT_003]', 'result': 'None', 'display': '[MoT_003]'}
        self.data["MoT_004"] = dict()
        self.data["MoT_004"] = {'text': '[MoT_004]', 'result': 'None', 'display': '[MoT_004]'}
        self.data["MoT_005"] = dict()
        self.data["MoT_005"] = {'text': '[MoT_005]', 'result': 'None', 'display': '[MoT_005]'}
        self.data["MoT_006"] = dict()
        self.data["MoT_006"] = {'text': '[MoT_006]', 'result': 'None', 'display': '[MoT_006]'}
        self.data["MoT_007"] = dict()
        self.data["MoT_007"] = {'text': '[MoT_007]', 'result': 'None', 'display': '[MoT_007]'}
        self.data["MoT_008"] = dict()
        self.data["MoT_008"] = {'text': '[MoT_008]', 'result': 'None', 'display': '[MoT_008]'}
        self.data["MoT_009"] = dict()
        self.data["MoT_009"] = {'text': '[MoT_009]', 'result': 'None', 'display': '[MoT_009]'}
        self.data["MoT_010"] = dict()
        self.data["MoT_010"] = {'text': '[MoT_010]', 'result': 'None', 'display': '[MoT_010]'}
        self.data["MoT_011"] = dict()
        self.data["MoT_011"] = {'text': '[MoT_011]', 'result': 'None', 'display': '[MoT_011]'}
        self.data["MoT_012"] = dict()
        self.data["MoT_012"] = {'text': '[MoT_012]', 'result': 'None', 'display': '[MoT_012]'}
        self.data["MoT_013"] = dict()
        self.data["MoT_013"] = {'text': '[MoT_013]', 'result': 'None', 'display': '[MoT_013]'}
        self.data["MoT_014"] = dict()
        self.data["MoT_014"] = {'text': '[MoT_014]', 'result': 'None', 'display': '[MoT_014]'}
        self.data["MoT_015"] = dict()
        self.data["MoT_015"] = {'text': '[MoT_015]', 'result': 'None', 'display': '[MoT_015]'}
        self.data["MoT_016"] = dict()
        self.data["MoT_016"] = {'text': '[MoT_016]', 'result': 'None', 'display': '[MoT_016]'}
        self.data["MoT_017"] = dict()
        self.data["MoT_017"] = {'text': '[MoT_017]', 'result': 'None', 'display': '[MoT_017]'}


class UIRobotState(Enum):
    DISSCONNECT = 0x00
    ABNORMAL = 0x01
    WARNING = 0x02
    NAVIGATION = 0x03
    RETURN = 0x04
    STANDBY = 0x05
    REMOTE = 0x06


class RobotState(Enum):
    REMOTE = 0x00
    LEFT_TOP_NAVIGATION = 0x01
    RIGHT_TOP_NAVIGATION = 0x02
    RETURN = 0x03
    SPEED_TEST = 0x04
    LOW_BATTERY_ABNORMAL = 0x05
    ABNORMAL = 0x06
    RA_TEST = 0x07
    MOTOR_TEST = 0x08
    CAMERA_ABNORMAL = 0x09
    INITIAL = 0x0A


class CleanMode(Enum):
    LEFT_TOP_NAVIGATION = 0x00
    RIGHT_TOP_NAVIGATION = 0x01
    RETURN = 0x02
    SPEED_TEST = 0x03
    RA_TEST = 0x04
    MOTOR_TEST = 0x05
    INITIAL = 0x06


class LogType(Enum):
    INFO = 0x00
    WARNING = 0x01
    ERROR = 0x02
    DEBUG = 0x03
    CRITICAL = 0x04
    NOTSET = 0x05
