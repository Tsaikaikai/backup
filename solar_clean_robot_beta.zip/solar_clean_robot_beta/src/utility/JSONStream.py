import json


def format_json(_jsonData):
    if isinstance(_jsonData, float):
        if _jsonData == float("inf"):
            return int(_jsonData)
        else:
            return round(_jsonData, 2)
    elif isinstance(_jsonData, dict):
        return dict((k, format_json(v)) for k, v in _jsonData.items())
    elif isinstance(_jsonData, (list, tuple)):
        return list(map(format_json, _jsonData))
    return _jsonData


def update_json(_oldJsonData, _newJsonData):
    if isinstance(_newJsonData, type(None)):
        return _oldJsonData
    elif isinstance(_newJsonData, dict):
        for k, v in _newJsonData.items():
            _oldJsonData[k] = update_json(_oldJsonData[k], _newJsonData[k])
        return _oldJsonData
    elif isinstance(_newJsonData, (list, tuple)):
        return list(map(update_json, _oldJsonData, _newJsonData))
    else:
        return _newJsonData


def check_json(_inputStr):
    try:
        json.loads(_inputStr)
        return True
    except:
        return False


def get_dict_data(_rawData):
    if type(_rawData) == type(dict()):
        return _rawData
    elif type(_rawData) == type(str()):
        return json.loads(_rawData)
    else:
        return dict()
