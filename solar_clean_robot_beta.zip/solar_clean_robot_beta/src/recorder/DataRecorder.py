#!/usr/bin/env python3
# from RobotConfig import RobotData
from os import makedirs, listdir, fsync, stat
from os.path import join, isfile, exists, isdir
from threading import Thread, Event
from yaml import load, FullLoader, dump
from time import sleep, strftime, struct_time, localtime
import csv
from shutil import rmtree
import sys
from utility.RobotConfig import RobotData


class DataRecorder(Thread):
    def __init__(self, _robotType=""):
        Thread.__init__(self)
        print('[Rec INFO] Initial data recorder\r')
        self.finished = Event()

        # -----Flags and params for robot info-----#
        self.configPath = join('../config', _robotType)
        self.logPath = '../log'
        self.csvFilePath = None
        self.csvFolderPath = None
        self.loadConfigStatus = False
        self.recordJson = None
        self.initMonth = None
        self.initDay = None
        self.initHour = None
        self.currentMonth = None
        self.currentDay = None
        self.currentHour = None

        # -----Flags and params for consumable-----#
        self.linear = 0
        self.angular = 0
        self.cleanMotorFlag = False
        self.yamlPath = join('../../solar_clean_robot_data')
        self.yamlPathBK = '../../solar_clean_robot_data/bk'
        self.brushRemainTime = 0
        self.pedrailRemainTime = 0
        self.cleanAreaNow = 0
        self.cleanAreaTotal = 0
        self.prevCleanArea = 0
        self.cleanDistanceNow = 0
        self.cleanDistanceTotal = 0
        self.cleanDistanceStart = 0
        self.prevCleanDistance = 0
        self.cleanTimeNow = 0
        self.cleanTimeTotal = 0
        self.prevCleanTime = 0
        self.mileageNow = 0
        self.mileageTotal = 0
        self.prevMileage = 0
        self.navFlag = False
        self.pedrailLinearCounter = 0
        self.historyYamlPath = join(self.yamlPath, 'History.yaml')
        self.historyYamlPathBK = join(self.yamlPathBK, 'History.yaml')
        self.brushYamlPath = join(self.yamlPath, 'Brush.yaml')
        self.brushYamlPathBK = join(self.yamlPathBK, 'Brush.yaml')
        self.pedrailYamlPath = join(self.yamlPath, 'Pedrail.yaml')
        self.pedrailYamlPathBK = join(self.yamlPathBK, 'Pedrail.yaml')
        self.cloudYamlPath = join(self.yamlPath, 'CloudSetting.yaml')
        self.cloudYamlPathBK = join(self.yamlPathBK, 'CloudSetting.yaml')
        self.recorder = RobotData().data['recorder']
        self.prevBoardConnectStatus = False
        self.prevIMUConnectStatus = False
        self.prevCameraConnectStatus = False
        self.boardDisconnectCount = 0
        self.IMUDisconnectCount = 0
        self.cameraDisconnectCount = 0

        # -----moving parameter----#
        self.frequency = 10
        self.retention = 30
        self.brushLife = 15552000
        self.pedrailLife = 7776000

        # -----Flags and params for cloud setting-----#
        self.__cloudSetting = RobotData().data["recorder"]

    def run(self):
        self.load_config()
        if self.loadConfigStatus:
            self.load_yaml()
            sleep(10)
            counter = 0
            while not self.finished.is_set():
                counter += 1
                self.record_log()
                self.calc_clean_area_and_mileage()
                self.calc_clean_distance()
                if counter >= self.frequency:
                    self.calc_brush_life_expectance()
                    self.calc_pedrail_life_expectance()
                    self.calc_clean_time()
                    self.record_history_yaml()
                    self.record_brush_yaml()
                    self.record_pedrail_yaml()
                    counter = 0
                sleep(1/self.frequency)

    def stop(self):
        self.finished.set()
        print('[Rec INFO] Shutdown data recorder\r')

    def load_config(self):
        if not isdir(self.logPath):
            makedirs(self.logPath)
        print('[Rec INFO] Load config from yaml\r')
        recorderYamlPath = join(self.configPath, 'RecorderSetting.yaml')
        if not isfile(recorderYamlPath):
            print('\033[1;31m%s\033[0m\r' % ('[Nav ERROR] Load config error: RecorderSetting.yaml is not exists'))
        else:
            try:
                with open(recorderYamlPath, "r") as f:
                    recorderYamlDict = load(f, Loader=FullLoader)
                self.frequency = recorderYamlDict['UPDATE_FREQUENCY']
                self.retention = recorderYamlDict['RETENTION_PERIOD']
                self.brushLife = recorderYamlDict['BRUSH_LIFE']
                self.pedrailLife = recorderYamlDict['PEDRAIL_LIFE']
                self.loadConfigStatus = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] Load config error: ' + str(e)))

    def load_yaml(self):
        print('[Rec INFO] Load consumable from yaml\r')
        if not exists(self.yamlPath):
            makedirs(self.yamlPath)
        if not exists(self.yamlPathBK):
            makedirs(self.yamlPathBK)
        self.load_history_yaml()
        self.load_brush_yaml()
        self.load_pedrail_yaml()
        self.load_cloud_yaml()

    def load_cloud_yaml(self):
        if not isfile(self.cloudYamlPath):
            self.__cloudSetting['robotID'] = "SolarCleanRobot0"
            with open(self.cloudYamlPath, "w") as f:
                dump({"ROBOT_ID": self.__cloudSetting["robotID"]}, f)
                f.flush()
                fsync(f)
        try:
            with open(self.cloudYamlPath, "r") as f:
                cloudYamlDict = load(f, Loader=FullLoader)
            self.__cloudSetting['robotID'] = cloudYamlDict['ROBOT_ID']
        except Exception as e:
            print('\033[1;33m%s\033[0m\r' % ('[Rec WARN] Load cloud yaml error: ' + str(e) + ', load backup'))
            try:
                with open(self.cloudYamlPathBK, "r") as f:
                    cloudYamlDict = load(f, Loader=FullLoader)
                self.__cloudSetting['robotID'] = cloudYamlDict['ROBOT_ID']
                with open(self.cloudYamlPath, "w") as f:
                    dump(cloudYamlDict, f)
                    f.flush()
                    fsync(f)
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERROR] Load cloud backup yaml error: ' + str(e) + ', create new'))
                self.__cloudSetting['robotID'] = "SC_000"

    def load_history_yaml(self):
        try:
            with open(self.historyYamlPath, "r") as f:
                historyYamlDict = load(f, Loader=FullLoader)
            self.cleanAreaTotal = historyYamlDict['CLEAN_AREA_TOTAL']
            self.mileageTotal = historyYamlDict['MILEAGE_TOTAL']
            self.cleanTimeTotal = historyYamlDict['CLEAN_TIME_TOTAL']
            self.cleanDistanceTotal = historyYamlDict['CLEAN_DISTANCE_TOTAL']
        except Exception as e:
            print('\033[1;33m%s\033[0m\r' % ('[Rec WARN] Load history yaml error: ' + str(e) + ', load backup'))
            try:
                with open(self.historyYamlPathBK, "r") as f:
                    historyYamlDict = load(f, Loader=FullLoader)
                self.cleanAreaTotal = historyYamlDict['CLEAN_AREA_TOTAL']
                self.mileageTotal = historyYamlDict['MILEAGE_TOTAL']
                self.cleanTimeTotal = historyYamlDict['CLEAN_TIME_TOTAL']
                self.cleanDistanceTotal = historyYamlDict['CLEAN_DISTANCE_TOTAL']
                with open(self.historyYamlPath, "w") as f:
                    dump(historyYamlDict, f)
                    f.flush()
                    fsync(f)
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERROR] Load history backup yaml error: ' + str(e) + ', create new'))
                self.cleanAreaTotal = 0
                self.mileageTotal = 0
                self.cleanTimeTotal = 0
                self.cleanDistanceTotal = 0

    def load_brush_yaml(self):
        try:
            with open(self.brushYamlPath, "r") as f:
                brushYamlDict = load(f, Loader=FullLoader)
            self.brushRemainTime = brushYamlDict['BRUSH']
        except Exception as e:
            print('\033[1;33m%s\033[0m\r' % ('[Rec WARN] Load brush yaml error: ' + str(e) + ', load backup'))
            try:
                with open(self.brushYamlPathBK, "r") as f:
                    brushYamlDict = load(f, Loader=FullLoader)
                self.brushRemainTime = brushYamlDict['BRUSH']
                with open(self.brushYamlPath, "w") as f:
                    dump(brushYamlDict, f)
                    f.flush()
                    fsync(f)
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERROR] Load brush backup yaml error: ' + str(e) + ', create new'))
                self.brushRemainTime = self.brushLife

    def load_pedrail_yaml(self):
        try:
            with open(self.pedrailYamlPath, "r") as f:
                pedrailYamlDict = load(f, Loader=FullLoader)
            self.pedrailRemainTime = pedrailYamlDict['PEDRAIL']
        except Exception as e:
            print('\033[1;33m%s\033[0m\r' % ('[Rec WARN] Load pedrail yaml error: ' + str(e) + ', load backup'))
            try:
                with open(self.pedrailYamlPathBK, "r") as f:
                    pedrailYamlDict = load(f, Loader=FullLoader)
                self.pedrailRemainTime = pedrailYamlDict['PEDRAIL']
                with open(self.pedrailYamlPath, "w") as f:
                    dump(pedrailYamlDict, f)
                    f.flush()
                    fsync(f)
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERROR] Load pedrail backup yaml error: ' + str(e) + ', create new'))
                self.pedrailRemainTime = self.pedrailLife

    def set_robot_status(self, _robotData):
        self.linear, self.angular = _robotData['main']['controlVelocity']
        self.cleanMotorFlag = _robotData['uiCommand']["cleanMotorFlag"]
        self.cleanAreaNow = _robotData['navigation']['cleanArea']
        self.mileageNow = _robotData['driveMotor']['mileage']
        self.navFlag = _robotData['main']['navFlag']

        _info = self.pack_robot_info(_robotData)
        self.currentDay = _info['time'].tm_mday
        self.currentHour = _info['time'].tm_hour
        if self.initDay != self.currentDay:
            dir_list = listdir(self.logPath)
            dir_list.sort()
            while len(dir_list) >= self.retention:
                rmtree(join(self.logPath, dir_list[0]))
                dir_list.pop(0)
            self.initDay = _info['time'].tm_mday
            self.csvFolderPath = join(self.logPath, strftime("%Y-%m-%d", _info['time']))
            if not exists(self.csvFolderPath):
                makedirs(self.csvFolderPath)
        if self.initHour != self.currentHour:
            self.initHour = _info['time'].tm_hour
            self.csvFilePath = join(self.csvFolderPath, strftime("%Y-%m-%d_%H-00-00", _info['time']) + '.csv')
        self.recordJson = _info

    def get_consumable_value(self):
        self.recorder['brushRemainTime'] = self.brushRemainTime
        self.recorder['pedrailRemainTime'] = self.pedrailRemainTime
        self.recorder['cleanTimeNow'] = self.cleanTimeNow
        self.recorder['cleanTimeTotal'] = self.cleanTimeTotal
        self.recorder['cleanAreaNow'] = self.cleanAreaNow
        self.recorder['cleanAreaTotal'] = self.cleanAreaTotal
        self.recorder['mileageNow'] = self.mileageNow
        self.recorder['mileageTotal'] = self.mileageTotal
        self.recorder['cleanDistanceNow'] = self.cleanDistanceNow
        self.recorder['cleanDistanceTotal'] = self.cleanDistanceTotal
        self.recorder["robotID"] = self.__cloudSetting["robotID"]
        return self.recorder

    def record_log(self):
        if self.recordJson:
            json = self.recordJson
            if type(json['time']) == struct_time:
                json['time'] = strftime("%Y-%m-%d_%H-%M-%S", json['time'])
            headerFlag = False
            try:
                if not isfile(self.csvFilePath):
                    headerFlag = True
                elif stat(self.csvFilePath).st_size == 0:
                    headerFlag = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] headerFlag error: ' + str(e)))
            try:
                with open(self.csvFilePath, 'a+', newline='', encoding='utf-8', errors='replace') as outf:
                    dw = csv.DictWriter(outf, json.keys())
                    if headerFlag:
                        dw.writeheader()
                    dw.writerow(json)
                    outf.flush()
                    fsync(outf)
            except Exception as e:
                if not exists(self.csvFolderPath):
                    makedirs(self.csvFolderPath)
                print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] write config error: ' + str(e)))

    def record_history_yaml(self):
        historyYamlDict = dict()
        historyYamlDict['CLEAN_AREA_TOTAL'] = self.cleanAreaTotal
        historyYamlDict['MILEAGE_TOTAL'] = self.mileageTotal
        historyYamlDict['CLEAN_TIME_TOTAL'] = self.cleanTimeTotal
        historyYamlDict['CLEAN_DISTANCE_TOTAL'] = self.cleanDistanceTotal
        try:
            with open(self.historyYamlPath, "w") as f:
                dump(historyYamlDict, f)
                f.flush()
                fsync(f)
            with open(self.historyYamlPathBK, "w") as f:
                dump(historyYamlDict, f)
                f.flush()
                fsync(f)
        except Exception as e:
            if not exists(self.yamlPath):
                makedirs(self.yamlPath)
            if not exists(self.yamlPathBK):
                makedirs(self.yamlPathBK)
            print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] write history yaml error: ' + str(e)))

    def record_brush_yaml(self):
        if not isfile(self.brushYamlPath):
            self.brushRemainTime = self.brushLife
        brushYamlDict = dict()
        brushYamlDict["BRUSH"] = self.brushRemainTime
        try:
            with open(self.brushYamlPath, "w") as f:
                dump(brushYamlDict, f)
                f.flush()
                fsync(f)
            with open(self.brushYamlPathBK, "w") as f:
                dump(brushYamlDict, f)
                f.flush()
                fsync(f)
        except Exception as e:
            if not exists(self.yamlPath):
                makedirs(self.yamlPath)
            if not exists(self.yamlPathBK):
                makedirs(self.yamlPathBK)
            print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] write brush yaml error: ' + str(e)))

    def record_pedrail_yaml(self):
        if not isfile(self.pedrailYamlPath):
            self.pedrailRemainTime = self.pedrailLife
        pedrailYamlDict = dict()
        pedrailYamlDict["PEDRAIL"] = self.pedrailRemainTime
        try:
            with open(self.pedrailYamlPath, "w") as f:
                dump(pedrailYamlDict, f)
                f.flush()
                fsync(f)
            with open(self.pedrailYamlPathBK, "w") as f:
                dump(pedrailYamlDict, f)
                f.flush()
                fsync(f)
        except Exception as e:
            if not exists(self.yamlPath):
                makedirs(self.yamlPath)
            if not exists(self.yamlPathBK):
                makedirs(self.yamlPathBK)
            print('\033[1;31m%s\033[0m\r' % ('[Rec ERR] write pedrail yaml error: ' + str(e)))

    def calc_brush_life_expectance(self):
        if self.cleanMotorFlag:
            self.brushRemainTime = max(self.brushRemainTime-1, 0)

    def calc_pedrail_life_expectance(self):
        if self.linear != 0 or self.angular != 0:
            if self.angular != 0:
                self.pedrailRemainTime = max(self.pedrailRemainTime-1, 0)
            elif self.linear != 0:
                self.pedrailLinearCounter += 1
                if self.pedrailLinearCounter > 10:
                    self.pedrailRemainTime = max(self.pedrailRemainTime-1, 0)
                    self.pedrailLinearCounter = 0

    def calc_clean_area_and_mileage(self):
        cleanAreaNow = self.cleanAreaNow
        if cleanAreaNow - self.prevCleanArea > 0:
            self.cleanAreaTotal += (cleanAreaNow - self.prevCleanArea)
        self.prevCleanArea = cleanAreaNow
        mileageNow = self.mileageNow
        if mileageNow - self.prevMileage > 0 and mileageNow - self.prevMileage < 10:
            self.mileageTotal += (mileageNow - self.prevMileage)
        self.prevMileage = mileageNow

    def calc_clean_distance(self):
        mileageNow = self.mileageNow
        if self.navFlag:
            self.cleanDistanceNow = mileageNow - self.cleanDistanceStart
        else:
            self.cleanDistanceNow = 0
            self.cleanDistanceStart = mileageNow
        if self.cleanDistanceNow - self.prevCleanDistance > 0:
            self.cleanDistanceTotal += (self.cleanDistanceNow - self.prevCleanDistance)
        self.prevCleanDistance = self.cleanDistanceNow

    def calc_clean_time(self):
        if self.navFlag:
            self.cleanTimeNow += 1
        else:
            self.cleanTimeNow = 0
        if self.cleanTimeNow - self.prevCleanTime > 0:
            self.cleanTimeTotal += (self.cleanTimeNow - self.prevCleanTime)
        self.prevCleanTime = self.cleanTimeNow

    def pack_robot_info(self, _robotData):
        info = dict()
        info["time"] = localtime()
        info["connection_imu"] = _robotData['imu']['connect']
        info["connection_board_Master"] = _robotData['boardMaster']['connect']
        info["connection_board_Slave"] = _robotData['boardSlave']['connect']
        info["connection_drive_motor"] = _robotData['driveMotor']['connect']
        info["connection_battery"] = _robotData['battery']['connect']
        info["connection_sensor"] = _robotData['sonar']['connect']

        self.checkDisconnectStatus(_robotData['boardMaster']['connect'], _robotData['imu']['connect'], _robotData['camera']['connect'])
        info["clean_motor"] = _robotData['uiCommand']["cleanMotorFlag"]
        info["disconnect_board_master"] = self.boardDisconnectCount
        info["disconnect_imu"] = self.IMUDisconnectCount
        info["disconnect_camera"] = self.cameraDisconnectCount
        info["retry_board_master"] = _robotData['boardMaster']['retryCounter']
        info["retry_imu"] = _robotData['imu']['retryCounter']

        info["robotState"] = _robotData['navigation']['robotState']
        info["navState"] = _robotData['navigation']['navState']
        info["clean_count"] = _robotData['navigation']['cleanCountNow']
        info["velocity_linear"] = _robotData['main']['controlVelocity'][0]
        info["velocity_angular"] = _robotData['main']['controlVelocity'][1]

        info["camera_frame_number"] = _robotData['camera']['frameNumber']
        info["camera_status"] = _robotData['camera']['status']
        info["camera_location"] = _robotData['camera']['location']
        info["camera_angle"] = _robotData['camera']['angle']
        info["camera_data_0"] = _robotData['camera']['cameraDebugData']['data0']
        info["camera_data_1"] = _robotData['camera']['cameraDebugData']['data1']
        info["camera_data_2"] = _robotData['camera']['cameraDebugData']['data2']
        info["camera_data_3"] = _robotData['camera']['cameraDebugData']['data3']
        info["camera_data_4"] = _robotData['camera']['cameraDebugData']['data4']
        info["camera_data_5"] = _robotData['camera']['cameraDebugData']['data5']

        info["camera_direction"] = _robotData['navigation']['cameraDirection']
        info["camera_correction_step"] = _robotData['navigation']['slipCameraCorrectionCount']
        info["detect_side_mode"] = _robotData['navigation']['detectSideMode']
        info["initial_yaw"] = _robotData['navigation']['initialYaw']

        info["imu_roll"] = _robotData['imu']['euler'][0]
        info["imu_pitch"] = _robotData['imu']['euler'][1]
        info["imu_yaw"] = _robotData['imu']['euler'][2]

        info["imu_acceleration_x"] = _robotData['imu']['acceleration'][0]
        info["imu_acceleration_y"] = _robotData['imu']['acceleration'][1]
        info["imu_acceleration_z"] = _robotData['imu']['acceleration'][2]

        info["odom_x"] = _robotData['driveMotor']['odometry'][0]
        info["odom_y"] = _robotData['driveMotor']['odometry'][1]
        info["odom_th"] = _robotData['driveMotor']['odometry'][2]

        info["sensor_0"] = _robotData['sonar']['range'][0]
        info["sensor_1"] = _robotData['sonar']['range'][1]
        info["sensor_2"] = _robotData['sonar']['range'][2]
        info["sensor_3"] = _robotData['sonar']['range'][3]
        info["sensor_4"] = _robotData['sonar']['range'][4]
        info["sensor_5"] = _robotData['sonar']['range'][5]
        info["sensor_6"] = _robotData['sonar']['range'][6]
        info["sensor_7"] = _robotData['sonar']['range'][7]

        info["battery_voltage"] = _robotData['battery']['voltage']
        info["battery_current"] = _robotData['battery']['current']
        info["battery_soc"] = _robotData['battery']['SOC']
        info["battery_cycle"] = _robotData['battery']['cycle']
        info["battery_soh"] = _robotData['battery']['SOH']
        info["battery_temperature"] = _robotData['battery']['temperature']

        info["brush_remain_time"] = _robotData['recorder']['brushRemainTime']
        info["pedrail_remain_time"] = _robotData['recorder']['pedrailRemainTime']
        info["clean_area_now"] = _robotData['recorder']['cleanAreaNow']
        info["clean_area_total"] = _robotData['recorder']['cleanAreaTotal']
        info["clean_distance_now"] = _robotData['recorder']['cleanDistanceNow']
        info["clean_distance_total"] = _robotData['recorder']['cleanDistanceTotal']
        info["clean_time_now"] = _robotData['recorder']['cleanTimeNow']
        info["clean_time_total"] = _robotData['recorder']['cleanTimeTotal']
        info["mileage_now"] = _robotData['recorder']['mileageNow']
        info["mileage_total"] = _robotData['recorder']['mileageTotal']

        info["temperature_1"] = _robotData['sensor']['temperature'][0]
        info["temperature_2"] = _robotData['sensor']['temperature'][1]
        info["humidity"] = _robotData['sensor']['humidity']
        info["current_1"] = _robotData['sensor']['current'][0]
        info["current_2"] = _robotData['sensor']['current'][1]
        info["current_3"] = _robotData['sensor']['current'][2]
        info["current_4"] = _robotData['sensor']['current'][3]
        info["errorCode"] = _robotData['main']['errorCode']

        return info

    def checkDisconnectStatus(self, _currentBoard, _currentIMU, _currentCamera):
        if self.prevBoardConnectStatus != _currentBoard:
            self.prevBoardConnectStatus = _currentBoard
            if not _currentBoard:
                self.boardDisconnectCount += 1
        if self.prevIMUConnectStatus != _currentIMU:
            self.prevIMUConnectStatus = _currentIMU
            if not _currentIMU:
                self.IMUDisconnectCount += 1
        if self.prevCameraConnectStatus != _currentCamera:
            self.prevCameraConnectStatus = _currentCamera
            if not _currentCamera:
                self.cameraDisconnectCount += 1
