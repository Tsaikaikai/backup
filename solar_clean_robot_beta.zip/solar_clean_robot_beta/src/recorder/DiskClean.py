import time
import datetime
import os
import shutil
from threading import Thread
from threading import Event
from os.path import join

if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")

from utility import Stream

class DiskClean(Thread):
    def __init__(self, _robotType=""):
        # Initial Thread
        Thread.__init__(self)
        print('[DiskClean INFO] Initial DiskClean\r')
        self.finished = Event()
        self.loadConfigStatus = False

        # Config Path
        global configPath
        configPath = join(configPath, _robotType)

        # Setting
        self._setting = dict()
        self._sleep = 1

    def run(self):
        try:
            self._setting = Stream.load_config(
                join(configPath, 'DiskCleanSetting.yaml'))
            self._sleep = self._setting['SLEEP_TIME']

            self.loadConfigStatus = True
        except Exception as _exception:
                print('\033[1;31m%s\033[0m\r'
                      % ('[DiskClean ERROR] Load DiskClean config error: '
                      + str(_exception)))

        if not self.loadConfigStatus:
            return

        while not self.finished.is_set():
            if 'PLANE' not in self._setting:
                time.sleep(1)
                continue

            for p in self._setting['PLANE']:
                if 'Type' not in p:
                    continue
                if 'Path' not in p:
                    continue
                if 'Parameter' not in p:
                    continue

                if p['Type'] == 'byDay':                    
                    self._clean_by_day(p['Path'], p['Parameter'])
                elif p['Type'] == 'byHour':
                    self._clean_by_hour(p['Path'], p['Parameter'])
                elif p['Type'] == 'byCount':
                    self._clean_by_count(p['Path'], p['Parameter'])
                elif p['Type'] == 'byVolume':
                    self._clean_by_volume(p['Path'], p['Parameter'])
            
            time.sleep(self._sleep)

    def stop(self):
        self.finished.set()
        time.sleep(0.1)

    def _clean_by_day(self, path, days):
        print('Clean by Day:', path, days)
        now_time = datetime.datetime.now()
        for root, dirs, files in os.walk(path):
            for f in files:
                full_path = os.path.join(root, f)
                create_time = datetime.datetime.fromtimestamp(
                    os.path.getctime(full_path))

                duration = now_time - create_time
                if duration.days < days:
                    continue

                os.remove(full_path)

            for d in dirs:
                full_path = os.path.join(root, d)

                if not os.listdir(full_path):
                    os.rmdir(full_path)

    def _clean_by_hour(self, path, hours):
        print('Clean by Hour:', path, hours)
        now_time = datetime.datetime.now()
        for root, dirs, files in os.walk(path):
            for f in files:
                full_path = os.path.join(root, f)
                create_time = datetime.datetime.fromtimestamp(
                    os.path.getctime(full_path))
                duration = now_time - create_time

                duration_hours = duration.days * 24 + duration.seconds/3600
                if duration_hours < hours:
                    continue

                os.remove(full_path)

            for d in dirs:
                full_path = os.path.join(root, d)

                if not os.listdir(full_path):
                    os.rmdir(full_path)

    def _clean_by_volume(self, path, mb):
        print('Clean by Volume:', path, mb)
        for root, dirs, files in os.walk(path):
            for f in files:
                full_path = os.path.join(root, f)
                total, used, free = shutil.disk_usage('/')

                free_mb = free // (2**20)
                if free_mb > mb:
                    continue

                os.remove(full_path)

            for d in dirs:
                full_path = os.path.join(root, d)

                if not os.listdir(full_path):
                    os.rmdir(full_path)

    def _clean_by_count(self, path, counts):
        print('Clean by Count:', path, counts)
        file_list = []
        dir_list = []
        for root, dirs, files in os.walk(path):
            for f in files:
                full_path = os.path.join(root, f)
                file_list.append(full_path)

            for d in dirs:
                full_path = os.path.join(root, d)
                dir_list.append(full_path)

        for f in file_list[0:-counts]:
            os.remove(f)

        for d in dir_list:
            if not os.listdir(d):
                os.rmdir(d)
