import requests


class APIClient():
    def __init__(self, protocol="http", host="localhost", port="5000", path="api"):
        self.__protocol = protocol
        self.__host = host
        self.__port = port
        self.__path = path

        self.__url = self.__protocol + "://" + self.__host + ":" + self.__port + "/" + self.__path
        # self.__headers = {'Content-Type': 'application/octet-stream'}

    def post(self, data):
        response = requests.post(self.__url+data+'/', timeout=20)
        return response
