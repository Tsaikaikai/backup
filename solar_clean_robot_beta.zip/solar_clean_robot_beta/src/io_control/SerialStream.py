import serial
import time
import os
import sys
from subprocess import Popen, PIPE

import struct
from os.path import join

if not (os.path.isfile("main.py") or os.path.isfile("main.bin")):
    sys.path.append("..")

from io_control import PackageFormat
from utility import CRCTable


class SerialStream():
    def __init__(self, _comPortName, _baudrate, _packageLength, _payloadLength=None, _arduinoFirmwareVersion=0):
        self.__crcTable = CRCTable.crcXmodemTable
        self.msg = [b''] * _packageLength
        self.receivedPackage = b''
        self.transmitPackage = b''

        self.connectStatus = False
        self.errorFlag = False
        self.finishFlag = False
        self.initialFlag = False

        self.__port = _comPortName
        self.__baudrate = _baudrate
        self.__packageLength = _packageLength
        self.__payloadLength = _payloadLength
        self.__arduinoFirmware = _arduinoFirmwareVersion
        self.__retryCounter = 0

        self.serialPort = None

    def initial_serial(self) -> bool:
        try:
            self.serialPort = serial.Serial(port=self.__port, baudrate=self.__baudrate, bytesize=8, parity='N', stopbits=1, timeout=0.1, xonxoff=False, rtscts=False)
            self.serialPort.flushInput()
            time.sleep(1)
            self.reSend = True
            self.errorFlag = False
            # self.serialPort = _serialPort
            return True
        except:
            self.connectStatus = False
            self.errorFlag = True
            while self.errorFlag and not self.finishFlag:
                self.reconnect()
                time.sleep(1)
            return False

    def reconnect(self):
        self.__retryCounter = 0
        self.errorFlag = True
        self.reSend = True
        try:
            if self.serialPort:
                self.serialPort.close()
                _echo = Popen(['echo', 'robot'], stdout=PIPE)
                p = Popen(['sudo', '-S', 'udevadm', 'trigger', self.__port], stdin=_echo.stdout, stdout=PIPE)
            else:
                self.serialPort = serial.Serial(port=self.__port, baudrate=self.__baudrate, bytesize=8, parity='N', stopbits=1, timeout=0.1, xonxoff=False, rtscts=False)
                self.serialPort.flushInput()
            self.errorFlag = False

        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] ' + str(_exception)))

    def get_retry_counter(self) -> int:
        return self.__retryCounter

    def decode_arduino_package(self) -> bool:
        _result = False
        if self.__arduinoFirmware >= 0x110:
            if len(self.receivedPackage) >= self.__packageLength:
                if self.receivedPackage[0:1] == PackageFormat.PackageFormat.HEADER.value.to_bytes(1, 'little') and self.receivedPackage[1:2] == PackageFormat.PackageFormat.STX.value.to_bytes(1, 'little') and self.receivedPackage[self.__packageLength-1:self.__packageLength] == PackageFormat.PackageFormat.FOOTER.value.to_bytes(1, 'little'):
                    _crc = self.__crc16_xmodem_with_table(b'\x00\x00', self.receivedPackage[0:34])
                    _crc = self.__crc16_xmodem_with_table(_crc, self.receivedPackage[36:38])
                    if _crc == self.receivedPackage[34:36]:
                        _result = True
                        self.initialFlag = True
                        self.__retryCounter = 0
                    else:
                        self.__retryCounter += 1
                        self.serialPort.flushInput()
                        self.receivedPackage = b''
                    time.sleep(0.005)
                    # print(_crc == self.receivedPackage[34:36])
                    # print(self.receivedPackage.hex())
                else:
                    self.receivedPackage = self.receivedPackage[1:]
        elif self.__arduinoFirmware >= 0x100:
            if len(self.receivedPackage) >= self.__packageLength:
                if self.receivedPackage[0:1] == PackageFormat.PackageFormat.HEADER.value.to_bytes(1, 'little') and self.receivedPackage[1:2] == PackageFormat.PackageFormat.STX.value.to_bytes(1, 'little') and self.receivedPackage[self.__packageLength-1:self.__packageLength] == PackageFormat.PackageFormat.FOOTER.value.to_bytes(1, 'little'):
                    _crc = self.__crc16_xmodem_with_table(b'\x00\x00', self.receivedPackage[0:26])
                    _crc = self.__crc16_xmodem_with_table(_crc, self.receivedPackage[28:30])
                    if _crc == self.receivedPackage[26:28]:
                        _result = True
                        self.initialFlag = True
                        self.__retryCounter
                    else:
                        self.serialPort.flushInput()
                        self.receivedPackage = b''
                        self.__retryCounter += 1
                    time.sleep(0.005)
                    # print(_crc == self.receivedPackage[26:28])
                    # print(self.receivedPackage.hex())
                else:
                    self.receivedPackage = self.receivedPackage[1:]
        elif self.__arduinoFirmware >= 0x000:
            if self.receivedPackage[0:1] == PackageFormat.PackageFormat.STX.value.to_bytes(1, 'little') and self.receivedPackage[self.__packageLength-1:self.__packageLength] == PackageFormat.PackageFormat.ETX.value.to_bytes(1, 'little'):
                _result = True
                self.initialFlag = True
                # print(self.receivedPackage.hex())
            else:
                self.receivedPackage = self.receivedPackage[1:]

        return _result

    def decode_imu_package(self) -> bool:
        _result = False
        try:
            if len(self.receivedPackage) >= self.__packageLength:
                if self.receivedPackage[0:1] == PackageFormat.PackageFormat.PRE.value.to_bytes(1, 'little') and self.receivedPackage[1:2] == PackageFormat.PackageFormat.TYPE.value.to_bytes(1, 'little'):
                    _crc = b'\x00\x00'

                    self.__payloadLength = int.from_bytes(self.receivedPackage[2:4], "little")
                    _crc = self.__crc16_xmodem_with_table(_crc, self.receivedPackage[0:4])
                    _crc = self.__crc16_xmodem_with_table(_crc, self.receivedPackage[6:self.__packageLength])

                    _msgCRC = int.from_bytes(self.receivedPackage[4:6], "little")
                    if self.receivedPackage[4:6] == _crc:
                        self.connectStatus = True
                        _result = True
                        self.__retryCounter = 0
                    else:
                        print(self.receivedPackage)
                        _data = dict()
                        _data['packageLabel'] = self.receivedPackage[6]
                        _data['deviceID'] = self.receivedPackage[7]
                        _data['airPressure'] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[10:14])))
                        _data['timeStamp'] = int.from_bytes(self.receivedPackage[14: 18], "little")
                        _data['acceleration'] = [0.0] * 3
                        _data['acceleration'][0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[18:22])))
                        _data['acceleration'][1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[22:26])))
                        _data['acceleration'][2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[26:30])))
                        _data['gyroscope'] = [0.0] * 3
                        _data['gyroscope'][0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[30:34])))
                        _data['gyroscope'][1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[34:38])))
                        _data['gyroscope'][2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[38:42])))
                        _data['magnetic'] = [0.0] * 3
                        _data['magnetic'][0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[42:46])))
                        _data['magnetic'][1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[46:50])))
                        _data['magnetic'][2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[50:54])))
                        _data['euler'] = [0.0] * 3
                        _data['euler'][0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[54:58])))
                        _data['euler'][1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[58:62])))
                        _data['euler'][2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[62:66]))) % 360
                        _data['quaternion'] = [0.0] * 4
                        _data['quaternion'][0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[66:70])))
                        _data['quaternion'][1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[70:74])))
                        _data['quaternion'][2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[74:78])))
                        _data['quaternion'][3] = float('.'.join(str(ele) for ele in struct.unpack('f', self.receivedPackage[78:82])))
                        print(_data)
                        print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] IMU crc error'))
                        self.serialPort.flushInput()
                        self.receivedPackage = b''
                        self.__retryCounter += 1
                    # print(self.receivedPackage.hex())
                else:
                    self.receivedPackage = self.receivedPackage[1:]

            return _result
        except:
            return False

    def __crc16_xmodem_with_table(self, _currentCrc, _inputData):
        _crc = _currentCrc
        for _index in range(0, len(_inputData), 2):
            _crc = (int.from_bytes(_crc, 'big', signed=False) ^ int.from_bytes(_inputData[_index:_index+2], 'little', signed=False)).to_bytes(2, 'little', signed=False)
            _crc = self.__crcTable[int.from_bytes(_crc, 'little', signed=False)]
        return _crc

    def readline_serial(self):
        if self.serialPort == None:
            self.reconnect()
            time.sleep(1)
        else:
            self.receivedPackage = self.serialPort.readline()
        if self.errorFlag and len(self.receivedPackage) == 0:
            self.reconnect()
            time.sleep(1)
        time.sleep(0.001)

    def read_serial(self):
        self.receivedPackage += self.serialPort.read()
        if self.errorFlag and len(self.receivedPackage) == 0:
            self.reconnect()
            time.sleep(1)

    def write_serial(self):
        self.serialPort.write(self.transmitPackage)
        time.sleep(0.001)
        self.transmitPackage = b''
        return True
