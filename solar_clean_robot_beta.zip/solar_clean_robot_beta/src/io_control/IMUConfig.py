class IMUData():
    def __init__(self):
        self.deviceID = 0
        self.timeStamp = 0
        self.acceleration = [0.0, 0.0, 0.0]  # acceleration x, y, z
        self.gyroscope = [0.0, 0.0, 0.0]  # gyroscope x, y, z
        self.magnetic = [0.0, 0.0, 0.0]  # magnetic x, y, z
        self.euler = [0.0, 0.0, 0.0]  # Pitch, Roll, Yaw
        self.quaternion = [0.0, 0.0, 0.0, 0.0]
        self.packageLabel = 0
        self.airPressure = 0.0
        self.imu = {"connect": False, "retryCounter": 0, "errorCode": 0, "euler": [0.0, 0.0, 0.0], "acceleration": [0.0, 0.0, 0.0]}
