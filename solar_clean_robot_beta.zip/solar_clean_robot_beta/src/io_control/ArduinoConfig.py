import os
import sys

if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from io_control import PackageFormat


class ArduinoPackage():
    def __init__(self, _firmwareVersion) -> None:
        if _firmwareVersion >= 0x320:
            self.dataPackageLength = 67
            self.commandPackageLength = 17
        elif _firmwareVersion >= 0x300:
            self.dataPackageLength = 66
            self.commandPackageLength = 16


class ArduinoData():
    def __init__(self, _firmwareVersion):
        # Board Parameter
        if _firmwareVersion >= 0x300:
            self.masterBoard = {"timeStamp": 0, "connect": False, "retryCounter": 0, "errorCode": 0}
            self.slaveBoard = {"timeStamp": 0, "connect": False, "errorCode": 0}
            self.sonar = {"connect": False, "errorCode": 0, "cliffState": [True, True, True, True, True, True, True, True], "range": [-2, -2, -2, -2, -2, -2, -2, -2]}
            self.battery = {"connect": False, "errorCode": 0, "voltage": 0.0, "current": 0.0, "temperature": 0.0, "SOC": -2, "SOH": 0, "cycle": 0}
            self.driveMotor = {"connect": False, "errorCode": 0, "state": PackageFormat.PackageFormat.DRIVE_MOTOR_STOP.value, "velocity": [0.0, 0.0], "odometry": [0.0, 0.0, 0.0], "mileage": 0.0}
            self.cleanMotor = {"state": PackageFormat.PackageFormat.RELAY_ALL_OFF.value}
            self.button = {"power": False, "clean": False}
            self.sensor = {"temperature": [0.0, 0.0], "humidity": 0.0, "current": [0.0, 0.0, 0.0, 0.0]}
            self.controller = {"connect": False, "remoteFlag": False, "navFlag": False}
            self.tempValue = {"mileageRawData": 0.0, "preMileage": 0.0, "crcCheck": False}


class ArduinoCommand():
    def __init__(self, _firmwareVersion):
        if _firmwareVersion >= 0x300:
            self.cleanMotor = {"state": PackageFormat.PackageFormat.RELAY_ALL_OFF.value}
            self.driveMotor = {"state": PackageFormat.PackageFormat.DRIVE_MOTOR_STOP.value, "velocity": [0.0, 0.0]}
            self.beeper = {"state": PackageFormat.PackageFormat.BEEPER_OFF.value}
