from IMUCommunication import IMUCommunication
import time
import serial

_comPort = '/dev/ttyUSB0'
_baudRate = 115200
_str = ''


def get_info():
    ser = serial.Serial(_comPort, _baudRate)
    ser.write(b'AT+EOUT=0\r\n')
    time.sleep(0.1)
    ser.flushInput()
    time.sleep(0.1)
    ser.write(b'AT+INFO\r\n')
    time.sleep(0.1)
    global _str
    for i in range(9):
        _str = ser.readline()
        print(_str)
    time.sleep(0.1)

    ser.write(b'AT+EOUT=1\r\n')
    time.sleep(0.1)
    ser.close()


def main():
    # IMU INFO Test
    get_info()

    # Start IMU Thread
    _imuCommunicationThread = IMUCommunication("Beta_3_1")
    _imuCommunicationThread.start()
    time.sleep(3)

    _errorCounter = 0
    _timer = 0
    try:
        print("Test Start!")

        # IMU Packet Loss Test
        while _timer < 500:
            _preTimeStamp = _imuCommunicationThread.get_time_stamp()
            _now = _imuCommunicationThread.get_time_stamp()
            while (_now - _preTimeStamp == 0):
                _now = _imuCommunicationThread.get_time_stamp()
                time.sleep(0.005)
            _timer += 1
            if _timer % 50 == 0:
                print(_timer/50)
            if _now - _preTimeStamp > 20:
                _errorCounter += 1

        print("Packet Loss Rate:" + str(_errorCounter/5) + "%")

        # IMU Axis Test

        print("Please test Pitch(X axis)")
        time.sleep(1)
        _timer = 0
        while _timer < 500:
            time.sleep(0.01)
            _timer += 1
            print(_imuCommunicationThread.get_euler()[1])

        print("Please test Roll(Y axis)")
        time.sleep(1)
        _timer = 0
        while _timer < 500:
            time.sleep(0.01)
            _timer += 1
            print(_imuCommunicationThread.get_euler()[0])

        print("Please test Yaw(Z axis)")
        time.sleep(1)
        _timer = 0
        while _timer < 500:
            time.sleep(0.01)
            _timer += 1
            print(_imuCommunicationThread.get_euler()[2])

        if _str == b'OK\r\n':
            print('\033[1;32m%s\033[0m\r' % ("IMU INFO OK"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("IMU INFO NG"))

        print("Packet Loss Rate:" + str(_errorCounter/5) + "%")
        if _errorCounter / 5 < 5:
            print('\033[1;32m%s\033[0m\r' % ("IMU Package OK"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("IMU Package NG"))

        _imuCommunicationThread.stop()
        print("RA_IMUTest.py shutdown")
    except KeyboardInterrupt:
        _imuCommunicationThread.stop()
        print("RA_IMUTest.py shutdown")


if __name__ == "__main__":
    main()
