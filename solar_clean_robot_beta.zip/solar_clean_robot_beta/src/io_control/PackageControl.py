import os
import sys
import struct
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from io_control import ArduinoConfig, APIClient, SocketClient, PackageFormat
from utility import Stream, CRCTable, RobotConfig


class PackageControl():
    def __init__(self, _arduinoSetting) -> None:
        self.__arduinoSetting = _arduinoSetting
        self.__arduinoPackage = ArduinoConfig.ArduinoPackage(self.__arduinoSetting["FIRMWARE_VERSION"])
        # self.__arduinoData = ArduinoConfig.ArduinoData(self.__arduinoSetting["FIRMWARE_VERSION"])
        self.__arduinoCommand = ArduinoConfig.ArduinoCommand(self.__arduinoSetting["FIRMWARE_VERSION"])

    def __crc16_xmodem_with_table(self, _currentCrc, _inputData):
        _crc = _currentCrc
        for _index in range(0, len(_inputData), 2):
            _crc = (int.from_bytes(_crc, 'big', signed=False) ^ int.from_bytes(_inputData[_index: _index+2], 'little', signed=False)).to_bytes(2, 'little', signed=False)
            _crc = CRCTable.crcXmodemTable[int.from_bytes(_crc, 'little', signed=False)]
        return _crc

    def decode_arduino_package(self, _inputData, _preData, _deviceNumber=0) -> dict():
        _outputData = _preData
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x310:
            if len(_inputData) == self.__arduinoPackage.dataPackageLength and _inputData[: 1] == b'\xFF' and _inputData[-2: -1] == b'\xEE':
                if _inputData[63: 65] != self.__crc16_xmodem_with_table(b'\x00\x00', _inputData[1: 63]):
                    _outputData.tempValue["crcCheck"] = False
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Board Data CRC Checksum Error!'))
                else:
                    _outputData.tempValue["crcCheck"] = True
                    _outputData.masterBoard["timeStamp"] = int.from_bytes(_inputData[1: 5], "little", signed=False)
                    _outputData.masterBoard["connect"] = True
                    _outputData.slaveBoard["connect"] = bool(int.from_bytes(_inputData[5: 6], "little", signed=False) & 0x80)
                    _outputData.button["power"] = bool(int.from_bytes(_inputData[5: 6], "little", signed=False) & 0x01)
                    _outputData.button["clean"] = bool(int.from_bytes(_inputData[5: 6], "little", signed=False) & 0x02)
                    _outputData.driveMotor["connect"] = True
                    _outputData.driveMotor["odometry"][0] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[6: 10])))
                    _outputData.driveMotor["odometry"][1] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[10: 14])))
                    _outputData.driveMotor["odometry"][2] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[14: 18])))
                    _outputData.tempValue["mileageRawData"] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[18: 22])))
                    if _outputData.tempValue["mileageRawData"] - _outputData.tempValue["preMileage"] < 10 and _outputData.tempValue["mileageRawData"] - _outputData.tempValue["preMileage"] > 0:
                        _outputData.driveMotor["mileage"] += _outputData.tempValue["mileageRawData"] - _outputData.tempValue["preMileage"]
                    _outputData.tempValue["preMileage"] = _outputData.tempValue["mileageRawData"]
                    _outputData.slaveBoard["timeStamp"] = _outputData.masterBoard["timeStamp"]
                    _outputData.sonar["range"][0] = int.from_bytes(_inputData[22: 24], "little", signed=True)
                    _outputData.sonar["range"][1] = int.from_bytes(_inputData[24: 26], "little", signed=True)
                    _outputData.sonar["range"][2] = int.from_bytes(_inputData[26: 28], "little", signed=True)
                    _outputData.sonar["range"][3] = int.from_bytes(_inputData[28: 30], "little", signed=True)
                    _outputData.sonar["range"][4] = int.from_bytes(_inputData[30: 32], "little", signed=True)
                    _outputData.sonar["range"][5] = int.from_bytes(_inputData[32: 34], "little", signed=True)
                    _outputData.sonar["range"][6] = int.from_bytes(_inputData[34: 36], "little", signed=True)
                    _outputData.sonar["range"][7] = int.from_bytes(_inputData[36: 38], "little", signed=True)
                    for i in range(0, 8):
                        if _outputData.sonar["range"][i] >= 0:
                            _outputData.sonar["range"][i] += self.__arduinoSetting['SONAR_BIAS'][i]
                            if _outputData.sonar["range"][i] >= self.__arduinoSetting['SONAR_UPPER_LIMIT'] or _outputData.sonar["range"][i] < self.__arduinoSetting['SONAR_LOWER_LIMIT']:
                                _outputData.sonar["cliffState"][i] = True
                            else:
                                _outputData.sonar["cliffState"][i] = False
                            _outputData.sonar["range"][i] /= 10.0
                        elif _outputData.sonar["range"][i] == -2:
                            pass
                        else:
                            _outputData.sonar["cliffState"][i] = True
                    if -2 in _outputData.sonar["range"]:
                        _outputData.sonar["connect"] = False
                    else:
                        _outputData.sonar["connect"] = True
                    _outputData.sensor["humidity"] = int.from_bytes(_inputData[38: 40], "little", signed=True)
                    _outputData.sensor["temperature"][0] = int.from_bytes(_inputData[40: 42], "little", signed=True)
                    _outputData.sensor["temperature"][1] = int.from_bytes(_inputData[42: 44], "little", signed=True)
                    _outputData.sensor["current"][0] = int.from_bytes(_inputData[46: 48], "little", signed=True)
                    _outputData.sensor["current"][1] = int.from_bytes(_inputData[48: 50], "little", signed=True)
                    _outputData.sensor["current"][2] = int.from_bytes(_inputData[50: 52], "little", signed=True)
                    _outputData.sensor["current"][3] = int.from_bytes(_inputData[52: 54], "little", signed=True)
                    _outputData.battery["SOC"] = int.from_bytes(_inputData[54: 55], "little", signed=True)
                    if _outputData.battery["SOC"] == -1:
                        _outputData.battery["connect"] = False
                    else:
                        _outputData.battery["connect"] = True
                    _outputData.battery["SOH"] = int.from_bytes(_inputData[55: 56], "little", signed=True)
                    _outputData.battery["voltage"] = int.from_bytes(_inputData[56: 58], "little", signed=True) / 100.0
                    _outputData.battery["current"] = int.from_bytes(_inputData[58: 60], "little", signed=True) / 100.0
                    _outputData.battery["cycle"] = int.from_bytes(_inputData[60: 61], "little", signed=True)
                    _outputData.battery["temperature"] = int.from_bytes(_inputData[61: 63], "little", signed=True) / 10.0
            else:
                print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Board Data Length Error!'))
        elif self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
            if _deviceNumber == 0 and len(_inputData) == self.__arduinoPackage.dataPackageLength:
                if _inputData[63: 65] != self.__crc16_xmodem_with_table(b'\x00\x00', _inputData[1: 63]):
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Board Data CRC Checksum Error!'))
                else:
                    _outputData.masterBoard["timeStamp"] = int.from_bytes(_inputData[1: 5], "little", signed=False)
                    _outputData.driveMotor["odometry"][0] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[6: 10])))
                    _outputData.driveMotor["odometry"][1] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[10: 14])))
                    _outputData.driveMotor["odometry"][2] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[14: 18])))
                    _outputData.driveMotor["mileage"] = float('.'.join(str(ele) for ele in struct.unpack('f', _inputData[18: 22])))
            elif _deviceNumber == 1 and len(_inputData) == self.__arduinoPackage.dataPackageLength:
                if _inputData[63: 65] != self.__crc16_xmodem_with_table(b'\x00\x00', _inputData[1: 63]):
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Board Data CRC Checksum Error!'))
                else:
                    _outputData.slaveBoard["timeStamp"] = int.from_bytes(_inputData[1: 5], "little", signed=False)
                    _outputData.sonar["range"][0] = int.from_bytes(_inputData[22: 24], "little", signed=True)
                    _outputData.sonar["range"][1] = int.from_bytes(_inputData[24: 26], "little", signed=True)
                    _outputData.sonar["range"][2] = int.from_bytes(_inputData[26: 28], "little", signed=True)
                    _outputData.sonar["range"][3] = int.from_bytes(_inputData[28: 30], "little", signed=True)
                    _outputData.sonar["range"][4] = int.from_bytes(_inputData[30: 32], "little", signed=True)
                    _outputData.sonar["range"][5] = int.from_bytes(_inputData[32: 34], "little", signed=True)
                    _outputData.sonar["range"][6] = int.from_bytes(_inputData[34: 36], "little", signed=True)
                    _outputData.sonar["range"][7] = int.from_bytes(_inputData[36: 38], "little", signed=True)
                    for i in range(0, 8):
                        if _outputData.sonar["range"][i] >= 0:
                            _outputData.sonar["range"][i] += self.__arduinoSetting['SONAR_BIAS'][i]
                            if _outputData.sonar["range"][i] >= self.__arduinoSetting['SONAR_UPPER_LIMIT'] or _outputData.sonar["range"][i] <= self.__arduinoSetting['SONAR_LOWER_LIMIT']:
                                _outputData.sonar["cliffState"][i] = True
                            else:
                                _outputData.sonar["cliffState"][i] = False
                            _outputData.sonar["range"][i] /= 10.0
                        elif _outputData.sonar["range"][i] == -2:
                            pass
                        else:
                            _outputData.sonar["cliffState"][i] = True
                    if -2 in _outputData.sonar["range"]:
                        _outputData.sonar["connect"] = False
                    else:
                        _outputData.sonar["connect"] = True
                    _outputData.sensor["humidity"] = int.from_bytes(_inputData[38: 40], "little", signed=True)
                    _outputData.sensor["temperature"][0] = int.from_bytes(_inputData[40: 42], "little", signed=True)
                    _outputData.sensor["temperature"][1] = int.from_bytes(_inputData[42: 44], "little", signed=True)
                    _outputData.sensor["current"][0] = int.from_bytes(_inputData[44: 46], "little", signed=True)
                    _outputData.sensor["current"][1] = int.from_bytes(_inputData[46: 48], "little", signed=True)
                    _outputData.sensor["current"][2] = int.from_bytes(_inputData[48: 50], "little", signed=True)
                    _outputData.sensor["current"][3] = int.from_bytes(_inputData[50: 52], "little", signed=True)
                    _outputData.battery["SOC"] = int.from_bytes(_inputData[54: 55], "little", signed=True)
                    if _outputData.battery["SOC"] == -1:
                        _outputData.battery["connect"] = False
                    else:
                        _outputData.battery["connect"] = True
                    _outputData.battery["SOH"] = int.from_bytes(_inputData[55: 56], "little", signed=True)
                    _outputData.battery["voltage"] = int.from_bytes(_inputData[56: 58], "little", signed=True) / 100.0
                    _outputData.battery["current"] = int.from_bytes(_inputData[58: 60], "little", signed=True) / 100.0
                    _outputData.battery["cycle"] = int.from_bytes(_inputData[60: 61], "little", signed=True)
                    _outputData.battery["temperature"] = int.from_bytes(_inputData[61: 63], "little", signed=True) / 10.0
        return _outputData

    def encode_arduino_package(self, _inputData) -> bytes:
        _outputData = b'\xFF'
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x320:
            _outputData += struct.pack('f', _inputData.driveMotor["velocity"][0])
            _outputData += struct.pack('f', _inputData.driveMotor["velocity"][1])
            _outputData += struct.pack('B', _inputData.driveMotor["state"] | _inputData.cleanMotor["state"])
            _outputData += self.__crc16_xmodem_with_table(b'\x00\x00', _outputData)
            _outputData += b'\xEE'
            _outputData += b'\n'
        return _outputData
