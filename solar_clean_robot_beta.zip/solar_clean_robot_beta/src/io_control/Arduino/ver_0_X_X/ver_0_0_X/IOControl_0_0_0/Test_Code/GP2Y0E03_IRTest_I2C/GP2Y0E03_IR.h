#ifndef GP2Y0E03_IR_H
#define GP2Y0E03_IR_H

#include <Arduino.h>
#include <Wire.h>
#define SENSOR_ADDRESS 0x40 // I2C address of GP2Y0E03 
#define DISTANCE_ADDRESS 0x5E // Data address of Distance Value // Functions to process only at power-on and reset 

class GP2Y0E03_IR {
  public:
    GP2Y0E03_IR();
    ~GP2Y0E03_IR();
    void initial();
    void request_ir_data();
    int echo_ir_mm();
    
  private:
    int _ans;
};

#endif
