//#define DEBUG

//LED Layout
#define LEFT_LED_R 5
#define LEFT_LED_G 6
#define LEFT_LED_B 7
#define RIGHT_LED_R 8
#define RIGHT_LED_G 9
#define RIGHT_LED_B 10

//IR Layout
#define IR_ECHO_COUNT 6
#define CLIFF_SENSOR_MODEL 430
byte irPins[IR_ECHO_COUNT] = {A0, A1, A2, A3, A4, A5};

//Relay Layout
#define RELAY_1_IN1 22
#define RELAY_1_IN2 23

#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1

//Define Frenquency of Status Publish
float statusFrequency = 2.0;//Unit: Hz
float irFrequency = 20.0;//Unit: Hz
int connectTimeout = 10;//Unit: s
int bootTimeout = 20;//Unit: s

//LED Parameter
int blinkFrequency = 2;//unit: Hz

//Define Slow Start Parameter
int controlTime = 1000;//Unit: ms
