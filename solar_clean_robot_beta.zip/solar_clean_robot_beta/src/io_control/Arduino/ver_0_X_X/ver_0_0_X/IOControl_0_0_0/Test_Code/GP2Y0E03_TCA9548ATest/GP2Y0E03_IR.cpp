#include "GP2Y0E03_IR.h"

GP2Y0E03_IR::GP2Y0E03_IR()
{
  initial();
}

GP2Y0E03_IR::~GP2Y0E03_IR()
{

}

void GP2Y0E03_IR::initial()
{
  Wire.begin(); // Initialize I2C,
}

void GP2Y0E03_IR::request_ir_data()
{
  Wire.beginTransmission (SENSOR_ADDRESS); // start communication processing
  Wire.write (DISTANCE_ADDRESS); // specify the address of the table storing the distance value
  _ans = Wire.endTransmission(); // send and close data
}

int GP2Y0E03_IR::echo_ir_mm()
{
  unsigned char _c[2];
  if (_ans == 0)
  {
    _ans = Wire.requestFrom(SENSOR_ADDRESS, 2) ;
    _c[0] = Wire.read(); // Read the 11th to 4th bits of data c [1]
    _c[1] = Wire.read(); // Read the 3rd and 0th bits of the data
    _ans = (_c [0] * 16 + _c [1]) / 16 / 4 * 10; // distance

    //Serial.print(_ans);
    //Serial.println ("cm"); //to display on serial monitor;
  }
  else
  {
    //Serial.print ("ERROR NO. ="); // Can not communicate with GP2Y0E03
    //Serial.println (_ans);
    _ans = -1;
  }
  return _ans;
}

void GP2Y0E03_IR::set_pulse_width()
{
  Wire.beginTransmission (SENSOR_ADDRESS); // start communication processing
  Wire.write (PULSE_WIDTH_ADDRESS);
  Wire.write (PULSE_WIDTH);
  Wire.endTransmission(); // send and close data
}
