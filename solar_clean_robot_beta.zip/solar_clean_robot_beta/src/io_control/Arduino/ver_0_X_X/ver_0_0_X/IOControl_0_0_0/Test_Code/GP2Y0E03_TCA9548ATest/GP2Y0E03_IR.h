#ifndef GP2Y0E03_IR_H
#define GP2Y0E03_IR_H

#include <Arduino.h>
#include <Wire.h>
#define SENSOR_ADDRESS 0x40 // I2C address of GP2Y0E03 
#define DISTANCE_ADDRESS 0x5E // Data address of Distance Value // Functions to process only at power-on and reset 
#define PULSE_WIDTH_ADDRESS 0x13 // Maximum Emitting Pulse Width

#define PULSE_WIDTH 0x03 //40us
//#define PULSE_WIDTH 0x04 //80us
//#define PULSE_WIDTH 0x05 //160us
//#define PULSE_WIDTH 0x06 //240us
//#define PULSE_WIDTH 0x07 //320us


class GP2Y0E03_IR {
  public:
    GP2Y0E03_IR();
    ~GP2Y0E03_IR();
    void initial();
    void request_ir_data();
    int echo_ir_mm();
    void set_pulse_width();
    
  private:
    int _ans;
};

#endif
