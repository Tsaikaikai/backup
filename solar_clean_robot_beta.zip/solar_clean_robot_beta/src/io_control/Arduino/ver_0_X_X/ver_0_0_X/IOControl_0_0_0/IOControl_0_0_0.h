#include <Wire.h>
#include <Stream.h>
#include "SharpIR.h"
#include "PackageFormat.h"
#include "Config.h"

// Status Parameter
byte sonarErrorStatus = 0xFF;
int statusCycleTime = 1000 / statusFrequency;//Unit: ms

// LED Parameter
unsigned long blinkTimer = 0;
long ledState = 0b00000000;

// Clean Motor Parameter
byte motorState = MOTOR_STOP;
byte preMotorState = MOTOR_STOP;
static bool controlFlag = false;

//Sonar Parameter
float sonarFrequency = 10.0;//Unit: Hz
int sonarCycleTime = 1000 / sonarFrequency; //Unit: ms
float maxRange = 0.8;//Unit: m
float soundSpeed = 340; //Unit: m/s
int triggerTime = 2250;//Unit: us
int sonarTimeout = ( maxRange * 2 ) * 1000 * 1000 / soundSpeed + triggerTime;//Unit: us

//IR Parameter
byte irErrorStatus = 0xFF;
int irCycleTime = 1000 / (irFrequency * IR_ECHO_COUNT); //Unit: ms
bool irRequestFlag[IR_ECHO_COUNT] = {false};

SharpIR irSensor[IR_ECHO_COUNT] = {SharpIR(irPins[0], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[1], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[2], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[3], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[4], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[5], CLIFF_SENSOR_MODEL)
                                  };

union Data {
  long longValue;
  float floatValue;
  byte byteValue[4];
  bool boolValue;
};

struct Package {
  byte header = STX;
  byte function = 0;
  byte value[4] = {0xFF, 0xFF, 0xFF, 0xFF};
  byte footer = ETX;
};

byte receivedPackage[7] = {0x00};
