//#define DEBUG
//#define VERSION 0x100 //6 channel IR
//#define VERSION 0x101 //6 channel IR for EL
//#define VERSION 0x102//6 channel IR, distance unit:mm
//#define VERSION 0x110 //8 channel IR, distance unit:mm
#define VERSION 0x111 //8 channel IR, distance unit:mm & Increase a Relay

//IR Layout
#if VERSION >= 0x110
#define IR_ECHO_COUNT 8
#define CLIFF_SENSOR_MODEL 430
byte irPins[IR_ECHO_COUNT] = {A0, A1, A2, A3, A4, A5, A6, A7};

#elif VERSION >= 0x101
#define IR_ECHO_COUNT 6
byte irPins[IR_ECHO_COUNT] = {A0, A1, A3, A4, A5, A7};
#define CLIFF_SENSOR_MODEL 430

#elif VERSION >= 0x100
#define IR_ECHO_COUNT 6
byte irPins[IR_ECHO_COUNT] = {A0, A1, A2, A3, A4, A5};
#define CLIFF_SENSOR_MODEL 430

#endif

//Relay Layout
#define RELAY_1_IN1 22
#define RELAY_1_IN2 23

#if VERSION >= 0x111
#define RELAY_2_IN1 8
#endif

#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1

//Define Frenquency of Status Publish
float statusFrequency = 2.0;//Unit: Hz
float irFrequency = 15.0;//Unit: Hz
int connectTimeout = 10;//Unit: s
int bootTimeout = 20;//Unit: s

//Define Slow Start Parameter
int controlTime = 1000;//Unit: ms
