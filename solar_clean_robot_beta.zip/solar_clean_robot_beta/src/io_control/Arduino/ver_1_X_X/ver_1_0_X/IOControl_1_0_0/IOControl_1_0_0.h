#include <Wire.h>
#include <Stream.h>
#include "SharpIR.h"
#include "PackageFormat.h"
#include "Config.h"
#include "CRC.h"
#include "CRC16.h"

// Status Parameter
byte sonarErrorStatus = 0xFF;
int statusCycleTime = 1000 / statusFrequency;//Unit: ms

// Clean Motor Parameter
byte motorState = MOTOR_STOP;
byte preMotorState = MOTOR_STOP;
byte preRelay2State = RELAY_2_OFF;
byte relay2State = RELAY_2_OFF;
static bool controlFlag = false;

//IR Parameter
byte irErrorStatus = 0xFF;
int irCycleTime = 1000 / (irFrequency * IR_ECHO_COUNT); //Unit: ms
bool irRequestFlag[IR_ECHO_COUNT] = {false};
#if VERSION >= 0x110
SharpIR irSensor[IR_ECHO_COUNT] = {SharpIR(irPins[0], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[1], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[2], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[3], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[4], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[5], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[6], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[7], CLIFF_SENSOR_MODEL)
                                  };
#else
SharpIR irSensor[IR_ECHO_COUNT] = {SharpIR(irPins[0], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[1], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[2], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[3], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[4], CLIFF_SENSOR_MODEL),
                                   SharpIR(irPins[5], CLIFF_SENSOR_MODEL)
                                  };
#endif

union Data {
  long longValue;
  float floatValue;
  byte byteValue[4];
  bool boolValue;
};

struct Package {
  byte header = STX;
  byte function = 0;
  byte value[4] = {0xFF, 0xFF, 0xFF, 0xFF};
  byte footer = ETX;
};

byte receivedPackage[7] = {0x00};
