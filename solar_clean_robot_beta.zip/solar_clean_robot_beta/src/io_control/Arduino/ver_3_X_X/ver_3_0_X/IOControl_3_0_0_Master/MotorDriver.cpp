#define Arduino
#include "Arduino.h"
#include "MotorDriver.h"

// void _interruptHallSensorU();

MotorDriver::MotorDriver(int runStatusContorlPin, int directionControlPin, int pwmSignalPin, int alarmStatePin, int lockContolPin,
                         int accelerateQuantity, int invers)
{
#ifdef DEBUG
    Serial.println("MotorDriver:: new class->MotorDriver()");
#endif
    _runStatusContorlPin = runStatusContorlPin;
    _directionControlPin = directionControlPin;
    _pwmSignalPin = pwmSignalPin;
    _alarmStatePin = alarmStatePin;
    _lockContolPin = lockContolPin;
    _accelerateQuantity = accelerateQuantity;
    _invers = invers;
    _motorNumber = _invers == MOTOR_R_INVERS ? MOTOR_R : MOTOR_L; // 0=L  1=R

#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print("  MotorDriver:: new ");
    Serial.println(_motorNumber == MOTOR_R ? "R" : "L");
    // Serial.println("MotorDriver:: new class->MotorDriver()");
#endif

    // Define pin
    pinMode(_pwmSignalPin, OUTPUT);        // Frequency 1K hz
    pinMode(_directionControlPin, OUTPUT); // HIGH:Forward; LOW:Back
    pinMode(_runStatusContorlPin, OUTPUT); // HIGH:Break; LOW:Run
    pinMode(_alarmStatePin, INPUT);        // HIGH:No Alarm; LOW:Alarm
    pinMode(_lockContolPin, OUTPUT);       // HIGH:UNLOCK ; LOW:LOCK
    // digitalWrite(_lockContolPin, LOW);    // Set Lock Pin Default LOW = LOCK
    // this->set_lock_state(true);

    _set_Interrupt_Parameter();
    // digitalWrite(_runStatusContorlPin, LOW);

    sensorPulseCount = 0;
}

MotorDriver::~MotorDriver()
{
}

// float MotorDriver::get_odometry()
// {
//     // float odograph;
//     // return odograph;
//     return _odometry;
// }

uint32_t MotorDriver::get_Pulse_Count()
{
    return sensorPulseCount;
}

void MotorDriver::set_lock_state(bool setState)
{
    if (!setState)
        digitalWrite(this->_lockContolPin, HIGH);
    else
        digitalWrite(this->_lockContolPin, LOW);

#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.println(digitalRead(this->_lockContolPin) == HIGH ? "  UNLOCK." : "  LOCK."); // 測試用
#endif
}

bool MotorDriver::get_lock_state()
{
    if (digitalRead(this->_lockContolPin) == HIGH)
        return false;
    else
        return true;
}

bool MotorDriver::get_alarm_state()
{
    if (digitalRead(this->_alarmStatePin) == HIGH)
        return true;
    else
        return false;
}

/*
bool MotorDriver::get_alarm(int alarm)
{
    return false;
}
*/

/*
int MotorDriver::control_manual(int target, int command)
{
#ifdef DEBUG
    // Serial.print(" PWMPin: ");
    // Serial.print(this->_pwmSignalPin);
    // Serial.print(" Target: ");
    // Serial.print(target);
#endif
    //_unlock();

    // if (this->get_lock_state())
    //     this->set_lock_state(false);

    // if (this->_invers * target < 0) // target正 + No Invers ; target負 + Invers => 正轉
    //     digitalWrite(this->_directionControlPin, HIGH);
    // else if (this->_invers * target > 0) // target正 +  Invers ; target負 + No Invers => 反轉
    //     digitalWrite(this->_directionControlPin, LOW);

    if (command < target)
    {
        command = command + _accelerateQuantity;
        if (command > target)
            command = target;
    }
    else if (command > target)
    {
        command = command - _accelerateQuantity;
        if (command < target)
            command = target;
    }
    analogWrite(this->_pwmSignalPin, abs(command));
    return command;
}
*/

int MotorDriver::set_velocity(float *velocity)
{
#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print(_motorNumber == MOTOR_R ? "  R " : "  L "); // 測試用
    Serial.print("Input Linear Velocity: ");
    Serial.print(velocity[0]);
    Serial.print(", Angular Velocity: ");
    Serial.println(velocity[1]);
#endif

    float _motorRunRPM = 0;
    _motorRunRPM = (velocity[0] - float(this->_invers) * (WHEEL_BASE / 2.0) * velocity[1]) / (2.0 * WHEEL_RADIUS * PI / (60.0 * GEAR_RATIO));

#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print("    Output Motor RPM: ");
    Serial.println(_motorRunRPM);
#endif

    return this->_set_motor_rpm(_motorRunRPM);
}

int MotorDriver::_set_motor_rpm(float motorRunRPM)
{
#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print(_motorNumber == MOTOR_R ? "  R " : "  L "); // 測試用
    Serial.print("Input Motor RPM: ");
    Serial.println(motorRunRPM);
#endif

    int _outTargetDuty = 0;
    if (this->_invers * motorRunRPM > 0) // RPM正 + No Invers ; RPM負 + Invers => 正轉
        digitalWrite(this->_directionControlPin, HIGH);
    else if (this->_invers * motorRunRPM < 0) // RPM正 +  Invers ; RPM負 + No Invers => 反轉
        digitalWrite(this->_directionControlPin, LOW);
    // _motor_rpm_command = map(abs(rpm), 100, 3000, 26, 154); // Map 0~3000 RPM to Duty Cycle 0~60%
    int _absRPM = int(abs(motorRunRPM));
    if (_absRPM < DRIVER_RPM_MIN)
        _outTargetDuty = 0;
    else if (_absRPM > DRIVER_RPM_MAX)
        _outTargetDuty = DUTY_CYCLE_MAX;
    else
        _outTargetDuty = map(_absRPM, DRIVER_RPM_MIN, DRIVER_RPM_MAX, DUTY_CYCLE_MIN, DUTY_CYCLE_MAX); // Map 100~4000 RPM to Duty Cycle 0~80%

#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print("    Output PWM Duty: ");
    Serial.print(_outTargetDuty);
    Serial.println(digitalRead(this->_directionControlPin) == HIGH ? ", FORWARD" : ", REVERSE");
#endif

    return _outTargetDuty;
}

/*
int MotorDriver::control(int targetDuty, int currentDuty)
{
#ifdef DEBUG
    // Serial.print(" PWMPin: ");
    // Serial.print(_pwmPin);
    // Serial.print(" Target: ");
    // Serial.print(target);
#endif

    if (currentDuty < targetDuty)
    {
        currentDuty = currentDuty + this->_accelerateQuantity;
        if (currentDuty >= targetDuty)
            currentDuty = targetDuty;
    }
    else if (currentDuty > targetDuty)
    {
        currentDuty = currentDuty - this->_accelerateQuantity;
        if (currentDuty <= targetDuty)
            currentDuty = targetDuty;
    }

    // if (currentDuty < 25)
    //     this->set_lock_state(true);
    // else
    //     this->set_lock_state(false);

    analogWrite(this->_pwmSignalPin, currentDuty);
    return currentDuty;
}
*/

int MotorDriver::drive_operation_command(int targetDuty, int currentDuty)
{
#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print(_motorNumber == MOTOR_R ? "  R " : "  L "); // 測試用
    Serial.print("Input Target: ");
    Serial.print(targetDuty);
    Serial.print(", Current: ");
    Serial.println(targetDuty);
#endif

    if (currentDuty < targetDuty)
    {
        currentDuty = currentDuty + this->_accelerateQuantity;
        if (currentDuty >= targetDuty)
            currentDuty = targetDuty;
    }
    else if (currentDuty > targetDuty)
    {
        currentDuty = currentDuty - this->_accelerateQuantity;
        if (currentDuty <= targetDuty)
            currentDuty = targetDuty;
    }
    analogWrite(this->_pwmSignalPin, currentDuty);

#ifdef TEST_VIEW_MSG
    Serial.print(millis());
    Serial.print("    Output Target: ");
    Serial.print(targetDuty);
    Serial.print(", Current: ");
    Serial.println(targetDuty);
#endif

    return currentDuty;
}

void MotorDriver::_set_Interrupt_Parameter()
{
    // pinMode(_sensorHallUPin, INPUT_PULLUP);
    // pinMode(_sensorHallVPin, INPUT_PULLUP);
    // pinMode(_sensorHallWPin, INPUT_PULLUP);
    noInterrupts();
    // attachInterrupt(digitalPinToInterrupt(_sensorHallUPin), _interruptHallSensorU, RISING);
    TCCR4A = _BV(COM4A0) | _BV(COM4B1) | _BV(WGM41) | _BV(WGM40);
    TCCR4B = _BV(WGM43) | _BV(WGM42) | _BV(CS40) | _BV(CS41);
    OCR4A = 249;
    interrupts();
}
/*
void _interruptHallSensorU()
{
    if (instance->_sensorPulseCount == 4294967295)
        instance->_sensorPulseCount = 0;
    instance->_sensorPulseCount += 1;
    int _sensorStateV = digitalRead(instance->_sensorHallVPin);
    int _sensorStateW = digitalRead(instance->_sensorHallWPin);
    if (_sensorStateV == 0 && _sensorStateW == 1)
    {
        instance->_currentDirection = 1;
    }
    else if (_sensorStateV == 1 && _sensorStateW == 0)
    {
        instance->_currentDirection = -1;
    }
    else
        instance->_errorSignalCount += 1;
}
*/
