
#include "PackageFormat.h"
#include "Config.h"
#include "MotorDriver.h"
#include "RobotAPI.h"
#include "JoyStick.h"

float robotCycleTime = 1000.0 / ROBOT_FREQUENCY;
float motorCycleTime = 1000.0 / MOTOR_FREQUENCY;
float updateMoveStatusCycleTime = 100; // 毫秒

byte robotMacAddress[6] = ROBOT_MAC_ADDRESS;
byte robotIp[4] = ROBOT_IP;
byte robotGateway[4] = ROBOT_GATEWAY;
byte robotSubnet[4] = ROBOT_SUBNET;
int robotPort = ROBOT_PORT;

int motorcommandL = 0;
int motorcommandR = 0;

RobotAPI *robot;
MotorDriver *motorL;
MotorDriver *motorR;

RobotData robotData;
RobotCommand robotCommand;

// 系統狀態
int actionControlType; // 0:初始狀態,無控制  1:遙控器控制  2:上位控制
int currentActionControlType;

// 里程相關
unsigned long prevLeftPulse = 0;
unsigned long prevRightPulse = 0;
float relativeMoveCoordinateX = 0;
float relativeMoveCoordinateY = 0;
float prevRelativeMoveCoordinateX = 0;
float prevRelativeMoveCoordinateY = 0;
float relativeMoveTheta = 0;
float totalMileage = 0;

// 搖桿添加後續再修改
// Switch
int REMOTE_MODE = 3;
bool Mode_State = false;
bool Switch_Mode_Value = false;
bool Motor_Enb_Value = false;
bool AUTO_OnOff = false;
// Rotate
int Rotate_State = 0; // 前進、後退、左旋、右旋
int Rotate_Level = 0;
// bool motorlockL = false; // true:unlock;false:lock
// bool motorlockR = false; // true:unlock;false:lock
int motorMoveStatus = 0; // 0->靜止   1->移動

JoyStick joystick(SWITCH_MODE_PIN, MOTOR_ENB_PIN, L_X_PIN, L_Y_PIN, R_X_PIN, R_Y_PIN);

void _check_motor_status();
void _update_mileage();
int _change_operating_mode_stop();

void interrupt_hall_sensor_U_R();
void interrupt_hall_sensor_U_L();
