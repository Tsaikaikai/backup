#ifndef JOY_STICK_H
#define JOY_STICK_H

#define Arduino
#include "Arduino.h"
#include "Config.h"

class JoyStick
{
public:
    JoyStick(int switchPin, int enbPin, byte lxPin, byte lyPin, byte rxPin, byte ryPin);

    ~JoyStick();

    int mode_decide(int mode);
    int pwm_decide(byte Mushroom_head);
    int state_switch_decide(int state);
    int rotate_level_decide(int level);
    bool lock();

private:
    int _switchPin;
    int _enbPin;
    byte _lxPin;
    byte _lyPin;
    byte _rxPin;
    byte _ryPin;
    bool auto_lock();
};

#endif