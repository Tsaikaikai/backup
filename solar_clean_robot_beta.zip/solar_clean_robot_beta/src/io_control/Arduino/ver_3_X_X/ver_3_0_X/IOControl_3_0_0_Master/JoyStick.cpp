#define Arduino
#include "Arduino.h"
#include "JoyStick.h"

// Initialisation function
JoyStick::JoyStick(int switchPin, int enbPin, byte lxPin, byte lyPin, byte rxPin, byte ryPin)
{
#ifdef DEBUG
    Serial.println("JoyStick::JoyStick()");
#endif
    _switchPin = switchPin;
    _enbPin = enbPin;
    _lxPin = lxPin;
    _lyPin = lyPin;
    _rxPin = rxPin;
    _ryPin = ryPin;
    // Define pin
    pinMode(switchPin, INPUT);
    pinMode(enbPin, INPUT);
}

JoyStick::~JoyStick()
{
}

int JoyStick::mode_decide(int mode)
{
    int Motor_Enb_Value = 0;
    int Switch_Mode_Value = 0;
    int buffer = 0;
    /*
    #ifdef DEBUG
        Serial.println("JoyStick::mode_decide");
    #endif
    */
    Motor_Enb_Value = digitalRead(_enbPin);
    Switch_Mode_Value = digitalRead(_switchPin);
    if (Switch_Mode_Value == HIGH && Motor_Enb_Value == HIGH)
        buffer = 1;
    else if (Switch_Mode_Value == LOW && Motor_Enb_Value == HIGH)
        buffer = 2;
    else if (Motor_Enb_Value == LOW)
        buffer = 3;
    if (buffer != mode)
        delay(1);
    return buffer;
}

int JoyStick::pwm_decide(byte Mushroom_head)
{
    int Buffer = 0;
    /*
    #ifdef DEBUG
        Serial.println("JoyStick::pwm_decide()");
    #endif
    */
    if (Mushroom_head == R_X_PIN)
        Buffer = analogRead(_rxPin) - 512;
    else if (Mushroom_head == R_Y_PIN)
        Buffer = analogRead(_ryPin) - 512;
    else if (Mushroom_head == L_X_PIN)
        Buffer = analogRead(_lxPin) - 512;
    else if (Mushroom_head == L_Y_PIN)
        Buffer = analogRead(_lyPin) - 512;
    else
        return Buffer = 999;

    if (Buffer < -82)
        Buffer = map(abs(Buffer), 0, 512, 0, 154);
    // return abs(Buffer);
    else if (Buffer > 82)
        Buffer = map(Buffer, 0, 512, 0, 154);
    // return Buffer * -1;
    else
        return Buffer = 0; // Duty Cycle 0%
}

int JoyStick::state_switch_decide(int state)
{
    int Buffer1 = 0;
    int Buffer2 = 0;
    /*
#ifdef DEBUG
    Serial.println("JoyStick::state_switch_decide()");
#endif
*/
    Buffer1 = analogRead(_ryPin);
    Buffer2 = analogRead(_rxPin);
    if (400 < Buffer1 < 600 && 400 < Buffer2 < 600)
        state = 5;
    if (Buffer1 < 50 && 50 < Buffer2 < 950)
        state = 1;
    if (Buffer1 > 950 && 50 < Buffer2 < 950)
        state = 2;
    if (Buffer2 < 50 && 50 < Buffer1 < 950)
        state = 3;
    if (Buffer2 > 950 && 50 < Buffer1 < 950)
        state = 4;
    return state;
}

int JoyStick::rotate_level_decide(int level)
{
    /*
#ifdef DEBUG
    Serial.println("JoyStick::rotate_level_decide()");
#endif
*/
    int Buffer = 0;
    Buffer = analogRead(_lyPin);
    if (Buffer < 950 && level < 155)
        level++;
    else if (Buffer > 50 && level > 0)
        level--;
    delay(5);
    return level;
}

bool JoyStick::lock()
{
    bool _result = false;
#ifdef DEBUG
    Serial.println("JoyStick::lock()");
#endif
    return _result;
}

bool JoyStick::auto_lock()
{
    bool _result = false;
#ifdef DEBUG
    Serial.println("JoyStick::auto_lock()");
#endif
    return _result;
}
