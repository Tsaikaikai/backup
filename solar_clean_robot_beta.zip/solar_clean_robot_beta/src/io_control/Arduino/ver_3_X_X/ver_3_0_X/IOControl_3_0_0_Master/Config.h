// #define TEST_VIEW_MSG
// #define DEBUG
#define VERSION 0x300

// Arduino Setting Parameter
#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1
// Robot parameters
#define ROBOT_IP         \
    {                    \
        192, 168, 10, 10 \
    }
#define ROBOT_GATEWAY     \
    {                     \
        192, 168, 10, 254 \
    }
#define ROBOT_SUBNET     \
    {                    \
        255, 255, 255, 0 \
    }
#define ROBOT_MAC_ADDRESS                  \
    {                                      \
        0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED \
    }
#define ROBOT_PORT 80
#define ROBOT_FREQUENCY 10

// Motor parameters
#define MOTOR_FREQUENCY 10
#define MOTOR_ACCELERATE 10
#define MOTOR_ECHO_COUNT 2
#define WHEEL_RADIUS 0.035
#define WHEEL_BASE 0.63
#define GEAR_RATIO 20.0
#define WHEEL_PULSE 100.0
#define PI 3.1415926535897932384626433832795

#define CLINET_CONNECTION_TIMEOUT 500
#define BUFFER_STOP_TIME 200 // ms
#define DUTY_CYCLE_MIN 26    // 10%
#define DUTY_CYCLE_MAX 204   // 80%
#define DRIVER_RPM_MIN 100
#define DRIVER_RPM_MAX 4000
// Right Motor
#define MOTOR_R 1         // 馬達編號
#define MOTOR_R_INVERS -1 // 1:invers; -1:no invers
#define MOTOR_R_PWM_PIN 8 // 13
#define MOTOR_R_ALARM_PIN 38
#define MOTOR_R_RUN_BREAK_PIN 40 // HIGH:Break; LOW:Run
#define MOTOR_R_CWCCW_PIN 42     // HIGH:Forward; LOW:Back
#define MOTOR_R_LOCK_PIN 44      // HIGH:Forward; LOW:Back
#define MOTOR_R_HALL_U_PIN 2

// Left Motor
#define MOTOR_L 0         // 馬達編號
#define MOTOR_L_INVERS 1  // 1:invers; -1:no invers
#define MOTOR_L_PWM_PIN 7 // 4
#define MOTOR_L_ALARM_PIN 39
#define MOTOR_L_RUN_BREAK_PIN 41 // HIGH:Break; LOW:Run
#define MOTOR_L_CWCCW_PIN 43     // HIGH:Forward; LOW:Back
#define MOTOR_L_LOCK_PIN 45      // HIGH:Forward; LOW:Back
#define MOTOR_L_HALL_U_PIN 3

// Joystick parameters
#define SWITCH_AUTO_PIN 37 // 上位/遙控切換
#define MOTOR_ENB_PIN 48   // 手動測試For Servo On/Off  灰線
#define SWITCH_MODE_PIN 49 // 手動測試For 模式切換 橘線
#define L_X_PIN A10
#define L_Y_PIN A11
#define R_X_PIN A8
#define R_Y_PIN A9

// IMU parameters
#define IMU_SERIAL_NUMBER 2
#define IMU_BAUD_RATE 115200
#define IMU_FREQUENCY 10
