#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H

#define Arduino
#include "Arduino.h"
#include "Config.h"

class MotorDriver
{
public:
  /// @brief
  /// @param runStatusContorlPin 驅動器運轉控制腳位 HIGH=停止, LOW=運作
  /// @param directionControlPin CW/CCW 正反轉控制腳位 HIGH=向前, LOW=向後
  /// @param pwmSignalPin PWM輸入腳位 1K Hz
  /// @param alarmStatePin 警報狀態腳位 HIGH=發生警報, LOW=正常
  /// @param lockContolPin 鎖控制腳位 HIGH=解鎖, LOW=上鎖
  /// @param accelerate 速度累加遞減量
  /// @param invers 反轉訊號 -1=反轉, 1=不變
  MotorDriver(int runStatusContorlPin, int directionControlPin, int pwmSignalPin, int alarmStatePin, int lockContolPin,
              int accelerateQuantity, int invers);
  ~MotorDriver();

  volatile unsigned long sensorPulseCount;

  void set_lock_state(bool setState); // 設定Lock狀態, setState: True->上鎖, False->解鎖
  bool get_lock_state();              // 取得Lock狀態, Return: True->上鎖, False->解鎖
  bool get_alarm_state();
  // int control(int target, int command);                // for driver in IPC Control
  // int control_manual(int targetDuty, int currentDuty); // for driver in manual
  int set_velocity(float *velocity); // IPC velocity command to motor rpm
  int drive_operation_command(int targetDuty, int currentDuty);
  // float get_odometry();                        // return x,y
  uint32_t get_Pulse_Count();

private:
  int _runStatusContorlPin;
  int _directionControlPin;
  int _pwmSignalPin;
  int _alarmStatePin;
  int _lockContolPin;
  int _accelerateQuantity;
  int _invers;
  int _motorNumber = 0;
  float _velocity[2] = {0}; // 線速度、角速度
  // int _motorMoveStatus = 0; // 0->靜止   1->移動
  // uint32_t _motorFinishMoveDutyTimer = 0;
  // float _odometry = 0.0;    // 內部里程計累積

  int _set_motor_rpm(float rpm); // RPM to arduino PWm  //輸入RPM 輸出 Arduino需輸出的PWM
  void _set_Interrupt_Parameter();
  // friend void _interruptHallSensorU();
};
// static MotorDriver *instance = NULL;
#endif
