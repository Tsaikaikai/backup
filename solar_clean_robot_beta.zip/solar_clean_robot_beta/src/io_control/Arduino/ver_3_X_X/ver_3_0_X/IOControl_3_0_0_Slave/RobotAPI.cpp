#include "RobotAPI.h"
bool RobotAPI::post_data(RobotData *_data)
{
    bool _return = false;
    crc16.reset();
    crc16.setPolynome(0x1021);

    unsigned char *dataPointer = (unsigned char *)_data;
    for (int i = 1; i < sizeof(*_data) - 3; i++)
    {
        crc16.add(dataPointer[i]);
    }
    dataPointer[sizeof(*_data) - 3] = crc16.getCRC() & 0x00FF;
    dataPointer[sizeof(*_data) - 2] = crc16.getCRC() >> 8;
    if (this->post(dataPointer, sizeof(*_data)))
    {
        _return = true;
    }

    return _return;
}

RobotCommand RobotAPI::get_command()
{
    return this->_robotCommand;
}

//deocde binary package from middle ware
bool RobotAPI::decode_package()
{
    bool _return = false;
    this->_robotCommand.header = get_data()[0];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0])) = get_data()[1];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 1) = get_data()[2];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 2) = get_data()[3];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 3) = get_data()[4];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1])) = get_data()[5];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 1) = get_data()[6];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 2) = get_data()[7];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 3) = get_data()[8];
    this->_robotCommand.cleanMode = get_data()[9];
    this->_robotCommand.crc16 = get_data()[10] + (get_data()[11] << 8);
    this->_robotCommand.footer = get_data()[12];
    _return = true;
    return _return;
}