#ifndef ETHERNET_STREAM_h
#define ETHERNET_STREAM_h
#include "Arduino.h"
#include <SPI.h>
#include <Ethernet.h>

class EthernetStream
{
public:
  EthernetStream(byte *_macAdress, byte *_ip, byte *_gateway, byte *_subnet, int _port);
  ~EthernetStream();
  bool connect_available();
  bool client_available();
  bool client_connected();
  bool post(unsigned char *_data, int _length);
  uint8_t *get_data();

private:
  bool _data_convert(String _data);
  EthernetServer *_server;
  EthernetClient *_client;
  String _readString;
  uint8_t _data[100];
};

#endif
