#include "Sensors.h"

bool Sensors::decode_package()
{
}

int *Sensors::get_sensors_range()
{
    return this->_sensorsRange;
}
//todo: add other sensors