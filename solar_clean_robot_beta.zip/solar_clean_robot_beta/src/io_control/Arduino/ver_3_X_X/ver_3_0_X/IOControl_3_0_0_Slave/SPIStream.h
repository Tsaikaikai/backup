#ifndef SPI_STREAM_h
#define SPI_STREAM_h
#include "Arduino.h"
#include <SPI.h>

#define SPI_SS_PIN 10
#define SPI_MOSI_PIN 11
#define SPI_MISO_PIN 12
#define SPI_SCK_PIN 13

class SPIStream
{
public:
    SPIStream();
    ~SPIStream();

private:
};

#endif
