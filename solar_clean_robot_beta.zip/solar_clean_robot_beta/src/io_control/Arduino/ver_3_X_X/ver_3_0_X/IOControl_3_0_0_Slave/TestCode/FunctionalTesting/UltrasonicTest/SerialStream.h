#ifndef SERIAL_STREAM_h
#define SERIAL_STREAM_h
#include "Arduino.h"

class SerialStream
{
public:
  SerialStream(int serialNumber, int baudRate, byte header, byte footer);
  ~SerialStream();
  bool set_received_package_length(int packageLength);
  int get_package_length();
  bool read_serial();
  bool read_serial_without_header();
  bool write_serial(unsigned char *command, int commandLength);
  unsigned char *get_data();
  bool free_data();

private:
  void _serial_begin();
  int _serial_available();
  int _serial_read();
  size_t _serial_write(unsigned char command);
  void _serial_flush();
  int _packageLength = 0;
  int _serialNumber = 0;
  byte _header = 0x00;
  byte _footer = 0x00;
  int _baudRate;
  int _dataCount = 0;
  unsigned char *_receivedData = NULL;
  unsigned char *_transmittedData = NULL;
};

#endif
