#include "HYBattery.h"
bool HYBattery::set_register(byte registerAddress)
{
    static unsigned char _command[7] = {0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77};
    switch (registerAddress)
    {
    case BATTERY_INFORMATION:
        _command[2] = 0x03;
        _command[5] = 0xFD;
        set_received_package_length(0x1B + 7); // 0x1B = 27, 7 = header + state + commad code + length + checksum_H + checksum_L + footer
        break;
    case CELL_VOLT:
        _command[2] = 0x04;
        _command[5] = 0xFC;
        set_received_package_length(0x1E + 7); // 0x1E = 30, 7 = header + state + commad code + length + checksum_H + checksum_L + footer
        break;
    case FIRMWARE_VERSION:
        _command[2] = 0x05;
        _command[5] = 0xFB;
        set_received_package_length(0x0A + 7); // 0x0A = 10, 7 = header + state + commad code + length + checksum_H + checksum_L + footer
        break;
    default:
        _command[2] = 0x00;
        _command[5] = 0x00;
        set_received_package_length(0);
        break;
    }
    write_serial(_command, 7);
    return true;
}
bool HYBattery::decode_package(byte registerAddress)
{
    switch (registerAddress)
    {
    case BATTERY_INFORMATION:
        return _decode_battery_information();
        break;
    case CELL_VOLT:
        return _decode_cell_volt();
        break;
    case FIRMWARE_VERSION:
        return _decode_firmware_version();
        break;
    default:
        return false;
        break;
    }
}

bool HYBattery::_decode_battery_information()
{
    unsigned int _checksum = 0;
    bool _result = false;
    for (int i = 0; i < get_data()[3] + 2; i++) // 2 = state + length
    {
        _checksum += int(get_data()[i + 2]);
    }
    _checksum = 0x10000 - _checksum;
    if (_checksum - int(get_data()[get_package_length() - 3] << 8) - int(get_data()[get_package_length() - 2]))
    {
        _result = false;
    }
    else
    {
        this->_totalVolt = (int(get_data()[4] << 8) + int(get_data()[5])) * 10;
        this->_totalCurrent = (65536 - (int(get_data()[6] << 8) + int(get_data()[7]))) * 10;
        this->_remainingCapacity = (int(get_data()[8] << 8) + int(get_data()[9])) * 10;
        this->_normalCapacity = (int(get_data()[10] << 8) + int(get_data()[11])) * 10;
        this->_cycleCount = (int(get_data()[12] << 8) + int(get_data()[13]));
        this->_productDate = (int(get_data()[14] << 8) + int(get_data()[15]));
        this->_version = int(get_data()[22]);
        this->_SOC = int(get_data()[23]);
        this->_temperature = (int(get_data()[27] << 8) + int(get_data()[28]) - 2731) / 10.0;
        _result = true;
    }
    free_data();
    return _result;
}
bool HYBattery::_decode_cell_volt()
{
    return true;
}
bool HYBattery::_decode_firmware_version()
{
    return true;
}

int HYBattery::get_total_volt()
{
    return this->_totalVolt;
}
int HYBattery::get_total_current()
{
    return this->_totalCurrent;
}
int HYBattery::get_remaining_capacity()
{
    return this->_remainingCapacity;
}

int HYBattery::get_normal_capacity()
{
    return this->_normalCapacity;
}

int HYBattery::get_cycle_count()
{
    return this->_cycleCount;
}

int HYBattery::get_product_date()
{
    return this->_productDate;
}

int HYBattery::get_version()
{
    return this->_version;
}

int HYBattery::get_SOC()
{
    return this->_SOC;
}

float HYBattery::get_temperature()
{
    return this->_temperature;
}

int HYBattery::get_SOH()
{
    return this->_normalCapacity * 10 / CAPCITY;
}