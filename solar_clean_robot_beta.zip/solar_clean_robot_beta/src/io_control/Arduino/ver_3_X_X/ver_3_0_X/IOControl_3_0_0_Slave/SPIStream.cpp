#include "SPIStream.h"
SPIStream::SPIStream()
{
    pinMode(SPI_MISO_PIN, OUTPUT);
    SPCR |= _BV(SPE);
    SPI.attachInterrupt();
}
SPIStream::~SPIStream()
{
}