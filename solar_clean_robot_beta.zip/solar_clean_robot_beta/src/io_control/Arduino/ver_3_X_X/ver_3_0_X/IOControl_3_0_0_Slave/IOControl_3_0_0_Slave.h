#include <SPI.h>
#include <Wire.h>
#include <Stream.h>

#include "Sensor.h"
#include "PackageFormat.h"
#include "Config.h"
#include "Ultrasonic.h"
#include "HYBattery.h"
#include "CRC.h"
#include "CRC16.h"
#include "RobotAPI.h"

float slaveCycleTime = 1000.0 / SLAVE_FREQUENCY;
byte slaveMacAddress[6] = SLAVE_MAC_ADDRESS;
byte slaveIp[4] = SLAVE_IP;
byte slaveGateway[4] = SLAVE_GATEWAY;
byte slaveSubnet[4] = SLAVE_SUBNET;
int slavePort = SLAVE_PORT;

RobotAPI *slave;
RobotData robotData;
RobotCommand robotCommand;

// SPI Parameter
volatile boolean processing_SPI = false;
byte receivedPackage[7] = {0x00};

// Clean Motor Parameter
int controlTime = 1000; // Unit: ms
byte motorState = MOTOR_STOP;
byte preMotorState = MOTOR_STOP;
byte preRelay2State = RELAY_2_OFF;
byte relay2State = RELAY_2_OFF;
static bool controlFlag = false;

// UltraSonic Parameter
Ultrasonic ultrasonics(ULTRASONIC_SERAIL_NUMBER, ULTRASONIC_BAUD_RATE, 0xDD, 0x77);
byte ultrasonicErrorStatus = 0xFF;                                                        // Not Used
static float ultrasonicCycleTime = 1000 / (ULTRASONIC_FREQUENCY * ULTRASONIC_ECHO_COUNT); // Unit: ms //Not Used
bool ultrasonicRequestFlag[ULTRASONIC_ECHO_COUNT] = {false};                              // Not Used
static byte _ultrasonicbuffer[2] = {0, 0};
static int _currentUltrasonicWriteCount = ULTRASONIC_ECHO_COUNT;
static int _prevUltrasonicReadCount = ULTRASONIC_ECHO_COUNT;
static int _currentUltrasonicReadCount = ULTRASONIC_ECHO_COUNT; // For Receive Ultrasonic count 0~8

// HYBattery Parameter
HYBattery battery(BATTERY_SERAIL_NUMBER, BATTERY_BAUD_RATE, 0xDD, 0x77);
byte batteryErrorStatus = 0xFF;
static float batteryCycleTime = 1000 / BATTERY_FREQUENCY; // Unit: ms
bool batteryRequestFlag = {false};
static uint16_t _batteryValue[6] = {}; // batterySOC; batterySOH; batteryVoltage; batteryCurrent; batteryCycle; batteryTemperature;

// ANALOG_PIN
byte sensorPins[SENSOR_ECHO_COUNT] = SENSOR_PINS;
byte sensorErrorStatus = 0xFF;
static float sensorCycleTime = 1000 / (SENSORFREQUENCY * SENSOR_ECHO_COUNT); // Unit: ms
bool sensorRequestFlag[SENSOR_ECHO_COUNT] = {false};
static int _sensorCount = 0;

#if VERSION >= 0x300
SENSOR sensors[SENSOR_ECHO_COUNT] = {SENSOR(sensorPins[0], SENSOR_TYPE),
                                     SENSOR(sensorPins[1], SENSOR_TYPE),
                                     SENSOR(sensorPins[2], SENSOR_TYPE),
                                     SENSOR(sensorPins[3], SENSOR_TYPE),
                                     SENSOR(sensorPins[4], SENSOR_TYPE),
                                     SENSOR(sensorPins[5], SENSOR_TYPE),
                                     SENSOR(sensorPins[6], SENSOR_TYPE),
                                     SENSOR(sensorPins[7], SENSOR_TYPE)};
#endif

union Data_ULTRASONIC
{
  byte byteValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT * 2];
  int intValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT];
  uint16_t uintValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT];
  // long longValue_ULTRASONIC;   // Not Used
  // float floatValue_ULTRASONIC; // Not Used
  // bool boolValue_ULTRASONIC;     // Not Used
  // char charValue_ULTRASONIC[50]; // Not Used
};
static Data_ULTRASONIC _data_ultrasonic = {};

union Data_SENSOR
{
  byte byteValue_SENSOR[SENSOR_ECHO_COUNT * 2];
  int intValue_SENSOR[SENSOR_ECHO_COUNT];
  float floatValue_SENSOR[SENSOR_ECHO_COUNT];
  // long longValue_SENSOR;   // Not Used
  // bool boolValue_SENSOR;     // Not Used
  // char charValue_SENSOR[50]; // Not Used
};
static Data_SENSOR _data_sensor = {};

union Data
{
  long longValue;
  float floatValue;
  byte byteValue[4];
  bool boolValue;
};
static Data _data;

struct Package
{
  byte header = STX;
  byte function = 0;
  byte value[4] = {0xFF, 0xFF, 0xFF, 0xFF};
  byte footer = ETX;
};