// #define DEBUG
//   #define VERSION 0x300 // Sensor Board Beta2, Original Version
#define VERSION 0x301 // Sensor Board Beta2, For UltraSonic Test

// Arduino Setting Parameter
#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1
// SLAVE parameters
#define SLAVE_IP         \
    {                    \
        192, 168, 20, 11 \
    }
#define SLAVE_GATEWAY     \
    {                     \
        192, 168, 20, 254 \
    }
#define SLAVE_SUBNET     \
    {                    \
        255, 255, 255, 0 \
    }
#define SLAVE_MAC_ADDRESS                  \
    {                                      \
        0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xEF \
    }
#define SLAVE_PORT 80
#define SLAVE_FREQUENCY 10

// Battery parameters
#define BATTERY_SERAIL_NUMBER 2
#define BATTERY_BAUD_RATE 9600
#define BATTERY_FREQUENCY 10 // Unit: Hz
#define CAPCITY 1200

// Ultrasonic parameters
#define COMMAND_WAIT_TIME 5 // ms
#define ULTRASONIC_SERAIL_NUMBER 3
#define ULTRASONIC_BAUD_RATE 115200
#if VERSION >= 0x301
#define ULTRASONIC_FREQUENCY 6 // Unit: Hz
#define ULTRASONIC_ECHO_COUNT 8
#define ULTRASONIC_TIMEOUT 50 // Unit: ms; 0x14=>20; 0xB0=>40
#define ULTRASONIC_RANGE_MAX 2016
#define ULTRASONIC_ADDR {0xe0, 0xd0, 0xe4, 0xd4, 0xe2, 0xd2, 0xe6, 0xd6}; // sensor順序
#define ULTRASONIC_COMMAND {0xD0, 0x02, 0x14};                            // 測距命令,回傳mm值,範圍1~2016mm,週期時間<17ms
#elif VERSION >= 0x300
#define ULTRASONIC_FREQUENCY 3 // Unit: Hz
#define ULTRASONIC_ECHO_COUNT 4
#define ULTRASONIC_TIMEOUT 40 // Unit: ms; 0x14=>20; 0xB0=>40
#define ULTRASONIC_RANGE_MAX 5657
#define ULTRASONIC_ADDR {0xd0, 0xd4, 0xd2, 0xd6}; // sensor順序
#define ULTRASONIC_COMMAND {0xD0, 0x02, 0xB0};    // 測距命令,回傳mm值,範圍1~5657mm,週期時間<33ms
#endif

// Analog Layout
#define SENSORFREQUENCY 10.0 // Unit: Hz
#if VERSION >= 0x300
#define SENSOR_ECHO_COUNT 8
#define SENSOR_PINS {A0, A1, A2, A3, A4, A5, A6, A7};
#define SENSOR_TYPE 500
#define SENSOR_TYPE_TEMPERATURE 501
#define SENSOR_TYPE_CURRENT 502
#define SENSOR_TYPE_HUMIDITY 503
#define SENSOR_TYPE_VOLUME 504
#define SENSOR_TYPE_CURRENT_OLD 505
#endif

// Digital Layout
#define RELAY_1 40
#define RELAY_2 42
#define RELAY_3 44