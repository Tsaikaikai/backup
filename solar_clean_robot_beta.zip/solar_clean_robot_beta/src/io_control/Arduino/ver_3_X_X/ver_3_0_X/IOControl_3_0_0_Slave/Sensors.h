#ifndef SENSORS_h
#define SENSORS_h
#include "SerialStream.h"
#include "Config.h"

class Sensors : public SerialStream
{
public:
  Sensors(int serialNumber, int baudRate, byte header, byte footer) : SerialStream(serialNumber, baudRate, header, footer) {}
  bool decode_package();
  int *get_sensors_range();
  //todo: add other sensors

private:
  int _packageLength = 0;
  int *_sensorsRange;
  //todo: add other sensors
};

#endif
