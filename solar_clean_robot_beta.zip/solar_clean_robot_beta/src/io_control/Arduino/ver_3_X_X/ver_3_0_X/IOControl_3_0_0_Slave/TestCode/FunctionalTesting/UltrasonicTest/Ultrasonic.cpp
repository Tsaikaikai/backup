#include "Ultrasonic.h"

bool Ultrasonic::set_fov()
{
    bool _result = false;
    return _result;
}

bool Ultrasonic::send_distance_command(int no)
{
    static unsigned char ultrasonic_addr[] = ULTRASONIC_ADDR;
    static unsigned char _command[3] = ULTRASONIC_COMMAND; // 測距命令，回傳mm值，範圍1~500cm，週期時間<33ms
    _command[0] = ultrasonic_addr[no];
    // Serial.println(_command[0],HEX);
    write_serial(_command, 3);
    return true;
}

bool Ultrasonic::decode_distance()
{
    bool _result = false;
    this->_distance = (int(get_data()[0]) * 256 + int(get_data()[1]));
    _result = true;
    free_data();
    return _distance;
}

int Ultrasonic::get_distance()
{
    return this->_distance;
}