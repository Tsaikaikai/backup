#define ULTRASONIC_SERAIL_NUMBER 3
#define ULTRASONIC_BAUD_RATE 115200

#define ULTRASONIC_ECHO_COUNT 8
#define ULTRASONIC_ADDR {0xe0, 0xd0, 0xe4, 0xd4, 0xe2, 0xd2, 0xe6, 0xd6}; // sensor順序
#define ULTRASONIC_COMMAND {0xD0, 0x02, 0x05};                            // 測距命令，回傳us值，範圍1~50cm，除以58換算cm，週期時間<9ms