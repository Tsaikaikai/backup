#ifndef HY_BATTERY_h
#define HY_BATTERY_h
#include "SerialStream.h"
#include "Config.h"
enum RegisterAddress : byte
{
  BATTERY_INFORMATION = 0x03,
  CELL_VOLT = 0x04,
  FIRMWARE_VERSION = 0x05,
};
class HYBattery : public SerialStream
{
public:
  HYBattery(int serialNumber, int baudRate, byte header, byte footer) : SerialStream(serialNumber, baudRate, header, footer) {}
  bool set_register(byte registerAddress);
  bool decode_package(byte registerAddress);
  int get_total_volt();
  int get_total_current();
  int get_remaining_capacity();
  float get_normal_capacity();
  int get_cycle_count();
  int get_product_date();
  int get_version();
  int get_SOC();
  float get_temperature();
  float get_SOH();

private:
  bool _decode_battery_information();
  bool _decode_cell_volt();
  bool _decode_firmware_version();
  int _packageLength = 0;
  int _totalVolt = 0;
  int _totalCurrent = 0;
  int _remainingCapacity = 0;
  float _normalCapacity = 0;
  int _cycleCount = 0;
  int _productDate = 0;
  int _version = 0;
  int _SOC = 0;
  float _temperature = 0;
  float _SOH = 0;
  uint8_t _battery_SOH=0;//20230830
 };

#endif
