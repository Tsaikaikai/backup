#include "Config.h"
#include "PackageFormat.h"
#include "HYBattery.h"
#include "Sensor.h"
#include "Ultrasonic.h"
#include "MasterSlaveHandshake.h"

void change_brush_action();
void set_Ultrasonic_IO_State(uint8_t, int);

// Clean Motor Parameter
uint8_t brushRelayState = 0b00000000;
uint8_t motorRunMode = 0;
uint8_t prevMotorRunMode = 0;

int controlTime = 1000; // Unit: ms
byte motorState = MOTOR_STOP;
byte preMotorState = MOTOR_STOP;
byte preRelay2State = RELAY_2_OFF;
byte relay2State = RELAY_2_OFF;
bool controlFlag = false;

// Master Slave UART Parameter
MasterSlaveHandshake _slaveUart(MASTER_SLAVE_UART_SERAIL_NUMBER, MASTER_SLAVE_UART_BAUD_RATE,
                                MASTER_SLAVE_HANDSHAKE_HEADER, MASTER_SLAVE_HANDSHAKE_FOOTER);

// UltraSonic Parameter
Ultrasonic ultrasonics(ULTRASONIC_SERAIL_NUMBER, ULTRASONIC_BAUD_RATE, 0x00, 0x00);
uint8_t _currentUltrasonicWriteCount = ULTRASONIC_ECHO_COUNT;
uint8_t _prevUltrasonicReadCount = ULTRASONIC_ECHO_COUNT;
uint8_t _currentUltrasonicReadCount = ULTRASONIC_ECHO_COUNT; // For Receive Ultrasonic count 0~8
uint8_t ultrasonicErrorCount[ULTRASONIC_ECHO_COUNT] = {0};
uint8_t ultrasonicAlarmCount[ULTRASONIC_ECHO_COUNT] = {0};

// HYBattery Parameter
uint8_t checkBatteryCommandtransfer = 0;
uint32_t batteryAccumulationError = 0;
HYBattery battery(BATTERY_SERAIL_NUMBER, BATTERY_BAUD_RATE, 0xDD, 0x77);
byte batteryErrorStatus = 0xFF;
float batteryCycleTime = 1000 / BATTERY_FREQUENCY; // Unit: ms
bool batteryRequestFlag = {false};
uint16_t _batteryValue[6] = {}; // batterySOC; batterySOH; batteryVoltage; batteryCurrent; batteryCycle; batteryTemperature;

// ANALOG_PIN
byte sensorPins[SENSOR_ECHO_COUNT] = SENSOR_PINS;
byte sensorErrorStatus = 0xFF;
float sensorCycleTime = 1000 / (SENSORFREQUENCY * SENSOR_ECHO_COUNT); // Unit: ms
bool sensorRequestFlag[SENSOR_ECHO_COUNT] = {false};
int _sensorCount = 0;

#if VERSION >= 0x300
SENSOR sensors[SENSOR_ECHO_COUNT] = {SENSOR(sensorPins[0], SENSOR_TYPE_HUMIDITY),
                                     SENSOR(sensorPins[1], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[2], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[3], SENSOR_TYPE),
                                     SENSOR(sensorPins[4], SENSOR_TYPE_CURRENT),
                                     SENSOR(sensorPins[5], SENSOR_TYPE_CURRENT),
                                     SENSOR(sensorPins[6], SENSOR_TYPE_CURRENT),
                                     SENSOR(sensorPins[7], SENSOR_TYPE_CURRENT)};
#endif

union Data_ULTRASONIC
{
  byte byteValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT * 2];
  int intValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT];
  uint16_t uintValue_ULTRASONIC[ULTRASONIC_ECHO_COUNT];
  // long longValue_ULTRASONIC;   // Not Used
  // float floatValue_ULTRASONIC; // Not Used
  // bool boolValue_ULTRASONIC;     // Not Used
  // char charValue_ULTRASONIC[50]; // Not Used
};
static Data_ULTRASONIC _data_ultrasonic = {};

union Data_SENSOR
{
  byte byteValue_SENSOR[SENSOR_ECHO_COUNT * 2];
  int intValue_SENSOR[SENSOR_ECHO_COUNT];
  float floatValue_SENSOR[SENSOR_ECHO_COUNT];
  // long longValue_SENSOR;   // Not Used
  // bool boolValue_SENSOR;     // Not Used
  // char charValue_SENSOR[50]; // Not Used
};
static Data_SENSOR _data_sensor = {};

union Data
{
  long longValue;
  float floatValue;
  byte byteValue[4];
  bool boolValue;
};
static Data _data;

struct Package
{
  byte header = STX;
  byte function = 0;
  byte value[4] = {0xFF, 0xFF, 0xFF, 0xFF};
  byte footer = ETX;
};