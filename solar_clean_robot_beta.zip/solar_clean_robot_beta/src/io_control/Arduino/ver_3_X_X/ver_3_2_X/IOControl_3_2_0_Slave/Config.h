// #define DEBUG
#define VERSION 0x320

// Arduino Setting Parameter
#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1

// SLAVE parameters
#define MASTER_SLAVE_UART_SERAIL_NUMBER 1
#define MASTER_SLAVE_UART_BAUD_RATE 115200
#define MASTER_SLAVE_UART_CYCLE_TIME 20

// Battery parameters
#define BATTERY_SERAIL_NUMBER 2
#define BATTERY_BAUD_RATE 9600
#define BATTERY_FREQUENCY 10 // Unit: Hz
#define CAPCITY 18000
#define BATTERY_RECEIVE_ERROR_COUNT 10
#define BATTERY_READ_TIMEOUT 20 // ms

// Ultrasonic IO Handshake Master Parameter
#define ULTRASONIC_SENSOR_IO_PIN_1 38
#define ULTRASONIC_SENSOR_IO_PIN_2 47
#define ULTRASONIC_SENSOR_IO_PIN_3 48
#define ULTRASONIC_SENSOR_IO_PIN_4 49
#define ULTRASONIC_SENSOR_IO_PIN_5 42
#define ULTRASONIC_SENSOR_IO_PIN_6 43
#define ULTRASONIC_SENSOR_IO_PIN_7 44
#define ULTRASONIC_SENSOR_IO_PIN_8 45
#define ULTRASONIC_BASE 10.0      // mm
#define ULTRASONIC_THRESHOLD 70.0 // mm

// Ultrasonic parameters
#define COMMAND_WAIT_TIME 5 // ms
#define ULTRASONIC_ERROR_COUNT 5
#define ULTRASONIC_SERAIL_NUMBER 3
#define ULTRASONIC_BAUD_RATE 115200
#define ULTRASONIC_ECHO_COUNT 12
#define ULTRASONIC_TIMEOUT 20 // Unit: ms; 0x14=>20; 0xB0=>40
#define ULTRASONIC_RANGE_MAX 2016
#define ULTRASONIC_ADDR {0xe0, 0xd0, 0xe4, 0xd4, 0xe2, 0xd2, 0xe6, 0xd6, 0xe8, 0xd8, 0xea, 0xda}; // sensor順序
#define ULTRASONIC_COMMAND {0xD0, 0x02, 0x14};                                                    // 測距命令,回傳mm值,範圍1~2016mm,週期時間<17ms

// Analog Layout
#define SENSORFREQUENCY 10.0 // Unit: Hz
#define SENSOR_ECHO_COUNT 8
#define SENSOR_PINS {A0, A1, A2, A3, A4, A5, A6, A7};
#define SENSOR_TYPE 500
#define SENSOR_TYPE_TEMPERATURE 501
#define SENSOR_TYPE_CURRENT 502
#define SENSOR_TYPE_HUMIDITY 503
#define SENSOR_TYPE_VOLUME 504
#define SENSOR_TYPE_CURRENT_OLD 505

// Digital Layout
#define BRUSH_START_DELAY 500
#define RELAY_1 26
#define RELAY_2 27
#define RELAY_3 25
