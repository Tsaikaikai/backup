#include "MasterSlaveHandshake.h"

uint8_t MasterSlaveHandshake::_decode_format()
{
    uint8_t _decodeReturn = 0;
    switch (this->_roleType)
    {
    case 0: // Slave
        _decodeReturn = _decode_master_format();
        break;
    case 1: // Master
        _decodeReturn = _decode_slave_format();
        break;
    default:
        _decodeReturn = 0;
        break;
    }
    return _decodeReturn;
}

uint8_t MasterSlaveHandshake::_decode_master_format()
{
    unsigned char *ptrReceivedData = get_data();
    this->masterData.heartbeat = ptrReceivedData[1];
    uint32_t _timestamp = 0;
    uint8_t *_ptrUint32 = (uint8_t *)&_timestamp;
    _ptrUint32[0] = ptrReceivedData[2];
    _ptrUint32[1] = ptrReceivedData[3];
    _ptrUint32[2] = ptrReceivedData[4];
    _ptrUint32[3] = ptrReceivedData[5];
    this->masterData.timestamp = _timestamp;
    this->masterData.cleanMode = ptrReceivedData[6];
    uint16_t _crc16Value = 0;
    uint8_t *_ptrUint16 = (uint8_t *)&_crc16Value;
    _ptrUint16[0] = ptrReceivedData[7];
    _ptrUint16[1] = ptrReceivedData[8];
    this->masterData.crc16 = _crc16Value;
    return 1;
}

uint8_t MasterSlaveHandshake::_decode_slave_format()
{
    unsigned char *ptrReceivedData = get_data();
    this->slaveData.heartbeat = ptrReceivedData[1];
    this->slaveData.brushRelayStatus = ptrReceivedData[2];
    uint8_t _sonarValueIndex = 3;
    uint8_t _sensorValueIndex = 27;
    for (int i = 0; i < 12; i++)
    {
        int16_t _sonarDataValue = 0;
        uint8_t *_ptrSonarUint16 = (uint8_t *)&_sonarDataValue;
        _ptrSonarUint16[0] = ptrReceivedData[_sonarValueIndex++];
        _ptrSonarUint16[1] = ptrReceivedData[_sonarValueIndex++];
        this->slaveData.sonarData[i] = _sonarDataValue;

        if (i < 8)
        {
            int16_t _sensorDataValue = 0;
            uint8_t *_ptrSensorUint16 = (uint8_t *)&_sensorDataValue;
            _ptrSensorUint16[0] = ptrReceivedData[_sensorValueIndex++];
            _ptrSensorUint16[1] = ptrReceivedData[_sensorValueIndex++];
            this->slaveData.sensorsData[i] = _sensorDataValue;
        }
    }
    this->slaveData.batterySOC = ptrReceivedData[43];
    this->slaveData.batterySOH = ptrReceivedData[44];
    uint16_t _batteryValue = 0;
    uint8_t *_ptrbatteryUint16 = (uint8_t *)&_batteryValue;
    _ptrbatteryUint16[0] = ptrReceivedData[45];
    _ptrbatteryUint16[1] = ptrReceivedData[46];
    this->slaveData.batteryVoltage = _batteryValue;
    _ptrbatteryUint16[0] = ptrReceivedData[47];
    _ptrbatteryUint16[1] = ptrReceivedData[48];
    this->slaveData.batteryCurrent = _batteryValue;
    this->slaveData.batteryCycle = ptrReceivedData[49];
    _ptrbatteryUint16[0] = ptrReceivedData[50];
    _ptrbatteryUint16[1] = ptrReceivedData[51];
    this->slaveData.batteryTemperature = _batteryValue;
    uint16_t _crc16Value = 0;
    uint8_t *_ptrUint16 = (uint8_t *)&_crc16Value;
    _ptrUint16[0] = ptrReceivedData[52];
    _ptrUint16[1] = ptrReceivedData[53];
    this->slaveData.crc16 = _crc16Value;
    return 1;
}

uint8_t MasterSlaveHandshake::init_send_data(uint8_t roleType = 0)
{
    this->_roleType = roleType;
    slaveDataLength = sizeof(struct SlaveFormat);
    masterDataLength = sizeof(struct MasterFormat);
    switch (_roleType)
    {
    case 0: // Slave
        slaveData.header = MASTER_SLAVE_HANDSHAKE_HEADER;
        for (int i = 0; i < 12; i++)
        {
            slaveData.sonarData[i] = 0;
            if (i < 8)
            {
                slaveData.sensorsData[i] = 0;
            }
        }
        slaveData.batterySOC = 0;
        slaveData.batterySOH = 0;
        slaveData.batteryVoltage = 0;
        slaveData.batteryCurrent = 0;
        slaveData.batteryCycle = 0;
        slaveData.batteryTemperature = 0;
        slaveData.footer = MASTER_SLAVE_HANDSHAKE_FOOTER;
        set_received_package_length(masterDataLength);
        break;
    case 1: // Master
        masterData.header = MASTER_SLAVE_HANDSHAKE_HEADER;
        masterData.footer = MASTER_SLAVE_HANDSHAKE_FOOTER;
        set_received_package_length(slaveDataLength);
        break;
    default:
        break;
    }
    return 1;
}

uint8_t MasterSlaveHandshake::transfer_data()
{
    _crc16.reset();
    _crc16.setPolynome(0x1021);
    unsigned char *dataPointer = _roleType == 0 ? (unsigned char *)&slaveData : (unsigned char *)&masterData;
    uint8_t _formatLength = _roleType == 0 ? slaveDataLength : masterDataLength;
    uint8_t _calcCRCLength = _formatLength - 3;
    for (int i = 1; i < _calcCRCLength; i++)
    {
        _crc16.add(dataPointer[i]);
    }
    dataPointer[_formatLength - 3] = _crc16.getCRC() & 0x00FF;
    dataPointer[_formatLength - 2] = _crc16.getCRC() >> 8;
    clear_buffer();
    if (write_serial(dataPointer, _formatLength))
        return 0;
    else
        return 1;
}

uint8_t MasterSlaveHandshake::receive_data()
{
    if (read_serial())
    {
        // Serial.println("Read Serial 1 OK.");
        _crc16.reset();
        _crc16.setPolynome(0x1021);
        uint8_t _formatLength = get_package_length(); //_roleType == 0 ? slaveDataLength : masterDataLength;
        uint8_t _calcCRCLength = _formatLength - 3;
        unsigned char *ptrReceivedData = get_data();
        for (int i = 1; i < _calcCRCLength; i++)
            _crc16.add(ptrReceivedData[i]);
        byte _crcLSB = _crc16.getCRC() & 0x00FF;
        byte _crcMSB = _crc16.getCRC() >> 8;
        if (_crcLSB != ptrReceivedData[_formatLength - 3] || _crcMSB != ptrReceivedData[_formatLength - 2])
        {
            // Serial.println("CRC Fail.");
            clear_buffer();
            return 0;
        }

        this->receiveHeartbeat = ptrReceivedData[1];
        this->_decode_format();
    }
    else
    {
        return 0;
    }
    return 1;
}
