#ifndef MASTER_SLAVE_HANDSHAKE_H
#define MASTER_SLAVE_HANDSHAKE_H
#include "CRC16.h"
#include "SerialStream.h"

#define MASTER_SLAVE_HANDSHAKE_HEADER 0xFF
#define MASTER_SLAVE_HANDSHAKE_FOOTER 0xEF

struct MasterFormat
{
    uint8_t header = MASTER_SLAVE_HANDSHAKE_HEADER;
    uint8_t heartbeat;  // 0->1->0->1 loop
    uint32_t timestamp; // unit: 1ms
    uint8_t cleanMode;  // bit0:front brush, bit1:back brush, bit2:保留,
    uint16_t crc16;     //[crc16 high byte, crc16 low byte]
    uint8_t footer = MASTER_SLAVE_HANDSHAKE_FOOTER;
};
struct SlaveFormat
{
    uint8_t header = MASTER_SLAVE_HANDSHAKE_HEADER;
    uint8_t heartbeat;
    uint8_t brushRelayStatus;   // 0b00000111  Relay3,Relay2,Relay1
    int16_t sonarData[12];      //[sonar 1, sonar 2, ...], unit: 1mm
    int16_t sensorsData[8];     //[sensor 1, sensor 2, ...]
    uint8_t batterySOC;         // unit: 1%
    uint8_t batterySOH;         // unit: 1%
    uint16_t batteryVoltage;    // 1mV
    uint16_t batteryCurrent;    // 1mA
    uint8_t batteryCycle;       // unit: 1cycle
    int16_t batteryTemperature; // unit: 0.1C
    uint16_t crc16;             //[crc16 high byte, crc16 low byte]
    uint8_t footer = MASTER_SLAVE_HANDSHAKE_FOOTER;
};

class MasterSlaveHandshake : public SerialStream
{
public:
    MasterSlaveHandshake(int _serialNumber, int32_t _baudRate, byte _header, byte _footer) : SerialStream(_serialNumber, _baudRate, _header, _footer) {}

    uint8_t receiveHeartbeat;

    size_t masterDataLength;
    MasterFormat masterData;
    size_t slaveDataLength;
    SlaveFormat slaveData;

    uint8_t init_send_data(uint8_t roleType);
    uint8_t transfer_data();
    uint8_t receive_data();

private:
    uint8_t _roleType = 0;
    CRC16 _crc16;

    uint8_t _decode_format();
    uint8_t _decode_master_format();
    uint8_t _decode_slave_format();
};
#endif