#define Arduino
#include "Arduino.h"
#include "Sensor.h"

// Initialisation function
SENSOR::SENSOR(int sensorPin, long sensorType)
{
  _sensorPin = sensorPin;
  _type = sensorType;

  // Define pin as Input
  pinMode(_sensorPin, INPUT);
  analogReference(DEFAULT);
}

// Sort an array
void SENSOR::sort(int a[], int size)
{
  for (int i = 0; i < (size - 1); i++)
  {
    bool flag = true;
    for (int o = 0; o < (size - (i + 1)); o++)
    {
      if (a[o] > a[o + 1])
      {
        int t = a[o];
        a[o] = a[o + 1];
        a[o + 1] = t;
        flag = false;
      }
    }
    if (flag)
      break;
  }
}

// Read analog data and compute it
float SENSOR::compute()
{
  // float y =10.0;
  // return y;
  int sensor_val[NB_SAMPLE] = {};
  float data_convert;
  float current;
  int median;

  for (int i = 0; i < NB_SAMPLE; i++)
  {
    // Read analog value
    sensor_val[i] = analogRead(_sensorPin);
  }

  // Get the approx median
#if USE_MEDOFMEDIANS
  median = medianOfMedians(sensor_val, NB_SAMPLE);
#else
  sort(sensor_val, NB_SAMPLE);
  median = sensor_val[NB_SAMPLE / 2];
#endif

  if (_type == 500)
  {
    // Sensor Output Data in Voltage (V)
    data_convert = map(median, 0, 1023, 0, 5000) / 1000.0;
  }
  else if (_type == 501)
  {
    // Temperature Sensor Output Data in Celsius (°C)
    data_convert = 0.48828125 * median;
  }
  else if (_type == 502)
  {
    // Current Sensor Output Data in Ampere (A)
    float value = abs(median * 4.88758553 - 2500) * 1000 / 185;
    if (median == 0 || value <= 251)
      data_convert = 0;
    else
      data_convert = value;
  }
  else if (_type == 503)
  {
    // Humidity Sensor Output Data in Percentage (%)
    // data_convert = 0.09775171 * median;
    data_convert = ((5.0 * (float)median) / 1023.0) / 0.03;
  }
  else if (_type == 504)
  {
    // Volume Sensor Output Data in Decibel (db)
    data_convert = median / 1023 * 1000;
  }
  else if (_type == 505)
  {
    // Old Current Sensor
    data_convert = median * 24.437928;
  }

  return data_convert;
}

int SENSOR::medianOfMedians(int a[], int size)
{
  int ans;
  int numMedians = size / 5;
  int *medians = new int[numMedians];
  for (int i = 0; i < numMedians; i++)
  {
    partialSort(a, i * 5, i * 5 + 4);
    medians[i] = a[i * 5 + 2];
  }
  if (numMedians > 25)
  {
    ans = medianOfMedians(medians, numMedians);
  }
  else
  {
    sort(medians, numMedians);
    ans = medians[numMedians / 2];
  }
  delete[] medians;
  medians = nullptr;
  return ans;
}

// Sort a partial array
void SENSOR::partialSort(int a[], int min, int max)
{
  int t;
  bool flag;
  for (int i = min; i < max; i++)
  {
    flag = true;
    for (int o = min; o < (max - i); o++)
    {
      if (a[o] > a[o + 1])
      {
        t = a[o];
        a[o] = a[o + 1];
        a[o + 1] = t;
        flag = false;
      }
    }
    if (flag)
      break;
  }
}
