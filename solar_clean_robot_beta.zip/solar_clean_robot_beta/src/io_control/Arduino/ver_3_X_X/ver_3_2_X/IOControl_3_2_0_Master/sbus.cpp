
#include "sbus.h" // NOLINT
#include "Arduino.h"

namespace bfs
{
  void SbusRx::Begin()
  {
    if (fast_)
    {
      baud_ = 200000;
    }
    else
    {
      baud_ = 100000;
    }
    uart_->begin(baud_, SERIAL_8E2);

    /* flush the bus */
    uart_->flush();
  }

  bool SbusRx::Read()
  {
    /* Read through all available packets to get the newest */
    new_data_ = false;
    do
    {
      if (Parse())
      {
        new_data_ = true;
      }
    } while (uart_->available());
    return new_data_;
  }

  bool SbusRx::Parse()
  {
    /* Parse messages */
    while (uart_->available())
    {
      cur_byte_ = uart_->read();
      if (state_ == 0)
      {
        if ((cur_byte_ == HEADER_) && ((prev_byte_ == FOOTER_) ||
                                       ((prev_byte_ & 0x0F) == FOOTER2_)))
        {
          buf_[state_++] = cur_byte_;
        }
        else
        {
          state_ = 0;
        }
      }
      else if (state_ < PAYLOAD_LEN_ + HEADER_LEN_)
      {
        buf_[state_++] = cur_byte_;
      }
      else if (state_ < PAYLOAD_LEN_ + HEADER_LEN_ + FOOTER_LEN_)
      {
        state_ = 0;
        prev_byte_ = cur_byte_;
        if ((cur_byte_ == FOOTER_) || ((cur_byte_ & 0x0F) == FOOTER2_))
        {
          /* Grab the channel data */
          data_.ch[0] = static_cast<int16_t>(buf_[1] |
                                             ((buf_[2] << 8) & 0x07FF));
          data_.ch[1] = static_cast<int16_t>((buf_[2] >> 3) |
                                             ((buf_[3] << 5) & 0x07FF));
          data_.ch[2] = static_cast<int16_t>((buf_[3] >> 6) |
                                             (buf_[4] << 2) |
                                             ((buf_[5] << 10) & 0x07FF));
          data_.ch[3] = static_cast<int16_t>((buf_[5] >> 1) |
                                             ((buf_[6] << 7) & 0x07FF));
          data_.ch[4] = static_cast<int16_t>((buf_[6] >> 4) |
                                             ((buf_[7] << 4) & 0x07FF));
          data_.ch[5] = static_cast<int16_t>((buf_[7] >> 7) |
                                             (buf_[8] << 1) |
                                             ((buf_[9] << 9) & 0x07FF));
          data_.ch[6] = static_cast<int16_t>((buf_[9] >> 2) |
                                             ((buf_[10] << 6) & 0x07FF));
          data_.ch[7] = static_cast<int16_t>((buf_[10] >> 5) |
                                             ((buf_[11] << 3) & 0x07FF));
          data_.ch[8] = static_cast<int16_t>(buf_[12] |
                                             ((buf_[13] << 8) & 0x07FF));
          data_.ch[9] = static_cast<int16_t>((buf_[13] >> 3) |
                                             ((buf_[14] << 5) & 0x07FF));
          data_.ch[10] = static_cast<int16_t>((buf_[14] >> 6) |
                                              (buf_[15] << 2) |
                                              ((buf_[16] << 10) & 0x07FF));
          data_.ch[11] = static_cast<int16_t>((buf_[16] >> 1) |
                                              ((buf_[17] << 7) & 0x07FF));
          data_.ch[12] = static_cast<int16_t>((buf_[17] >> 4) |
                                              ((buf_[18] << 4) & 0x07FF));
          data_.ch[13] = static_cast<int16_t>((buf_[18] >> 7) |
                                              (buf_[19] << 1) |
                                              ((buf_[20] << 9) & 0x07FF));
          data_.ch[14] = static_cast<int16_t>((buf_[20] >> 2) |
                                              ((buf_[21] << 6) & 0x07FF));
          data_.ch[15] = static_cast<int16_t>((buf_[21] >> 5) |
                                              ((buf_[22] << 3) & 0x07FF));
          /* CH 17 */
          data_.ch17 = buf_[23] & CH17_MASK_;
          /* CH 18 */
          data_.ch18 = buf_[23] & CH18_MASK_;
          /* Grab the lost frame */
          data_.lost_frame = buf_[23] & LOST_FRAME_MASK_;
          /* Grab the failsafe */
          data_.failsafe = buf_[23] & FAILSAFE_MASK_;
          return true;
        }
        else
        {
          return false;
        }
      }
      else
      {
        state_ = 0;
      }
      prev_byte_ = cur_byte_;
    }
    return false;
  }

  void SbusTx::Begin()
  {
    if (fast_)
    {
      baud_ = 200000;
    }
    else
    {
      baud_ = 100000;
    }
    /* Start the bus */
    uart_->begin(baud_, SERIAL_8E2);
  }

  void SbusTx::Write()
  {
    /* Assemble packet */
    buf_[0] = HEADER_;
    buf_[1] = static_cast<uint8_t>((data_.ch[0] & 0x07FF));
    buf_[2] = static_cast<uint8_t>((data_.ch[0] & 0x07FF) >> 8 |
                                   (data_.ch[1] & 0x07FF) << 3);
    buf_[3] = static_cast<uint8_t>((data_.ch[1] & 0x07FF) >> 5 |
                                   (data_.ch[2] & 0x07FF) << 6);
    buf_[4] = static_cast<uint8_t>((data_.ch[2] & 0x07FF) >> 2);
    buf_[5] = static_cast<uint8_t>((data_.ch[2] & 0x07FF) >> 10 |
                                   (data_.ch[3] & 0x07FF) << 1);
    buf_[6] = static_cast<uint8_t>((data_.ch[3] & 0x07FF) >> 7 |
                                   (data_.ch[4] & 0x07FF) << 4);
    buf_[7] = static_cast<uint8_t>((data_.ch[4] & 0x07FF) >> 4 |
                                   (data_.ch[5] & 0x07FF) << 7);
    buf_[8] = static_cast<uint8_t>((data_.ch[5] & 0x07FF) >> 1);
    buf_[9] = static_cast<uint8_t>((data_.ch[5] & 0x07FF) >> 9 |
                                   (data_.ch[6] & 0x07FF) << 2);
    buf_[10] = static_cast<uint8_t>((data_.ch[6] & 0x07FF) >> 6 |
                                    (data_.ch[7] & 0x07FF) << 5);
    buf_[11] = static_cast<uint8_t>((data_.ch[7] & 0x07FF) >> 3);
    buf_[12] = static_cast<uint8_t>((data_.ch[8] & 0x07FF));
    buf_[13] = static_cast<uint8_t>((data_.ch[8] & 0x07FF) >> 8 |
                                    (data_.ch[9] & 0x07FF) << 3);
    buf_[14] = static_cast<uint8_t>((data_.ch[9] & 0x07FF) >> 5 |
                                    (data_.ch[10] & 0x07FF) << 6);
    buf_[15] = static_cast<uint8_t>((data_.ch[10] & 0x07FF) >> 2);
    buf_[16] = static_cast<uint8_t>((data_.ch[10] & 0x07FF) >> 10 |
                                    (data_.ch[11] & 0x07FF) << 1);
    buf_[17] = static_cast<uint8_t>((data_.ch[11] & 0x07FF) >> 7 |
                                    (data_.ch[12] & 0x07FF) << 4);
    buf_[18] = static_cast<uint8_t>((data_.ch[12] & 0x07FF) >> 4 |
                                    (data_.ch[13] & 0x07FF) << 7);
    buf_[19] = static_cast<uint8_t>((data_.ch[13] & 0x07FF) >> 1);
    buf_[20] = static_cast<uint8_t>((data_.ch[13] & 0x07FF) >> 9 |
                                    (data_.ch[14] & 0x07FF) << 2);
    buf_[21] = static_cast<uint8_t>((data_.ch[14] & 0x07FF) >> 6 |
                                    (data_.ch[15] & 0x07FF) << 5);
    buf_[22] = static_cast<uint8_t>((data_.ch[15] & 0x07FF) >> 3);
    buf_[23] = 0x00 | (data_.ch17 * CH17_MASK_) | (data_.ch18 * CH18_MASK_) |
               (data_.failsafe * FAILSAFE_MASK_) |
               (data_.lost_frame * LOST_FRAME_MASK_);
    buf_[24] = FOOTER_;
    /* Send packet to servos */
    uart_->write(buf_, sizeof(buf_));
  }

} // namespace bfs
