#include "RobotAPI.h"

void RobotAPI::getFormatLen()
{
    tranLen = sizeof(struct RobotData);
    recvLen = sizeof(struct RobotCommand);
}

bool RobotAPI::post_data(RobotData *_data)  //20231013 RobotAPI.h\struct RobotData   // Master>IPC
{
    bool _return = false;
    crc16.reset();
    crc16.setPolynome(0x1021); //多項式

    unsigned char *dataPointer = (unsigned char *)_data; //20231013 將_data轉成unsigned char型態
    for (int i = 1; i < sizeof(*_data) - 4; i++) //-4無須取crc16之後的
    {
        crc16.add(dataPointer[i]);
    }
    dataPointer[sizeof(*_data) - 4] = crc16.getCRC() & 0x00FF; // -4 對應CRC高位元組   總長度-1代表倒數第一陣列(一陣列=1byte=8bit)
    dataPointer[sizeof(*_data) - 3] = crc16.getCRC() >> 8;     // -3 對應CRC低位元組
    if (this->post(dataPointer, sizeof(*_data)))
    {
        _return = true;
    }

    return _return;
}

RobotCommand RobotAPI::get_command()
{
    return this->_robotCommand; //20231013 回傳_robotCommand 相關
}

// deocde binary package from middle ware
bool RobotAPI::decode_package() // 解封包
{
    bool _return = false;
    if (get_data()[0] != 0xff || get_data()[12] != 0xee)
        return false;
    this->_robotCommand.header = get_data()[0];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0])) = get_data()[1];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 1) = get_data()[2];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 2) = get_data()[3];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[0]) + 3) = get_data()[4];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1])) = get_data()[5];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 1) = get_data()[6];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 2) = get_data()[7];
    *((uint8_t *)(&this->_robotCommand.motorVelocity[1]) + 3) = get_data()[8];
    this->_robotCommand.cleanMode = get_data()[9];
    // this->_robotCommand.crc16 = get_data()[10] + (get_data()[11] << 8);
    this->_robotCommand.footer = get_data()[12];
    _return = true;
    return _return;
}
