#ifndef JOY_STICK_H
#define JOY_STICK_H

#define Arduino
#include "Arduino.h"
#include "sbus.h"

// #define INTERLOCKE_ENABLE_LOWEST_TIME 1800
// #define INTERLOCKE_ENABLE_HIGHEST_TIME 2500
// #define STATIC_SAFETY_RANGE_UPPER 1600
// #define STATIC_SAFETY_RANGE_LOWER 1300
// #define DIRECTION_RANGE_MIN 1000
// #define DIRECTION_RANGE_MAX 1900

#define BUTTON_ENABLE_LOW 500 // 1000
#define BUTTON_ENABLE_HIGH 1500
#define DIRECTION_RANGE_MIN 450
#define DIRECTION_RANGE_MAX 1550
#define STATIC_SAFETY_RANGE_LOWER 750  
#define STATIC_SAFETY_RANGE_UPPER 1250 

class JoyStick
{
public:
    JoyStick(int serialNumber);
    ~JoyStick();

    uint8_t get_velocity(float *linearVelocity, float *angularVelocity);
    uint8_t operatorCarMode;

private:
    uint8_t _getInterlockState();
    int8_t _get_left_x();
    int8_t _get_left_y();
    uint8_t _get_accelerator();
    uint8_t _check_operate_mode();
    uint8_t _readChannelData();

    Stream *_selectSerial = nullptr;
    bfs::SbusRx *sbus_rx = nullptr;
    bfs::SbusTx *sbus_tx = nullptr;
    bfs::SbusData data;

    uint32_t _oldRecvTime = 0;
};

#endif