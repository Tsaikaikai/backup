#include "EthernetStream.h"
#include "Config.h"
EthernetStream::EthernetStream(byte *macAdress, byte *ip, byte *gateway, byte *subnet, int port, int resetPin, int controlPin)
{
    _resetPin = resetPin;
    _controlPin = controlPin;
    _macAdress = macAdress;
    _ip = ip;
    _gateway = gateway;
    _subnet = subnet;
    _port = port;
    Ethernet.init(_controlPin);
    pinMode(_resetPin, OUTPUT);
    digitalWrite(_resetPin, LOW);
    delay(200);
    digitalWrite(_resetPin, HIGH);
    delay(200);
    this->_server = new EthernetServer(port);
    Ethernet.begin(macAdress, ip, gateway, subnet);
    delay(100);
    this->_server->begin();
#ifdef DEBUGLOG
    Serial2.print("server is at ");
    Serial2.print(Ethernet.localIP());
    Serial2.print(":");
    Serial2.println(port);
#endif
}
EthernetStream::~EthernetStream()
{
}

uint8_t EthernetStream::resetEthernet()
{
    digitalWrite(_resetPin, LOW);
    delay(50);
    delete this->_server;
    this->_server = NULL;
    digitalWrite(_resetPin, HIGH);
    delay(50);
    this->_server = new EthernetServer(_port);
    Ethernet.begin(_macAdress, _ip, _gateway, _subnet);
    delay(20);
    this->_server->begin();
#ifdef DEBUGLOG
    Serial2.print("server is at ");
    Serial2.print(Ethernet.localIP());
    Serial2.print(":");
    Serial2.println(_port);
#endif
    return 0;
}

bool EthernetStream::connect_available()
{
    bool _return = false;
    this->_client = &this->_server->available();
    if (*this->_client)
    {
        _return = true;
    }
    else
    {
        _return = false;
    }
    return _return;
}
bool EthernetStream::client_available()
{
    return this->_client->available();
}

bool EthernetStream::client_connected()
{
    return this->_client->connected();
}

byte byteData[1024] = {0};
byte _recvData[20] = {0};
uint8_t _indexID = 0;
uint32_t getcmdtime = 0;
uint8_t _recvFlag = 0;
bool EthernetStream::post(unsigned char *data, int length)
{
    // Serial.print(millis());
    // Serial.println("  Will Post.");
    bool _return = false;
    int _value = this->_client->read();
    if (_value > -1)
    {
        byteData[_indexID] = (byte)_value;
        _indexID++;
        if (_indexID >= 1024)
            _indexID = 0; // 如果超過陣列最大值則重製
        if ((byte)_value == '\n')
        {
            // Serial.print(" String:");
            // for (int i = 0; i < _indexID; i++)
            // {
            //     Serial.print(byteData[i], HEX);
            //     Serial.print(" ");
            // }
            // Serial.println();

            // L-1 = \n , L-2 = 0xee , L-3 = crcM , L-4 = crcL
            // L-5 = clear mode
            // L-6-7-8-9 = float angular velocity
            // L-10-11-12-13 = float linear velocity
            // L-14 = 0xff
            // if (_indexID >= 14 &&
            //     byteData[_indexID - 2] == 0xee &&
            //     byteData[_indexID - 14] == 0xff)
            if (_indexID >= (recvLen - 1) &&                       
                byteData[_indexID - 2] == 0xee &&                   //footer = 0xEE 
                byteData[_indexID - (recvLen + 1)] == 0xff)         //header = 0xFF  
            {
                netCRC16.reset();
                netCRC16.setPolynome(0x1021);                       //CCITT CRC16 多項式:x16+x12+x5+1
                uint8_t startIndex = _indexID - (recvLen + 1);
                for (int i = 0; i < recvLen; i++)
                {
                    _recvData[i] = byteData[i + startIndex];
                    if (i < (recvLen - 3))
                    {
                        netCRC16.add(_recvData[i]);
                    }
                }
                    //_recvData[(recvLen - 3)] != (netCRC16.getCRC() & 0x00FF)========LSB
                    //_recvData[(recvLen - 2)] != (netCRC16.getCRC() >> 8     ========MSB
                if (_recvData[(recvLen - 3)] != (netCRC16.getCRC() & 0x00FF) || _recvData[(recvLen - 2)] != (netCRC16.getCRC() >> 8))
                {
                    uint16_t _ipcCRC16 = (_recvData[(recvLen - 3)] & 0x00FF) | ((_recvData[(recvLen - 2)] & 0x00FF) << 8);
                    Serial2.print("Board Calc-> CRC16: [");
                    Serial2.print(netCRC16.getCRC());
                    Serial2.print("] ,LSB[");
                    Serial2.print(netCRC16.getCRC() & 0x00FF);
                    Serial2.print("] ,MSB[");
                    Serial2.print(netCRC16.getCRC() >> 8);
                    Serial2.print("],   IPC-> CRC16: [");
                    Serial2.print(_ipcCRC16);
                    Serial2.print("] ,LSB[");
                    Serial2.print(_recvData[(recvLen - 3)]);
                    Serial2.print("] ,MSB[");
                    Serial2.print(_recvData[(recvLen - 2)]);
                    Serial2.println("]  ,Recv IPC CRC16 Error.");

                    Serial.print("Board Calc-> CRC16: [");
                    Serial.print(netCRC16.getCRC());
                    Serial.print("] ,LSB[");
                    Serial.print(netCRC16.getCRC() & 0x00FF);
                    Serial.print("] ,MSB[");
                    Serial.print(netCRC16.getCRC() >> 8);
                    Serial.print("],   IPC-> CRC16: [");
                    Serial.print(_ipcCRC16);
                    Serial.print("] ,LSB[");
                    Serial.print(_recvData[(recvLen - 3)]);
                    Serial.print("] ,MSB[");
                    Serial.print(_recvData[(recvLen - 2)]);
                    Serial.println("]  ,Recv IPC CRC16 Error.");
                }

                if (this->_client->availableForWrite())
                {
                    this->_client->write(data, length);
                }
                else
                {
                    Serial2.println("Send Buffer Full.");
                    Serial.println("Send Buffer Full.");
                }

                // 20230906------------------
                uint32_t costtime = millis() - getcmdtime;
                if (costtime > 200)
                {
                    Serial2.print("timeout, ");
                    Serial2.print(costtime);
                    Serial2.println(" ms.");

                    Serial.print("timeout, ");
                    Serial.print(costtime);
                    Serial.println(" ms.");
                    // 20230906------------------
                    Serial2.print("Timeout Get IPC Command: ");
                    Serial2.print("[0,");
                    Serial2.print(byteData[0]);
                    Serial2.print("]");

                    Serial.print("Timeout Get IPC Command: ");
                    Serial.print("[0,");
                    Serial.print(byteData[0]);
                    Serial.print("]");
                    int iTotalCount = _indexID - 1;
                    for (int i = 1; i < iTotalCount; i++)
                    {
                        Serial2.print("-[");
                        Serial2.print(i);
                        Serial2.print(",");
                        Serial2.print(byteData[i]);
                        Serial2.print("]");

                        Serial.print("-[");
                        Serial.print(i);
                        Serial.print(",");
                        Serial.print(byteData[i]);
                        Serial.print("]");
                    }
                    Serial2.println(".");
                    Serial.println(".");
                    //--------------------------
                }
                getcmdtime = millis();
                //-----------------------------

                // this->_data_convert();
                this->_readString = "";
                _indexID = 0;
                _return = true;
            }
            else if (_indexID >= 14)
            {
                // 收到\n字符, 但往前推的格式錯誤
                Serial2.print("Receive Length Over. ");
                Serial2.println(_indexID);

                Serial2.print("Timeout Get IPC Command: ");
                Serial2.print("[0,");
                Serial2.print(byteData[0]);
                Serial2.print("]");

                Serial.print("Receive Length Over. ");
                Serial.println(_indexID);

                Serial.print("Timeout Get IPC Command: ");
                Serial.print("[0,");
                Serial.print(byteData[0]);
                Serial.print("]");
                int iTotalCount = _indexID - 1;
                for (int i = 1; i < iTotalCount; i++)
                {
                    Serial2.print("-[");
                    Serial2.print(i);
                    Serial2.print(",");
                    Serial2.print(byteData[i]);
                    Serial2.print("]");
                    Serial.print("-[");
                    Serial.print(i);
                    Serial.print(",");
                    Serial.print(byteData[i]);
                    Serial.print("]");
                }
                Serial2.println(".");
                Serial.println(".");
                _indexID = 0;
            }
        }
    }
    return _return;
}

uint8_t *EthernetStream::get_data()
{
    // return this->_data;
    return _recvData;
}

bool EthernetStream::_data_convert(String data) // String data
{
    bool _return = false;
    // int _index = data.indexOf("/FF") + 1;
    // int _end = data.indexOf("EE/") + 1;
    // int _indexNumber = 0;

    // for (int i = _index; i < _end; i += 2)
    // {
    //     this->_data[_indexNumber] = (uint8_t)strtol(data.substring(i, i + 2).c_str(), NULL, 16);
    //     _indexNumber++;
    // }

    // this->_data[0] = byteData[0];

    _return = true;

    // for (int i = 0; i < 100; i++)
    // {
    //     Serial.print(this->get_data()[i], HEX);
    //     Serial.print(" ");
    // }
    // Serial.println();

    return _return;
}
