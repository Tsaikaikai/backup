
#include "PackageFormat.h"
#include "Config.h"
#include "MotorDriver.h"
#include "RobotAPI.h"
#include "JoyStick.h"
#include "MasterSlaveHandshake.h"

float updateMoveStatusCycleTime = 100; // 毫秒

byte robotMacAddress[6] = ROBOT_MAC_ADDRESS;
byte robotIp[4] = ROBOT_IP;
byte robotGateway[4] = ROBOT_GATEWAY;
byte robotSubnet[4] = ROBOT_SUBNET;
int robotPort = ROBOT_PORT;

int motorcommandL = 0;
int motorcommandR = 0;

RobotAPI *robot;
MotorDriver *motorL;
MotorDriver *motorR;
JoyStick *joyStick;

RobotData robotData;
RobotCommand robotCommand;

// 系統狀態
uint8_t slaveState = 0;
int actionControlType; // 0:初始狀態,無控制  1:遙控器控制  2:上位控制
int currentActionControlType;
uint8_t driverAlarmState = 0;
uint8_t _wdtResetFlag = 1;
uint8_t _errorCount = 0;
uint8_t _ethernetCommunicationStatus = 0; // 20230823

// CCD IO 觸發參數
char prevMoveDIR = 'F';

// 里程相關
unsigned long prevLeftPulse = 0;  // 20230920
unsigned long prevRightPulse = 0; // 20230920
float relativeMoveCoordinateX = 0;
float relativeMoveCoordinateY = 0;
float prevRelativeMoveCoordinateX = 0;
float prevRelativeMoveCoordinateY = 0;
float relativeMoveTheta = 0;
float totalMileage = 0;

// 搖桿添加後續再修改
// Switch
uint8_t readJoyState = 0;
float getJoyLineVelocity = 0.0;
float getJoyAngularVelocity = 0.0;

// Rotate
int motorMoveStatus = 0; // 0->靜止   1->移動

// Master Slave UART 相關
uint8_t uartHeartbeat = 0;
uint32_t uartAccumulationError = 0;
uint8_t checkCommandtransfer = 0;
// JoyStick joystick(LEFT_X_PIN, LEFT_Y_PIN, VELOCITY_PIN, INTERLOCK_PIN, CLEAR_COUNT_PIN, JOY_MODE_PIN);
MasterSlaveHandshake _masterUart(MASTER_SLAVE_UART_SERAIL_NUMBER, MASTER_SLAVE_UART_BAUD_RATE,
                                 MASTER_SLAVE_HANDSHAKE_HEADER, MASTER_SLAVE_HANDSHAKE_FOOTER);

void _check_sensor_abnormal_stop(float *velocity);
void _check_motor_status();
void _update_mileage();
int _change_operating_mode_stop();

void interrupt_hall_sensor_U_R();
void interrupt_hall_sensor_U_L();
int freeRam();
