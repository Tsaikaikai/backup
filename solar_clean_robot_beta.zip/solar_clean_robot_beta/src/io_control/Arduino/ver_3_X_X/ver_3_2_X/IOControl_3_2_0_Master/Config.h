// #define DEBUG
#define DEBUGLOG
#define VERSION 0x320

// Arduino Setting Parameter
#define BAUD_RATE 115200
#define SERIAL_CONFIG SERIAL_8N1
// Robot parameters
#define ROBOT_IP         \
    {                    \
        192, 168, 10, 10 \
    }
#define ROBOT_GATEWAY     \
    {                     \
        192, 168, 10, 254 \
    }
#define ROBOT_SUBNET     \
    {                    \
        255, 255, 255, 0 \
    }

#define ROBOT_MAC_ADDRESS                  \
    {                                      \
        0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED \
    }
#define ROBOT_PORT 80
#define ROBOT_FREQUENCY 10
#define ROBOT_RESET_PIN 24
#define ROBOT_CONTROL_PIN 53

// Master Slave UART Time
#define MASTER_SLAVE_UART_SERAIL_NUMBER 1
#define MASTER_SLAVE_UART_BAUD_RATE 115200
#define MASTER_SLAVE_UART_CYCLE_TIME 30
#define MASTER_SLAVE_UART_TIMEOUT 25
#define MASTER_SLAVE_RECEIVE_ERROR_COUNT 50

// CCD Gap IO
#define CCD_GAP_IO_ON_TIME 1500 // ms
#define RESET_TIME 500          // ms
#define CCD_GAP_IO_P7 4
#define CCD_GAP_IO_P6 5

// Ultrasonic IO Handshake Master Parameter
#define ULTRASONIC_SENSOR_IO_PIN_1 61
#define ULTRASONIC_SENSOR_IO_PIN_2 62
#define ULTRASONIC_SENSOR_IO_PIN_3 63
#define ULTRASONIC_SENSOR_IO_PIN_4 64
#define ULTRASONIC_SENSOR_IO_PIN_5 60
#define ULTRASONIC_SENSOR_IO_PIN_6 59
#define ULTRASONIC_SENSOR_IO_PIN_7 58
#define ULTRASONIC_SENSOR_IO_PIN_8 57
//
#define COLLISION_STOP_MIN 1   // mm
#define COLLISION_STOP_MAX 600 // mm

#define SLOW_KEEP_TIME 1000 // ms

// Motor parameters
#define MOTOR_FREQUENCY 10
#define MOTOR_ACCELERATE 10
#define MOTOR_ECHO_COUNT 2
#define WHEEL_RADIUS 0.032 // 0.035
#define WHEEL_BASE 0.614   // 0.63
#define GEAR_RATIO 30.0    // 20.0
#define WHEEL_PULSE 5.0    // 100.0
#define PI 3.1415926535897932384626433832795

#define CLINET_COMMUNICATION_TIMEOUT 5000 // ms
#define CLINET_CONNECTION_TIMEOUT 200     // ms
#define VOLTAGE_BUCK_WAIT_TIME 1000       // ms
#define START_BUFFER_TIME 50              // ms
#define STOP_BUFFER_TIME 200              // ms
#define DUTY_CYCLE_MIN 26                 // 10%
#define DUTY_CYCLE_MAX 204                // 80%
#define DRIVER_RPM_MIN 100
#define DRIVER_RPM_MAX 4000

#define VOLTAGE_BUCK_PIN 31 // 24V降壓至12V 控制腳 LOW:24V  HIGH:12V
#define MOTOR_RESET 38      // 驅動器RESET 腳位,啟動後設HIGH
// Right Motor
#define MOTOR_R 1         // 馬達編號
#define MOTOR_R_INVERS -1 // 1:invers; -1:no invers
#define MOTOR_R_PWM_PIN 7
#define MOTOR_R_ALARM_PIN 42
#define MOTOR_R_RUN_BREAK_PIN 41 // HIGH:Break; LOW:Run
#define MOTOR_R_CWCCW_PIN 40     // HIGH:Forward; LOW:Back
#define MOTOR_R_LOCK_PIN 25      // HIGH:Forward; LOW:Back
#define MOTOR_R_HALL_U_PIN 2

// Left Motor
#define MOTOR_L 0        // 馬達編號
#define MOTOR_L_INVERS 1 // 1:invers; -1:no invers
#define MOTOR_L_PWM_PIN 8
#define MOTOR_L_ALARM_PIN 43
#define MOTOR_L_RUN_BREAK_PIN 37 // HIGH:Break; LOW:Run
#define MOTOR_L_CWCCW_PIN 36     // HIGH:Forward; LOW:Back
#define MOTOR_L_LOCK_PIN 25      // HIGH:Forward; LOW:Back
#define MOTOR_L_HALL_U_PIN 3

// Joystick parameters
#define JOY_SERIAL_NUMBER 3
#define JOY_CONTROL_HIGHT_LIMIT_MAX 400 // mm ->  V/10 cm

// IMU parameters
#define IMU_SERIAL_NUMBER 2
#define IMU_BAUD_RATE 115200
#define IMU_FREQUENCY 10

// BUTTON
#define BUTTON_1 26
#define BUTTON_2 28
#define BUTTON_3 39
#define BUTTON_LED_1 27
#define BUTTON_LED_2 29
#define BUTTON_LED_3 30
// BZ
#define BZ_IO_PIN 44
// Leak sensor
#define leak_Sensor_PIN 46
