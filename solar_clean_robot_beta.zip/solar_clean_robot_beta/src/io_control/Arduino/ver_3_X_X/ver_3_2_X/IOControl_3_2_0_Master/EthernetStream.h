#ifndef ETHERNET_STREAM_h
#define ETHERNET_STREAM_h
#include "Arduino.h"
#include <SPI.h>
#include <Ethernet.h>
#include "CRC16.h"

class EthernetStream
{
public:
  EthernetStream(byte *macAdress, byte *ip, byte *gateway, byte *subnet, int port, int resetPin, int controlPin);
  ~EthernetStream();
  bool connect_available();
  bool client_available();
  bool client_connected();
  bool post(unsigned char *data, int length);
  uint8_t *get_data();
  uint8_t resetEthernet();
  size_t recvLen = 0;
  size_t tranLen = 0;

private:
  bool _data_convert(String data);
  EthernetServer *_server;
  EthernetClient *_client;
  byte *_macAdress;
  byte *_ip;
  byte *_gateway;
  byte *_subnet;
  int _port;
  int _resetPin;
  int _controlPin;
  String _readString;
  uint8_t _data[100];
  CRC16 netCRC16; //[crc16 high byte, crc16 low byte]
};

#endif
