#ifndef ROBOT_API_H
#define ROBOT_API_H
#include "Config.h"
#include "EthernetStream.h"
#include "CRC16.h"
#include "PackageFormat.h"

struct RobotCommand // IPC>Master
{
    uint8_t header;
    float motorVelocity[2]; //[linear velocity, angular velocity], unit: 1m/s, 1rad/s
    uint8_t cleanMode;      // 0: stop, 1: clean front, 2: clean back, 3: clean both  // 32
    uint16_t crc16;         //[crc16 high byte, crc16 low byte]
    uint8_t footer;
};
struct RobotData // Master>IPC
{
    uint8_t header = 0xFF;
    uint32_t timestamp;         // unit: 1ms
    uint8_t buttonStatus;       //[power button, clean button, ...]
    float odometry[3];          // [x, y,  theta], unit: 1.0m, 1.0m,  1.0rad
    float mileage;              // unit: 1.0m
    int16_t sonarData[8];       //[sonar 1, sonar 2, ...], unit: 1mm
    int16_t sensorsData[8];     //[sensor 1, sensor 2, ...]
    uint8_t batterySOC;         // unit: 1%
    uint8_t batterySOH;         // unit: 1%
    uint16_t batteryVoltage;    // 1mV
    uint16_t batteryCurrent;    // 1mA
    uint8_t batteryCycle;       // unit: 1cycle
    int16_t batteryTemperature; // unit: 0.1C
    uint16_t crc16;             //[crc16 high byte, crc16 low byte]
    uint8_t footer = 0xEE;
    uint8_t endCharacter = '\n';
};

class RobotAPI : public EthernetStream
{
public:
    RobotAPI(byte *_macAdress, byte *_ip, byte *_gateway, byte *_subnet, int _port, int resetPin, int controlPin) : EthernetStream(_macAdress, _ip, _gateway, _subnet, _port, resetPin, controlPin) {}
    void getFormatLen();
    bool post_data(RobotData *_data); //*_data 可有可無 指定記憶體第一個位置
    RobotCommand get_command();
    bool decode_package();

private:
    String _readString;
    RobotCommand _robotCommand;
    RobotData _robotData;
    CRC16 crc16;
};
#endif
