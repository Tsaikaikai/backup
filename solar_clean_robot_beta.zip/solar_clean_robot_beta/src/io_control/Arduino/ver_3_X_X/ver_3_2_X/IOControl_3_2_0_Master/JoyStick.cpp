#define Arduino
#include "Arduino.h"
#include "JoyStick.h"

// Initialisation function
JoyStick::JoyStick(int serialNumber)
{
#ifdef DEBUG
    Serial.println("New JoyStick.");
#endif
    switch (serialNumber)
    {
    case 0:
        this->sbus_rx = new bfs::SbusRx(&Serial);
        this->sbus_tx = new bfs::SbusTx(&Serial);
        break;
    case 1:
        this->sbus_rx = new bfs::SbusRx(&Serial1);
        this->sbus_tx = new bfs::SbusTx(&Serial1);
        break;
    case 2:
        this->sbus_rx = new bfs::SbusRx(&Serial2);
        this->sbus_tx = new bfs::SbusTx(&Serial2);
        break;
    case 3:
        this->sbus_rx = new bfs::SbusRx(&Serial3);
        this->sbus_tx = new bfs::SbusTx(&Serial3);
        break;
    }

    this->sbus_rx->Begin();
    this->sbus_tx->Begin();

    operatorCarMode = 2;
}

JoyStick::~JoyStick()
{
}

uint8_t JoyStick::_getInterlockState()
{
    // Serial.println(this->data.ch[5]);
    if (this->data.ch[5] > BUTTON_ENABLE_HIGH)
        return 1;
    else
        return 0;
}

int8_t JoyStick::_get_left_x()
{
    if (this->data.ch[0] >= STATIC_SAFETY_RANGE_LOWER && this->data.ch[0] <= STATIC_SAFETY_RANGE_UPPER)
    { // 水平搖桿接近中間, 不移動
        return 0;
    }
    if (this->data.ch[0] < STATIC_SAFETY_RANGE_LOWER)
    { // 左轉
        if (this->data.ch[0] < DIRECTION_RANGE_MIN)
            return 10;
        int8_t _valuelevel = map(this->data.ch[0], DIRECTION_RANGE_MIN, STATIC_SAFETY_RANGE_LOWER, 0, 10); // -10 0
        return _valuelevel;
    }
    if (this->data.ch[0] > STATIC_SAFETY_RANGE_UPPER)
    { // 右轉
        if (this->data.ch[0] > DIRECTION_RANGE_MAX)
            return -10;
        int8_t _valuelevel = map(this->data.ch[0], STATIC_SAFETY_RANGE_UPPER, DIRECTION_RANGE_MAX, -10, 0); // 0  10
        return _valuelevel;
    }
    return 0;
}

int8_t JoyStick::_get_left_y()
{
    if (this->data.ch[1] >= STATIC_SAFETY_RANGE_LOWER && this->data.ch[1] <= STATIC_SAFETY_RANGE_UPPER)
    { // 水平搖桿接近中間, 不移動
        return 0;
    }
    if (this->data.ch[1] < STATIC_SAFETY_RANGE_LOWER)
    { // 後退
        if (this->data.ch[1] < DIRECTION_RANGE_MIN)
            return -10;
        int8_t _valuelevel = map(this->data.ch[1], DIRECTION_RANGE_MIN, STATIC_SAFETY_RANGE_LOWER, -10, 0);
        return _valuelevel;
    }
    if (this->data.ch[1] > STATIC_SAFETY_RANGE_UPPER)
    { // 前進
        if (this->data.ch[1] > DIRECTION_RANGE_MAX)
            return 10;
        int8_t _valuelevel = map(this->data.ch[1], STATIC_SAFETY_RANGE_UPPER, DIRECTION_RANGE_MAX, 0, 10);
        return _valuelevel;
    }
    return 0;
}

uint8_t JoyStick::_get_accelerator()
{
    if (this->data.ch[2] < DIRECTION_RANGE_MIN)
        return 0;
    if (this->data.ch[2] > DIRECTION_RANGE_MAX)
        return 10;
    uint8_t _valuelevel = map(this->data.ch[2], DIRECTION_RANGE_MIN, DIRECTION_RANGE_MAX, 0, 10);
    return _valuelevel;
    return 0;
}

uint8_t JoyStick::_check_operate_mode()
{ // 0:初始狀態,無控制  1:遙控器控制  2:上位控制

    // Serial.println(this->data.ch[4]);
    if (this->data.ch[4] < BUTTON_ENABLE_LOW)
    {
        operatorCarMode = 2;
    }
    else if (this->data.ch[4] > BUTTON_ENABLE_HIGH)
    {
        operatorCarMode = 1;
    }
    else
    {
        operatorCarMode = 0;
    }
    return 1;
}

uint8_t JoyStick::get_velocity(float *linearVelocity, float *angularVelocity)
{
    if (this->sbus_rx->Read())
    {
        this->data = sbus_rx->data();
        // Serial.print(millis());
        // Serial.print("  ");

        // for (int8_t i = 0; i < 8; i++)
        // { // data.NUM_CH
        //     Serial.print(this->data.ch[i]);
        //     Serial.print(", ");
        // }
        // Serial.println();

        // 確認數值對應功能
        _check_operate_mode();
        uint8_t _getInterlockValue = _getInterlockState();
        int8_t _getJoyValueX = _get_left_x();
        int8_t _getJoyValueY = _get_left_y();
        uint8_t _getJoyValueACC = _get_accelerator();
        if (_getInterlockValue)
        {
            float _tmpMaxLinearVelocity = (float((5 * _getJoyValueACC)) * 0.01);
            _tmpMaxLinearVelocity = _tmpMaxLinearVelocity <= 0.4 ? _tmpMaxLinearVelocity : 0.4;
            float _tmpAngularVelocity = (float(5 * _getJoyValueX)) * 0.01;
            *angularVelocity = abs(_tmpAngularVelocity) <= 0.4 ? _tmpAngularVelocity : (_tmpAngularVelocity < 0 ? -0.4 : 0.4);
            float _tmpLinearVelocity = (float(5 * _getJoyValueY)) * 0.01;
            *linearVelocity = abs(_tmpLinearVelocity) <= _tmpMaxLinearVelocity ? _tmpLinearVelocity : (_tmpLinearVelocity < 0.0 ? (-1.0 * _tmpMaxLinearVelocity) : _tmpMaxLinearVelocity);

            //* (float((5 * _getJoyValueACC)) * 0.01)
        }
        else
        {
            *linearVelocity = 0.0;
            *angularVelocity = 0.0;
        }
        // Serial.print(millis());
        // // Serial.print("  JOY Mode: ");
        // // Serial.print(operatorCarMode);
        // Serial.print("  Interlock: ");
        // Serial.print(_getInterlockValue);
        // Serial.print(", X: ");
        // Serial.print(_getJoyValueX);
        // Serial.print(", Y: ");
        // Serial.print(_getJoyValueY);
        // Serial.print(", ACC: ");
        // Serial.print(_getJoyValueACC);
        // Serial.print(", V0: ");
        // Serial.print(*linearVelocity);
        // Serial.print(", V1: ");
        // Serial.print(*angularVelocity);
        _oldRecvTime = millis();
        return 1;
    }
    else
    {
        // this->operatorCarMode = 2; // 遙控器尚未連線, 默認PC
        if (millis() - _oldRecvTime > 1000)
        {
            this->operatorCarMode = 2; // 遙控器尚未連線, 默認PC
            return 0;
        }
        return 1;
    }
}
