#define Arduino
#include "Arduino.h"
#include "JoyStick.h"

// Initialisation function
JoyStick::JoyStick(int leftPinX, int leftPinY, int velocityPin, int interlockPin, int clearCountPin, int joyModePin)
{
#ifdef DEBUG
    Serial.println("New JoyStick.");
#endif
    _leftPinX = leftPinX;
    _leftPinY = leftPinY;
    _velocityPin = velocityPin;
    _clearCountPin = clearCountPin;
    _interlockPin = interlockPin;
    _joyModePin = joyModePin;
    operatorCarMode = 0;

    pinMode(_leftPinX, INPUT);
    pinMode(_leftPinY, INPUT);
    pinMode(_velocityPin, INPUT);
    pinMode(_clearCountPin, INPUT);
    pinMode(_interlockPin, INPUT);
    pinMode(_joyModePin, INPUT);
    digitalWrite(_leftPinX, LOW);
    digitalWrite(_leftPinY, LOW);
    digitalWrite(_velocityPin, LOW);
    digitalWrite(_clearCountPin, LOW);
    digitalWrite(_interlockPin, LOW);
    digitalWrite(_joyModePin, LOW);
}

JoyStick::~JoyStick()
{
}

uint8_t JoyStick::_getInterlockState()
{
    uint32_t _buttonOnTime = pulseIn(_interlockPin, HIGH, 30000);
    if (_buttonOnTime > INTERLOCKE_ENABLE_LOWEST_TIME && _buttonOnTime < INTERLOCKE_ENABLE_HIGHEST_TIME)
        return 1;
    else
        return 0;
}

int8_t JoyStick::_get_left_x()
{
    uint32_t _buttonOnTime = pulseIn(_leftPinX, HIGH, 30000);
    if (_buttonOnTime >= STATIC_SAFETY_RANGE_LOWER && _buttonOnTime <= STATIC_SAFETY_RANGE_UPPER)
    { // 水平搖桿接近中間, 不移動
        return 0;
    }
    if (_buttonOnTime < STATIC_SAFETY_RANGE_LOWER)
    { // 左轉
        if (_buttonOnTime < DIRECTION_RANGE_MIN)
            return -10;
        int8_t _valuelevel = map(_buttonOnTime, DIRECTION_RANGE_MIN, STATIC_SAFETY_RANGE_LOWER, -10, 0);
        return _valuelevel;
    }
    if (_buttonOnTime > STATIC_SAFETY_RANGE_UPPER)
    { // 右轉
        if (_buttonOnTime > DIRECTION_RANGE_MAX)
            return 10;
        int8_t _valuelevel = map(_buttonOnTime, STATIC_SAFETY_RANGE_UPPER, DIRECTION_RANGE_MAX, 0, 10);
        return _valuelevel;
    }
}

int8_t JoyStick::_get_left_y()
{
    uint32_t _buttonOnTime = pulseIn(_leftPinY, HIGH, 30000);
    if (_buttonOnTime >= STATIC_SAFETY_RANGE_LOWER && _buttonOnTime <= STATIC_SAFETY_RANGE_UPPER)
    { // 水平搖桿接近中間, 不移動
        return 0;
    }
    if (_buttonOnTime < STATIC_SAFETY_RANGE_LOWER)
    { // 後退
        if (_buttonOnTime < DIRECTION_RANGE_MIN)
            return -10;
        int8_t _valuelevel = map(_buttonOnTime, DIRECTION_RANGE_MIN, STATIC_SAFETY_RANGE_LOWER, -10, 0);
        return _valuelevel;
    }
    if (_buttonOnTime > STATIC_SAFETY_RANGE_UPPER)
    { // 前進
        if (_buttonOnTime > DIRECTION_RANGE_MAX)
            return 10;
        int8_t _valuelevel = map(_buttonOnTime, STATIC_SAFETY_RANGE_UPPER, DIRECTION_RANGE_MAX, 0, 10);
        return _valuelevel;
    }
}

uint8_t JoyStick::_get_accelerator()
{
    uint32_t _buttonOnTime = pulseIn(_velocityPin, HIGH, 30000);
    if (_buttonOnTime < DIRECTION_RANGE_MIN)
        return 0;
    if (_buttonOnTime > DIRECTION_RANGE_MAX)
        return 10;
    uint8_t _valuelevel = map(_buttonOnTime, DIRECTION_RANGE_MIN, DIRECTION_RANGE_MAX, 0, 10);
    return _valuelevel;
}

uint8_t JoyStick::_check_operate_mode()
{ // 0:初始狀態,無控制  1:遙控器控制  2:上位控制
    uint8_t _result = _getInterlockState();
    // if (!_getInterlockState())
    //     return 0;
    uint32_t _buttonOnTime = pulseIn(_joyModePin, HIGH, 30000);
    operatorCarMode = 0;
    //    Serial.println(_buttonOnTime);
    if (_buttonOnTime < STATIC_SAFETY_RANGE_LOWER)
    {
        operatorCarMode = 2;
        // return 1;
    }
    if (_buttonOnTime > STATIC_SAFETY_RANGE_UPPER)
    {
        operatorCarMode = 1;
        // return 1;
    }

    return _result; // 1
}

uint8_t JoyStick::get_velocity(float *linearVelocity, float *angularVelocity)
{
    if (!_check_operate_mode())
    {
        return 0;
    }
    int8_t _getJoyValueX = _get_left_x();
    int8_t _getJoyValueY = _get_left_y();
    uint8_t _getJoyValueACC = _get_accelerator();
    // if (!_check_operate_mode())
    // {
    //     return 0;
    // }
    // Serial.print(millis());
    // Serial.print("  X: ");
    // Serial.print(_getJoyValueX);
    // Serial.print(", Y: ");
    // Serial.print(_getJoyValueY);
    // Serial.print(", ACC: ");
    // Serial.println(_getJoyValueACC);
    float _tmpAngularVelocity = (float(5 * _getJoyValueX)) * 0.01;
    *angularVelocity = abs(_tmpAngularVelocity) <= 0.3 ? _tmpAngularVelocity : (_tmpAngularVelocity < 0 ? -0.3 : 0.3);
    float _tmpLinearVelocity = (_getJoyValueY > 0 ? 1 : (_getJoyValueY < 0 ? -1 : 0)) * (float((5 * _getJoyValueACC)) * 0.01);
    *linearVelocity = abs(_tmpLinearVelocity) <= 0.3 ? _tmpLinearVelocity : (_tmpLinearVelocity < 0 ? -0.3 : 0.3);
    // Serial.print(",   V0: ");
    // Serial.print(*linearVelocity);
    // Serial.print(", V1: ");
    // Serial.println(*angularVelocity);
    return 1;
}
