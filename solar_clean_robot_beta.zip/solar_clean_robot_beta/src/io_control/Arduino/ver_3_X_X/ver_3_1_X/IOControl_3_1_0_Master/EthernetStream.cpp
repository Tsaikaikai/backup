#include "EthernetStream.h"
#include "Config.h"
EthernetStream::EthernetStream(byte *macAdress, byte *ip, byte *gateway, byte *subnet, int port, int resetPin, int controlPin)
{
    _resetPin = resetPin;
    _controlPin = controlPin;
    Ethernet.init(_controlPin);
    pinMode(_resetPin, OUTPUT);
    digitalWrite(_resetPin, LOW);
    delay(200);
    digitalWrite(_resetPin, HIGH);
    delay(200);
    this->_server = new EthernetServer(port);
    Ethernet.begin(macAdress, ip, gateway, subnet);
    delay(100);
    this->_server->begin();
#ifdef DEBUG
    Serial.print("server is at ");
    Serial.print(Ethernet.localIP());
    Serial.print(":");
    Serial.println(port);
#endif
}
EthernetStream::~EthernetStream()
{
}
bool EthernetStream::connect_available()
{
    bool _return = false;
    this->_client = &this->_server->available();
    if (*this->_client)
    {
        _return = true;
    }
    else
    {
        _return = false;
    }
    return _return;
}
bool EthernetStream::client_available()
{
    return this->_client->available();
}

bool EthernetStream::client_connected()
{
    return this->_client->connected();
}
bool EthernetStream::post(unsigned char *data, int length)
{
    // Serial.print(millis());
    // Serial.println("  Will Post.");
    bool _return = false;
    char c = this->_client->read();
    if (this->_readString.length() < 100)
    {
        this->_readString += c;
    }
    if (c == '\n')
    {
#ifdef DEBUG
        Serial.println(this->_readString);
        Serial.print("data: ");
        for (int i = 0; i < length; i++)
            Serial.print(data[i], HEX);
        Serial.println();
        Serial.print("data size: ");
        Serial.println(length);
#endif
        this->_client->println("HTTP/1.1 200 OK"); // send new page
        this->_client->println("Content-Type: application/octet-stream");
        this->_client->println();
        this->_client->write(data, length);
        this->_client->stop();
        // Serial.println("client disconnected");
        this->_data_convert(this->_readString);
        this->_readString = "";
        _return = true;
    }
    return _return;
}

uint8_t *EthernetStream::get_data()
{
    return this->_data;
}

bool EthernetStream::_data_convert(String data)
{
    bool _return = false;
    int _index = data.indexOf("/FF") + 1;
    int _end = data.indexOf("EE/") + 1;
    int _indexNumber = 0;

    for (int i = _index; i < _end; i += 2)
    {
        this->_data[_indexNumber] = (uint8_t)strtol(data.substring(i, i + 2).c_str(), NULL, 16);
        _indexNumber++;
    }
    _return = true;
#ifdef DEBUG
    for (int i = 0; i < 100; i++)
    {
        Serial.print(this->get_data()[i], HEX);
        Serial.print(" ");
    }
    Serial.println();
#endif
    return _return;
}