#ifndef JOY_STICK_H
#define JOY_STICK_H

#define Arduino
#include "Arduino.h"

#define INTERLOCKE_ENABLE_LOWEST_TIME 1800
#define INTERLOCKE_ENABLE_HIGHEST_TIME 2500
#define STATIC_SAFETY_RANGE_UPPER 1600
#define STATIC_SAFETY_RANGE_LOWER 1300
#define DIRECTION_RANGE_MIN 1000
#define DIRECTION_RANGE_MAX 1900

class JoyStick
{
public:
    JoyStick(int leftPinX, int leftPinY, int velocityPin, int interlockPin, int clearCountPin, int joyModePin);
    ~JoyStick();

    uint8_t get_velocity(float *linearVelocity, float *angularVelocity);

    uint8_t operatorCarMode;

private:
    uint8_t _getInterlockState();
    int8_t _get_left_x();
    int8_t _get_left_y();
    uint8_t _get_accelerator();
    uint8_t _check_operate_mode();
    int _leftPinX;
    int _leftPinY;
    int _velocityPin;
    int _interlockPin;
    int _clearCountPin;
    int _joyModePin;
};

#endif