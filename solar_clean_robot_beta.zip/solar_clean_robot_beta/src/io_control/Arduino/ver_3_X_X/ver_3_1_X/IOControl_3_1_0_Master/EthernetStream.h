#ifndef ETHERNET_STREAM_h
#define ETHERNET_STREAM_h
#include "Arduino.h"
#include <SPI.h>
#include <Ethernet.h>
class EthernetStream
{
public:
  EthernetStream(byte *macAdress, byte *ip, byte *gateway, byte *subnet, int port, int resetPin, int controlPin);
  ~EthernetStream();
  bool connect_available();
  bool client_available();
  bool client_connected();
  bool post(unsigned char *data, int length);
  uint8_t *get_data();

private:
  bool _data_convert(String data);
  EthernetServer *_server;
  EthernetClient *_client;
  int _resetPin;
  int _controlPin;
  String _readString;
  uint8_t _data[100];
};

#endif
