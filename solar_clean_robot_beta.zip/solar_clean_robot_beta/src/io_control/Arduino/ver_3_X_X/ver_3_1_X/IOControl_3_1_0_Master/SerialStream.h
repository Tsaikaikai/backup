#ifndef SERIAL_STREAM_h
#define SERIAL_STREAM_h
#include "Arduino.h"

class SerialStream
{
public:
  SerialStream(int _serialNumber, int32_t _baudRate, byte _header, byte _footer);
  ~SerialStream();
  bool set_received_package_length(int packageLength);
  int get_package_length();
  uint8_t read_serial();
  bool read_serial_without_header();
  bool write_serial(unsigned char *command, int commandLength);
  unsigned char *get_data();
  bool free_data();
  void clear_buffer();

private:
  void _serial_begin();
  int _serial_available();
  int _serial_read();
  size_t _serial_write(unsigned char command);
  void _serial_flush();
  int _packageLength = 0;
  int _serialNumber = 0;
  byte _header = 0x00;
  byte _footer = 0x00;
  int32_t _baudRate;
  int _dataCount = 0;
  unsigned char *_receivedData = NULL;
  unsigned char *_transmittedData = NULL;
};

#endif
