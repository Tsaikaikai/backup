#include "Ultrasonic.h"

bool Ultrasonic::send_distance_command(int no)
{
    clear_buffer();
    static unsigned char ultrasonic_addr[] = ULTRASONIC_ADDR;
    static unsigned char _command[3] = ULTRASONIC_COMMAND;
    _command[0] = ultrasonic_addr[no];
    // Serial.println(_command[0],HEX);
    write_serial(_command, 3);
    return true;
}

uint8_t Ultrasonic::check_get_Value()
{
    uint8_t _getSensorValue = 0;
    if (read_serial())
    {
        this->_distance = (int(get_data()[0]) * 256 + int(get_data()[1]));
        _getSensorValue = 1;
    }
    return _getSensorValue;
}

int Ultrasonic::get_distance()
{
    return this->_distance;
}