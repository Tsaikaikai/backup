#ifndef Ultrasonic_h
#define Ultrasonic_h

#include "SerialStream.h"
#include "Config.h"

class Ultrasonic : public SerialStream
{
public:
  Ultrasonic(int _serialNumber, int32_t _baudRate, byte _header, byte _footer) : SerialStream(_serialNumber, _baudRate, _header, _footer) {}

  bool send_distance_command(int no);
  uint8_t check_get_Value();
  int get_distance();

private:
  int _distance = 0;
};

#endif
