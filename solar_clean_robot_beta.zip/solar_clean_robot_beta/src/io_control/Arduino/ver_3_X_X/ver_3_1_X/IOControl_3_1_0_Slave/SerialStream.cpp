#include "SerialStream.h"
SerialStream::SerialStream(int _serialNumber, int32_t _baudRate, byte _header = 0x00, byte _footer = 0x00)
{
    this->_serialNumber = _serialNumber;
    this->_baudRate = _baudRate;
    this->_header = _header;
    this->_footer = _footer;
    _serial_begin();
}

SerialStream::~SerialStream()
{
}

void SerialStream::_serial_begin()
{
    switch (this->_serialNumber)
    {
    case 0:
        Serial.begin(this->_baudRate);
        _selectSerial = &Serial;
        break;
    case 1:
        Serial1.begin(this->_baudRate);
        _selectSerial = &Serial1;
        break;
    case 2:
        Serial2.begin(this->_baudRate);
        _selectSerial = &Serial2;
        break;
    case 3:
        Serial3.begin(this->_baudRate);
        _selectSerial = &Serial3;
        break;
    }
}

int SerialStream::_serial_available()
{
    return _selectSerial->available();
    // switch (this->_serialNumber)
    // {
    // case 0:
    //     return Serial.available();
    //     break;
    // case 1:
    //     return Serial1.available();
    //     break;
    // case 2:
    //     return Serial2.available();
    //     break;
    // case 3:
    //     return Serial3.available();
    //     break;
    // }
}

int SerialStream::_serial_read()
{
    return _selectSerial->read();
    // switch (this->_serialNumber)
    // {
    // case 0:
    //     return Serial.read();
    //     break;
    // case 1:
    //     return Serial1.read();
    //     break;
    // case 2:
    //     return Serial2.read();
    //     break;
    // case 3:
    //     return Serial3.read();
    //     break;
    // }
}

void SerialStream::_serial_flush()
{
    _selectSerial->flush();
    // switch (this->_serialNumber)
    // {
    // case 0:
    //     Serial.flush();
    //     break;
    // case 1:
    //     Serial1.flush();
    //     break;
    // case 2:
    //     Serial2.flush();
    //     break;
    // case 3:
    //     Serial3.flush();
    //     break;
    // }
}

size_t SerialStream::_serial_write(unsigned char command)
{
    return _selectSerial->write(command);
    // switch (this->_serialNumber)
    // {
    // case 0:
    //     return Serial.write(command);
    //     break;
    // case 1:
    //     return Serial1.write(command);
    //     break;
    // case 2:
    //     return Serial2.write(command);
    //     break;
    // case 3:
    //     return Serial3.write(command);
    //     break;
    // }
}

bool SerialStream::set_received_package_length(int packageLength)
{
    this->_packageLength = packageLength;
    this->_receivedData = new unsigned char[this->_packageLength];
    return true;
}
int SerialStream::get_package_length()
{
    return this->_packageLength;
}

uint8_t SerialStream::read_serial()
{
    uint8_t _result = 0;
    while (_serial_available())
    {
        this->_receivedData[this->_dataCount] = _serial_read();
        // if (this->_serialNumber == 3)
        // {
        //     Serial.print(this->_receivedData[this->_dataCount]);
        //     Serial.print("[");
        //     Serial.print(this->_dataCount);
        //     Serial.print("],");
        // }
        // Serial.print(this->_receivedData[this->_dataCount]);
        // Serial.print("[");
        // Serial.print(this->_serialNumber);
        // Serial.print("-");
        // Serial.print(this->_dataCount);
        // Serial.print("],");
        //        Serial.print(this->_receivedData[this->_dataCount]);
        //        Serial.print(",");
        if (this->_header != 0x00 && this->_footer != 0x00)
        {
            if (this->_receivedData[0] == this->_header)
            {
                this->_dataCount++;
                if (this->_dataCount == this->_packageLength && this->_receivedData[this->_packageLength - 1] == this->_footer)
                {
                    _result = 1;
                    this->_dataCount = 0;
                    // Serial.println("OK");
                }
                else if (this->_dataCount == this->_packageLength && this->_receivedData[this->_packageLength - 1] != this->_footer)
                {
                    this->_dataCount = 0;
                    clear_buffer();
                    //_serial_flush();
                    // Serial.println("NG");
                }
            }
            else
            {
                this->_dataCount = 0;
                _serial_flush();
                // Serial.println("ERROR");
            }
        }
        else
        {
            this->_dataCount++;
            if (this->_dataCount == this->_packageLength)
            {
                _result = 1;
                this->_dataCount = 0;
                // Serial.println(" ; not heard get finish.");
            }
        }
    }
    return _result;
}

bool SerialStream::read_serial_without_header()
{
    bool _result = false;
    while (_serial_available())
    {
        this->_receivedData[this->_dataCount] = _serial_read();
        // Serial.print(this->_receivedData[this->_dataCount], HEX);
        this->_dataCount++;
        if (this->_dataCount == this->_packageLength)
        {
            _result = true;
            this->_dataCount = 0;
            // Serial.println();
        }
    }
    return _result;
}
bool SerialStream::write_serial(unsigned char *command, int commandLength)
{
    //    Serial.print(this->_serialNumber);
    //    Serial.print("  Write  ");
    //    for(int i=0;i<commandLength;i++){
    //      Serial.print( command[i]);
    //      Serial.print(",");
    //    }
    //    Serial.println();
    for (int i = 0; i < commandLength; i++)
    {
        _serial_write(command[i]);
    }
    return true;
}

unsigned char *SerialStream::get_data()
{
    return this->_receivedData;
}

void SerialStream::clear_buffer()
{
    while (_serial_available())
        int _clearData = _serial_read();
}

bool SerialStream::free_data()
{
    if (this->_receivedData == NULL)
        return true;
    delete[] this->_receivedData;
    return true;
}
