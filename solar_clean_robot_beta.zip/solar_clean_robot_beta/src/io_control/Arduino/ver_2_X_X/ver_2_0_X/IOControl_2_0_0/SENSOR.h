#ifndef SENSOR_h
#define SENSOR_h

#define NB_SAMPLE 50
#define USE_MEDOFMEDIANS true

#define Arduino
#include "Arduino.h"

class SENSOR
{
  public:

    SENSOR (int sensorPin, long sensorType);
    float compute();

  private:

    void sort(int a[], int size);

    int _sensorPin;
    long _type;
    void partialSort(int a[], int min, int max);
    int medianOfMedians(int a[], int size);
};

#endif
