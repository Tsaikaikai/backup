#include <Wire.h>
#include <Stream.h>
#include "SENSOR.h"
// #include "SharpIR.h"
#include "PackageFormat.h"
#include "Config.h"
#include "CRC.h"
#include "CRC16.h"

// Status Parameter
byte sonarErrorStatus = 0xFF;
int statusCycleTime = 1000 / statusFrequency; // Unit: ms

// Clean Motor Parameter
byte motorState = MOTOR_STOP;
byte preMotorState = MOTOR_STOP;
byte preRelay2State = RELAY_2_OFF;
byte relay2State = RELAY_2_OFF;
static bool controlFlag = false;

// IR Parameter
byte sensorErrorStatus = 0xFF;
int sensorCycleTime = 1000 / (sensorFrequency * SENSOR_ECHO_COUNT); // Unit: ms
bool sensorRequestFlag[SENSOR_ECHO_COUNT] = {false};

#if VERSION >= 0x200
SENSOR sensors[SENSOR_ECHO_COUNT] = {SENSOR(sensorPins[0], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[1], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[2], SENSOR_TYPE_CURRENT),
                                     SENSOR(sensorPins[3], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[4], SENSOR_TYPE_TEMPERATURE),
                                     SENSOR(sensorPins[5], SENSOR_TYPE_HUMIDITY),
                                     SENSOR(sensorPins[6], SENSOR_TYPE_CURRENT),
                                     SENSOR(sensorPins[7], SENSOR_TYPE_CURRENT)};
#elif VERSION >= 0x110
SharpIR sensors[SENSOR_ECHO_COUNT] = {SharpIR(sensorPins[0], SENSOR_TYPE),
                                      SharpIR(sensorPins[1], SENSOR_TYPE),
                                      SharpIR(sensorPins[2], SENSOR_TYPE),
                                      SharpIR(sensorPins[3], SENSOR_TYPE),
                                      SharpIR(sensorPins[4], SENSOR_TYPE),
                                      SharpIR(sensorPins[5], SENSOR_TYPE_HUMIDITY),
                                      SharpIR(sensorPins[6], SENSOR_TYPE_CURRENT),
                                      SharpIR(sensorPins[7], SENSOR_TYPE_CURRENT)};
#else
SharpIR sensors[SENSOR_ECHO_COUNT] = {SharpIR(sensorPins[0], SENSOR_TYPE),
                                      SharpIR(sensorPins[1], SENSOR_TYPE),
                                      SharpIR(sensorPins[2], SENSOR_TYPE),
                                      SharpIR(sensorPins[3], SENSOR_TYPE),
                                      SharpIR(sensorPins[4], SENSOR_TYPE),
                                      SharpIR(sensorPins[5], SENSOR_TYPE)};
#endif

union Data
{
  long longValue;
  float floatValue;
  byte byteValue[4];
  bool boolValue;
};

struct Package
{
  byte header = STX;
  byte function = 0;
  byte value[4] = {0xFF, 0xFF, 0xFF, 0xFF};
  byte footer = ETX;
};

byte receivedPackage[7] = {0x00};