from io_control.ArduinoCommunication import ArduinoCommunication
import time


def main():
    # Thread of Arduino Serial
    _arduinoCommunicationThread = ArduinoCommunication("Beta_1_1")
    _arduinoCommunicationThread.start()
    time.sleep(5)

    try:
        input("Press enter to continue after IR ready !")
        for _index in range(0, 1000):
            time.sleep(0.01)
            print(_arduinoCommunicationThread.get_ir_range())

        # Motor Test
        input("Press enter and test motor !")
        _arduinoCommunicationThread.set_motor_status(True)
        for _timer in range(0, 3):
            print(".")
            time.sleep(1)

        _arduinoCommunicationThread.set_motor_status(False)
        for _timer in range(0, 3):
            print(".")
            time.sleep(1)

        # Relay 2 Test
        _arduinoCommunicationThread.set_relay_2_status(True)
        for _timer in range(0, 3):
            print(".")
            time.sleep(1)

        _arduinoCommunicationThread.set_relay_2_status(False)
        for _timer in range(0, 3):
            print(".")
            time.sleep(1)

        _arduinoCommunicationThread.stop()
        print("Test Finish")
    except KeyboardInterrupt:
        _arduinoCommunicationThread.stop()
        print("RA_Sensors_Test.py shutdown")


if __name__ == "__main__":
    main()
