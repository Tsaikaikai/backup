#!/usr/bin/env python3
import os
from os.path import join
import sys
import time
import struct
from threading import Thread, Event
import codecs
import asyncio
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from io_control import ArduinoConfig, APIClient, SocketClient, PackageFormat, PackageControl
from utility import Stream, CRCTable


class ArduinoCommunication(Thread):
    def __init__(self, robotType="") -> None:
        # Initial Thread
        Thread.__init__(self)
        print('[IO Control INFO] Initial arduino ...\r')
        self.finished = Event()
        self.loadConfigStatus = False

        self.__preMileage = 0.0
        self.__prevOdomTh = 0.0
        # Config Path
        global configPath
        configPath = join(configPath, robotType)

        self.__cleanMotorChangeFlag = False

    def set_setting_config(self, _arduinoSetting) -> bool:
        self.__arduinoSetting = _arduinoSetting
        Stream.save_config(
            join(configPath, "ArduinoSetting.yaml"), self.__arduinoSetting)
        return True

    def get_setting_config(self) -> dict:
        return self.__arduinoSetting

    def set_clean_motor(self, _flag) -> bool:
        if _flag != bool(self.__arduinoCommand.cleanMotor["state"]):
            self.__cleanMotorChangeFlag = True
        if _flag and round(self.__arduinoData.tempValue["mileageRawData"], 0) != -2.0:
            self.__arduinoCommand.cleanMotor["state"] = PackageFormat.PackageFormat.RELAY_0_ON.value | PackageFormat.PackageFormat.RELAY_1_ON.value
        else:
            self.__arduinoCommand.cleanMotor["state"] = PackageFormat.PackageFormat.RELAY_ALL_OFF.value
        return True

    def set_beeper(self, _flag) -> bool:
        if _flag:
            self.__arduinoCommand.beeper["state"] = PackageFormat.PackageFormat.BEEPER_ON.value
        else:
            self.__arduinoCommand.beeper["state"] = PackageFormat.PackageFormat.BEEPER_OFF.value
        return True

    def get_controller(self) -> dict:
        if round(self.__arduinoData.tempValue["mileageRawData"], 0) == -2.0:
            self.__arduinoData.controller["remoteFlag"] = True
            self.__arduinoData.controller["navFlag"] = False
        else:
            self.__arduinoData.controller["remoteFlag"] = False
        return self.__arduinoData.controller

    def get_drive_motor(self) -> dict:
        if self.__arduinoSetting["SELF_TEST"]["DRIVE_MOTOR"] == True:
            if not self.__arduinoData.driveMotor["connect"]:
                self.__arduinoData.driveMotor["errorCode"] = 3001
            elif abs(self.__arduinoData.driveMotor['odometry'][2] - self.__prevOdomTh) > 1000:
                self.__arduinoData.driveMotor["errorCode"] = 3002
            elif round(self.__arduinoData.tempValue["mileageRawData"], 0) == -1.0:
                self.__arduinoData.driveMotor["errorCode"] = 3003
            # elif round(self.__arduinoData.tempValue["mileageRawData"], 0) != -2.0 and self.__mileageCounter / self.__arduinoSetting['UPDATE_FREQUENCY'] > 3:
            #     self.__arduinoData.driveMotor["errorCode"] = 3004
            else:
                self.__arduinoData.driveMotor["errorCode"] = 0
                self.__prevOdomTh = self.__arduinoData.driveMotor['odometry'][2]
        else:
            self.__arduinoData.driveMotor["errorCode"] = 0
            self.__prevOdomTh = self.__arduinoData.driveMotor['odometry'][2]
        return self.__arduinoData.driveMotor

    def set_velocity(self, _velocity) -> bool:
        if round(self.__arduinoData.tempValue["mileageRawData"], 0) != -2.0:
            self.__arduinoCommand.driveMotor['velocity'] = _velocity
        else:
            self.__arduinoCommand.driveMotor['velocity'] = [0.0, 0.0]
        return True

    def get_battery(self) -> dict:
        if self.__arduinoSetting["SELF_TEST"]["BATTERY"] == True:
            if not self.__arduinoData.battery["connect"]:
                self.__arduinoData.battery["errorCode"] = 4001
            else:
                self.__arduinoData.battery["errorCode"] = 0
        else:
            self.__arduinoData.battery["errorCode"] = 0
        return self.__arduinoData.battery

    def get_sonar(self) -> dict:
        if self.__arduinoSetting["SELF_TEST"]["SONAR"] == True:
            if not self.__arduinoData.sonar["connect"]:
                self.__arduinoData.sonar["errorCode"] = 5001
            else:
                self.__arduinoData.sonar["errorCode"] = 0
        else:
            self.__arduinoData.sonar["errorCode"] = 0

        return self.__arduinoData.sonar

    def get_master_board(self) -> dict:
        self.__arduinoData.masterBoard["firmwareVersion"] = self.__arduinoSetting["FIRMWARE_VERSION"]
        if self.__arduinoSetting["SELF_TEST"]["BOARD_MASTER"] == True:
            if not self.__arduinoData.masterBoard["connect"]:
                self.__arduinoData.masterBoard["errorCode"] = 2001
            else:
                self.__arduinoData.masterBoard["errorCode"] = 0
        else:
            self.__arduinoData.masterBoard["errorCode"] = 0
        return self.__arduinoData.masterBoard

    def get_slave_board(self) -> dict:
        if self.__arduinoSetting["SELF_TEST"]["BOARD_SLAVE"] == True:
            if not self.__arduinoData.slaveBoard["connect"]:
                self.__arduinoData.slaveBoard["errorCode"] = 2002
            else:
                self.__arduinoData.slaveBoard["errorCode"] = 0
        else:
            self.__arduinoData.slaveBoard["errorCode"] = 0
        return self.__arduinoData.slaveBoard

    def get_sensor(self) -> dict:
        if self.__arduinoSetting["SELF_TEST"]["SENSOR"] == True:
            if self.__cleanMotorChangeFlag != True and self.__arduinoData.sensor["current"][2] > self.__arduinoSetting["BRUSH_CURRENT_LIMIT"] or self.__arduinoData.sensor["current"][3] > self.__arduinoSetting["BRUSH_CURRENT_LIMIT"]:
                self.__arduinoData.sensor["errorCode"] = 7003
            else:
                self.__arduinoData.sensor["errorCode"] = 0
        else:
            self.__arduinoData.sensor["errorCode"] = 0
        return self.__arduinoData.sensor

    def get_power_button(self) -> bool:
        return self.__arduinoData.button["power"]

    def get_clean_button(self) -> bool:
        return self.__arduinoData.button["clean"]

    def __float_to_hex(self, _floatData) -> str:
        _packed = struct.pack('<f', _floatData)
        _hexStr = ''.join(['{:02x}'.format(b) for b in _packed])
        return _hexStr

    def __hex_to_float(self, _hexData) -> float:
        _packed = bytearray.fromhex(_hexData)
        _float = struct.unpack('<f', _packed)[0]
        return _float

    def __int_to_hex(self, _intData) -> str:
        _packed = struct.pack('<i', _intData)
        _hexStr = ''.join(['{:02x}'.format(b) for b in _packed])
        return _hexStr

    def __uint8_to_hex(self, _uint8Data) -> str:
        _packed = struct.pack('<B', _uint8Data)
        _hexStr = ''.join(['{:02x}'.format(b) for b in _packed])
        return _hexStr

    def __hex_to_bytes(self, _hexData) -> bytes:
        _bytesData = codecs.decode(_hexData, 'hex_codec')
        return _bytesData

    def __bytes_to_hex(self, _bytesData) -> str:
        _hexData = codecs.encode(_bytesData, 'hex_codec')
        return _hexData

    def __data_to_str(self, _data) -> str:
        __commandData = 'FF'
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
            __commandData += self.__float_to_hex(_data.driveMotor['velocity'][0])
            __commandData += self.__float_to_hex(_data.driveMotor['velocity'][1])
            __commandData += self.__uint8_to_hex(_data.driveMotor["state"] | _data.cleanMotor["state"])
            __commandData += self.__crc16_xmodem_with_table(b'\x00\x00', self.__hex_to_bytes(__commandData)).hex()
            __commandData += 'EE'
        return __commandData

    def __data_to_bytes(self, _data) -> bytes:
        __commandData = b'\xFF'
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x320:
            __commandData += struct.pack('f', _data.driveMotor['velocity'][0])
            __commandData += struct.pack('f', _data.driveMotor['velocity'][1])
            __commandData += struct.pack('B', _data.driveMotor["state"] | _data.cleanMotor["state"])
            __commandData += self.__crc16_xmodem_with_table(b'\x00\x00', __commandData)
            __commandData += b'\xEE'
            __commandData += b'\n'
        return __commandData

    def __post_command(self) -> bool:
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
            self.__arduinoAPI.post_command(self.__arduinoCommand)
        return True

    def __crc16_xmodem_with_table(self, _currentCrc, _inputData) -> bytes:
        _crc = _currentCrc
        for _index in range(0, len(_inputData), 2):
            _crc = (int.from_bytes(_crc, 'big', signed=False) ^ int.from_bytes(_inputData[_index: _index+2], 'little', signed=False)).to_bytes(2, 'little', signed=False)
            _crc = CRCTable.crcXmodemTable[int.from_bytes(_crc, 'little', signed=False)]
        return _crc

    def disconnect(self, __deviceNumber=0) -> None:
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x310:
            self.__arduinoData.masterBoard.update({"timeStamp": -1, "connect": False})
            self.__arduinoData.driveMotor.update({"connect": False, "state": PackageFormat.PackageFormat.DRIVE_MOTOR_STOP.value, 'velocity': [0.0, 0.0], 'odometry': [0.0, 0.0, 0.0]})
            self.__arduinoData.button.update({"power": False, "clean": False})
            self.__arduinoData.slaveBoard.update({"timeStamp": -1, "connect": False})
            self.__arduinoData.sonar.update({"connect": False, 'range': [-2, -2, -2, -2, -2, -2, -2, -2]})
            self.__arduinoData.sensor.update({'temperature': [0.0, 0.0], 'humidity': 0.0, 'current': [0.0, 0.0, 0.0, 0.0]})
            self.__arduinoData.battery.update({"connect": False, 'voltage': 0.0, 'current': 0.0, 'temperature': 0.0, 'SOC': -2, 'SOH': 0, 'cycle': 0})
            self.__arduinoData.cleanMotor.update({"state": PackageFormat.PackageFormat.RELAY_ALL_OFF.value})
        elif self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
            if __deviceNumber == 0:
                self.__arduinoData.masterBoard.update({"timeStamp": 0, "connect": False, "errorCode": 0})
                self.__arduinoData.driveMotor.update({"connect": False, "errorCode": 0, "state": PackageFormat.PackageFormat.DRIVE_MOTOR_STOP.value, 'velocity': [0.0, 0.0], 'odometry': [0.0, 0.0, 0.0]})
                self.__arduinoData.button.update({"power": False, "clean": False})
            elif __deviceNumber == 1:
                self.__arduinoData.slaveBoard.update({"timeStamp": 0, "connect": False, "errorCode": 0})
                self.__arduinoData.sonar.update({"connect": False, "errorCode": 0, 'cliffState': [True, True, True, True, True, True, True, True], 'range': [-2, -2, -2, -2, -2, -2, -2, -2]})
                self.__arduinoData.sensor.update({'temperature': [0.0, 0.0], 'humidity': 0.0, 'current': [0.0, 0.0, 0.0, 0.0]})
                self.__arduinoData.battery.update({"connect": False, "errorCode": 0, 'voltage': 0.0, 'current': 0.0, 'temperature': 0.0, 'SOC': -2, 'SOH': 0, 'cycle': 0})
                self.__arduinoData.cleanMotor.update({"state": PackageFormat.PackageFormat.RELAY_ALL_OFF.value})

    async def master_loop(self) -> None:
        _updateCycle = 1.0/self.__arduinoSetting['UPDATE_FREQUENCY']
        _retryCounter = 0
        self.__mileageCounter = 0
        self.__cleanMotorChangeCounter = 0
        self.__arduinoSocket.connect()
        while not self.finished.is_set():
            try:
                if self.__cleanMotorChangeFlag:
                    self.__cleanMotorChangeCounter += 1
                if self.__cleanMotorChangeCounter / self.__arduinoSetting["UPDATE_FREQUENCY"] > 3:
                    self.__cleanMotorChangeCounter = 0
                    self.__cleanMotorChangeFlag = False
                if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x320:
                    _receivedPackage = self.__arduinoSocket.send(self.__data_to_bytes(self.__arduinoCommand))
                else:
                    _receivedPackage = self.__arduinoAPI.post(self.__data_to_str(self.__arduinoCommand)).content
                self.__arduinoData = self.__packageControl.decode_arduino_package(_receivedPackage, self.__arduinoData)
                if self.__arduinoData.tempValue["crcCheck"]:
                    # if _temp.driveMotor["mileage"] == self.__arduinoData.driveMotor["mileage"]:
                    #     self.__mileageCounter += 1
                    # else:
                    #     self.__mileageCounter = 0
                    _retryCounter = 0
                else:
                    if _retryCounter < 3:
                        print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Decode Fail and Retry ' + str(_retryCounter) + ' times'))
                    _retryCounter += 1
                    await asyncio.sleep(1)
                    self.__arduinoData.masterBoard['retryCounter'] += 1
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master Decode Fail'))
                    self.__arduinoData.masterBoard["connect"] = False
                    self.__arduinoData.driveMotor["connect"] = False
                    self.__arduinoData.slaveBoard["connect"] = False
                    self.__arduinoData.sonar["connect"] = False
                    self.__arduinoData.sensor["connect"] = False
                    self.__arduinoData.battery["connect"] = False

            except Exception as _exception:
                self.disconnect()
                self.__arduinoSocket.close()
                if ('HTTPConnectionPool' in str(_exception)):
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master: Connection pool error'))
                    _receivedPackage = ""
                    await asyncio.sleep(2)
                else:
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Master: ' + str(_exception)))
                self.__arduinoSocket.connect()
                _retryCounter = 0
            await asyncio.sleep(_updateCycle)

    async def slave_loop(self) -> None:
        _updateCycle = 1.0/self.__arduinoSetting['UPDATE_FREQUENCY']
        while not self.finished.is_set():
            try:
                _receivedPackage = self.__arduinoAPI1.post(self.__data_to_str(self.__arduinoCommand)).content
                _temp = self.__packageControl.decode_arduino_package(_receivedPackage, 1)
                if _temp != dict():
                    self.__arduinoData = _temp
                # if self.__decode_package(_receivedPackage, 1):
                #     self.__arduinoData.slaveBoard["connect"] = True
                # else:
                #     self.__arduinoData.slaveBoard["connect"] = False
            except Exception as _exception:
                self.disconnect(1)
                if ('HTTPConnectionPool' in str(_exception)):
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Slave: Connection pool error'))
                    _receivedPackage = ""
                    await asyncio.sleep(2)
                else:
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Slave:' + str(_exception)))
            await asyncio.sleep(_updateCycle)

    async def main_loop(self) -> None:
        if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x310:
            masterTask = asyncio.create_task(self.master_loop())
            await asyncio.gather(masterTask)
        elif self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
            masterTask = asyncio.create_task(self.master_loop())
            slaveTask = asyncio.create_task(self.slave_loop())
            await asyncio.gather(masterTask, slaveTask)

    def run(self) -> None:
        try:
            # Arduino Setting
            self.__arduinoSetting = Stream.load_config(join(configPath, "ArduinoSetting.yaml"))
            time.sleep(1)

            if self.__arduinoSetting:
                self.loadConfigStatus = True
                # Arduino Parameter
                self.__arduinoPackage = ArduinoConfig.ArduinoPackage(self.__arduinoSetting["FIRMWARE_VERSION"])
                self.__arduinoData = ArduinoConfig.ArduinoData(self.__arduinoSetting["FIRMWARE_VERSION"])
                self.__arduinoCommand = ArduinoConfig.ArduinoCommand(self.__arduinoSetting["FIRMWARE_VERSION"])
                self.__packageControl = PackageControl.PackageControl(self.__arduinoSetting)
            if self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x320:
                self.__arduinoSocket = SocketClient.SocketClient(host=self.__arduinoSetting['HOST'], port=self.__arduinoSetting['PORT'], timeout=0.2)
            elif self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x310:
                self.__arduinoAPI = APIClient.APIClient(protocol=self.__arduinoSetting['PROTOCOL'], host=self.__arduinoSetting['HOST'], port=self.__arduinoSetting['PORT'], path='/')
            elif self.__arduinoSetting["FIRMWARE_VERSION"] >= 0x300:
                self.__arduinoAPI = APIClient.APIClient(protocol=self.__arduinoSetting['PROTOCOL'], host=self.__arduinoSetting['HOST'], port=self.__arduinoSetting['PORT'], path='/')
                self.__arduinoAPI1 = APIClient.APIClient(protocol=self.__arduinoSetting['PROTOCOL'], host=self.__arduinoSetting['HOST_1'], port=self.__arduinoSetting['PORT'], path='/')
        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Load arduino or battery config exception: ' + str(_exception)))
        if self.loadConfigStatus:
            print('[IO Control INFO] Run Arduino\r')
            asyncio.run(self.main_loop())

    def stop(self) -> None:
        self.__arduinoSocket.close()
        self.finished.set()
        time.sleep(1)
        print('[IO Control INFO] Shutdown Arduino\r')
