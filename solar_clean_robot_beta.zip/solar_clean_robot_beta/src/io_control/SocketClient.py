import socket


class SocketClient():
    def __init__(self, host="localhost", port=5000, timeout=0.1) -> None:
        self.__host = host
        self.__port = int(port)
        self.__timeout = timeout

    def send(self, inputData) -> str:
        self.__socket.send(inputData)
        _outputData = self.__socket.recv(128)
        return _outputData

    def close(self):
        self.__socket.close()

    def connect(self) -> bool:
        try:
            self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.__socket.settimeout(self.__timeout)
            self.__socket.connect((self.__host, self.__port))
            return True
        except Exception as _exception:
            return False
