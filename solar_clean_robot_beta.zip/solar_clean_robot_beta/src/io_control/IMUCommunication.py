#!/usr/bin/env python3
import time
import struct
import os
import sys
from os.path import join
from threading import Thread, Event

if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from io_control import IMUConfig, SerialStream
from utility import Stream


class IMUCommunication(Thread):
    def __init__(self, _robotType=""):
        # Initial Thread
        Thread.__init__(self)
        print('[IO Control INFO] Initial IMU ...\r')
        self.finished = Event()
        self.loadConfigStatus = False

        # Config Path
        global configPath
        configPath = join(configPath, _robotType)

        # IMU Setting
        self.__imuSetting = dict()

        # IMU Parameter
        self.__imuData = IMUConfig.IMUData()

    def get_connect_status(self):
        return self.__imuSerial.connectStatus

    def get_time_stamp(self):
        return self.__imuData.timeStamp

    def get_acceleration(self):
        return self.__imuData.acceleration

    def get_gyroscope(self):
        return self.__imuData.gyroscope

    def get_magnetic(self):
        return self.__imuData.magnetic

    def get_euler(self):
        return self.__imuData.euler

    def get_quaternion(self):
        return self.__imuData.quaternion

    def get_imu(self):
        self.__imuData.imu['connect'] = self.__imuSerial.connectStatus
        self.__imuData.imu['euler'] = [round(self.__imuData.euler[0], 3), round(self.__imuData.euler[1], 3), round(self.__imuData.euler[2], 3)]
        self.__imuData.imu['acceleration'] = [round(self.__imuData.acceleration[0], 3), round(self.__imuData.acceleration[1], 3), round(self.__imuData.acceleration[2], 3)]
        if not self.__imuData.imu['connect']:
            self.__imuData.imu['errorCode'] = 1001
        else:
            self.__imuData.imu['errorCode'] = 0
        return self.__imuData.imu

    def run(self):
        # Serial Parameter
        try:
            self.__imuSetting = Stream.load_config(join(configPath, 'IMUSetting.yaml'))
            if self.__imuSetting:
                self.loadConfigStatus = True
            self.__imuSerial = SerialStream.SerialStream(_comPortName=self.__imuSetting['COM_PORT_NAME'], _baudrate=115200, _packageLength=self.__imuSetting['PACKAGE_LENGTH'], _payloadLength=self.__imuSetting['PAYLOAD_LENGTH'])
        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Load IMU config error: ' + str(_exception)))

        if self.loadConfigStatus:
            self.__imuSerial.initial_serial()
            _now = time.time()
            _connectStatusTimer = _now
            _connectStatusTimeout = 0.5
            _retryCounter = 0
            if not self.finished.is_set():
                print('[IO Control INFO] Run IMU\r')
            while not self.finished.is_set():
                try:
                    _now = time.time()
                    if self.__imuSerial.serialPort.is_open:
                        if _now - _connectStatusTimer > _connectStatusTimeout:
                            self.__imuSerial.connectStatus = False
                            print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] IMU timeout'))
                            self.__imuSerial.errorFlag = True
                            _connectStatusTimer = _now
                        if self.__imuSerial.decode_imu_package():
                            self.__imuData.packageLabel = self.__imuSerial.receivedPackage[6]
                            self.__imuData.deviceID = self.__imuSerial.receivedPackage[7]
                            self.__imuData.airPressure = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[10:14])))
                            self.__imuData.timeStamp = int.from_bytes(self.__imuSerial.receivedPackage[self.__imuSetting['TIME_STAMP_SIGNIFICANT_BIT'][0] + 6: self.__imuSetting['TIME_STAMP_SIGNIFICANT_BIT'][1] + 6 + 1], "little")
                            self.__imuData.acceleration[0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['ACCELERATION_X_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['ACCELERATION_X_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.acceleration[1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['ACCELERATION_Y_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['ACCELERATION_Y_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.acceleration[2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['ACCELERATION_Z_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['ACCELERATION_Z_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.gyroscope[0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['GYROSCOPE_X_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['GYROSCOPE_X_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.gyroscope[1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['GYROSCOPE_Y_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['GYROSCOPE_Y_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.gyroscope[2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['GYROSCOPE_Z_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['GYROSCOPE_Z_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.magnetic[0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['MAGNETIC_X_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['MAGNETIC_X_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.magnetic[1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['MAGNETIC_Y_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['MAGNETIC_Y_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.magnetic[2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['MAGNETIC_Z_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['MAGNETIC_Z_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.euler[0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['ROLL_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['ROLL_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.euler[1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['PITCH_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['PITCH_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.euler[2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['YAW_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['YAW_SIGNIFICANT_BIT'][1] + 6 + 1]))) % 360
                            self.__imuData.quaternion[0] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['QUATERNION_1_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['QUATERNION_1_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.quaternion[1] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['QUATERNION_2_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['QUATERNION_2_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.quaternion[2] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['QUATERNION_3_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['QUATERNION_3_SIGNIFICANT_BIT'][1] + 6 + 1])))
                            self.__imuData.quaternion[3] = float('.'.join(str(ele) for ele in struct.unpack('f', self.__imuSerial.receivedPackage[self.__imuSetting['QUATERNION_4_SIGNIFICANT_BIT'][0] + 6:self.__imuSetting['QUATERNION_4_SIGNIFICANT_BIT'][1] + 6 + 1])))

                            #print(_now- _connectStatusTimer)
                            _connectStatusTimer = _now
                            if self.__imuSetting['LOW_POWER']:
                                time.sleep(0.05)
                            self.__imuSerial.receivedPackage = b''
                            self.__imuSerial.serialPort.flushInput()
                            _retryCounter = 0
                        else:
                            if _retryCounter != self.__imuSerial.get_retry_counter():
                                _retryCounter = self.__imuSerial.get_retry_counter()
                                self.__imuData.imu["retryCounter"] += 1
                            self.__imuSerial.read_serial()
                    else:

                        self.__imuSerial.serialPort.open()
                        time.sleep(1)

                except Exception as _exception:
                    self.__imuSerial.connectStatus = False
                    self.__imuSerial.errorFlag = True
                    if (str(_exception) != "'NoneType' object has no attribute 'read'"):
                        print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] IMU:' + str(_exception)))
                    self.__imuSerial.reconnect()
                    time.sleep(1)

    def stop(self):
        self.finished.set()
        self.__imuSerial.finishFlag = True
        time.sleep(1)
        if self.__imuSerial.serialPort:
            self.__imuSerial.serialPort.close()
        print('[IO Control INFO] Shutdown IMU\r')
