import time
import datetime
from threading import Thread
from threading import Event
import sys
import os
from os.path import join
import subprocess

if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from io_control import Camera
from utility.RobotConfig import RobotData
from utility import Stream


class CameraCommunication(Thread):
    def __init__(self, _robotType=""):

        # Initial Thread
        Thread.__init__(self)
        print('[Cam INFO] Initial CameraCommunication\r')
        self.finished = Event()
        self.loadConfigStatus = False
        self.data = dict()
        self.camera = RobotData().data['camera']

        # Config Path
        global configPath
        configPath = join(configPath, _robotType)

        # Camera Setting
        self._camera_setting = dict()
        self._camera_port = '/usb1/'
        self._save_count_max = 5

        # Camera Parameter
        self._camera_para = dict()
        self._save_image = False
        self._save_flag = 'flag'
        self._save_count = 0
        self._current_row = 0
        self._error_event = False

    def run(self):
        try:
            self._camera_setting = Stream.load_config(
                join(configPath, 'CameraSetting.yaml'))

            self._camera_port = self._camera_setting['CAM_PORT_NAME']
            self._save_count_max = self._camera_setting['SAVE_IMAGE_COUNT']

            self._camera_para['index'] = self._find_camera()
            self._camera_para['live'] = self._camera_setting['LIVE_SHOW']
            self._camera_para['mean_error_min'] = self._camera_setting['MIN_MEAN']
            self._camera_para['mean_error_max'] = self._camera_setting['MAX_MEAN']
            self._camera_para['anchor_count'] = self._camera_setting['ANCHOR_COUNT']
            self._camera_para['min_angle'] = self._camera_setting['LIMIT_ANGLE']
            self._camera_para['gap'] = self._camera_setting['LINE_GAP']
            self._camera_para['frame_width'] = self._camera_setting['FRAME_WIDTH']
            self._camera_para['frame_height'] = self._camera_setting['FRAME_HEIGHT']
            self._camera_para['image_width'] = self._camera_setting['IMAGE_WIDTH']
            self._camera_para['image_height'] = self._camera_setting['IMAGE_HEIGHT']

            self.loadConfigStatus = True
        except Exception as _exception:
                print('\033[1;31m%s\033[0m\r'
                      % ('[Cam ERROR] Load Cam config error: ' + str(_exception)))

        if not self.loadConfigStatus:
            return

        self._init_params()
        cap = Camera.Camera(self._camera_para)

        while not self.finished.is_set():
            dt = datetime.datetime.now()
            image_path = '../img/%s/' % (dt.strftime('%Y-%m-%d'))
            if not os.path.isdir(image_path):
                os.makedirs(image_path)

            if self._save_image:
                save_path = '%s%s_%s_%00d' % (
                    image_path, dt.strftime('%H%M%S'),
                    _save_flag, self._save_count)
                self._save_count += 1
                if self._save_count > self._save_count_max:
                    self._save_image = False
                    self._save_count = 0
                    self._save_flag = 'flag'
            else:
                save_path = ''

            try:
                result = cap.get_result(self._reset_flag, save_path)
                self._set_params(result)
            except Exception as _exception:
                print('\033[1;31m%s\033[0m\r'
                      % ('[Cam ERROR]' + str(_exception)))
            time.sleep(0.05)

    def stop(self):
        self.finished.set()
        time.sleep(0.1)

    def reset(self):
        self._reset_flag = True

    def set_robot_status(self, current_row, error_event):
        if current_row == self._current_row + 1:
            self._save_image = True
            self._save_flag = '%000d' % (current_row)

        if error_event and not self._error_event:
            self._save_image = True
            self._save_flag = 'Error_%000d' % (current_row)

        self._current_row = current_row
        self._error_event = error_event

    def get_camera(self):
        if self.data['status'] == -1:
            self.camera['connect'] = False
        else:
            self.camera['connect'] = True
        self.camera['frameNumber'] = self.data['frame']
        self.camera['status'] = self.data['status']
        self.camera['location'] = self.data['location']
        self.camera['angle'] = self.data['angle']
        self.camera['cameraDebugData']['data0'] = self.data['data0']
        self.camera['cameraDebugData']['data1'] = self.data['data1']
        self.camera['cameraDebugData']['data2'] = self.data['data2']
        self.camera['cameraDebugData']['data3'] = self.data['data3']
        self.camera['cameraDebugData']['data4'] = self.data['data4']
        self.camera['cameraDebugData']['data5'] = self.data['data5']
        return self.camera

    def _init_params(self):
        self._reset_flag = False
        self.data.clear()
        self.data['status'] = -1
        self.data['frame'] = -1
        self.data['location'] = 0
        self.data['angle'] = 0
        self.data['data0'] = '0'
        self.data['data1'] = '0'
        self.data['data2'] = '0'
        self.data['data3'] = '0'
        self.data['data4'] = '0'
        self.data['data5'] = False

    def _set_params(self, value):
        self.data['status'] = value['status']
        if value['status'] == 2:
            self._reset_flag = 0

        self.data['frame'] = value['frame']
        self.data['location'] = value['location']
        self.data['angle'] = value['angle']
        self.data['data0'] = value['data0']
        self.data['data1'] = value['data1']
        self.data['data2'] = value['data2']
        self.data['data3'] = value['data3']
        self.data['data4'] = value['data4']
        self.data['data5'] = self._reset_flag

    def _find_camera(self):
        device_index = 999

        for f in os.listdir('/sys/class/video4linux'):
            real_file = os.path.realpath('/sys/class/video4linux/' + f)

            if self._camera_port not in real_file:
                continue
            temp = int(real_file.split('/video')[-1])

            if temp > device_index:
                continue
            device_index = temp

        return device_index
