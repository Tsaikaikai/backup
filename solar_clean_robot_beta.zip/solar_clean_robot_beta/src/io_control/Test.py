from ArduinoCommunication import ArduinoCommunication
from ArduinoLogSerial import ArduinoLogSerial
from IMUCommunication import IMUCommunication
import json
import time


def get_config_json():
    _jsonRawData = dict()
    _jsonRawData['COM_PORT_NAME'] = "/dev/controlIO"
    _jsonRawData['FIRMWARE_VERSION'] = 0x320
    _jsonRawData['SONAR_LOWER_LIMIT'] = 5
    _jsonRawData['SONAR_UPPER_LIMIT'] = 15
    _jsonRawData['IR_LOWER_LIMIT'] = 5
    _jsonRawData['IR_UPPER_LIMIT'] = 14
    _jsonRawData['IR_BIAS'] = [1, 2, 0, 1, 2, 1]
    return json.dumps(_jsonRawData)


def get_json():
    _jsonRawData = dict()

    _jsonRawData['connection'] = [False, False, True, False, False]
    _jsonRawData['robotState'] = 0
    _jsonRawData['robotVelocity'] = [0.2, 0.1]
    _jsonRawData['imu'] = [1.23, 2.34, 4.56]
    _jsonRawData['odom'] = [1.23444, 4.56, 1.23, 2.35, 4.56]
    _jsonRawData['sensor'] = dict()
    _jsonRawData['sensor']['cliff'] = [
        False, False, False, True, False, False]
    _jsonRawData['sensor']['range'] = [10, 10, 10, 10, 9, 10]
    _jsonRawData['sensor']['lower'] = 5
    _jsonRawData['sensor']['upper'] = 16
    _jsonRawData['battery'] = [12.01, 3.20, 45, 75]
    _jsonRawData['cleanArea'] = 123
    _jsonRawData['consumable'] = [12, 13]
    _jsonRawData['errorCode'] = 5
    _jsonRawData['testTimer'] = 12.3
    _jsonRawData['finishFlag'] = False

    return json.dumps(_jsonRawData)


def main():
    # Thread of Arduino Communication
    _arduinoCommunicationThread = ArduinoCommunication("Beta_3_1")
    _arduinoCommunicationThread.start()
    time.sleep(1)

    # Thread of Arduion Log Serial
    _arduinoLogSerialThread = ArduinoLogSerial("Beta_3_1")
    _arduinoLogSerialThread.start()
    time.sleep(1)

    # Thread of IMU
    _imuCommunicationThread = IMUCommunication("Beta_3_1")
    _imuCommunicationThread.start()
    time.sleep(1)

    try:
        # _arduinoCommunicationThread.set_setting_config(get_config_json())
        # print(_arduinoCommunicationThread.get_setting_config())
        while(1):
            time.sleep(0.01)
            # _arduinoCommunicationThread.set_clean_motor(True)
            # _arduinoCommunicationThread.set_velocity([0.2, 0.1])
            # print(_arduinoCommunicationThread.get_drive_motor())
            # print(_arduinoCommunicationThread.get_battery())
            # print(_arduinoCommunicationThread.get_sonar())
            # print(_arduinoCommunicationThread.get_master_board())
            # print(_arduinoCommunicationThread.get_slave_board())
            # print(_arduinoCommunicationThread.get_power_button())
            # print(_arduinoCommunicationThread.get_clean_button())

            # print(_imuCommunicationThread.get_time_stamp())
            # print(_imuCommunicationThread.get_connect_status())
            # print(_imuCommunicationThread.get_imu())
            # print(_imuCommunicationThread.get_euler())
            # print(_imuCommunicationThread.get_acceleration())
            # print(_imuCommunicationThread.get_gyroscope())
            # print(_imuCommunicationThread.get_magnetic())
            # print(_imuCommunicationThread.get_quaternion())

    except KeyboardInterrupt:
        _arduinoCommunicationThread.stop()
        _arduinoLogSerialThread.stop()
        _imuCommunicationThread.stop()
        print("Test.py shutdown")


if __name__ == "__main__":
    main()
