#!/usr/bin/env python3
import os
from os.path import join
import sys
import time
from datetime import date, datetime
from threading import Thread, Event
from subprocess import Popen, PIPE
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
    logPath = '../log'
else:
    configPath = '../../config'
    logPath = '../../log'
    sys.path.append("..")
from utility import Stream
import serial


class ArduinoLogSerial(Thread):
    def __init__(self, robotType=""):
        # Initial Thread
        Thread.__init__(self)
        print('[IO Control INFO] Initial arduino Log Serial...\r')
        self.finished = Event()
        self.loadConfigStatus = False
        # Config Path
        global configPath
        configPath = join(configPath, robotType)

        self.__arduinoMasterLogSerial = None
        self.__arduinoSlaveLogSerial = None

    def set_setting_config(self, _arduinoSetting):
        self.__arduinoSetting = _arduinoSetting
        Stream.save_config(
            join(configPath, 'ArduinoSetting.yaml'), self.__arduinoSetting)
        return True

    def get_setting_config(self):
        return self.__arduinoSetting

    def run(self):
        try:
            global configPath
            global logPath
            # Arduino Setting
            self.__arduinoSetting = Stream.load_config(join(configPath, 'ArduinoSetting.yaml'))
            logPath = join(logPath, str(date.today()))
            if self.__arduinoSetting:
                self.loadConfigStatus = True
                # Arduino Parameter
            if self.__arduinoSetting['FIRMWARE_VERSION'] >= 0x320:
                self.__arduinoMasterLogSerial = serial.Serial(port=self.__arduinoSetting['MASTER_LOG_PORT'], baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=5, xonxoff=False, rtscts=False)
                # self.__arduinoSlaveLogSerial = serial.Serial(port=self.__arduinoSetting['SLAVE_DEBUG_PORT'], baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=5, xonxoff=False, rtscts=False)
        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Load arduino config exception: ' + str(_exception)))
        if self.loadConfigStatus:
            print('[IO Control INFO] Run Arduino Log Serial\r')
            while not self.finished.is_set():
                time.sleep(0.01)
                try:
                    if self.__arduinoMasterLogSerial.in_waiting:
                        _masterData = self.__arduinoMasterLogSerial.readline().decode('utf-8')
                        if _masterData:
                            _logFileName = "Master_"+str(datetime.now().strftime("%Y-%m-%d_%H")) + ".txt"
                            _timeStamp = str(datetime.now().strftime("%H:%M:%S"))
                            Stream.save_log(logPath, _logFileName, _timeStamp, _masterData)
                except Exception as _exception:
                    try:
                        _logFileName = "Master_"+str(datetime.now().strftime("%Y-%m-%d_%H")) + ".txt"
                        _timeStamp = str(datetime.now().strftime("%H:%M:%S"))
                        _logData = "Arduino Log Serial Exception: " + str(_exception)+"\n"
                        Stream.save_log(logPath, _logFileName, _timeStamp, _logData)
                        if self.__arduinoMasterLogSerial:
                            self.__arduinoMasterLogSerial.close()
                            _echo = Popen(['echo', 'robot'], stdout=PIPE)
                            p = Popen(['sudo', '-S', 'udevadm', 'trigger', self.__arduinoSetting['MASTER_LOG_PORT']], stdin=_echo.stdout, stdout=PIPE)
                            time.sleep(5)
                            self.__arduinoMasterLogSerial.open()
                        else:
                            time.sleep(1)
                            self.__arduinoMasterLogSerial = serial.Serial(port=self.__arduinoSetting['MASTER_LOG_PORT'], baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=0.1, xonxoff=False, rtscts=False)
                    except Exception as __exception:
                        pass
                    print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Log Serial Exception: ' + str(_exception)))
                # try:
                #     if self.__arduinoSlaveLogSerial.in_waiting:
                #         _slaveData = self.__arduinoSlaveLogSerial.readline().decode('utf-8')
                #         if _slaveData:
                #             # print(_slaveData)
                #             _logFileName = "Slave"+str(datetime.now().strftime("%d-%m-%Y_%H")) + ".txt"
                #             _timeStamp = str(datetime.now().strftime("%H:%M:%S"))
                #             Stream.save_log(logPath, _logFileName, _timeStamp, _slaveData)
                # except Exception as _exception:
                #     try:
                #         if self.__arduinoSlaveLogSerial:
                #             self.__arduinoSlaveLogSerial.close()
                #             _echo = Popen(['echo', 'robot'], stdout=PIPE)
                #             p = Popen(['sudo', '-S', 'udevadm', 'trigger', self.__arduinoSetting['SLAVE_DEBUG_PORT']], stdin=_echo.stdout, stdout=PIPE)
                #             time.sleep(5)
                #             self.__arduinoSlaveLogSerial.open()
                #         else:
                #             time.sleep(1)
                #             self.__arduinoSlaveLogSerial = serial.Serial(port=self.__arduinoSetting['SLAVE_DEBUG_PORT'], baudrate=115200, bytesize=8, parity='N', stopbits=1, timeout=0.1, xonxoff=False, rtscts=False)
                #     except Exception as __exception:
                #         pass
                #     print('\033[1;31m%s\033[0m\r' % ('[IO Control ERROR] Arduino Log Serial Exception: ' + str(_exception)))

    def stop(self):
        if self.__arduinoMasterLogSerial:
            self.__arduinoMasterLogSerial.close()
        if self.__arduinoSlaveLogSerial:
            self.__arduinoSlaveLogSerial.close()
        self.finished.set()
        time.sleep(1)
        print('[IO Control INFO] Shutdown Arduino log recorder\r')
