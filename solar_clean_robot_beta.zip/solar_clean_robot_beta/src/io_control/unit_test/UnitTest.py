import time
from sys import path
from os.path import isfile, join
if isfile("main.py") or isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../../config'
    path.append("../../")
from utility import RobotConfig, Stream
from io_control.unit_test import ArduinoPackageTest


robotData = RobotConfig.RobotData().data
robotType = "Beta_3_1"
configPath = join(configPath, robotType)
arduinoSetting = Stream.load_config(join(configPath, "ArduinoSetting.yaml"))
time.sleep(1)


def main():
    global robotData
    try:
        time.sleep(1)
        print("IO Control Test Start")

        # Arduino Package Test
        _arduinoPackageTest = ArduinoPackageTest.ArduinoPackageTest(arduinoSetting)
        _arduinoPackageTest.decode_package()
        _arduinoPackageTest.encode_package()

        print("IO Control Test End")
    except KeyboardInterrupt:
        print("UnitTest.py shutdown")


if __name__ == "__main__":
    main()
