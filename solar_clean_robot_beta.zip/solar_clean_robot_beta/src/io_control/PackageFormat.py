from enum import Enum


class PackageFormat(Enum):
    HEADER = 0xFF
    FOOTER = 0xEE

    # class CH110PackageFormat(Enum):
    PRE = 0x5A
    TYPE = 0xA5
    POLY = 0x1021

    # class clean motor state(Enum):
    RELAY_ALL_OFF = 0b00000000
    RELAY_ALL_ON = 0b00000111
    RELAY_0_ON = 0b00000001
    RELAY_1_ON = 0b00000010
    RELAY_2_ON = 0b00000100

    # class drive motor state(Enum):
    DRIVE_MOTOR_STOP = 0b00000000
    DRIVE_MOTOR_BRAKE_OFF = 0b10000000
    DRIVE_MOTOR_ALARM = 0b01000000

    # class beeper state(Enum):
    BEEPER_OFF = 0b00000000
    BEEPER_ON = 0b00000001
