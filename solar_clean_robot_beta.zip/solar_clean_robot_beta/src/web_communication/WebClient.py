#!/usr/bin/env python3
import time
import requests
import json
from datetime import datetime, date, timezone
from os.path import join, isfile
from threading import Thread, Event
from yaml import load, FullLoader

if isfile("./main.py") or isfile("./main.bin"):
    configPath = "../config"
    logPath = '../log'
elif isfile("./UnitTest.py"):
    import sys
    configPath = "../../../config"
    logPath = '../../../log'
    sys.path.append("../..")
else:
    import sys
    configPath = "../../config"
    logPath = '../../log'
    sys.path.append("..")

from utility import JSONStream, RobotConfig, Stream
from web_communication import APIControl, MQTTControl, UIConfig


class WebClient(Thread):
    # class WebClient():
    def __init__(self, _robotType="") -> None:
        # Initial Thread
        Thread.__init__(self)
        # Log data
        self.__logDataList = []
        self.__logDataList.append(Stream.print_log("[Web Communication INFO] Initial Web Client ...\r", RobotConfig.LogType.INFO.value))
        self.finished = Event()
        self.loadConfigStatus = False
        self.threadStatus = False

        # Config Path
        global configPath
        configPath = join(configPath, _robotType)
        self.__reportDict = dict()
        self.__cloudDict = dict()

        self.__patchRobotFlag = False
        self.__mqttDataMessage = {"state_code": 0, "sub_state_code": 0, "alarm": 0, "clean_motor_flag": 0, "message": ""}
        self.__mqttDataRequest = False
        self.__mqttDataResponse = False
        self.__emergencyFlag = False
        self.__controlFlag = False
        self.__finishFlag = False

        self.__mqttInformationMessage = dict()
        self.__mqttInformationMessage["alarm"] = {"status": False, "message": ""}
        self.__mqttInformationMessage["controlVelocity"] = {"status": False, "message": ""}
        self.__mqttInformationMessage["cleanMotorFlag"] = {"status": False, "message": ""}

        self.__mqttInformationRequest = dict()
        self.__mqttInformationRequest["alarm"] = False
        self.__mqttInformationRequest["controlVelocity"] = False
        self.__mqttInformationRequest["cleanMotorFlag"] = False

        self.__batteryStart = 0
        self.__softwareVersion = 0
        self.__firmwareVersion = 0

        # JSON Data
        self.__uiStatus = UIConfig.UIStatus().data
        self.__robotStatus = UIConfig.RobotStatus().data
        self.__taskLog = []
        self.__uiCommand = RobotConfig.RobotData().data["uiCommand"]

        if self.__load_config(configPath):
            self.loadConfigStatus = True
            self.threadStatus = self.loadConfigStatus

            self.__mqttControlList = ["alarm", "controlVelocity", "cleanMotorFlag"]
            self.__mqttTopicList = ["alarm", "control_velocity", "clean_motor_flag", "imu"]
            self.__uiCommandList = ["beeperFlag", "controlVelocity", "cleanMotorFlag"]
            self.__deviceStatusList = [False, False, False]

    def initial_class(self) -> None:
        while self.__robotStatus["backend"]["robotID"] == "":
            self.__logDataList.append(Stream.print_log("[Web Communication INFO] Wait for robot ID ...\r", RobotConfig.LogType.INFO.value))
            time.sleep(1)
        self.__robotApiControl = APIControl.RobotAPIControl(self.__cloudDict, _protocol="http")

        self.__mqttController = MQTTControl.MQTTController(_ip=self.__cloudDict["MQTT_URL"], _port=self.__cloudDict["MQTT_PORT"], _userName=self.__cloudDict["MQTT_USERNAME"],
                                                           _password=self.__cloudDict["MQTT_PASSWORD"], _robotID=self.__cloudDict["ROBOT_ID"], _qos=self.__cloudDict["BACKEND_MQTT_QOS"])

    def initial_parameter(self) -> None:
        self.__patchRobotFlag = False
        self.__mqttDataMessage = {"state_code": 0, "sub_state_code": 0, "alarm": 0, "clean_motor_flag": 0, "message": ""}
        self.__mqttDataRequest = False
        self.__mqttDataResponse = False

        # JSON Data
        self.__uiStatus = UIConfig.UIStatus().data
        self.__taskLog = []
        self.__robotStatus = UIConfig.RobotStatus().data
        self.__uiCommand = RobotConfig.RobotData().data["uiCommand"]

    def __load_config(self, _configPath) -> bool:
        _cloudPath = join(_configPath, "CloudSetting.yaml")
        if not isfile(_cloudPath):
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Load Report config error: CloudSetting.yaml are not exists", RobotConfig.LogType.ERROR.value))
            return False
        else:
            try:
                with open(_cloudPath, "r") as f:
                    self.__cloudDict = load(f, Loader=FullLoader)
                    f.close()
                return True
            except Exception as _exception:
                # print("\033[1;31m%s\033[0m\r" % ("[IO Control ERROR] Load arduino or battery config error: " + str(_exception)))
                return False

    def __update_task_log(self):
        self.__taskLog[-1]["stateCode"] = self.__robotStatus["backend"]["stateCode"]
        self.__taskLog[-1]["subStateCode"] = self.__robotStatus["backend"]["subStateCode"]
        self.__taskLog[-1]["cleanCountNow"] = self.__robotStatus["backend"]["cleanCountNow"]
        self.__taskLog[-1]["cleanTimeNow"] = self.__robotStatus["backend"]["cleanTimeNow"]
        self.__taskLog[-1]["cleanDistanceNow"] = self.__robotStatus["backend"]["cleanDistanceNow"]
        self.__taskLog[-1]["batteryNowUsed"] = self.__robotStatus["backend"]["batteryNowUsed"]
        self.__taskLog[-1]["cleanEndTime"] = datetime.now(timezone.utc).isoformat(timespec="seconds")

    def set_cloud_parameter(self, _cloudData) -> None:
        self.__cloudDict.update(JSONStream.get_dict_data(_cloudData))
        self.__robotStatus["backend"]["robotID"] = self.__cloudDict["ROBOT_ID"]

    def get_location(self):
        return self.__ipinfoControl.get_location()

    def get_button_status(self) -> dict:
        return self.__uiCommand

    def get_ui_status(self) -> dict:
        return self.__uiStatus

    def robot_state_to_ui_robot_state(self, _robotState) -> int:
        if _robotState == RobotConfig.RobotState.REMOTE.value:
            return RobotConfig.UIRobotState.STANDBY.value
        elif _robotState == RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value or _robotState == RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value:
            return RobotConfig.UIRobotState.NAVIGATION.value
        elif _robotState == RobotConfig.RobotState.RETURN.value:
            return RobotConfig.UIRobotState.RETURN.value
        elif _robotState == RobotConfig.RobotState.ABNORMAL.value:
            return RobotConfig.UIRobotState.ABNORMAL.value
        elif _robotState == RobotConfig.RobotState.LOW_BATTERY_ABNORMAL.value:
            self.__robotStatus["backend"]["subStateCode"] = 4002
            return RobotConfig.UIRobotState.ABNORMAL.value
        elif _robotState == RobotConfig.RobotState.CAMERA_ABNORMAL.value:
            self.__robotStatus["backend"]["subStateCode"] = 9001
            return RobotConfig.UIRobotState.ABNORMAL.value
        else:
            return RobotConfig.UIRobotState.DISSCONNECT.value

    def ui_robot_state_to_robot_state(self, _uiRobotState) -> int:
        if _uiRobotState == RobotConfig.UIRobotState.STANDBY.value:
            return RobotConfig.RobotState.REMOTE.value
        elif _uiRobotState == RobotConfig.UIRobotState.NAVIGATION.value:
            if self.__uiCommand["navSetting"]["cleanMode"] == RobotConfig.CleanMode.LEFT_TOP_NAVIGATION.value:
                return RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value
            elif self.__uiCommand["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RIGHT_TOP_NAVIGATION.value:
                return RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value
        elif _uiRobotState == RobotConfig.UIRobotState.RETURN.value:
            return RobotConfig.RobotState.RETURN.value
        elif _uiRobotState == RobotConfig.UIRobotState.ABNORMAL.value:
            return RobotConfig.RobotState.ABNORMAL.value
        else:
            return RobotConfig.RobotState.INITIAL.value

    def version_format(self, _version) -> str:
        _versionPatch = _version % 16
        _versionMinor = (_version >> 4) % 16
        _versionMajor = (_version >> 8) % 16
        return str(_versionMajor)+"."+str(_versionMinor)+"."+str(_versionPatch)

    def set_robot_status(self, _robotConfig) -> bool:
        self.__robotStatus["backend"]["robotID"] = _robotConfig["recorder"]["robotID"]
        self.__cloudDict["ROBOT_ID"] = _robotConfig["recorder"]["robotID"]
        if self.__robotStatus["backend"]["stateCode"] != self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"]):
            self.__patchRobotFlag = True
            if self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"]) == RobotConfig.UIRobotState.NAVIGATION.value:
                self.__batteryStart = self.__robotStatus["backend"]["battery"]
            elif self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"]) == RobotConfig.UIRobotState.STANDBY.value:
                self.__uiCommand["navFlag"] = False
                self.__uiCommand["cleanMotorFlag"] = False
                self.__uiCommand["controlVelocity"] = [0.0, 0.0]
            elif self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"]) == RobotConfig.UIRobotState.RETURN.value:
                self.__batteryStart = self.__robotStatus["backend"]["battery"]
        elif self.__robotStatus["backend"]["cleanCountNow"] != _robotConfig["navigation"]["cleanCountNow"] and self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"]) == RobotConfig.UIRobotState.NAVIGATION.value:
            self.__patchRobotFlag = True
        if _robotConfig["navigation"]["finishFlag"] == True and (self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.NAVIGATION.value or self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.RETURN.value):
            self.__patchRobotFlag = True
        self.__softwareVersion = _robotConfig["main"]["softwareVersion"]
        self.__firmwareVersion = _robotConfig["boardMaster"]["firmwareVersion"]
        self.__finishFlag = _robotConfig["navigation"]["finishFlag"]
        self.__robotStatus["backend"]["stateCode"] = self.robot_state_to_ui_robot_state(_robotConfig["navigation"]["robotState"])
        if _robotConfig["navigation"]["robotState"] != RobotConfig.RobotState.LOW_BATTERY_ABNORMAL.value and _robotConfig["navigation"]["robotState"] != RobotConfig.RobotState.CAMERA_ABNORMAL.value:
            self.__robotStatus["backend"]["subStateCode"] = _robotConfig["main"]["errorCode"][0]
        self.__robotStatus["backend"]["battery"] = _robotConfig["battery"]["SOC"]
        self.__robotStatus["backend"]["batteryNowUsed"] = self.__batteryStart - _robotConfig["battery"]["SOC"]
        self.__robotStatus["backend"]["cleanDistanceNow"] = int(_robotConfig["recorder"]["cleanDistanceNow"])  # Uint: m
        self.__robotStatus["backend"]["cleanDistanceTotal"] = _robotConfig["recorder"]["cleanDistanceTotal"]/1000.0  # Uint: km
        self.__robotStatus["backend"]["cleanTimeNow"] = int(_robotConfig["recorder"]["cleanTimeNow"]/60)  # Uint: min
        self.__robotStatus["backend"]["cleanTimeTotal"] = int(_robotConfig["recorder"]["cleanTimeTotal"]/3600)  # Uint: hour
        self.__robotStatus["backend"]["cleanCountNow"] = _robotConfig["navigation"]["cleanCountNow"]
        self.__robotStatus["backend"]["pedrailRemainTime"] = int(_robotConfig["recorder"]["pedrailRemainTime"]/(60*60))  # Uint: hour
        self.__robotStatus["backend"]["brushRemainTime"] = int(_robotConfig["recorder"]["brushRemainTime"]/(60*60))  # Uint: hour
        self.__robotStatus["backend"]["internetState"] = "4G Good"

        if self.__controlFlag:
            self.__robotStatus["backend"]["alarm"] = int(self.__uiCommand["beeperFlag"] and _robotConfig["boardMaster"]["connect"])
            self.__mqttDataMessage["alarm"] = int(self.__uiCommand["beeperFlag"] and _robotConfig["boardMaster"]["connect"])
            self.__uiCommand["beeprFlag"] = bool(self.__robotStatus["backend"]["alarm"])

            self.__robotStatus["backend"]["cleanMotorFlag"] = int(self.__uiCommand["cleanMotorFlag"] and _robotConfig["boardMaster"]["connect"])
            self.__mqttDataMessage["clean_motor_flag"] = int(self.__uiCommand["cleanMotorFlag"] and _robotConfig["boardMaster"]["connect"])
            self.__uiCommand["cleanMotorFlag"] = bool(self.__robotStatus["backend"]["cleanMotorFlag"])
            self.__patchRobotFlag = True
            self.__mqttDataRequest = True

        self.__robotStatus["frontend"]["clean_distance_now"] = int(_robotConfig["recorder"]["cleanDistanceNow"])
        self.__robotStatus["frontend"]["clean_distance_total"] = _robotConfig["recorder"]["cleanDistanceTotal"]/1000.0
        if _robotConfig["imu"]["connect"]:
            self.__robotStatus["frontend"]["imu"]["pitch"] = _robotConfig["imu"]["euler"][1]
        else:
            self.__robotStatus["frontend"]["imu"]["pitch"] = 0xFFFF
        self.__deviceStatusList[0] = _robotConfig["boardMaster"]["connect"]
        self.__deviceStatusList[1] = _robotConfig["driveMotor"]["connect"]
        self.__deviceStatusList[2] = _robotConfig["boardMaster"]["connect"]

        if self.__patchRobotFlag:
            if self.__mqttDataRequest:
                self.__mqttDataMessage["state_code"] = self.__robotStatus["backend"]["stateCode"]
                self.__mqttDataMessage["sub_state_code"] = self.__robotStatus["backend"]["subStateCode"]
                self.__controlFlag = False
                self.__mqttDataRequest = False
                self.__mqttDataResponse = True
            if self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.RETURN.value and _robotConfig["navigation"]["finishFlag"] == False:
                self.__uiCommand["navFlag"] = True
                self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                self.__uiStatus["stateCode"] = self.__robotStatus["backend"]["stateCode"]
                self.__uiStatus["subStateCode"] = self.__robotStatus["backend"]["subStateCode"]
            elif self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.DISSCONNECT or self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.ABNORMAL.value:
                self.__uiCommand["navFlag"] = False
                self.__uiCommand["cleanMotorFlag"] = False
                self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                self.__uiStatus["stateCode"] = self.__robotStatus["backend"]["stateCode"]
                self.__uiStatus["subStateCode"] = self.__robotStatus["backend"]["subStateCode"]
            elif self.__robotStatus["backend"]["stateCode"] == RobotConfig.UIRobotState.STANDBY.value:
                self.__uiCommand["navFlag"] = False
                self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                self.__uiStatus["stateCode"] = self.__robotStatus["backend"]["stateCode"]
                self.__uiStatus["subStateCode"] = self.__robotStatus["backend"]["subStateCode"]
        return True

    def __decode_mqtt_data_message(self):
        if "clean_command" in self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"]).keys():
            self.__commandTimeout = datetime.strptime(self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["timeout"], "%Y-%m-%dT%H:%M:%S%z")
            if (self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] & UIConfig.CleanCommand.CLEAN_MOTOR_OFF.value) == UIConfig.CleanCommand.CLEAN_MOTOR_OFF.value:
                self.__uiCommand["cleanMotorFlag"] = bool(self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] & 0x01)
                self.__controlFlag = True
            elif (self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] & UIConfig.CleanCommand.ALARM_OFF.value) == UIConfig.CleanCommand.ALARM_OFF.value:
                self.__uiCommand["beeperFlag"] = bool(self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] & 0x01)
                self.__mqttDataMessage["alarm"] = int(self.__uiCommand["beeperFlag"] and self.__deviceStatusList[0])
                self.__controlFlag = True
                self.__uiCommand["errorCode"] = 8003
            elif self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] != UIConfig.CleanCommand.STOP_CLEAN.value and self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] != UIConfig.CleanCommand.STOP_RETURN.value:
                try:
                    self.__taskLog.append(UIConfig.UITaskLog().data)
                    self.__taskLog[-1]["cleanSerialNumber"] = self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_serial_number"]
                    _serialNumber = self.__taskLog[-1]["cleanSerialNumber"].split("$")
                    datetime.strptime(_serialNumber[1], "%Y-%m-%dT%H:%M:%S%z")
                    if self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] == UIConfig.CleanCommand.START_CLEAN.value:
                        _robotSetting = self.__robotApiControl.get_robot_setting(self.__cloudDict["ROBOT_ID"])
                        if _robotSetting["sub_state_code"] == 0:
                            if _robotSetting["direction"] == 0:
                                self.__uiCommand["navSetting"]["cleanMode"] = RobotConfig.CleanMode.LEFT_TOP_NAVIGATION.value
                            else:
                                self.__uiCommand["navSetting"]["cleanMode"] = RobotConfig.CleanMode.RIGHT_TOP_NAVIGATION.value
                            self.__uiCommand["navSetting"]["cleanCount"] = _robotSetting["clean_count"]
                            self.__uiCommand["navFlag"] = True
                            self.__uiCommand["cleanMotorFlag"] = True
                            self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                            self.__uiCommand["navSetting"]["cleanSpeed"] = _robotSetting["clean_speed"]
                            self.__taskLog[-1]["cleanSpeed"] = _robotSetting["clean_speed"]
                            self.__taskLog[-1]["direction"] = _robotSetting["direction"]
                            self.__mqttDataRequest = True
                        else:
                            self.__mqttDataMessage["state_code"] = _robotSetting["state_code"]
                            self.__mqttDataMessage["message"] = _robotSetting["Error"]
                            self.__mqttDataResponse = True
                            self.__mqttDataRequest = False
                        self.__mqttDataMessage["sub_state_code"] = _robotSetting["sub_state_code"]
                    elif self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"])["clean_command"] == UIConfig.CleanCommand.START_RETURN.value:
                        self.__uiCommand["navSetting"]["cleanMode"] = RobotConfig.CleanMode.RETURN.value
                        self.__uiCommand["navFlag"] = True
                        self.__uiCommand["cleanMotorFlag"] = False
                        self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                        self.__mqttDataMessage["state_code"] = RobotConfig.UIRobotState.RETURN.value
                        self.__mqttDataMessage["message"] = ""
                        self.__mqttDataRequest = True
                    else:
                        self.__uiCommand["navFlag"] = False
                        self.__uiCommand["cleanMotorFlag"] = False
                        self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                        self.__mqttDataResponse = True
                        self.__mqttDataRequest = False

                except Exception as _exception:
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_exception) + "\r", RobotConfig.LogType.ERROR.value))
                    self.__uiStatus["stateCode"] = RobotConfig.UIRobotState.STANDBY.value
                    self.__uiStatus["subStateCode"] = 1009
                    self.__uiCommand["navFlag"] = False
                    self.__uiCommand["cleanMotorFlag"] = False
                    self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                    self.__mqttDataMessage["state_code"] = RobotConfig.UIRobotState.STANDBY.value
                    self.__mqttDataMessage["sub_state_code"] = 1009
                    self.__mqttDataMessage["message"] = "Serial Number Error"
                    self.__mqttDataResponse = True
                    self.__mqttDataRequest = False
            else:
                self.__uiCommand["navFlag"] = False
                self.__uiCommand["cleanMotorFlag"] = False
                self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                self.__mqttDataRequest = True

    def __decode_mqtt_control_message(self, _keyValue) -> None:
        self.__mqttInformationRequest[_keyValue] = True
        if self.__mqttTopicList[self.__mqttControlList.index(_keyValue)] in self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/control_velocity/robot_control").keys():
            if self.__deviceStatusList[self.__mqttControlList.index(_keyValue)]:
                self.__mqttInformationMessage[_keyValue] = {"status": True, "message": ""}
            else:
                self.__mqttInformationMessage[_keyValue] = {"status": False, "message": "Device Disconnect"}
            self.__uiCommand[self.__uiCommandList[self.__mqttControlList.index(_keyValue)]] = self.__mqttController.get_info(self.__cloudDict["ROBOT_ID"]+"/control_velocity/robot_control")[self.__mqttTopicList[self.__mqttControlList.index(_keyValue)]]
            if _keyValue == "controlVelocity":
                if self.__uiCommand["controlVelocity"][0] == None:
                    self.__uiCommand["controlVelocity"][0] = 0.0
                if self.__uiCommand["controlVelocity"][1] == None:
                    self.__uiCommand["controlVelocity"][1] = 0.0
                self.__uiCommand["controlVelocity"][1] *= -1

    def run(self) -> None:
        global logPath
        try:
            if self.loadConfigStatus:
                logPath = join(logPath, str(date.today()))
                self.__logDataList.append(Stream.print_log("[Web Communication INFO] Run Web Client\r", RobotConfig.LogType.INFO.value))
                self.initial_class()
                self.api_loop()
        except Exception as _exception:
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_exception) + "\r", RobotConfig.LogType.ERROR.value))
            if(len(self.__logDataList) > 0):
                _logFileName = "WebClient_"+str(datetime.now().strftime("%Y-%m-%d_%H")) + ".txt"
                _logFileName = join(logPath, _logFileName)
                Stream.save_log_list(_logFileName, self.__logDataList)

    def api_loop(self) -> None:
        global logPath
        _now = time.time()
        _dataUpdateTimer = _now
        _realtimeInformationUpdateTimer = _now
        _controlUpdateTimer = _now
        _emergencyTimer = _now
        self.__mqttController.client.loop_start()
        while not self.__softwareVersion or not self.__firmwareVersion:
            time.sleep(1)
        self.__logDataList.append(Stream.print_log("[Web Communication INFO] Robot ID: "+self.__cloudDict["ROBOT_ID"]+", Software Version: "+self.version_format(self.__softwareVersion)+", Firmware Version: "+self.version_format(self.__firmwareVersion)+"\r", RobotConfig.LogType.INFO.value))
        self.__robotApiControl.patch_robot_version({"robotID": self.__cloudDict["ROBOT_ID"], "softwareVersion": self.version_format(self.__softwareVersion), "firmwareVersion": self.version_format(self.__firmwareVersion)})
        while not self.finished.is_set():
            try:
                time.sleep(0.01)
                _now = time.time()
                if self.__mqttController.available(_topicName=self.__cloudDict["ROBOT_ID"]+"/"+self.__cloudDict["BACKEND_SUBSCRIBE_TOPIC"]):
                    self.__decode_mqtt_data_message()
                if self.__patchRobotFlag:
                    self.__patchRobotFlag = False
                    if self.__finishFlag:

                        _tempRobotStatus = self.__robotStatus["backend"]
                        if self.__robotStatus["backend"]["subStateCode"] == 0:
                            _tempRobotStatus["stateCode"] = RobotConfig.UIRobotState.STANDBY.value
                            if self.__taskLog:
                                self.__update_task_log()
                                self.__robotApiControl.put_robot_log(self.__taskLog[-1])
                                self.__taskLog.remove(self.__taskLog[-1])
                        else:
                            _tempRobotStatus["stateCode"] = RobotConfig.UIRobotState.ABNORMAL.value
                        _response = self.__robotApiControl.patch_robot(_tempRobotStatus)
                        self.__uiCommand["navFlag"] = False
                        self.__uiCommand["cleanMotorFlag"] = False
                        self.__robotStatus["backend"]["cleanCountNow"] = 0
                        self.__patchRobotFlag = True
                    else:
                        if self.__taskLog and self.__uiCommand["navFlag"] == False:
                            self.__update_task_log()
                            if self.__taskLog[-1]["stateCode"] == RobotConfig.UIRobotState.ABNORMAL.value:
                                self.__robotApiControl.put_robot_abnormal_log(self.__taskLog[-1])
                                self.__robotApiControl.put_robot_log(self.__taskLog[-1])
                                self.__taskLog.remove(self.__taskLog[-1])
                        _response = self.__robotApiControl.patch_robot(self.__robotStatus["backend"])

                    if _response["sub_state_code"] != 0:
                        self.__mqttDataMessage["state_code"] = _response["state_code"]
                        self.__mqttDataMessage["sub_state_code"] = _response["sub_state_code"]
                        self.__mqttDataMessage["message"] = _response["Error"]
                    else:
                        self.__mqttDataMessage["state_code"] = self.__robotStatus["backend"]["stateCode"]
                        self.__mqttDataMessage["sub_state_code"] = self.__robotStatus["backend"]["subStateCode"]

                    if self.__mqttDataResponse:
                        self.__uiStatus["stateCode"] = self.__mqttDataMessage["state_code"]
                        self.__uiStatus["subStateCode"] = self.__mqttDataMessage["sub_state_code"]
                    else:
                        self.__uiStatus["stateCode"] = _response["state_code"]
                        self.__uiStatus["subStateCode"] = _response["sub_state_code"]
                    _dataUpdateTimer = _now
                elif self.__mqttDataResponse:
                    self.__mqttDataResponse = False
                    if self.__mqttDataMessage["sub_state_code"] == 0:
                        self.__mqttDataMessage.update({"state_code": self.__robotStatus["backend"]["stateCode"], "sub_state_code": self.__robotStatus["backend"]["subStateCode"], "message": ""})
                    elif self.__uiCommand["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value and self.__robotStatus["backend"]["stateCode"] & 0x0F == RobotConfig.UIRobotState.RETURN.value:
                        self.__mqttDataMessage.update({"state_code": RobotConfig.UIRobotState.RETURN.value, "sub_state_code": 4002, "message": ""})
                    elif self.__uiCommand["navFlag"] == True:
                        if self.__robotStatus["backend"]["stateCode"] != RobotConfig.UIRobotState.NAVIGATION.value and self.__uiCommand["navSetting"]["cleanMode"] != RobotConfig.CleanMode.LEFT_TOP_NAVIGATION.value and self.__uiCommand["navSetting"]["cleanMode"] != RobotConfig.CleanMode.RIGHT_TOP_NAVIGATION.value:
                            self.__mqttDataMessage.update({"state_code": RobotConfig.UIRobotState.STANDBY.value, "sub_state_code": 1008, "message": "robot state can't be changed"})
                        elif self.__robotStatus["backend"]["stateCode"] != RobotConfig.UIRobotState.RETURN.value and self.__uiCommand["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value:
                            self.__mqttDataMessage.update({"state_code": RobotConfig.RobotConfig.UIRobotState.STANDBY.value, "sub_state_code": 1008, "message": "robot state can't be changed"})
                    elif self.__uiCommand["navFlag"] == False and self.__robotStatus["backend"]["stateCode"] & 0x0F != RobotConfig.UIRobotState.STANDBY.value:
                        self.__mqttDataMessage.update({"state_code": RobotConfig.UIRobotState.STANDBY.value, "sub_state_code": 1008, "message": "robot state can't be changed"})
                    if self.__commandTimeout > datetime.now(timezone.utc):
                        self.__mqttController.client.publish(self.__cloudDict["ROBOT_ID"]+"/data/receive", json.dumps(self.__mqttDataMessage))
                    else:
                        self.__uiCommand["navFlag"] = False
                        self.__uiCommand["cleanMotorFlag"] = False
                        self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                    self.__uiStatus["stateCode"] = self.__mqttDataMessage["state_code"]
                    self.__uiStatus["subStateCode"] = self.__mqttDataMessage["sub_state_code"]
                if self.__mqttController.available(_topicName=self.__cloudDict["ROBOT_ID"]+"/control_velocity/robot_control"):
                    self.__decode_mqtt_control_message("controlVelocity")
                    _controlUpdateTimer = _now
                elif _now - _controlUpdateTimer > 1:
                    self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                elif self.__mqttInformationRequest["controlVelocity"] == True:
                    self.__mqttInformationRequest["controlVelocity"] = False
                    if not self.__deviceStatusList[self.__mqttControlList.index("controlVelocity")]:
                        self.__uiCommand["controlVelocity"] = [0.0, 0.0]
                    self.__mqttController.client.publish(self.__cloudDict["ROBOT_ID"]+"/control_velocity/robot_information", json.dumps(self.__mqttInformationMessage["controlVelocity"]))
                if _now - _dataUpdateTimer > int(self.__cloudDict["UPDATE_CYCLE_TIME"]["ROBOT_STATE"]):
                    if self.__robotStatus["backend"]["stateCode"] != 0:
                        if self.__robotApiControl.patch_robot(self.__robotStatus["backend"]) != 0:
                            print(datetime.now())
                        else:
                            self.__uiStatus["stateCode"] = self.__robotStatus["backend"]["stateCode"]
                            self.__uiStatus["subStateCode"] = self.__robotStatus["backend"]["subStateCode"]
                    _dataUpdateTimer = _now
                if _now - _realtimeInformationUpdateTimer > int(self.__cloudDict["UPDATE_CYCLE_TIME"]["REALTIME"]):
                    _realtimeInformationUpdateTimer = _now
                    self.__mqttController.client.publish(self.__cloudDict["ROBOT_ID"]+"/realtime/robot_information", json.dumps(JSONStream.format_json(self.__robotStatus["frontend"])))
                if self.__uiCommand["errorCode"] == 8003:
                    if self.__emergencyFlag:
                        if _now - _emergencyTimer > 3:
                            self.__uiCommand["errorCode"] = 0
                            self.__emergencyFlag = False
                    else:
                        _emergencyTimer = _now
                        self.__emergencyFlag = True
            except requests.exceptions.RequestException as _requestException:
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Network is unreachable\r", RobotConfig.LogType.ERROR.value))
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_requestException) + "\r", RobotConfig.LogType.ERROR.value))
                _dataUpdateTimer = _now
                _realtimeInformationUpdateTimer = _now
            except Exception as _exception:
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_exception) + "\r", RobotConfig.LogType.ERROR.value))
            if(len(self.__mqttController.get_log_data_list()) > 0):
                self.__logDataList.extend(self.__mqttController.get_log_data_list())
                self.__mqttController.clear_log_data_list()
            if(len(self.__robotApiControl.get_log_data_list()) > 0):
                self.__logDataList.extend(self.__robotApiControl.get_log_data_list())
                self.__robotApiControl.clear_log_data_list()
            if(len(self.__logDataList) > 0):
                _logFileName = "WebClient_"+str(datetime.now().strftime("%Y-%m-%d_%H")) + ".txt"
                _logFileName = join(logPath, _logFileName)
                Stream.save_log_list(_logFileName, self.__logDataList)

    def stop(self) -> None:
        self.finished.set()
        time.sleep(1)
        self.__logDataList.append(Stream.print_log("[Web Communication INFO] Stop Web Client\r", RobotConfig.LogType.INFO.value))
        _logFileName = "WebClient_"+str(datetime.now().strftime("%Y-%m-%d_%H")) + ".txt"
        _logFileName = join(logPath, _logFileName)
        Stream.save_log_list(_logFileName, self.__logDataList)
