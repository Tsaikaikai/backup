import time
import os
import sys
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = "../config/"
else:
    sys.path.append("..")
    configPath = "../../config/"
from web_communication import APIControl
from utility import Stream


def delete_robot() -> bool:
    global configPath
    _result = False
    input("Keyin Robot ID and Password, Press Enter to Continue")
    _robotType = Stream.load_config(os.path.join(configPath, "MainSetting.yaml"))["ROBOT_TYPE"]
    configPath = os.path.join(configPath, _robotType)
    _config = Stream.load_config(os.path.join(configPath, "CloudSetting.yaml"))
    _existRobotID = input("Exist Robot ID: ")
    _existRobotPassword = input("Exist Robot Password: ")
    _robotApiControl = APIControl.RobotAPIControl({"SERVER_URL": _config["SERVER_URL"], "SERVER_PORT": _config["SERVER_PORT"], "ROBOT_ID": _existRobotID}, "http")

    if _robotApiControl.delete_robot(_existRobotID, _existRobotPassword) == 200:
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        _result = True
    else:
        print('\033[1;31m%s\033[0m\r' % ("FAIL"))
    print("=====================================")
    return _result


if __name__ == "__main__":
    delete_robot()
