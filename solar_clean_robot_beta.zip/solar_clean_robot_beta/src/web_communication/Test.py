import time
import sys
import os

if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    configPath = '../config'
else:
    configPath = '../../config'
    sys.path.append("..")
from utility import RobotConfig
from web_communication import WebClient, UIConfig

robotID = "ADT_SC002"


robotData = RobotConfig.RobotData().data
uiStatus = UIConfig.UIStatus().data

finishFlag = False
returnCount = 0

_updateFinish = False
_returnCounter = 0


def robot_simulator(_robotData) -> dict():
    global _updateFinish, _returnCounter
    if _robotData["uiCommand"]["navFlag"] == True:
        if _updateFinish == False:
            _updateFinish = True
            _robotData["navigation"]["cleanCountNow"] = 0
        if _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.LEFT_TOP_NAVIGATION.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value
        elif _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RIGHT_TOP_NAVIGATION.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value
        elif _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.RETURN.value
        _robotData["main"]["errorCode"] = [0]
    elif _robotData["uiCommand"]["navFlag"] == False:
        if _robotData["navigation"]["robotState"] == RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value or _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value or _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RETURN.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
            _robotData["main"]["errorCode"] = [0]

    if _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RETURN.value:
        _returnCounter += 1
    else:
        _returnCounter = 0

    if _returnCounter >= 10:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        _robotData["main"]["errorCode"] = [0]
    if _robotData["navigation"]["robotState"] == RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value or _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value:
        _robotData["navigation"]["cleanCountNow"] += 1
    else:
        _robotData["navigation"]["cleanCountNow"] = 0

    if _robotData["navigation"]["cleanCountNow"] >= _robotData["uiCommand"]["navSetting"]["cleanCount"]:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        _robotData["main"]["errorCode"] = [0]
        _updateFinish = False

    _robotData["main"]["errorCode"] = [_robotData["uiCommand"]["errorCode"]]
    if _robotData["uiCommand"]["errorCode"] != 0:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
    elif _robotData["uiCommand"]["errorCode"] == 0 and _robotData["navigation"]["robotState"] == RobotConfig.RobotState.ABNORMAL.value:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value

    _robotData["battery"]["SOC"] -= 1
    _robotData["recorder"]["cleanDistanceNow"] += 1
    _robotData["recorder"]["cleanDistanceTotal"] += 1
    _robotData["recorder"]["cleanTimeNow"] += 1
    _robotData["recorder"]["cleanTimeTotal"] += 1

    _robotData["recorder"]["pedrailRemainTime"] -= 1
    _robotData["recorder"]["brushRemainTime"] -= 1
    _robotData["imu"]["euler"][1] += 1
    return _robotData


def main():
    global robotData
    # Web API Client
    _webClient = WebClient.WebClient("Beta_3_1")
    _webClient.start()

    robotData["imu"]["euler"][1] = 0.0
    robotData["imu"]["connect"] = True
    robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
    # robotData["navigation"]["robotState"] = RobotState.LEFT_TOP_NAVIGATION.value
    robotData["main"]["errorCode"] = [0]
    robotData["battery"]["SOC"] = 100
    robotData["boardMaster"]["connect"] = True
    robotData["driveMotor"]["connect"] = True
    robotData["recorder"]["robotID"] = robotID
    robotData["recorder"]["cleanDistanceNow"] = 0
    robotData["recorder"]["cleanDistanceTotal"] = 100
    robotData["recorder"]["cleanTimeNow"] = 0
    robotData["recorder"]["cleanTimeTotal"] = 150
    robotData["recorder"]["cleanCountNow"] = 0
    robotData["recorder"]["pedrailRemainTime"] = 500
    robotData["recorder"]["brushRemainTime"] = 500

    # Data Recorder
    # _dataRecorder = DataRecorder("Beta_3_1")
    # _dataRecorder.start()
    # _timeZone = timezone(timedelta(hours=-8))
    # _timeStamp = datetime.now(_timeZone).isoformat(timespec="seconds")
    # _serialNumber = "sr001$"+_timeStamp
    _taskLog = {"taskLog": {"stateCode": 5, "subStateCode": 0, "cleanCountNow": 2, "direction": 1, "cleanTimeNow": 1.5, "cleanSpeed": 0.4, "cleanDistanceNow": 40, "batteryNowUsed": 2}}
    try:
        time.sleep(3)
        while(1):
            time.sleep(1)

            # _webClient.set_echo_message(_robotState)
            # print(_webClient.get_location())

            robotData.update(_webClient.get_button_status())
            # _buttonStatus.update(_taskLog)

            robotData = robot_simulator(robotData)
            # print(robotData)
            _webClient.set_robot_status(robotData)

            # _dataRecorder.set_task_log(_buttonStatus)

            # _taskLog = _dataRecorder.get_task_log()
            # print(_taskLog)
    except KeyboardInterrupt:
        _webClient.stop()
        # _mqttClient.stop()
        # _dataRecorder.stop()
        print("Test.py shutdown")


if __name__ == "__main__":
    main()
