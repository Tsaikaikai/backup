import os
import sys
import time
from datetime import datetime, timedelta, timezone
import json
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../..")
from utility import RobotConfig
from web_communication.unit_test import RobotSimulator


class RobotSetting():

    def __init__(self, _config, _uiStatus, _robotData) -> None:
        self.__config = _config
        self.__robotData = _robotData
        self.__uiStatus = _uiStatus

    def auto_clean_test(self, _webClient, _mqttClient):
        try:
            self.TC_Robot_010(_webClient, _mqttClient)
            self.TC_Robot_011(_webClient, _mqttClient)
            self.TC_Robot_012(_webClient, _mqttClient)
            self.TC_Robot_013(_webClient, _mqttClient)
            print('\033[1;32m%s\033[0m\r' % ("Auto Clean Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("Auto Clean Test Fail"))

    def stop_clean_test(self, _webClient, _mqttClient):
        try:
            self.TC_Robot_014(_webClient, _mqttClient)
            self.TC_Robot_015(_webClient, _mqttClient)
            print('\033[1;32m%s\033[0m\r' % ("Stop Clean Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("Stop Clean Test Fail"))

    def robot_information(self, _webClient):
        try:
            self.TC_Robot_016(_webClient)
            self.TC_Robot_017(_webClient)
            self.TC_Robot_018(_webClient)
            self.TC_Robot_019(_webClient)
            self.TC_Robot_020(_webClient)
            print('\033[1;32m%s\033[0m\r' % ("Robot Information Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("Robot Information Test Fail"))

    def TC_Robot_010(self, _webClient, _mqttClient):
        print("TC-Robot-010")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            _uiStatus = _webClient.get_ui_status()
            if _uiStatus["stateCode"] == RobotConfig.UIRobotState.STANDBY.value and _uiStatus["subStateCode"] == 1009:
                self.__robotData["navigation"]["robotState"] = _webClient.ui_robot_state_to_robot_state(_uiStatus["stateCode"])
                self.__robotData["main"]["errorCode"][0] = _uiStatus["subStateCode"]
                _webClient.set_robot_status(self.__robotData)
                break
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$20231010T08:00:00+00:00", "clean_command": 1, "timeout": "2023-10-10T08:00:08+00:00"}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))

        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(3)

    def TC_Robot_011(self, _webClient, _mqttClient):
        print("TC-Robot-011")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            if self.__robotData["uiCommand"]["navFlag"] == True:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
                self.__robotData["main"]["errorCode"] = [1001]
                _webClient.set_robot_status(self.__robotData)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 1, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))

        time.sleep(1)
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_012(self, _webClient, _mqttClient):
        print("TC-Robot-012")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        time.sleep(1)
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            _webClient.set_robot_status(self.__robotData)
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=1)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 1, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
            time.sleep(1)

            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.STANDBY.value and self.__uiStatus["subStateCode"] == 0:
                break
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_013(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-013")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            _webClient.set_robot_status(self.__robotData)
            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.NAVIGATION.value and self.__uiStatus["subStateCode"] == 0:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value
                self.__robotData["main"]["errorCode"] = [0]
                _webClient.set_robot_status(self.__robotData)
                time.sleep(1)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 1, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))

        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_014(self, _webClient, _mqttClient):
        print("TC-Robot-014")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        time.sleep(1)
        now = datetime.now(timezone.utc)
        timeout = now + timedelta(seconds=8)
        _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 1, "timeout": timeout.isoformat(timespec="seconds")}
        _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
        self.__robotData["uiCommand"].update(_webClient.get_button_status())
        self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
        _webClient.set_robot_status(self.__robotData)
        time.sleep(1)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            if self.__robotData["uiCommand"]["navFlag"] == False:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
                self.__robotData["main"]["errorCode"] = [1001]
                _webClient.set_robot_status(self.__robotData)
            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.ABNORMAL.value and self.__uiStatus["subStateCode"] == 1001:
                _webClient.set_robot_status(self.__robotData)
                time.sleep(1)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 0, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))

        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_015(self, _webClient, _mqttClient):
        print("TC-Robot-015")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData.update(_webClient.get_button_status())
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            if self.__robotData["uiCommand"]["navFlag"] == False:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
                self.__robotData["main"]["errorCode"] = [0]
                _webClient.set_robot_status(self.__robotData)
                time.sleep(3)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 0, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_016(self, _webClient):
        print("TC-Robot-016")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
        self.__robotData["main"]["errorCode"] = [1001]
        _webClient.set_robot_status(self.__robotData)
        time.sleep(5)
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_017(self, _webClient):
        print("TC-Robot-017")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        self.__robotData["imu"]["euler"][1] = 0.0
        self.__robotData["imu"]["connect"] = True
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["imu"]["euler"][1] += 0.5
            _webClient.set_robot_status(self.__robotData)
            if self.__robotData["imu"]["euler"][1] == 10:
                break
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_018(self, _webClient):
        print("TC-Robot-018")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
        self.__robotData["main"]["errorCode"] = [4002]
        self.__robotData["battery"]["SOC"] = 20
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["battery"]["SOC"] -= 1
            _webClient.set_robot_status(self.__robotData)
            if self.__robotData["battery"]["SOC"] == 10:
                break
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_019(self, _webClient):
        print("TC-Robot-019")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["noExistRobotID"]})
        self.__robotData["recorder"]["robotID"] = self.__config["noExistRobotID"]
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        self.__robotData["battery"]["SOC"] = 80
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData.update(_webClient.get_button_status())
            _uiStatus = _webClient.get_ui_status()
            if _uiStatus["subStateCode"] == 1007:
                break
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_020(self, _webClient):
        _webClient.initial_parameter()
        print("TC-Robot-020")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["recorder"]["robotID"] = self.__config["existRobotID"]
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        time.sleep(1)
        self.__robotData.update(_webClient.get_button_status())
        _uiStatus = _webClient.get_ui_status()
        time.sleep(1)
        if _uiStatus["subStateCode"] == 0:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)
