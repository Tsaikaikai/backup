import time
import os
import sys
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../../")
from utility import RobotConfig
from web_communication import WebClient, APIControl, UIConfig
from web_communication.unit_test import RobotList, RobotSetting, ManualMode, UpdateRobotLog, UserSetting
import paho.mqtt.client

config = {
    "existRobotID": "ADT_SC002",
    "existRobotPassword": "Auo@84149738",
    "newRobotID": "ADT_SC030",
    "newRobotPassword": "Auo@84149738",
    "noExistRobotID": "sr999",
    "serverPort": 37460,
    "serverUrl": "4.193.214.60",
    "mqttUrl": "4.193.214.60",
    "mqttPort": 1883,
    "mqttUser": "auo8",
    "mqttPassword": "auo84149738",
    "softwareVersion": 0x100,
    "firmwareVersion": 0x320}


# _webClient = WebClient("Beta_3_1")
_robotApiControl = APIControl.RobotAPIControl({"SERVER_URL": config["serverUrl"], "SERVER_PORT": config["serverPort"], "ROBOT_ID": config["existRobotID"]}, "http")
robotStatus = UIConfig.RobotStatus().data
robotStatus["frontend"]["imu"]["pitch"] = 0.0
robotStatus["backend"]["robotID"] = config["existRobotID"]
robotStatus["backend"]["stateCode"] = 5
robotStatus["backend"]["subStateCode"] = 0
robotStatus["backend"]["battery"] = 100
robotStatus["backend"]["batteryNowUsed"] = 0
robotStatus["backend"]["cleanDistanceNow"] = 0
robotStatus["backend"]["cleanDistanceTotal"] = 100
robotStatus["backend"]["cleanTimeNow"] = 0
robotStatus["backend"]["cleanTimeTotal"] = 150
robotStatus["backend"]["cleanCountNow"] = 1
robotStatus["backend"]["pedrailRemainTime"] = 500
robotStatus["backend"]["brushRemainTime"] = 500
robotStatus["backend"]["internetState"] = "4G Good"
robotStatus["backend"]["robotID"] = config["existRobotID"]
robotStatus["taskLog"]["cleanSerialNumber"] = config["existRobotID"] + "$2023-10-10T08:00:00+00:00"
robotStatus["taskLog"]["stateCode"] = 5
robotStatus["taskLog"]["subStateCode"] = 0
robotStatus["taskLog"]["cleanCountNow"] = 0
robotStatus["taskLog"]["direction"] = 0
robotStatus["taskLog"]["cleanTimeNow"] = 0
robotStatus["taskLog"]["cleanSpeed"] = 0.4
robotStatus["taskLog"]["cleanDistanceNow"] = 50
robotStatus["taskLog"]["batteryNowUsed"] = 5
robotStatus["taskLog"]["cleanEndTime"] = config["existRobotID"] + "$2023-10-10T08:05:00+00:00"
uiStatus = UIConfig.UIStatus().data
robotData = RobotConfig.RobotData().data
robotData["recorder"]["robotID"] = config["existRobotID"]

time.sleep(1)


def main():
    global config
    global robotStatus
    global robotData
    global uiStatus
    try:
        _mqttClient = paho.mqtt.client.Client(client_id="test")
        _mqttClient.username_pw_set(config["mqttUser"], config["mqttPassword"])

        _mqttClient.connect(config["mqttUrl"], config["mqttPort"], 60)
        time.sleep(1)
        _mqttClient.loop_start()

        _webClient = WebClient.WebClient("Beta_3_1")
        _webClient.start()
        time.sleep(1)
        _webClient.set_cloud_parameter({"ROBOT_ID": config["existRobotID"]})

        robotData["main"]["softwareVersion"] = config["softwareVersion"]
        robotData["boardMaster"]["firmwareVersion"] = config["firmwareVersion"]
        _webClient.set_robot_status(robotData)
        time.sleep(1)
        print("UI Test Start")

        # Robot List Test
        _robotListTest = RobotList.RobotList(config, robotStatus)
        _robotListTest.add_robot_test()
        _robotListTest.patch_robot_test()
        _robotListTest.delete_robot_test()

        # Robot Setting Test
        _robotSettingTest = RobotSetting.RobotSetting(config, uiStatus, robotData)
        _robotSettingTest.auto_clean_test(_webClient, _mqttClient)
        _robotSettingTest.stop_clean_test(_webClient, _mqttClient)
        _robotSettingTest.robot_information(_webClient)

        # Manual Mode Test
        _manualModeTest = ManualMode.ManualMode(config, uiStatus, robotData)
        _manualModeTest.manual_mode_test(_webClient, _mqttClient)
        _manualModeTest.manual_return_test(_webClient, _mqttClient)

        # Update Robot Log
        _updateRobotLogTest = UpdateRobotLog.UpdateRobotLog(config, robotStatus)
        _updateRobotLogTest.update_robot_abnormal_log()
        _updateRobotLogTest.update_robot_log()

        # User Setting Test
        _userSettingTest = UserSetting.UserSetting(_webClient, config, robotStatus)
        _userSettingTest.update_robot_version()

        _webClient.stop()
        _mqttClient.loop_stop()
        print("UI Test End")
    except KeyboardInterrupt:
        print("Test.py shutdown")
        _webClient.stop()
        _mqttClient.loop_stop()


if __name__ == "__main__":
    main()
