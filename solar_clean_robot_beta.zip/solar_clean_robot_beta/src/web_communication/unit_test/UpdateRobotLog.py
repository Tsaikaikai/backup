import os
import sys
import time
from datetime import datetime, timezone
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../..")
from web_communication import APIControl


class UpdateRobotLog():

    def __init__(self, _config, _robotStatus) -> None:
        self.__config = _config
        self.__robotStatus = _robotStatus
        self.__robotApiControl = APIControl.RobotAPIControl({"SERVER_URL": self.__config["serverUrl"], "SERVER_PORT": self.__config["serverPort"], "ROBOT_ID": self.__config["existRobotID"]}, "http")

    def update_robot_abnormal_log(self):
        try:
            self.TC_Robot_028()
            self.TC_Robot_029()
            self.TC_Robot_030()
            self.TC_Robot_031()
            print('\033[1;32m%s\033[0m\r' % ("Update Robot Abnormal Log Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("pdate Robot Abnormal Log Test Fail"))

    def update_robot_log(self):
        try:
            self.TC_Robot_032()
            self.TC_Robot_033()
            print('\033[1;32m%s\033[0m\r' % ("Update Robot Log Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("pdate Robot Log Test Fail"))

    def TC_Robot_028(self):
        print("TC-Robot-028")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["noExistRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["noExistRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 1
        self.__robotStatus["taskLog"]["subStateCode"] = 4002
        if self.__robotApiControl.put_robot_abnormal_log(self.__robotStatus["taskLog"])["status_code"] == 404:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_029(self):
        print("TC-Robot-029")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["existRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 1
        self.__robotStatus["taskLog"]["subStateCode"] = 0
        if self.__robotApiControl.put_robot_abnormal_log(self.__robotStatus["taskLog"])["status_code"] == 400:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_030(self):
        print("TC-Robot-030")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["existRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 1
        self.__robotStatus["taskLog"]["subStateCode"] = 4002
        if self.__robotApiControl.put_robot_abnormal_log(self.__robotStatus["taskLog"])["status_code"] == 200:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_031(self):
        print("TC-Robot-031")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["existRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 1
        self.__robotStatus["taskLog"]["subStateCode"] = 4002
        if self.__robotApiControl.put_robot_abnormal_log(self.__robotStatus["taskLog"])["status_code"] == 400:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_032(self):
        print("TC-Robot-032")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["noExistRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["noExistRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 5
        self.__robotStatus["taskLog"]["subStateCode"] = 0
        self.__robotStatus["taskLog"]["cleanCountNow"] = 3
        self.__robotStatus["taskLog"]["direction"] = 1
        self.__robotStatus["taskLog"]["cleanTimeNow"] = 6
        self.__robotStatus["taskLog"]["cleanSpeed"] = 0.4
        self.__robotStatus["taskLog"]["cleanDistanceNow"] = 60
        self.__robotStatus["taskLog"]["batteryNowUsed"] = 6
        self.__robotStatus["taskLog"]["cleanEndTime"] = now.isoformat(timespec="seconds")
        if self.__robotApiControl.put_robot_log(self.__robotStatus["taskLog"])["status_code"] == 404:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_033(self):
        print("TC-Robot-033")
        now = datetime.now(timezone.utc)
        self.__robotStatus["taskLog"]["robotID"] = self.__config["existRobotID"]
        self.__robotStatus["taskLog"]["cleanSerialNumber"] = self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds")
        self.__robotStatus["taskLog"]["stateCode"] = 5
        self.__robotStatus["taskLog"]["subStateCode"] = 0
        self.__robotStatus["taskLog"]["cleanCountNow"] = 3
        self.__robotStatus["taskLog"]["direction"] = 1
        self.__robotStatus["taskLog"]["cleanTimeNow"] = 6
        self.__robotStatus["taskLog"]["cleanSpeed"] = 0.4
        self.__robotStatus["taskLog"]["cleanDistanceNow"] = 60
        self.__robotStatus["taskLog"]["batteryNowUsed"] = 6
        self.__robotStatus["taskLog"]["cleanEndTime"] = now.isoformat(timespec="seconds")
        if self.__robotApiControl.put_robot_log(self.__robotStatus["taskLog"])["status_code"] == 200:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)
