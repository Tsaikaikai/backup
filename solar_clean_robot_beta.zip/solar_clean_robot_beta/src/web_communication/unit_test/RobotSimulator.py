import os
import sys
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../..")
from utility import RobotConfig


def robot_simulator(_robotData) -> dict():
    if _robotData["uiCommand"]["navFlag"] == True:
        if _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.LEFT_TOP_NAVIGATION.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value
        elif _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RIGHT_TOP_NAVIGATION.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value
        elif _robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.RETURN.value
        _robotData["main"]["errorCode"] = [0]
    elif _robotData["uiCommand"]["navFlag"] == False:
        if _robotData["navigation"]["robotState"] == RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value or _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RIGHT_TOP_NAVIGATION.value or _robotData["navigation"]["robotState"] == RobotConfig.RobotState.RETURN.value:
            _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
            _robotData["main"]["errorCode"] = [0]

    if _robotData["navigation"]["robotState"] == RobotConfig.RobotState.LEFT_TOP_NAVIGATION.value:
        _robotData["navigation"]["cleanCountNow"] += 0.1
    else:
        _robotData["navigation"]["cleanCountNow"] = 0

    if _robotData["navigation"]["cleanCountNow"] >= _robotData["uiCommand"]["navSetting"]["cleanCount"]:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        _robotData["main"]["errorCode"] = [0]
        _robotData["navigation"]["cleanCountNow"] = 0

    _robotData["main"]["errorCode"] = [_robotData["uiCommand"]["errorCode"]]
    if _robotData["uiCommand"]["errorCode"] != 0:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
    elif _robotData["uiCommand"]["errorCode"] == 0 and _robotData["navigation"]["robotState"] == RobotConfig.RobotState.ABNORMAL.value:
        _robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value

    _robotData["battery"]["SOC"] -= 1
    _robotData["recorder"]["cleanDistanceNow"] += 1
    _robotData["recorder"]["cleanDistanceTotal"] += 1
    _robotData["recorder"]["cleanTimeNow"] += 1
    _robotData["recorder"]["cleanTimeTotal"] += 1

    _robotData["recorder"]["pedrailRemainTime"] -= 1
    _robotData["recorder"]["brushRemainTime"] -= 1
    _robotData["imu"]["euler"][1] += 1
    return _robotData
