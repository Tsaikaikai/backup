import time
import os
import sys
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../..")
from web_communication import APIControl


class RobotList():

    def __init__(self, _config, _robotStatus) -> None:
        self.__config = _config
        self.__robotStatus = _robotStatus
        self.__robotApiControl = APIControl.RobotAPIControl({"SERVER_URL": self.__config["serverUrl"], "SERVER_PORT": self.__config["serverPort"], "ROBOT_ID": self.__config["existRobotID"]}, "http")

    def add_robot_test(self):
        self.TC_Robot_001()
        self.TC_Robot_002()
        self.TC_Robot_003()

    def patch_robot_test(self):
        self.TC_Robot_004()
        self.TC_Robot_005()
        self.TC_Robot_006()

    def delete_robot_test(self):
        self.TC_Robot_007()
        self.TC_Robot_008()
        self.TC_Robot_009()

    def TC_Robot_001(self):
        print("TC-Robot-001")
        if self.__robotApiControl.add_robot(self.__config["newRobotID"], self.__config["newRobotPassword"], 60) == 200:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_002(self):
        print("TC-Robot-002")
        if self.__robotApiControl.add_robot(self.__config["newRobotID"], self.__config["newRobotPassword"], 60) == 409:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_003(self):
        print("Disconnect Internet and Press Enter to Continue")
        input("Press Enter to continue.")
        print("TC-Robot-003")
        if self.__robotApiControl.add_robot(self.__config["existRobotID"], self.__config["existRobotPassword"], 60) == 3:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        print("Connect Internet and Press Enter to Continue")
        input("Press Enter to continue.")
        time.sleep(1)

    def TC_Robot_004(self):
        print("TC-Robot-004")
        self.__robotStatus["backend"]["robotID"] = self.__config["existRobotID"]
        if self.__robotApiControl.patch_robot(self.__robotStatus["backend"])["status_code"] == 200:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_005(self):
        print("TC-Robot-005")
        self.__robotStatus["backend"]["robotID"] = self.__config["noExistRobotID"]
        if self.__robotApiControl.patch_robot(self.__robotStatus["backend"])["status_code"] == 404:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_006(self):
        print("TC-Robot-006")
        self.__robotStatus["backend"]["robotID"] = self.__config["existRobotID"]
        self.__robotStatus["backend"]["subStateCode"] = 9999
        if self.__robotApiControl.patch_robot(self.__robotStatus["backend"])["status_code"] == 404:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_007(self):
        print("TC-Robot-007")
        if self.__robotApiControl.delete_robot(self.__config["newRobotID"], "12345") == 400:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_008(self):
        print("TC-Robot-008")
        if self.__robotApiControl.delete_robot(self.__config["newRobotID"], self.__config["newRobotPassword"]) == 200:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_009(self):
        print("TC-Robot-009")
        if self.__robotApiControl.delete_robot(self.__config["newRobotID"], self.__config["newRobotPassword"]) == 404:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)
