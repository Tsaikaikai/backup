import os
import sys
import time
from datetime import datetime, timedelta, timezone
import json
if os.path.isfile("main.py") or os.path.isfile("main.bin"):
    pass
else:
    sys.path.append("../..")
from utility import RobotConfig
from web_communication.unit_test import RobotSimulator


class ManualMode():

    def __init__(self, _config, _uiStatus, _robotData) -> None:
        self.__config = _config
        self.__robotData = _robotData
        self.__uiStatus = _uiStatus

    def manual_mode_test(self, _webClient, _mqttClient):
        try:
            self.TC_Robot_021(_webClient, _mqttClient)
            self.TC_Robot_022(_webClient, _mqttClient)
            self.TC_Robot_023(_webClient, _mqttClient)
            print('\033[1;32m%s\033[0m\r' % ("Manual Mode Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("Manual Mode Test Fail"))

    def manual_return_test(self, _webClient, _mqttClient):
        try:
            self.TC_Robot_024(_webClient, _mqttClient)
            self.TC_Robot_025(_webClient, _mqttClient)
            self.TC_Robot_026(_webClient, _mqttClient)
            self.TC_Robot_027(_webClient, _mqttClient)
            print('\033[1;32m%s\033[0m\r' % ("Manual Return Test Pass"))
        except KeyboardInterrupt:
            print('\033[1;31m%s\033[0m\r' % ("Manual Return Test Fail"))

    def TC_Robot_021(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-021")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        self.__robotData["boardMaster"]["connect"] = True
        _webClient.set_robot_status(self.__robotData)
        while 1:
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            if self.__robotData["uiCommand"]["beeperFlag"] == True:
                _webClient.set_robot_status(self.__robotData)
                break
            _webClient.set_robot_status(self.__robotData)
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 5, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
            time.sleep(1)
        if self.__robotData["uiCommand"]["beeperFlag"] == True:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(2)

    def TC_Robot_022(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-022")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        self.__robotData["driveMotor"]["velocity"] = [0.0, 0.0]
        self.__robotData["driveMotor"]["connect"] = True
        _webClient.set_robot_status(self.__robotData)
        while 1:
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            if self.__robotData["uiCommand"]["controlVelocity"] == [0.2, 0.0]:
                self.__robotData["driveMotor"]["velocity"] = [0.2, 0.0]
                _webClient.set_robot_status(self.__robotData)
                break
            _webClient.set_robot_status(self.__robotData)
            _jsonTemp = {"control_velocity": [0.2, 0.0]}
            _mqttClient.publish(self.__config["existRobotID"]+"/control_velocity/robot_control", json.dumps(_jsonTemp))
            time.sleep(1)
        time.sleep(1)
        if self.__robotData["driveMotor"]["errorCode"] == 0:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_023(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-023")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        self.__robotData["boardMaster"]["connect"] = True
        _webClient.set_robot_status(self.__robotData)
        while 1:
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__robotData = RobotSimulator.robot_simulator(self.__robotData)
            if self.__robotData["uiCommand"]["cleanMotorFlag"] == True:
                _webClient.set_robot_status(self.__robotData)
                break
            _webClient.set_robot_status(self.__robotData)
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 7, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
            time.sleep(1)
        time.sleep(1)
        if self.__robotData["uiCommand"]["cleanMotorFlag"] == True:
            print('\033[1;32m%s\033[0m\r' % ("PASS"))
        else:
            print('\033[1;31m%s\033[0m\r' % ("FAIL"))
        print("=====================================")
        time.sleep(1)

    def TC_Robot_024(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-024")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            if self.__robotData["uiCommand"]["navFlag"] == True and self.__robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
                self.__robotData["main"]["errorCode"] = [4001]
                _webClient.set_robot_status(self.__robotData)
            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.STANDBY.value and self.__uiStatus["subStateCode"] == 1008:
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 3, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
            _webClient.set_robot_status(self.__robotData)
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(3)

    def TC_Robot_025(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-025")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            if self.__robotData["uiCommand"]["navFlag"] == True and self.__robotData["uiCommand"]["navSetting"]["cleanMode"] == RobotConfig.CleanMode.RETURN.value:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.RETURN.value
                self.__robotData["main"]["errorCode"] = [0]
                _webClient.set_robot_status(self.__robotData)
                time.sleep(3)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 3, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(3)

    def TC_Robot_026(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-026")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.RETURN.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            if self.__robotData["uiCommand"]["navFlag"] == False:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.ABNORMAL.value
                self.__robotData["main"]["errorCode"] = [4001]
                _webClient.set_robot_status(self.__robotData)
                time.sleep(1)
            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.STANDBY.value and self.__uiStatus["subStateCode"] == 1008:
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 2, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(3)

    def TC_Robot_027(self, _webClient, _mqttClient):
        _webClient.initial_parameter()
        print("TC-Robot-027")
        _webClient.set_cloud_parameter({"ROBOT_ID": self.__config["existRobotID"]})
        self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.RETURN.value
        self.__robotData["main"]["errorCode"] = [0]
        _webClient.set_robot_status(self.__robotData)
        while True:
            time.sleep(1)
            self.__robotData["uiCommand"].update(_webClient.get_button_status())
            self.__uiStatus = _webClient.get_ui_status()
            if self.__robotData["uiCommand"]["navFlag"] == False:
                self.__robotData["navigation"]["robotState"] = RobotConfig.RobotState.REMOTE.value
                self.__robotData["main"]["errorCode"] = [0]
                _webClient.set_robot_status(self.__robotData)
            if self.__uiStatus["stateCode"] == RobotConfig.UIRobotState.STANDBY.value and self.__uiStatus["subStateCode"] == 0:
                time.sleep(1)
                break
            now = datetime.now(timezone.utc)
            timeout = now + timedelta(seconds=8)
            _jsonTemp = {"clean_serial_number": self.__config["existRobotID"] + "$" + now.isoformat(timespec="seconds"), "clean_command": 2, "timeout": timeout.isoformat(timespec="seconds")}
            _mqttClient.publish(self.__config["existRobotID"]+"/data", json.dumps(_jsonTemp))
        print('\033[1;32m%s\033[0m\r' % ("PASS"))
        print("=====================================")
        time.sleep(3)
