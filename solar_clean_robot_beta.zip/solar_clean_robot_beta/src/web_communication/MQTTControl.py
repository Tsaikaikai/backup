from os.path import isfile
import sys
import paho.mqtt.client
import json


if isfile("./main.py") or isfile("./main.bin"):
    logPath = "../log/"

else:
    logPath = "../../log/"
    sys.path.append("..")
from utility import JSONStream, Stream, RobotConfig


class MQTTController():
    def __init__(self, _ip="localhost", _port=1883, _userName="", _password="", _robotID="", _qos=0) -> None:

        self.client = paho.mqtt.client.Client(client_id=_robotID)
        self.client.username_pw_set(_userName, _password)
        self.client.on_connect = self.on_connect
        self.client.on_publish = self.on_publish
        self.client.on_message = self.on_message

        self.__ip = _ip
        self.__port = _port
        self.__robotID = _robotID
        self.__qos = _qos

        self.__receivedJsonDict = dict()
        self.__receivedJsonDict[_robotID+"/data"] = ""
        self.__receivedJsonDict[_robotID+"/control_velocity/robot_control"] = [0.0, 0.0]
        self.__receivedFlag = dict()
        self.__receivedFlag[_robotID+"/data"] = False
        self.__receivedFlag[_robotID+"/control_velocity/robot_control"] = False
        self.__transmitJsonDict = dict()

        self.client.connect(host=self.__ip, port=self.__port, keepalive=60)

        self.__logDataList = []

    def get_log_data_list(self) -> list:
        return self.__logDataList

    def clear_log_data_list(self) -> None:
        self.__logDataList = []

    def on_connect(self, client, userdata, flags, rc) -> None:
        if rc == 0:
            self.__logDataList.append(Stream.print_log("Connected to MQTT broker\r", RobotConfig.LogType.INFO))

            client.subscribe(self.__robotID+"/data", qos=self.__qos)
            client.subscribe(self.__robotID+"/control_velocity/robot_control", qos=self.__qos)
        else:
            self.__logDataList.append(Stream.print_log("Connection failed. Return code: " + str(rc)+"\r", RobotConfig.LogType.ERROR))

    def on_publish(self, client, userdata, mid) -> None:
        self.__logDataList.append(Stream.print_log("Message published with ID: " + str(mid)+", Client: "+str(client)+", Data: "+str(userdata)+"\r", RobotConfig.LogType.INFO))

    def available(self, _topicName) -> bool:
        if _topicName in self.__receivedFlag:
            return self.__receivedFlag[_topicName]
        else:
            return False

    def on_message(self, updata, client, msg) -> None:
        try:
            self.__logDataList.append(Stream.print_log("MQTT Subscribe \nTopic: " + msg.topic + ", \nMsg:" + str(msg.payload)+"\r", RobotConfig.LogType.INFO))
            _receivedJson = msg.payload.decode('utf-8')
            self.__receivedJsonDict[msg.topic] = json.loads(_receivedJson)
            self.__receivedFlag[msg.topic] = True

        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' % ('[Web Communication ERROR] ' + str(_exception)))

    def get_info(self, _topicName) -> dict:
        self.__receivedFlag[_topicName] = False
        if self.__receivedJsonDict[_topicName] == dict():
            return None
        else:
            return self.__receivedJsonDict[_topicName]

    def clear_info(self) -> None:
        self.__receivedJsonDict = dict()

    def on_disconnect(self, client, userdata, rc) -> None:
        if rc != 0:
            self.__logDataList.append(Stream.print_log("Disconnected from MQTT broker. Return code: " + str(rc)+"\r", RobotConfig.LogType.ERROR))
            self.__logDataList.append(Stream.print_log("Attempting to reconnect...\r", RobotConfig.LogType.INFO))
        else:
            self.__logDataList.append(Stream.print_log("Disconnected from MQTT broker. Return code: " + str(rc)+"\r", RobotConfig.LogType.INFO))
            print("Disconnect from MQTT broker")

    def set_dict_info(self, _transmitMsg, _updateFlag) -> bool:
        self.__update = True
        if _updateFlag:
            self.__transmitJsonDict.update(JSONStream.format_json(_transmitMsg))
        else:
            self.__transmitJsonDict = JSONStream.format_json(_transmitMsg)
        return True

    def clear_info(self) -> None:
        self.__transmitJsonDict = dict()
