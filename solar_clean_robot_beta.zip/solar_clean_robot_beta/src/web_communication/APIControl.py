import requests
import time

# pip3 uninstall crypto
# pip3 uninstall pycrypto
# pip3 install pycryptodome
from os.path import isfile
import sys
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
import base64

if isfile("./main.py") or isfile("./main.bin"):
    logPath = "../log/"
else:
    logPath = "../../log/"
    sys.path.append("..")

from utility import Stream, RobotConfig


class RobotAPIControl():
    def __init__(self, _yamlDict, _protocol="https") -> None:
        self.__serverUrl = _protocol+"://" + _yamlDict['SERVER_URL']+":"+str(_yamlDict['SERVER_PORT'])
        self.__logDataList = []

    def get_log_data_list(self) -> list:
        return self.__logDataList

    def clear_log_data_list(self) -> None:
        self.__logDataList = []

    def __get_rsa_publisc_key(self) -> str:
        try:
            _headers = {'accept': 'application/json', 'X-CSRFToken': ''}
            _response = requests.get(self.__serverUrl + "/api/generate_rsa_public_key/", headers=_headers)
            if _response.status_code == 200:
                return _response.json()['public_key']
            else:
                return _response.json()
        except Exception as _exception:
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_exception)+"\r", RobotConfig.LogType.ERROR))

    def __encrypt(self, _data) -> str:
        _publicKey = self.__get_rsa_publisc_key()
        _data = _data.encode('utf-8')
        _publicKey = _publicKey.encode('utf-8')
        _cipherPublic = PKCS1_v1_5.new(RSA.importKey(_publicKey))
        _textEncrypted = _cipherPublic.encrypt(_data)
        _textEncryptedBase64 = base64.b64encode(_textEncrypted).decode('utf-8')
        return _textEncryptedBase64

    def add_robot(self, _robotId,  _robotPassword, _aliveInterval) -> int:
        _retryCount = 0
        while _retryCount < 3:
            try:
                _passwordEncrypted = self.__encrypt(_robotPassword)
                _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
                _data = {"robot_id": _robotId, "robot_encrypted_rsa_password": _passwordEncrypted, "alive_interval": _aliveInterval, "clean_max_speed": 0.4, "robot_type": "Beta_3_1", "software_version": "1.0.0", "firmware_version": "1.0.0"}
                _response = requests.post(self.__serverUrl + "/api/robot_operate/", headers=_headers, json=_data)
                if _response.status_code == 200:
                    self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _robotId + " " + _response.json()['Success']+"\r", RobotConfig.LogType.INFO))
                elif _response.status_code == 409:
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotId + " " + _response.json()['Error']+"\r", RobotConfig.LogType.ERROR))
                else:
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code)+">" + _response.text+"\r", RobotConfig.LogType.ERROR))
                return _response.status_code
            # except requests.exceptions.RequestException as _requestException:
            except Exception as _exception:
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_exception)+"\r", RobotConfig.LogType.ERROR))
                _retryCount += 1
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Retry " + str(_retryCount)+"\r", RobotConfig.LogType.ERROR))
                time.sleep(0.5)
        return _retryCount

    def patch_robot(self, _robotData) -> dict():
        _retryCount = 0
        while _retryCount < 3:
            try:
                if _robotData == dict():
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] RobotData is empty\r", RobotConfig.LogType.ERROR))
                    return False
                else:
                    _data = {"robot_id": _robotData['robotID'], "state_code": _robotData['stateCode'], "sub_state_code": _robotData['subStateCode'], "battery": _robotData['battery'], "battery_now_used": _robotData['batteryNowUsed'], "clean_distance_now": _robotData['cleanDistanceNow'], "clean_distance_total": _robotData['cleanDistanceTotal'],
                             "clean_time_now": _robotData['cleanTimeNow'], "clean_time_total": _robotData['cleanTimeTotal'], "clean_count_now": _robotData['cleanCountNow'], "pedrail_remain_time": _robotData['pedrailRemainTime'], "brush_remain_time": _robotData['brushRemainTime'], "internet_state": _robotData['internetState'], "alarm": _robotData["alarm"], "clean_motor_flag": _robotData["cleanMotorFlag"]}
                    _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
                    _response = requests.patch(self.__serverUrl + "/api/robot_operate/", json=_data, headers=_headers, timeout=3)

                    if _response.status_code == 200:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["state_code"] = _data['state_code']
                        _returnDict["sub_state_code"] = 0
                        _returnDict["message"] = ""
                        self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _robotData["robotID"] + " " + (_response.json())['Success']+"\r", RobotConfig.LogType.INFO))
                    elif _response.status_code == 401:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["state_code"] = 5
                        _returnDict["sub_state_code"] = 1005
                        _returnDict["message"] = (_response.json())['Error']
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotData["robotID"] + " " + (_response.json())['Error']+"\r", RobotConfig.LogType.ERROR))
                    elif _response.status_code == 404:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["state_code"] = 5
                        _returnDict["sub_state_code"] = 1007
                        _returnDict["message"] = (_response.json())['Error']
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotData["robotID"] + " " + (_response.json())['Error']+"\r", RobotConfig.LogType.ERROR))
                    else:
                        _returnDict = dict()
                        _returnDict["state_code"] = 5
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["sub_state_code"] = 1006
                        _returnDict["message"] = _response.text
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
                    return _returnDict
            except requests.exceptions.RequestException as _requestException:
                _retryCount += 1
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_requestException)+"\r", RobotConfig.LogType.ERROR))
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Retry " + str(_retryCount)+"\r", RobotConfig.LogType.ERROR))
                time.sleep(0.5)
        return {"status_code": _retryCount}

    def delete_robot(self, _robotId, _robotPassword) -> int:
        _passwordEncrypted = self.__encrypt(_robotPassword)
        _data = {"robot_id": _robotId, "robot_encrypted_rsa_password": _passwordEncrypted}
        _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
        _response = requests.delete(url=self.__serverUrl + "/api/robot_operate/", json=_data, headers=_headers)
        if _response.status_code == 200:
            self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _robotId + " " + _response.json()['Success']+"\r", RobotConfig.LogType.INFO))
        elif _response.status_code == 401 or _response.status_code == 404:
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotId + " " + _response.json()['Error']+"\r", RobotConfig.LogType.ERROR))
        else:
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
        return _response.status_code

    def put_robot_abnormal_log(self, _taskData) -> dict():
        _retryCount = 0
        while _retryCount < 3:
            try:
                if _taskData == dict():
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + '%s' % ("Task Log is empty")+"\r", RobotConfig.LogType.ERROR))
                    return False
                else:
                    _data = {"error_serial_number": _taskData["cleanSerialNumber"], "state_code": _taskData['stateCode'], "sub_state_code": _taskData['subStateCode']}
                    _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
                    _response = requests.put(self.__serverUrl + "/api/update_robot_abnormal_log/", json=_data, headers=_headers, timeout=3)
                    if _response.status_code == 200:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = ""
                        self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _taskData["cleanSerialNumber"] + " " + (_response.json())['Success']+"\r", RobotConfig.LogType.INFO))
                    else:
                        _returnDict = dict()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = _response.text
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
                    return _returnDict
            except requests.exceptions.RequestException as _requestException:
                _retryCount += 1
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_requestException)+"\r", RobotConfig.LogType.ERROR))
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Retry " + str(_retryCount)+"\r", RobotConfig.LogType.ERROR))
                time.sleep(0.5)
        return {"status_code": _retryCount}

    def put_robot_log(self, _taskData) -> dict():
        _retryCount = 0
        while _retryCount < 3:
            try:
                if _taskData == dict():
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + '%s' % ("Task Log is empty")+"\r", RobotConfig.LogType.ERROR))
                    return False
                else:
                    _data = {"clean_serial_number": _taskData["cleanSerialNumber"], "state_code": _taskData['stateCode'], "sub_state_code": _taskData['subStateCode'], "clean_count_now": _taskData['cleanCountNow'], "direction": _taskData["direction"],
                             "clean_time_now": _taskData['cleanTimeNow'], "clean_speed": _taskData["cleanSpeed"], "clean_distance_now": _taskData['cleanDistanceNow'], "battery_now_used": _taskData['batteryNowUsed'], "clean_end_time": _taskData["cleanEndTime"]}
                    _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
                    _response = requests.put(self.__serverUrl + "/api/update_robot_log/", json=_data, headers=_headers, timeout=3)
                    if _response.status_code == 200:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = ""
                        self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _taskData["cleanSerialNumber"] + " " + (_response.json())['Success']+"\r", RobotConfig.LogType.INFO))
                    else:
                        _returnDict = dict()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = _response.text
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
                    return _returnDict
            except requests.exceptions.RequestException as _requestException:
                _retryCount += 1
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_requestException)+"\r", RobotConfig.LogType.ERROR))
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Retry " + str(_retryCount)+"\r", RobotConfig.LogType.ERROR))
                time.sleep(0.5)
        return {"status_code": _retryCount}

    def get_robot_setting(self, _robotId) -> dict():
        _headers = {"accept": "application/json", "X-CSRFToken": ""}
        _response = requests.get(url=self.__serverUrl + "/api/get_robot_setting/?robot_id="+_robotId, headers=_headers)
        if _response.status_code == 200:
            _returnDict = _response.json()
            _returnDict["sub_state_code"] = 0
        elif _response.status_code == 401:
            _returnDict = _response.json()
            _returnDict["state_code"] = 5
            _returnDict["sub_state_code"] = 1002
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotId + " " + _response.json()['Error']+"\r", RobotConfig.LogType.ERROR))
        elif _response.status_code == 404:
            _returnDict = _response.json()
            _returnDict["state_code"] = 5
            _returnDict["sub_state_code"] = 1004
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotId + " " + _response.json()['Error']+"\r", RobotConfig.LogType.ERROR))
        else:
            _returnDict = dict()
            _returnDict["state_code"] = 5
            _returnDict["sub_state_code"] = 1003
            _returnDict["Error"] = _response.text
            self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
        return _returnDict

    def patch_robot_version(self, _robotData) -> dict():
        _retryCount = 0
        while _retryCount < 3:
            try:
                if _robotData == dict():
                    self.__logDataList.append(Stream.print_log("[Web Communication ERROR] RobotData is emptyr", RobotConfig.LogType.ERROR))
                    return False
                else:
                    _data = {"robot_id": _robotData['robotID'], "software_version": _robotData['softwareVersion'], "firmware_version": _robotData['firmwareVersion']}
                    _headers = {"accept": "application/json", "Content-Type": "application/json", "X-CSRFToken": ""}
                    _response = requests.patch(self.__serverUrl + "/api/robot_version/", json=_data, headers=_headers, timeout=3)

                    if _response.status_code == 200:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        self.__logDataList.append(Stream.print_log("[Web Communication INFO] " + _robotData["robotID"] + " " + (_response.json())['Success']+"\r", RobotConfig.LogType.INFO))
                    elif _response.status_code == 404:
                        _returnDict = _response.json()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = (_response.json())['Error']
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _robotData["robotID"] + " " + (_response.json())['Error']+"\r", RobotConfig.LogType.ERROR))
                    else:
                        _returnDict = dict()
                        _returnDict["status_code"] = _response.status_code
                        _returnDict["message"] = _response.text
                        self.__logDataList.append(Stream.print_log("[Web Communication ERROR] <" + str(_response.status_code) + ">" + _response.text+"\r", RobotConfig.LogType.ERROR))
                    return _returnDict
            except requests.exceptions.RequestException as _requestException:
                _retryCount += 1
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] " + str(_requestException)+"\r", RobotConfig.LogType.ERROR))
                self.__logDataList.append(Stream.print_log("[Web Communication ERROR] Retry " + str(_retryCount)+"\r", RobotConfig.LogType.ERROR))
                time.sleep(0.5)
        return {"status_code": _retryCount}
