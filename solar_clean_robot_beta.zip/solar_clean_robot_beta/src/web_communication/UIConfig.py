from enum import Enum


class RobotStatus():
    def __init__(self) -> None:
        self.data = dict()
        self.data["frontend"] = dict()
        self.data["frontend"]["imu"] = {"pitch": 0.0}
        self.data["frontend"]["clean_distance_now"] = 0.0
        self.data["frontend"]["clean_distance_total"] = 0.0
        self.data["backend"] = dict()
        self.data["backend"]["robotID"] = ""
        self.data["backend"]["stateCode"] = 0
        self.data["backend"]["subStateCode"] = 0
        self.data["backend"]["battery"] = 0
        self.data["backend"]["batteryNowUsed"] = 0
        self.data["backend"]["cleanDistanceNow"] = 0
        self.data["backend"]["cleanDistanceTotal"] = 0
        self.data["backend"]["cleanTimeNow"] = 0
        self.data["backend"]["cleanTimeTotal"] = 0
        self.data["backend"]["cleanCountNow"] = 0
        self.data["backend"]["pedrailRemainTime"] = 0
        self.data["backend"]["brushRemainTime"] = 0
        self.data["backend"]["internetState"] = ""
        self.data["backend"]["alarm"] = 0
        self.data["backend"]["cleanMotorFlag"] = 0
        self.data["taskLog"] = dict()
        self.data["taskLog"]["cleanSerialNumber"] = ""
        self.data["taskLog"]["stateCode"] = 0
        self.data["taskLog"]["subStateCode"] = 0
        self.data["taskLog"]["cleanCountNow"] = 0
        self.data["taskLog"]["direction"] = 0
        self.data["taskLog"]["cleanTimeNow"] = 0
        self.data["taskLog"]["cleanSpeed"] = 0
        self.data["taskLog"]["cleanDistanceNow"] = 0
        self.data["taskLog"]["batteryNowUsed"] = 0
        self.data["taskLog"]["cleanEndTime"] = ""


class UIStatus():
    def __init__(self) -> None:
        self.data = dict()
        self.data["stateCode"] = 0
        self.data["subStateCode"] = 0


class VersionState():
    def __init__(self) -> None:
        self.data = dict()
        self.data["robot_id"] = ""
        self.data["software_version"] = ""
        self.data["firmware_version"] = ""


class UITaskLog():
    def __init__(self) -> None:
        self.data = dict()
        self.data["cleanSerialNumber"] = ""
        self.data["stateCode"] = 0
        self.data["subStateCode"] = 0
        self.data["cleanCountNow"] = 0
        self.data["direction"] = 0  # 0:"Left-top Navigation", 1:"Right-top Navigation"
        self.data["cleanTimeNow"] = 0
        self.data["cleanSpeed"] = 0
        self.data["cleanDistanceNow"] = 0
        self.data["batteryNowUsed"] = 0
        self.data["cleanEndTime"] = 0


class CleanCommand(Enum):
    STOP_CLEAN = 0x00
    START_CLEAN = 0x01
    STOP_RETURN = 0x02
    START_RETURN = 0x03
    ALARM_OFF = 0x04  # 0100
    ALARM_ON = 0x05  # 0101
    CLEAN_MOTOR_OFF = 0x06  # 0110
    CLEAN_MOTOR_ON = 0x07  # 0111
