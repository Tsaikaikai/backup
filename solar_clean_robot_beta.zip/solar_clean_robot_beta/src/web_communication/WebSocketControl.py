#!/usr/bin/env python3
from websocket import create_connection


class WebSocketClient():
    def __init__(self, _protocol="ws", _url="0.0.0.0", _port="8080", _api="/"):
        self.__serverUrl = _protocol + "://" + _url + ":"+_port + _api

    async def receive_message(self):
        try:
            return self.__ws.recv()
        except Exception as _exception:
            return ""

    async def send_message(self, _message):
        try:
            if type(_message) == bytes:
                self.__ws.send_binary(_message)
                _response = self.__ws.send(_message)
            else:
                _response = self.__ws.send(_message)
            return _response
        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' %
                  ('[ROS Converter ERROR] ' + str(_exception)))
            return False

    def on_close(self):
        print("close web socket")
        self.__ws.close()
        self.__ws = None

    def on_open(self):
        try:
            print("Connect to " + self.__serverUrl)
            self.__ws = create_connection(self.__serverUrl)
            self.__ws.settimeout(0.1)
            return True
        except Exception as _exception:
            print('\033[1;31m%s\033[0m\r' %
                  ('[ROS Converter ERROR] ' + str(_exception)))
            return False
