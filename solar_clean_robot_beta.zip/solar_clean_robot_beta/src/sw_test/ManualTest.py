#!/usr/bin/env python3

from time import sleep, time
import sys
from traceback import extract_tb
from io_control.ArduinoCommunication import ArduinoCommunication
from io_control.IMUCommunication import IMUCommunication
from io_control.CameraCommunication import CameraCommunication
from utility.RobotConfig import RobotData
from consolemenu import *
from consolemenu.items import *
from threading import Thread, Event


class ManualTest(Thread):
    def __init__(self, _robotType=""):
        # Initial Thread
        Thread.__init__(self)
        print('[Test INFO] Initial manual test\r')
        self.finished = Event()
        self.loadConfigStatus = False

        # ---------Initial params and flags--------- #
        self.configPath = '../config'
        self.loadConfigStatus = False
        self.threadList = []

        # ---------Initial config--------- #
        self.robotType = _robotType

        # ---------Initial sensors--------- #
        self.robotData = RobotData().data

    def run(self):
        self.setup()
        sleep(5)
        if self.loadConfigStatus:
            print('[Test INFO] Run manual test\r')
            try:
                while not self.finished.is_set():
                    self.robotData['sensor'] = self.ArduinoCommunicationThread.get_sensor()
                    self.robotData['driveMotor'] = self.ArduinoCommunicationThread.get_drive_motor()
                    self.robotData['sonar'] = self.ArduinoCommunicationThread.get_sonar()
                    self.robotData['battery'] = self.ArduinoCommunicationThread.get_battery()
                    self.robotData['boardMaster'] = self.ArduinoCommunicationThread.get_master_board()
                    self.robotData['boardSlave'] = self.ArduinoCommunicationThread.get_slave_board()
                    self.robotData['imu'] = self.PanelSimThread.get_imu()
                    self.robotData['camera'] = self.PanelSimThread.get_camera()
                    self.ArduinoCommunicationThread.set_clean_motor(self.robotData['uiCommand']["cleanMotorFlag"])
                    self.ArduinoCommunicationThread.set_beeper(self.robotData['uiCommand']["beeperFlag"])
                    self.ArduinoCommunicationThread.set_velocity(self.robotData['main']['controlVelocity'])
                    sleep(0.01)
            except Exception as e:
                error_class = e.__class__.__name__
                detail = e.args[0]
                cl, exc, tb = sys.exc_info()
                lastCallStack = extract_tb(tb)[-1]
                fileName = lastCallStack[0]
                lineNum = lastCallStack[1]
                funcName = lastCallStack[2]
                errMsg = "File \"{}\", line {}, in {}: [{}] {}".format(fileName, lineNum, funcName, error_class, detail)
                print('\033[1;31m%s\033[0m\r' % ('[Test ERROR] ' + str(errMsg)))

    def setup(self):
        print('[Test INFO] Setup manual test\r')

        # ---------Bringup io control--------- #
        self.ArduinoCommunicationThread = None
        self.ArduinoCommunicationThread = ArduinoCommunication(self.robotType)
        self.threadList.append(self.ArduinoCommunicationThread)
        self.IMUCommunicationThread = None
        self.IMUCommunicationThread = IMUCommunication(self.robotType)
        self.threadList.append(self.IMUCommunicationThread)
        self.CameraCommunicationThread = None
        self.CameraCommunicationThread = CameraCommunication(self.robotType)
        self.threadList.append(self.CameraCommunicationThread)

        for i in self.threadList:
            i.setDaemon(True)
            i.start()
            sleep(0.01)

        # ---------Check thread status--------- #
        sleep(1)
        checkDict = {
            "ArduinoSetting": self.ArduinoCommunicationThread.loadConfigStatus,
            "IMUSetting": self.IMUCommunicationThread.loadConfigStatus,
            "CameraSetting": self.CameraCommunicationThread.loadConfigStatus,
        }
        if not all(checkDict.values()):
            self.loadConfigStatus = False
            failList = list(filter(lambda x: checkDict[x] == False, checkDict))
            print('\033[1;31m%s\033[0m\r' % ('[Test ERROR] Load sub thread config error: ' + str(failList)))

    def stop(self):
        for i in self.threadList:
            i.stop()
            sleep(0.01)
        print('[Test INFO] Shutdown manual test\r')

    def check_sonar_range(self, _range):
        print('Range: ' + str(self.robotData['sonar']['range']))
        print('Cliff state: ' + str(self.robotData['sonar']['cliffState']))
        print('Connect: ' + str(self.robotData['sonar']['connect']))
        if _range > 0:
            for i in range(len(self.robotData['sonar']['range'])):
                if self.robotData['sonar']['range'][i] > _range*1.05 or self.robotData['sonar']['range'][i] < _range*0.95:
                    print('\033[1;31m%s\033[0m\r' % ('Range test result NG!\n'))
                    return 'NG'
                if (not self.robotData['sonar']['cliffState'][i] and (self.robotData['sonar']['range'][i] >= 7)) or (self.robotData['sonar']['cliffState'][i] and (self.robotData['sonar']['range'][i] < 7)):
                    print('\033[1;31m%s\033[0m\r' % ('Cliff state test result NG!\n'))
                    return 'NG'
            if not self.robotData['sonar']['connect']:
                print('\033[1;31m%s\033[0m\r' % ('Connect test result NG!\n'))
                return 'NG'
        elif _range == -2:
            for i in range(len(self.robotData['sonar']['range'])):
                if self.robotData['sonar']['range'][i] != _range:
                    print('\033[1;31m%s\033[0m\r' % ('Range test result NG!\n'))
                    return 'NG'
                if not self.robotData['sonar']['cliffState'][i]:
                    print('\033[1;31m%s\033[0m\r' % ('Cliff state test result NG!\n'))
                    return 'NG'
            if self.robotData['sonar']['connect']:
                print('\033[1;31m%s\033[0m\r' % ('Connect test result NG!\n'))
                return 'NG'
        elif _range == -3:
            for i in range(len(self.robotData['sonar']['range'])):
                if self.robotData['sonar']['range'][i] != _range:
                    print('\033[1;31m%s\033[0m\r' % ('Range test result NG!\n'))
                    return 'NG'
                if not self.robotData['sonar']['cliffState'][i]:
                    print('\033[1;31m%s\033[0m\r' % ('Cliff state test result NG!\n'))
                    return 'NG'
            if not self.robotData['sonar']['connect']:
                print('\033[1;31m%s\033[0m\r' % ('Connect test result NG!\n'))
                return 'NG'
        print('\033[1;32m%s\033[0m\r' % ('Test result OK!\n'))
        return 'OK'

    def check_manual(self, _msg):
        while True:
            data = input(str(_msg))
            if data == '0' or data == '1':
                break
            else:
                print('Input error')
        if data == '0':
            print('\033[1;32m%s\033[0m\r' % ('Test result OK!\n'))
            return 'OK'
        elif data == '1':
            print('\033[1;31m%s\033[0m\r' % ('Test result NG!\n'))
            return 'NG'

    def test_selector(self, _testID):
        if _testID == 'MoT_001':
            return self.MoT_001()
        elif _testID == 'MoT_002':
            return self.MoT_002()
        elif _testID == 'MoT_003':
            return self.MoT_003()
        elif _testID == 'MoT_004':
            return self.MoT_004()
        elif _testID == 'MoT_005':
            return self.MoT_005()
        elif _testID == 'MoT_006':
            return self.MoT_006()
        elif _testID == 'MoT_007':
            return self.MoT_007()
        elif _testID == 'MoT_008':
            return self.MoT_008()
        elif _testID == 'MoT_009':
            return self.MoT_009()
        elif _testID == 'MoT_010':
            return self.MoT_010()
        elif _testID == 'MoT_011':
            return self.MoT_011()
        elif _testID == 'MoT_012':
            return self.MoT_012()
        elif _testID == 'MoT_013':
            return self.MoT_013()
        elif _testID == 'MoT_014':
            return self.MoT_014()
        elif _testID == 'MoT_015':
            return self.MoT_015()
        elif _testID == 'MoT_016':
            return self.MoT_016()
        elif _testID == 'MoT_017':
            return self.MoT_017()

    def MoT_001(self):
        input("Start test MoT_001, please place the ultrasonic sensors 5 centimeters away from the obstacle. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [5, 5, 5, 5, 5, 5, 5, 5]
        # self.robotData['sonar']['cliffState'] = [False, False, False, False, False, False, False, False]
        # self.robotData['sonar']['connect'] = True
        result = self.check_sonar_range(5)
        if result == 'NG':
            return result
        input("Start test MoT_001, please place the ultrasonic sensors 10 centimeters away from the obstacle. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [10, 10, 10, 10, 10, 10, 10, 10]
        # self.robotData['sonar']['cliffState'] = [True, True, True, True, True, True, True, True]
        result = self.check_sonar_range(10)
        if result == 'NG':
            return result
        input("Start test MoT_001, please place the ultrasonic sensors 100 centimeters away from the obstacle. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [100, 100, 100, 100, 100, 100, 100, 100]
        result = self.check_sonar_range(100)
        return result

    def MoT_002(self):
        input("Start test MoT_002, please place the ultrasonic sensors 5 centimeters away from the obstacle. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [5, 5, 5, 5, 5, 5, 5, 5]
        # self.robotData['sonar']['cliffState'] = [False, False, False, False, False, False, False, False]
        # self.robotData['sonar']['connect'] = True
        result = self.check_sonar_range(5)
        if result == 'NG':
            return result
        input("Start test MoT_002, please disconnect communication cable of the ultrasonic sensors. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [-2, -2, -2, -2, -2, -2, -2, -2]
        # self.robotData['sonar']['cliffState'] = [True, True, True, True, True, True, True, True]
        # self.robotData['sonar']['connect'] = False
        result = self.check_sonar_range(-2)
        return result

    def MoT_003(self):
        input("Start test MoT_003, please place the ultrasonic sensors 5 centimeters away from the obstacle. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [5, 5, 5, 5, 5, 5, 5, 5]
        # self.robotData['sonar']['cliffState'] = [False, False, False, False, False, False, False, False]
        # self.robotData['sonar']['connect'] = True
        result = self.check_sonar_range(5)
        if result == 'NG':
            return result
        input("Start test MoT_003, please trigger all ultrasonic sensors co-channel interference. Press Enter to continue...")
        # self.robotData['sonar']['range'] = [-3, -3, -3, -3, -3, -3, -3, -3]
        # self.robotData['sonar']['cliffState'] = [True, True, True, True, True, True, True, True]
        result = self.check_sonar_range(-3)
        return result

    def MoT_004(self):
        input("Start test MoT_004, the brushes is about to activate, please check if the area around the brushes is clear. Press Enter to continue...")
        self.robotData['uiCommand']["cleanMotorFlag"] = True
        return self.check_manual('Please confirm that the brushes has been activated. Input 0 for OK, input 1 for NG: ')

    def MoT_005(self):
        input("Start test MoT_005, the brushes is about to deactivate, please check if the area around the brushes is clear. Press Enter to continue...")
        self.robotData['uiCommand']["cleanMotorFlag"] = False
        return self.check_manual('Please confirm that the brushes has been deactivated. Input 0 for OK, input 1 for NG: ')

    def MoT_006(self):
        input("Start test MoT_006, the buzzer is about to activate. Press Enter to continue...")
        self.robotData['uiCommand']["beeperFlag"] = True
        return self.check_manual('Please confirm that the buzzer has been activated. Input 0 for OK, input 1 for NG: ')

    def MoT_007(self):
        input("Start test MoT_007, the buzzer is about to deactivate. Press Enter to continue...")
        self.robotData['uiCommand']["beeperFlag"] = False
        return self.check_manual('Please confirm that the buzzer has been deactivated. Input 0 for OK, input 1 for NG: ')

    def MoT_008(self):
        input("Start test MoT_008, the robot is about to move forward and backward at a speed of 0.1 m/s. Press Enter to continue...")
        print('Start moving forward...')
        start = time()
        while time() - start < 2:
            self.robotData['main']['controlVelocity'] = [0.1, 0.0]
            sleep(0.01)
        self.robotData['main']['controlVelocity'] = [0.0, 0.0]
        sleep(1)
        print('Start moving backward...')
        start = time()
        while time() - start < 2:
            self.robotData['main']['controlVelocity'] = [-0.1, 0.0]
            sleep(0.01)
        self.robotData['main']['controlVelocity'] = [0.0, 0.0]
        return self.check_manual('Please confirm that the robot is operating normally. Input 0 for OK, input 1 for NG: ')

    def MoT_009(self):
        input("Start test MoT_009, the robot is about to move forward at a speed of 0.1 m/s for 2 seconds. Press Enter to continue...")
        # self.robotData['driveMotor'] = {"connect": True, "errorCode": 0, "state": 0, "velocity": [0.0, 0.0], "odometry": [0.03, 0.0, 0.0], "mileage": 0.03}
        prevDriveMotor = self.robotData['driveMotor']
        print('Start moving forward...')
        start = time()
        while time() - start < 2:
            self.robotData['main']['controlVelocity'] = [0.1, 0.0]
            sleep(0.01)
        self.robotData['main']['controlVelocity'] = [0.0, 0.0]
        # self.robotData['driveMotor'] = {"connect": True, "errorCode": 0, "state": 0, "velocity": [0.0, 0.0], "odometry": [0.23, 0.0, 0.0], "mileage": 0.23}
        print('Before: ' + str(prevDriveMotor))
        print('After:  ' + str(self.robotData['driveMotor']))
        if not self.robotData['driveMotor']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Motor connect result NG!\n'))
            return 'NG'
        elif self.robotData['driveMotor']['state'] != 0:
            print('\033[1;31m%s\033[0m\r' % ('Motor state result NG!\n'))
            return 'NG'
        elif self.robotData['driveMotor']['odometry'][0] - prevDriveMotor['odometry'][0] < 0.15:
            print('\033[1;31m%s\033[0m\r' % ('Motor odometry result NG!\n'))
            return 'NG'
        elif self.robotData['driveMotor']['mileage'] - prevDriveMotor['mileage'] < 0.15:
            print('\033[1;31m%s\033[0m\r' % ('Motor mileage result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Motor test result OK!\n'))
            return 'OK'

    def MoT_010(self):
        input("Start test MoT_010, please disconnect communication cable of the drive motor. Press Enter to continue...")
        print(self.robotData['driveMotor'])
        if self.robotData['driveMotor']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Motor connect result NG!\n'))
            return 'NG'
        elif self.robotData['driveMotor']['state'] == 0:
            print('\033[1;31m%s\033[0m\r' % ('Motor state result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Motor test result OK!\n'))
            return 'OK'

    def MoT_011(self):
        input("Start test MoT_011, please keep the robot in a stationary state. Press Enter to continue...")
        # self.robotData['battery'] = {"connect": True, "errorCode": 0, "voltage": 24.0, "current": 2.0, "temperature": 25.0, "SOC": 100, "SOH": 100, "cycle": 5}
        print(self.robotData['battery'])
        if not self.robotData['battery']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Battery connect result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['errorCode'] != 0:
            print('\033[1;31m%s\033[0m\r' % ('Battery error code result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['SOC'] < 20:
            print('\033[1;31m%s\033[0m\r' % ('Battery SOC result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Battery test result OK!\n'))
            return 'OK'

    def MoT_012(self):
        input("Start test MoT_012, please disconnect communication cable of the battery. Press Enter to continue...")
        # self.robotData['battery'] = {"connect": False, "errorCode": 4001, "voltage": 0.0, "current": 0.0, "temperature": 0.0, "SOC": -2, "SOH": 0, "cycle": 0}
        print(self.robotData['battery'])
        if self.robotData['battery']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Battery connect result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['errorCode'] != 4001:
            print('\033[1;31m%s\033[0m\r' % ('Battery error code result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['SOC'] != -2:
            print('\033[1;31m%s\033[0m\r' % ('Battery SOC result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Battery test result OK!\n'))
            return 'OK'

    def MoT_013(self):
        input("Start test MoT_013, please use a battery with less than 20% SOC. Press Enter to continue...")
        # self.robotData['battery'] = {"connect": True, "errorCode": 4002, "voltage": 24.0, "current": 2.0, "temperature": 25.0, "SOC": 15, "SOH": 100, "cycle": 5}
        print(self.robotData['battery'])
        if not self.robotData['battery']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Battery connect result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['errorCode'] != 4002:
            print('\033[1;31m%s\033[0m\r' % ('Battery error code result NG!\n'))
            return 'NG'
        elif self.robotData['battery']['SOC'] > 15:
            print('\033[1;31m%s\033[0m\r' % ('Battery SOC result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Battery test result OK!\n'))
            return 'OK'

    def MoT_014(self):
        input("Start test MoT_014, please keep the robot in a stationary state. Press Enter to continue...")
        # self.robotData["imu"] = {"connect": True, "retryCounter": 0, "errorCode": 0, "euler": [0.0, 0.0, 0.0], "acceleration": [0.0, 0.0, 0.0]}
        prevIMU = self.robotData['imu']
        print('Please rotate the robot...')
        start = time()
        while time() - start < 2:
            sleep(0.01)
        # self.robotData["imu"] = {"connect": True, "retryCounter": 0, "errorCode": 0, "euler": [0.0, 0.0, 3.0], "acceleration": [0.0, 0.0, 0.0]}
        print('Before: ' + str(prevIMU))
        print('After:  ' + str(self.robotData['imu']))
        if not self.robotData['imu']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('IMU connect result NG!\n'))
            return 'NG'
        elif self.robotData['imu']['errorCode'] != 0:
            print('\033[1;31m%s\033[0m\r' % ('IMU error code result NG!\n'))
            return 'NG'
        elif self.robotData['imu']['euler'][2] == prevIMU['euler'][2]:
            print('\033[1;31m%s\033[0m\r' % ('IMU euler result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('IMU test result OK!\n'))
            return 'OK'

    def MoT_015(self):
        input("Start test MoT_015, please disconnect communication cable of the IMU. Press Enter to continue...")
        # self.robotData["imu"] = {"connect": False, "retryCounter": 0, "errorCode": 1001, "euler": [0.0, 0.0, 0.0], "acceleration": [0.0, 0.0, 0.0]}
        print(self.robotData['imu'])
        if self.robotData['imu']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('IMU connect result NG!\n'))
            return 'NG'
        elif self.robotData['imu']['errorCode'] != 1001:
            print('\033[1;31m%s\033[0m\r' % ('IMU error code result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('IMU test result OK!\n'))
            return 'OK'

    def MoT_016(self):
        input("Start test MoT_016, please keep the robot in a stationary state. Press Enter to continue...")
        # self.robotData["camera"] = {"connect": True, "frameNumber": 0, "status": 4, "location": -1, "angle": 0, "cameraDebugData": {"data0": "0", "data1": "0", "data2": "0", "data3": "0", "data4": "0", "data5": "0"}}
        prevCamera = self.robotData['camera']
        print('Please wait for camera...')
        start = time()
        while time() - start < 2:
            sleep(0.01)
        # self.robotData["camera"] = {"connect": True, "frameNumber": 100, "status": 4, "location": -1, "angle": 0, "cameraDebugData": {"data0": "0", "data1": "0", "data2": "0", "data3": "0", "data4": "0", "data5": "0"}}
        print('Before: ' + str(prevCamera))
        print('After:  ' + str(self.robotData['camera']))
        if not self.robotData['camera']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Camera connect result NG!\n'))
            return 'NG'
        elif self.robotData['camera']['status'] == -1:
            print('\033[1;31m%s\033[0m\r' % ('Camera status result NG!\n'))
            return 'NG'
        elif self.robotData['camera']['frameNumber'] == prevCamera['frameNumber']:
            print('\033[1;31m%s\033[0m\r' % ('Camera frame number result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Camera test result OK!\n'))
            return 'OK'

    def MoT_017(self):
        input("Start test MoT_017, please disconnect communication cable of the camera. Press Enter to continue...")
        # self.robotData["camera"] = {"connect": False, "frameNumber": 0, "status": -1, "location": -1, "angle": 0, "cameraDebugData": {"data0": "0", "data1": "0", "data2": "0", "data3": "0", "data4": "0", "data5": "0"}}
        print(self.robotData['camera'])
        if self.robotData['camera']['connect']:
            print('\033[1;31m%s\033[0m\r' % ('Camera connect result NG!\n'))
            return 'NG'
        elif self.robotData['camera']['status'] != -1:
            print('\033[1;31m%s\033[0m\r' % ('Camera status result NG!\n'))
            return 'NG'
        else:
            print('\033[1;32m%s\033[0m\r' % ('Camera test result OK!\n'))
            return 'OK'
