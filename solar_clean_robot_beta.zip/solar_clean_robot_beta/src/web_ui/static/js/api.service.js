async function directionControl(direction) {
    const reqData = { direction }

    const response = await axios({
        method: "post",
        url: '/direction-control',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    return resData.message
}

async function directionStop() {

    const response = await axios({
        method: "post",
        url: '/direction-stop',
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    return resData.message
}

async function cleanMotorStatus(status) {

    const reqData = { status }

    const response = await axios({
        method: "post",
        url: '/clean-motor-status',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    return resData.message
}

async function navSetting(loopFlag, initFlag) {
    const reqData = {
        loopFlag,
        initFlag
    }

    const response = await axios({
        method: "post",
        url: '/nav-setting',
        data: reqData,
        headers: {
            'content-type': 'application/json'
        }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    console.log(resData.message)
    return resData.message
}

async function navStartDirection(loopFlag, initFlag, direction) {

    const reqData = { loopFlag, initFlag, direction }

    const response = await axios({
        method: "post",
        url: '/nav-start-direction',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    console.log(resData.message)
    return resData.message
}

async function navStop() {

    const response = await axios({
        method: "post",
        url: '/nav-stop',
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return
    console.log(resData.message)
    return resData.message
}

async function speedTest(linear, angular, distance) {

    const reqData = { linear, angular, distance }

    const response = await axios({
        method: "post",
        url: '/speed-test',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    console.log(resData.message)
    return resData.message
}

async function raTest(linear, angular, distance) {

    const reqData = { linear, angular, distance }

    const response = await axios({
        method: "post",
        url: '/ra-test',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    console.log(resData.message)
    return resData.message
}

async function motorTest(linear, angular, distance) {

    const reqData = { linear, angular, distance }

    const response = await axios({
        method: "post",
        url: '/motor-test',
        data: reqData,
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return
    console.log(resData.message)
    return resData.message
}

async function navReturn() {

    const response = await axios({
        method: "post",
        url: '/nav-return',
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return
    console.log(resData.message)
    return resData.message
}

async function robotStatus() {

    const response = await axios({
        method: "post",
        url: '/robot-status',
        headers: { 'content-type': 'application/json' }
    })
    if (response.status !== 200) return

    const resData = response.data
    if (!resData) return

    console.log(resData.message)
    return resData.data
}
