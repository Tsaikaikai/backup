const app = Vue.createApp({
    data() {
        return {
            device: 'mobile',
            mobileDisplayMode: 'operation',
            mobileMonitorContent: 'robot-monitor',
            btnHovered: null,
            operatingMode: 'remote',
            monitorDataCategory: 'realTime',
            realTimeData: new Map(),
            longTermData: new Map(),
            dashboardData: {
                battery: -1,
                errorCode: "None",
                robotState: "StandBy",
                robotVelocity: {
                    line: 0,
                    angular: 0,
                },
                sensorSignal: [],
                //sensorRange: [],
                connectionStatus: false,
            },
            remoteModeData: {
                cleanMotorFlag: false,
            },
            navigateModeData: {
                mileage: 0,
                navFlag: false,
                navSetting: {
                    loopFlag: false,
                    initFlag: false,
                },
            },
            speedTestModeData: {
                navFlag: false,
                testTimer: 0,
            },
            speedTestVal: [{
                name: 'Linear',
                min: -0.4,
                max: 0.4,
                step: 0.05,
                value: 0.2
            },
            {
                name: 'Angular',
                min: -0.4,
                max: 0.4,
                step: 0.05,
                value: 0
            },
            {
                name: 'Distance',
                min: 0.0,
                max: 2.0,
                step: 0.05,
                value: 0.8
            },
            ],

        }
    },
    methods: {
        initRobotStatus: async function () {

            //if(window.innerWidth < 768 && window.location.pathname !== "/moblie") window.location.href = "/moblie";
            await this.updateRobotStatus()

            console.log("finish init")

            setInterval(async () => { await this.updateRobotStatus() }, 200)

        },
        updateRobotStatus: async function () {
            const response = await robotStatus()

            const realTimeDataMap = new Map(Object.entries(response.realTimeData))
            const realTimeDataArr = []
            realTimeDataMap.forEach((value, key) => {
                realTimeDataArr.push([key, new Map(Object.entries(value))])
            })
            this.realTimeData = new Map(realTimeDataArr)

            const longTermDataMap = new Map(Object.entries(response.longTermData))
            const longTermDataArr = []
            longTermDataMap.forEach((value, key) => {
                longTermDataArr.push([key, new Map(Object.entries(value))])
            })
            this.longTermData = new Map(longTermDataArr)


            this.dashboardData = response.dashboardData
            this.remoteModeData = response.remoteModeData
            this.navigateModeData = response.navigateModeData
            this.speedTestModeData = response.speedTestModeData

            const connectionStatus = Object.entries(realTimeDataMap.get('Connection')).map(item => item[1].content)

            this.dashboardData.connectionStatus = connectionStatus.includes('Disconnected') ? false : true


        },
        handleChangeOperatingMode: function (mode) {
            this.operatingMode = mode
        },
        handleDirectionControl: async function (direction) {
            const respnose = await directionControl(direction)
            console.log("direction :", respnose)
        },
        handleDirectionStop: async function () {
            const response = await directionStop()
            console.log(response)
        },
        handleCleanMotorStatus: async function (status) {
            const response = await cleanMotorStatus(status)
        },
        handleNavSetting: async function (loopFlag, initFlag) {
            const response = await navSetting(loopFlag, initFlag)
        },
        handleNavStartDirection: async function (direction) {
            const {
                loopFlag,
                initFlag
            } = this.navigateModeData.navSetting
            const response = await navStartDirection(loopFlag, initFlag, direction)
        },
        handleNavStop: async function () {
            const response = await navStop()
        },
        handleSpeedTest: async function () {
            const inputVal = this.speedTestVal.map(item => item.value)
            const response = await speedTest(...inputVal)
        },
        handleRaTest: async function () {
            const inputVal = this.speedTestVal.map(item => item.value)
            const response = await raTest(...inputVal)
        },
        handleMotorTest: async function () {
            const inputVal = this.speedTestVal.map(item => item.value)
            const response = await motorTest(...inputVal)
        },
        handleNavReturn: async function () {
            const response = await navReturn()
        }
    },
    mounted() {
        this.initRobotStatus()
    },
})

const vm = app.mount('#app');
