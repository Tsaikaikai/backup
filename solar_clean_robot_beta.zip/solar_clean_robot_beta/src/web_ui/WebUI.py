from flask import Flask, request, render_template, jsonify
from flask_cors import CORS
from threading import Thread
from gevent.pywsgi import WSGIServer
from os.path import isdir
import sys
from utility.RobotConfig import RobotData


def response(code, message, data=None):
    # code=0 for success, code=1 for fail
    return jsonify({'code': code, 'message': message, 'data': data})


class CustomFlask(Flask):
    jinja_options = Flask.jinja_options.copy()
    jinja_options.update(dict(
        # Default is '{{', I'm changing this because Vue.js uses '{{' / '}}'
        variable_start_string='%%',
        variable_end_string='%%',
    ))


app = CustomFlask(__name__)
app.config['JSON_SORT_KEYS'] = False
CORS(app)

currentLinear = 0
currentAngular = 0
testLinear = 0
testAngular = 0
testDistance = 0
cleanMode = 0
robotState = -1
errorCode = [0]
sensorRange = [-2, -2, -2, -2, -2, -2, -2, -2]
navFlag = False
cleanMotorFlag = False
loopFlag = False
initFlag = False
robotMsg = [
    "Remote",
    "Left-top Navigation",
    "Right-top Navigation",
    "Return",
    "Speed Test",
    "Low Battery",
    "Alert",
    "RA Test",
    "Motor Test",
    "CCD Error",
    "Initial"
]
errorMsg = [
    "None",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6"
]
robotInfoJson = {
    # real time data
    "connection": [False, False, False, False, False, False],
    "battery": [-2, -2, -2, -2],
    "odom": [0, 0, 0],
    "imu": [0, 0, 0],
    "camera": [0, 0, 0],
    "temperature": [-2, -2],
    "current": [-2, -2, -2, -2],
    "otherSensors": [-2],

    # long term data
    "consumable": [0, 0, 0, 0, 0],

    # dashboard data
    "robotState": 0,
    "errorCode": 0,
    "robotVelocity": [0, 0],

    # navigate mode data
    "mileage": 0,

    # speed test mode data
    "finishFlag": False,

    # others
    "sensor": {
        "cliffState": [False, False, False, False, False, False, False, False],
        "range": [-2, -2, -2, -2, -2, -2, -2, -2],
    },

}

uiBackendJson = {
    # remote mode data
    "cleanMotorFlag": False,

    # navigate mode data
    "navFlag": False,
    "navSetting": [False, False],   # loopFlag, initFlag

    # others
    "robotMsg": "Initial",
    "errorMsg": "None",
    "sensorConnection": [False, False, False, False, False, False, False, False],
}


def getProcessedData(source, titles, units):
    target = {}
    for index, item in enumerate(titles):
        target[item] = {}
        if str(source[index]).isalpha():
            target[item]["content"] = source[index]
        else:
            target[item]["content"] = round(source[index], 2)
        target[item]["unit"] = units[index]
    return target


class realTimeData:
    def __init__(self, robotInfo):
        self.robotInfo = robotInfo

    def getAllData(self):
        connectInfo = []
        for item in self.robotInfo['connection']:
            connectInfo.append('Connect' if item else 'Disconnected')
        if len(connectInfo) == 5:
            connection = getProcessedData(connectInfo, ["IMU", "Board", "Motor", "Battery", "Sensor"], ["", "", "", "", ""])
        elif len(connectInfo) == 6:
            connection = getProcessedData(connectInfo, ["IMU", "Board Master",  "Board Slave", "Motor", "Battery", "Sensor"], ["", "", "", "", "", ""])
        battery = getProcessedData(self.robotInfo['battery'], ['Voltage', 'Current', 'SOC', 'Temperature'], ['V', 'A', '%', '°C'])
        odom = getProcessedData(self.robotInfo['odom'], ['X', 'Y', 'Angle'], ['m', 'm', 'rad'])
        imu = getProcessedData(self.robotInfo['imu'], ["Roll", "Pitch", "Yaw"], ["°", "°", "°"])
        sensorRange = getProcessedData(self.robotInfo['sensor']['range'], ["sensor_0", "sensor_1", "sensor_2", "sensor_3", "sensor_4", "sensor_5", "sensor_6", "sensor_7"], ["cm", "cm", "cm", "cm", "cm", "cm", "cm", "cm"])
        camera = getProcessedData(self.robotInfo['camera'], ["Status", "Location", "Angle"], ["", "pixel", "°"])

        return {
            "Connection": connection,
            "Battery": battery,
            "Odometry": odom,
            "IMU": imu,
            "Sensor": sensorRange,
            "Camera": camera
        }


class longTermData:
    def __init__(self, robotInfo):
        self.robotInfo = robotInfo

    def getAllData(self):
        temperature = getProcessedData(self.robotInfo["temperature"], ["temperature_1", "temperature_2"], ['°C', '°C'])
        current = getProcessedData(self.robotInfo["current"], ["current_1", "current_2", "current_3", "current_4"], ['mA', 'mA', 'mA', 'mA'])
        otherSensors = getProcessedData(self.robotInfo["otherSensors"], ["Humidity"], ['%'])
        consumable = getProcessedData(self.robotInfo["consumable"], ["Brush", "Pedrail", "Total Clean Time", "Total Mileage", "Total Clean Area"], ['days', 'days', 'days', 'm', 'm²'])
        return {
            "Temperature": temperature,
            "Current": current,
            "Other Sensors": otherSensors,
            "Consumable": consumable
        }


class DashboardData:
    def __init__(self, robotInfo, backendInfo):
        self.robotInfo, self.backendInfo = robotInfo, backendInfo

    def getAllData(self):
        robotState = self.backendInfo['robotMsg']
        errorCode = self.backendInfo['errorMsg']
        robotVelocity = {
            "line": self.robotInfo['robotVelocity'][0],
            "angular": self.robotInfo['robotVelocity'][1],
        }
        sensorConnection = self.backendInfo['sensorConnection']
        sensorCliff = self.robotInfo['sensor']['cliffState']
        sensorSignal = []

        for index, item in enumerate(sensorConnection):
            if item == False:
                sensorSignal.append('disconnect')
            elif sensorCliff[index] == False:
                sensorSignal.append('cliff-false')
            else:
                sensorSignal.append('cliff-true')

        battery = self.robotInfo['battery'][2]

        return {
            "errorCode": errorCode,
            "robotState": robotState,
            "robotVelocity": robotVelocity,
            "sensorSignal": sensorSignal,
            "battery": battery,
        }


@app.route('/')
def desktop():
    return render_template('desktop.html')


@app.route('/mobile')
def mobile():
    return render_template('mobile.html')


@app.route('/mvixDemo')
def mvixDemo():
    return render_template('mvixDemo.html')


@app.route('/direction-control', methods=['POST'])
def direction_control():
    global currentLinear, currentAngular
    data = request.get_json()
    direction = data['direction']

    if direction == 'forward':
        currentLinear = check_linear_limit(currentLinear + 0.05)
    elif direction == 'backward':
        currentLinear = check_linear_limit(currentLinear - 0.05)
    elif direction == 'left':
        currentAngular = check_angular_limit(currentAngular + 0.05)
    elif direction == 'right':
        currentAngular = check_angular_limit(currentAngular - 0.05)

    return response(0, direction)


@app.route('/direction-stop', methods=['POST'])
def direction_stop():
    global currentLinear, currentAngular
    currentLinear = 0
    currentAngular = 0
    return response(0, 'remote control stop success')


@app.route('/clean-motor-status', methods=['POST'])
def clean_motor_status():
    global cleanMotorFlag
    data = request.get_json()
    status = data['status']

    if status == 'off':
        cleanMotorFlag = False
        return response(0, 'clean motor off')

    if status == 'on':
        cleanMotorFlag = True
        return response(0, 'clean motor on')


@app.route('/nav-setting', methods=['POST'])
def nav_setting():
    global loopFlag, initFlag
    data = request.get_json()
    if data['loopFlag']:
        loopFlag = True
    else:
        loopFlag = False

    if data['initFlag']:
        initFlag = True
    else:
        initFlag = False

    return response(0, 'nav_setting set success')


@app.route('/nav-start-direction', methods=['POST'])
def nav_start_direction():
    global currentLinear, currentAngular, navFlag, cleanMode, cleanMotorFlag, loopFlag, initFlag
    navFlag = True
    cleanMotorFlag = True
    currentLinear = 0
    currentAngular = 0

    data = request.get_json()
    if data['loopFlag']:
        loopFlag = True
    else:
        loopFlag = False

    if data['initFlag']:
        initFlag = True
    else:
        initFlag = False

    if data['direction'] == 'left':
        cleanMode = 0

    if data['direction'] == 'right':
        cleanMode = 1
    return response(0, 'nav start ' + str(cleanMode))


@app.route('/nav-stop', methods=['POST'])
def nav_stop():
    global currentLinear, currentAngular, navFlag, cleanMotorFlag
    navFlag = False
    cleanMotorFlag = False
    currentLinear = 0
    currentAngular = 0
    return response(0, 'nav_stop stop success')


@app.route('/speed-test', methods=['POST'])
def speed_test():
    global navFlag, cleanMode, cleanMotorFlag, currentLinear, currentAngular, testLinear, testAngular, testDistance
    navFlag = True
    cleanMode = 3
    currentLinear = 0
    currentAngular = 0

    data = request.get_json()
    testLinear = float(data['linear'])
    testAngular = float(data['angular'])
    testDistance = float(data['distance'])

    return response(0, 'speed test success')


@app.route('/ra-test', methods=['POST'])
def ra_test():
    global navFlag, cleanMode, cleanMotorFlag, currentLinear, currentAngular, testLinear, testAngular, testDistance
    navFlag = True
    cleanMode = 4
    currentLinear = 0
    currentAngular = 0

    data = request.get_json()
    testLinear = float(data['linear'])
    testAngular = float(data['angular'])
    testDistance = float(data['distance'])

    return response(0, 'ra test success')


@app.route('/motor-test', methods=['POST'])
def motor_test():
    global navFlag, cleanMode, cleanMotorFlag, currentLinear, currentAngular, testLinear, testAngular, testDistance
    navFlag = True
    cleanMode = 5
    currentLinear = 0
    currentAngular = 0

    data = request.get_json()
    testLinear = float(data['linear'])
    testAngular = float(data['angular'])
    testDistance = float(data['distance'])

    return response(0, 'motor test success')


@app.route('/nav-return', methods=['POST'])
def nav_return():
    global navFlag, cleanMode, cleanMotorFlag, currentLinear, currentAngular, testLinear, testAngular, testDistance
    navFlag = True
    cleanMotorFlag = False
    cleanMode = 2
    currentLinear = 0
    currentAngular = 0
    return response(0, 'nav_return success')


@app.route("/robot-status", methods=['POST'])
def robot_status():
    global robotInfoJson, navFlag, cleanMotorFlag, robotMsg, robotState, errorMsg, errorCode, sensorRange, loopFlag, initFlag, uiBackendJson
    uiBackendJson['navFlag'] = navFlag
    uiBackendJson['cleanMotorFlag'] = cleanMotorFlag
    uiBackendJson['robotMsg'] = robotMsg[robotState]
    uiBackendJson['errorMsg'] = errorCode
    sensorConnection = []
    for i in range(len(sensorRange)):
        if sensorRange[i] != -2:
            sensorConnection.append(True)
        else:
            sensorConnection.append(False)
    uiBackendJson['sensorConnection'] = sensorConnection
    uiBackendJson['navSetting'] = [loopFlag, initFlag]

    responseData = {
        "realTimeData": realTimeData(robotInfoJson).getAllData(),
        "longTermData": longTermData(robotInfoJson).getAllData(),
        "dashboardData": DashboardData(robotInfoJson, uiBackendJson).getAllData(),
        "remoteModeData": {
            "cleanMotorFlag": uiBackendJson['cleanMotorFlag']
        },
        "navigateModeData": {
            "navFlag": uiBackendJson['navFlag'],
            "navSetting": {
                "loopFlag": uiBackendJson['navSetting'][0],
                "initFlag": uiBackendJson['navSetting'][1],
            },
            "mileage": robotInfoJson['mileage'],
        },
        "speedTestModeData": {
            "navFlag": uiBackendJson['navFlag'],
        }

    }
    return response(0, 'get robot status', responseData)


def constrain(vel, low, high):
    if vel < low:
        vel = low
    elif vel > high:
        vel = high
    else:
        vel = vel
    return vel


def check_linear_limit(vel):
    vel = constrain(vel, -0.4, 0.4)
    return round(vel, 3)


def check_angular_limit(vel):
    vel = constrain(vel, -0.5, 0.5)
    return round(vel, 3)


class WebUI(Thread):
    def __init__(self):
        Thread.__init__(self)
        print('[Command INFO] Initial drive web app\r')
        self.sonar = None
        self.imu = None
        self.threadStatus = False
        self.server = None
        self.uiCommand = RobotData().data['uiCommand']

    def run(self):
        print('[Command INFO] Run drive web app\r')
        app.config['TEMPLATES_AUTO_RELOAD'] = True
        app.jinja_env.auto_reload = True
        self.server = WSGIServer(('0.0.0.0', 5000), app, log=None)
        try:
            self.threadStatus = True
            self.server.serve_forever()
        except:
            self.threadStatus = False

    def get_button_status(self):
        global currentLinear, currentAngular, navFlag, cleanMode, cleanMotorFlag, loopFlag, initFlag, testLinear, testAngular, testDistance
        self.uiCommand["navSetting"]["cleanMode"] = cleanMode
        self.uiCommand["navSetting"]["cleanSpeed"] = 0.4
        if loopFlag:
            self.uiCommand["navSetting"]["cleanCount"] = 999
        else:
            self.uiCommand["navSetting"]["cleanCount"] = 1
        self.uiCommand["speedTestSetting"]["testLinear"] = testLinear
        self.uiCommand["speedTestSetting"]["testAngular"] = testAngular
        self.uiCommand["speedTestSetting"]["testDistance"] = testDistance
        self.uiCommand["controlVelocity"] = [currentLinear, currentAngular]
        self.uiCommand["cleanMotorFlag"] = cleanMotorFlag
        self.uiCommand["navFlag"] = navFlag

        return self.uiCommand

    def set_robot_status(self, _robotData):
        global robotInfoJson, navFlag, cleanMotorFlag, robotState, errorCode, sensorRange
        robotInfoJson = self.pack_robot_info(_robotData)
        robotState = robotInfoJson["robotState"]
        errorCode = robotInfoJson["errorCode"]
        sensorRange = robotInfoJson["sensor"]["range"]
        if robotInfoJson["finishFlag"]:
            navFlag = False
            cleanMotorFlag = False

    def stop(self):
        if self.server:
            self.server.stop()
            self.server.close()
        print('[Command INFO] Shutdown drive web app\r')

    def pack_robot_info(self, _robotData):
        info = dict()
        info["connection"] = [_robotData['imu']['connect'], _robotData['boardMaster']['connect'], _robotData['boardSlave']['connect'], _robotData['driveMotor']['connect'], _robotData['battery']['connect'], _robotData['sonar']['connect']]
        info["robotState"] = _robotData['navigation']['robotState']
        info["robotVelocity"] = [round(_robotData['main']['controlVelocity'][0], 2), round(_robotData['main']['controlVelocity'][1], 2)]
        info["imu"] = _robotData['imu']['euler']

        info["camera"] = [_robotData['camera']['status'], _robotData['camera']['location'], _robotData['camera']['angle']]
        info["odom"] = _robotData['driveMotor']['odometry']
        info["sensor"] = _robotData['sonar']
        info["battery"] = [_robotData['battery']['voltage'], _robotData['battery']['current'], _robotData['battery']['SOC'], _robotData['battery']['temperature']]
        info["mileage"] = round(_robotData['recorder']['mileageNow'], 2)
        info["consumable"] = [round(_robotData['recorder']['brushRemainTime']/86400), round(_robotData['recorder']['pedrailRemainTime']/86400), round(_robotData['recorder']['cleanTimeTotal']/86400),
                              _robotData['recorder']['mileageTotal'], _robotData['recorder']['cleanAreaTotal']]
        info["temperature"] = _robotData['sensor']['temperature']
        info["current"] = _robotData['sensor']['current']
        info["otherSensors"] = [_robotData['sensor']['humidity']]
        info["errorCode"] = _robotData['main']['errorCode']
        info["finishFlag"] = _robotData['navigation']['finishFlag']

        return info


def main():
    app.jinja_env.auto_reload = True
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    main()
