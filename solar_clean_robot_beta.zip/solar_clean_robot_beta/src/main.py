#!/usr/bin/env python3

from os.path import join, isfile
from time import sleep, time
from sys import exc_info
from traceback import extract_tb
from navigation.ZigzagShapedClean import ZigzagShapedClean
from navigation.ZigzagShapedClean_test import ZigzagShapedCleanTest
from io_control.CameraCommunication import CameraCommunication
from recorder.DataRecorder import DataRecorder
from simulator.PanelSim import PanelSim
from simulator.DriveControlSim import DriveControlSim
from io_control.ArduinoCommunication import ArduinoCommunication
from io_control.ArduinoLogSerial import ArduinoLogSerial
from io_control.IMUCommunication import IMUCommunication
from web_communication.WebClient import WebClient
from web_ui.WebUI import WebUI
from utility.RobotConfig import RobotData
import yaml
from subprocess import Popen, PIPE
import hashlib


class SolarCleanRobot(object):
    def __init__(self):
        super(SolarCleanRobot, self).__init__()
        print('[Main INFO] Initial solar clean robot\r')

        # ---------Initial params and flags--------- #
        self.configPath = '../config'
        self.loadConfigStatus = False
        self.robotInfoJson = None
        self.recordJson = None
        self.threadList = []

        # velocity
        self.prevLinear = 0.0
        self.prevAngular = 0.0
        self.linearHistory = []
        self.angularHistory = []
        self.prevLeftMotorSpeed = 0.0
        self.prevRightMotorSpeed = 0.0

        # robot info
        self.prevBoardMasterStatus = False
        self.prevBoardSlaveStatus = False
        self.prevImuStatus = False
        self.prevDriveMotorStatus = False
        self.prevCleanMotorFlag = False
        self.prevBatteryStatus = False
        self.prevSonarStatus = False
        self.prevCameraStatus = False
        self.errorTimer = 0
        self.cancelTimer = 0

        # ---------Initial config--------- #
        self.robotType = ''
        self.controlMode = 0  # 0: Web UI 1: New Web UI
        self.simulate = True  # True: Simulate False: Online
        self.navTestMode = 0

        # ---------Initial sensors--------- #
        self.robotData = RobotData().data

    def run(self):
        self.load_config()
        self.setup()
        sleep(5)
        if self.loadConfigStatus:
            print('[Main INFO] Run solar clean robot\r')
            try:
                while True:
                    #  Get sensor
                    if self.simulate:
                        self.robotData['driveMotor'] = self.DriveControlThread.get_drive_motor()
                        self.robotData['sonar'] = self.PanelSimThread.get_sonar(self.robotData['driveMotor']['odometry'])
                        self.robotData['imu'] = self.PanelSimThread.get_imu()
                        self.robotData['battery'] = self.PanelSimThread.get_battery()
                        self.robotData['boardMaster'] = self.PanelSimThread.get_board()
                        self.robotData['boardSlave'] = self.PanelSimThread.get_board()
                        self.PanelSimThread.set_clean_mode(self.robotData['uiCommand']['navSetting']['cleanMode'])
                        self.robotData['camera'] = self.PanelSimThread.get_camera()
                    else:
                        self.robotData['sensor'] = self.ArduinoCommunicationThread.get_sensor()
                        self.robotData['driveMotor'] = self.ArduinoCommunicationThread.get_drive_motor()
                        self.robotData['sonar'] = self.ArduinoCommunicationThread.get_sonar()
                        self.robotData['battery'] = self.ArduinoCommunicationThread.get_battery()
                        self.robotData['boardMaster'] = self.ArduinoCommunicationThread.get_master_board()
                        self.robotData['boardSlave'] = self.ArduinoCommunicationThread.get_slave_board()
                        # self.robotData['controller'] = self.ArduinoCommunicationThread.get_controller()
                        self.ArduinoCommunicationThread.set_clean_motor(self.robotData['uiCommand']["cleanMotorFlag"])
                        self.ArduinoCommunicationThread.set_beeper(self.robotData['uiCommand']["beeperFlag"])
                        self.robotData['imu'] = self.IMUCommunicationThread.get_imu()
                        self.robotData['camera'] = self.CameraCommunicationThread.get_camera()

                    # Send robot info and get ui command
                    self.RecordThread.set_robot_status(self.robotData)
                    self.robotData['recorder'] = self.RecordThread.get_consumable_value()
                    if self.controlMode == 1:
                        self.UIMonitorThread.set_robot_status(self.robotData)
                    self.UIBackendThread.set_robot_status(self.robotData)
                    self.robotData['uiCommand'] = self.UIBackendThread.get_button_status()
                    self.NavigationThread.set_robot_status(self.robotData)
                    self.robotData['navigation'] = self.NavigationThread.get_navigation()

                    # Check controller or UI whether cancel navigation
                    self.robotData['controller']['navFlag'] = self.robotData['uiCommand']['navFlag']
                    self.robotData['main']['navFlag'] = self.robotData['uiCommand']['navFlag'] or self.robotData['controller']['navFlag']
                    if not (self.robotData['uiCommand']['navFlag'] and self.robotData['controller']['navFlag']):
                        if self.robotData['main']['navFlag'] and time()-self.cancelTimer > 1:
                            self.robotData['main']['cancelFlag'] = True
                        else:
                            self.robotData['main']['cancelFlag'] = False
                    else:
                        self.robotData['main']['cancelFlag'] = False
                        self.cancelTimer = time()

                    # Check robot error code
                    self.get_error_code()
                    if self.robotData['main']['errorCode'][0] != 0:
                        if time()-self.errorTimer > 30:
                            self.robotData['main']['connectFlag'] = False
                        elif self.robotData['navigation']['errorCode'] != 0 or self.robotData['uiCommand']['errorCode'] != 0 or self.robotData['sensor']['errorCode'] != 0 or self.robotData['driveMotor']['errorCode']:
                            self.robotData['main']['connectFlag'] = False
                        else:
                            self.robotData['main']['connectFlag'] = True
                    else:
                        self.robotData['main']['connectFlag'] = True
                        self.errorTimer = time()

                    # Send control velocity
                    if self.robotData['main']['errorCode'][0] != 0 and self.robotData['main']['navFlag']:
                        self.robotData['main']['controlVelocity'] = [0.0, 0.0]
                    elif self.robotData['main']['navFlag']:
                        self.robotData['main']['controlVelocity'] = self.robotData['navigation']['controlVelocity']
                    else:
                        self.robotData['main']['controlVelocity'] = self.robotData['uiCommand']['controlVelocity']
                    if self.simulate:
                        self.DriveControlThread.set_sonar(self.robotData['sonar']['cliffState'])
                        self.DriveControlThread.set_velocity(self.robotData['main']['controlVelocity'])
                    else:
                        self.ArduinoCommunicationThread.set_velocity(self.robotData['main']['controlVelocity'])

                    # Update prev status
                    # self.prevLinear, self.prevAngular = self.checkVelocity(self.prevLinear, self.robotData['main']['controlVelocity'][0], self.prevAngular, self.robotData['main']['controlVelocity'][1])
                    # self.prevLeftMotorSpeed, self.prevRightMotorSpeed = self.checkVelocity(self.prevLeftMotorSpeed, self.robotData['navigation']['leftMotorSpeed'], self.prevRightMotorSpeed, self.robotData['navigation']['rightMotorSpeed'])
                    self.prevBoardMasterStatus = self.checkStatus('Master Board status', self.prevBoardMasterStatus, self.robotData['boardMaster']['connect'])
                    self.prevBoardSlaveStatus = self.checkStatus('Slave Board status', self.prevBoardSlaveStatus, self.robotData['boardSlave']['connect'])
                    self.prevImuStatus = self.checkStatus('IMU status', self.prevImuStatus, self.robotData['imu']['connect'])
                    self.prevDriveMotorStatus = self.checkStatus('Drive motor status', self.prevDriveMotorStatus, self.robotData['driveMotor']['connect'])
                    self.prevCleanMotorFlag = self.checkStatus('Clean motor Flag', self.prevCleanMotorFlag, self.robotData['uiCommand']["cleanMotorFlag"])
                    self.prevBatteryStatus = self.checkStatus('Battery status', self.prevBatteryStatus, self.robotData['battery']['connect'])
                    self.prevSonarStatus = self.checkStatus('Sensor status', self.prevSonarStatus, self.robotData['sonar']['connect'])
                    self.prevCameraStatus = self.checkStatus('Camera status', self.prevCameraStatus, self.robotData['camera']['connect'])
                    sleep(0.01)
            except Exception as e:
                error_class = e.__class__.__name__
                detail = e.args[0]
                cl, exc, tb = exc_info()
                lastCallStack = extract_tb(tb)[-1]
                fileName = lastCallStack[0]
                lineNum = lastCallStack[1]
                funcName = lastCallStack[2]
                errMsg = "File \"{}\", line {}, in {}: [{}] {}".format(fileName, lineNum, funcName, error_class, detail)
                print('\033[1;31m%s\033[0m\r' % ('[Main ERROR] ' + str(errMsg)))

    def setup(self):
        print('[Main INFO] Setup solar clean robot\r')

        # ---------Trigger--------- #
        try:
            echo = Popen(['echo', 'robot'], stdout=PIPE)
            p = Popen(['sudo', '-S', 'udevadm', 'trigger'], stdin=echo.stdout, stdout=PIPE)
            sleep(1)
        except:
            pass

        # ---------Bringup panel simulator--------- #
        self.PanelSimThread = None
        self.DriveControlThread = None
        if self.simulate:
            self.PanelSimThread = PanelSim(self.robotType)
            self.threadList.append(self.PanelSimThread)
            self.DriveControlThread = DriveControlSim(self.robotType)
            self.threadList.append(self.DriveControlThread)

        # ---------Bringup io control--------- #
        self.ArduinoCommunicationThread = None
        self.ArduinoLogSerialThread = None
        self.IMUCommunicationThread = None
        self.CameraCommunicationThread = None
        if not self.simulate:
            self.ArduinoCommunicationThread = ArduinoCommunication(self.robotType)
            self.threadList.append(self.ArduinoCommunicationThread)
            self.ArduinoLogSerialThread = ArduinoLogSerial(self.robotType)
            self.threadList.append(self.ArduinoLogSerialThread)
            self.IMUCommunicationThread = IMUCommunication(self.robotType)
            self.threadList.append(self.IMUCommunicationThread)
            self.CameraCommunicationThread = CameraCommunication(self.robotType)
            self.threadList.append(self.CameraCommunicationThread)

        # ---------Bringup drive command--------- #
        self.UIBackendThread = None
        self.UIMonitorThread = None
        if self.controlMode == 0:
            self.UIBackendThread = WebUI()
        elif self.controlMode == 1:
            self.UIBackendThread = WebClient(self.robotType)
            self.UIMonitorThread = WebUI()
            self.threadList.append(self.UIMonitorThread)
        self.threadList.append(self.UIBackendThread)

        # ---------Bringup navigation--------- #
        self.NavigationThread = None
        if self.navTestMode == 0:
            self.NavigationThread = ZigzagShapedClean(self.robotType)
        elif self.navTestMode == 1:
            self.NavigationThread = ZigzagShapedCleanTest(self.robotType)
        self.threadList.append(self.NavigationThread)

        # ---------Bringup data recorder--------- #
        self.RecordThread = None
        self.RecordThread = DataRecorder(self.robotType)
        self.threadList.append(self.RecordThread)

        for i in self.threadList:
            i.setDaemon(True)
            i.start()
            sleep(0.01)

        # ---------Check thread status--------- #
        sleep(1)
        checkDict = None
        if not self.simulate:
            checkDict = {
                "ArduinoSetting": self.ArduinoCommunicationThread.loadConfigStatus,
                "RecorderSetting": self.RecordThread.loadConfigStatus,
                "IMUSetting": self.IMUCommunicationThread.loadConfigStatus,
                "CameraSetting": self.CameraCommunicationThread.loadConfigStatus,
                "NavigationSetting": self.NavigationThread.loadConfigStatus,
                "UIBackendStatus": self.UIBackendThread.threadStatus
            }
        else:
            checkDict = {
                "RecorderSetting": self.RecordThread.loadConfigStatus,
                "MotorSetting": self.DriveControlThread.loadConfigStatus,
                "NavigationSetting": self.NavigationThread.loadConfigStatus,
                "SimulatorSetting": self.PanelSimThread.loadConfigStatus,
                "UIBackendStatus": self.UIBackendThread.threadStatus
            }
        if not all(checkDict.values()):
            self.loadConfigStatus = False
            failList = list(filter(lambda x: checkDict[x] == False, checkDict))
            print('\033[1;31m%s\033[0m\r' % ('[Main ERROR] Load sub thread config error: ' + str(failList)))

    def stop(self):
        for i in reversed(self.threadList):
            i.stop()
            sleep(0.01)
        print('[Main INFO] Shutdown solar clean robot\r')

    def load_config(self):
        print('[Main INFO] Load config from yaml\r')
        mainYamlPath = join(self.configPath, 'MainSetting.yaml')
        if not isfile(mainYamlPath):
            print('\033[1;31m%s\033[0m\r' % ('[Main ERROR] Load config error: MainSetting.yaml is not exists'))
        else:
            try:
                with open(mainYamlPath, "r") as f:
                    mainYamlDict = yaml.load(f, Loader=yaml.FullLoader)
                self.robotType = mainYamlDict['ROBOT_TYPE']
                self.robotData['main']['softwareVersion'] = mainYamlDict['SOFTWARE_VERSION']
                self.controlMode = mainYamlDict['CONTROL_MODE']
                self.simulate = mainYamlDict['SIMULATE']
                self.navTestMode = mainYamlDict['NAV_TEST_MODE']
                self.loadConfigStatus = True
            except Exception as e:
                print('\033[1;31m%s\033[0m\r' % ('[Main ERROR] Load config error: ' + str(e)))

    def checkStatus(self, _name, _prev, _current):
        if _prev != _current:
            print('\033[1;33m%s\033[0m\r' % ('[Main WARN] ' + str(_name) + ': ' + str(_current)))
            _prev = _current
        return _prev

    def checkVelocity(self, _prevL, _currentL, _prevA, _currentA):
        flag = False
        if _prevL != round(_currentL, 2):
            _prevL = round(_currentL, 2)
            flag = True
        if _prevA != round(_currentA, 2):
            _prevA = round(_currentA, 2)
            flag = True
        if flag:
            print('\033[1;32m%s\033[0m\r' % ('[Main Info] Linear: ' + str(round(_currentL, 2)) + ' Angular: ' + str(round(_currentA, 2)) + '\r'))
        return _prevL, _prevA

    def get_error_code(self):
        errorCount = 0
        errorList = ['imu', 'boardMaster', 'boardSlave', 'driveMotor', 'battery', 'sonar', 'sensor', 'recorder', 'navigation', 'uiCommand']
        for key in errorList:
            if self.robotData[key]['errorCode'] != 0:
                if self.robotData[key]['errorCode'] not in self.robotData['main']['errorCode']:
                    self.robotData['main']['errorCode'].append(self.robotData[key]['errorCode'])
                errorCount += 1
        self.robotData['main']['errorCode'].sort()
        if len(self.robotData['main']['errorCode']) > 1 and self.robotData['main']['errorCode'][0] == 0:
            self.robotData['main']['errorCode'].pop(0)
        if errorCount == 0:
            self.robotData['main']['errorCode'] = [0]


def get_cpu_id():
    cpuID = None
    with open('/proc/cpuinfo') as f:
        for line in f:
            if line.split(':')[0].strip() == 'Serial':
                cpuID = line.split(':')[1].strip()
    return cpuID


def main():
    checkFlag = True
    if isfile("main.bin"):
        cpuID = get_cpu_id()
        hl1 = hashlib.md5(cpuID.encode(encoding='UTF-8')).hexdigest()
        hl2 = hashlib.sha256(hl1.encode(encoding='UTF-8')).hexdigest()
        if isfile("/usr/src/.key"):
            with open('/usr/src/.key', 'r') as f:
                bKey = f.read()
        else:
            bKey = 'error'
        if bKey != hl2[16:32]:
            checkFlag = False

    if checkFlag:
        Worker = SolarCleanRobot()
        try:
            Worker.run()
        except KeyboardInterrupt:
            pass
        Worker.stop()


if __name__ == "__main__":
    main()
