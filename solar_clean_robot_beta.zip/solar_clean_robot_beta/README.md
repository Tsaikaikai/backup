# solar_clean_robot_beta

## Setup RP-RK3568
1. Open RKDevTool, then use the OTG cable to connect to RP-RK3568. 
2. Keep holding down the upgrade button and power on the device.
3. Wait for the device status bar on RKDevTool to display "Found One Loader Device", then release upgrade button.
4. Click on the "Upgrade Firmware" tab, then click on the "Firmware" button and select the Linux image file.
5. Click on the "EraseFlash" button and wait for the erase process to complete.
6. Click on the "Upgrade" button and wait for the burning process to complete.
7. After restarting, enter the following command to create a WIFI AP.
```sh
sudo create_ap -n -g 192.168.16.110 wlan0 SolarCleanRobot solarcleanrobot --mkconfig /etc/create_ap.conf
systemctl start create_ap
systemctl enable create_ap
sudo reboot
```
8. Fixed tty device assignments in Linux using udev. For example,
```sh
sudo udevadm info --attribute-walk --name=/dev/ttyUSB0
cd /etc/udev/rules.d
sudo gedit imu.rules
KERNELS=="5-1", ATTRS{idVendor}=="10c4",ATTRS{idProduct}=="ea60",MODE:="0777" ,SYMLINK+="imu"
sudo udevadm trigger
```
9. Set up automatic startup.
```sh
gnome-session-properties
sh -c "sleep 5s; /home/rpdzkj/solar_clean_robot_beta/bin/main.sh"
```

## Git Version Control with tag.
Listing the existing tags in Git
```sh
git tag
```
Creating an annotated tag in Git
```sh
git tag -a vX.X.X -m "Solar Clean Robot Version vX.X.X"
```
Sharing Tags
```sh
git push origin vX.X.X
```
