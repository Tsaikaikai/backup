#!/bin/bash

sudo cp docker.list /etc/apt/sources.list.d/
sudo apt-get update
sudo apt-get install apt-transport-https ca-certificates curl gnupg-agent software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -
sudo ln -s /usr/lib/python3/dist-packages/apt_pkg.cpython-36m-aarch64-linux-gnu.so /usr/lib/python3/dist-packages/apt_pkg.so
sudo ln -s /usr/lib/python3/dist-packages/gi/_gi.cpython-36m-aarch64-linux-gnu.so /usr/lib/python3/dist-packages/gi/_gi.so
sudo ln -s /usr/lib/python3/dist-packages/gi/_gi_cairo.cpython-36m-aarch64-linux-gnu.so /usr/lib/python3/dist-packages/gi/_gi_cairo.so
sudo add-apt-repository "deb [arch=arm64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io
docker run hello-world