﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using AOISystem.Halcon.Controls;
using AOISystem.Halcon.Recipe;
using HalconDotNet;
using System.ComponentModel;
using System.IO;

namespace AOISystem.Halcon.ROI
{
    public delegate void FuncROIDelegate();

    /// <summary>
    /// This class creates and manages ROI objects. It responds 
    /// to  mouse device inputs using the methods mouseDownAction and 
    /// mouseMoveAction. You don't have to know this class in detail when you 
    /// build your own C# project. But you must consider a few things if 
    /// you want to use interactive ROIs in your application: There is a
    /// quite close connection between the ROIController and the HWndCtrl 
    /// class, which means that you must 'register' the ROIController
    /// with the HWndCtrl, so the HWndCtrl knows it has to forward user input
    /// (like mouse events) to the ROIController class.  
    /// The visualization and manipulation of the ROI objects is done 
    /// by the ROIController.
    /// This class provides special support for the matching
    /// applications by calculating a model region from the list of ROIs. For
    /// this, ROIs are added and subtracted according to their sign.
    /// </summary>
    public class ROIController
    {
        /// <summary>
        /// Constant for setting the ROI mode: positive ROI sign.
        /// </summary>
        public const int MODE_ROI_POS = 21;

        /// <summary>
        /// Constant for setting the ROI mode: negative ROI sign.
        /// </summary>
        public const int MODE_ROI_NEG = 22;

        /// <summary>
        /// Constant for setting the ROI mode: no model region is computed as
        /// the sum of all ROI objects.
        /// </summary>
        public const int MODE_ROI_NONE = 23;

        /// <summary>Constant describing an update of the model region</summary>
        public const int EVENT_UPDATE_ROI = 30;

        private ROIBase roiMode;

        private int stateROI;

        /// <summary>RecipeNo of the active ROI object</summary>
        public int ActiveROIIndex { get; set; }

        private List<ROIBase> _rOIList;
        /// <summary>List containing all created ROI objects so far</summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public List<ROIBase> ROIList
        {
            get { return _rOIList; }
            set { _rOIList = value; }
        }

        /// <summary>
        /// Region obtained by summing up all negative 
        /// and positive ROI objects from the ROIList 
        /// </summary>
        public HRegion ModelROI;

        private string activeCol = "green";
        private string activeHdlCol = "red";
        private string inactiveCol = "red";

        public int Roiactive = -1;

        //public HWndCtrl		   viewController;
        private HControl m_HControl;

        /// <summary>
        /// Constructor
        /// </summary>
        public ROIController()
        {
            stateROI = MODE_ROI_NONE;
            _rOIList = new List<ROIBase>();
            ActiveROIIndex = -1;
            //ModelROI = new HRegion();
            //NotifyRCObserver = new IconicDelegate(dummyI);
        }

        /// <summary>
        /// Registers the HWndCtrl to this ROIController instance
        /// </summary>
        /// <param name="view"></param>
        public void SetViewController(HControl view)
        {
            m_HControl = view;
        }

        /// <summary>Gets the ModelROI object</summary>
        public HRegion getModelRegion()
        {
            return ModelROI;
        }

        public int ProduceROIIndex()
        {
            bool flag = false;
            for (int i = 0; i < this.ROIList.Count; i++)
            {
                flag = false;
                for (int j = 0; j < this.ROIList.Count; j++)
                {
                    if (this.ROIList[j].ROIInfo.Index == (i + 1))
                    {
                        flag = true;
                    }
                }
                if (!flag)
                {
                    return (i + 1);
                }
            }
            return this.ROIList.Count + 1;
        }

        /// <summary>
        /// To create a new ROI object the application class initializes a 
        /// 'seed' ROI instance and passes it to the ROIController.
        /// The ROIController now responds by manipulating this new ROI
        /// instance.
        /// </summary>
        /// <param name="r">
        /// 'Seed' ROI object forwarded by the application forms class.
        /// </param>
        public void SetROIShape(ROIBase r)
        {
            r.ROIInfo.Index = ProduceROIIndex();

            Roiactive = r.ROIInfo.Index;
            roiMode = r;
            roiMode.setOperatorFlag(stateROI);
        }

        public void ResetROIShape()
        {
            ActiveROIIndex = -1;
            Roiactive = -1;
            roiMode = null;
        }

        public void SetROIMode(ROIBase r)
        {
            //r.ROIInfo.Index = ProduceROIIndex(r);

            roiMode = r;
            roiMode.setOperatorFlag(stateROI);

            ROIList.Add(roiMode);
            roiMode = null;
        }

        /// <summary>
        /// Sets the sign of a ROI object to the value 'mode' (MODE_ROI_NONE,
        /// MODE_ROI_POS,MODE_ROI_NEG)
        /// </summary>
        public void setROISign(int mode)
        {
            stateROI = mode;

            if (ActiveROIIndex != -1)
            {
                ((ROIBase)ROIList[ActiveROIIndex]).setOperatorFlag(stateROI);

                defineModelROI();
                m_HControl.Repaint();
            }
        }

        /// <summary>
        /// Removes the ROI object that is marked as active. 
        /// If no ROI object is active, then nothing happens. 
        /// </summary>
        public void RemoveActive()
        {
            if (ActiveROIIndex != -1)
            {
                ROIList.RemoveAt(ActiveROIIndex);
                ActiveROIIndex = -1;
                Roiactive = -1;
                defineModelROI();
                m_HControl.Repaint();
            }
        }

        /// <summary>
        /// RemoveAll
        /// </summary>
        public void RemoveAll()
        {
            ROIList.Clear();
            ActiveROIIndex = -1;
            defineModelROI();
            if (this.m_HControl != null)
            {
                this.m_HControl.Repaint();
            }
        }


        /// <summary>
        /// Calculates the ModelROI region for all objects contained 
        /// in ROIList, by adding and subtracting the positive and 
        /// negative ROI objects.
        /// </summary>
        public void defineModelROI()
        {
            HRegion tmpAdd, tmpDiff, tmp;
            double row, col;

            if (stateROI == MODE_ROI_NONE)
            {
                if (ActiveROIIndex != -1)
                {
                    try
                    {
                        RectangleF rectF = ((ROIBase)ROIList[ActiveROIIndex]).getRectangleF();
                    }
                    catch (Exception)
                    { }

                    //((ROIBase)ROIList[ActiveROIIndex]).ROIInfo.X = rectF.X;
                    //((ROIBase)ROIList[ActiveROIIndex]).ROIInfo.Y = rectF.Y;
                    //((ROIBase)ROIList[ActiveROIIndex]).ROIInfo.Width = rectF.Width;
                    //((ROIBase)ROIList[ActiveROIIndex]).ROIInfo.Height = rectF.Height;
                }
                return;
            }

            tmpAdd = new HRegion();
            tmpDiff = new HRegion();

            for (int i = 0; i < ROIList.Count; i++)
            {
                switch (((ROIBase)ROIList[i]).getOperatorFlag())
                {
                    case ROIBase.POSITIVE_FLAG:
                        tmp = ((ROIBase)ROIList[i]).getRegion();
                        tmpAdd = tmp.Union2(tmpAdd);
                        break;
                    case ROIBase.NEGATIVE_FLAG:
                        tmp = ((ROIBase)ROIList[i]).getRegion();
                        tmpDiff = tmp.Union2(tmpDiff);
                        break;
                    default:
                        break;
                }//end of switch
            }//end of for

            ModelROI = null;

            if (tmpAdd.AreaCenter(out row, out col) > 0)
            {
                tmp = tmpAdd.Difference(tmpDiff);
                if (tmp.AreaCenter(out row, out col) > 0)
                {
                    ModelROI = tmp;
                }
            }

            //NotifyRCObserver(ROIController.EVENT_UPDATE_ROI);

            // in case the set of positiv and negative ROIs dissolve 
            if ((ModelROI == null) && (ActiveROIIndex != -1))
            {
                m_HControl.Repaint();
            }
        }

        /// <summary>
        /// Clears all variables managing ROI objects
        /// </summary>
        public void Reset()
        {
            ROIList.Clear();
            ActiveROIIndex = -1;
            ModelROI = null;
            roiMode = null;
            //NotifyRCObserver(ROIController.EVENT_UPDATE_ROI);
        }

        /// <summary>
        /// Deletes this ROI instance if a 'seed' ROI object has been passed
        /// to the ROIController by the application class.
        /// </summary>
        public void resetROI()
        {
            ActiveROIIndex = -1;
            roiMode = null;
        }

        /// <summary>Defines the colors for the ROI objects</summary>
        /// <param name="aColor">Color for the active ROI object</param>
        /// <param name="inaColor">Color for the inactive ROI objects</param>
        /// <param name="aHdlColor">
        /// Color for the active handle of the active ROI object
        /// </param>
        public void setDrawColor(string aColor, string aHdlColor, string inaColor)
        {
            if (aColor != "")
            {
                activeCol = aColor;
            }
            if (aHdlColor != "")
            {
                activeHdlCol = aHdlColor;
            }
            if (inaColor != "")
            {
                inactiveCol = inaColor;
            }
        }

        /// <summary>
        /// Paints all objects from the ROIList into the HALCON window
        /// </summary>
        /// <param name="window">HALCON window</param>
        public void paintData(HalconDotNet.HWindow window, bool fontflag)
        {
            window.SetDraw("margin");
            //window.SetLineWidth(2000);
            string color;
            if (ROIList.Count > 0)
            {

                window.SetDraw("margin");

                for (int i = 0; i < ROIList.Count; i++)
                {
                    ROIInfo recipe = ((ROIBase)ROIList[i]).ROIInfo;
                    color = recipe.InActiveColor.ToString();
                    if (color.Contains('_'))
                    {
                        color = color.Replace('_', ' ');
                    }
                    window.SetColor(color);
                    window.SetLineStyle(((ROIBase)ROIList[i]).flagLineStyle);

                    //((ROI)ROIList[i]).Recipe.HRectangle = ((ROI)ROIList[i]).getRectangleF();
                    ((ROIBase)ROIList[i]).setROIParameter(m_HControl);
                    ((ROIBase)ROIList[i]).draw(window);
                    if (fontflag)
                    {
                        ((ROIBase)ROIList[i]).drawFont(window);
                    }
                }

                if (ActiveROIIndex != -1)
                {
                    ROIInfo recipe = ((ROIBase)ROIList[ActiveROIIndex]).ROIInfo;

                    setDrawColor(recipe.ActiveColor.ToString(), recipe.ActiveHColor.ToString(), recipe.InActiveColor.ToString());
                    color = activeCol.ToString();
                    if (color.Contains('_'))
                    {
                        color = color.Replace('_', ' ');
                    }
                    window.SetColor(color);
                    window.SetLineStyle(((ROIBase)ROIList[ActiveROIIndex]).flagLineStyle);

                    ((ROIBase)ROIList[ActiveROIIndex]).setROIParameter(m_HControl);
                    ((ROIBase)ROIList[ActiveROIIndex]).draw(window);
                    if (fontflag)
                    {
                        ((ROIBase)ROIList[ActiveROIIndex]).drawFont(window);
                    }
                    color = activeHdlCol.ToString();
                    if (color.Contains('_'))
                    {
                        color = color.Replace('_', ' ');
                    }
                    window.SetColor(color);
                    ((ROIBase)ROIList[ActiveROIIndex]).displayActive(window);
                }
            }
        }

        /// <summary>
        /// Reaction of ROI objects to the 'mouse button down' event: changing
        /// the shape of the ROI and adding it to the ROIList if it is a 'seed'
        /// ROI.
        /// </summary>
        /// <param name="imgX">x coordinate of mouse event</param>
        /// <param name="imgY">y coordinate of mouse event</param>
        /// <returns></returns>
        public int mouseDownAction(double imgX, double imgY)
        {
            int idxROI = -1;
            //the handles

            if (roiMode != null)			 //either a new ROI object is created
            {
                roiMode.setROIParameter(m_HControl);
                roiMode.createROI(imgX, imgY);
                ROIList.Add(roiMode);

                roiMode = null;
                ActiveROIIndex = ROIList.Count - 1;

                m_HControl.Repaint();
            }
            else if (ROIList.Count > 0)		// ... or an existing one is manipulated
            {
                if (Roiactive == -1)
                {
                    ActiveROIIndex = -1;
                    int selectionRoi = -1;
                    int temp = int.MaxValue;
                    int ROIarea;    //=-1 不在框內
                    for (int i = 0; i < ROIList.Count; i++)
                    {
                        ROIarea = ((ROIBase)ROIList[i]).ROIdistance(imgX, imgY);
                        if (ROIarea != -1)
                        {
                            if (ROIarea < temp)
                            {
                                temp = ROIarea;
                                selectionRoi = i;
                            }
                        }
                    }

                    if (selectionRoi != -1 && ((ROIBase)ROIList[selectionRoi]).distToClosestHandle2(imgX, imgY))
                    {
                        Roiactive = selectionRoi;
                        idxROI = selectionRoi;
                    }

                    if (idxROI >= 0)
                    {
                        ActiveROIIndex = idxROI;
                    }
                }
                else
                {
                    if (((ROIBase)ROIList[ActiveROIIndex]).distToClosestHandle2(imgX, imgY))
                    {
                        idxROI = ActiveROIIndex;
                    }
                }
                m_HControl.Repaint();
            }
            return ActiveROIIndex;
        }

        public int mouseRightDownCheck(double imgX, double imgY, out bool flag)
        {
            int RoiFrame = -1;
            if (ROIList.Count > 0)		// ... or an existing one is manipulated
            {

                if (Roiactive == -1)
                {
                    int temp = int.MaxValue;
                    int ROIarea;    //=-1 不在框內
                    for (int i = 0; i < ROIList.Count; i++)
                    {
                        ROIarea = ((ROIBase)ROIList[i]).ROIdistance(imgX, imgY);
                        if (ROIarea != -1)
                        {
                            if (ROIarea < temp)
                            {
                                temp = ROIarea;
                                RoiFrame = i;
                            }
                        }
                    }
                }
                m_HControl.Repaint();
            }
            flag = false;
            if (RoiFrame != -1)
            {
                if (((ROIBase)ROIList[RoiFrame]).ROIInfo.RegionType == 1)
                {
                    flag = true;
                }
            }
            return RoiFrame;
        }

        /// <summary>
        /// Reaction of ROI objects to the 'mouse button move' event: moving
        /// the active ROI.
        /// </summary>
        /// <param name="newX">x coordinate of mouse event</param>
        /// <param name="newY">y coordinate of mouse event</param>
        public void mouseMoveAction(double newX, double newY)
        {
            ((ROIBase)ROIList[ActiveROIIndex]).moveByHandle(newX, newY);
            defineModelROI();
            m_HControl.Repaint();
        }

        public void dummyI(int v)
        {

        }

        public void SaveSelectedROIImage()
        {
            SaveSelectedROIImage(this.ActiveROIIndex);
        }

        public void SaveSelectedROIImage(int index)
        {
            HObject cutHimage = new HObject();
            HTuple Row1 = ((ROIBase)ROIList[index]).ROIInfo.Y;
            HTuple Col1 = ((ROIBase)ROIList[index]).ROIInfo.X;
            HTuple Row2 = ((ROIBase)ROIList[index]).ROIInfo.Y + ((ROIBase)ROIList[index]).ROIInfo.Height - 1;
            HTuple Col2 = ((ROIBase)ROIList[index]).ROIInfo.X + ((ROIBase)ROIList[index]).ROIInfo.Width - 1;

            HTuple width, height, type, pointer;
            HOperatorSet.GetImagePointer1(this.m_HControl.GetHImage(true), out pointer, out type, out width, out height);

            Row1 = Row1 >= 0 ? Row1 : new HTuple(0);
            Col1 = Col1 >= 0 ? Col1 : new HTuple(0);
            Row2 = Row2 < height ? Row2 : height - 1;
            Col2 = Col2 < width ? Col2 : width - 1;

            HOperatorSet.CropRectangle1(this.m_HControl.GetHImage(false), out cutHimage, Row1, Col1, Row2, Col2);
            if (cutHimage == null)
            {
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = HImageFormat.AllFormat;
            saveFileDialog.FilterIndex = 2;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string extension = Path.GetExtension(saveFileDialog.FileName);
                extension = extension.Substring(1, extension.Length - 1);
                HOperatorSet.WriteImage(cutHimage, extension, 0, saveFileDialog.FileName);
            }
        }

        public void CropSelectedROIImage(HObject image, out HObject cutHimage)
        {
            if (image == null || ActiveROIIndex == -1)
            {
                cutHimage = null;
                return;
            }
            int Roi = ActiveROIIndex;
            HTuple Row1 = ((ROIBase)ROIList[Roi]).ROIInfo.Y;
            HTuple Col1 = ((ROIBase)ROIList[Roi]).ROIInfo.X;
            HTuple Row2 = ((ROIBase)ROIList[Roi]).ROIInfo.Y + ((ROIBase)ROIList[Roi]).ROIInfo.Height - 1;
            HTuple Col2 = ((ROIBase)ROIList[Roi]).ROIInfo.X + ((ROIBase)ROIList[Roi]).ROIInfo.Width - 1;
            HOperatorSet.CropRectangle1(image, out cutHimage, Row1, Col1, Row2, Col2);


        }

        public HObject TestCutModel(int Roi, HObject image)
        {
            HObject cutHimage = new HObject();
            HObject ho_modelCross, ho_modelContours;
            HOperatorSet.GenEmptyObj(out ho_modelCross);
            HOperatorSet.GenEmptyObj(out ho_modelContours);
            HTuple hv_ModelID, hv_ParameterName, hv_ParameterValue, Msg;
            HTuple TestRunTime, hv_Timeout;
            HTuple testScore = ((ROIBase)ROIList[Roi]).ROIInfo.testScore;
            HTuple testOverlap = ((ROIBase)ROIList[Roi]).ROIInfo.testOverlap;
            HTuple testNum = ((ROIBase)ROIList[Roi]).ROIInfo.testNum;
            HTuple Row1 = ((ROIBase)ROIList[Roi]).ROIInfo.Y;
            HTuple Col1 = ((ROIBase)ROIList[Roi]).ROIInfo.X;
            HTuple Row2 = ((ROIBase)ROIList[Roi]).ROIInfo.Y + ((ROIBase)ROIList[Roi]).ROIInfo.Height - 1;
            HTuple Col2 = ((ROIBase)ROIList[Roi]).ROIInfo.X + ((ROIBase)ROIList[Roi]).ROIInfo.Width - 1;
            HOperatorSet.CropRectangle1(image, out cutHimage, Row1, Col1, Row2, Col2);
            if (cutHimage == null)
            {
                return null;
            }
            HOperatorSet.DetermineShapeModelParams(cutHimage, "auto", -0.39, 0.79, 0.9,
               1.1, "auto", "use_polarity", "auto", "auto", "all", out hv_ParameterName,
               out hv_ParameterValue);
            HOperatorSet.CreateShapeModel(cutHimage, "auto", -0.39, 0.79, "auto", "auto",
            "use_polarity", ((((hv_ParameterValue.TupleSelect(4))).TupleConcat(hv_ParameterValue.TupleSelect(
            5)))).TupleConcat(hv_ParameterValue.TupleSelect(6)), hv_ParameterValue.TupleSelect(
            7), out hv_ModelID);
            //test_Find_shape_model(image, out ho_modelCross, out ho_modelContours, 1, hv_ModelID, 0.5, 1, 0.5, 0.7,1, out TestRunTime, out Msg);
            //------------------------------------------------
            //Timeout機制
            //hv_Timeout = ((TestRunTime * 1.5)).TupleFloor();
            //HOperatorSet.SetShapeModelParam(hv_ModelID, "timeout", hv_Timeout);
            //MessageBox.Show(hv_Timeout.ToString());
            //------------------------------------------------
            test_Find_shape_model(image, out ho_modelCross, out ho_modelContours, 1, hv_ModelID, testScore, testNum, testOverlap, 0.7, 0, out TestRunTime, out Msg);
            return ho_modelContours;
        }

        public void SaveCutModel(int Roi, HObject image)
        {
            HObject cutHimage = new HObject();
            HTuple hv_ModelID, hv_ParameterName, hv_ParameterValue;
            HTuple Row1 = ((ROIBase)ROIList[Roi]).ROIInfo.Y;
            HTuple Col1 = ((ROIBase)ROIList[Roi]).ROIInfo.X;
            HTuple Row2 = ((ROIBase)ROIList[Roi]).ROIInfo.Y + ((ROIBase)ROIList[Roi]).ROIInfo.Height - 1;
            HTuple Col2 = ((ROIBase)ROIList[Roi]).ROIInfo.X + ((ROIBase)ROIList[Roi]).ROIInfo.Width - 1;
            HOperatorSet.CropRectangle1(image, out cutHimage, Row1, Col1, Row2, Col2);
            if (cutHimage == null)
            {
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                HTuple hv_Path = Path.GetDirectoryName(saveFileDialog.FileName) + "\\" + Path.GetFileNameWithoutExtension(saveFileDialog.FileName);
                HOperatorSet.DetermineShapeModelParams(cutHimage, "auto", -0.39, 0.79, 0.9,
                1.1, "auto", "use_polarity", "auto", "auto", "all", out hv_ParameterName,
                out hv_ParameterValue);
                HOperatorSet.CreateShapeModel(cutHimage, "auto", -0.39, 0.79, "auto", "auto",
                "use_polarity", ((((hv_ParameterValue.TupleSelect(4))).TupleConcat(hv_ParameterValue.TupleSelect(
                5)))).TupleConcat(hv_ParameterValue.TupleSelect(6)), hv_ParameterValue.TupleSelect(
                7), out hv_ModelID);
                //HOperatorSet.CreateShapeModel(cutHimage, "auto", -0.3491, 0.3491,
                //    "auto", "auto", "use_polarity", "auto", "auto", out hv_ModelID);
                HOperatorSet.WriteImage(cutHimage, "bmp", 0, hv_Path + ".bmp");
                HOperatorSet.WriteShapeModel(hv_ModelID, hv_Path + ".shm");
                HOperatorSet.ClearShapeModel(hv_ModelID);
            }
        }

        public void test_Find_shape_model(HObject ho_Image, out HObject ho_modelCross,
            out HObject ho_modelContours, HTuple hv_Num_Model, HTuple hv_ModelID, HTuple hv_testScore,
            HTuple hv_testNum, HTuple hv_testOverlap, HTuple hv_testGreediness, HTuple hv_TestTimeoutMode,
            out HTuple hv_Runtime, out HTuple hv_Msg)
        {


            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];
            long SP_O = 0;

            // Local iconic variables 

            HObject ho_ModelContours = null, ho_TransContours = null;


            // Local control variables 

            HTuple hv_S1 = new HTuple(), hv_Loops = new HTuple();
            HTuple hv_ModelRow = new HTuple(), hv_ModelColumn = new HTuple();
            HTuple hv_ModelAngle = new HTuple(), hv_ModelScore = new HTuple();
            HTuple hv_S2 = new HTuple(), hv_MatchingObjIdx = new HTuple();
            HTuple hv_HomMat = new HTuple(), hv_Exception;

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_modelCross);
            HOperatorSet.GenEmptyObj(out ho_modelContours);
            HOperatorSet.GenEmptyObj(out ho_ModelContours);
            HOperatorSet.GenEmptyObj(out ho_TransContours);

            hv_Runtime = new HTuple();
            hv_Msg = new HTuple();
            try
            {
                HOperatorSet.CountSeconds(out hv_S1);
                if ((int)(new HTuple(hv_TestTimeoutMode.TupleEqual(0))) != 0)
                {
                    hv_Loops = 1;
                    HOperatorSet.FindShapeModel(ho_Image, hv_ModelID, -0.39, 0.78, hv_testScore,
                        hv_testNum, hv_testOverlap, "least_squares", 0, hv_testGreediness, out hv_ModelRow,
                        out hv_ModelColumn, out hv_ModelAngle, out hv_ModelScore);
                }
                else
                {
                    for (hv_Loops = 1; (int)hv_Loops <= 10; hv_Loops = (int)hv_Loops + 1)
                    {
                        HOperatorSet.FindShapeModel(ho_Image, hv_ModelID, -0.39, 0.78, hv_testScore,
                            1, hv_testOverlap, "least_squares", 0, hv_testGreediness, out hv_ModelRow,
                            out hv_ModelColumn, out hv_ModelAngle, out hv_ModelScore);
                    }
                }
                HOperatorSet.CountSeconds(out hv_S2);
                hv_Runtime = ((hv_S2 - hv_S1) * 1000.0) / hv_Loops;
                if ((int)(new HTuple((new HTuple(hv_ModelScore.TupleLength())).TupleNotEqual(
                    0))) != 0)
                {
                    ho_ModelContours.Dispose();
                    HOperatorSet.GetShapeModelContours(out ho_ModelContours, hv_ModelID, 1);
                    ho_modelContours.Dispose();
                    HOperatorSet.GenEmptyObj(out ho_modelContours);
                    for (hv_MatchingObjIdx = 0; (int)hv_MatchingObjIdx <= (int)((new HTuple(hv_ModelScore.TupleLength()
                        )) - 1); hv_MatchingObjIdx = (int)hv_MatchingObjIdx + 1)
                    {
                        HOperatorSet.HomMat2dIdentity(out hv_HomMat);
                        HOperatorSet.HomMat2dRotate(hv_HomMat, hv_ModelAngle.TupleSelect(hv_MatchingObjIdx),
                            0, 0, out hv_HomMat);
                        HOperatorSet.HomMat2dTranslate(hv_HomMat, hv_ModelRow.TupleSelect(hv_MatchingObjIdx),
                            hv_ModelColumn.TupleSelect(hv_MatchingObjIdx), out hv_HomMat);
                        ho_TransContours.Dispose();
                        HOperatorSet.AffineTransContourXld(ho_ModelContours, out ho_TransContours,
                            hv_HomMat);
                        OTemp[SP_O] = ho_modelContours.CopyObj(1, -1);
                        SP_O++;
                        ho_modelContours.Dispose();
                        HOperatorSet.ConcatObj(OTemp[SP_O - 1], ho_TransContours, out ho_modelContours
                            );
                        OTemp[SP_O - 1].Dispose();
                        SP_O = 0;
                    }
                    ho_modelCross.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_modelCross, hv_ModelRow, hv_ModelColumn,
                        100, 0);
                    hv_Msg = 0;
                }
                else
                {
                    hv_Msg = -1;
                }
            }
            // catch (Exception) 
            catch (HalconException HDevExpDefaultException)
            {
                HDevExpDefaultException.ToHTuple(out hv_Exception);
                hv_Msg = hv_Exception.Clone();
            }
            //ho_ModelContours.Dispose();
            ho_TransContours.Dispose();

            return;
        }
    }
}
