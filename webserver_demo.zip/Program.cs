var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// 靜態檔案支援 - 使用 ./static 資料夾
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(
        Path.Combine(Directory.GetCurrentDirectory(), "static")),
    RequestPath = ""
});

// 記憶體中的使用者資料
var users = new List<User>
{
    new User { Id = 1, Name = "張三", Email = "zhang@example.com" },
    new User { Id = 2, Name = "李四", Email = "li@example.com" },
    new User { Id = 3, Name = "王五", Email = "wang@example.com" }
};

// 首頁路由
app.MapGet("/", () => "歡迎使用混合 Web 伺服器！");

// 伺服器時間 API
app.MapGet("/api/time", () => new { 
    serverTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
    timestamp = DateTimeOffset.Now.ToUnixTimeSeconds()
});

// 使用者 CRUD API
app.MapGet("/api/users", () => users);

app.MapGet("/api/users/{id}", (int id) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    return user is not null ? Results.Ok(user) : Results.NotFound("找不到使用者");
});

app.MapPost("/api/users", (User user) =>
{
    user.Id = users.Max(u => u.Id) + 1;
    users.Add(user);
    return Results.Created($"/api/users/{user.Id}", user);
});

app.MapPut("/api/users/{id}", (int id, User updatedUser) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    if (user is null) return Results.NotFound("找不到使用者");
    
    user.Name = updatedUser.Name;
    user.Email = updatedUser.Email;
    return Results.Ok(user);
});

app.MapDelete("/api/users/{id}", (int id) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    if (user is null) return Results.NotFound("找不到使用者");
    
    users.Remove(user);
    return Results.Ok("使用者已刪除");
});

Console.WriteLine("伺服器啟動於 http://localhost:5000");
Console.WriteLine("API 端點:");
Console.WriteLine("  GET    /api/time       - 取得伺服器時間");
Console.WriteLine("  GET    /api/users      - 取得所有使用者");
Console.WriteLine("  GET    /api/users/{id} - 取得特定使用者");
Console.WriteLine("  POST   /api/users      - 新增使用者");
Console.WriteLine("  PUT    /api/users/{id} - 更新使用者");
Console.WriteLine("  DELETE /api/users/{id} - 刪除使用者");

app.Run();

public class User
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}