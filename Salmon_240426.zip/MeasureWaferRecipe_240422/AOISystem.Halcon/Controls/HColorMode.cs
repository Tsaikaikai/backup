﻿namespace AOISystem.Halcon.Controls
{
    public enum HColorMode
    {
        black,
        white,
        red,
        green,
        blue,
        dim_gray,
        gray,
        light_gray,
        cyan,
        magenta,
        yellow,
        medium_slate_blue,
        coral,
        slate_blue,
        spring_green,
        orange_red,
        orange,
        dark_olive_green,
        pink,
        cadet_blue
    }
}
