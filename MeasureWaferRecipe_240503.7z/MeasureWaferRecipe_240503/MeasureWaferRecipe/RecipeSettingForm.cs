﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeasureWaferRecipe
{
    public partial class FormBootConfig : Form
    {
        private CAlgorithmConfig config = null;
        private string configPath = "./AlgorithmConfig.xml";

        public FormBootConfig()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (config.WriteXmlConfig(configPath))
            {
                MessageBox.Show("Save Successful", "Save");
            }

        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Config File |*.xml";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                config = config.ReadXmlConfig(openFileDialog.FileName);
                propertyGrid.SelectedObject = config;
            }
        }

        public void SetConfig(string configPath)
        {
            this.configPath = configPath.Trim();
            try
            {
                config = new CAlgorithmConfig();
                config = config.ReadXmlConfig(configPath);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void FormBootConfig_Load(object sender, EventArgs e)
        {
            config = config.ReadXmlConfig(configPath);
            propertyGrid.SelectedObject = config;
        }
    }
}
