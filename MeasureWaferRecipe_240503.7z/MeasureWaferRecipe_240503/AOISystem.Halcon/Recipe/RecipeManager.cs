﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AOISystem.Halcon.Recipe
{
    public static class RecipeManager
    {
        private const string Xml_Root_Node = "Document";
        private const string Xml_Collection_Node = "Collection";
        private const string Xml_Recipe_Node = "Recipe";

        private const string Recipe_Root_Path = "Recipe\\";
        private const string Recipe_Flie_Path = "Recipe\\Recipe.xml";

        public static string RecipeRootPath
        {
            get
            {
                string recipeRootPath = string.Format(@"{0}\{1}", Application.StartupPath, Recipe_Root_Path);
                if (!Directory.Exists(recipeRootPath))
                {
                    Directory.CreateDirectory(recipeRootPath);
                }
                return recipeRootPath;
            }
        }

        public static string RecipeFliePath
        {
            get
            {
                string recipeFliePath = string.Format(@"{0}\{1}", Application.StartupPath, Recipe_Flie_Path);
                if (!File.Exists(recipeFliePath))
                {
                    throw new Exception(string.Format("{0}檔案路徑不存在", recipeFliePath));
                }
                return recipeFliePath;
            }
        }

        public static RecipeInfo ActiveRecipe { get; set; }

        #region - Recipe Operation Methods -
        public static RecipeInfoCollection GetRecipeCollection()
        {
            return GetRecipeCollection(RecipeFliePath);
        }

        public static RecipeInfoCollection GetRecipeCollection(string path)
        {
            XDocument xDoc = XDocument.Load(path);
            RecipeInfoCollection recipeCollection = new RecipeInfoCollection();

            foreach (XElement element in xDoc.Element(Xml_Root_Node).Element(Xml_Collection_Node).Elements())
            {
                recipeCollection.Add(new RecipeInfo()
                {
                    RecipeNo = (int)element.Attribute("RecipeNo"),
                    RecipeID = (string)element.Attribute("RecipeID"),
                    Active = (bool)element.Attribute("Active"),
                    ModifyTime = (DateTime)element.Attribute("ModifyTime"),
                    Description = (string)element.Attribute("Description")
                });
            }
            return recipeCollection;
        }

        public static void SetRecipeCollection(RecipeInfoCollection recipeCollection)
        {
            string recipeFliePath = string.Format(@"{0}\{1}", Application.StartupPath, Recipe_Flie_Path);
            SetRecipeCollection(recipeFliePath, recipeCollection);
        }

        public static void SetRecipeCollection(string path, RecipeInfoCollection recipeCollection)
        {
            XDocument xDoc;
            if (System.IO.File.Exists(path) == false)
            {
                xDoc = new XDocument();
                XElement rootElement = new XElement(Xml_Root_Node);
                XElement collectionElement = new XElement(Xml_Collection_Node);

                rootElement.Add(collectionElement);
                xDoc.Add(rootElement);
            }
            else
            {
                xDoc = XDocument.Load(path);
            }

            xDoc.Element(Xml_Root_Node).Element(Xml_Collection_Node).RemoveNodes();
            foreach (RecipeInfo recipe in recipeCollection)
            {
                xDoc.Element(Xml_Root_Node).Element(Xml_Collection_Node).Add(
                    new XElement(Xml_Recipe_Node,
                        new XAttribute("RecipeNo", recipe.RecipeNo),
                        new XAttribute("Active", recipe.Active),
                        new XAttribute("RecipeID", recipe.RecipeID),
                        new XAttribute("ModifyTime", recipe.ModifyTime.ToString("yyyy.MM.dd HH:mm:ss")),
                        new XAttribute("Description", recipe.Description)
                        ));
            }
            xDoc.Save(path);
        }
        #endregion - Recipe Operation Methods -
    }
}
