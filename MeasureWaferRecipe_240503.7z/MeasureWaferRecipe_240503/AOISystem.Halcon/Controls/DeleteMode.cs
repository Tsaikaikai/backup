﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOISystem.Halcon.Controls
{
    public enum DeleteMode
    {
        Match,
        UnMatch
    }
}
