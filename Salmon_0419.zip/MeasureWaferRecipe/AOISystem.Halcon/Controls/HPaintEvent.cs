﻿using System;
using System.Drawing;

namespace AOISystem.Halcon.Controls
{
    /// <summary>
    /// HControl Paint Handler
    /// </summary>
    public delegate void HPaintEventHandler(object sender, HPaintEventArgs e);

    /// <summary>
    /// Hcontrol Paint Event Args
    /// </summary>
    public class HPaintEventArgs : EventArgs
    {
        public int X;
        public int Y;
        public Point Location;
        public int Value;
        public float Zoom;

        public int Width;
        public int Height;

        public HPaintEventArgs(int x, int y, int value, float zoom)
        {
            this.X = x;
            this.Y = y;
            this.Value = value;
            Location = new Point(x, y);
            this.Zoom = zoom;
        }

        public HPaintEventArgs(Size paintSize)
        {
            this.Width = paintSize.Width;
            this.Height = paintSize.Height;
        }
    }
}
