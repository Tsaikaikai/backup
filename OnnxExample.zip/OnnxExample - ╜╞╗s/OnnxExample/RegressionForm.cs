﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Runtime.InteropServices;
using Emgu.CV.Util;
using Brandy;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class RegressionForm : Form
    {
        RegressionModel core = null;
        String[] filenames = null;
        Mat[] inputImages = null;
        int[] inputshape = null;
        int[] outputshape = null
            ;
        List<RegressionItem> results = null;
        public RegressionForm()
        {
            InitializeComponent();
            UpdateListBoxItem(typeof(RegressionMode), cbx_modelType);
            cbx_modelType.SelectedIndex = 0;
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Onnx file |*.onnx";
            try
            {
                if (op.ShowDialog() == DialogResult.OK)
                {
                    int gpuid = (int)numericUpDown1.Value;
                    core = new RegressionModel(op.FileName, gpuid);
                    inputshape = core.InputShape;
                    outputshape = core.OutputShape;

                    string shapeinf = "InputShape：";
                    for (int i = 0; i < inputshape.Length; i++)
                    {
                        shapeinf += inputshape[i].ToString();
                        if ((i + 1) != inputshape.Length)
                            shapeinf += "*";
                    }
                    shapeinf += Environment.NewLine + "OutputShape：";
                    for (int i = 0; i < outputshape.Length; i++)
                    {
                        shapeinf += outputshape[i].ToString();
                        if ((i + 1) != outputshape.Length)
                            shapeinf += "*";
                    }

                    textBox2.Text = shapeinf;
                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                    numericUpDown1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("載入模型錯誤，請確認載入類型");
            }
        }
        private void btn_freeModel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;

                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void btn_openImage_Click(object sender, EventArgs e)
        {
            FreeObjects();
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            op.Multiselect = true;
            if (op.ShowDialog() == DialogResult.OK)
            {
                filenames = op.FileNames;
                inputImages = new Mat[filenames.Length];
                for (int i = 0; i < filenames.Length; i++)
                {
                    inputImages[i] = CvInvoke.Imread(filenames[i], Emgu.CV.CvEnum.ImreadModes.Unchanged);
                    if (inputImages[i].Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                    {
                        CvInvoke.ConvertScaleAbs(inputImages[i], inputImages[i], 0.0625, 0);
                        inputImages[i].ConvertTo(inputImages[i], Emgu.CV.CvEnum.DepthType.Cv8U);
                    }
                    if (inputImages[i].NumberOfChannels > 3)
                        CvInvoke.CvtColor(inputImages[i], inputImages[i], Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                }
                pictureBoxSrc.Image = inputImages[0].Bitmap;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImages == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
                RegressionMode type = (RegressionMode)cbx_modelType.SelectedIndex;
                Stopwatch sw = new Stopwatch();
                sw.Start();
                results = new List<RegressionItem>();
                for (int i = 0; i < inputImages.Length; i++)
                {
                    results.Add(new RegressionItem(filenames[i]));
                    Mat img = new Mat();
                    inputImages[i].CopyTo(img);

                    img = GetRotateImage(img, type);
                    if (img.NumberOfChannels > 1)
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }
                    img.ConvertTo(img, Emgu.CV.CvEnum.DepthType.Cv32F);
                    float[] inputData = Mat_chw(img);
                    Brandy.ImageChannel ch = Brandy.ImageChannel.RGBPlanner;
                    if (img.NumberOfChannels == 1)
                        ch = Brandy.ImageChannel.Gray;
                    BrandyImage input = new BrandyImage(inputData, ch, img.Width, img.Height);
                    if (core.Inference(input))
                    {
                        float[] result = core.Output;
                        results[i].Result = DataToString(result);
                        results[i].ResultData = result;
                    }
                }
                sw.Stop();
                dataGridViewResult.DataSource = results;
                dataGridViewResult.Invalidate();
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";

                if (ckb_showResult.Checked)
                {
                    var source = (List<RegressionItem>)dataGridViewResult.DataSource;
                    RegressionItem item = source[0];

                    pictureBoxSrc.Image = DrawResultLine(inputImages[0],
                        item.ResultData, type).Bitmap;
                }
                else
                {
                    pictureBoxSrc.Image = inputImages[0].Bitmap;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        float[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            float[] chwData = new float[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }

        void FreeObjects()
        {
            pictureBoxSrc.Image=null;
            if(inputImages!=null)
            {
                for (int i = 0; i < inputImages.Length; i++)
                {
                    if (inputImages[i]!=null)
                    {
                        inputImages[i].Dispose();
                        inputImages[i] = null;
                    }
                }
                inputImages = null;
            }
            filenames = null;
            dataGridViewResult.DataSource = null;
            results = null;
        }

        private void RegressionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            FreeObjects();
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (inputImages == null)
                    return;

                if (!this.dataGridViewResult.Focused)
                    return;

                int index = this.dataGridViewResult.CurrentRow.Index;
                RegressionMode type = (RegressionMode)cbx_modelType.SelectedIndex;
                if (inputImages[index] != null)
                {
                    if(ckb_showResult.Checked)
                    {
                        var source = (List<RegressionItem>)dataGridViewResult.DataSource;
                        RegressionItem item = source[index];

                        pictureBoxSrc.Image = DrawResultLine(inputImages[index], 
                            item.ResultData, type).Bitmap;
                    }
                    else
                    {
                        pictureBoxSrc.Image = GetRotateImage(inputImages[index], type).Bitmap;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }


        }
        private String DataToString(float[] data)
        {
            string result = string.Empty;
            if(data != null)
            {
                for (int i = 0; i < data.Length; i++)
                {
                    var temp = data[i];
                    result += temp.ToString("#0.000");
                    if(i != data.Length-1)
                    {
                        result += ",";
                    }
                }
            }

            return result;
        }
        private Mat DrawResultLine(Mat image , float[] data ,RegressionMode mode)
        {
            Mat resultimg = image.Clone();
            resultimg = GetRotateImage(resultimg, mode);
            if (resultimg.NumberOfChannels ==1)
            {
                CvInvoke.CvtColor(resultimg, resultimg, Emgu.CV.CvEnum.ColorConversion.Gray2Bgr);
            }
            else if (resultimg.NumberOfChannels > 3)
            {
                CvInvoke.CvtColor(resultimg, resultimg, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
            }

            for (int i = 0; i < data.Length; i++)
            {
                int width = resultimg.Width;
                int height = resultimg.Height;
                int x = (int)(data[i] * width);
                CvInvoke.Line(resultimg, new Point(x, 0), new Point(x, height - 1),
                    new MCvScalar(0, 0, 255));
            }

            switch (mode)
            {
                case RegressionMode.Vertical:
                    break;
                case RegressionMode.Horizontal:
                    CvInvoke.Rotate(resultimg, resultimg, Emgu.CV.CvEnum.RotateFlags.Rotate90Clockwise);
                    break;
                default:
                    break;
            }

            return resultimg;
        }

        private Mat GetRotateImage(Mat image, RegressionMode mode)
        {
            Mat resultimg = image.Clone();
            RegressionMode type = (RegressionMode)cbx_modelType.SelectedIndex;
            switch (type)
            {
                case RegressionMode.Vertical:
                    break;
                case RegressionMode.Horizontal:
                    CvInvoke.Rotate(resultimg, resultimg, Emgu.CV.CvEnum.RotateFlags.Rotate90CounterClockwise);
                    break;
                default:
                    break;
            }
            return resultimg;
        }

        private void ckb_showResult_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.dataGridViewResult.DataSource == null)
                    return;

                int index = this.dataGridViewResult.CurrentRow.Index;

                if (inputImages[index] != null)
                {
                    RegressionMode type = (RegressionMode)cbx_modelType.SelectedIndex;
                    if (ckb_showResult.Checked)
                    {
                        var source = (List<RegressionItem>)dataGridViewResult.DataSource;
                        RegressionItem item = source[index];
                        pictureBoxSrc.Image = DrawResultLine(inputImages[index], item.ResultData,
                            type).Bitmap;
                    }
                    else
                    {
           
                        pictureBoxSrc.Image = inputImages[index].Bitmap;
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        private void UpdateListBoxItem(Type EnumType, ComboBox Box)
        {
            Box.Items.Clear();
            if (EnumType == null)
                return;
            Array Values = System.Enum.GetValues(EnumType);
            foreach (int Value in Values)
            {
                string Display = Enum.GetName(EnumType, Value);
                Box.Items.Add(Display);
            }
        }

        private void cbx_modelType_SelectedIndexChanged(object sender, EventArgs e)
        {
            FreeObjects();
        }

    }
    public class RegressionItem
    {
        public String path { get; set; }
        public string Result { get; set; } = string.Empty;
        public float[] ResultData { get; set; } = null;
        public RegressionItem(String filepath)
        {
            path = filepath;
        }
    }
    
    public enum RegressionMode
    {
        Vertical,
        Horizontal,
    };
}
