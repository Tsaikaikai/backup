﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void btn_CycleGan_Click(object sender, EventArgs e)
        {
            CycleGanForm form = new CycleGanForm();
            form.ShowDialog();
        }
        private void btn_Ganormaly_Click(object sender, EventArgs e)
        {
            GanormalyForm form = new GanormalyForm();
            form.ShowDialog();
        }
        private void btn_Classification_Click(object sender, EventArgs e)
        {
            ClassificationForm form = new ClassificationForm();
            form.ShowDialog();
        }

        private void btn_Yolo_Click(object sender, EventArgs e)
        {
            YoloForm form = new YoloForm();
            form.ShowDialog();
        }

        private void btn_STPM_Click(object sender, EventArgs e)
        {
            StpmForm form = new StpmForm();
            form.ShowDialog();
        }

        private void btn_Regression_Click(object sender, EventArgs e)
        {
            RegressionForm form = new RegressionForm();
            form.ShowDialog();
        }

        private void btn_MaskRcnn_Click(object sender, EventArgs e)
        {
            MaskRcnnForm form = new MaskRcnnForm();
            form.ShowDialog();
        }

        private void btn_Yolo_V7_Click(object sender, EventArgs e)
        {
            YoloV7Form form = new YoloV7Form();
            form.ShowDialog();
        }

        private void btn_ChangeDetection_Click(object sender, EventArgs e)
        {
            ChangeDetectionForm form = new ChangeDetectionForm();
            form.ShowDialog();
        }
    }
}
