﻿
namespace WindowsFormsApp1
{
    partial class RegressionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_loadModel = new System.Windows.Forms.Button();
            this.btn_freeModel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btn_Inference = new System.Windows.Forms.Button();
            this.btn_openImage = new System.Windows.Forms.Button();
            this.label_result = new System.Windows.Forms.Label();
            this.pictureBoxSrc = new System.Windows.Forms.PictureBox();
            this.dataGridViewResult = new System.Windows.Forms.DataGridView();
            this.ColumnPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnResult = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.ckb_showResult = new System.Windows.Forms.CheckBox();
            this.cbx_modelType = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_loadModel
            // 
            this.btn_loadModel.Location = new System.Drawing.Point(12, 12);
            this.btn_loadModel.Name = "btn_loadModel";
            this.btn_loadModel.Size = new System.Drawing.Size(76, 36);
            this.btn_loadModel.TabIndex = 2;
            this.btn_loadModel.Text = "LoadModel";
            this.btn_loadModel.UseVisualStyleBackColor = true;
            this.btn_loadModel.Click += new System.EventHandler(this.btn_loadModel_Click);
            // 
            // btn_freeModel
            // 
            this.btn_freeModel.Enabled = false;
            this.btn_freeModel.Location = new System.Drawing.Point(12, 54);
            this.btn_freeModel.Name = "btn_freeModel";
            this.btn_freeModel.Size = new System.Drawing.Size(76, 36);
            this.btn_freeModel.TabIndex = 3;
            this.btn_freeModel.Text = "FreeModel";
            this.btn_freeModel.UseVisualStyleBackColor = true;
            this.btn_freeModel.Click += new System.EventHandler(this.btn_freeModel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(94, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Gpu";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(94, 54);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(38, 22);
            this.numericUpDown1.TabIndex = 5;
            // 
            // btn_Inference
            // 
            this.btn_Inference.Enabled = false;
            this.btn_Inference.Location = new System.Drawing.Point(12, 144);
            this.btn_Inference.Name = "btn_Inference";
            this.btn_Inference.Size = new System.Drawing.Size(107, 71);
            this.btn_Inference.TabIndex = 6;
            this.btn_Inference.Text = "Run";
            this.btn_Inference.UseVisualStyleBackColor = true;
            this.btn_Inference.Click += new System.EventHandler(this.btn_Inference_Click);
            // 
            // btn_openImage
            // 
            this.btn_openImage.Location = new System.Drawing.Point(12, 100);
            this.btn_openImage.Name = "btn_openImage";
            this.btn_openImage.Size = new System.Drawing.Size(76, 38);
            this.btn_openImage.TabIndex = 7;
            this.btn_openImage.Text = "Open Image";
            this.btn_openImage.UseVisualStyleBackColor = true;
            this.btn_openImage.Click += new System.EventHandler(this.btn_openImage_Click);
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_result.Location = new System.Drawing.Point(8, 373);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(62, 24);
            this.label_result.TabIndex = 9;
            this.label_result.Text = "0:ms";
            // 
            // pictureBoxSrc
            // 
            this.pictureBoxSrc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxSrc.Location = new System.Drawing.Point(188, 12);
            this.pictureBoxSrc.Name = "pictureBoxSrc";
            this.pictureBoxSrc.Size = new System.Drawing.Size(605, 395);
            this.pictureBoxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSrc.TabIndex = 10;
            this.pictureBoxSrc.TabStop = false;
            // 
            // dataGridViewResult
            // 
            this.dataGridViewResult.AllowUserToAddRows = false;
            this.dataGridViewResult.AllowUserToDeleteRows = false;
            this.dataGridViewResult.AllowUserToResizeColumns = false;
            this.dataGridViewResult.AllowUserToResizeRows = false;
            this.dataGridViewResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewResult.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnPath,
            this.ColumnResult});
            this.dataGridViewResult.Location = new System.Drawing.Point(12, 413);
            this.dataGridViewResult.MultiSelect = false;
            this.dataGridViewResult.Name = "dataGridViewResult";
            this.dataGridViewResult.ReadOnly = true;
            this.dataGridViewResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewResult.Size = new System.Drawing.Size(781, 146);
            this.dataGridViewResult.TabIndex = 11;
            this.dataGridViewResult.SelectionChanged += new System.EventHandler(this.dataGridViewResult_SelectionChanged);
            // 
            // ColumnPath
            // 
            this.ColumnPath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ColumnPath.DataPropertyName = "Path";
            this.ColumnPath.HeaderText = "Path";
            this.ColumnPath.Name = "ColumnPath";
            this.ColumnPath.ReadOnly = true;
            this.ColumnPath.Width = 50;
            // 
            // ColumnResult
            // 
            this.ColumnResult.DataPropertyName = "Result";
            this.ColumnResult.HeaderText = "Result";
            this.ColumnResult.Name = "ColumnResult";
            this.ColumnResult.ReadOnly = true;
            this.ColumnResult.Width = 59;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 247);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(170, 41);
            this.textBox2.TabIndex = 12;
            // 
            // ckb_showResult
            // 
            this.ckb_showResult.AutoSize = true;
            this.ckb_showResult.Location = new System.Drawing.Point(12, 330);
            this.ckb_showResult.Name = "ckb_showResult";
            this.ckb_showResult.Size = new System.Drawing.Size(79, 16);
            this.ckb_showResult.TabIndex = 13;
            this.ckb_showResult.Text = "ShowResult";
            this.ckb_showResult.UseVisualStyleBackColor = true;
            this.ckb_showResult.CheckedChanged += new System.EventHandler(this.ckb_showResult_CheckedChanged);
            // 
            // cbx_modelType
            // 
            this.cbx_modelType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_modelType.FormattingEnabled = true;
            this.cbx_modelType.Location = new System.Drawing.Point(12, 221);
            this.cbx_modelType.Name = "cbx_modelType";
            this.cbx_modelType.Size = new System.Drawing.Size(107, 20);
            this.cbx_modelType.TabIndex = 14;
            this.cbx_modelType.SelectedIndexChanged += new System.EventHandler(this.cbx_modelType_SelectedIndexChanged);
            // 
            // RegressionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 571);
            this.Controls.Add(this.cbx_modelType);
            this.Controls.Add(this.ckb_showResult);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.dataGridViewResult);
            this.Controls.Add(this.pictureBoxSrc);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.btn_Inference);
            this.Controls.Add(this.btn_openImage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btn_freeModel);
            this.Controls.Add(this.btn_loadModel);
            this.Name = "RegressionForm";
            this.Text = "Regression";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegressionForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_loadModel;
        private System.Windows.Forms.Button btn_freeModel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btn_Inference;
        private System.Windows.Forms.Button btn_openImage;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.PictureBox pictureBoxSrc;
        private System.Windows.Forms.DataGridView dataGridViewResult;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnResult;
        private System.Windows.Forms.CheckBox ckb_showResult;
        private System.Windows.Forms.ComboBox cbx_modelType;
    }
}