﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Runtime.InteropServices;
using Emgu.CV.Util;
using Brandy;

namespace WindowsFormsApp1
{
    public partial class GanormalyForm : Form
    {
        GanormalyModel core = null;
        int[] inputshape = null;
        int[] outputshape = null;
        Mat inputImage = null;
        Mat outputImage = null;
        public GanormalyForm()
        {
            InitializeComponent();
            cbx_InferenceMode.SelectedIndex = 0;
        }

        float[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            float[] chwData = new float[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }
        Mat chw_Mat(float[] data, int c, int w, int h)
        {
            if (c * w * h != data.Length)
                return null;
            if (c > 1)
            {
                Mat image = new Mat(new Size(w, h), Emgu.CV.CvEnum.DepthType.Cv32F, c);
                VectorOfMat matVector = new VectorOfMat();
                Mat[] channels = image.Split();
                for (int i = 0; i < channels.Length; i++)
                {
                    Marshal.Copy(data, i * w * h, channels[i].DataPointer, w * h);
                    matVector.Push(channels[i]);
                }

                CvInvoke.Merge(matVector, image);
                return image;
            }
            else
            {
                Mat image = new Mat(new Size(w, h), Emgu.CV.CvEnum.DepthType.Cv32F, 1);
                Marshal.Copy(data, 0, image.DataPointer, w * h);
                return image;
            }
        }

        void chw_Mat(float[] data, int c, int w, int h, Mat output)
        {
            if (c * w * h != data.Length)
                return;
            if (c > 1)
            {
                Mat image = output;
                VectorOfMat matVector = new VectorOfMat();
                Mat[] channels = image.Split();
                for (int i = 0; i < channels.Length; i++)
                {
                    Marshal.Copy(data, i * w * h, channels[i].DataPointer, w * h);
                    matVector.Push(channels[i]);
                }

                CvInvoke.Merge(matVector, image);
            }
            else
            {
                Mat image = output;
                Marshal.Copy(data, 0, image.DataPointer, w * h);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Onnx file |*.onnx";
            try
            {
                if (op.ShowDialog() == DialogResult.OK)
                {
                    int gpuid = (int)numericUpDown1.Value;

                    core = new GanormalyModel(op.FileName, gpuid);
                    core.IsCalculateFator = true;
                    inputshape = core.InputShape;
                    outputshape = core.OutputShape;

                    string shapeinf = "InputShape：";
                    for (int i = 0; i < inputshape.Length; i++)
                    {
                        shapeinf += inputshape[i].ToString();
                        if ((i + 1) != inputshape.Length)
                            shapeinf += "*";
                    }
                    shapeinf += Environment.NewLine + "OutputShape：";
                    for (int i = 0; i < outputshape.Length; i++)
                    {
                        shapeinf += outputshape[i].ToString();
                        if ((i + 1) != outputshape.Length)
                            shapeinf += "*";
                    }
                    textBox2.Text = shapeinf;
                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                    numericUpDown1.Enabled = false;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("載入模型錯誤，請確認載入類型");
            }
        }
        private void btn_freeModel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void btn_openImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {
                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage.Bitmap;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {

            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }

                Mat img = new Mat();
                inputImage.CopyTo(img);
                img.Save("./input.tif");
                if (cbx_InferenceMode.SelectedIndex == 0)
                {
                    if (img.NumberOfChannels == 3)
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }

                    img.ConvertTo(img, Emgu.CV.CvEnum.DepthType.Cv32F);
                    float[] inputData = Mat_chw(img);
                    Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                    if (img.NumberOfChannels == 1)
                        type = Brandy.ImageChannel.Gray;

                    BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);
                    Stopwatch sw = new Stopwatch();
                    sw.Start();
                    if (core.Inference(input))
                    {
                        sw.Stop();
                    }
                    BrandyImage outImage = core.OutputImage;
                    outImage.RGB2BGR();
                    outImage.Save("./output.tif");
                    pictureBoxResult.Image = outImage.Bitmap;


                    label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
                    label2.Text = "Abnormal：" + core.AbnormalFactor.ToString("#0.000");

                }
                else
                {
                    if (img.Height < inputshape[2])
                    {
                        CvInvoke.Resize(img, img, new Size(inputshape[2], img.Width), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                    }
                    if (img.Width < inputshape[3])
                    {
                        CvInvoke.Resize(img, img, new Size(img.Height, inputshape[3]), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                    }

                    if (inputshape[1] > 1)
                    {
                        if (img.NumberOfChannels != 3)
                        {
                            CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Gray2Rgb);
                        }
                        else
                        {
                            CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                        }
                    }
                    else
                    {
                        if (img.NumberOfChannels == 3)
                        {
                            CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Rgb2Gray);
                        }
                    }

                    if (outputImage != null)
                    {
                        outputImage.Dispose();
                        outputImage = null;
                    }
                    outputImage = new Mat();
                    img.CopyTo(outputImage);
                    outputImage.ConvertTo(outputImage, Emgu.CV.CvEnum.DepthType.Cv32F);

                    Rectangle roi = new Rectangle(0, 0, inputshape[3], inputshape[2]);

                    int xTimes = (int)Math.Ceiling((img.Width - inputshape[3]) / (double)inputshape[3]) + 1;
                    int yTimes = (int)Math.Ceiling((img.Height - inputshape[2]) / (double)inputshape[2]) + 1;

                    Mat roiInput = new Mat(roi.Size, img.Depth, img.NumberOfChannels);
                    Mat roiOutput = new Mat(roi.Size, outputImage.Depth, outputImage.NumberOfChannels);

                    Stopwatch sw = new Stopwatch();
                    sw.Start();

                    for (int y = 0; y < yTimes; y++)
                    {
                        for (int x = 0; x < xTimes; x++)
                        {
                            int pointx = x * inputshape[3];
                            int pointy = y * inputshape[2];

                            int endx = pointx + inputshape[3];
                            int endy = pointy + inputshape[2];
                            if (endx >= img.Width)
                            {
                                pointx = (int)img.Width - inputshape[3];
                                endx = (int)inputshape[3] - 1;
                            }
                            if (endy >= img.Height)
                            {
                                pointy = (int)img.Height - inputshape[2];
                                endy = (int)img.Height - 1;
                            }
                            roi.X = pointx;
                            roi.Y = pointy;

                            Mat temp = new Mat(img, roi);
                            temp.CopyTo(roiInput);
                            roiInput.ConvertTo(roiInput, Emgu.CV.CvEnum.DepthType.Cv32F);

                            float[] inputData = Mat_chw(roiInput);
                            Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                            if (roiInput.NumberOfChannels == 1)
                                type = Brandy.ImageChannel.Gray;
                            BrandyImage input = new BrandyImage(inputData, type, roiInput.Width, roiInput.Height);

                            if (core.Inference(input))
                            {
                                float[] result = core.Output;
                                chw_Mat(result, inputshape[1], inputshape[2], inputshape[3], roiOutput);
                                Mat outtemp = new Mat(outputImage, roi);
                                roiOutput.CopyTo(outtemp);
                            }
                        }
                    }
                    outputImage.ConvertTo(outputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                    if (outputImage.NumberOfChannels > 1)
                        CvInvoke.CvtColor(outputImage, outputImage, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    pictureBoxResult.Image = outputImage.Bitmap;

                    sw.Stop();
                    label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
                    outputImage.Save("./output.tif");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }


        }
    }
}
