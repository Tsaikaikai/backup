﻿
namespace WindowsFormsApp1
{
    partial class MaskRcnnForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_loadModel = new System.Windows.Forms.Button();
            this.btn_freeModel = new System.Windows.Forms.Button();
            this.btn_openimage = new System.Windows.Forms.Button();
            this.pictureBoxSrc = new System.Windows.Forms.PictureBox();
            this.btn_Inference = new System.Windows.Forms.Button();
            this.label_result = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dataGridViewResult = new System.Windows.Forms.DataGridView();
            this.ColumnLabel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnScore = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnBox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBoxMask = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMask)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_loadModel
            // 
            this.btn_loadModel.Location = new System.Drawing.Point(12, 10);
            this.btn_loadModel.Name = "btn_loadModel";
            this.btn_loadModel.Size = new System.Drawing.Size(87, 34);
            this.btn_loadModel.TabIndex = 0;
            this.btn_loadModel.Text = "Load Model";
            this.btn_loadModel.UseVisualStyleBackColor = true;
            this.btn_loadModel.Click += new System.EventHandler(this.btn_loadModel_Click);
            // 
            // btn_freeModel
            // 
            this.btn_freeModel.Enabled = false;
            this.btn_freeModel.Location = new System.Drawing.Point(12, 50);
            this.btn_freeModel.Name = "btn_freeModel";
            this.btn_freeModel.Size = new System.Drawing.Size(87, 36);
            this.btn_freeModel.TabIndex = 4;
            this.btn_freeModel.Text = "Free Model";
            this.btn_freeModel.UseVisualStyleBackColor = true;
            this.btn_freeModel.Click += new System.EventHandler(this.btn_freemodel_Click);
            // 
            // btn_openimage
            // 
            this.btn_openimage.Location = new System.Drawing.Point(12, 92);
            this.btn_openimage.Name = "btn_openimage";
            this.btn_openimage.Size = new System.Drawing.Size(87, 36);
            this.btn_openimage.TabIndex = 4;
            this.btn_openimage.Text = "open image";
            this.btn_openimage.UseVisualStyleBackColor = true;
            this.btn_openimage.Click += new System.EventHandler(this.btn_openimage_Click);
            // 
            // pictureBoxSrc
            // 
            this.pictureBoxSrc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxSrc.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxSrc.Name = "pictureBoxSrc";
            this.pictureBoxSrc.Size = new System.Drawing.Size(808, 496);
            this.pictureBoxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSrc.TabIndex = 5;
            this.pictureBoxSrc.TabStop = false;
            // 
            // btn_Inference
            // 
            this.btn_Inference.Enabled = false;
            this.btn_Inference.Location = new System.Drawing.Point(12, 134);
            this.btn_Inference.Name = "btn_Inference";
            this.btn_Inference.Size = new System.Drawing.Size(107, 71);
            this.btn_Inference.TabIndex = 6;
            this.btn_Inference.Text = "Run";
            this.btn_Inference.UseVisualStyleBackColor = true;
            this.btn_Inference.Click += new System.EventHandler(this.btn_Inference_Click);
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_result.Location = new System.Drawing.Point(8, 267);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(62, 24);
            this.label_result.TabIndex = 7;
            this.label_result.Text = "0:ms";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(117, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "Gpu";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(117, 41);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(38, 22);
            this.numericUpDown1.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 211);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(170, 41);
            this.textBox2.TabIndex = 13;
            // 
            // dataGridViewResult
            // 
            this.dataGridViewResult.AllowUserToAddRows = false;
            this.dataGridViewResult.AllowUserToDeleteRows = false;
            this.dataGridViewResult.AllowUserToResizeColumns = false;
            this.dataGridViewResult.AllowUserToResizeRows = false;
            this.dataGridViewResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewResult.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnLabel,
            this.ColumnScore,
            this.ColumnBox});
            this.dataGridViewResult.Location = new System.Drawing.Point(12, 552);
            this.dataGridViewResult.MultiSelect = false;
            this.dataGridViewResult.Name = "dataGridViewResult";
            this.dataGridViewResult.ReadOnly = true;
            this.dataGridViewResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewResult.Size = new System.Drawing.Size(781, 146);
            this.dataGridViewResult.TabIndex = 14;
            this.dataGridViewResult.SelectionChanged += new System.EventHandler(this.dataGridViewResult_SelectionChanged);
            // 
            // ColumnLabel
            // 
            this.ColumnLabel.DataPropertyName = "Label";
            this.ColumnLabel.HeaderText = "Label";
            this.ColumnLabel.Name = "ColumnLabel";
            this.ColumnLabel.ReadOnly = true;
            this.ColumnLabel.Width = 56;
            // 
            // ColumnScore
            // 
            this.ColumnScore.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ColumnScore.DataPropertyName = "Score";
            this.ColumnScore.HeaderText = "Score";
            this.ColumnScore.Name = "ColumnScore";
            this.ColumnScore.ReadOnly = true;
            this.ColumnScore.Width = 56;
            // 
            // ColumnBox
            // 
            this.ColumnBox.DataPropertyName = "Box";
            this.ColumnBox.HeaderText = "Box";
            this.ColumnBox.Name = "ColumnBox";
            this.ColumnBox.ReadOnly = true;
            this.ColumnBox.Width = 50;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(210, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(822, 528);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBoxSrc);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(814, 502);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Image";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBoxMask);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(814, 502);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mask";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBoxMask
            // 
            this.pictureBoxMask.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxMask.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxMask.Name = "pictureBoxMask";
            this.pictureBoxMask.Size = new System.Drawing.Size(808, 496);
            this.pictureBoxMask.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMask.TabIndex = 0;
            this.pictureBoxMask.TabStop = false;
            // 
            // MaskRcnnForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 721);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dataGridViewResult);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.btn_Inference);
            this.Controls.Add(this.btn_openimage);
            this.Controls.Add(this.btn_freeModel);
            this.Controls.Add(this.btn_loadModel);
            this.Name = "MaskRcnnForm";
            this.Text = "MaskRcnnForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MaskRcnnForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMask)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_loadModel;
        private System.Windows.Forms.Button btn_freeModel;
        private System.Windows.Forms.Button btn_openimage;
        private System.Windows.Forms.PictureBox pictureBoxSrc;
        private System.Windows.Forms.Button btn_Inference;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DataGridView dataGridViewResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnScore;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnBox;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBoxMask;
    }
}