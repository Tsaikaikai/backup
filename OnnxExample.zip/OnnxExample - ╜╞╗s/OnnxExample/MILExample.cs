﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Matrox.MatroxImagingLibrary;

namespace WindowsFormsApp1
{
    static class MILExample
    {
        static public float[] MIL2Array(MIL_ID milsys,MIL_ID Input,
            int modelchannel, int modelsizeX, int modelsizeY)
        {
            float[] result = new float[modelchannel * modelsizeX * modelsizeY];

            MIL_INT ImgSizeX = 0;
            MIL_INT ImgSizeY = 0;
            MIL_INT ImgBits = 0;
            MIL_INT ImgBand = 0;

            MIL_ID Image32F = MIL.M_NULL;
            MIL_ID convertImage = MIL.M_NULL;

            MIL.MbufInquire(Input, MIL.M_SIZE_X, ref ImgSizeX);
            MIL.MbufInquire(Input, MIL.M_SIZE_Y, ref ImgSizeY);
            MIL.MbufInquire(Input, MIL.M_SIZE_BIT, ref ImgBits);
            MIL.MbufInquire(Input, MIL.M_SIZE_BAND, ref ImgBand);
            try
            {
                if (modelchannel == 1)
                {
                    Image32F = MIL.MbufAlloc2d(milsys, modelsizeX, modelsizeY, 32 + MIL.M_FLOAT,
                        MIL.M_IMAGE + MIL.M_PROC, MIL.M_NULL);
                    if (ImgBand != 1)
                    {
                        convertImage = MIL.MbufAlloc2d(milsys, ImgSizeX, ImgSizeY, 8 + MIL.M_UNSIGNED,
                                MIL.M_IMAGE + MIL.M_PROC, MIL.M_NULL);
                        MIL.MimConvert(Input, convertImage, MIL.M_RGB_TO_Y);
                    }
                    else
                    {
                        convertImage = MIL.MbufClone(Input, milsys, MIL.M_DEFAULT, MIL.M_DEFAULT,
    MIL.M_DEFAULT, MIL.M_DEFAULT, MIL.M_DEFAULT, MIL.M_NULL);
                        MIL.MbufCopy(Input, convertImage);
                    }
                }
                else
                {
                    Image32F = MIL.MbufAllocColor(milsys,
                        ImgBand, modelsizeX, modelsizeY, 32 + MIL.M_FLOAT,
                        MIL.M_IMAGE + MIL.M_PROC + MIL.M_PLANAR, MIL.M_NULL);
                    if (ImgBand != 3)
                    {
                        convertImage = MIL.MbufAllocColor(milsys,
                            ImgBand, ImgSizeX, ImgSizeY, 8 + MIL.M_UNSIGNED,
                            MIL.M_IMAGE + MIL.M_PROC + MIL.M_PLANAR + MIL.M_RGB24, MIL.M_NULL);
                        MIL.MimConvert(Input, convertImage, MIL.M_L_TO_RGB);
                    }
                    else
                    {
                        convertImage = MIL.MbufClone(Input, milsys, MIL.M_DEFAULT, MIL.M_DEFAULT,
    MIL.M_DEFAULT, MIL.M_DEFAULT, MIL.M_DEFAULT, MIL.M_NULL);
                        MIL.MbufCopy(Input, convertImage);
                    }

                }
                MIL.MimResize(convertImage, Image32F, MIL.M_FILL_DESTINATION,
                        MIL.M_FILL_DESTINATION, MIL.M_BILINEAR);
                MIL.MbufGet2d(Image32F, 0, 0, modelsizeX, modelsizeY, result);

                MIL.MbufFree(Image32F);
                MIL.MbufFree(convertImage);
                return result;
            }
            catch (Exception ex )
            {
                throw ex ;
            }
        }
    }
}
