﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Runtime.InteropServices;
using Emgu.CV.Util;
using Brandy;

namespace WindowsFormsApp1
{
    public partial class StpmForm : Form
    {
        StpmModel core = null;
        int[] inputshape = null;
        int[] outputshape = null;
        Mat inputImage = null;
        Mat outputImage = null;

        public StpmForm()
        {
            InitializeComponent();          
        }

        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }
        Mat chw_Mat(float[] data, int c, int w, int h)
        {
            if (c * w * h != data.Length)
                return null;
            if (c > 1)
            {
                Mat image = new Mat(new Size(w, h), Emgu.CV.CvEnum.DepthType.Cv32F, c);
                VectorOfMat matVector = new VectorOfMat();
                Mat[] channels = image.Split();
                for (int i = 0; i < channels.Length; i++)
                {
                    Marshal.Copy(data, i * w * h, channels[i].DataPointer, w * h);
                    matVector.Push(channels[i]);
                }

                CvInvoke.Merge(matVector, image);
                return image;
            }
            else
            {
                Mat image = new Mat(new Size(w, h), Emgu.CV.CvEnum.DepthType.Cv32F, 1);
                Marshal.Copy(data, 0, image.DataPointer, w * h);
                return image;
            }
        }

        void chw_Mat(float[] data, int c, int w, int h, Mat output)
        {
            if (c * w * h != data.Length)
                return;
            if (c > 1)
            {
                Mat image = output;
                VectorOfMat matVector = new VectorOfMat();
                Mat[] channels = image.Split();
                for (int i = 0; i < channels.Length; i++)
                {
                    Marshal.Copy(data, i * w * h, channels[i].DataPointer, w * h);
                    matVector.Push(channels[i]);
                }

                CvInvoke.Merge(matVector, image);
            }
            else
            {
                Mat image = output;
                Marshal.Copy(data, 0, image.DataPointer, w * h);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Onnx file |*.onnx";
            try
            {
                if (op.ShowDialog() == DialogResult.OK)
                {
                    int gpuid = (int)numericUpDown1.Value;
                    core = new StpmModel(op.FileName, gpuid);
                    inputshape = core.InputShape;
                    outputshape = core.OutputShape;

                    string shapeinf = "InputShape：";
                    for (int i = 0; i < inputshape.Length; i++)
                    {
                        shapeinf += inputshape[i].ToString();
                        if ((i + 1) != inputshape.Length)
                            shapeinf += "*";
                    }
                    shapeinf+=Environment.NewLine + "OutputShape：";
                    for (int i = 0; i < outputshape.Length; i++)
                    {
                        shapeinf += outputshape[i].ToString();
                        if ((i + 1) != outputshape.Length)
                            shapeinf += "*";
                    }
                    textBox2.Text = shapeinf;
                    num_scale.Value = (int)core.OutputScale;
                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                    numericUpDown1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("載入模型錯誤，請確認載入類型");
            }
        }

        private void btn_freeModel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;

                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void btn_openImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {
                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);

                pictureBoxSrc.Image = inputImage.Bitmap;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
                core.OutputScale = (float)num_scale.Value;
                Mat img = new Mat();
                inputImage.CopyTo(img);
                img.Save("./input.tif");
                if (img.NumberOfChannels == 3)
                {
                    CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                }
                if (outputImage != null)
                {
                    outputImage.Dispose();
                    outputImage = null;
                }
                byte[] inputData = Mat_chw(img);
                Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                if (img.NumberOfChannels == 1)
                    type = Brandy.ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);

                Stopwatch sw = new Stopwatch();
                sw.Start();
                if (core.Inference(input))
                {
                    sw.Stop();
                    float[] result = core.Output;
                }

                pictureBoxResult.Image = core.OutputImage.Bitmap;

                label2.Text = "Abnormal：" + core.AbnormalFactor.ToString("#0.000");

                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";

                core.OutputImage.Save("./output.tif");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }


        }
    }
}
