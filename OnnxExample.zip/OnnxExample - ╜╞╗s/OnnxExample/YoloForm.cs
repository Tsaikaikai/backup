﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Brandy;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class YoloForm : Form
    {
        YoloV4Model _yolo = null;
        Mat inputImage = null;
        public YoloForm()
        {
            InitializeComponent();
        }
        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            byte[] chwData = new byte[total];
            Marshal.Copy(src.DataPointer, chwData, 0, total);
            return chwData;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "請選擇模型所在資料夾";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "資料夾路徑不能為空", "提示");
                    return;
                }
                textBox1.Text = dialog.SelectedPath;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "")
                {
                    
                    _yolo = new YoloV4Model(textBox1.Text,ckb_enableGpu.Checked);
                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void btn_freemodel_Click(object sender, EventArgs e)
        {
            if(_yolo!=null)
            {
                _yolo.Dispose();
  
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
            }
        }
        private void btn_openimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {
                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage.Bitmap;
                dataGridViewResult.DataSource = null;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                Mat img = new Mat();
                inputImage.CopyTo(img);
                byte[] inputData = Mat_chw(img);
                ImageChannel ch = ImageChannel.RGBPackage;
                if (img.NumberOfChannels == 1)
                    ch = ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, ch, img.Width, img.Height);
                Stopwatch sw = new Stopwatch();
                sw.Start();

                _yolo.Inference(input);
                List<YoloOutput> output = _yolo.Output;
                this.dataGridViewResult.DataSource = output;
                DrawBoundingBoxes(output);
                sw.Stop();
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void DrawBoundingBoxes(List<YoloOutput> items, YoloOutput selectedItem = null)
        {
            Image image = new Bitmap(pictureBoxSrc.Image);
            using (var canvas = Graphics.FromImage(image))
            {
                foreach (var item in items)
                {
                    var x = item.X;
                    var y = item.Y;
                    var width = item.Width;
                    var height = item.Height;

                    var brush = this.GetBrush(item.Confidence);
                    var penSize = image.Width / 100.0f;

                    using (var pen = new Pen(brush, penSize))
                    using (var overlayBrush = new SolidBrush(Color.FromArgb(150, 255, 255, 102)))
                    {
                        if (item.Equals(selectedItem))
                        {
                            canvas.FillRectangle(overlayBrush, x, y, width, height);
                        }

                        canvas.DrawRectangle(pen, x, y, width, height);
                    }
                }

                canvas.Flush();
            }

            var oldImage = this.pictureBoxSrc.Image;
            this.pictureBoxSrc.Image = image;
            oldImage?.Dispose();

        }

        private Brush GetBrush(double confidence)
        {
            if (confidence > 0.5)
            {
                return Brushes.GreenYellow;
            }
            else if (confidence > 0.2 && confidence <= 0.5)
            {
                return Brushes.Orange;
            }

            return Brushes.DarkRed;
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            pictureBoxSrc.Image = inputImage.Bitmap;
            if (!this.dataGridViewResult.Focused)
            {
                return;
            }

            var items = this.dataGridViewResult.DataSource as List<YoloOutput>;
            var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as YoloOutput;
            this.DrawBoundingBoxes(items, selectedItem);
        }

        private void YoloForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_yolo != null)
            {
                _yolo.Dispose();
                _yolo = null;
            }
        }
    }
}
