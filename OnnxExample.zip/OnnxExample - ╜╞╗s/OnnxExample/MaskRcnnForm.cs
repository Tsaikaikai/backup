﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Brandy;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class MaskRcnnForm : Form
    {
        MaskRcnnModel core = null;
        int inputshape = 3;
        Mat inputImage = null;

        public MaskRcnnForm()
        {
            InitializeComponent();
        }
        float[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            float[] chwData = new float[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                op.Filter = "Onnx file |*.onnx";
                try
                {
                    if (op.ShowDialog() == DialogResult.OK)
                    {
                        int gpuid = (int)numericUpDown1.Value;

                        core = new MaskRcnnModel(op.FileName, gpuid);
                        inputshape = core.InputChannel;

                        textBox2.Text = "Input Channel：" + inputshape;
                        btn_loadModel.Enabled = false;
                        btn_freeModel.Enabled = true;
                        btn_Inference.Enabled = true;
                        numericUpDown1.Enabled = false;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    MessageBox.Show("載入模型錯誤，請確認載入類型");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw;
            }


        }

        private void btn_freemodel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;

                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }
        private void btn_openimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {

                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage.Bitmap;
                dataGridViewResult.DataSource = null;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
              
                Stopwatch sw = new Stopwatch();
                sw.Start();
                Mat img = new Mat();
                inputImage.CopyTo(img);

                if (inputshape > 1)
                {
                    if (img.NumberOfChannels != 3)
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Gray2Rgb);
                    }
                    else
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }
                }
                else
                {
                    if (img.NumberOfChannels == 3)
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Rgb2Gray);
                    }
                }
                img.ConvertTo(img, Emgu.CV.CvEnum.DepthType.Cv32F);         
                float[] inputData = Mat_chw(img);
                Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                if (img.NumberOfChannels == 1)
                    type = Brandy.ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);

                sw.Restart();
                if (core.Inference(input))
                {
                    var outputdata = core.GetResults();
                    sw.Stop();
                    dataGridViewResult.DataSource = outputdata;
                    dataGridViewResult.Invalidate();
                }
                if(dataGridViewResult.DataSource != null)
                {
                    var items = this.dataGridViewResult.DataSource as List<MaskRcnnResult>;
                    var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as MaskRcnnResult;
                    pictureBoxMask.Image?.Dispose();
                    pictureBoxMask.Image = selectedItem.Mask.Bitmap;
                    this.DrawBoundingBoxes(items, selectedItem);
                }
                img.Dispose();

                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";           
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void DrawBoundingBoxes(List<MaskRcnnResult> items, MaskRcnnResult selectedItem = null)
        {
            Image image = new Bitmap(pictureBoxSrc.Image);
            using (var canvas = Graphics.FromImage(image))
            {
                foreach (var item in items)
                {
                    var x = item.Box.X;
                    var y = item.Box.Y;
                    var width = item.Box.Width;
                    var height = item.Box.Height;

                    var brush = this.GetBrush(item.Score);
                    var penSize = (image.Width / 1000.0f) < 10 ? 10 : (image.Width / 1000.0f);
                    var penSizeSelect = (image.Width / 500.0f) < 20 ?  20 : (image.Width / 500.0f);
                    using (var pen = new Pen(brush, penSize))
                    using (var penSelect = new Pen(Brushes.DarkBlue, penSize))
                    {

                        if (item.Equals(selectedItem))
                        {
                            canvas.DrawRectangle(penSelect, x, y, width, height);
                        }
                        else
                        {
                            canvas.DrawRectangle(pen, x, y, width, height);
                        }
                    }
                }

                canvas.Flush();
            }

            var oldImage = this.pictureBoxSrc.Image;
            this.pictureBoxSrc.Image = image;
            oldImage?.Dispose();

        }

        private Brush GetBrush(double confidence)
        {
            if (confidence > 0.5)
            {
                return Brushes.GreenYellow;
            }
            else if (confidence > 0.2 && confidence <= 0.5)
            {
                return Brushes.Orange;
            }

            return Brushes.DarkRed;
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            pictureBoxSrc.Image = inputImage.Bitmap;
            if (!this.dataGridViewResult.Focused)
            {
                return;
            }

            int imageW = pictureBoxSrc.Image.Width;
            int imageH = pictureBoxSrc.Image.Height;

            var items = this.dataGridViewResult.DataSource as List<MaskRcnnResult>;
            var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as MaskRcnnResult;
            pictureBoxMask.Image?.Dispose();
            pictureBoxMask.Image = selectedItem.Mask.Bitmap;
            this.DrawBoundingBoxes(items, selectedItem);
        }

        private void MaskRcnnForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }
    }
}
