﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Runtime.InteropServices;
using Emgu.CV.Util;
using Brandy;

namespace WindowsFormsApp1
{
    public partial class ChangeDetectionForm : Form
    {
        ChangeDetectionModel core = null;
        int[] inputshape = null;
        int[] outputshape = null;
        Mat inputImage1 = null;
        Mat inputImage2 = null;
        Mat outputImage = null;

        public ChangeDetectionForm()
        {
            InitializeComponent();
            cbx_InferenceMode.SelectedIndex = 0;
        }

        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }
            return chwData;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Onnx file |*.onnx";
            try
            {
                if (op.ShowDialog() == DialogResult.OK)
                {
                    int gpuid = (int)numericUpDown1.Value;

                    core = new ChangeDetectionModel(op.FileName, gpuid);
                    inputshape = core.InputShape;
                    outputshape = core.OutputShape;
                    string shapeinf = "InputShape：";
                    for (int i = 0; i < inputshape.Length; i++)
                    {
                        shapeinf += inputshape[i].ToString();
                        if ((i + 1) != inputshape.Length)
                            shapeinf += "*";
                    }
                    shapeinf += Environment.NewLine + "OutputShape：";
                    for (int i = 0; i < outputshape.Length; i++)
                    {
                        shapeinf += outputshape[i].ToString();
                        if ((i + 1) != outputshape.Length)
                            shapeinf += "*";
                    }
                    textBox2.Text = shapeinf;
                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                    numericUpDown1.Enabled = false;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("載入模型錯誤，請確認載入類型");
            }
        }
        private void btn_freeModel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void btn_openImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op1 = new OpenFileDialog();
            op1.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op1.ShowDialog() == DialogResult.OK)
            {
                inputImage1 = CvInvoke.Imread(op1.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage1.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage1, inputImage1, 0.0625, 0);
                    inputImage1.ConvertTo(inputImage1, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage1.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage1, inputImage1, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage1.Bitmap;
            }

            OpenFileDialog op2 = new OpenFileDialog();
            op2.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op2.ShowDialog() == DialogResult.OK)
            {
                inputImage2 = CvInvoke.Imread(op2.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage2.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage2, inputImage2, 0.0625, 0);
                    inputImage2.ConvertTo(inputImage2, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage2.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage2, inputImage2, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxCpr.Image = inputImage2.Bitmap;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage1 == null)
                {
                    MessageBox.Show("請載入Golden影像");
                    return;
                }
                if (inputImage2 == null)
                {
                    MessageBox.Show("請載入Sourse影像");
                    return;
                }

                Mat img1 = new Mat();
                Mat img2 = new Mat();
                inputImage1.CopyTo(img1);
                inputImage2.CopyTo(img2);
                img1.Save("./input1.tif");
                img2.Save("./input2.tif");
                if (cbx_InferenceMode.SelectedIndex == 0) //resize than inference 
                {
                    if (img1.NumberOfChannels == 3)
                    {
                        CvInvoke.CvtColor(img1, img1, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }
                    if (img2.NumberOfChannels == 3)
                    {
                        CvInvoke.CvtColor(img2, img2, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }
                    byte[] inputData1 = Mat_chw(img1);
                    byte[] inputData2 = Mat_chw(img2);
                    Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                    if (img1.NumberOfChannels == 1 && img2.NumberOfChannels == 1)
                        type = Brandy.ImageChannel.Gray;
                    BrandyImage input1 = new BrandyImage(inputData1, type, img1.Width, img1.Height);
                    BrandyImage input2 = new BrandyImage(inputData2, type, img2.Width, img2.Height);

                    Stopwatch sw = new Stopwatch();
                    sw.Start();
                    if (core.Inference(input1, input2))
                    {
                        sw.Stop();
                    }
                    List<BrandyImage> outputs = core.GetOutputImage(0,1);
                    pictureBoxResult.Image = outputs[0].Bitmap;
                    //output.Save("./output.tif");
                    label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
                }
                else//crop image than inference
                {
                    if(img1.Height!=img2.Height || img1.Width!=img2.Width || img1.NumberOfChannels != img2.NumberOfChannels)
                    {
                        new Exception("The size of img1 and img2 not match.");
                    }
                    if (img1.Height < inputshape[2])
                    {
                        CvInvoke.Resize(img1, img1, new Size(inputshape[2], img1.Width), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                        CvInvoke.Resize(img2, img2, new Size(inputshape[2], img2.Width), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                    }
                    if (img1.Width < inputshape[3])
                    {
                        CvInvoke.Resize(img1, img1, new Size(img1.Height, inputshape[3]), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                        CvInvoke.Resize(img2, img2, new Size(img2.Height, inputshape[3]), 0, 0, Emgu.CV.CvEnum.Inter.Cubic);
                    }
                    if (inputshape[1] > 1) //Color mode
                    {
                        if (img1.NumberOfChannels != 3)
                        {
                            CvInvoke.CvtColor(img1, img1, Emgu.CV.CvEnum.ColorConversion.Gray2Rgb);
                            CvInvoke.CvtColor(img2, img2, Emgu.CV.CvEnum.ColorConversion.Gray2Rgb);
                        }
                    }
                    else //Gray mode
                    {
                        if (img1.NumberOfChannels == 3)
                        {
                            CvInvoke.CvtColor(img1, img1, Emgu.CV.CvEnum.ColorConversion.Rgb2Gray);
                            CvInvoke.CvtColor(img2, img2, Emgu.CV.CvEnum.ColorConversion.Rgb2Gray);
                        }
                    }
                    if (outputImage != null)
                    {
                        outputImage.Dispose();
                        outputImage = null;
                    }
                    outputImage = new Mat();
                    img1.CopyTo(outputImage);
                    outputImage.ConvertTo(outputImage, Emgu.CV.CvEnum.DepthType.Cv32F);

                    Rectangle roi = new Rectangle(0, 0, inputshape[3], inputshape[2]);

                    int xTimes = (int)Math.Ceiling((img1.Width - inputshape[3]) / (double)inputshape[3]) + 1;
                    int yTimes = (int)Math.Ceiling((img1.Height - inputshape[2]) / (double)inputshape[2]) + 1;

                    Mat roiInput1 = new Mat(roi.Size, img1.Depth, img1.NumberOfChannels);
                    Mat roiInput2 = new Mat(roi.Size, img2.Depth, img2.NumberOfChannels);
                    Mat roiOutput = new Mat(roi.Size, outputImage.Depth, outputImage.NumberOfChannels);

                    Stopwatch sw = new Stopwatch();
                    sw.Start();

                    for (int y = 0; y < yTimes; y++)
                    {
                        for (int x = 0; x < xTimes; x++)
                        {
                            int pointx = x * inputshape[3];
                            int pointy = y * inputshape[2];

                            int endx = pointx + inputshape[3];
                            int endy = pointy + inputshape[2];
                            if (endx >= img1.Width)
                            {
                                pointx = (int)img1.Width - inputshape[3];
                                endx = (int)inputshape[3] - 1;
                            }
                            if (endy >= img1.Height)
                            {
                                pointy = (int)img1.Height - inputshape[2];
                                endy = (int)img1.Height - 1;
                            }
                            roi.X = pointx;
                            roi.Y = pointy;

                            Mat temp1 = new Mat(img1, roi);
                            Mat temp2 = new Mat(img2, roi);
                            temp1.CopyTo(roiInput1);
                            temp2.CopyTo(roiInput2);
                            roiInput1.Save("./input1_" + x.ToString() + "_" + y.ToString() + ".tif");
                            roiInput2.Save("./input2_" + x.ToString() + "_" + y.ToString() + ".tif");

                            if (roiInput1.NumberOfChannels == 3)
                            {
                                CvInvoke.CvtColor(roiInput1, roiInput1, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                                CvInvoke.CvtColor(roiInput2, roiInput2, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                            }

                            byte[] inputData1 = Mat_chw(roiInput1);
                            byte[] inputData2 = Mat_chw(roiInput2);
                            Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                            if (img1.NumberOfChannels == 1 && img2.NumberOfChannels == 1)
                                type = Brandy.ImageChannel.Gray;
                            BrandyImage input1 = new BrandyImage(inputData1, type, roiInput1.Width, roiInput1.Height);
                            BrandyImage input2 = new BrandyImage(inputData2, type, roiInput2.Width, roiInput2.Height);

                            if (core.Inference(input1, input2))
                            {
                                //BrandyImage output = core.GetOutputImage();
                                //pictureBoxResult.Image = output.Bitmap;
                                //output.Save("./output_" + x.ToString() +"_"+ y.ToString() + ".tif");
                                //outputImage = output.image;
                            }
                        }
                    }
                    sw.Stop();
                    label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
                    pictureBoxResult.Image = outputImage.Bitmap;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
