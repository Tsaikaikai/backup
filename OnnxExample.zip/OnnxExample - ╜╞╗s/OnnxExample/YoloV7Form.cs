﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Brandy;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class YoloV7Form : Form
    {
        YoloV7Model core = null;
        int[] inputshape = null;
        Mat inputImage = null;
        List<BrandyImage> inputImages = new List<BrandyImage>();
        Point MsPt = new Point(0, 0);

        public object ParallelPreprocess { get; private set; }

        public YoloV7Form()
        {
            InitializeComponent();
        }
        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                op.Filter = "Onnx file |*.onnx";
                try
                {
                    if (op.ShowDialog() == DialogResult.OK)
                    {
                        int gpuid = (int)numericUpDown1.Value;

                        core = new YoloV7Model(op.FileName, gpuid);
                        inputshape = core.InputShape;
                        string shapeinf = "InputShape：";
                        for (int i = 0; i < inputshape.Length; i++)
                        {
                            shapeinf += inputshape[i].ToString();
                            if ((i + 1) != inputshape.Length)
                                shapeinf += "*";
                        }

                        textBox2.Text = shapeinf;

                        btn_loadModel.Enabled = false;
                        btn_freeModel.Enabled = true;
                        btn_Inference.Enabled = true;
                        btn_batchInference.Enabled = true;
                        numericUpDown1.Enabled = false;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    MessageBox.Show("載入模型錯誤，請確認載入類型");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw;
            }


        }

        private void btn_freemodel_Click(object sender, EventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;

                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }
        private void btn_openimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            if (op.ShowDialog() == DialogResult.OK)
            {

                inputImage = CvInvoke.Imread(op.FileName, Emgu.CV.CvEnum.ImreadModes.Unchanged);
                if (inputImage.Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                {
                    CvInvoke.ConvertScaleAbs(inputImage, inputImage, 0.0625, 0);
                    inputImage.ConvertTo(inputImage, Emgu.CV.CvEnum.DepthType.Cv8U);
                }
                if (inputImage.NumberOfChannels > 3)
                    CvInvoke.CvtColor(inputImage, inputImage, Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                pictureBoxSrc.Image = inputImage.Bitmap;
                dataGridViewResult.DataSource = null;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (inputImage == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
              
                Stopwatch sw = new Stopwatch();
                sw.Start();
                Mat img = new Mat();
                inputImage.CopyTo(img);

                if (img.NumberOfChannels == 3)
                {
                    CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                }
                byte[] inputData = Mat_chw(img);
                Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                if (img.NumberOfChannels == 1)
                    type = Brandy.ImageChannel.Gray;
                BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);
                if (core.Inference(input))
                {
                    var outputdata = core.Output;
                    sw.Stop();
                    dataGridViewResult.DataSource = outputdata;
                    dataGridViewResult.Invalidate();
                }
                if(dataGridViewResult.DataSource != null)
                {
                    var items = this.dataGridViewResult.DataSource as List<YoloOutput>;
                    var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as YoloOutput;
                    //pictureBoxMask.Image?.Dispose();
                    //pictureBoxMask.Image = selectedItem.Mask.Bitmap;
                    this.DrawBoundingBoxes(items, selectedItem);
                }
                img.Dispose();
                string t2 = sw.ElapsedMilliseconds.ToString("0") + "ms";
                label_result.Text = "Time : \r\n" + t2;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void DrawBoundingBoxes(List<YoloOutput> items, YoloOutput selectedItem = null)
        {
            Image image = new Bitmap(pictureBoxSrc.Image);
            int imageW = image.Width > image.Height? image.Width : image.Height;
            float gain = inputshape[2] / (float)imageW;
            float pad_x = ((float)inputshape[2] - image.Width * gain) / 2;
            float pad_y = ((float)inputshape[2] - image.Height * gain) / 2;
            using (var canvas = Graphics.FromImage(image))
            {
                foreach (var item in items)
                {
                    var x = item.X;
                    var y = item.Y;
                    var width = item.Width;
                    var height = item.Height;

                    var brush = this.GetBrush(item.Confidence);
                    var penSize = (image.Width / 1000.0f) < 10 ? 10 : (image.Width / 1000.0f);
                    var penSizeSelect = (image.Width / 500.0f) < 20 ?  20 : (image.Width / 500.0f);
                    using (var pen = new Pen(brush, penSize))
                    using (var penSelect = new Pen(Brushes.DarkBlue, penSize))
                    {

                        if (item.Equals(selectedItem))
                        {
                            canvas.DrawRectangle(penSelect, x, y, width, height);
                        }
                        else
                        {
                            canvas.DrawRectangle(pen, x, y, width, height);
                        }
                    }
                }
                canvas.Flush();
            }

            var oldImage = this.pictureBoxSrc.Image;
            this.pictureBoxSrc.Image = image;
            oldImage?.Dispose();
        }

        private Brush GetBrush(double confidence)
        {
            if (confidence > 0.5)
            {
                return Brushes.GreenYellow;
            }
            else if (confidence > 0.2 && confidence <= 0.5)
            {
                return Brushes.Orange;
            }

            return Brushes.DarkRed;
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            pictureBoxSrc.Image = inputImage.Bitmap;
            if (!this.dataGridViewResult.Focused)
            {
                return;
            }

            int imageW = pictureBoxSrc.Image.Width;
            int imageH = pictureBoxSrc.Image.Height;

            var items = this.dataGridViewResult.DataSource as List<YoloOutput>;
            var selectedItem = this.dataGridViewResult.CurrentRow?.DataBoundItem as YoloOutput;
            //pictureBoxMask.Image?.Dispose();
            //pictureBoxMask.Image = selectedItem.Mask.Bitmap;
            this.DrawBoundingBoxes(items, selectedItem);
        }

        private void YoloV7Form_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (core != null)
            {
                core.Dispose();
                core = null;
            }
        }

        private void pictureBoxSrc_MouseMove(object sender, MouseEventArgs e)
        {
            this.MsPt = this.unScale(new Point(e.X, e.Y));
            this.Text = String.Format("({0},{1})", this.MsPt.X, this.MsPt.Y);
        }

        private Point unScale(Point scaledP)
        {
            if (pictureBoxSrc.SizeMode != PictureBoxSizeMode.Zoom ) //only zoom mode need to scale
                return scaledP;

            if (pictureBoxSrc.Image == null)
                return scaledP;

            Point unscaled_p = new Point();
            // image and container dimensions
            int w_i = pictureBoxSrc.Image.Width;
            int h_i = pictureBoxSrc.Image.Height;
            int w_c = pictureBoxSrc.Width;
            int h_c = pictureBoxSrc.Height;
            float imageRatio = w_i / (float)h_i; // image W:H ratio
            float containerRatio = w_c / (float)h_c; // container W:H ratio

            if (imageRatio >= containerRatio)
            {
                // horizontal image
                float scaleFactor = w_c / (float)w_i;
                float scaledHeight = h_i * scaleFactor;
                // calculate gap between top of container and top of image
                float filler = Math.Abs(h_c - scaledHeight) / 2;
                unscaled_p.X = (int)(scaledP.X / scaleFactor);
                unscaled_p.Y = (int)((scaledP.Y - filler) / scaleFactor);
            }
            else
            {
                // vertical image
                float scaleFactor = h_c / (float)h_i;
                float scaledWidth = w_i * scaleFactor;
                float filler = Math.Abs(w_c - scaledWidth) / 2;
                unscaled_p.X = (int)((scaledP.X - filler) / scaleFactor);
                unscaled_p.Y = (int)(scaledP.Y / scaleFactor);
            }

            if (unscaled_p.X > pictureBoxSrc.Image.Width )
            {
                unscaled_p.X = pictureBoxSrc.Image.Width;
            }
            else if(unscaled_p.X < 0 )
            {
                unscaled_p.X = 0;
            }

            if (unscaled_p.Y > pictureBoxSrc.Image.Height)
            {
                unscaled_p.Y = pictureBoxSrc.Image.Height;
            }
            else if(unscaled_p.Y < 0)
            {
                unscaled_p.Y = 0;
            }

            return unscaled_p;
        }

        private void pictureBoxSrc_DoubleClick(object sender, EventArgs e)
        {          
            var ds = this.dataGridViewResult.DataSource as List<YoloOutput>;
            String msInfo = String.Empty;
            foreach (YoloOutput tmp_ds in ds)
            {
                if (Math.Abs(this.MsPt.X - tmp_ds.X) < 5 && Math.Abs(this.MsPt.Y - tmp_ds.Y) < 5)
                    msInfo += String.Format("Type=[{0}] , Score[{1}]" + "\r\n", tmp_ds.Type, tmp_ds.Confidence);
            }
            MessageBox.Show(String.Format("{0}", msInfo));
        }

        private void btn_openfolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "Select Input Folder";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = dialog.SelectedPath;
                inputImages.Clear();
                foreach (string fname in System.IO.Directory.GetFiles(filepath))
                {
                    if (fname.ToLower().EndsWith(".jpg") || fname.ToLower().EndsWith(".png") || 
                        fname.ToLower().EndsWith(".tif") || fname.ToLower().EndsWith(".bmp"))
                    {
                        BrandyImage input = new BrandyImage(fname);
                        inputImages.Add(input);
                    }
                    
                }
                textBox1.Text = filepath;
            }
            else return;
        }

        private void btn_batchInference_Click(object sender, EventArgs e)
        {
            if (core == null)
            {
                MessageBox.Show("請載入AI model");
                return;
            }
            if (inputImages.Count == 0)
            {
                MessageBox.Show("請載入影像");
                return;
            }

            Stopwatch sw = new Stopwatch();
            sw.Start();
            core.ParallelPreprocess(ref inputImages);

            float[] batchData = new float[inputImages[0].ProcessImage.Length * inputImages.Count];
            Parallel.For(0, inputImages.Count, i =>
            {
                Array.Copy(inputImages[i].ProcessImage, 0, batchData, inputImages[i].ProcessImage.Length * i, inputImages[i].ProcessImage.Length);
            });
            sw.Stop();

            long t1 = sw.ElapsedMilliseconds;
            double eachTime1 = t1 / inputImages.Count();

            sw.Restart();
            core.BatchInference(batchData, inputImages.Count());
            sw.Stop();
            List<YoloOutput> outputdata = core.Output;

            long t2 = sw.ElapsedMilliseconds;
            double eachTime2 = t2 / inputImages.Count();
            label_result.Text = "Total : \n\r" + inputImages.Count().ToString() + " images" + "\n\rTotal Time : " + (t1+t2).ToString() + 
                "\n\rEach preprocess Time : \n\r" + eachTime1.ToString() + "ms" + "\r\nEach AI infernce Time : \n\r" + eachTime2.ToString() + "ms";
        }
    }
}
