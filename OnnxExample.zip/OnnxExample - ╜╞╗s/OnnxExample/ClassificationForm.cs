﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Runtime.InteropServices;
using Emgu.CV.Util;
using Brandy;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class ClassificationForm : Form
    {
        CspResnetModel Core = null;
        String[] Filenames = null;
        Mat[] InputImages = null;
        int[] Inputshape = null;
        List<ClassificationItem> Results = null;
        public ClassificationForm()
        {
            InitializeComponent();
        }

        private void btn_loadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Onnx file |*.onnx";
            try
            {
                if (op.ShowDialog() == DialogResult.OK)
                {
                    int gpuid = (int)numericUpDown1.Value;
                    Core = new CspResnetModel(op.FileName, gpuid);
                    Inputshape = Core.InputShape;

                    string shapeinf = "InputShape：";
                    for (int i = 0; i < Inputshape.Length; i++)
                    {
                        shapeinf += Inputshape[i].ToString();
                        if ((i + 1) != Inputshape.Length)
                            shapeinf += "*";
                    }
                    textBox2.Text = shapeinf;

                    btn_loadModel.Enabled = false;
                    btn_freeModel.Enabled = true;
                    btn_Inference.Enabled = true;
                    btn_batchRun.Enabled = true;
                    btn_Load_Inference.Enabled = true;
                    numericUpDown1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("載入模型錯誤，請確認載入類型");
            }
        }
        private void btn_freeModel_Click(object sender, EventArgs e)
        {
            if (Core != null)
            {
                Core.Dispose();
                Core = null;
                textBox2.Text = string.Empty;
                btn_loadModel.Enabled = true;
                btn_freeModel.Enabled = false;
                btn_Inference.Enabled = false;
                btn_batchRun.Enabled = false;
                btn_Load_Inference.Enabled = false;
                numericUpDown1.Enabled = true;
            }
        }

        private void btn_openImage_Click(object sender, EventArgs e)
        {
            FreeObjects();
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Image files (*.bmp, *.jpg, *.jpeg, *.tif , *.tiff, *.png) |" +
                "*.bmp; *.jpg; *.jpeg; *.tif; *.tiff; *.png";
            op.Multiselect = true;
            if (op.ShowDialog() == DialogResult.OK)
            {
                Filenames = op.FileNames;
                InputImages = new Mat[Filenames.Length];
                for (int i = 0; i < Filenames.Length; i++)
                {
                    InputImages[i] = CvInvoke.Imread(Filenames[i], Emgu.CV.CvEnum.ImreadModes.Unchanged);
                    if (InputImages[i].Depth != Emgu.CV.CvEnum.DepthType.Cv8U)
                    {
                        CvInvoke.ConvertScaleAbs(InputImages[i], InputImages[i], 0.0625, 0);
                        InputImages[i].ConvertTo(InputImages[i], Emgu.CV.CvEnum.DepthType.Cv8U);
                    }
                    if (InputImages[i].NumberOfChannels > 3)
                        CvInvoke.CvtColor(InputImages[i], InputImages[i], Emgu.CV.CvEnum.ColorConversion.Bgra2Bgr);
                }

                pictureBoxSrc.Image = InputImages[0].Bitmap;
            }
        }

        private void btn_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (Core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (InputImages == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }

                Stopwatch swImage = new Stopwatch();
                Stopwatch sw = new Stopwatch();
                swImage.Start();
                sw.Start();
                Results = new List<ClassificationItem>();
                for (int i = 0; i < InputImages.Length; i++)
                {
                    swImage.Restart();
                    Results.Add(new ClassificationItem(Filenames[i]));
                    Mat img = new Mat();
                    InputImages[i].CopyTo(img);
                    if (img.NumberOfChannels == 3)
                    {
                        CvInvoke.CvtColor(img, img, Emgu.CV.CvEnum.ColorConversion.Bgr2Rgb);
                    }
                    byte[] inputData = Mat_chw(img);
                    Brandy.ImageChannel type = Brandy.ImageChannel.RGBPlanner;
                    if (img.NumberOfChannels == 1)
                        type = Brandy.ImageChannel.Gray;
                    BrandyImage input = new BrandyImage(inputData, type, img.Width, img.Height);
                    if (Core.Inference(input))
                    {
                        //float[] result = Core.Output;
                        Results[i].Class = Core.OutputClass;
                        Results[i].Score = Core.OutputScore;
                        Results[i].Time = swImage.Elapsed.TotalMilliseconds.ToString("f2");
                    }
                }
                sw.Stop();
                dataGridViewResult.DataSource = Results;
                dataGridViewResult.Invalidate();
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_Load_Inference_Click(object sender, EventArgs e)
        {
            try
            {
                if (Core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                if (InputImages == null)
                {
                    MessageBox.Show("請載入影像");
                    return;
                }
                Stopwatch swImage = new Stopwatch();
                Stopwatch sw = new Stopwatch();
                swImage.Start();
                sw.Start();
                Results = new List<ClassificationItem>();
                for (int i = 0; i < InputImages.Length; i++)
                {
                    swImage.Restart();
                    Results.Add(new ClassificationItem(Filenames[i]));     
                    if (Core.Inference(Filenames[i]))
                    {
                        float[] result = Core.Output;
                        Results[i].Class = Core.OutputClass;
                        Results[i].Score = Core.OutputScore;
                        Results[i].Time = swImage.Elapsed.TotalMilliseconds.ToString("f2");
                    }
                }
                sw.Stop();
                dataGridViewResult.DataSource = Results;
                dataGridViewResult.Invalidate();
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_BatchRun_Click(object sender, EventArgs e)
        {
            try
            {
                if (Core == null)
                {
                    MessageBox.Show("請載入AI model");
                    return;
                }
                Stopwatch sw = new Stopwatch();
                sw.Start();

                //資料前處理
                List<BrandyImage> inputImages = Core.MatsToBrandyImages(InputImages);
                Core.ParallelPreprocess(ref inputImages);
                                                                                             
                float[] batchData = new float[inputImages[0].ProcessImage.Length * inputImages.Count];
                Parallel.For(0, inputImages.Count, i =>
                {
                    Array.Copy(inputImages[i].ProcessImage, 0, batchData, inputImages[i].ProcessImage.Length * i, inputImages[i].ProcessImage.Length);
                });

                //AI預測
                Results = new List<ClassificationItem>();
                if (Core.BatchInference(batchData, inputImages.Count))
                {
                    sw.Stop();
                    //取結果
                    for (int i = 0; i < inputImages.Count; i++)
                    {
                        Results.Add(new ClassificationItem(Filenames[i]));
                        Results[i].Class = Core.BatchOutputClass[i];
                        Results[i].Score = Core.BatchOutputScore[i];
                        Results[i].Time = (sw.Elapsed.TotalMilliseconds/ inputImages.Count).ToString("f2");
                    }
                }
                label_result.Text = sw.ElapsedMilliseconds.ToString() + "ms";
                dataGridViewResult.DataSource = Results;
                dataGridViewResult.Invalidate();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        byte[] Mat_chw(Mat src)
        {
            int total = src.Rows * src.Cols * src.NumberOfChannels;
            int imgSize = src.Rows * src.Cols;
            Mat[] bgrChannels = src.Split();
            byte[] chwData = new byte[total];
            for (int i = 0; i < bgrChannels.Length; i++)
            {
                Marshal.Copy(bgrChannels[i].DataPointer, chwData, i * imgSize, imgSize);
            }

            return chwData;
        }

        void FreeObjects()
        {
            if(InputImages!=null)
            {
                for (int i = 0; i < InputImages.Length; i++)
                {
                    if (InputImages[i]!=null)
                    {
                        InputImages[i].Dispose();
                        InputImages[i] = null;
                    }
                }
                InputImages = null;
            }
            Filenames = null;
            dataGridViewResult.DataSource = null;
            Results = null;
        }

        private void ClassificationForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            FreeObjects();
            if (Core != null)
            {
                Core.Dispose();
                Core = null;
            }
        }

        private void dataGridViewResult_SelectionChanged(object sender, EventArgs e)
        {
            if (!this.dataGridViewResult.Focused)
            {
                return;
            }
            int index = this.dataGridViewResult.CurrentRow.Index;
            if(InputImages!=null)
            {
                if (InputImages[index] != null)
                    pictureBoxSrc.Image = InputImages[index].Bitmap;
            }
        }


    }
    public class ClassificationItem
    {
        public String path { get; set; }
        public int Class { get; set; } = -1;
        public float Score { get; set; } = -1;
        public string Time { get; set; } = "";
        public ClassificationItem(String filepath)
        {
            path = filepath;
        }
    }
}
