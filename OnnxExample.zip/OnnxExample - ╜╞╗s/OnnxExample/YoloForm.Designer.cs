﻿
namespace WindowsFormsApp1
{
    partial class YoloForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_loadModel = new System.Windows.Forms.Button();
            this.btn_freeModel = new System.Windows.Forms.Button();
            this.btn_openimage = new System.Windows.Forms.Button();
            this.pictureBoxSrc = new System.Windows.Forms.PictureBox();
            this.btn_Inference = new System.Windows.Forms.Button();
            this.label_result = new System.Windows.Forms.Label();
            this.dataGridViewResult = new System.Windows.Forms.DataGridView();
            this.ColumnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnConfidence = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnResultWidth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnResultHeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ckb_enableGpu = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 34);
            this.button1.TabIndex = 0;
            this.button1.Text = "模型路徑";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(194, 22);
            this.textBox1.TabIndex = 3;
            // 
            // btn_loadModel
            // 
            this.btn_loadModel.Location = new System.Drawing.Point(12, 40);
            this.btn_loadModel.Name = "btn_loadModel";
            this.btn_loadModel.Size = new System.Drawing.Size(87, 34);
            this.btn_loadModel.TabIndex = 0;
            this.btn_loadModel.Text = "載入模型";
            this.btn_loadModel.UseVisualStyleBackColor = true;
            this.btn_loadModel.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_freeModel
            // 
            this.btn_freeModel.Enabled = false;
            this.btn_freeModel.Location = new System.Drawing.Point(12, 80);
            this.btn_freeModel.Name = "btn_freeModel";
            this.btn_freeModel.Size = new System.Drawing.Size(87, 36);
            this.btn_freeModel.TabIndex = 4;
            this.btn_freeModel.Text = "Free Model";
            this.btn_freeModel.UseVisualStyleBackColor = true;
            this.btn_freeModel.Click += new System.EventHandler(this.btn_freemodel_Click);
            // 
            // btn_openimage
            // 
            this.btn_openimage.Location = new System.Drawing.Point(12, 122);
            this.btn_openimage.Name = "btn_openimage";
            this.btn_openimage.Size = new System.Drawing.Size(87, 36);
            this.btn_openimage.TabIndex = 4;
            this.btn_openimage.Text = "open image";
            this.btn_openimage.UseVisualStyleBackColor = true;
            this.btn_openimage.Click += new System.EventHandler(this.btn_openimage_Click);
            // 
            // pictureBoxSrc
            // 
            this.pictureBoxSrc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxSrc.Location = new System.Drawing.Point(224, 44);
            this.pictureBoxSrc.Name = "pictureBoxSrc";
            this.pictureBoxSrc.Size = new System.Drawing.Size(738, 481);
            this.pictureBoxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSrc.TabIndex = 5;
            this.pictureBoxSrc.TabStop = false;
            // 
            // btn_Inference
            // 
            this.btn_Inference.Enabled = false;
            this.btn_Inference.Location = new System.Drawing.Point(12, 164);
            this.btn_Inference.Name = "btn_Inference";
            this.btn_Inference.Size = new System.Drawing.Size(107, 71);
            this.btn_Inference.TabIndex = 6;
            this.btn_Inference.Text = "Run";
            this.btn_Inference.UseVisualStyleBackColor = true;
            this.btn_Inference.Click += new System.EventHandler(this.btn_Inference_Click);
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_result.Location = new System.Drawing.Point(12, 275);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(62, 24);
            this.label_result.TabIndex = 7;
            this.label_result.Text = "0:ms";
            // 
            // dataGridViewResult
            // 
            this.dataGridViewResult.AllowUserToAddRows = false;
            this.dataGridViewResult.AllowUserToDeleteRows = false;
            this.dataGridViewResult.AllowUserToResizeColumns = false;
            this.dataGridViewResult.AllowUserToResizeRows = false;
            this.dataGridViewResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnType,
            this.ColumnConfidence,
            this.ColumnX,
            this.ColumnY,
            this.ColumnResultWidth,
            this.ColumnResultHeight});
            this.dataGridViewResult.Location = new System.Drawing.Point(12, 551);
            this.dataGridViewResult.MultiSelect = false;
            this.dataGridViewResult.Name = "dataGridViewResult";
            this.dataGridViewResult.ReadOnly = true;
            this.dataGridViewResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewResult.Size = new System.Drawing.Size(1020, 158);
            this.dataGridViewResult.TabIndex = 8;
            this.dataGridViewResult.SelectionChanged += new System.EventHandler(this.dataGridViewResult_SelectionChanged);
            // 
            // ColumnType
            // 
            this.ColumnType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnType.DataPropertyName = "Type";
            this.ColumnType.HeaderText = "Type";
            this.ColumnType.Name = "ColumnType";
            this.ColumnType.ReadOnly = true;
            // 
            // ColumnConfidence
            // 
            this.ColumnConfidence.DataPropertyName = "Confidence";
            dataGridViewCellStyle2.Format = "N3";
            dataGridViewCellStyle2.NullValue = null;
            this.ColumnConfidence.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnConfidence.HeaderText = "Confidence";
            this.ColumnConfidence.Name = "ColumnConfidence";
            this.ColumnConfidence.ReadOnly = true;
            // 
            // ColumnX
            // 
            this.ColumnX.DataPropertyName = "X";
            this.ColumnX.HeaderText = "X";
            this.ColumnX.Name = "ColumnX";
            this.ColumnX.ReadOnly = true;
            this.ColumnX.Width = 50;
            // 
            // ColumnY
            // 
            this.ColumnY.DataPropertyName = "Y";
            this.ColumnY.HeaderText = "Y";
            this.ColumnY.Name = "ColumnY";
            this.ColumnY.ReadOnly = true;
            this.ColumnY.Width = 50;
            // 
            // ColumnResultWidth
            // 
            this.ColumnResultWidth.DataPropertyName = "Width";
            this.ColumnResultWidth.HeaderText = "Width";
            this.ColumnResultWidth.Name = "ColumnResultWidth";
            this.ColumnResultWidth.ReadOnly = true;
            this.ColumnResultWidth.Width = 50;
            // 
            // ColumnResultHeight
            // 
            this.ColumnResultHeight.DataPropertyName = "Height";
            this.ColumnResultHeight.HeaderText = "Height";
            this.ColumnResultHeight.Name = "ColumnResultHeight";
            this.ColumnResultHeight.ReadOnly = true;
            this.ColumnResultHeight.Width = 50;
            // 
            // ckb_enableGpu
            // 
            this.ckb_enableGpu.AutoSize = true;
            this.ckb_enableGpu.Checked = true;
            this.ckb_enableGpu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckb_enableGpu.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ckb_enableGpu.Location = new System.Drawing.Point(105, 45);
            this.ckb_enableGpu.Name = "ckb_enableGpu";
            this.ckb_enableGpu.Size = new System.Drawing.Size(64, 23);
            this.ckb_enableGpu.TabIndex = 10;
            this.ckb_enableGpu.Text = "GPU";
            this.ckb_enableGpu.UseVisualStyleBackColor = true;
            // 
            // YoloForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 721);
            this.Controls.Add(this.ckb_enableGpu);
            this.Controls.Add(this.dataGridViewResult);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.btn_Inference);
            this.Controls.Add(this.pictureBoxSrc);
            this.Controls.Add(this.btn_openimage);
            this.Controls.Add(this.btn_freeModel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_loadModel);
            this.Controls.Add(this.button1);
            this.Name = "YoloForm";
            this.Text = "YoloForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.YoloForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_loadModel;
        private System.Windows.Forms.Button btn_freeModel;
        private System.Windows.Forms.Button btn_openimage;
        private System.Windows.Forms.PictureBox pictureBoxSrc;
        private System.Windows.Forms.Button btn_Inference;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.DataGridView dataGridViewResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnConfidence;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnY;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnResultWidth;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnResultHeight;
        private System.Windows.Forms.CheckBox ckb_enableGpu;
    }
}