﻿
namespace WindowsFormsApp1
{
    partial class StpmForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxSrc = new System.Windows.Forms.PictureBox();
            this.label_result = new System.Windows.Forms.Label();
            this.btn_Inference = new System.Windows.Forms.Button();
            this.btn_openImage = new System.Windows.Forms.Button();
            this.btn_freeModel = new System.Windows.Forms.Button();
            this.btn_loadModel = new System.Windows.Forms.Button();
            this.pictureBoxResult = new System.Windows.Forms.PictureBox();
            this.ckb_OrgSize = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.num_scale = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_scale)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxSrc
            // 
            this.pictureBoxSrc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxSrc.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxSrc.Name = "pictureBoxSrc";
            this.pictureBoxSrc.Size = new System.Drawing.Size(524, 508);
            this.pictureBoxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxSrc.TabIndex = 0;
            this.pictureBoxSrc.TabStop = false;
            // 
            // label_result
            // 
            this.label_result.AutoSize = true;
            this.label_result.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_result.Location = new System.Drawing.Point(8, 497);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(62, 24);
            this.label_result.TabIndex = 6;
            this.label_result.Text = "0:ms";
            // 
            // btn_Inference
            // 
            this.btn_Inference.Enabled = false;
            this.btn_Inference.Location = new System.Drawing.Point(12, 140);
            this.btn_Inference.Name = "btn_Inference";
            this.btn_Inference.Size = new System.Drawing.Size(107, 71);
            this.btn_Inference.TabIndex = 7;
            this.btn_Inference.Text = "Run";
            this.btn_Inference.UseVisualStyleBackColor = true;
            this.btn_Inference.Click += new System.EventHandler(this.btn_Inference_Click);
            // 
            // btn_openImage
            // 
            this.btn_openImage.Location = new System.Drawing.Point(12, 96);
            this.btn_openImage.Name = "btn_openImage";
            this.btn_openImage.Size = new System.Drawing.Size(76, 38);
            this.btn_openImage.TabIndex = 16;
            this.btn_openImage.Text = "Open Image";
            this.btn_openImage.UseVisualStyleBackColor = true;
            this.btn_openImage.Click += new System.EventHandler(this.btn_openImage_Click);
            // 
            // btn_freeModel
            // 
            this.btn_freeModel.Enabled = false;
            this.btn_freeModel.Location = new System.Drawing.Point(12, 54);
            this.btn_freeModel.Name = "btn_freeModel";
            this.btn_freeModel.Size = new System.Drawing.Size(76, 36);
            this.btn_freeModel.TabIndex = 8;
            this.btn_freeModel.Text = "FreeModel";
            this.btn_freeModel.UseVisualStyleBackColor = true;
            this.btn_freeModel.Click += new System.EventHandler(this.btn_freeModel_Click);
            // 
            // btn_loadModel
            // 
            this.btn_loadModel.Location = new System.Drawing.Point(12, 12);
            this.btn_loadModel.Name = "btn_loadModel";
            this.btn_loadModel.Size = new System.Drawing.Size(76, 36);
            this.btn_loadModel.TabIndex = 9;
            this.btn_loadModel.Text = "LoadModel";
            this.btn_loadModel.UseVisualStyleBackColor = true;
            this.btn_loadModel.Click += new System.EventHandler(this.btn_loadModel_Click);
            // 
            // pictureBoxResult
            // 
            this.pictureBoxResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxResult.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxResult.Name = "pictureBoxResult";
            this.pictureBoxResult.Size = new System.Drawing.Size(520, 508);
            this.pictureBoxResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxResult.TabIndex = 0;
            this.pictureBoxResult.TabStop = false;
            // 
            // ckb_OrgSize
            // 
            this.ckb_OrgSize.AutoSize = true;
            this.ckb_OrgSize.Location = new System.Drawing.Point(12, 218);
            this.ckb_OrgSize.Name = "ckb_OrgSize";
            this.ckb_OrgSize.Size = new System.Drawing.Size(61, 16);
            this.ckb_OrgSize.TabIndex = 11;
            this.ckb_OrgSize.Text = "OrgSize";
            this.ckb_OrgSize.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(94, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Gpu";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(94, 80);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(38, 22);
            this.numericUpDown1.TabIndex = 13;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(202, 12);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.pictureBoxSrc);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pictureBoxResult);
            this.splitContainer1.Size = new System.Drawing.Size(1052, 510);
            this.splitContainer1.SplitterDistance = 526;
            this.splitContainer1.TabIndex = 17;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 270);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(170, 41);
            this.textBox2.TabIndex = 10;
            // 
            // num_scale
            // 
            this.num_scale.Location = new System.Drawing.Point(12, 240);
            this.num_scale.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.num_scale.Name = "num_scale";
            this.num_scale.Size = new System.Drawing.Size(79, 22);
            this.num_scale.TabIndex = 1;
            this.num_scale.Value = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 332);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Abnormal：";
            // 
            // StpmForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1266, 534);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.num_scale);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.btn_Inference);
            this.Controls.Add(this.btn_openImage);
            this.Controls.Add(this.btn_freeModel);
            this.Controls.Add(this.btn_loadModel);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.ckb_OrgSize);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Name = "StpmForm";
            this.Text = "STPMForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.num_scale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxSrc;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.Button btn_Inference;
        private System.Windows.Forms.Button btn_openImage;
        private System.Windows.Forms.Button btn_freeModel;
        private System.Windows.Forms.Button btn_loadModel;
        private System.Windows.Forms.PictureBox pictureBoxResult;
        private System.Windows.Forms.CheckBox ckb_OrgSize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.NumericUpDown num_scale;
        private System.Windows.Forms.Label label2;
    }
}