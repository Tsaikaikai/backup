﻿
namespace WindowsFormsApp1
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Ganormaly = new System.Windows.Forms.Button();
            this.btn_Yolo = new System.Windows.Forms.Button();
            this.btn_Classification = new System.Windows.Forms.Button();
            this.btn_STPM = new System.Windows.Forms.Button();
            this.btn_Regression = new System.Windows.Forms.Button();
            this.btn_MaskRcnn = new System.Windows.Forms.Button();
            this.btn_CycleGan = new System.Windows.Forms.Button();
            this.btn_Yolo_V7 = new System.Windows.Forms.Button();
            this.btn_ChangeDetection = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Ganormaly
            // 
            this.btn_Ganormaly.Location = new System.Drawing.Point(161, 12);
            this.btn_Ganormaly.Name = "btn_Ganormaly";
            this.btn_Ganormaly.Size = new System.Drawing.Size(143, 112);
            this.btn_Ganormaly.TabIndex = 0;
            this.btn_Ganormaly.Text = "Ganormaly";
            this.btn_Ganormaly.UseVisualStyleBackColor = true;
            this.btn_Ganormaly.Click += new System.EventHandler(this.btn_Ganormaly_Click);
            // 
            // btn_Yolo
            // 
            this.btn_Yolo.Location = new System.Drawing.Point(161, 261);
            this.btn_Yolo.Name = "btn_Yolo";
            this.btn_Yolo.Size = new System.Drawing.Size(143, 112);
            this.btn_Yolo.TabIndex = 0;
            this.btn_Yolo.Text = "Yolo";
            this.btn_Yolo.UseVisualStyleBackColor = true;
            this.btn_Yolo.Click += new System.EventHandler(this.btn_Yolo_Click);
            // 
            // btn_Classification
            // 
            this.btn_Classification.Location = new System.Drawing.Point(12, 143);
            this.btn_Classification.Name = "btn_Classification";
            this.btn_Classification.Size = new System.Drawing.Size(143, 112);
            this.btn_Classification.TabIndex = 0;
            this.btn_Classification.Text = "Classification";
            this.btn_Classification.UseVisualStyleBackColor = true;
            this.btn_Classification.Click += new System.EventHandler(this.btn_Classification_Click);
            // 
            // btn_STPM
            // 
            this.btn_STPM.Location = new System.Drawing.Point(310, 12);
            this.btn_STPM.Name = "btn_STPM";
            this.btn_STPM.Size = new System.Drawing.Size(143, 112);
            this.btn_STPM.TabIndex = 0;
            this.btn_STPM.Text = "STPM";
            this.btn_STPM.UseVisualStyleBackColor = true;
            this.btn_STPM.Click += new System.EventHandler(this.btn_STPM_Click);
            // 
            // btn_Regression
            // 
            this.btn_Regression.Location = new System.Drawing.Point(310, 143);
            this.btn_Regression.Name = "btn_Regression";
            this.btn_Regression.Size = new System.Drawing.Size(143, 112);
            this.btn_Regression.TabIndex = 0;
            this.btn_Regression.Text = "Regression";
            this.btn_Regression.UseVisualStyleBackColor = true;
            this.btn_Regression.Click += new System.EventHandler(this.btn_Regression_Click);
            // 
            // btn_MaskRcnn
            // 
            this.btn_MaskRcnn.Location = new System.Drawing.Point(12, 261);
            this.btn_MaskRcnn.Name = "btn_MaskRcnn";
            this.btn_MaskRcnn.Size = new System.Drawing.Size(143, 112);
            this.btn_MaskRcnn.TabIndex = 0;
            this.btn_MaskRcnn.Text = "MaskRcnn";
            this.btn_MaskRcnn.UseVisualStyleBackColor = true;
            this.btn_MaskRcnn.Click += new System.EventHandler(this.btn_MaskRcnn_Click);
            // 
            // btn_CycleGan
            // 
            this.btn_CycleGan.Location = new System.Drawing.Point(12, 12);
            this.btn_CycleGan.Name = "btn_CycleGan";
            this.btn_CycleGan.Size = new System.Drawing.Size(143, 112);
            this.btn_CycleGan.TabIndex = 0;
            this.btn_CycleGan.Text = "CycleGan";
            this.btn_CycleGan.UseVisualStyleBackColor = true;
            this.btn_CycleGan.Click += new System.EventHandler(this.btn_CycleGan_Click);
            // 
            // btn_Yolo_V7
            // 
            this.btn_Yolo_V7.Location = new System.Drawing.Point(161, 143);
            this.btn_Yolo_V7.Name = "btn_Yolo_V7";
            this.btn_Yolo_V7.Size = new System.Drawing.Size(143, 112);
            this.btn_Yolo_V7.TabIndex = 0;
            this.btn_Yolo_V7.Text = "YoloV7";
            this.btn_Yolo_V7.UseVisualStyleBackColor = true;
            this.btn_Yolo_V7.Click += new System.EventHandler(this.btn_Yolo_V7_Click);
            // 
            // btn_ChangeDetection
            // 
            this.btn_ChangeDetection.Location = new System.Drawing.Point(310, 261);
            this.btn_ChangeDetection.Name = "btn_ChangeDetection";
            this.btn_ChangeDetection.Size = new System.Drawing.Size(143, 112);
            this.btn_ChangeDetection.TabIndex = 1;
            this.btn_ChangeDetection.Text = "ChangeDetection";
            this.btn_ChangeDetection.UseVisualStyleBackColor = true;
            this.btn_ChangeDetection.Click += new System.EventHandler(this.btn_ChangeDetection_Click);
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 386);
            this.Controls.Add(this.btn_ChangeDetection);
            this.Controls.Add(this.btn_MaskRcnn);
            this.Controls.Add(this.btn_Regression);
            this.Controls.Add(this.btn_Yolo_V7);
            this.Controls.Add(this.btn_Yolo);
            this.Controls.Add(this.btn_Classification);
            this.Controls.Add(this.btn_STPM);
            this.Controls.Add(this.btn_CycleGan);
            this.Controls.Add(this.btn_Ganormaly);
            this.Name = "StartForm";
            this.Text = "Onnx Test Tool-220510";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Ganormaly;
        private System.Windows.Forms.Button btn_Yolo;
        private System.Windows.Forms.Button btn_Classification;
        private System.Windows.Forms.Button btn_STPM;
        private System.Windows.Forms.Button btn_Regression;
        private System.Windows.Forms.Button btn_MaskRcnn;
        private System.Windows.Forms.Button btn_CycleGan;
        private System.Windows.Forms.Button btn_Yolo_V7;
        private System.Windows.Forms.Button btn_ChangeDetection;
    }
}