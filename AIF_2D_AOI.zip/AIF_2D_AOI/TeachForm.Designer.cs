﻿
namespace AIF_2D_AOI
{
    partial class TeachForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExecute = new System.Windows.Forms.Button();
            this.pictureboxCpr = new System.Windows.Forms.PictureBox();
            this.pictureboxSrc = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonOutput = new System.Windows.Forms.Button();
            this.labelScore = new System.Windows.Forms.Label();
            this.labelRotate = new System.Windows.Forms.Label();
            this.labelPosY = new System.Windows.Forms.Label();
            this.labelPosX = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelAlignExeTime = new System.Windows.Forms.Label();
            this.buttonOutputAndCrop = new System.Windows.Forms.Button();
            this.buttonAutoAlign = new System.Windows.Forms.Button();
            this.buttonDetect = new System.Windows.Forms.Button();
            this.pictureboxRst = new System.Windows.Forms.PictureBox();
            this.buttonLoadModel = new System.Windows.Forms.Button();
            this.buttonFreeModel = new System.Windows.Forms.Button();
            this.labelTotalTime = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonBatchAutoAlign = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_setting = new System.Windows.Forms.Button();
            this.txb_recipePath = new System.Windows.Forms.TextBox();
            this.checkBox_SaveResult = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxCpr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxSrc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxRst)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonExecute
            // 
            this.buttonExecute.BackColor = System.Drawing.Color.White;
            this.buttonExecute.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonExecute.Location = new System.Drawing.Point(261, 583);
            this.buttonExecute.Name = "buttonExecute";
            this.buttonExecute.Size = new System.Drawing.Size(168, 51);
            this.buttonExecute.TabIndex = 0;
            this.buttonExecute.Text = "Execute";
            this.buttonExecute.UseVisualStyleBackColor = false;
            this.buttonExecute.Click += new System.EventHandler(this.buttonExecute_Click);
            // 
            // pictureboxCpr
            // 
            this.pictureboxCpr.AllowDrop = true;
            this.pictureboxCpr.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureboxCpr.Location = new System.Drawing.Point(559, 82);
            this.pictureboxCpr.Name = "pictureboxCpr";
            this.pictureboxCpr.Size = new System.Drawing.Size(480, 480);
            this.pictureboxCpr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureboxCpr.TabIndex = 1;
            this.pictureboxCpr.TabStop = false;
            this.pictureboxCpr.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureboxCpr_DragDrop);
            this.pictureboxCpr.DragEnter += new System.Windows.Forms.DragEventHandler(this.pictureboxCpr_DragEnter);
            this.pictureboxCpr.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureboxCpr_Paint);
            // 
            // pictureboxSrc
            // 
            this.pictureboxSrc.AllowDrop = true;
            this.pictureboxSrc.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureboxSrc.Location = new System.Drawing.Point(51, 82);
            this.pictureboxSrc.Name = "pictureboxSrc";
            this.pictureboxSrc.Size = new System.Drawing.Size(480, 480);
            this.pictureboxSrc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureboxSrc.TabIndex = 2;
            this.pictureboxSrc.TabStop = false;
            this.pictureboxSrc.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureboxSrc_DragDrop);
            this.pictureboxSrc.DragEnter += new System.Windows.Forms.DragEventHandler(this.pictureboxSrc_DragEnter);
            this.pictureboxSrc.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureboxSrc_Paint);
            this.pictureboxSrc.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureboxSrc_MouseDown);
            this.pictureboxSrc.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureSrc_MouseMove);
            this.pictureboxSrc.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureboxSrc_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(497, 575);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 28);
            this.label1.TabIndex = 3;
            this.label1.Text = "Pos X : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(497, 623);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "Pos Y : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(499, 719);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 28);
            this.label3.TabIndex = 6;
            this.label3.Text = "Score : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(494, 671);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 28);
            this.label4.TabIndex = 5;
            this.label4.Text = "Rotate : ";
            // 
            // buttonOutput
            // 
            this.buttonOutput.BackColor = System.Drawing.Color.White;
            this.buttonOutput.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonOutput.Location = new System.Drawing.Point(261, 662);
            this.buttonOutput.Name = "buttonOutput";
            this.buttonOutput.Size = new System.Drawing.Size(168, 51);
            this.buttonOutput.TabIndex = 7;
            this.buttonOutput.Text = "Output Image";
            this.buttonOutput.UseVisualStyleBackColor = false;
            this.buttonOutput.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // labelScore
            // 
            this.labelScore.AutoSize = true;
            this.labelScore.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelScore.Location = new System.Drawing.Point(567, 719);
            this.labelScore.Name = "labelScore";
            this.labelScore.Size = new System.Drawing.Size(60, 28);
            this.labelScore.TabIndex = 17;
            this.labelScore.Text = "NULL";
            // 
            // labelRotate
            // 
            this.labelRotate.AutoSize = true;
            this.labelRotate.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelRotate.Location = new System.Drawing.Point(567, 671);
            this.labelRotate.Name = "labelRotate";
            this.labelRotate.Size = new System.Drawing.Size(60, 28);
            this.labelRotate.TabIndex = 16;
            this.labelRotate.Text = "NULL";
            // 
            // labelPosY
            // 
            this.labelPosY.AutoSize = true;
            this.labelPosY.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelPosY.Location = new System.Drawing.Point(567, 623);
            this.labelPosY.Name = "labelPosY";
            this.labelPosY.Size = new System.Drawing.Size(60, 28);
            this.labelPosY.TabIndex = 15;
            this.labelPosY.Text = "NULL";
            // 
            // labelPosX
            // 
            this.labelPosX.AutoSize = true;
            this.labelPosX.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelPosX.Location = new System.Drawing.Point(567, 575);
            this.labelPosX.Name = "labelPosX";
            this.labelPosX.Size = new System.Drawing.Size(60, 28);
            this.labelPosX.TabIndex = 14;
            this.labelPosX.Text = "NULL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(455, 767);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 28);
            this.label5.TabIndex = 19;
            this.label5.Text = "Align Time : ";
            // 
            // labelAlignExeTime
            // 
            this.labelAlignExeTime.AutoSize = true;
            this.labelAlignExeTime.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelAlignExeTime.Location = new System.Drawing.Point(567, 767);
            this.labelAlignExeTime.Name = "labelAlignExeTime";
            this.labelAlignExeTime.Size = new System.Drawing.Size(60, 28);
            this.labelAlignExeTime.TabIndex = 20;
            this.labelAlignExeTime.Text = "NULL";
            // 
            // buttonOutputAndCrop
            // 
            this.buttonOutputAndCrop.BackColor = System.Drawing.Color.White;
            this.buttonOutputAndCrop.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonOutputAndCrop.Location = new System.Drawing.Point(261, 744);
            this.buttonOutputAndCrop.Name = "buttonOutputAndCrop";
            this.buttonOutputAndCrop.Size = new System.Drawing.Size(168, 51);
            this.buttonOutputAndCrop.TabIndex = 21;
            this.buttonOutputAndCrop.Text = "Output and Crop";
            this.buttonOutputAndCrop.UseVisualStyleBackColor = false;
            // 
            // buttonAutoAlign
            // 
            this.buttonAutoAlign.BackColor = System.Drawing.Color.White;
            this.buttonAutoAlign.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonAutoAlign.Location = new System.Drawing.Point(51, 662);
            this.buttonAutoAlign.Name = "buttonAutoAlign";
            this.buttonAutoAlign.Size = new System.Drawing.Size(168, 51);
            this.buttonAutoAlign.TabIndex = 22;
            this.buttonAutoAlign.Text = "Auto Align";
            this.buttonAutoAlign.UseVisualStyleBackColor = false;
            this.buttonAutoAlign.Click += new System.EventHandler(this.buttonAutoAlign_Click);
            // 
            // buttonDetect
            // 
            this.buttonDetect.BackColor = System.Drawing.Color.White;
            this.buttonDetect.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonDetect.Location = new System.Drawing.Point(784, 662);
            this.buttonDetect.Name = "buttonDetect";
            this.buttonDetect.Size = new System.Drawing.Size(168, 51);
            this.buttonDetect.TabIndex = 23;
            this.buttonDetect.Text = "Detect";
            this.buttonDetect.UseVisualStyleBackColor = false;
            this.buttonDetect.Click += new System.EventHandler(this.buttonDetect_Click);
            // 
            // pictureboxRst
            // 
            this.pictureboxRst.AllowDrop = true;
            this.pictureboxRst.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureboxRst.Location = new System.Drawing.Point(1071, 82);
            this.pictureboxRst.Name = "pictureboxRst";
            this.pictureboxRst.Size = new System.Drawing.Size(480, 480);
            this.pictureboxRst.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureboxRst.TabIndex = 24;
            this.pictureboxRst.TabStop = false;
            // 
            // buttonLoadModel
            // 
            this.buttonLoadModel.BackColor = System.Drawing.Color.White;
            this.buttonLoadModel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonLoadModel.Location = new System.Drawing.Point(784, 583);
            this.buttonLoadModel.Name = "buttonLoadModel";
            this.buttonLoadModel.Size = new System.Drawing.Size(168, 51);
            this.buttonLoadModel.TabIndex = 25;
            this.buttonLoadModel.Text = "Load Model";
            this.buttonLoadModel.UseVisualStyleBackColor = false;
            this.buttonLoadModel.Click += new System.EventHandler(this.buttonLoadModel_Click);
            // 
            // buttonFreeModel
            // 
            this.buttonFreeModel.BackColor = System.Drawing.Color.White;
            this.buttonFreeModel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonFreeModel.Location = new System.Drawing.Point(784, 744);
            this.buttonFreeModel.Name = "buttonFreeModel";
            this.buttonFreeModel.Size = new System.Drawing.Size(168, 51);
            this.buttonFreeModel.TabIndex = 34;
            this.buttonFreeModel.Text = "Free Model";
            this.buttonFreeModel.UseVisualStyleBackColor = false;
            this.buttonFreeModel.Click += new System.EventHandler(this.buttonFreeModel_Click);
            // 
            // labelTotalTime
            // 
            this.labelTotalTime.AutoSize = true;
            this.labelTotalTime.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelTotalTime.Location = new System.Drawing.Point(1126, 686);
            this.labelTotalTime.Name = "labelTotalTime";
            this.labelTotalTime.Size = new System.Drawing.Size(60, 28);
            this.labelTotalTime.TabIndex = 38;
            this.labelTotalTime.Text = "NULL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Noto Sans TC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(990, 685);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 28);
            this.label12.TabIndex = 37;
            this.label12.Text = "Inspect Time : ";
            // 
            // buttonBatchAutoAlign
            // 
            this.buttonBatchAutoAlign.BackColor = System.Drawing.Color.White;
            this.buttonBatchAutoAlign.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonBatchAutoAlign.Location = new System.Drawing.Point(51, 741);
            this.buttonBatchAutoAlign.Name = "buttonBatchAutoAlign";
            this.buttonBatchAutoAlign.Size = new System.Drawing.Size(168, 51);
            this.buttonBatchAutoAlign.TabIndex = 40;
            this.buttonBatchAutoAlign.Text = "Batch Auto Align";
            this.buttonBatchAutoAlign.UseVisualStyleBackColor = false;
            this.buttonBatchAutoAlign.Click += new System.EventHandler(this.buttonBatchAutoAlign_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(227, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 21);
            this.label9.TabIndex = 42;
            this.label9.Text = "NG Image";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(720, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(156, 21);
            this.label10.TabIndex = 43;
            this.label10.Text = "OK Image (Golden)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(1249, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(118, 21);
            this.label11.TabIndex = 44;
            this.label11.Text = "Inspect Result";
            // 
            // btn_setting
            // 
            this.btn_setting.BackColor = System.Drawing.Color.White;
            this.btn_setting.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_setting.Location = new System.Drawing.Point(51, 12);
            this.btn_setting.Name = "btn_setting";
            this.btn_setting.Size = new System.Drawing.Size(81, 55);
            this.btn_setting.TabIndex = 45;
            this.btn_setting.Text = "Setting";
            this.btn_setting.UseVisualStyleBackColor = false;
            this.btn_setting.Click += new System.EventHandler(this.btn_setting_Click);
            // 
            // txb_recipePath
            // 
            this.txb_recipePath.Location = new System.Drawing.Point(151, 12);
            this.txb_recipePath.Name = "txb_recipePath";
            this.txb_recipePath.Size = new System.Drawing.Size(888, 22);
            this.txb_recipePath.TabIndex = 46;
            // 
            // checkBox_SaveResult
            // 
            this.checkBox_SaveResult.AutoSize = true;
            this.checkBox_SaveResult.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_SaveResult.Location = new System.Drawing.Point(66, 595);
            this.checkBox_SaveResult.Name = "checkBox_SaveResult";
            this.checkBox_SaveResult.Size = new System.Drawing.Size(144, 31);
            this.checkBox_SaveResult.TabIndex = 47;
            this.checkBox_SaveResult.Text = "Save Result";
            this.checkBox_SaveResult.UseVisualStyleBackColor = true;
            // 
            // TeachForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 819);
            this.Controls.Add(this.checkBox_SaveResult);
            this.Controls.Add(this.txb_recipePath);
            this.Controls.Add(this.btn_setting);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.buttonBatchAutoAlign);
            this.Controls.Add(this.labelTotalTime);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.buttonFreeModel);
            this.Controls.Add(this.buttonLoadModel);
            this.Controls.Add(this.pictureboxRst);
            this.Controls.Add(this.buttonDetect);
            this.Controls.Add(this.buttonAutoAlign);
            this.Controls.Add(this.buttonOutputAndCrop);
            this.Controls.Add(this.labelAlignExeTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelScore);
            this.Controls.Add(this.labelRotate);
            this.Controls.Add(this.labelPosY);
            this.Controls.Add(this.labelPosX);
            this.Controls.Add(this.buttonOutput);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureboxSrc);
            this.Controls.Add(this.pictureboxCpr);
            this.Controls.Add(this.buttonExecute);
            this.Name = "TeachForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AIF 2D AOI Tool";
            this.Load += new System.EventHandler(this.TeachForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxCpr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxSrc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxRst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExecute;
        private System.Windows.Forms.PictureBox pictureboxCpr;
        private System.Windows.Forms.PictureBox pictureboxSrc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonOutput;
        private System.Windows.Forms.Label labelScore;
        private System.Windows.Forms.Label labelRotate;
        private System.Windows.Forms.Label labelPosY;
        private System.Windows.Forms.Label labelPosX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelAlignExeTime;
        private System.Windows.Forms.Button buttonOutputAndCrop;
        private System.Windows.Forms.Button buttonAutoAlign;
        private System.Windows.Forms.Button buttonDetect;
        private System.Windows.Forms.PictureBox pictureboxRst;
        private System.Windows.Forms.Button buttonLoadModel;
        private System.Windows.Forms.Button buttonFreeModel;
        private System.Windows.Forms.Label labelTotalTime;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonBatchAutoAlign;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_setting;
        private System.Windows.Forms.TextBox txb_recipePath;
        private System.Windows.Forms.CheckBox checkBox_SaveResult;
    }
}

