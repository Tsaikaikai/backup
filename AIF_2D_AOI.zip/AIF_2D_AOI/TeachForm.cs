﻿using Brandy;
//using AIF_2D;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using PatternMatch;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIF_2D_AOI
{
    public partial class TeachForm : Form
    {
        #region Initial
        public bool SaveCrop;
        public Mat SrcImage;
        public Mat CprImage;
        public Mat AlignSrcImage;
        public Mat AlignCprImage;

        private bool IsSelecting = false;  // 標記是否正在選擇區域
        private Rectangle SelectionRectangle;  // 標記選擇區域的矩形
        private PointF[] MatchRectangle = new PointF[4];  // 標記選擇區域的矩形

        public int PatternCenterX;
        public int PatternCenterY;
        public int MatchCenterX;
        public int MatchCenterY;
        public double MatchRotate;
        public double MatchScore;

        //creat pattern
        int PictureBoxCenterX = 256;
        int PictureBoxCenterY = 256;
        int PictureBoxCropWidth = 448;
        int PictureBoxCropHeight = 448;

        public int DetectSize;
        public ChangeDetectionModel core;

        AIFAlgorithm aifAlgorithm = new AIFAlgorithm();
        string ConfigPath = "./AlgorithmConfig.xml";

        public string SrcImagePath;
        public string CprImagePath;
        public string PatternPath;
        public string ResultPath = ".\\result\\";
        public string AlignPath = ".\\align\\";

        public class CutImage : IDisposable
        {
            public Mat ImageA;
            public Mat ImageB;
            public float[] floatImageA;
            public float[] floatImageB;
            public int X;
            public int Y;
            public Bitmap Result;
            bool _disposed;

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            ~CutImage()
            {
                Dispose();
            }
            protected virtual void Dispose(bool disposing)
            {
                if (_disposed) return;
                if (disposing)
                {
                    if (ImageA != null)
                        ImageA.Dispose();
                    if (ImageB != null)
                        ImageB.Dispose();
                }
                _disposed = true;
            }
        }
        public TeachForm()
        {
            InitializeComponent();
            buttonExecute.Enabled = false;
            buttonOutput.Enabled = false;
            buttonOutputAndCrop.Enabled = false;
            buttonDetect.Enabled = false;
            buttonFreeModel.Enabled = false;
            if (!Directory.Exists(ResultPath)) Directory.CreateDirectory(ResultPath);
            if (!Directory.Exists(AlignPath)) Directory.CreateDirectory(AlignPath);
        }
        private void TeachForm_Load(object sender, EventArgs e)
        {
            //load recipe
            aifAlgorithm.LoadConfig(ConfigPath);
            txb_recipePath.Text = ConfigPath;
        }
        #endregion

        #region Post Process
        private void buttonOutput_Click(object sender, EventArgs e)
        {
            Mat cropSrcImage = new Mat();
            Mat cropCprImage = new Mat();

            string srcFileName = Path.GetFileName(SrcImagePath);
            string cprFileName = Path.GetFileName(CprImagePath);

            cropSrcImage.SaveImage(AlignPath + "\\" + srcFileName);
            cropCprImage.SaveImage(AlignPath + "\\" + cprFileName);
        }
        #endregion

        #region UI Control
        private void buttonExecute_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Mat patternImage = Cv2.ImRead(PatternPath);
            Mat cprImage = Cv2.ImRead(CprImagePath);
            List<PatternMatchResult> resultList = new List<PatternMatchResult>();
            aifAlgorithm.FastPatternMatch(patternImage, cprImage, ref resultList);
            if (resultList.Count != 1)
            {
                ShowMatchFail();
                return;
            }

            PatternMatchResult result = resultList[0];
            ShowResult(result);
            int matchCenterX = Convert.ToInt32(result.ptCenter.X);
            int matchCenterY = Convert.ToInt32(result.ptCenter.Y);
            double matchRotate = Math.Round(result.Angle, 3);

            stopwatch.Stop();
            labelAlignExeTime.Text = stopwatch.Elapsed.TotalMilliseconds.ToString() + " ms";
            pictureboxCpr.Invalidate();
            buttonOutput.Enabled = true;
            buttonOutputAndCrop.Enabled = true;

            //save aligned cpr image
            Mat rotateCprImage = RotateImage(CprImage, matchCenterX, matchCenterY, -matchRotate);
            Rect patternCropRoi = UIRecToImageRec(new Rectangle(PictureBoxCenterX - PictureBoxCropWidth/2,
                                                                PictureBoxCenterY - PictureBoxCropHeight/2,
                                                                PictureBoxCropWidth,
                                                                PictureBoxCropHeight));

            Rect cprCropRoi = new Rect(patternCropRoi.X + matchCenterX - PatternCenterX,
                                    patternCropRoi.Y + matchCenterY - PatternCenterY,
                                    patternCropRoi.Width,
                                    patternCropRoi.Height);

            AlignSrcImage = CropImage(SrcImage, patternCropRoi);
            AlignCprImage = CropImage(rotateCprImage, cprCropRoi);

            if (AlignCprImage == null)
            {
                ShowOutofRegion();
                return;
            }

            //save image
            if (checkBox_SaveResult.Checked)
            {
                AlignSrcImage.SaveImage(AlignPath + Path.GetFileName(SrcImagePath));
                AlignCprImage.SaveImage(AlignPath + Path.GetFileName(CprImagePath));
            }
        }
        private bool IsImageFile(string filename)
        {
            string extension = Path.GetExtension(filename);
            // 檢查文件擴展名是否為常見的圖像擴展名，你可以根據需要擴展這個檢查
            return (extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".png", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".bmp", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".tiff", StringComparison.OrdinalIgnoreCase)
                    );
        }
        private void pictureboxSrc_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
        private void pictureboxSrc_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                SrcImagePath = files[0];  // 只處理第一個拖放的文件
                if (IsImageFile(SrcImagePath))
                {
                    pictureboxSrc.Image = Image.FromFile(SrcImagePath);
                    SrcImage = Cv2.ImRead(SrcImagePath);
                    buttonExecute.Enabled = false;
                    buttonOutput.Enabled = false;
                    buttonOutputAndCrop.Enabled = false;
                    MatchRectangle = new PointF[4];
                    pictureboxCpr.Invalidate();
                    labelPosX.Text = "";
                    labelPosY.Text = "";
                    labelRotate.Text = "";
                    labelScore.Text = "";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        private void pictureboxCpr_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
        private void pictureboxCpr_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                CprImagePath = files[0];  // 只處理第一個拖放的文件
                if (IsImageFile(CprImagePath))
                {
                    pictureboxCpr.Image = Image.FromFile(CprImagePath);
                    CprImage = Cv2.ImRead(CprImagePath);
                    MatchRectangle = new PointF[4];
                    pictureboxCpr.Invalidate();
                    labelPosX.Text = "";
                    labelPosY.Text = "";
                    labelRotate.Text = "";
                    labelScore.Text = "";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        private void pictureboxSrc_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                IsSelecting = true;
                SelectionRectangle = new Rectangle(e.Location, new System.Drawing.Size());
            }
        }
        private void pictureSrc_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsSelecting)
            {
                SelectionRectangle.Width = e.X - SelectionRectangle.X;
                SelectionRectangle.Height = e.Y - SelectionRectangle.Y;
                pictureboxSrc.Invalidate();
            }
        }
        private void pictureboxSrc_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsSelecting)
            {
                IsSelecting = false;
                Rect patternCropRoi = UIRecToImageRec(SelectionRectangle);
                PatternCenterX = Convert.ToInt32(patternCropRoi.X + patternCropRoi.Width / 2);
                PatternCenterY = Convert.ToInt32(patternCropRoi.Y + patternCropRoi.Height / 2);

                Mat croppedImage = CropImage(SrcImage, patternCropRoi);
                if (croppedImage == null)
                {
                    return;
                }
                PatternPath = "./pattern.bmp";
                croppedImage.SaveImage(PatternPath);
                buttonExecute.Enabled = true;
            }
        }
        private void pictureboxSrc_Paint(object sender, PaintEventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null) return;
                
            if (IsSelecting)
            {
                e.Graphics.DrawRectangle(Pens.Red, SelectionRectangle);
            }
            else
            {
                int alignBuffer = 128;
                double wScale = (double)pictureboxSrc.Width / pictureboxSrc.Image.Width;
                double hScale = (double)pictureboxSrc.Height / pictureboxSrc.Image.Height;
                Rectangle autoSelectionRectangle = new Rectangle(Convert.ToInt32(alignBuffer * wScale),
                                                                 Convert.ToInt32(alignBuffer * hScale),
                                                                 Convert.ToInt32((pictureboxSrc.Image.Width - alignBuffer * 2) * wScale),
                                                                 Convert.ToInt32((pictureboxSrc.Image.Height - alignBuffer * 2) * hScale));
                e.Graphics.DrawRectangle(Pens.Red, autoSelectionRectangle);
            }
        }
        private void PictureboxCpr_Paint(object sender, PaintEventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null) return;

            PointF[] drawMatchPolygon = new PointF[4];
            for (int i = 0; i < 4; i++)
            {
                drawMatchPolygon[i].X = MatchRectangle[i].X * pictureboxCpr.Width / pictureboxCpr.Image.Width;
                drawMatchPolygon[i].Y = MatchRectangle[i].Y * pictureboxCpr.Height / pictureboxCpr.Image.Height;
            }
            e.Graphics.DrawPolygon(Pens.Red, drawMatchPolygon);
        }
        #endregion

        #region Tool
        private Mat CropImage(Mat sourceImage, Rect cropArea)
        {
            // Create a Region of Interest (ROI) based on the crop area
            if (cropArea.X < 0 || 
                cropArea.Y < 0 || 
                cropArea.X + cropArea.Width > sourceImage.Width || 
                cropArea.Y + cropArea.Height > sourceImage.Height)
                return null;

            Mat croppedImage = new Mat(sourceImage, cropArea);
            return croppedImage;
        }
        private Rect UIRecToImageRec(Rectangle selectionRectangle)
        {
            // 將選擇區域的座標和大小進行調整，以確保都是正值
            if (selectionRectangle.Width < 0)
            {
                selectionRectangle.X += selectionRectangle.Width;
                selectionRectangle.Width = -selectionRectangle.Width;
            }
            if (selectionRectangle.Height < 0)
            {
                selectionRectangle.Y += selectionRectangle.Height;
                selectionRectangle.Height = -selectionRectangle.Height;
            }

            int patternCropX = Convert.ToInt32(selectionRectangle.X * pictureboxSrc.Image.Width / pictureboxSrc.Width);
            int patternCropY = Convert.ToInt32(selectionRectangle.Y * pictureboxSrc.Image.Height / pictureboxSrc.Height);
            int patternWidth = Convert.ToInt32(selectionRectangle.Width * pictureboxSrc.Image.Width / pictureboxSrc.Width);
            int patternHeight = Convert.ToInt32(selectionRectangle.Height * pictureboxSrc.Image.Height / pictureboxSrc.Height);

            Rect patternCropRoi = new Rect(patternCropX, patternCropY, patternWidth, patternHeight);
            return patternCropRoi;
        }

        private Mat RotateImage(Mat image,int rotateX,int rotateY, double angle)
        {
            // 設定旋轉中心點
            Point2f center = new Point2f(rotateY, rotateX);

            // 計算旋轉矩陣
            Mat rotationMatrix = Cv2.GetRotationMatrix2D(center, angle, 1.0);

            // 進行圖片旋轉
            Mat rotatedImage = new Mat();
            Cv2.WarpAffine(image, rotatedImage, rotationMatrix, image.Size());
            return rotatedImage;
        }

        private void ShowMatchFail()
        {
            labelPosX.Text = "match fail";
            labelPosY.Text = "match fail";
            labelRotate.Text = "match fail";
            labelScore.Text = "match fail";
            labelAlignExeTime.Text = "match fail";
            MatchRectangle = new PointF[4];
            pictureboxCpr.Invalidate();
        }
        private void ShowOutofRegion()
        {
            labelPosX.Text = "out of region";
            labelPosY.Text = "out of region";
            labelRotate.Text = "out of region";
            labelScore.Text = "out of region";
            labelAlignExeTime.Text = "out of region";
            MatchRectangle = new PointF[4];
            pictureboxCpr.Invalidate();
        }
        private void ShowResult(PatternMatchResult result)
        {
            MatchRectangle[0] = result.ptLT;
            MatchRectangle[1] = result.ptRT;
            MatchRectangle[2] = result.ptRB;
            MatchRectangle[3] = result.ptLB;
            MatchCenterX = Convert.ToInt32(result.ptCenter.X);
            MatchCenterY = Convert.ToInt32(result.ptCenter.Y);
            MatchRotate = Math.Round(result.Angle, 3);
            MatchScore = Math.Round(result.Score, 5);

            labelPosX.Text = MatchCenterX.ToString();
            labelPosY.Text = MatchCenterY.ToString();
            labelRotate.Text = MatchRotate.ToString() + " deg";
            labelScore.Text = MatchScore.ToString();
        }
        #endregion

        private void buttonAutoAlign_Click(object sender, EventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null ) return;
            PatternMatchResult alignResult = new PatternMatchResult();

            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                
                if (aifAlgorithm.DoAutoAlignment(SrcImage, CprImage,ref AlignSrcImage,ref AlignCprImage,ref alignResult))
                {
                    ShowResult(alignResult);
                    stopwatch.Stop();

                    pictureboxSrc.Invalidate();
                    pictureboxCpr.Invalidate();
                    labelAlignExeTime.Text = stopwatch.Elapsed.TotalMilliseconds.ToString() + " ms";

                    if (checkBox_SaveResult.Checked)
                    {
                        AlignSrcImage.SaveImage(AlignPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_pattern" + Path.GetExtension(SrcImagePath));
                        AlignCprImage.SaveImage(AlignPath + Path.GetFileName(CprImagePath));
                    }
                }
            }
            catch(Exception ex)
            {
                ShowMatchFail();
                MessageBox.Show(ex.ToString());
            }
        }

        private void buttonLoadModel_Click(object sender, EventArgs e)
        {
            try
            {
                if (aifAlgorithm.DoLoadAIModel())
                {
                    buttonLoadModel.BackColor = Color.LimeGreen;
                    buttonDetect.Enabled = true;
                    buttonFreeModel.Enabled = true;
                    MessageBox.Show("Load Model Successful !");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load Model Fail : " + ex.Message);
            }
        }

        private void buttonDetect_Click(object sender, EventArgs e)
        {
            Bitmap mask = null;
            Bitmap result = null;
            List<AIFAlgorithm.Defect> defectList = new List<AIFAlgorithm.Defect>();
            Stopwatch sw = new Stopwatch();
            try
            {
                if (AlignSrcImage == null || AlignCprImage == null) return;

                sw.Start();
                if(aifAlgorithm.DoInspection(AlignSrcImage, AlignCprImage,ref mask) != true)
                {

                }
                sw.Stop();
                
                if (aifAlgorithm.DoOutputResult(SrcImage, mask, ref result, ref defectList))
                {

                }

                labelTotalTime.Text = sw.Elapsed.TotalMilliseconds.ToString() + " ms";
                pictureboxRst.Image = result;
                pictureboxRst.Invalidate();
                result.Save(ResultPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_result.png");
                mask.Save(ResultPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_mask.png");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mask?.Dispose();
                defectList?.Clear();
            }
        }

        private void buttonFreeModel_Click(object sender, EventArgs e)
        {
            if (aifAlgorithm.DoDisposeAIModel())
            {
                buttonDetect.Enabled = false;
                buttonLoadModel.Enabled = true;
                buttonLoadModel.BackColor = Color.White;
                buttonFreeModel.Enabled = false;
            }
        }

        private void buttonBatchAutoAlign_Click(object sender, EventArgs e)
        {
            Mat srcImage = new Mat();
            Mat cprImage = new Mat();
            Mat alignSrcImage = new Mat();
            Mat alignCprImage = new Mat();
            PatternMatchResult alignResult = new PatternMatchResult();
            Bitmap maskImage = null;
            OpenFileDialog openFileDialogSrc = new OpenFileDialog();
            openFileDialogSrc.Title = "Select the image to be detected.";
            openFileDialogSrc.Multiselect = true; // 允許多選
            openFileDialogSrc.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.tif";

            FolderBrowserDialog folderBrowserDialogCpr = new FolderBrowserDialog();
            string alignFail = "";

            try
            {
                if (openFileDialogSrc.ShowDialog() == DialogResult.OK)
                {
                    folderBrowserDialogCpr.Description = "Select the golden sample folder.";
                    folderBrowserDialogCpr.SelectedPath = Path.GetDirectoryName(openFileDialogSrc.FileName);
                    string[] ngFileNames = openFileDialogSrc.FileNames;

                    if (folderBrowserDialogCpr.ShowDialog() == DialogResult.OK)
                    {
                        foreach (string srcImagePath in ngFileNames)
                        {
                            string cprImagePath = folderBrowserDialogCpr.SelectedPath + "\\" + Path.GetFileName(srcImagePath);

                            if (File.Exists(srcImagePath) && File.Exists(cprImagePath))
                            {
                                srcImage = Cv2.ImRead(srcImagePath);
                                cprImage = Cv2.ImRead(cprImagePath);
                                pictureboxSrc.Image = Image.FromFile(srcImagePath);
                                pictureboxCpr.Image = Image.FromFile(cprImagePath);

                                try
                                {
                                    aifAlgorithm.DoAutoAlignment(srcImage, cprImage, ref alignSrcImage, ref alignCprImage, ref alignResult);
                                }
                                catch(Exception)
                                {
                                    alignFail = alignFail + Path.GetFileName(srcImagePath) + ", ";
                                    continue;
                                }

                                aifAlgorithm.DoInspection(alignSrcImage, alignCprImage,ref maskImage);
                                Bitmap resultImage = aifAlgorithm.DrawResult(maskImage, srcImage);
                                List<AIFAlgorithm.Defect> defectList = aifAlgorithm.ShowDefect(maskImage);
                                pictureboxRst.Image = resultImage;
                                resultImage.Save(ResultPath + Path.GetFileNameWithoutExtension(srcImagePath) + "_result.png");
                                maskImage.Save(ResultPath + Path.GetFileNameWithoutExtension(srcImagePath) + "_mask.png");
                            }
                            else
                            {
                                alignFail = alignFail + Path.GetFileName(srcImagePath) + ", ";
                                continue;
                            }
                        }

                        MessageBox.Show("Alignment fail list ->" + alignFail);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Auto Align fail." + ex.Message);
            }
            finally
            {
                srcImage.Dispose();
                cprImage.Dispose();
                alignSrcImage.Dispose();
                alignCprImage.Dispose();
            }
        }

        private void buttonBatchDetect_Click(object sender, EventArgs e)
        {

        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            FormBootConfig frm = new FormBootConfig();
            frm.SetConfig(ConfigPath);
            frm.ShowDialog(this);
            try
            {
                aifAlgorithm.LoadConfig(ConfigPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
