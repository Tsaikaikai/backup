﻿using System;
using System.Windows.Forms;
using DDABridge;
using DDAExecutor;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace AMC_InferenceTool
{
    public partial class InferenceTool : Form
    {
        public InferenceTool()
        {
            InitializeComponent();
            //Program.OriginalTest();
        }


        private void btn_selectFolder_Click(object sender, EventArgs e)
        {
            string selectPath = null;
            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.Description = "Please Select Inference Folder";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    MessageBox.Show(this, "Folder can't be Null.", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    selectPath = dialog.SelectedPath;
                    textBox_imagePath.Text = selectPath;
                }
            }

            JArray imagePaths = new JArray { };
            foreach (string newPath in Directory.GetFiles(selectPath, "*.*", SearchOption.TopDirectoryOnly))
            {
                if(newPath.ToUpper().EndsWith(".JPG") || newPath.ToUpper().EndsWith(".PNG") || 
                    newPath.ToUpper().EndsWith(".TIFF") || newPath.ToUpper().EndsWith(".BMP"))
                {
                    imagePaths.Add(newPath);
                }
            }
            string predictResponse = Program.TestPredict(this.textBox_predictJson.Text, imagePaths);

            JObject results = JObject.Parse(predictResponse);
            foreach (KeyValuePair<string, JToken> result in results)
            {
                dataGridView_result.Rows.Add(result.Key, result.Value.ToString());
            }
        }

        private void btn_loadJson_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false;
            dialog.Title = "Please Select Predict Json File.";
            dialog.Filter = "Json file|*.json";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox_predictJson.Text = dialog.FileName;
            }
        }
    }
}
