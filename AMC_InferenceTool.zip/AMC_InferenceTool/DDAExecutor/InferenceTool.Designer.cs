﻿
namespace AMC_InferenceTool
{
    partial class InferenceTool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_loadJson = new System.Windows.Forms.Button();
            this.btn_inference = new System.Windows.Forms.Button();
            this.textBox_predictJson = new System.Windows.Forms.TextBox();
            this.textBox_imagePath = new System.Windows.Forms.TextBox();
            this.dataGridView_result = new System.Windows.Forms.DataGridView();
            this.prediction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.image_path = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_result)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_loadJson
            // 
            this.btn_loadJson.Location = new System.Drawing.Point(21, 53);
            this.btn_loadJson.Name = "btn_loadJson";
            this.btn_loadJson.Size = new System.Drawing.Size(123, 38);
            this.btn_loadJson.TabIndex = 0;
            this.btn_loadJson.Text = "Load Predict Json";
            this.btn_loadJson.UseVisualStyleBackColor = true;
            this.btn_loadJson.Click += new System.EventHandler(this.btn_loadJson_Click);
            // 
            // btn_inference
            // 
            this.btn_inference.Location = new System.Drawing.Point(21, 135);
            this.btn_inference.Name = "btn_inference";
            this.btn_inference.Size = new System.Drawing.Size(123, 38);
            this.btn_inference.TabIndex = 1;
            this.btn_inference.Text = "Inference";
            this.btn_inference.UseVisualStyleBackColor = true;
            this.btn_inference.Click += new System.EventHandler(this.btn_selectFolder_Click);
            // 
            // textBox_predictJson
            // 
            this.textBox_predictJson.Location = new System.Drawing.Point(172, 63);
            this.textBox_predictJson.Name = "textBox_predictJson";
            this.textBox_predictJson.Size = new System.Drawing.Size(595, 22);
            this.textBox_predictJson.TabIndex = 2;
            // 
            // textBox_imagePath
            // 
            this.textBox_imagePath.Location = new System.Drawing.Point(172, 145);
            this.textBox_imagePath.Name = "textBox_imagePath";
            this.textBox_imagePath.Size = new System.Drawing.Size(595, 22);
            this.textBox_imagePath.TabIndex = 3;
            // 
            // dataGridView_result
            // 
            this.dataGridView_result.AllowUserToDeleteRows = false;
            this.dataGridView_result.AllowUserToOrderColumns = true;
            this.dataGridView_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prediction,
            this.image_path});
            this.dataGridView_result.Location = new System.Drawing.Point(21, 217);
            this.dataGridView_result.Name = "dataGridView_result";
            this.dataGridView_result.ReadOnly = true;
            this.dataGridView_result.RowTemplate.Height = 24;
            this.dataGridView_result.Size = new System.Drawing.Size(746, 205);
            this.dataGridView_result.TabIndex = 4;
            // 
            // prediction
            // 
            this.prediction.HeaderText = "prediction";
            this.prediction.Name = "prediction";
            this.prediction.ReadOnly = true;
            // 
            // image_path
            // 
            this.image_path.HeaderText = "image_path";
            this.image_path.Name = "image_path";
            this.image_path.ReadOnly = true;
            this.image_path.Width = 600;
            // 
            // InferenceTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView_result);
            this.Controls.Add(this.textBox_imagePath);
            this.Controls.Add(this.textBox_predictJson);
            this.Controls.Add(this.btn_inference);
            this.Controls.Add(this.btn_loadJson);
            this.Name = "InferenceTool";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_result)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_loadJson;
        private System.Windows.Forms.Button btn_inference;
        private System.Windows.Forms.TextBox textBox_predictJson;
        private System.Windows.Forms.TextBox textBox_imagePath;
        private System.Windows.Forms.DataGridView dataGridView_result;
        private System.Windows.Forms.DataGridViewTextBoxColumn prediction;
        private System.Windows.Forms.DataGridViewTextBoxColumn image_path;
    }
}