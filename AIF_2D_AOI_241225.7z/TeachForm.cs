﻿using Brandy;
//using AIF_2D;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using PatternMatch;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIF_2D_AOI
{
    public partial class TeachForm : Form
    {
        #region Initial
        public bool SaveCrop;
        public Mat SrcImage;
        public Mat CprImage;
        public Mat AlignSrcImage;
        public Mat AlignCprImage;

        private bool IsSelecting = false;  // 標記是否正在選擇區域
        private Rectangle SelectionRectangle;  // 標記選擇區域的矩形
        private PointF[] MatchRectangle = new PointF[4];  // 標記選擇區域的矩形

        public int PatternCenterX;
        public int PatternCenterY;
        public int MatchCenterX;
        public int MatchCenterY;
        public double MatchRotate;
        public double MatchScore;

        //creat pattern
        int PictureBoxCenterX = 256;
        int PictureBoxCenterY = 256;
        int PictureBoxCropWidth = 448;
        int PictureBoxCropHeight = 448;

        public int DetectSize;
        public ChangeDetectionModel core;

        AIFAlgorithm aifAlgorithm = new AIFAlgorithm();
        string ConfigPath = "./AlgorithmConfig.xml";

        public string SrcImagePath;
        public string CprImagePath;
        public string PatternPath;
        public string ResultPath = ".\\result\\";
        public string AlignPath = ".\\align\\";

        public int PATCH_SIZE = 448;

        public class CutImage : IDisposable
        {
            public Mat ImageA;
            public Mat ImageB;
            public float[] floatImageA;
            public float[] floatImageB;
            public int X;
            public int Y;
            public Bitmap Result;
            bool _disposed;

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            ~CutImage()
            {
                Dispose();
            }
            protected virtual void Dispose(bool disposing)
            {
                if (_disposed) return;
                if (disposing)
                {
                    if (ImageA != null)
                        ImageA.Dispose();
                    if (ImageB != null)
                        ImageB.Dispose();
                }
                _disposed = true;
            }
        }

        private ProgressBar progressBar1;
        private Label progressLabel;

        private void InitializeProgressControls()
        {
            // 初始化進度條
            progressBar1 = new ProgressBar
            {
                Width = 250,
                Height = 23,
                Location = new System.Drawing.Point(48, this.Height - 80),
                Visible = false
            };

            // 初始化進度標籤
            progressLabel = new Label
            {
                AutoSize = true,
                Location = new System.Drawing.Point(progressBar1.Left, progressBar1.Top - 20),
                Visible = false
            };

            this.Controls.Add(progressBar1);
            this.Controls.Add(progressLabel);
        }
        public TeachForm()
        {
            InitializeComponent();
            InitializeProgressControls();
            buttonExecute.Enabled = false;
            buttonDetect.Enabled = false;
            buttonFreeModel.Enabled = false;
            if (!Directory.Exists(ResultPath)) Directory.CreateDirectory(ResultPath);
            if (!Directory.Exists(AlignPath)) Directory.CreateDirectory(AlignPath);
        }
        private void TeachForm_Load(object sender, EventArgs e)
        {
            //load recipe
            aifAlgorithm.LoadConfig(ConfigPath);
            txb_recipePath.Text = ConfigPath;
        }
        #endregion

        #region UI Control
        private void buttonExecute_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Mat patternImage = Cv2.ImRead(PatternPath);
            Mat cprImage = Cv2.ImRead(CprImagePath);
            List<PatternMatchResult> resultList = new List<PatternMatchResult>();
            aifAlgorithm.FastPatternMatch(patternImage, cprImage, ref resultList);
            if (resultList.Count != 1)
            {
                ShowMatchFail();
                return;
            }

            PatternMatchResult result = resultList[0];
            ShowResult(result);
            int matchCenterX = Convert.ToInt32(result.ptCenter.X);
            int matchCenterY = Convert.ToInt32(result.ptCenter.Y);
            double matchRotate = Math.Round(result.Angle, 3);

            stopwatch.Stop();
            labelAlignExeTime.Text = stopwatch.Elapsed.TotalMilliseconds.ToString() + " ms";
            pictureboxCpr.Invalidate();

            //save aligned cpr image
            Mat rotateCprImage = RotateImage(CprImage, matchCenterX, matchCenterY, -matchRotate);
            Rect patternCropRoi = UIRecToImageRec(new Rectangle(PictureBoxCenterX - PictureBoxCropWidth/2,
                                                                PictureBoxCenterY - PictureBoxCropHeight/2,
                                                                PictureBoxCropWidth,
                                                                PictureBoxCropHeight));

            Rect cprCropRoi = new Rect(patternCropRoi.X + matchCenterX - PatternCenterX,
                                    patternCropRoi.Y + matchCenterY - PatternCenterY,
                                    patternCropRoi.Width,
                                    patternCropRoi.Height);

            AlignSrcImage = CropImage(SrcImage, patternCropRoi);
            AlignCprImage = CropImage(rotateCprImage, cprCropRoi);

            if (AlignCprImage == null)
            {
                ShowOutofRegion();
                return;
            }

            //save image
            if (checkBox_SaveResult.Checked)
            {
                AlignSrcImage.SaveImage(AlignPath + Path.GetFileName(SrcImagePath));
                AlignCprImage.SaveImage(AlignPath + Path.GetFileName(CprImagePath));
            }
        }
        private bool IsImageFile(string filename)
        {
            string extension = Path.GetExtension(filename);
            // 檢查文件擴展名是否為常見的圖像擴展名，你可以根據需要擴展這個檢查
            return (extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".png", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".bmp", StringComparison.OrdinalIgnoreCase) ||
                    extension.Equals(".tiff", StringComparison.OrdinalIgnoreCase)
                    );
        }
        private void pictureboxSrc_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
        private void pictureboxSrc_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                SrcImagePath = files[0];  // 只處理第一個拖放的文件
                if (IsImageFile(SrcImagePath))
                {
                    pictureboxSrc.Image = Image.FromFile(SrcImagePath);
                    SrcImage = Cv2.ImRead(SrcImagePath);
                    buttonExecute.Enabled = false;
                    MatchRectangle = new PointF[4];
                    pictureboxCpr.Invalidate();
                    labelPosX.Text = "";
                    labelPosY.Text = "";
                    labelRotate.Text = "";
                    labelScore.Text = "";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        private void pictureboxCpr_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
        private void pictureboxCpr_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files.Length > 0)
            {
                CprImagePath = files[0];  // 只處理第一個拖放的文件
                if (IsImageFile(CprImagePath))
                {
                    pictureboxCpr.Image = Image.FromFile(CprImagePath);
                    CprImage = Cv2.ImRead(CprImagePath);
                    MatchRectangle = new PointF[4];
                    pictureboxCpr.Invalidate();
                    labelPosX.Text = "";
                    labelPosY.Text = "";
                    labelRotate.Text = "";
                    labelScore.Text = "";
                    labelAlignExeTime.Text = "";
                }
            }
        }
        private void pictureboxSrc_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                IsSelecting = true;
                SelectionRectangle = new Rectangle(e.Location, new System.Drawing.Size());
            }
        }
        private void pictureSrc_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsSelecting)
            {
                SelectionRectangle.Width = e.X - SelectionRectangle.X;
                SelectionRectangle.Height = e.Y - SelectionRectangle.Y;
                pictureboxSrc.Invalidate();
            }
        }
        private void pictureboxSrc_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsSelecting)
            {
                IsSelecting = false;
                Rect patternCropRoi = UIRecToImageRec(SelectionRectangle);
                PatternCenterX = Convert.ToInt32(patternCropRoi.X + patternCropRoi.Width / 2);
                PatternCenterY = Convert.ToInt32(patternCropRoi.Y + patternCropRoi.Height / 2);

                Mat croppedImage = CropImage(SrcImage, patternCropRoi);
                if (croppedImage == null)
                {
                    return;
                }
                PatternPath = "./pattern.bmp";
                //croppedImage.SaveImage(PatternPath);
                buttonExecute.Enabled = true;
            }
        }
        private void pictureboxSrc_Paint(object sender, PaintEventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null) return;
                
            if (IsSelecting)
            {
                e.Graphics.DrawRectangle(Pens.Red, SelectionRectangle);
            }
            else
            {
                int alignBuffer = 128;
                double wScale = (double)pictureboxSrc.Width / pictureboxSrc.Image.Width;
                double hScale = (double)pictureboxSrc.Height / pictureboxSrc.Image.Height;
                Rectangle autoSelectionRectangle = new Rectangle(Convert.ToInt32(alignBuffer * wScale),
                                                                 Convert.ToInt32(alignBuffer * hScale),
                                                                 Convert.ToInt32((pictureboxSrc.Image.Width - alignBuffer * 2) * wScale),
                                                                 Convert.ToInt32((pictureboxSrc.Image.Height - alignBuffer * 2) * hScale));
                e.Graphics.DrawRectangle(Pens.Red, autoSelectionRectangle);
            }
        }
        private void PictureboxCpr_Paint(object sender, PaintEventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null) return;

            PointF[] drawMatchPolygon = new PointF[4];
            for (int i = 0; i < 4; i++)
            {
                drawMatchPolygon[i].X = MatchRectangle[i].X * pictureboxCpr.Width / pictureboxCpr.Image.Width;
                drawMatchPolygon[i].Y = MatchRectangle[i].Y * pictureboxCpr.Height / pictureboxCpr.Image.Height;
            }
            e.Graphics.DrawPolygon(Pens.Red, drawMatchPolygon);
        }
        #endregion

        #region ProcessBar
        private void UpdateProgress(int percentage, string status)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => UpdateProgress(percentage, status)));
                return;
            }

            progressBar1.Value = percentage;
            progressLabel.Text = status;
        }

        private void ShowProgress()
        {
            progressBar1.Value = 0;
            progressBar1.Visible = true;
            progressLabel.Visible = true;
        }

        private void HideProgress()
        {
            progressBar1.Visible = false;
            progressLabel.Visible = false;
        }

        #endregion

        #region Tool
        private Mat CropImage(Mat sourceImage, Rect cropArea)
        {
            // Create a Region of Interest (ROI) based on the crop area
            if (cropArea.X < 0 || 
                cropArea.Y < 0 || 
                cropArea.X + cropArea.Width > sourceImage.Width || 
                cropArea.Y + cropArea.Height > sourceImage.Height)
                return null;

            Mat croppedImage = new Mat(sourceImage, cropArea);
            return croppedImage;
        }
        private Rect UIRecToImageRec(Rectangle selectionRectangle)
        {
            // 將選擇區域的座標和大小進行調整，以確保都是正值
            if (selectionRectangle.Width < 0)
            {
                selectionRectangle.X += selectionRectangle.Width;
                selectionRectangle.Width = -selectionRectangle.Width;
            }
            if (selectionRectangle.Height < 0)
            {
                selectionRectangle.Y += selectionRectangle.Height;
                selectionRectangle.Height = -selectionRectangle.Height;
            }

            int patternCropX = Convert.ToInt32(selectionRectangle.X * pictureboxSrc.Image.Width / pictureboxSrc.Width);
            int patternCropY = Convert.ToInt32(selectionRectangle.Y * pictureboxSrc.Image.Height / pictureboxSrc.Height);
            int patternWidth = Convert.ToInt32(selectionRectangle.Width * pictureboxSrc.Image.Width / pictureboxSrc.Width);
            int patternHeight = Convert.ToInt32(selectionRectangle.Height * pictureboxSrc.Image.Height / pictureboxSrc.Height);

            Rect patternCropRoi = new Rect(patternCropX, patternCropY, patternWidth, patternHeight);
            return patternCropRoi;
        }
        private Mat RotateImage(Mat image,int rotateX,int rotateY, double angle)
        {
            // 設定旋轉中心點
            Point2f center = new Point2f(rotateY, rotateX);

            // 計算旋轉矩陣
            Mat rotationMatrix = Cv2.GetRotationMatrix2D(center, angle, 1.0);

            // 進行圖片旋轉
            Mat rotatedImage = new Mat();
            Cv2.WarpAffine(image, rotatedImage, rotationMatrix, image.Size());
            return rotatedImage;
        }
        private void ShowMatchFail()
        {
            labelPosX.Text = "match fail";
            labelPosY.Text = "match fail";
            labelRotate.Text = "match fail";
            labelScore.Text = "match fail";
            labelAlignExeTime.Text = "match fail";
            MatchRectangle = new PointF[4];
            pictureboxCpr.Invalidate();
        }
        private void ShowOutofRegion()
        {
            labelPosX.Text = "out of region";
            labelPosY.Text = "out of region";
            labelRotate.Text = "out of region";
            labelScore.Text = "out of region";
            labelAlignExeTime.Text = "out of region";
            MatchRectangle = new PointF[4];
            pictureboxCpr.Invalidate();
        }
        private void ShowResult(PatternMatchResult result)
        {
            MatchRectangle[0] = result.ptLT;
            MatchRectangle[1] = result.ptRT;
            MatchRectangle[2] = result.ptRB;
            MatchRectangle[3] = result.ptLB;
            MatchCenterX = Convert.ToInt32(result.ptCenter.X);
            MatchCenterY = Convert.ToInt32(result.ptCenter.Y);
            MatchRotate = Math.Round(result.Angle, 3);
            MatchScore = Math.Round(result.Score, 5);

            labelPosX.Text = MatchCenterX.ToString();
            labelPosY.Text = MatchCenterY.ToString();
            labelRotate.Text = MatchRotate.ToString() + " deg";
            labelScore.Text = MatchScore.ToString();
        }
        private string[] SelectFoldersWithDialog(string[] discriptions)
        {
            string[] paths = new string[discriptions.Length];
            using (var dialog = new FolderBrowserDialog())
            {
                for (int i = 0; i < discriptions.Length; i++)
                {
                    dialog.Description = discriptions[i];
                    if (dialog.ShowDialog() != DialogResult.OK)
                        throw new OperationCanceledException("使用者取消選擇資料夾");
                    string path = dialog.SelectedPath;
                    paths[i] = path;
                }
            }
            return paths;
        }
        private void ValidateFolders(string okFolder, string ngFolder, string labelFolder)
        {
            var okFiles = Directory.GetFiles(okFolder).Select(f => Path.GetFileNameWithoutExtension(f)).ToList();
            var ngFiles = Directory.GetFiles(ngFolder).Select(f => Path.GetFileNameWithoutExtension(f)).ToList();
            var labelFiles = Directory.GetFiles(labelFolder).Select(f => Path.GetFileNameWithoutExtension(f)).ToList();

            if (okFiles.Count != ngFiles.Count)
            {
                throw new InvalidOperationException("OK和NG資料夾的檔案數量不一致");
            }

            if (!okFiles.SequenceEqual(ngFiles))
            {
                throw new InvalidOperationException("OK和NG資料夾的檔案名稱不一致");
            }

            var invalidLabels = labelFiles.Except(okFiles).ToList();
            if (invalidLabels.Any())
            {
                throw new InvalidOperationException(
                    $"Label資料夾中有不對應的檔案: {string.Join(", ", invalidLabels)}");
            }
        }
        private void ValidateFolders(string okFolder, string ngFolder)
        {
            var okFiles = Directory.GetFiles(okFolder).Select(f => Path.GetFileNameWithoutExtension(f)).ToList();
            var ngFiles = Directory.GetFiles(ngFolder).Select(f => Path.GetFileNameWithoutExtension(f)).ToList();

            if (okFiles.Count != ngFiles.Count)
            {
                throw new InvalidOperationException("OK和NG資料夾的檔案數量不一致");
            }

            if (!okFiles.SequenceEqual(ngFiles))
            {
                throw new InvalidOperationException("OK和NG資料夾的檔案名稱不一致");
            }
        }
        private void SplitAndProcessData(string okFolder, string ngFolder, string labelFolder, string outputBasePath)
        {
            var okFiles = Directory.GetFiles(okFolder).ToList();
            Random rnd = new Random();
            okFiles = okFiles.OrderBy(x => rnd.Next()).ToList();

            int totalCount = okFiles.Count;
            int testCount = (int)(totalCount * 0.15);
            int validCount = (int)(totalCount * 0.15);
            int trainCount = totalCount - testCount - validCount;

            var testFiles = okFiles.Take(testCount).ToList();
            var validFiles = okFiles.Skip(testCount).Take(validCount).ToList();
            var trainFiles = okFiles.Skip(testCount + validCount).Take(trainCount).ToList();

            CreateDirectories(outputBasePath);

            ProcessDataset("test", testFiles, okFolder, ngFolder, labelFolder, outputBasePath, UpdateProgress);
            ProcessDataset("valid", validFiles, okFolder, ngFolder, labelFolder, outputBasePath, UpdateProgress);
            ProcessDataset("train", trainFiles, okFolder, ngFolder, labelFolder, outputBasePath, UpdateProgress);
        }
        private void CreateDirectories(string basePath)
        {
            foreach (var dataset in new[] { "test", "valid", "train" })
            {
                Directory.CreateDirectory(Path.Combine(basePath, dataset, "A"));
                Directory.CreateDirectory(Path.Combine(basePath, dataset, "B"));
                Directory.CreateDirectory(Path.Combine(basePath, dataset, "label"));
            }
        }
        private void ProcessDataset(string datasetName, List<string> files, string okFolder, string ngFolder, string labelFolder, string basePath, Action<int, string> progressCallback)
        {
            int totalFiles = files.Count;
            int currentFile = 0;

            foreach (var okFile in files)
            {
                currentFile++;
                string baseName = Path.GetFileNameWithoutExtension(okFile);

                // 計算總體進度百分比
                int percentage = (int)((double)currentFile / totalFiles * 100);
                progressCallback(percentage, $"Processing {datasetName} dataset: {currentFile}/{totalFiles} - {baseName}");

                string ngFile = Directory.GetFiles(ngFolder, baseName + ".*").FirstOrDefault()
                    ?? throw new FileNotFoundException($"找不到對應的NG檔案: {baseName}");

                string labelFile = Directory.GetFiles(labelFolder, baseName + ".*").FirstOrDefault();

                using (var okImage = new Mat(okFile))
                using (var ngImage = new Mat(ngFile))
                {
                    if (okImage.Empty() || ngImage.Empty())
                    {
                        throw new InvalidOperationException($"無法讀取圖片: {baseName}");
                    }

                    int rows = okImage.Rows / PATCH_SIZE;
                    int cols = okImage.Cols / PATCH_SIZE;

                    for (int i = 0; i < rows; i++)
                    {
                        for (int j = 0; j < cols; j++)
                        {
                            var roi = new Rect(j * PATCH_SIZE, i * PATCH_SIZE, PATCH_SIZE, PATCH_SIZE);

                            using (var okPatch = new Mat(okImage, roi))
                            using (var ngPatch = new Mat(ngImage, roi))
                            {
                                okPatch.SaveImage(Path.Combine(basePath, datasetName, "A", $"{baseName}_{i}_{j}.png"));
                                ngPatch.SaveImage(Path.Combine(basePath, datasetName, "B", $"{baseName}_{i}_{j}.png"));

                                if (labelFile != null)
                                {
                                    using (var labelImage = new Mat(labelFile,ImreadModes.Grayscale))
                                    {
                                        if (labelImage.Empty())
                                        {
                                            throw new InvalidOperationException($"無法讀取Label圖片: {baseName}");
                                        }
                                        using (var labelPatch = new Mat(labelImage, roi))
                                        {
                                            labelPatch.SaveImage(Path.Combine(basePath, datasetName, "label", $"{baseName}_{i}_{j}.png"));
                                        }
                                    }
                                }
                                else //無標註建立全黑label
                                {
                                    using (Mat labelImage = Mat.Zeros(okImage.Rows,okImage.Cols,MatType.CV_8UC1))
                                    {
                                        using (var labelPatch = new Mat(labelImage, roi))
                                        {
                                            labelPatch.SaveImage(Path.Combine(basePath, datasetName, "label", $"{baseName}_{i}_{j}.png"));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        private void ProcessImageAlignment(string okPath, string ngPath, string outputPath, Action<int, string> progressCallback)
        {
            Directory.CreateDirectory(outputPath + "\\OK");
            Directory.CreateDirectory(outputPath + "\\NG");
            string[] okFiles = Directory.GetFiles(okPath, "*.*").Where(f => IsImageFile(f)).ToArray();
            int totalFiles = okFiles.Length;
            int currentFile = 0;

            foreach (string okFilePath in okFiles)
            {
                currentFile++;
                string fileName = Path.GetFileName(okFilePath);
                string ngFilePath = Path.Combine(ngPath, fileName);

                // 更新進度
                int percentage = (int)((double)currentFile / totalFiles * 100);
                progressCallback(percentage, $"Processing file {currentFile}/{totalFiles} - {fileName}");

                // 檢查NG資料夾中是否存在相對應的檔案
                if (!File.Exists(ngFilePath))
                {
                    throw new Exception($"Warning: Corresponding NG image not found for {fileName}");
                }

                // 讀取圖片
                using (Mat srcImage = Cv2.ImRead(ngFilePath))
                using (Mat cprImage = Cv2.ImRead(okFilePath))
                {
                    // 檢查圖片是否成功讀取
                    if (srcImage.Empty() || cprImage.Empty())
                    {
                        throw new Exception($"Error: Failed to read images for {fileName}");
                    }

                    // 準備對位後的圖片變數
                    Mat alignSrcImage = new Mat();
                    Mat alignCprImage = new Mat();
                    PatternMatchResult alignResult = new PatternMatchResult();
                    string alignFail = "";

                    try
                    {
                        aifAlgorithm.DoAutoAlignment(srcImage, cprImage, ref alignSrcImage, ref alignCprImage, ref alignResult);
                    }
                    catch (Exception)
                    {
                        alignFail = alignFail + fileName + ", ";
                        continue;
                    }

                    // 對位成功，儲存到OK資料夾
                    string okOutputPath = Path.Combine(outputPath + "\\OK", fileName);
                    alignCprImage.SaveImage(okOutputPath);

                    // 對位成功，儲存到NG資料夾
                    string ngOutputPath = Path.Combine(outputPath + "\\NG", fileName);
                    alignSrcImage.SaveImage(ngOutputPath);

                    if (alignFail != "") MessageBox.Show("Alignment fail list ->" + alignFail);
                }
            }
        }
        #endregion

        #region Main Button

        private void buttonAutoAlign_Click(object sender, EventArgs e)
        {
            if (pictureboxSrc.Image == null || pictureboxCpr.Image == null ) return;
            PatternMatchResult alignResult = new PatternMatchResult();

            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                
                if (aifAlgorithm.DoAutoAlignment(SrcImage, CprImage, ref AlignSrcImage,ref AlignCprImage,ref alignResult))
                {
                    ShowResult(alignResult);
                    stopwatch.Stop();

                    pictureboxSrc.Invalidate();
                    pictureboxCpr.Invalidate();
                    labelAlignExeTime.Text = stopwatch.Elapsed.TotalMilliseconds.ToString() + " ms";

                    if (checkBox_SaveResult.Checked)
                    {
                        AlignSrcImage.SaveImage(AlignPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_pattern" + Path.GetExtension(SrcImagePath));
                        AlignCprImage.SaveImage(AlignPath + Path.GetFileName(CprImagePath));
                    }
                }
            }
            catch(Exception ex)
            {
                ShowMatchFail();
                MessageBox.Show(ex.ToString());
            }
        }

        private void buttonLoadModel_Click(object sender, EventArgs e)
        {
            try
            {
                if (aifAlgorithm.DoLoadAIModel())
                {
                    buttonLoadModel.BackColor = Color.LimeGreen;
                    buttonDetect.Enabled = true;
                    buttonFreeModel.Enabled = true;
                    MessageBox.Show("Load Model Successful !");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load Model Fail : " + ex.Message);
            }
        }

        private void buttonDetect_Click(object sender, EventArgs e)
        {
            Bitmap mask = null;
            Bitmap result = null;
            List<AIFAlgorithm.Defect> defectList = new List<AIFAlgorithm.Defect>();
            Stopwatch sw = new Stopwatch();
            try
            {
                if (AlignSrcImage == null || AlignCprImage == null) return;

                sw.Start();
                if(aifAlgorithm.DoInspection(AlignSrcImage, AlignCprImage,ref mask) != true)
                {

                }
                
                
                if (aifAlgorithm.DoOutputResult(SrcImage, mask, ref result, ref defectList))
                {

                }
                sw.Stop();
                labelTotalTime.Text = sw.Elapsed.TotalMilliseconds.ToString() + " ms";
                pictureboxRst.Image = result;
                pictureboxRst.Invalidate();
                result.Save(ResultPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_result.png");
                mask.Save(ResultPath + Path.GetFileNameWithoutExtension(SrcImagePath) + "_mask.png");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mask?.Dispose();
                defectList?.Clear();
            }
        }

        private void buttonFreeModel_Click(object sender, EventArgs e)
        {
            if (aifAlgorithm.DoDisposeAIModel())
            {
                buttonDetect.Enabled = false;
                buttonLoadModel.Enabled = true;
                buttonLoadModel.BackColor = Color.White;
                buttonFreeModel.Enabled = false;
            }
        }

        private void buttonBatchAutoAlign_Click(object sender, EventArgs e)
        {
            Mat srcImage = new Mat();
            Mat cprImage = new Mat();
            Mat alignSrcImage = new Mat();
            Mat alignCprImage = new Mat();
            PatternMatchResult alignResult = new PatternMatchResult();
            Bitmap maskImage = null;
            OpenFileDialog openFileDialogSrc = new OpenFileDialog();
            openFileDialogSrc.Title = "Select the image to be detected.";
            openFileDialogSrc.Multiselect = true; // 允許多選
            openFileDialogSrc.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.tif";

            FolderBrowserDialog folderBrowserDialogCpr = new FolderBrowserDialog();
            string alignFail = "";

            try
            {
                if (openFileDialogSrc.ShowDialog() == DialogResult.OK)
                {
                    folderBrowserDialogCpr.Description = "Select the golden sample folder.";
                    folderBrowserDialogCpr.SelectedPath = Path.GetDirectoryName(openFileDialogSrc.FileName);
                    string[] ngFileNames = openFileDialogSrc.FileNames;

                    if (folderBrowserDialogCpr.ShowDialog() == DialogResult.OK)
                    {
                        foreach (string srcImagePath in ngFileNames)
                        {
                            string cprImagePath = folderBrowserDialogCpr.SelectedPath + "\\" + Path.GetFileName(srcImagePath);

                            if (File.Exists(srcImagePath) && File.Exists(cprImagePath))
                            {
                                srcImage = Cv2.ImRead(srcImagePath);
                                cprImage = Cv2.ImRead(cprImagePath);
                                pictureboxSrc.Image = Image.FromFile(srcImagePath);
                                pictureboxCpr.Image = Image.FromFile(cprImagePath);

                                try
                                {
                                    aifAlgorithm.DoAutoAlignment(srcImage, cprImage, ref alignSrcImage, ref alignCprImage, ref alignResult);
                                }
                                catch(Exception)
                                {
                                    alignFail = alignFail + Path.GetFileName(srcImagePath) + ", ";
                                    continue;
                                }

                                aifAlgorithm.DoInspection(alignSrcImage, alignCprImage,ref maskImage);
                                Bitmap resultImage = aifAlgorithm.DrawResult(maskImage, srcImage);
                                List<AIFAlgorithm.Defect> defectList = aifAlgorithm.ShowDefect(maskImage);
                                pictureboxRst.Image = resultImage;
                                resultImage.Save(ResultPath + Path.GetFileNameWithoutExtension(srcImagePath) + "_result.png");
                                maskImage.Save(ResultPath + Path.GetFileNameWithoutExtension(srcImagePath) + "_mask.png");
                            }
                            else
                            {
                                alignFail = alignFail + Path.GetFileName(srcImagePath) + ", ";
                                continue;
                            }
                        }
                        if(alignFail != "") MessageBox.Show("Alignment fail list ->" + alignFail);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Auto Align fail." + ex.Message);
            }
            finally
            {
                srcImage.Dispose();
                cprImage.Dispose();
                alignSrcImage.Dispose();
                alignCprImage.Dispose();
            }
        }

        private void buttonGenerateTrainingData_Click(object sender, EventArgs e)
        {
            try
            {
                ShowProgress();
                string outputBasePath = "./output_training";
                string[] discribtions = new string[] { "選擇OK資料夾", "選擇NG資料夾", "選擇Label資料夾" };
                string[] paths = SelectFoldersWithDialog(discribtions);
                string okPath = paths[0];
                string ngPath = paths[1];
                string labelPath = paths[2];
                ValidateFolders(okPath, ngPath, labelPath);
                SplitAndProcessData(okPath, ngPath, labelPath, outputBasePath);
                MessageBox.Show("Generate Training Data Successful.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Generate Training Data fail." + ex.Message);
            }
            finally
            {
                HideProgress();
            }
        }
        private void buttonAlignTrainData_Click(object sender, EventArgs e)
        {
            try
            {
                ShowProgress();
                string outputPath = "./output_alignment";
                string[] discribtions = new string[] { "選擇OK資料夾", "選擇NG資料夾"};
                string[] paths = SelectFoldersWithDialog(discribtions);

                string okPath = paths[0];
                string ngPath = paths[1];
                ValidateFolders(okPath, ngPath);
                ProcessImageAlignment(okPath, ngPath, outputPath, UpdateProgress);
                MessageBox.Show("Alignment Training Data Successful.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alignment Training Data fail." + ex.Message);
            }
            finally
            {
                HideProgress();
            }
        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            FormBootConfig frm = new FormBootConfig();
            frm.SetConfig(ConfigPath);
            frm.ShowDialog(this);
            try
            {
                aifAlgorithm.LoadConfig(ConfigPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion
    }
}
