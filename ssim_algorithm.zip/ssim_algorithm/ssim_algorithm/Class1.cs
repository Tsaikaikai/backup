﻿using System;
using Opencvsharp;
namespace ssim_algorithm
{
    public class SSIM
    {
        public static Scalar CalculateSSIM(Mat i1, Mat i2)
        {
            const double C1 = 6.5025, C2 = 58.5225;
            /***************************** INITS **********************************/
            MatType d = MatType.CV_32F;

            Mat EXTRA0 = new Mat(), EXTRA1 = new Mat();
            i1.ConvertTo(EXTRA0, d);           // cannot calculate on one byte large values
            i2.ConvertTo(EXTRA1, d);

            Mat EXTRA2 = EXTRA0.Mul(EXTRA0);        // I1^2
            Mat EXTRA3 = EXTRA1.Mul(EXTRA1);        // I2^2
            Mat EXTRA4 = EXTRA0.Mul(EXTRA1);        // I1 * I2

            /***********************PRELIMINARY COMPUTING ******************************/

            Mat EXTRA5 = new Mat(), EXTRA6 = new Mat();   //
            Cv2.GaussianBlur(EXTRA0, EXTRA5, new OpenCvSharp.Size(11, 11), 1.5);
            Cv2.GaussianBlur(EXTRA1, EXTRA6, new OpenCvSharp.Size(11, 11), 1.5);

            Mat EXTRA7 = EXTRA5.Mul(EXTRA5);
            Mat EXTRA8 = EXTRA6.Mul(EXTRA6);
            Mat EXTRA9 = EXTRA5.Mul(EXTRA6);

            Mat EXTRA10 = new Mat(), EXTRA11 = new Mat(), EXTRA12 = new Mat();

            Cv2.GaussianBlur(EXTRA2, EXTRA10, new OpenCvSharp.Size(11, 11), 1.5);
            Cv2.GaussianBlur(EXTRA3, EXTRA11, new OpenCvSharp.Size(11, 11), 1.5);        
            Cv2.GaussianBlur(EXTRA4, EXTRA12, new OpenCvSharp.Size(11, 11), 1.5);
            

            EXTRA10 = EXTRA10 - EXTRA7;
            EXTRA11 = EXTRA11 - EXTRA8;
            EXTRA12 = EXTRA12 - EXTRA9;


            ///////////////////////////////// FORMULA ////////////////////////////////
            Mat EXTRA13, EXTRA14, EXTRA15;

            EXTRA13 = 2 * EXTRA9 ;
            EXTRA13 = EXTRA13 + C1;

            EXTRA14 = 2 * EXTRA12 ;
            EXTRA14 = EXTRA14 + C2;

            EXTRA15 = EXTRA13.Mul(EXTRA14);              // t3 = ((2*mu1_mu2 + C1).*(2*sigma12 + C2))



            EXTRA13 = EXTRA7 + EXTRA8 ;
            EXTRA13 = EXTRA13 + C1;

            EXTRA14 = EXTRA10 + EXTRA11 ;
            EXTRA14 = EXTRA14 + C2;

            EXTRA13 = EXTRA13.Mul(EXTRA14);               // t1 =((mu1_2 + mu2_2 + C1).*(sigma1_2 + sigma2_2 + C2))

            Mat EXTRA16 = new Mat();
            Cv2.Divide(EXTRA15, EXTRA13, EXTRA16);      // ssim_map =  t3./t1;


            Scalar mssim = Cv2.Mean(EXTRA16);// mssim = average of ssim map
            return mssim;
        }
    }
}
